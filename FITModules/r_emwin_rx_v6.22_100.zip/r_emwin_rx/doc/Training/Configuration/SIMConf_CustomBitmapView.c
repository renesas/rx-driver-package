#include "LCD_SIM.h"

void SIM_X_Config() {
  SIM_GUI_UseCustomBitmaps();
  SIM_GUI_SetLCDPos(50, 20);
}
