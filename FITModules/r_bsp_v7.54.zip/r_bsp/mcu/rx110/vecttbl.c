/*
* Copyright (c) 2011 Renesas Electronics Corporation and/or its affiliates
*
* SPDX-License-Identifier: BSD-3-Clause
*/
/***********************************************************************************************************************
* File Name    : vecttbl.c
* Device(s)    : RX110
* Description  : Definition of the fixed vector table and option setting memory.
***********************************************************************************************************************/
/***********************************************************************************************************************
* History : DD.MM.YYYY Version  Description
*         : 08.11.2012 1.00     First Release
*         : 19.11.2012 1.10     Updated code to use 'BSP_' and 'BSP_CFG_' prefix for macros.
*         : 06.05.2013 1.20     Code auto detects endian from compiler macros now.
*         : 24.06.2013 1.30     Code now uses functions from mcu_interrupts.c for exception callbacks. All interrupts
*                               that map to NMI vector are now supported.
*         : 01.11.2017 2.00     Added the bsp startup module disable function.
*         : 27.07.2018 2.01     Deleted the static analysis tool comment.
*         : 28.02.2019 3.00     Deleted exception functions.
*                               (Exception functions moved to the common file (r_bsp_interrupts.c).)
*                               Added support for GNUC and ICCRX.
*                               Fixed coding style.
*         : 08.10.2019 3.01     Changed for added support of Renesas RTOS (RI600V4 or RI600PX).
*         : 26.02.2025 3.02     Changed the disclaimer.
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
/* BSP configuration. */
#include "platform.h"

/* When using the user startup program, disable the following code. */
#if BSP_CFG_STARTUP_DISABLE == 0

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Exported global functions (to be accessed by other files)
***********************************************************************************************************************/
R_BSP_POR_FUNCTION(R_BSP_POWER_ON_RESET_FUNCTION);

/***********************************************************************************************************************
* The following array fills in the endian and option function select registers, and the fixed vector table
* bytes.
***********************************************************************************************************************/
#ifdef __BIG
    #define BSP_PRV_MDE_VALUE (0xfffffff8)    /* big */
#else
    #define BSP_PRV_MDE_VALUE (0xffffffff)    /* little */
#endif

#if defined(__ICCRX__)

#pragma public_equ = "__MDES", BSP_PRV_MDE_VALUE
#pragma public_equ = "__OFS1", BSP_CFG_OFS1_REG_VALUE
#pragma public_equ = "__OFS0", BSP_CFG_OFS0_REG_VALUE
#pragma public_equ = "__ID_BYTES_1_4", BSP_CFG_ID_CODE_LONG_1
#pragma public_equ = "__ID_BYTES_5_8", BSP_CFG_ID_CODE_LONG_2
#pragma public_equ = "__ID_BYTES_9_12", BSP_CFG_ID_CODE_LONG_3
#pragma public_equ = "__ID_BYTES_13_16", BSP_CFG_ID_CODE_LONG_4

#endif /* defined(__ICCRX__) */

#if BSP_CFG_RTOS_USED == 4  /* Renesas RI600V4 & RI600PX */
     /* System configurator generates the ritble.src as interrupt & exception vector tables. */
#else /* BSP_CFG_RTOS_USED!=4 */

#if defined(__CCRX__) || defined(__GNUC__)
R_BSP_ATTRIB_SECTION_CHANGE_FIXEDVECT void * const Fixed_Vectors[] =
{
    /* The Endian select register (MDE), Option function select register 1 (OFS1), and Option function select
       register 0 (OFS0) are located in User ROM. */
    (void *)BSP_PRV_MDE_VALUE,        /* 0xffffff80 - MDE */
    (void *)0xFFFFFFFF,               /* 0xffffff84 - Reserved */
    (void *)BSP_CFG_OFS1_REG_VALUE,   /* 0xffffff88 - OFS1 */
    (void *)BSP_CFG_OFS0_REG_VALUE,   /* 0xffffff8c - OFS0 */

    /* 0xffffff90 through 0xffffffaf: Reserved area */
    (void *)0xFFFFFFFF,   /* 0xffffff90 - Reserved */
    (void *)0xFFFFFFFF,   /* 0xffffff94 - Reserved */
    (void *)0xFFFFFFFF,   /* 0xffffff98 - Reserved */
    (void *)0xFFFFFFFF,   /* 0xffffff9c - Reserved */

    /* 0xffffffa0 through 0xffffffaf: ID Code Protection. The ID code is specified using macros in r_bsp_config.h. */
    (void *) BSP_CFG_ID_CODE_LONG_1,  /* 0xffffffa0 - Control code and ID code */
    (void *) BSP_CFG_ID_CODE_LONG_2,  /* 0xffffffa4 - ID code (cont.) */
    (void *) BSP_CFG_ID_CODE_LONG_3,  /* 0xffffffa8 - ID code (cont.) */
    (void *) BSP_CFG_ID_CODE_LONG_4,  /* 0xffffffac - ID code (cont.) */

    /* 0xffffffb0 through 0xffffffcf: Reserved area */
    (void *) 0xFFFFFFFF,  /* 0xffffffb0 - Reserved */
    (void *) 0xFFFFFFFF,  /* 0xffffffb4 - Reserved */
    (void *) 0xFFFFFFFF,  /* 0xffffffb8 - Reserved */
    (void *) 0xFFFFFFFF,  /* 0xffffffbc - Reserved */
    (void *) 0xFFFFFFFF,  /* 0xffffffc0 - Reserved */
    (void *) 0xFFFFFFFF,  /* 0xffffffc4 - Reserved */
    (void *) 0xFFFFFFFF,  /* 0xffffffc8 - Reserved */
    (void *) 0xFFFFFFFF,  /* 0xffffffcc - Reserved */

    /* Fixed vector table */
    (void *) excep_supervisor_inst_isr,         /* 0xffffffd0  Exception(Supervisor Instruction) */
    (void *) undefined_interrupt_source_isr,    /* 0xffffffd4  Reserved */
    (void *) undefined_interrupt_source_isr,    /* 0xffffffd8  Reserved */
    (void *) excep_undefined_inst_isr,          /* 0xffffffdc  Exception(Undefined Instruction) */
    (void *) undefined_interrupt_source_isr,    /* 0xffffffe0  Reserved */
    (void *) undefined_interrupt_source_isr,    /* 0xffffffe4  Reserved */
    (void *) undefined_interrupt_source_isr,    /* 0xffffffe8  Reserved */
    (void *) undefined_interrupt_source_isr,    /* 0xffffffec  Reserved */
    (void *) undefined_interrupt_source_isr,    /* 0xfffffff0  Reserved */
    (void *) undefined_interrupt_source_isr,    /* 0xfffffff4  Reserved */
    (void *) non_maskable_isr,                  /* 0xfffffff8  NMI */
    (void *) R_BSP_POWER_ON_RESET_FUNCTION      /* 0xfffffffc  RESET */
};
R_BSP_ATTRIB_SECTION_CHANGE_END
#endif /* defined(__CCRX__), defined(__GNUC__) */

#endif/* BSP_CFG_RTOS_USED */

#endif /* BSP_CFG_STARTUP_DISABLE == 0 */

