/**********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO
 * THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2021 Renesas Electronics Corporation. All rights reserved.
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * File Name    : LCDConf.c
 * Version      : 1.30
 * Description  : Display controller configuration (single layer).
 *********************************************************************************************************************/
/**********************************************************************************************************************
 * History : DD.MM.YYYY Version  Description
 *         : 31.07.2020 1.00     First Release
 *         : 04.09.2020 1.10     Update to adjust r_emwin_rx_config.h file.
 *         : 11.12.2020 1.20     Update to adjust emWin v6.14g. Modify multi-touch and timer function.
 *                               Adjust GCC and IAR compilers.
 *         : 31.03.2021 1.30     Update to adjust the spec of Smart Configurator and QE for Display.
 *********************************************************************************************************************/

/* MultiBuffering:
 *  emWin requires 3 buffers to be able to work with efficiently.
 *  The available On-chip RAM unfortunately restricts use of
 *  3 buffers for MultiBuffering to 1- and 4bpp mode.
 *  In 8bpp the line offset is 512, because LNOFF needs to be a
 *  multiple of 0x40 (see GRnFLM3.LNOFF). In that case
 *  0x200 * 0x110 * 3 = 0x66000 bytes are required. But
 *  unfortunately the size of the memory area is only 0x60000.
 *  In that case DoubleBuffering is used. In that mode the CPU has to
 *  wait for the next VSYNC interrupt in case of a new frame buffer.
 *
 * 32bpp mode:
 *  Has not been tested because of a lack of RAM. */

/**********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 *********************************************************************************************************************/
#include <stdint.h>
#include <stdlib.h>
#include "GUI.h"
#include "GUIDRV_Lin.h"
#include "LCDConf.h"

#include "platform.h"
#include "r_glcdc_rx_if.h"
#include "r_pinset.h"
#include "r_dmaca_rx_if.h"
#include "r_gpio_rx_if.h"
#include "r_emwin_rx_if.h"

#if (USE_DAVE2D == 1)
#include "dave_base.h"
#include "dave_driver.h"
#endif

/**********************************************************************************************************************
 Macro definitions
 *********************************************************************************************************************/
/* Color format selection */
#define FORMAT_RGB_565   (GLCDC_IN_FORMAT_16BITS_RGB565)
#define FORMAT_RGB_888   (GLCDC_IN_FORMAT_32BITS_RGB888)
#define FORMAT_ARGB_1555 (GLCDC_IN_FORMAT_16BITS_ARGB1555)
#define FORMAT_ARGB_4444 (GLCDC_IN_FORMAT_16BITS_ARGB4444)
#define FORMAT_ARGB_8888 (GLCDC_IN_FORMAT_32BITS_ARGB8888)
#define FORMAT_CLUT_8    (GLCDC_IN_FORMAT_CLUT8)
#define FORMAT_CLUT_4    (GLCDC_IN_FORMAT_CLUT4)
#define FORMAT_CLUT_1    (GLCDC_IN_FORMAT_CLUT1)

/* Color conversion, display driver and multiple buffers */
#if   (EMWIN_BITS_PER_PIXEL == 32)
#define COLOR_CONVERSION (GUICC_M8888I)
#if (EMWIN_DISPLAY_ORIENTATION == ORIENTATION_0)
#define DISPLAY_DRIVER   (GUIDRV_LIN_32)      /* Default */
#elif (EMWIN_DISPLAY_ORIENTATION == ORIENTATION_CW)
#define DISPLAY_DRIVER   (GUIDRV_LIN_OSX_32)  /* CW */
#elif (EMWIN_DISPLAY_ORIENTATION == ORIENTATION_CCW)
#define DISPLAY_DRIVER   (GUIDRV_LIN_OSY_32)  /* CCW */
#else
#define DISPLAY_DRIVER   (GUIDRV_LIN_OXY_32)  /* 180 */
#endif
#define NUM_BUFFERS      (1)
#define COLOR_FORMAT     (FORMAT_RGB_ARGB8888)
#elif (EMWIN_BITS_PER_PIXEL == 16)
#define COLOR_CONVERSION (GUICC_M565)
#if (EMWIN_DISPLAY_ORIENTATION == ORIENTATION_0)
#define DISPLAY_DRIVER   (GUIDRV_LIN_16)      /* Default */
#elif (EMWIN_DISPLAY_ORIENTATION == ORIENTATION_CW)
#define DISPLAY_DRIVER   (GUIDRV_LIN_OSX_16)  /* CW */
#elif (EMWIN_DISPLAY_ORIENTATION == ORIENTATION_CCW)
#define DISPLAY_DRIVER   (GUIDRV_LIN_OSY_16)  /* CCW */
#else
#define DISPLAY_DRIVER   (GUIDRV_LIN_OXY_16)  /* 180 */
#endif
#define NUM_BUFFERS      (2)
#define COLOR_FORMAT     (FORMAT_RGB_565)
#elif (EMWIN_BITS_PER_PIXEL == 8)
#define COLOR_CONVERSION (GUICC_8666)
#if (EMWIN_DISPLAY_ORIENTATION == ORIENTATION_0)
#define DISPLAY_DRIVER   (GUIDRV_LIN_8)      /* Default */
#elif (EMWIN_DISPLAY_ORIENTATION == ORIENTATION_CW)
#define DISPLAY_DRIVER   (GUIDRV_LIN_OSX_8)  /* CW */
#elif (EMWIN_DISPLAY_ORIENTATION == ORIENTATION_CCW)
#define DISPLAY_DRIVER   (GUIDRV_LIN_OSY_8)  /* CCW */
#else
#define DISPLAY_DRIVER   (GUIDRV_LIN_OXY_8)  /* 180 */
#endif
#define NUM_BUFFERS      (2)
#define COLOR_FORMAT     (FORMAT_CLUT_8)
#elif (EMWIN_BITS_PER_PIXEL == 4)
#define COLOR_CONVERSION (GUICC_16)
#if (EMWIN_DISPLAY_ORIENTATION == ORIENTATION_0)
#define DISPLAY_DRIVER   (GUIDRV_LIN_4)      /* Default */
#elif (EMWIN_DISPLAY_ORIENTATION == ORIENTATION_CW)
#define DISPLAY_DRIVER   (GUIDRV_LIN_OSX_4)  /* CW */
#elif (EMWIN_DISPLAY_ORIENTATION == ORIENTATION_CCW)
#define DISPLAY_DRIVER   (GUIDRV_LIN_OSY_4)  /* CCW */
#else
#define DISPLAY_DRIVER   (GUIDRV_LIN_OXY_4)  /* 180 */
#endif
#define NUM_BUFFERS      (2)
#define COLOR_FORMAT     (FORMAT_CLUT_4)
#elif (EMWIN_BITS_PER_PIXEL == 1)
#define COLOR_CONVERSION (GUICC_1)
#if (EMWIN_DISPLAY_ORIENTATION == ORIENTATION_0)
#define DISPLAY_DRIVER   (GUIDRV_LIN_1)      /* Default */
#elif (EMWIN_DISPLAY_ORIENTATION == ORIENTATION_CW)
#define DISPLAY_DRIVER   (GUIDRV_LIN_OSX_1)  /* CW */
#elif (EMWIN_DISPLAY_ORIENTATION == ORIENTATION_CCW)
#define DISPLAY_DRIVER   (GUIDRV_LIN_OSY_1)  /* CCW */
#else
#define DISPLAY_DRIVER   (GUIDRV_LIN_OXY_1)  /* 180 */
#endif
#define NUM_BUFFERS      (2)
#define COLOR_FORMAT     (FORMAT_CLUT_1)
#endif

/* Buffer size and stride */
#define BYTES_PER_LINE   ((EMWIN_BITS_PER_PIXEL * EMWIN_XSIZE_PHYS) / 8)
#define LINE_OFFSET      (((BYTES_PER_LINE + 63) / 64) * 64)
#define VXSIZE_PHYS      ((LINE_OFFSET * 8) / EMWIN_BITS_PER_PIXEL)
#define BYTES_PER_BUFFER (LINE_OFFSET * EMWIN_YSIZE_PHYS)

/* Color number */
#if ((USE_DAVE2D == 0) && (EMWIN_BITS_PER_PIXEL < 16))
#define NUM_COLORS (1 << EMWIN_BITS_PER_PIXEL)
#else
#define NUM_COLORS  (256)
#endif

/**********************************************************************************************************************
 Local Typedef definitions
 *********************************************************************************************************************/
#if (USE_DAVE2D == 1)
#if (ORIENTATION_0 == EMWIN_DISPLAY_ORIENTATION)
typedef int DRAW_POLY_OUTLOINE (const GUI_POINT * p_src, int num_points, int thickness, int x, int y);
typedef int DRAW_ARC (int x0, int y0, int rx, int ry, I32 a0, I32 a1);
typedef int FILL_POLYGON (const GUI_POINT * p_points, int num_points, int x0, int y0);
#endif
typedef int FILL_CIRCLE (int x0, int y0, int r);
typedef int DRAW_CIRCLE (int x0, int y0, int r);
typedef int DRAW_LINE (int x0, int y0, int x1, int y1);
#endif

/* GLCDC FIT module setting check */
#if ((GLCDC_CFG_CONFIGURATION_MODE == 1) || defined(QE_DISPLAY_CONFIGURATION))

#if (EMWIN_XSIZE_PHYS != LCD_CH0_DISP_HW) || (EMWIN_XSIZE_PHYS != LCD_CH0_IN_GR2_HSIZE)
#warning "Warning!! There is a problem in the setting of the GLCDC FIT module.\n Missing the graphic layer 2 width setting."
#endif

#if (EMWIN_YSIZE_PHYS != LCD_CH0_DISP_VW) || (EMWIN_YSIZE_PHYS != LCD_CH0_IN_GR2_VSIZE)
#warning "Warning!! There is a problem in the setting of the GLCDC FIT module.\n Missing the graphic layer 2 height setting."
#endif

#if (LINE_OFFSET != LCD_CH0_IN_GR2_LINEOFFSET)
#warning "Warning!! There is a problem in the setting of the GLCDC FIT module.\n Missing the graphic layer 2 line offset setting."
#endif

#ifndef __GNUC__
#if (LCD_CH0_IN_GR1_PBASE != NULL)
#warning "Warning!! There is a problem in the setting of the GLCDC FIT module.\n Missing the graphic layer 1 setting."
#endif
#else
    /* Please check the graphic layer 1 setting. */
#endif

#if (LCD_CH0_DETECT_VPOS != true)
#warning "Warning!! There is a problem in the setting of the GLCDC FIT module.\n Missing the line detection setting."
#endif

#if (LCD_CH0_INTERRUPT_VPOS_ENABLE != true)
#warning "Warning!! There is a problem in the setting of the GLCDC FIT module.\n Missing the line detection interrupt setting."
#endif

#if (LCD_CH0_CALLBACK_ENABLE != true)
#warning "Warning!! There is a problem in the setting of the GLCDC FIT module.\n Missing the callback function setting. "
#endif

#endif /* ((GLCDC_CFG_CONFIGURATION_MODE != 1) && !defined(QE_DISPLAY_CONFIGURATION)) */


/* emWin FIT module setting check */
#if (EMWIN_BITS_PER_PIXEL != 16)
#warning "Warning!! The setting of the color depth is not suitale for emWin FIT module."
#endif

/**********************************************************************************************************************
 Exported global variables
 *********************************************************************************************************************/

/**********************************************************************************************************************
 Private (static) variables and functions
 *********************************************************************************************************************/
static const uint32_t s_a_buffer_ptr[] =
{
    EMWIN_GUI_FRAME_BUFFER1,  /* Begin of On-Chip RAM */
    EMWIN_GUI_FRAME_BUFFER2   /* Begin of Expansion RAM */
};

static volatile int32_t s_pending_buffer = -1;

static uint32_t s_write_buffer_index;

static glcdc_runtime_cfg_t s_runtime_cfg;

/* Dave2D */
#if (USE_DAVE2D == 1)
static uint32_t        s_dave_active;
static d2_device       * sp_d2_handle;
static d2_renderbuffer * sp_renderbuffer;
#endif

#if (EMWIN_BITS_PER_PIXEL < 16)
static uint32_t s_a_clut[NUM_COLORS];
#endif

static volatile bool s_first_interrupt_flag;           /* It is used for interrupt control of GLCDC module */

#if (USE_DAVE2D == 1)
static void lcd_fill_rect (int32_t layer_index, int32_t x0, int32_t y0, int32_t x1, int32_t y1, uint32_t pixel_index);
#endif

/**********************************************************************************************************************
 * Function Name: switch_buffers_on_vsync
 * Description  : .
 * Arguments    : .
 * Return Value : .
 *********************************************************************************************************************/
static void switch_buffers_on_vsync(int32_t index)
{
    uint32_t addr;
    glcdc_err_t ret;

    s_pending_buffer = 1;

    /* WAIT_LOOP */
    while (1 == s_pending_buffer)
    {
        /* Wait until s_pending_buffer is cleared by ISR */
        R_BSP_NOP();
    }
    addr = s_a_buffer_ptr[index];
    s_runtime_cfg.input.p_base = (uint32_t *)addr; /* Specify the start address of the frame buffer */
    ret = R_GLCDC_LayerChange(GLCDC_FRAME_LAYER_2, &s_runtime_cfg); /* Graphic 2 Register Value Reflection Enable */
    if (GLCDC_SUCCESS == ret)
    {
        GUI_MULTIBUF_ConfirmEx(0, index); /* Tell emWin that buffer is used */
    }
    else
    {
        /* You should not end up here. Buffer change has failed, check "ret" to get further information
         * or add code to debug the issue. */
        R_BSP_NOP();
    }
}
/**********************************************************************************************************************
 * End of function switch_buffers_on_vsync
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: init_controller
 * Description  : Should initialize the display controller.
 * Arguments    : .
 * Return Value : .
 *********************************************************************************************************************/
static void init_controller(void)
{
    glcdc_cfg_t glcdc_cfg;
    glcdc_err_t ret;

    /* Register Dave2D interrupt */
#if (USE_DAVE2D == 1)
    R_BSP_InterruptWrite(BSP_INT_SRC_AL1_DRW2D_DRW_IRQ, (bsp_int_cb_t)drw_int_isr);
#endif

#if (!defined(QE_DISPLAY_CONFIGURATION) && (GLCDC_CFG_CONFIGURATION_MODE == 0))
    /* Configuration example for RX72N envision kit. */

    /* Set the frequency of the LCD_CLK and PXCLK to suit the format and set the PANELCLK.CLKEN bit to 1 */
    glcdc_cfg.output.clksrc = GLCDC_CLK_SRC_INTERNAL;              /* Select PLL clock */
    glcdc_cfg.output.clock_div_ratio = GLCDC_PANEL_CLK_DIVISOR_24; /* 240 / 24 = 10 MHz */

    /* Definition of Background Screen */
    glcdc_cfg.output.htiming.front_porch = 5;
    glcdc_cfg.output.vtiming.front_porch = 8;
    glcdc_cfg.output.htiming.back_porch = 40;
    glcdc_cfg.output.vtiming.back_porch = 8;
    glcdc_cfg.output.htiming.display_cyc = EMWIN_XSIZE_PHYS;
    glcdc_cfg.output.vtiming.display_cyc = EMWIN_YSIZE_PHYS;
    glcdc_cfg.output.htiming.sync_width = 1;
    glcdc_cfg.output.vtiming.sync_width = 1;

    /* Graphic 1 configuration */
    glcdc_cfg.input[GLCDC_FRAME_LAYER_1].p_base = NULL;

    /* Graphic 2 configuration */
    glcdc_cfg.input[GLCDC_FRAME_LAYER_2].p_base = (uint32_t *)s_a_buffer_ptr[0];
    glcdc_cfg.input[GLCDC_FRAME_LAYER_2].offset = LINE_OFFSET;
    glcdc_cfg.input[GLCDC_FRAME_LAYER_2].format = COLOR_FORMAT;
    glcdc_cfg.blend[GLCDC_FRAME_LAYER_2].visible = true;
    glcdc_cfg.blend[GLCDC_FRAME_LAYER_2].blend_control = GLCDC_BLEND_CONTROL_NONE;
    glcdc_cfg.blend[GLCDC_FRAME_LAYER_2].frame_edge = false;
    glcdc_cfg.input[GLCDC_FRAME_LAYER_2].frame_edge = false;
    glcdc_cfg.input[GLCDC_FRAME_LAYER_2].coordinate.y = 0;
    glcdc_cfg.input[GLCDC_FRAME_LAYER_2].vsize = EMWIN_YSIZE_PHYS;
    glcdc_cfg.input[GLCDC_FRAME_LAYER_2].coordinate.x = 0;
    glcdc_cfg.input[GLCDC_FRAME_LAYER_2].hsize = EMWIN_XSIZE_PHYS;
    glcdc_cfg.blend[GLCDC_FRAME_LAYER_2].start_coordinate.x = 0;
    glcdc_cfg.blend[GLCDC_FRAME_LAYER_2].end_coordinate.x= EMWIN_YSIZE_PHYS;
    glcdc_cfg.blend[GLCDC_FRAME_LAYER_2].start_coordinate.y = 0;
    glcdc_cfg.blend[GLCDC_FRAME_LAYER_2].end_coordinate.y= EMWIN_XSIZE_PHYS;

    /* Timing configuration */
    glcdc_cfg.output.tcon_vsync = GLCDC_TCON_PIN_0;
    glcdc_cfg.output.tcon_hsync = GLCDC_TCON_PIN_2;
    glcdc_cfg.output.tcon_de    = GLCDC_TCON_PIN_3;
    glcdc_cfg.output.data_enable_polarity = GLCDC_SIGNAL_POLARITY_HIACTIVE;
    glcdc_cfg.output.hsync_polarity = GLCDC_SIGNAL_POLARITY_LOACTIVE;
    glcdc_cfg.output.vsync_polarity = GLCDC_SIGNAL_POLARITY_LOACTIVE;
    glcdc_cfg.output.sync_edge = GLCDC_SIGNAL_SYNC_EDGE_RISING;

    /* Output interface */
    glcdc_cfg.output.format = GLCDC_OUT_FORMAT_16BITS_RGB565;
    glcdc_cfg.output.color_order = GLCDC_COLOR_ORDER_RGB;
    glcdc_cfg.output.endian = GLCDC_ENDIAN_LITTLE;

    /* Brightness Adjustment */
    glcdc_cfg.output.brightness.b = 0x200;
    glcdc_cfg.output.brightness.g = 0x200;
    glcdc_cfg.output.brightness.r = 0x200;

    /* Contrast Adjustment Value */
    glcdc_cfg.output.contrast.b = 0x80;
    glcdc_cfg.output.contrast.g = 0x80;
    glcdc_cfg.output.contrast.r = 0x80;

    /* Disable Gamma */
    glcdc_cfg.output.gamma.enable = false;

    /* Disable Chromakey */
    glcdc_cfg.chromakey[GLCDC_FRAME_LAYER_2].enable = false;

    /* Disable Dithering */
    glcdc_cfg.output.dithering.dithering_on = false;

    /* CLUT Adjustment Value */
    glcdc_cfg.clut[GLCDC_FRAME_LAYER_2].enable = false;

    /* Enable VPOS ISR */
    glcdc_cfg.detection.vpos_detect = true;
    glcdc_cfg.interrupt.vpos_enable = true;
    glcdc_cfg.detection.gr1uf_detect = false;
    glcdc_cfg.detection.gr2uf_detect = false;
    glcdc_cfg.interrupt.gr1uf_enable = false;
    glcdc_cfg.interrupt.gr2uf_enable = false;

    /* Set function to be called on VSYNC */
    glcdc_cfg.p_callback = (void (*)(void *))_VSYNC_ISR;

#endif /* ((QE_DISPLAY_CONFIGURATION) && (GLCDC_CFG_CONFIGURATION_MODE == 0)) */

    /* Initialize a first time interrupt flag
     *   Unintended specified line notification from graphic 2 and graphic 1, 2 underflow is detected only
     *   for first time after release GLCDC software reset.
     *   This variable is a flag to skip the first time interrupt processing.
     *   Refer to Graphic LCD Controller (GLCDC) section of User's Manual: Hardware for details. */
    s_first_interrupt_flag = false;

    /* R_GLCDC_Open function release stop state of GLCDC. */
    ret = R_GLCDC_Open(&glcdc_cfg);
    if (GLCDC_SUCCESS != ret)
    {
        /* WAIT_LOOP */
        while (1)
        {
            R_BSP_NOP(); /* Error */
        }
    }

    s_runtime_cfg.blend = glcdc_cfg.blend[GLCDC_FRAME_LAYER_2];
    s_runtime_cfg.input = glcdc_cfg.input[GLCDC_FRAME_LAYER_2];
    s_runtime_cfg.chromakey = glcdc_cfg.chromakey[GLCDC_FRAME_LAYER_2];

    /* Function select of multiplex pins (Display B) */
    R_GLCDC_PinSet();

#if (EMWIN_USE_DISP_SIGNAL_PIN == 1)
    /* Set DISP signal on */
    R_GPIO_PinDirectionSet(EMWIN_DISP_SIGNAL_PIN, GPIO_DIRECTION_OUTPUT); /* Port direction: output */
    R_GPIO_PinWrite(EMWIN_DISP_SIGNAL_PIN, GPIO_LEVEL_HIGH); /* DISP on */
#endif

#if (EMWIN_USE_BACKLIGHT_PIN == 1)
    /* Switch backlight on, no PWM */
    R_GPIO_PinDirectionSet(EMWIN_BACKLIGHT_PIN, GPIO_DIRECTION_OUTPUT);
    R_GPIO_PinWrite(EMWIN_BACKLIGHT_PIN, GPIO_LEVEL_HIGH);
#endif

    /* Init DMA */
    R_DMACA_Init();

    /* Extended Bus Master Priority Control Register */
    BSC.EBMAPCR.BIT.PR1SEL = 3;
    BSC.EBMAPCR.BIT.PR2SEL = 1;
    BSC.EBMAPCR.BIT.PR3SEL = 2;
    BSC.EBMAPCR.BIT.PR4SEL = 0;
    BSC.EBMAPCR.BIT.PR5SEL = 4;
}
/**********************************************************************************************************************
 * End of function init_controller
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: set_lut_entry
 * Description  : Should set the desired LUT entry.
 * Arguments    : .
 * Return Value : .
 *********************************************************************************************************************/
static void set_lut_entry(LCD_COLOR color, uint8_t pos)
{
#if (EMWIN_BITS_PER_PIXEL < 16)
    glcdc_clut_cfg_t p_clut_cfg;
    glcdc_err_t      ret;

    s_a_clut[pos] = color;
    if (pos == (NUM_COLORS - 1))
    {
        p_clut_cfg.enable = true;
        p_clut_cfg.p_base = s_a_clut;
        p_clut_cfg.size = NUM_COLORS;
        p_clut_cfg.start = 0;
#ifdef __ICCRX__
        R_GLCDC_Control(GLCDC_CMD_START_DISPLAY, (void const * const)FIT_NO_FUNC); /* Enable background generation block */
#else
        R_GLCDC_Control(GLCDC_CMD_START_DISPLAY, FIT_NO_FUNC); /* Enable background generation block */
#endif
        GUI_Delay(100);
        ret = R_GLCDC_ClutUpdate(GLCDC_FRAME_LAYER_2, &p_clut_cfg);
        if (GLCDC_SUCCESS != ret)
        {
            /* WAIT_LOOP */
            while (1)
            {
                R_BSP_NOP(); /* Error */
            }
        }
    }
#else
    GUI_USE_PARA(color);
    GUI_USE_PARA(pos);
#endif
}
/**********************************************************************************************************************
 * End of function set_lut_entry
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: display_on_off
 * Description  : .
 * Arguments    : .
 * Return Value : .
 *********************************************************************************************************************/
static void display_on_off(int32_t on_off)
{
    if (on_off)
    {
#ifdef __ICCRX__
        R_GLCDC_Control(GLCDC_CMD_START_DISPLAY, (void const * const)FIT_NO_FUNC); /* Enable background generation block */
#else
        R_GLCDC_Control(GLCDC_CMD_START_DISPLAY, FIT_NO_FUNC); /* Enable background generation block */
#endif

#if (EMWIN_USE_BACKLIGHT_PIN == 1)
        R_GPIO_PinWrite(EMWIN_BACKLIGHT_PIN, GPIO_LEVEL_HIGH);
#endif
    }
    else
    {
#ifdef __ICCRX__
        R_GLCDC_Control(GLCDC_CMD_STOP_DISPLAY, (void const * const)FIT_NO_FUNC); /* Disable background generation block */
#else
        R_GLCDC_Control(GLCDC_CMD_STOP_DISPLAY, FIT_NO_FUNC); /* Disable background generation block */
#endif

#if (EMWIN_USE_BACKLIGHT_PIN == 1)
        R_GPIO_PinWrite(EMWIN_BACKLIGHT_PIN, GPIO_LEVEL_LOW);
#endif
    }
}
/**********************************************************************************************************************
 * End of function display_on_off
 *********************************************************************************************************************/

#if (USE_DAVE2D == 1)
/**********************************************************************************************************************
 * Function Name: get_d2_mode
 * Description  : .
 * Arguments    : .
 * Return Value : .
 *********************************************************************************************************************/
static uint32_t get_d2_mode(void)
{
    uint32_t r;
#if   (EMWIN_BITS_PER_PIXEL == 32)
    r = d2_mode_argb8888;
#elif (EMWIN_BITS_PER_PIXEL == 16)
    r = d2_mode_rgb565;
#elif (EMWIN_BITS_PER_PIXEL == 8)
    r = d2_mode_i8;
#elif (EMWIN_BITS_PER_PIXEL == 4)
    r = d2_mode_i4;
#elif (EMWIN_BITS_PER_PIXEL == 1)
    r = d2_mode_i1;
#endif
    return r;
}
/**********************************************************************************************************************
 * End of function get_d2_mode
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: modify_coord
 * Description  : .
 * Arguments    : .
 * Return Value : .
 *********************************************************************************************************************/
static void modify_coord(int32_t * p_x, int32_t * p_y)
{
#if (EMWIN_DISPLAY_ORIENTATION == ORIENTATION_CW)
    int32_t x_temp;

    x_temp = *p_x;
    *p_x   = EMWIN_XSIZE_PHYS - 1 - *p_y;
    *p_y   = x_temp;
#elif (EMWIN_DISPLAY_ORIENTATION == ORIENTATION_180)
    *p_x   = EMWIN_XSIZE_PHYS - 1 - *p_x;
    *p_y   = EMWIN_YSIZE_PHYS - 1 - *p_y;
#elif (EMWIN_DISPLAY_ORIENTATION == ORIENTATION_CCW)
    int32_t y_temp;

    y_temp = *p_y;
    *p_y   = EMWIN_YSIZE_PHYS - 1 - *p_x;
    *p_x   = y_temp;
#else
    R_BSP_NOP();
#endif
}
/**********************************************************************************************************************
 * End of function modify_coord
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: modify_rect
 * Description  : .
 * Arguments    : .
 * Return Value : .
 *********************************************************************************************************************/
static void modify_rect(const GUI_RECT * p_rect_org, GUI_RECT * p_rect)
{
#if (EMWIN_DISPLAY_ORIENTATION == ORIENTATION_CW)
    int32_t temp;
    p_rect->x0 = EMWIN_XSIZE_PHYS - 1 - p_rect_org->y0;
    p_rect->y0 = p_rect_org->x0;
    p_rect->x1 = EMWIN_XSIZE_PHYS - 1 - p_rect_org->y1;
    p_rect->y1 = p_rect_org->x1;
    if (p_rect->x0 > p_rect->x1)
    {
        temp = p_rect->x0;
        p_rect->x0 = p_rect->x1;
        p_rect->x1 = temp;
    }
#elif (EMWIN_DISPLAY_ORIENTATION == ORIENTATION_180)
    int32_t temp;
    p_rect->x0 = EMWIN_XSIZE_PHYS - 1 - p_rect_org->x0;
    p_rect->y0 = EMWIN_YSIZE_PHYS - 1 - p_rect_org->y0;
    p_rect->x1 = EMWIN_XSIZE_PHYS - 1 - p_rect_org->x1;
    p_rect->y1 = EMWIN_YSIZE_PHYS - 1 - p_rect_org->y1;
    if (p_rect->x0 > p_rect->x1)
    {
        temp = p_rect->x0;
        p_rect->x0 = p_rect->x1;
        p_rect->x1 = temp;
    }
    if (p_rect->y0 > p_rect->y1)
    {
        temp = p_rect->y0;
        p_rect->y0 = p_rect->y1;
        p_rect->y1 = temp;
    }
#elif (EMWIN_DISPLAY_ORIENTATION == ORIENTATION_CCW)
    int32_t temp;
    p_rect->x0 = p_rect_org->y0;
    p_rect->y0 = EMWIN_YSIZE_PHYS - 1 - p_rect_org->x0;
    p_rect->x1 = p_rect_org->y1;
    p_rect->y1 = EMWIN_YSIZE_PHYS - 1 - p_rect_org->x1;
    if (p_rect->y0 > p_rect->y1)
    {
        temp = p_rect->y0;
        p_rect->y0 = p_rect->y1;
        p_rect->y1 = temp;
    }
#else
    *p_rect = *p_rect_org;
#endif /* EMWIN_DISPLAY_ORIENTATION == ORIENTATION_CW */
}
/**********************************************************************************************************************
 * End of function modify_rect
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: lcd_fill_rect_xor
 * Description  : .
 * Arguments    : .
 * Return Value : .
 *********************************************************************************************************************/
static void lcd_fill_rect_xor(int32_t layer_index, int32_t x0, int32_t y0, int32_t x1, int32_t y1)
{
#if (EMWIN_DISPLAY_ORIENTATION != ORIENTATION_0)
    int32_t temp;
#endif
    LCD_SetDevFunc(layer_index, LCD_DEVFUNC_FILLRECT, NULL);

    /* The following is required because emWin already mirrors/swaps the coordinates.
     * Since we call the default function we have to revert the mirroring/swapping. */
#if (EMWIN_DISPLAY_ORIENTATION == ORIENTATION_0)
    LCD_FillRect(x0, y0, x1, y1);
#elif (EMWIN_DISPLAY_ORIENTATION == ORIENTATION_CW)
    temp = x0;
    x0 = EMWIN_XSIZE_PHYS - 1 - x1;
    x1 = EMWIN_XSIZE_PHYS - 1 - temp;
    temp = y0;
    y0 = x0;
    x0 = temp;
    temp = y1;
    y1 = x1;
    x1 = temp;
    LCD_FillRect(x0, y0, x1, y1);
#elif (EMWIN_DISPLAY_ORIENTATION == ORIENTATION_180)
    x0 = EMWIN_XSIZE_PHYS - 1 - x0;
    x1 = EMWIN_XSIZE_PHYS - 1 - x1;
    y0 = EMWIN_YSIZE_PHYS - 1 - y0;
    y1 = EMWIN_YSIZE_PHYS - 1 - y1;
    if (x0 > x1)
    {
        temp = x0;
        x0 = x1;
        x1 = temp;
    }
    if (y0 > y1)
    {
        temp = y0;
        y0 = y1;
        y1 = temp;
    }
    LCD_FillRect(x0, y0, x1, y1);
#else
    temp = y1;
    y1   = (EMWIN_YSIZE_PHYS - 1 - y0);
    y0   = (EMWIN_YSIZE_PHYS - 1 - temp);
    LCD_FillRect(y0, x0, y1, x1);
#endif /* EMWIN_DISPLAY_ORIENTATION == ORIENTATION_0 */
    LCD_SetDevFunc(layer_index, LCD_DEVFUNC_FILLRECT, (void(*)(void))lcd_fill_rect);
}
/**********************************************************************************************************************
 * End of function lcd_fill_rect_xor
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: lcd_fill_rect
 * Description  : .
 * Arguments    : .
 * Return Value : .
 *********************************************************************************************************************/
static void lcd_fill_rect(int32_t layer_index, int32_t x0, int32_t y0, int32_t x1, int32_t y1, uint32_t pixel_index)
{
    uint32_t mode;
    d2_color color;
    GUI_RECT rect;
    int32_t  x_size;
    int32_t  y_size;
    uint8_t  alpha;
    GUI_DRAWMODE draw_mode;

    draw_mode = GUI_GetDrawMode();
    if (GUI_DM_XOR == draw_mode)
    {
        lcd_fill_rect_xor(layer_index, x0, y0, x1, y1);
    }
    else
    {
        GUI_USE_PARA(layer_index);
        mode = get_d2_mode();

        /* Generate render operations */
        d2_framebuffer(sp_d2_handle, (void *)s_a_buffer_ptr[s_write_buffer_index], EMWIN_XSIZE_PHYS, EMWIN_XSIZE_PHYS, EMWIN_YSIZE_PHYS, mode);
        d2_selectrenderbuffer(sp_d2_handle, sp_renderbuffer);
        color = GUI_Index2Color(pixel_index);
        d2_setcolor(sp_d2_handle, 0, color);
        alpha = GUI_GetAlpha();
        d2_setalpha(sp_d2_handle, alpha);
        modify_rect(GUI_GetClipRect(), &rect);
        d2_cliprect(sp_d2_handle, rect.x0, rect.y0, rect.x1, rect.y1);
        x_size = (x1 - x0) + 1;
        y_size = (y1 - y0) + 1;
        d2_renderbox(sp_d2_handle, x0 * 16, y0 * 16, x_size * 16, y_size * 16);

        /* Execute render operations */
        d2_executerenderbuffer(sp_d2_handle, sp_renderbuffer, 0);
        d2_flushframe(sp_d2_handle);
        alpha = 0xFF;
        d2_setalpha(sp_d2_handle, alpha);
    }
}
/**********************************************************************************************************************
 * End of function lcd_fill_rect
 *********************************************************************************************************************/

#if (EMWIN_DISPLAY_ORIENTATION == ORIENTATION_0)
/**********************************************************************************************************************
 * Function Name: draw_memdev_alpha
 * Description  : .
 * Arguments    : .
 * Return Value : .
 *********************************************************************************************************************/
static void draw_memdev_alpha(void * p_dst, const void * p_src, int32_t x_size, int32_t y_size, int32_t bytes_per_line_dst, int32_t bytes_per_line_src)
{
    uint32_t pitch_src;
    uint32_t pitch_dst;
    uint32_t mode;

    pitch_dst = bytes_per_line_dst / 4;
    pitch_src = bytes_per_line_src / 4;
    mode = get_d2_mode();

    /* Set address of destination memory device as frame buffer to be used */
    d2_framebuffer(sp_d2_handle, p_dst, pitch_dst, pitch_dst, y_size, d2_mode_argb8888);

    /* Generate render operations */
    d2_selectrenderbuffer(sp_d2_handle, sp_renderbuffer);
    d2_setblitsrc(sp_d2_handle, (void *)p_src, pitch_src, x_size, y_size, d2_mode_argb8888);
    d2_blitcopy(sp_d2_handle, x_size, y_size, 0, 0, x_size * 16, y_size * 16, 0, 0, d2_bf_usealpha);

    /* Execute render operations */
    d2_executerenderbuffer(sp_d2_handle, sp_renderbuffer, 0);
    d2_flushframe(sp_d2_handle);

    /* Restore frame buffer */
    d2_framebuffer(sp_d2_handle, (void *)s_a_buffer_ptr[s_write_buffer_index], EMWIN_XSIZE_PHYS, EMWIN_XSIZE_PHYS, EMWIN_YSIZE_PHYS, mode);
}
/**********************************************************************************************************************
 * End of function draw_memdev_alpha
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: draw_bitmap_alpha
 * Description  : .
 * Arguments    : .
 * Return Value : .
 *********************************************************************************************************************/
static void draw_bitmap_alpha(int32_t layer_index, int32_t x, int32_t y, const void * p, int32_t x_size, int32_t y_size, int32_t bytes_per_line)
{
    uint32_t pitch;
    uint32_t mode;

    pitch = bytes_per_line / 4;
    mode = get_d2_mode();

    /* Generate render operations */
    d2_framebuffer(sp_d2_handle, (void *)s_a_buffer_ptr[s_write_buffer_index], EMWIN_XSIZE_PHYS, EMWIN_XSIZE_PHYS, EMWIN_YSIZE_PHYS, mode);
    d2_selectrenderbuffer(sp_d2_handle, sp_renderbuffer);
    d2_setblitsrc(sp_d2_handle, (void *)p, pitch, x_size, y_size, d2_mode_argb8888);
    d2_blitcopy(sp_d2_handle, x_size, y_size, 0, 0, x_size * 16, y_size * 16, x * 16, y * 16, d2_bf_usealpha);

    /* Execute render operations */
    d2_executerenderbuffer(sp_d2_handle, sp_renderbuffer, 0);
    d2_flushframe(sp_d2_handle);
}
/**********************************************************************************************************************
 * End of function draw_bitmap_alpha
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: draw_bitmap_16bpp
 * Description  : .
 * Arguments    : .
 * Return Value : .
 *********************************************************************************************************************/
static void draw_bitmap_16bpp(int32_t layer_index, int32_t x, int32_t y, const void * p, int32_t x_size, int32_t y_size, int32_t bytes_per_line)
{
    uint32_t mode;
    uint32_t mode_src;

    GUI_USE_PARA(layer_index);
    GUI_USE_PARA(bytes_per_line);
    mode     = get_d2_mode();
    mode_src = d2_mode_rgb565;

    /* Generate render operations */
    d2_framebuffer(sp_d2_handle, (void *)s_a_buffer_ptr[s_write_buffer_index], EMWIN_XSIZE_PHYS, EMWIN_XSIZE_PHYS, EMWIN_YSIZE_PHYS, mode);
    d2_selectrenderbuffer(sp_d2_handle, sp_renderbuffer);
    d2_setblitsrc(sp_d2_handle, (void *)p, bytes_per_line / 2, x_size, y_size, mode_src);
    d2_blitcopy(sp_d2_handle, x_size, y_size, 0, 0, x_size * 16, y_size * 16, x * 16, y * 16, 0);

    /* Execute render operations */
    d2_executerenderbuffer(sp_d2_handle, sp_renderbuffer, 0);
    d2_flushframe(sp_d2_handle);
}
/**********************************************************************************************************************
 * End of function draw_bitmap_16bpp
 *********************************************************************************************************************/
#endif /* EMWIN_DISPLAY_ORIENTATION == ORIENTATION_0 */

/**********************************************************************************************************************
 * Function Name: circle_aa
 * Description  : .
 * Arguments    : .
 * Return Value : .
 *********************************************************************************************************************/
static int32_t circle_aa(int32_t x0, int32_t y0, int32_t r, int32_t w)
{
    uint32_t mode;
    int32_t  ret;
    GUI_RECT rect;
    uint32_t color;

    mode = get_d2_mode();

    /* Generate render operations */
    d2_framebuffer(sp_d2_handle, (void *)s_a_buffer_ptr[s_write_buffer_index], EMWIN_XSIZE_PHYS, EMWIN_XSIZE_PHYS, EMWIN_YSIZE_PHYS, mode);
    d2_selectrenderbuffer(sp_d2_handle, sp_renderbuffer);
    color = GUI_Index2Color(GUI_GetColorIndex());
    d2_setcolor(sp_d2_handle, 0, color);
    modify_rect(GUI__GetClipRect(), &rect);
    d2_cliprect(sp_d2_handle, rect.x0, rect.y0, rect.x1, rect.y1);
    ret = d2_rendercircle(sp_d2_handle, x0 * 16, y0 * 16, r * 16, w * 16);

    /* Execute render operations */
    d2_executerenderbuffer(sp_d2_handle, sp_renderbuffer, 0);
    d2_flushframe(sp_d2_handle);

    return ret;
}
/**********************************************************************************************************************
 * End of function circle_aa
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: fill_circle_aa
 * Description  : .
 * Arguments    : .
 * Return Value : .
 *********************************************************************************************************************/
static int32_t fill_circle_aa(int32_t x0, int32_t y0, int32_t r)
{
    modify_coord(&x0, &y0);
    return (circle_aa(x0, y0, r, 0));
}
/**********************************************************************************************************************
 * End of function fill_circle_aa
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: draw_circle_aa
 * Description  : .
 * Arguments    : .
 * Return Value : .
 *********************************************************************************************************************/
static int32_t draw_circle_aa(int32_t x0, int32_t y0, int32_t r)
{
    modify_coord(&x0, &y0);
    return (circle_aa(x0, y0, r, GUI_GetPenSize()));
}
/**********************************************************************************************************************
 * End of function draw_circle_aa
 *********************************************************************************************************************/

#if (EMWIN_DISPLAY_ORIENTATION == ORIENTATION_0)
/**********************************************************************************************************************
 * Function Name: fill_polygon_aa
 * Description  : .
 * Arguments    : .
 * Return Value : .
 *********************************************************************************************************************/
static int32_t fill_polygon_aa(const GUI_POINT * p_points, int32_t num_points, int32_t x0, int32_t y0)
{
    uint32_t mode;
    d2_point * p_data;
    d2_point * p_data_i;
    int32_t  i;
    int32_t  ret;
    GUI_RECT rect;
    uint32_t color;

    mode = get_d2_mode();
    p_data = malloc(sizeof(d2_point) * num_points * 2);
    ret = 1;
    modify_coord(&x0, &y0);
    if (p_data)
    {
        p_data_i = p_data;

        /* WAIT_LOOP */
        for (i = 0; i < num_points; i++ )
        {
            modify_coord((int32_t *)&p_points->x, (int32_t *)&p_points->y);
            *p_data_i++ = (d2_point)(p_points->x + x0) * 16;
            *p_data_i++ = (d2_point)(p_points->y + y0) * 16;
            p_points++;
        }

        /* Generate render operations */
        d2_framebuffer(sp_d2_handle, (void *)s_a_buffer_ptr[s_write_buffer_index],
                        EMWIN_XSIZE_PHYS, EMWIN_XSIZE_PHYS, EMWIN_YSIZE_PHYS, mode);
        d2_selectrenderbuffer(sp_d2_handle, sp_renderbuffer);
        color = GUI_Index2Color(GUI_GetColorIndex());
        d2_setcolor(sp_d2_handle, 0, color);
        modify_rect(GUI__GetClipRect(), &rect);
        d2_cliprect(sp_d2_handle, rect.x0, rect.y0, rect.x1, rect.y1);
        ret = d2_renderpolygon(sp_d2_handle, p_data, num_points, d2_le_closed);

        /* Execute render operations */
        d2_executerenderbuffer(sp_d2_handle, sp_renderbuffer, 0);
        d2_flushframe(sp_d2_handle);
        free(p_data);
    }

    return ret;
}
/**********************************************************************************************************************
 * End of function fill_polygon_aa
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: draw_poly_outline_aa
 * Description  : .
 * Arguments    : .
 * Return Value : .
 *********************************************************************************************************************/
static int32_t draw_poly_outline_aa(const GUI_POINT * p_points, int32_t num_points, int32_t Thickness,
                                    int32_t x, int32_t y)
{
    uint32_t mode;
    d2_point * p_data;
    d2_point * p_data_i;
    int32_t  i;
    int32_t  ret;
    GUI_RECT rect;
    uint32_t color;

    mode = get_d2_mode();
    p_data = malloc(sizeof(d2_point) * num_points * 2);
    ret = 1;
    modify_coord(&x, &y);
    if (p_data)
    {
        p_data_i = p_data;

        /* WAIT_LOOP */
        for (i = 0; i < num_points; i++ )
        {
            modify_coord((int32_t *)&p_points->x, (int32_t *)&p_points->y);
            *p_data_i++ = (d2_point)(p_points->x + x) * 16;
            *p_data_i++ = (d2_point)(p_points->y + y) * 16;
            p_points++;
        }

        /* Generate render operations */
        d2_framebuffer(sp_d2_handle, (void *)s_a_buffer_ptr[s_write_buffer_index],
                        EMWIN_XSIZE_PHYS, EMWIN_XSIZE_PHYS, EMWIN_YSIZE_PHYS, mode);
        d2_selectrenderbuffer(sp_d2_handle, sp_renderbuffer);
        color = GUI_Index2Color(GUI_GetColorIndex());
        d2_setcolor(sp_d2_handle, 0, color);
        modify_rect(GUI__GetClipRect(), &rect);
        d2_cliprect(sp_d2_handle, rect.x0, rect.y0, rect.x1, rect.y1);
        d2_selectrendermode(sp_d2_handle, d2_rm_outline);
        ret = d2_renderpolyline(sp_d2_handle, p_data, num_points, Thickness * 16, d2_le_closed);
        d2_selectrendermode(sp_d2_handle, d2_rm_solid);

        /* Execute render operations */
        d2_executerenderbuffer(sp_d2_handle, sp_renderbuffer, 0);
        d2_flushframe(sp_d2_handle);
        free(p_data);
    }

    return ret;
}
/**********************************************************************************************************************
 * End of function draw_poly_outline_aa
 *********************************************************************************************************************/
#endif /* EMWIN_DISPLAY_ORIENTATION == ORIENTATION_0 */

/**********************************************************************************************************************
 * Function Name: draw_line_aa
 * Description  : .
 * Arguments    : .
 * Return Value : .
 *********************************************************************************************************************/
static int32_t draw_line_aa(int32_t x0, int32_t y0, int32_t x1, int32_t y1)
{
    uint32_t mode;
    int32_t  ret;
    uint32_t color;
    GUI_RECT rect;

    mode = get_d2_mode();
    modify_coord(&x0, &y0);
    modify_coord(&x1, &y1);

    /* Generate render operations */
    d2_framebuffer(sp_d2_handle, (void *)s_a_buffer_ptr[s_write_buffer_index],
                    EMWIN_XSIZE_PHYS, EMWIN_XSIZE_PHYS, EMWIN_YSIZE_PHYS, mode);
    d2_selectrenderbuffer(sp_d2_handle, sp_renderbuffer);
    color = GUI_Index2Color(GUI_GetColorIndex());
    d2_setcolor(sp_d2_handle, 0, color);
    modify_rect(GUI__GetClipRect(), &rect);
    d2_cliprect(sp_d2_handle, rect.x0, rect.y0, rect.x1, rect.y1);
    ret = d2_renderline(sp_d2_handle, x0 * 16, y0 * 16, x1 * 16, y1 * 16, GUI_GetPenSize() * 16, d2_le_exclude_none);

    /* Execute render operations */
    d2_executerenderbuffer(sp_d2_handle, sp_renderbuffer, 0);
    d2_flushframe(sp_d2_handle);

    return ret;
}
/**********************************************************************************************************************
 * End of function draw_line_aa
 *********************************************************************************************************************/

#if (EMWIN_DISPLAY_ORIENTATION == ORIENTATION_0)
/**********************************************************************************************************************
 * Function Name: draw_arc_aa
 * Description  : .
 * Arguments    : .
 * Return Value : .
 *********************************************************************************************************************/
static int32_t draw_arc_aa(int32_t x0, int32_t y0, int32_t rx, int32_t ry, int32_t a0, int32_t a1)
{
    uint32_t mode;
    int32_t  ret;
    int32_t  nx0;
    int32_t  ny0;
    int32_t  nx1;
    int32_t  ny1;
    GUI_RECT rect;
    uint32_t color;
    uint32_t flag;

    GUI_USE_PARA(ry);

    /* If both angles are equal (e.g. 0 and 0 or 180 and 180) nothing has to be done */
    if (a0 == a1)
    {
        return 0; /* Nothing to do, no angle - no arc */
    }
    if (a1 < a0)
    {
        return 0; /* Nothing to do, emWin doesn't support this one */
    }

    /* If the angles not equal, but meet at the same position
     * we don't draw an arc but a circle instead. */
    if (a1 > (a0 + 360000))
    {
        ret = draw_circle_aa(x0, y0, rx); /* a1 meets a0 after one round so we have a circle */

        return ret;
    }
    if ((a0 % 360000) == (a1 % 360000))
    {
        ret = draw_circle_aa(x0, y0, rx); /* Both angles are at the same position but not equal, so we have a circle */

        return ret;
    }

    mode = get_d2_mode();
    modify_coord(&x0, &y0);
    nx0  = -GUI__SinHQ(a0);
    ny0  = -GUI__CosHQ(a0);
    nx1  = GUI__SinHQ(a1);
    ny1  = GUI__CosHQ(a1);

    /* If the difference between both is larger than 180 degrees we must use the concave flag */
    if (((a1 - a0) % 360000) <= 180000)
    {
        flag = 0;
    }
    else
    {
        flag = d2_wf_concave;
    }

    /* Generate render operations */
    d2_framebuffer(sp_d2_handle, (void *)s_a_buffer_ptr[s_write_buffer_index],
                    EMWIN_XSIZE_PHYS, EMWIN_XSIZE_PHYS, EMWIN_YSIZE_PHYS, mode);
    d2_selectrenderbuffer(sp_d2_handle, sp_renderbuffer);
    color = GUI_Index2Color(GUI_GetColorIndex());
    d2_setcolor(sp_d2_handle, 0, color);
    modify_rect(GUI__GetClipRect(), &rect);
    d2_cliprect(sp_d2_handle, rect.x0, rect.y0, rect.x1, rect.y1);
    ret = d2_renderwedge(sp_d2_handle, x0 * 16, y0 * 16, rx * 16, GUI_GetPenSize() * 16, nx0, ny0, nx1, ny1, flag);

    /* Execute render operations */
    d2_executerenderbuffer(sp_d2_handle, sp_renderbuffer, 0);
    d2_flushframe(sp_d2_handle);

    return ret;
}
/**********************************************************************************************************************
 * End of function draw_arc_aa
 *********************************************************************************************************************/
#endif /* EMWIN_DISPLAY_ORIENTATION == ORIENTATION_0 */
#endif /* USE_DAVE2D == 1 */

/**********************************************************************************************************************
 * Function Name: copy_buffer
 * Description  : .
 * Arguments    : .
 * Return Value : .
 *********************************************************************************************************************/
static void copy_buffer(int32_t layer_index, int32_t index_src, int32_t index_dst)
{
    dmaca_return_t            ret;
    dmaca_transfer_data_cfg_t td_cfg;
    dmaca_stat_t              dmac_status;

    GUI_USE_PARA(layer_index);
    ret = R_DMACA_Open(DMACA_CH0);
    if (DMACA_SUCCESS != ret)
    {
        /* WAIT_LOOP */
        while (1)
        {
            R_BSP_NOP(); /* Error */
        }
    }

    td_cfg.transfer_mode        = DMACA_TRANSFER_MODE_BLOCK;
    td_cfg.repeat_block_side    = DMACA_REPEAT_BLOCK_DISABLE;
    td_cfg.data_size            = DMACA_DATA_SIZE_LWORD;
    td_cfg.act_source           = (dmaca_activation_source_t)0;
    td_cfg.request_source       = DMACA_TRANSFER_REQUEST_SOFTWARE;
    td_cfg.dtie_request         = DMACA_TRANSFER_END_INTERRUPT_DISABLE;
    td_cfg.esie_request         = DMACA_TRANSFER_ESCAPE_END_INTERRUPT_DISABLE;
    td_cfg.rptie_request        = DMACA_REPEAT_SIZE_END_INTERRUPT_DISABLE;
    td_cfg.sarie_request        = DMACA_SRC_ADDR_EXT_REP_AREA_OVER_INTERRUPT_DISABLE;
    td_cfg.darie_request        = DMACA_DES_ADDR_EXT_REP_AREA_OVER_INTERRUPT_DISABLE;
    td_cfg.src_addr_mode        = DMACA_SRC_ADDR_INCR;
    td_cfg.src_addr_repeat_area = DMACA_SRC_ADDR_EXT_REP_AREA_NONE;
    td_cfg.des_addr_mode        = DMACA_DES_ADDR_INCR;
    td_cfg.des_addr_repeat_area = DMACA_DES_ADDR_EXT_REP_AREA_NONE;
    td_cfg.offset_value         = LINE_OFFSET;
    td_cfg.interrupt_sel        = DMACA_CLEAR_INTERRUPT_FLAG_BEGINNING_TRANSFER;
    td_cfg.p_src_addr           = (void *)s_a_buffer_ptr[index_src];
    td_cfg.p_des_addr           = (void *)s_a_buffer_ptr[index_dst];
    td_cfg.transfer_count       = EMWIN_YSIZE_PHYS;
    td_cfg.block_size           = LINE_OFFSET >> 2;
    ret = R_DMACA_Create(DMACA_CH0, &td_cfg);
    if (DMACA_SUCCESS != ret)
    {
        /* WAIT_LOOP */
        while (1)
        {
            R_BSP_NOP(); /* Error */
        }
    }

    ret = R_DMACA_Control(DMACA_CH0, DMACA_CMD_ENABLE, &dmac_status);
    if (DMACA_SUCCESS != ret)
    {
        /* WAIT_LOOP */
        while (1)
        {
            R_BSP_NOP(); /* Error */
        }
    }

    ret = R_DMACA_Control(DMACA_CH0, DMACA_CMD_SOFT_REQ_NOT_CLR_REQ, &dmac_status);
    if (DMACA_SUCCESS != ret)
    {
        /* WAIT_LOOP */
        while (1)
        {
            R_BSP_NOP(); /* Error */
        }
    }

    do
    {
        ret = R_DMACA_Control(DMACA_CH0, DMACA_CMD_STATUS_GET, &dmac_status);
        if (DMACA_SUCCESS != ret)
        {
            /* WAIT_LOOP */
            while (1)
            {
                R_BSP_NOP(); /* Error */
            }
        }
    } while (0 == (dmac_status.dtif_stat)); /* WAIT_LOOP */

    ret = R_DMACA_Close(DMACA_CH0);
    if (DMACA_SUCCESS != ret)
    {
        /* WAIT_LOOP */
        while (1)
        {
            R_BSP_NOP(); /* Error */
        }
    }
    s_write_buffer_index = index_dst;
}
/**********************************************************************************************************************
 * End of function copy_buffer
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: R_EMWIN_GetBufferAddr
 * Description  : .
 * Arguments    : .
 * Return Value : .
 *********************************************************************************************************************/
void * R_EMWIN_GetBufferAddr(void)
{
    return (void *)s_a_buffer_ptr[s_write_buffer_index];
}
/**********************************************************************************************************************
 * End of function R_EMWIN_GetBufferAddr
 *********************************************************************************************************************/

#if (USE_DAVE2D == 1)
/**********************************************************************************************************************
 * Function Name: R_EMWIN_GetD2
 * Description  : .
 * Arguments    : .
 * Return Value : .
 *********************************************************************************************************************/
d2_device * R_EMWIN_GetD2(void)
{
    return sp_d2_handle;
}
/**********************************************************************************************************************
 * End of function R_EMWIN_GetD2
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: R_EMWIN_EnableDave2D
 * Description  : .
 * Arguments    : .
 * Return Value : .
 *********************************************************************************************************************/
void R_EMWIN_EnableDave2D(void)
{
#if (ORIENTATION_0 == EMWIN_DISPLAY_ORIENTATION)
    GUI_SetFuncDrawAlpha         ((GUI_DRAWMEMDEV_FUNC *)draw_memdev_alpha, (GUI_DRAWBITMAP_FUNC *)draw_bitmap_alpha);
    GUI_SetFuncDrawM565          ((GUI_DRAWMEMDEV_FUNC *)draw_memdev_alpha, (GUI_DRAWBITMAP_FUNC *)draw_bitmap_alpha);
    LCD_SetDevFunc(0, LCD_DEVFUNC_DRAWBMP_16BPP, (void(*)(void))draw_bitmap_16bpp);
    GUI_AA_SetFuncDrawPolyOutline((DRAW_POLY_OUTLOINE *)draw_poly_outline_aa);
    GUI_AA_SetFuncDrawArc        ((DRAW_ARC *)draw_arc_aa);
    GUI_AA_SetFuncFillPolygon    ((FILL_POLYGON *)fill_polygon_aa);
#endif
    GUI_AA_SetFuncFillCircle     ((FILL_CIRCLE *)fill_circle_aa);
    GUI_AA_SetFuncDrawCircle     ((DRAW_CIRCLE *)draw_circle_aa);
    GUI_AA_SetFuncDrawLine       ((DRAW_LINE *)draw_line_aa);
    LCD_SetDevFunc(0, LCD_DEVFUNC_FILLRECT, (void(*)(void))lcd_fill_rect);
    GUI_AlphaEnableFillRectHW(1);
    s_dave_active = 1;
}
/**********************************************************************************************************************
 * End of function R_EMWIN_EnableDave2D
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: R_EMWIN_DisableDave2D
 * Description  : .
 * Arguments    : .
 * Return Value : .
 *********************************************************************************************************************/
void R_EMWIN_DisableDave2D(void)
{
#if (ORIENTATION_0 == EMWIN_DISPLAY_ORIENTATION)
    GUI_SetFuncDrawAlpha         (NULL, NULL);
    GUI_SetFuncDrawM565          (NULL, NULL);
    LCD_SetDevFunc(0, LCD_DEVFUNC_DRAWBMP_16BPP, (void(*)(void))NULL);
    GUI_AA_SetFuncDrawPolyOutline(NULL);
    GUI_AA_SetFuncDrawArc        (NULL);
    GUI_AA_SetFuncFillPolygon    (NULL);
#endif
    GUI_AA_SetFuncFillCircle     (NULL);
    GUI_AA_SetFuncDrawCircle     (NULL);
    GUI_AA_SetFuncDrawLine       (NULL);
    LCD_SetDevFunc(0, LCD_DEVFUNC_FILLRECT, (void(*)(void))NULL);
    GUI_AlphaEnableFillRectHW(0);
    s_dave_active = 0;
}
/**********************************************************************************************************************
 * End of function R_EMWIN_DisableDave2D
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: R_EMWIN_GetDaveActive
 * Description  : .
 * Arguments    : .
 * Return Value : .
 *********************************************************************************************************************/
uint32_t R_EMWIN_GetDaveActive(void)
{
    return s_dave_active;
}
/**********************************************************************************************************************
 * End of function R_EMWIN_GetDaveActive
 *********************************************************************************************************************/
#endif /* USE_DAVE2D == 1 */

/**********************************************************************************************************************
 * Function Name: LCD_X_Config
 * Description  : Called during the initialization process in order to set up the display driver configuration.
 * Arguments    : .
 * Return Value : .
 *********************************************************************************************************************/
void LCD_X_Config(void)
{
    int32_t swap_xy_ex;
#if (USE_DAVE2D == 1)
    d2_s32  d2_ret;
#endif

#if (NUM_BUFFERS > 1)
    GUI_MULTIBUF_ConfigEx(0, NUM_BUFFERS);
#endif

    /* Set display driver and color conversion for 1st layer */
    GUI_DEVICE_CreateAndLink(DISPLAY_DRIVER, COLOR_CONVERSION, 0, 0);

    /* Display driver configuration */
    swap_xy_ex = LCD_GetSwapXYEx(0);
    if (swap_xy_ex)
    {
        LCD_SetSizeEx (0, EMWIN_YSIZE_PHYS, EMWIN_XSIZE_PHYS);
        LCD_SetVSizeEx(0, EMWIN_YSIZE_PHYS, EMWIN_XSIZE_PHYS);
    }
    else
    {
        LCD_SetSizeEx (0, EMWIN_XSIZE_PHYS, EMWIN_YSIZE_PHYS);
        LCD_SetVSizeEx(0, VXSIZE_PHYS, EMWIN_YSIZE_PHYS);
    }
    LCD_SetBufferPtrEx(0, (void **)s_a_buffer_ptr);

#if (USE_DAVE2D == 1)
    /* Initialize Dave2D */
    sp_d2_handle = d2_opendevice(0);
    if (NULL == sp_d2_handle)
    {
        /* WAIT_LOOP */
        while (1)
        {
            R_BSP_NOP(); /* Error */
        }
    }

    d2_ret = d2_inithw(sp_d2_handle, 0);
    if (D2_OK != d2_ret)
    {
        /* WAIT_LOOP */
        while (1)
        {
            R_BSP_NOP(); /* Error */
        }
    }

    sp_renderbuffer = d2_newrenderbuffer(sp_d2_handle, 20, 20);
    if (NULL == sp_renderbuffer)
    {
        /* WAIT_LOOP */
        while (1)
        {
            R_BSP_NOP(); /* Error */
        }
    }
#endif

    /* Set function pointers */
    LCD_SetDevFunc(0, LCD_DEVFUNC_COPYBUFFER, (void(*)(void))copy_buffer);
}
/**********************************************************************************************************************
 * End of function LCD_X_Config
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: LCD_X_DisplayDriver
 * Description  : This function is called by the display driver for several purposes.
 *                To support the according task the routine needs to be adapted to
 *                the display controller. Please note that the commands marked with
 *                'optional' are not cogently required and should only be adapted if
 *                the display controller supports these features.
 * Arguments    : layer_index - Index of layer to be configured
 *                cmd         - Please refer to the details in the switch statement below
 *                p_data      - Pointer to a LCD_X_DATA structure
 * Return Value : < -1 - Error
 *                  -1 - Command not handled
 *                   0 - Ok
 *********************************************************************************************************************/
int LCD_X_DisplayDriver(unsigned layer_index, unsigned cmd, void * p_data)
{
    int32_t r = 0;

    GUI_USE_PARA(layer_index);
    switch (cmd)
    {
        /* Required */
        case LCD_X_INITCONTROLLER:
        {
            /* Called during the initialization process in order to set up the
             * display controller and put it into operation. If the display
             * controller is not initialized by any external routine this needs
             * to be adapted by the customer... */
            init_controller();
#if (USE_DAVE2D == 1)
            R_EMWIN_EnableDave2D();
#endif
            break;
        }

        /* Required for setting a lookup table entry which is passed in the 'Pos' and 'Color' element of p. */
        case LCD_X_SETLUTENTRY:
        {
            LCD_X_SETLUTENTRY_INFO * p;

            p = (LCD_X_SETLUTENTRY_INFO *)p_data;
            set_lut_entry(p->Color, p->Pos);
            break;
        }

        /* Required if multiple buffers are used. The 'Index' element of p contains the buffer index. */
        case LCD_X_SHOWBUFFER:
        {
            LCD_X_SHOWBUFFER_INFO * p;

            p = (LCD_X_SHOWBUFFER_INFO *)p_data;
            switch_buffers_on_vsync(p->Index);
            break;
        }

        /* Required if the display controller should support switching on and off. */
        case LCD_X_ON:
        {
            display_on_off(1);
            break;
        }

        /* Required if the display controller should support switching on and off. */
        case LCD_X_OFF:
        {
            display_on_off(0);
            break;
        }

        default:
        {
            r = -1;
        }
    }

    return r;
}
/**********************************************************************************************************************
 * End of function LCD_X_DisplayDriver
 *********************************************************************************************************************/

/**********************************************************************************************************************
 * Function Name: _VSYNC_ISR
 * Description  : .
 * Arguments    : .
 * Return Value : .
 *********************************************************************************************************************/
void _VSYNC_ISR(void * p)
{
    if (false == s_first_interrupt_flag)
    {
        s_first_interrupt_flag = true;

        /* Do nothing */
    }
    else
    {
        glcdc_callback_args_t * p_decode;
        p_decode = (glcdc_callback_args_t*) p;

        if (GLCDC_EVENT_GR1_UNDERFLOW == p_decode->event)
        {
            R_BSP_NOP(); /* GR1 underflow , if necessary */
        }
        else if (GLCDC_EVENT_GR2_UNDERFLOW == p_decode->event)
        {
            R_BSP_NOP(); /* GR2 underflow , if necessary */
        }
        else /* GLCDC_EVENT_LINE_DETECTION */
        {
            /* Sets a flag to be able to notice the interrupt */
            s_pending_buffer = 0;
        }
    }
}
/**********************************************************************************************************************
 * End of function _VSYNC_ISR
 *********************************************************************************************************************/
