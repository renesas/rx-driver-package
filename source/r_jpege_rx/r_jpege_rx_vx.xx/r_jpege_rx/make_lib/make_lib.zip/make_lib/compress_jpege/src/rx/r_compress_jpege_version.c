/***********************************************************************************************************************
* Copyright (C) 2006-2013 Renesas Solutions Corp. All rights reserved.
***********************************************************************************************************************/

/*******************************************************************************
* File Name     : r_compress_jpege_version.c
* Version       :
* Device(s)     : RX Family
* Tool-Chain    :
* H/W Platform  :
* Description   : Version information
* Operation     :
******************************************************************************/

/******************************************************************************
Includes <System Includes> , "Project Includes"
******************************************************************************/
#include "r_stdint.h"
#include "r_mw_version.h"

#pragma section _jpeg_cmp_S

/******************************************************************************
Typedef definitions
******************************************************************************/

/******************************************************************************
Macro definitions
******************************************************************************/
#define __CMP_JPEGE_VERSION__ "1.00"

#if   (defined	(__RX600) && defined (__BIG))
#define __TARGET_CPU__ "RX600 BIG endian"
#define __COMPILER_VER__	__RENESAS_VERSION__
#elif (defined	(__RX600) && defined (__LIT))
#define __TARGET_CPU__ "RX600 LITTLE endian"
#define __COMPILER_VER__	__RENESAS_VERSION__
#elif (defined	(__RX200) && defined (__BIG))
#define __TARGET_CPU__ "RX200 BIG endian"
#define __COMPILER_VER__	__RENESAS_VERSION__
#elif (defined	(__RX200) && defined (__LIT))
#define __TARGET_CPU__ "RX200 LITTLE endian"
#define __COMPILER_VER__	__RENESAS_VERSION__
#else
#error "None-support combination of CPU and endian"
#endif

/******************************************************************************
Imported global variables and functions (from other files)
******************************************************************************/

/******************************************************************************
Exported global variables and functions (to be accessed by other files)
******************************************************************************/

const mw_version_t R_compress_jpege_version =
{
	__COMPILER_VER__ ,
	"JPEG File Compress Library version "__CMP_JPEGE_VERSION__" for the "__TARGET_CPU__".("__DATE__", "__TIME__")\n"
};

/******************************************************************************
Private global variables and functions
******************************************************************************/
