/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2006-2013 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/

/*******************************************************************************
* File Name     : ycc2rgb.c
* Version       :
* Device(s)     : RX family
* Tool-Chain    : C/C++ compiler package for RX family
* OS            :
* H/W Platform  :
* Description   : YCC->RGB conversion
* Operation     :
******************************************************************************/

/******************************************************************************
Includes <System Includes> , �gProject Includes�h
******************************************************************************/
#include "r_expand_jpegd.h"
#include "r_rgb2short.h"

/******************************************************************************
Typedef definitions
******************************************************************************/

/******************************************************************************
Macro definitions
******************************************************************************/
#define NUM_COEFF	(4)

/******************************************************************************
Imported global variables and functions (from other files)
******************************************************************************/

/******************************************************************************
Exported global variables and functions (to be accessed by other files)
******************************************************************************/

/******************************************************************************
Private global variables and functions
******************************************************************************/
#pragma section _jpeg_exp_F

typedef union
{
	int16_t word[NUM_COEFF];
	int32_t	longWord[NUM_COEFF / 2];
} CoeffData;

const CoeffData coeffData =
{
#ifdef __LIT
	0x59ba,			// +1.40200
	0xe9fb,			// -0.34414
	0xd24d,			// -0.71414
	0x7168,			// +1.77200
#else
	0xe9fb,			// -0.34414
	0x59ba,			// +1.40200
	0x7168,			// +1.77200
	0xd24d,			// -0.71414
#endif
};

#pragma inline_asm ycc2rgb
static void ycc2rgb(uint8_t *, uint8_t *);

/******************************************************************************
Functions
******************************************************************************/
#pragma section _jpeg_exp_F

/******************************************************************************
* Declaration       : static void ycc2rgb(uint8_t *ycc, uint8_t *rgb)
* Function Name     : ycc2rgb
* Description       : YCbCr is changed into RGB. 1 pixel
* Argument          : ycc - Pointer of YCbCr data
*                   : rgb - Pointer of RGB data
* Return Value      : none
******************************************************************************/
static void ycc2rgb(uint8_t *ycc, uint8_t *rgb)
{
	push.l	r6
	push.l	r7

; register r1: ycc
; register r2: rgb

	movu.b	[r1+], r3	; y
	movu.b	[r1+], r4	; cb
	movu.b	[r1], r5	; cr
	add	#-128, r4
	add	#-128, r5
	mov.l	#_coeffData, r1

	/*	R = Y + 1.40200 * Cr	*/
	mov.l	[r1+], r6
	mullo	r6, r5
	shlr	#16, r6		; Shift into lower 16 bits to use coefficient in upper 16 bits
	racw	#2
	mvfachi	r7
	add	r3, r7
 	min  	#000000FFH, r7		; Saturate calculation
 	max     #00H,r7
	mov.b   r7, [r2+]

	/*	G = Y - 0.34414 * Cb - 0.71414 * Cr	*/
	mov.l	[r1+], r7
	mullo	r6, r4
	maclo	r7, r5
	shlr	#16, r7		; Shift into lower 16 bits to use coefficient in upper 16 bits
	racw	#2
	mvfachi	r6
	add	r3, r6
	min  	#000000FFH, r6	; Saturate calculation
	max     #00H, r6
	mov.b   r6, [r2+]

	/*	B = Y + 1.77200 * Cb	*/
	mullo	r7, r4
	racw	#2
	mvfachi	r6
	add	r3, r6
	min  	#000000FFH, r6		; Saturate calculation
	max     #00H, r6
	mov.b   r6, [r2]

	pop	r7
	pop	r6
}

/******************************************************************************
* Declaration       : void ycc444_422v_rgb565(uint8_t *pY, uint8_t *pCb, uint8_t *pCr, uint16_t *outptr, int32_t width)
* Function Name     : ycc444_422v_rgb565
* Description       : Output 1 line by RGB565, for YCbCr 4:4:4 and 4:2:2 virtical.
* Argument          : pY - Pointer to the area in which Y component is stored.
*                   : pCb - Pointer to the area in which Cb component is stored.
*                   : pCr - Pointer to the area in which Cr component is stored.
*                   : outptr - Pointer to head of output data.
*                   : width - Width to output.
* Return Value      : none
******************************************************************************/
void
ycc444_422v_rgb565(uint8_t *pY, uint8_t *pCb, uint8_t *pCr, uint16_t *outptr, int32_t width)
{
	uint8_t ycbcr[3];
	uint8_t rgb[3];
	uint16_t rgb565;
	int32_t i;

	for (i = width; i; --i)
	{
		ycbcr[0] = *pY++;
		ycbcr[1] = *pCb++;
		ycbcr[2] = *pCr++;
		ycc2rgb(ycbcr, rgb);
		RGB2SHORT_R5G6B5(rgb565, rgb[0], rgb[1], rgb[2]);
		*outptr++ = rgb565;
	}
}

/******************************************************************************
* Declaration       : void ycc422_420_rgb565(uint8_t *pY, uint8_t *pCb, uint8_t *pCr, uint16_t *outptr, int32_t width)
* Function Name     : ycc422_420_rgb565
* Description       : Output 1 line by RGB565, for YCbCr 4:2:2 and 4:2:0.
* Argument          : pY - Pointer to the area in which Y component is stored.
*                   : pCb - Pointer to the area in which Cb component is stored.
*                   : pCr - Pointer to the area in which Cr component is stored.
*                   : outptr - Pointer to head of output data.
*                   : width - Width to output.
* Return Value      : none
******************************************************************************/
void
ycc422_420_rgb565(uint8_t *pY, uint8_t *pCb, uint8_t *pCr, uint16_t *outptr, int32_t width)
{
	uint8_t ycbcr[3];
	uint8_t rgb[3];
	uint16_t rgb565;
	int32_t i;

	for (i = width / 2; i; --i)
	{
		ycbcr[0] = *pY++;
		ycbcr[1] = *pCb++;
		ycbcr[2] = *pCr++;
		ycc2rgb(ycbcr, rgb);
		RGB2SHORT_R5G6B5(rgb565, rgb[0], rgb[1], rgb[2]);
		*outptr++ = rgb565;

		ycbcr[0] = *pY++;
		ycc2rgb(ycbcr, rgb);
		RGB2SHORT_R5G6B5(rgb565, rgb[0], rgb[1], rgb[2]);
		*outptr++ = rgb565;
	}
	if (width & 1)
	{
		ycbcr[0] = *pY++;
		ycbcr[1] = *pCb++;
		ycbcr[2] = *pCr++;
		ycc2rgb(ycbcr, rgb);
		RGB2SHORT_R5G6B5(rgb565, rgb[0], rgb[1], rgb[2]);
		*outptr++ = rgb565;
	}
}
