/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2006-2013 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/

/*******************************************************************************
* File Name     : r_expand_jpegd_version.c
* Version       :
* Device(s)     : RX Family
* Tool-Chain    :
* H/W Platform  :
* Description   : Version information
* Operation     :
******************************************************************************/

/******************************************************************************
Includes <System Includes> , "Project Includes"
******************************************************************************/
#include "r_stdint.h"
#include "r_mw_version.h"

/******************************************************************************
Typedef definitions
******************************************************************************/

/******************************************************************************
Macro definitions
******************************************************************************/
#define __EXP_JPEGD_VERSION__ "1.03"

#if   (defined	(__RX600) && defined (__BIG))
#define __TARGET_CPU__ "RX600 BIG endian"
#define __COMPILER_VER__	__RENESAS_VERSION__
#elif (defined	(__RX600) && defined (__LIT))
#define __TARGET_CPU__ "RX600 LITTLE endian"
#define __COMPILER_VER__	__RENESAS_VERSION__
#elif (defined	(__RX200) && defined (__BIG))
#define __TARGET_CPU__ "RX200 BIG endian"
#define __COMPILER_VER__	__RENESAS_VERSION__
#elif (defined	(__RX200) && defined (__LIT))
#define __TARGET_CPU__ "RX200 LITTLE endian"
#define __COMPILER_VER__	__RENESAS_VERSION__
#else
#error "None-support combination of CPU and endian"
#endif

/******************************************************************************
Imported global variables and functions (from other files)
******************************************************************************/

/******************************************************************************
Exported global variables and functions (to be accessed by other files)
******************************************************************************/
#pragma section _jpeg_exp_S

const mw_version_t R_expand_jpegd_version =
{
	__COMPILER_VER__ ,
	"JPEG File Expand Library version "__EXP_JPEGD_VERSION__" for the "__TARGET_CPU__".("__DATE__", "__TIME__")\n"
};

/******************************************************************************
Private global variables and functions
******************************************************************************/
