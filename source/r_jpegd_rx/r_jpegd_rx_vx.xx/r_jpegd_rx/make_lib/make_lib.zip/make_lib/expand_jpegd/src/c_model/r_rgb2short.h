/*******************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2006-2013 Renesas Electronics Corporation. All rights reserved.
*******************************************************************************/

/*******************************************************************************
* File Name     : r_rgb2short.h
* Version       :
* Device(s)     :
* Tool-Chain    :
* H/W Platform  :
* Description   : The macro definition of RGB565 conversion
******************************************************************************/

#if !defined(_r_rgb2short_h)
#define _r_rgb2short_h

/******************************************************************************
Macro definitions
******************************************************************************/
#define RGB2SHORT(r, g, b)	RGB2SHORT_##r##g##b

#define MASK_UP5BITS	(0xf8)
#define MASK_UP6BITS	(0xfc)

#define ONEBYTE8BITS	(8)
#define RGB6BITS		(6)
#define RGB5BITS		(5)

/* Case of R:G:B=5:6:5 */
#define SHORT565R		RGB5BITS
#define SHORT565G		RGB6BITS
#define SHORT565B		RGB5BITS
#define RGB2SHORT_R5G6B5(rgb, r, g, b)	\
			rgb = ((r) & MASK_UP5BITS) << (SHORT565G+SHORT565B-(ONEBYTE8BITS-SHORT565R));		\
			rgb |= (((g) & MASK_UP6BITS) << (SHORT565B-(ONEBYTE8BITS-SHORT565G)));		\
			rgb |= ((b) >> (ONEBYTE8BITS-SHORT565B));

#endif

