/***********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
 * SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2006-2024 Renesas Electronics Corporation. All rights reserved.
 **********************************************************************************************************************/
/***********************************************************************************************************************
* File Name     : r_expand.c
* Version       :
* Device(s)     :
* Tool-Chain    :
* H/W Platform  :
* Description   : Extension processing of JPEG file
***********************************************************************************************************************/
/**********************************************************************************************************************
* History : DD.MM.YYYY Version  Description
*         : 15.11.2024 2.07     Added WAIT_LOOP comment.
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_jpegd.h"
#include "r_expand_jpegd.h"
#include "r_jpeg_maker.h"

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
#define DC_TBL(finfo, n)	(finfo->dc_tbl_no[n])
#define AC_TBL(finfo, n)	(finfo->ac_tbl_no[n])
#define Q_TBL(finfo, cinfo, n)	 (cinfo->quant_tbl_no[finfo->component_id[n]-1])
#define DCT_WORK			align.mem.dct_work

/***********************************************************************************************************************
Imported global variables and functions (from other files)
***********************************************************************************************************************/
extern void ycc444_422v_rgb565(uint8_t *, uint8_t *, uint8_t *, uint16_t *, int32_t);
extern void ycc422_420_rgb565(uint8_t *, uint8_t *, uint8_t *, uint16_t *, int32_t);
extern void R_jpeg_read_input(struct _jpeg_working *wenv);

/***********************************************************************************************************************
Exported global variables and functions (to be accessed by other files)
***********************************************************************************************************************/

/***********************************************************************************************************************
Private global variables and functions
***********************************************************************************************************************/
#pragma section _jpeg_exp_F

static union
{
	uint32_t	dummy;
	struct
	{
		int16_t dct_work[_JPEG_DCTSIZE2 + 2];
		uint8_t  Y[_JPEG_DCTSIZE2 * 4];
		uint8_t Cb[_JPEG_DCTSIZE2];
		uint8_t Cr[_JPEG_DCTSIZE2];
	} mem;
} align;

static uint8_t *Y_outptr[_JPEG_DCTSIZE * 2];
static uint8_t *Cb_outptr[_JPEG_DCTSIZE];
static uint8_t *Cr_outptr[_JPEG_DCTSIZE];
static uint16_t *RGB_outptr[(_JPEG_DCTSIZE * 2) + 1];

static int16_t Y_last_dc_val, Cb_last_dc_val, Cr_last_dc_val;

static struct _jpeg_working working;
static struct _jpeg_dec_FMB FMB;

#pragma section _jpeg_exp_S

static struct _jpeg_dec_SMB SMB;
static int16_t _jpeg_MCU_count;
static int16_t _jpeg_next_restart_num;

#pragma section _jpeg_exp_F

static void init_ycc444_outptr(int16_t, uint8_t **, uint8_t **, uint8_t **);
static void init_ycc4xx_outptr(int16_t, uint8_t **, uint8_t **, uint8_t **);
static void init_last_outptr(int32_t, uint16_t **, uint16_t *);
static int16_t decode444(uint16_t *, int32_t);
static int16_t decode422(uint16_t *, int32_t);
static int16_t decode422v(uint16_t *, int32_t);
static int16_t decode420(uint16_t *, int32_t);
static int16_t _jpeg_restart_marker(struct _jpeg_working *);
static void _jpeg_open(uint8_t *, int32_t, struct _jpeg_working *);

/***********************************************************************************************************************
Functions
***********************************************************************************************************************/
#pragma section _jpeg_exp_F

/***********************************************************************************************************************
* Declaration       : void R_init_jpeg(void)
* Function Name     : R_init_jpeg
* Description       : Initialization of JPEG Software Library
* Argument          : none
* Return Value      : none
***********************************************************************************************************************/
void
R_init_jpeg(void)
{
	working.decFMB = &FMB;
	working.decSMB = &SMB;
	working.decFMC = (struct _jpeg_dec_FMC *)_top_of_jpeg_dec_FMC;
	working.dec_read_input = R_jpeg_read_input;
}

/***********************************************************************************************************************
* Declaration       : int16_t R_get_info_jpeg(uint8_t *input, int32_t fsize, uint16_t *w, uint16_t *h)
* Function Name     : R_get_info_jpeg
* Description       : Get information of JPEG file
* Argument          : input - Pointer to head of input data.
*                   : fsize - Size of input data.
*                   : w - Pointer to data of picture width.
*                   : h - Pointer to data of picture height.
* Return Value      : 0=success, not 0=error
***********************************************************************************************************************/
int16_t
R_get_info_jpeg(uint8_t *input, int32_t fsize, uint16_t *w, uint16_t *h)
{
	int16_t ret;
	struct _jpeg_dec_SMB *decSMB;

	decSMB = working.decSMB;

	_jpeg_open(input, fsize, &working);

	/* Read JPEG Header */
	ret = _jpeg_read_header(&working, _READ_HEADER_FOR_GET_INFO);
	if (ret != EXPAND_JPEGD_OK)
	{
		return ret;
	}

	*w = _jpeg_d_line_length(decSMB);
	*h = _jpeg_d_number_of_lines(decSMB);

	return EXPAND_JPEGD_OK;
}

/***********************************************************************************************************************
* Declaration       : int16_t R_expand_jpeg(uint8_t *input, int32_t fsize, uint16_t *outptr, int32_t offset)
* Function Name     : R_expand_jpeg
* Description       : Expand JPEG file
* Argument          : input - Pointer to head of input data.
*                   : fsize - Size of input data.
*                   : outptr - Pointer to head of output data.
*                   : offset - Number of pixels by 1 line in output area.
* Return Value      : 0=success, not 0=error
***********************************************************************************************************************/
int16_t
R_expand_jpeg(uint8_t *input, int32_t fsize, uint16_t *outptr, int32_t offset)
{
	int16_t ret;
	struct _jpeg_dec_SMB *decSMB;
	uint8_t *sample;
	int32_t hRatio, vRatio;

	decSMB = working.decSMB;

	_jpeg_open(input, fsize, &working);

	/* Read JPEG Header */
	ret = _jpeg_read_header(&working, _READ_HEADER_FOR_EXPAND);
	if (ret != EXPAND_JPEGD_OK)
	{
		return ret;
	}

	if(_jpeg_d_num_of_components(decSMB) != _JPEG_COMPONENT_NUM)
	{
		return EXPAND_JPEGD_NOT_SUPPORT;
	}
	
	init_last_outptr(offset, RGB_outptr, outptr);
	_jpeg_next_restart_num = 0;

	sample = (component_info(decSMB)).hsample_ratio;
	hRatio = sample[0];
	hRatio = (hRatio << 8) | sample[1];
	hRatio = (hRatio << 8) | sample[2];

	sample = (component_info(decSMB)).vsample_ratio;
	vRatio = sample[0];
	vRatio = (vRatio << 8) | sample[1];
	vRatio = (vRatio << 8) | sample[2];
	if ((hRatio == 0x00020101) && (vRatio == 0x00020101))
	{
		ret = decode420(outptr, offset);
	}
	else if ((hRatio == 0x00020101) && (vRatio == 0x00010101))
	{
		ret = decode422(outptr, offset);
	}
	else if ((hRatio == 0x00010101) && (vRatio == 0x00010101))
	{
		ret = decode444(outptr, offset);
	}
	else if ((hRatio == 0x00010101) && (vRatio == 0x00020101))
	{
		ret = decode422v(outptr, offset);
	}
	else
	{
		return EXPAND_JPEGD_NOT_SUPPORT;
	}
	if (ret != EXPAND_JPEGD_OK)
	{
		return ret;
	}

	/* EOI */
	if (_jpeg_checkEOI(&working))
	{
		return EXPAND_JPEGD_ERROR_EOI;
	}

	return EXPAND_JPEGD_OK;
}

/***********************************************************************************************************************
* Declaration       : static int16_t decode444(uint16_t *outptr, int32_t offset)
* Function Name     : decode444
* Description       : Decode processing of YCbCr 4:4:4
* Argument          : outptr - Pointer to head of output data.
*                   : offset - Number of pixels by 1 line in output area.
* Return Value      : 0=success, not 0=error
***********************************************************************************************************************/
static int16_t
decode444(uint16_t *outptr, int32_t offset)
{
	int16_t Y_dc_tbl_no, Y_ac_tbl_no, Y_q_tbl_no;
	int16_t Cb_dc_tbl_no, Cb_ac_tbl_no, Cb_q_tbl_no;
	int16_t Cr_dc_tbl_no, Cr_ac_tbl_no, Cr_q_tbl_no;
	uint8_t  **ppY, **ppCb, **ppCr;
	struct _jpeg_working *wenv;
	struct _jpeg_dec_FMB *decFMB = working.decFMB;
	struct _jpeg_dec_SMB *decSMB = working.decSMB;
	struct component_info *cinfo;
	struct frame_component_info *finfo;
	int16_t lines, width, right_edge, bottom_edge;
	int16_t i, j, k;
	int16_t output_start_col;
	uint16_t *outp, **outpp;
	int32_t block_h, block_w;
	int16_t ret;

	wenv = &working;
	decFMB = wenv->decFMB;
	decSMB = wenv->decSMB;

	Y_last_dc_val = Cb_last_dc_val = Cr_last_dc_val = 0;
	finfo = & (frame_component_info(decSMB));
	cinfo = &(component_info(decSMB));

	Y_dc_tbl_no = DC_TBL(finfo, 0);
	Y_ac_tbl_no = AC_TBL(finfo, 0);
	Y_q_tbl_no = Q_TBL(finfo, cinfo, 0);
	Cb_dc_tbl_no = DC_TBL(finfo, 1);
	Cb_ac_tbl_no = AC_TBL(finfo, 1);
	Cb_q_tbl_no = Q_TBL(finfo, cinfo, 1);
	Cr_dc_tbl_no = DC_TBL(finfo, 2);
	Cr_ac_tbl_no = AC_TBL(finfo, 2);
	Cr_q_tbl_no = Q_TBL(finfo, cinfo, 2);
	output_start_col = 0;

	lines = ((_jpeg_d_number_of_lines(decSMB) + _JPEG_DCTSIZE - 1) >> 3);
	bottom_edge = (_jpeg_d_number_of_lines(decSMB)) & 0x0007;

	width = ((_jpeg_d_line_length(decSMB) + _JPEG_DCTSIZE - 1) >> 3);
	right_edge = (_jpeg_d_line_length(decSMB)) & 0x0007;

	_jpeg_MCU_count = _jpeg_restart_interval(decFMB);
	init_ycc444_outptr(_JPEG_DCTSIZE, Y_outptr, Cb_outptr, Cr_outptr);

    /* WAIT_LOOP */
	for (i = 0; i < lines; ++i)
	{
		if ((i < lines - 1) || (bottom_edge == 0))
		{
			block_h = _JPEG_DCTSIZE;
		}
		else
		{
			block_h = bottom_edge;
		}
        /* WAIT_LOOP */
		for (j = 0; j < width; ++j)
		{
			if ((j < width - 1) || (right_edge == 0))
			{
				block_w = _JPEG_DCTSIZE;
			}
			else
			{
				block_w = right_edge;
			}
			if (_jpeg_restart_marker(wenv) < 0)
			{
				return EXPAND_JPEGD_ERROR_RST;
			}

			ret = R_jpeg_decode_one_block(Y_last_dc_val, Y_dc_tbl_no, Y_ac_tbl_no, DCT_WORK, wenv);
			if (ret != _JPEGD_OK)
			{
				return EXPAND_JPEGD_ERROR_DECODE;
			}
			Y_last_dc_val = DCT_WORK[0];
			R_jpeg_IDCT(DCT_WORK, Y_outptr, 0, Y_q_tbl_no, wenv);

			ret = R_jpeg_decode_one_block(Cb_last_dc_val, Cb_dc_tbl_no, Cb_ac_tbl_no, DCT_WORK, wenv);
			if (ret != _JPEGD_OK)
			{
				return EXPAND_JPEGD_ERROR_DECODE;
			}
			Cb_last_dc_val = DCT_WORK[0];
			R_jpeg_IDCT(DCT_WORK, Cb_outptr, 0, Cb_q_tbl_no, wenv);

			ret = R_jpeg_decode_one_block(Cr_last_dc_val, Cr_dc_tbl_no, Cr_ac_tbl_no, DCT_WORK, wenv);
			if (ret != _JPEGD_OK)
			{
				return EXPAND_JPEGD_ERROR_DECODE;
			}
			Cr_last_dc_val = DCT_WORK[0];
			R_jpeg_IDCT(DCT_WORK, Cr_outptr, 0, Cr_q_tbl_no, wenv);

			ppY = Y_outptr, ppCb = Cb_outptr, ppCr = Cr_outptr;
			outpp = RGB_outptr;

            /* WAIT_LOOP */
			for (k = 0; k < block_h; ++k)
			{
				outp = *outpp++;
				ycc444_422v_rgb565(*ppY++, *ppCb++, *ppCr++, (uint16_t *)&outp[output_start_col], block_w);
			}

			output_start_col += _JPEG_DCTSIZE;
		}

		output_start_col = 0;
		init_last_outptr(offset, RGB_outptr, RGB_outptr[_JPEG_DCTSIZE]);
	}
	return EXPAND_JPEGD_OK;
}

/***********************************************************************************************************************
* Declaration       : static int16_t decode422(uint16_t *outptr, int32_t offset)
* Function Name     : decode422
* Description       : Decode processing of YCbCr 4:2:2
* Argument          : outptr - Pointer to head of output data.
*                   : offset - Number of pixels by 1 line in output area.
* Return Value      : 0=success, not 0=error
***********************************************************************************************************************/
static int16_t
decode422(uint16_t *outptr, int32_t offset)
{
	int16_t Y_dc_tbl_no, Y_ac_tbl_no, Y_q_tbl_no;
	int16_t Cb_dc_tbl_no, Cb_ac_tbl_no, Cb_q_tbl_no;
	int16_t Cr_dc_tbl_no, Cr_ac_tbl_no, Cr_q_tbl_no;
	uint8_t **ppY, **ppCb, **ppCr;
	struct _jpeg_working *wenv;
	struct _jpeg_dec_FMB *decFMB = working.decFMB;
	struct _jpeg_dec_SMB *decSMB = working.decSMB;
	struct component_info *cinfo;
	struct frame_component_info *finfo;
	int16_t lines, width, right_edge, bottom_edge;
	int16_t i, j, k;
	int16_t output_start_col;
	uint16_t *outp, **outpp;
	int32_t block_h, block_w;
	int16_t ret;

	wenv = &working;
	decFMB = wenv->decFMB;
	decSMB = wenv->decSMB;

	Y_last_dc_val = Cb_last_dc_val = Cr_last_dc_val = 0;
	finfo = & (frame_component_info(decSMB));
	cinfo = &(component_info(decSMB));

	Y_dc_tbl_no = DC_TBL(finfo, 0);
	Y_ac_tbl_no = AC_TBL(finfo, 0);
	Y_q_tbl_no = Q_TBL(finfo, cinfo, 0);
	Cb_dc_tbl_no = DC_TBL(finfo, 1);
	Cb_ac_tbl_no = AC_TBL(finfo, 1);
	Cb_q_tbl_no = Q_TBL(finfo, cinfo, 1);
	Cr_dc_tbl_no = DC_TBL(finfo, 2);
	Cr_ac_tbl_no = AC_TBL(finfo, 2);
	Cr_q_tbl_no = Q_TBL(finfo, cinfo, 2);
	output_start_col = 0;

	lines = ((_jpeg_d_number_of_lines(decSMB) + _JPEG_DCTSIZE - 1) >> 3);
	bottom_edge = (_jpeg_d_number_of_lines(decSMB)) & 0x0007;

	width = ((_jpeg_d_line_length(decSMB) + (_JPEG_DCTSIZE * 2) - 1) >> 4);
	right_edge = (_jpeg_d_line_length(decSMB)) & 0x000F;

	_jpeg_MCU_count = _jpeg_restart_interval(decFMB);
	init_ycc4xx_outptr(2 * _JPEG_DCTSIZE, Y_outptr, Cb_outptr, Cr_outptr);

    /* WAIT_LOOP */
	for (i = 0; i < lines; ++i)
	{
		if ((i < lines - 1) || (bottom_edge == 0))
		{
			block_h = _JPEG_DCTSIZE;
		}
		else
		{
			block_h = bottom_edge;
		}
        /* WAIT_LOOP */
		for (j = 0; j < width; ++j)
		{
			if ((j < width - 1) || (right_edge == 0))
			{
				block_w = _JPEG_DCTSIZE * 2;
			}
			else
			{
				block_w = right_edge;
			}
			if (_jpeg_restart_marker(wenv) < 0)
			{
				return EXPAND_JPEGD_ERROR_RST;
			}

			ret = R_jpeg_decode_one_block(Y_last_dc_val, Y_dc_tbl_no, Y_ac_tbl_no, DCT_WORK, wenv);
			if (ret != _JPEGD_OK)
			{
				return EXPAND_JPEGD_ERROR_DECODE;
			}
			Y_last_dc_val = DCT_WORK[0];
			R_jpeg_IDCT(DCT_WORK, Y_outptr, 0, Y_q_tbl_no, wenv);

			ret = R_jpeg_decode_one_block(Y_last_dc_val, Y_dc_tbl_no, Y_ac_tbl_no, DCT_WORK, wenv);
			if (ret != _JPEGD_OK)
			{
				return EXPAND_JPEGD_ERROR_DECODE;
			}
			Y_last_dc_val = DCT_WORK[0];
			R_jpeg_IDCT(DCT_WORK, Y_outptr, _JPEG_DCTSIZE, Y_q_tbl_no, wenv);

			ret = R_jpeg_decode_one_block(Cb_last_dc_val, Cb_dc_tbl_no, Cb_ac_tbl_no, DCT_WORK, wenv);
			if (ret != _JPEGD_OK)
			{
				return EXPAND_JPEGD_ERROR_DECODE;
			}
			Cb_last_dc_val = DCT_WORK[0];
			R_jpeg_IDCT(DCT_WORK, Cb_outptr, 0, Cb_q_tbl_no, wenv);

			ret = R_jpeg_decode_one_block(Cr_last_dc_val, Cr_dc_tbl_no, Cr_ac_tbl_no, DCT_WORK, wenv);
			if (ret != _JPEGD_OK)
			{
				return EXPAND_JPEGD_ERROR_DECODE;
			}
			Cr_last_dc_val = DCT_WORK[0];
			R_jpeg_IDCT(DCT_WORK, Cr_outptr, 0, Cr_q_tbl_no, wenv);

			ppY = Y_outptr, ppCb = Cb_outptr, ppCr = Cr_outptr;
			outpp = RGB_outptr;

            /* WAIT_LOOP */
			for (k = 0; k < block_h; ++k)
			{
				outp = *outpp++;
				ycc422_420_rgb565(*ppY++, *ppCb++, *ppCr++, (uint16_t *)&outp[output_start_col], block_w);
			}

			output_start_col += 2 * _JPEG_DCTSIZE;
		}

		output_start_col = 0;
		init_last_outptr(offset, RGB_outptr, RGB_outptr[_JPEG_DCTSIZE]);
	}
	return EXPAND_JPEGD_OK;
}

/***********************************************************************************************************************
* Declaration       : static int16_t decode422v(uint16_t *outptr, int32_t offset)
* Function Name     : decode422v
* Description       : Decode processing of YCbCr 4:2:2 virtical
* Argument          : outptr - Pointer to head of output data.
*                   : offset - Number of pixels by 1 line in output area.
* Return Value      : 0=success, not 0=error
***********************************************************************************************************************/
static int16_t
decode422v(uint16_t *outptr, int32_t offset)
{
	int16_t Y_dc_tbl_no, Y_ac_tbl_no, Y_q_tbl_no;
	int16_t Cb_dc_tbl_no, Cb_ac_tbl_no, Cb_q_tbl_no;
	int16_t Cr_dc_tbl_no, Cr_ac_tbl_no, Cr_q_tbl_no;
	uint8_t **ppY, **ppCb, **ppCr;
	struct _jpeg_working *wenv;
	struct _jpeg_dec_FMB *decFMB = working.decFMB;
	struct _jpeg_dec_SMB *decSMB = working.decSMB;
	struct component_info *cinfo;
	struct frame_component_info *finfo;
	int16_t lines, width, right_edge, bottom_edge;
	int16_t i, j, k;
	int16_t output_start_col;
	uint16_t *outp, **outpp;
	int32_t block_h, block_w;
	int16_t ret;

	wenv = &working;
	decFMB = wenv->decFMB;
	decSMB = wenv->decSMB;

	Y_last_dc_val = Cb_last_dc_val = Cr_last_dc_val = 0;
	finfo = & (frame_component_info(decSMB));
	cinfo = &(component_info(decSMB));

	Y_dc_tbl_no = DC_TBL(finfo, 0);
	Y_ac_tbl_no = AC_TBL(finfo, 0);
	Y_q_tbl_no = Q_TBL(finfo, cinfo, 0);
	Cb_dc_tbl_no = DC_TBL(finfo, 1);
	Cb_ac_tbl_no = AC_TBL(finfo, 1);
	Cb_q_tbl_no = Q_TBL(finfo, cinfo, 1);
	Cr_dc_tbl_no = DC_TBL(finfo, 2);
	Cr_ac_tbl_no = AC_TBL(finfo, 2);
	Cr_q_tbl_no = Q_TBL(finfo, cinfo, 2);
	output_start_col = 0;


	lines = ((_jpeg_d_number_of_lines(decSMB) + (_JPEG_DCTSIZE * 2) - 1) >> 4);
	bottom_edge = (_jpeg_d_number_of_lines(decSMB)) & 0x000F;

	width = ((_jpeg_d_line_length(decSMB) + _JPEG_DCTSIZE - 1) >> 3);
	right_edge = (_jpeg_d_line_length(decSMB)) & 0x0007;

	_jpeg_MCU_count = _jpeg_restart_interval(decFMB);
	init_ycc4xx_outptr(2 * _JPEG_DCTSIZE, Y_outptr, Cb_outptr, Cr_outptr);

    /* WAIT_LOOP */
	for (i = 0; i < lines; ++i)
	{
		if ((i < lines - 1) || (bottom_edge == 0))
		{
			block_h = _JPEG_DCTSIZE * 2;
		}
		else
		{
			block_h = bottom_edge;
		}
        /* WAIT_LOOP */
		for (j = 0; j < width; ++j)
		{
			if ((j < width - 1) || (right_edge == 0))
			{
				block_w = _JPEG_DCTSIZE;
			}
			else
			{
				block_w = right_edge;
			}
			if (_jpeg_restart_marker(wenv) < 0)
			{
				return EXPAND_JPEGD_ERROR_RST;
			}

			ret = R_jpeg_decode_one_block(Y_last_dc_val, Y_dc_tbl_no, Y_ac_tbl_no, DCT_WORK, wenv);
			if (ret != _JPEGD_OK)
			{
				return EXPAND_JPEGD_ERROR_DECODE;
			}
			Y_last_dc_val = DCT_WORK[0];
			R_jpeg_IDCT(DCT_WORK, Y_outptr, 0, Y_q_tbl_no, wenv);

			ret = R_jpeg_decode_one_block(Y_last_dc_val, Y_dc_tbl_no, Y_ac_tbl_no, DCT_WORK, wenv);
			if (ret != _JPEGD_OK)
			{
				return EXPAND_JPEGD_ERROR_DECODE;
			}
			Y_last_dc_val = DCT_WORK[0];
			R_jpeg_IDCT(DCT_WORK, &Y_outptr[8], 0, Y_q_tbl_no, wenv);

			ret = R_jpeg_decode_one_block(Cb_last_dc_val, Cb_dc_tbl_no, Cb_ac_tbl_no, DCT_WORK, wenv);
			if (ret != _JPEGD_OK)
			{
				return EXPAND_JPEGD_ERROR_DECODE;
			}
			Cb_last_dc_val = DCT_WORK[0];
			R_jpeg_IDCT(DCT_WORK, Cb_outptr, 0, Cb_q_tbl_no, wenv);

			ret = R_jpeg_decode_one_block(Cr_last_dc_val, Cr_dc_tbl_no, Cr_ac_tbl_no, DCT_WORK, wenv);
			if (ret != _JPEGD_OK)
			{
				return EXPAND_JPEGD_ERROR_DECODE;
			}
			Cr_last_dc_val = DCT_WORK[0];
			R_jpeg_IDCT(DCT_WORK, Cr_outptr, 0, Cr_q_tbl_no, wenv);
			ppY = Y_outptr, ppCb = Cb_outptr, ppCr = Cr_outptr;
			outpp = RGB_outptr;
            /* WAIT_LOOP */
			for (k = 0; k < block_h; ++k)
			{
				outp = *outpp++;
				ycc444_422v_rgb565(*ppY++, *ppCb, *ppCr, (uint16_t *)&outp[output_start_col], block_w);
				if (k % 2)
				{
					ppCb++;
					ppCr++;
				}
			}
			output_start_col += _JPEG_DCTSIZE;

		}
		output_start_col = 0;
		init_last_outptr(offset, RGB_outptr, RGB_outptr[_JPEG_DCTSIZE * 2]);
	}
	return EXPAND_JPEGD_OK;
}

/***********************************************************************************************************************
* Declaration       : static int16_t decode420(uint16_t *outptr, int32_t offset)
* Function Name     : decode420
* Description       : Decode processing of YCbCr 4:2:0
* Argument          : outptr - Pointer to head of output data.
*                   : offset - Number of pixels by 1 line in output area.
* Return Value      : 0=success, not 0=error
***********************************************************************************************************************/
static int16_t
decode420(uint16_t *outptr, int32_t offset)
{
	int16_t Y_dc_tbl_no, Y_ac_tbl_no, Y_q_tbl_no;
	int16_t Cb_dc_tbl_no, Cb_ac_tbl_no, Cb_q_tbl_no;
	int16_t Cr_dc_tbl_no, Cr_ac_tbl_no, Cr_q_tbl_no;
	uint8_t **ppY, **ppCb, **ppCr;
	struct _jpeg_working *wenv;
	struct _jpeg_dec_FMB *decFMB = working.decFMB;
	struct _jpeg_dec_SMB *decSMB = working.decSMB;
	struct component_info *cinfo;
	struct frame_component_info *finfo;
	int16_t lines, width, right_edge, bottom_edge;
	int16_t i, j, k;
	int16_t output_start_col;
	uint16_t *outp, **outpp;
	int32_t block_h, block_w;
	int16_t ret;

	wenv = &working;
	decFMB = wenv->decFMB;
	decSMB = wenv->decSMB;

	Y_last_dc_val = Cb_last_dc_val = Cr_last_dc_val = 0;
	finfo = & (frame_component_info(decSMB));
	cinfo = &(component_info(decSMB));

	Y_dc_tbl_no = DC_TBL(finfo, 0);
	Y_ac_tbl_no = AC_TBL(finfo, 0);
	Y_q_tbl_no = Q_TBL(finfo, cinfo, 0);
	Cb_dc_tbl_no = DC_TBL(finfo, 1);
	Cb_ac_tbl_no = AC_TBL(finfo, 1);
	Cb_q_tbl_no = Q_TBL(finfo, cinfo, 1);
	Cr_dc_tbl_no = DC_TBL(finfo, 2);
	Cr_ac_tbl_no = AC_TBL(finfo, 2);
	Cr_q_tbl_no = Q_TBL(finfo, cinfo, 2);
	output_start_col = 0;

	lines = ((_jpeg_d_number_of_lines(decSMB) + (_JPEG_DCTSIZE * 2) - 1) >> 4);
	bottom_edge = (_jpeg_d_number_of_lines(decSMB)) & 0x000F;

	width = ((_jpeg_d_line_length(decSMB) + (_JPEG_DCTSIZE * 2) - 1) >> 4);
	right_edge = (_jpeg_d_line_length(decSMB)) & 0x000F;

	_jpeg_MCU_count = _jpeg_restart_interval(decFMB);
	init_ycc4xx_outptr(2 * _JPEG_DCTSIZE, Y_outptr, Cb_outptr, Cr_outptr);

    /* WAIT_LOOP */
	for (i = 0; i < lines; ++i)
	{
		if ((i < lines - 1) || (bottom_edge == 0))
		{
			block_h = _JPEG_DCTSIZE * 2;
		}
		else
		{
			block_h = bottom_edge;
		}
        /* WAIT_LOOP */
		for (j = 0; j < width; ++j)
		{
			if ((j < width - 1) || (right_edge == 0))
			{
				block_w = _JPEG_DCTSIZE * 2;
			}
			else
			{
				block_w = right_edge;
			}
			if (_jpeg_restart_marker(wenv) < 0)
			{
				return EXPAND_JPEGD_ERROR_RST;
			}

			ret = R_jpeg_decode_one_block(Y_last_dc_val, Y_dc_tbl_no, Y_ac_tbl_no, DCT_WORK, wenv);
			if (ret != _JPEGD_OK)
			{
				return EXPAND_JPEGD_ERROR_DECODE;
			}
			Y_last_dc_val = DCT_WORK[0];
			R_jpeg_IDCT(DCT_WORK, Y_outptr, 0, Y_q_tbl_no, wenv);

			ret = R_jpeg_decode_one_block(Y_last_dc_val, Y_dc_tbl_no, Y_ac_tbl_no, DCT_WORK, wenv);
			if (ret != _JPEGD_OK)
			{
				return EXPAND_JPEGD_ERROR_DECODE;
			}
			Y_last_dc_val = DCT_WORK[0];
			R_jpeg_IDCT(DCT_WORK, Y_outptr, _JPEG_DCTSIZE, Y_q_tbl_no, wenv);

			ret = R_jpeg_decode_one_block(Y_last_dc_val, Y_dc_tbl_no, Y_ac_tbl_no, DCT_WORK, wenv);
			if (ret != _JPEGD_OK)
			{
				return EXPAND_JPEGD_ERROR_DECODE;
			}
			Y_last_dc_val = DCT_WORK[0];
			R_jpeg_IDCT(DCT_WORK, &Y_outptr[8], 0, Y_q_tbl_no, wenv);

			ret = R_jpeg_decode_one_block(Y_last_dc_val, Y_dc_tbl_no, Y_ac_tbl_no, DCT_WORK, wenv);
			if (ret != _JPEGD_OK)
			{
				return EXPAND_JPEGD_ERROR_DECODE;
			}
			Y_last_dc_val = DCT_WORK[0];
			R_jpeg_IDCT(DCT_WORK, &Y_outptr[8], _JPEG_DCTSIZE, Y_q_tbl_no, wenv);

			ret = R_jpeg_decode_one_block(Cb_last_dc_val, Cb_dc_tbl_no, Cb_ac_tbl_no, DCT_WORK, wenv);
			if (ret != _JPEGD_OK)
			{
				return EXPAND_JPEGD_ERROR_DECODE;
			}
			Cb_last_dc_val = DCT_WORK[0];
			R_jpeg_IDCT(DCT_WORK, Cb_outptr, 0, Cb_q_tbl_no, wenv);

			ret = R_jpeg_decode_one_block(Cr_last_dc_val, Cr_dc_tbl_no, Cr_ac_tbl_no, DCT_WORK, wenv);
			if (ret != _JPEGD_OK)
			{
				return EXPAND_JPEGD_ERROR_DECODE;
			}
			Cr_last_dc_val = DCT_WORK[0];
			R_jpeg_IDCT(DCT_WORK, Cr_outptr, 0, Cr_q_tbl_no, wenv);
			ppY = Y_outptr, ppCb = Cb_outptr, ppCr = Cr_outptr;
			outpp = RGB_outptr;

            /* WAIT_LOOP */
			for (k = 0; k < block_h; ++k)
			{
				outp = *outpp++;
				ycc422_420_rgb565(*ppY++, *ppCb, *ppCr, (uint16_t *)&outp[output_start_col], block_w);
				if (k % 2)
				{
					ppCb++;
					ppCr++;
				}
			}
			output_start_col += 2 * _JPEG_DCTSIZE;

		}
		output_start_col = 0;
		init_last_outptr(offset, RGB_outptr, RGB_outptr[_JPEG_DCTSIZE * 2]);
	}
	return EXPAND_JPEGD_OK;
}

/***********************************************************************************************************************
* Declaration       : static void init_ycc4xx_outptr(int16_t width, uint8_t *Y_outptr[], uint8_t *Cb_outptr[], uint8_t *Cr_outptr[])
* Function Name     : init_ycc4xx_outptr
* Description       : Initialization of the output pointer of each ingredient except YCbCr 4:4:4
* Argument          : width - Width to output.
*                   : Y_outptr[] - Pointer to storage area of Y component.
*                   : Cb_outptr[] - Pointer to storage area of Cb component.
*                   : Cr_outptr[] - Pointer to storage area of Cr component.
* Return Value      : none
***********************************************************************************************************************/
static void
init_ycc4xx_outptr(int16_t width, uint8_t *Y_outptr[], uint8_t *Cb_outptr[], uint8_t *Cr_outptr[])
{
	uint8_t *p;

	p = align.mem.Y;
	*Y_outptr++ = p;
	p += width;
	*Y_outptr++ = p;
	p += width;
	*Y_outptr++ = p;
	p += width;
	*Y_outptr++ = p;
	p += width;
	*Y_outptr++ = p;
	p += width;
	*Y_outptr++ = p;
	p += width;
	*Y_outptr++ = p;
	p += width;
	*Y_outptr++ = p;
	p += width;
	*Y_outptr++ = p;
	p += width;
	*Y_outptr++ = p;
	p += width;
	*Y_outptr++ = p;
	p += width;
	*Y_outptr++ = p;
	p += width;
	*Y_outptr++ = p;
	p += width;
	*Y_outptr++ = p;
	p += width;
	*Y_outptr++ = p;
	p += width;
	*Y_outptr   = p;

	/* 1/2 size to width */
	width /=  2;
	p = align.mem.Cb;
	*Cb_outptr++ = p;
	p += width;
	*Cb_outptr++ = p;
	p += width;
	*Cb_outptr++ = p;
	p += width;
	*Cb_outptr++ = p;
	p += width;
	*Cb_outptr++ = p;
	p += width;
	*Cb_outptr++ = p;
	p += width;
	*Cb_outptr++ = p;
	p += width;
	*Cb_outptr   = p;

	p = align.mem.Cr;
	*Cr_outptr++ = p;
	p += width;
	*Cr_outptr++ = p;
	p += width;
	*Cr_outptr++ = p;
	p += width;
	*Cr_outptr++ = p;
	p += width;
	*Cr_outptr++ = p;
	p += width;
	*Cr_outptr++ = p;
	p += width;
	*Cr_outptr++ = p;
	p += width;
	*Cr_outptr   = p;
}

/***********************************************************************************************************************
* Declaration       : static void init_ycc444_outptr(int16_t width, uint8_t *Y_outptr[], uint8_t *Cb_outptr[], uint8_t *Cr_outptr[])
* Function Name     : init_ycc444_outptr
* Description       : Initialization of the output pointer of each component of YCbCr 4:4:4
* Argument          : width - Width to output.
*                   : Y_outptr[] - Pointer to storage area of Y component.
*                   : Cb_outptr[] - Pointer to storage area of Cb component.
*                   : Cr_outptr[] - Pointer to storage area of Cr component.
* Return Value      : none
***********************************************************************************************************************/
static void
init_ycc444_outptr(int16_t width, uint8_t *Y_outptr[], uint8_t *Cb_outptr[], uint8_t *Cr_outptr[])
{
	uint8_t *p;

	p = align.mem.Y;
	*Y_outptr++ = p;
	p += width;
	*Y_outptr++ = p;
	p += width;
	*Y_outptr++ = p;
	p += width;
	*Y_outptr++ = p;
	p += width;
	*Y_outptr++ = p;
	p += width;
	*Y_outptr++ = p;
	p += width;
	*Y_outptr++ = p;
	p += width;
	*Y_outptr   = p;

	p = align.mem.Cb;
	*Cb_outptr++ = p;
	p += width;
	*Cb_outptr++ = p;
	p += width;
	*Cb_outptr++ = p;
	p += width;
	*Cb_outptr++ = p;
	p += width;
	*Cb_outptr++ = p;
	p += width;
	*Cb_outptr++ = p;
	p += width;
	*Cb_outptr++ = p;
	p += width;
	*Cb_outptr   = p;

	p = align.mem.Cr;
	*Cr_outptr++ = p;
	p += width;
	*Cr_outptr++ = p;
	p += width;
	*Cr_outptr++ = p;
	p += width;
	*Cr_outptr++ = p;
	p += width;
	*Cr_outptr++ = p;
	p += width;
	*Cr_outptr++ = p;
	p += width;
	*Cr_outptr++ = p;
	p += width;
	*Cr_outptr   = p;
}

/***********************************************************************************************************************
* Declaration       : static void init_last_outptr(int32_t offset, uint16_t **last_outptr, uint16_t *start)
* Function Name     : init_last_outptr
* Description       : Initialization of the output pointer for the last picture
* Argument          : offset - The number of bytes for one line of the image display area.
*                   : last_outptr - Pointer to the array of the last output.
*                   : start - Output start address.
* Return Value      : none
***********************************************************************************************************************/
static void
init_last_outptr(int32_t offset, uint16_t **last_outptr, uint16_t *start)
{
	uint16_t *p;

	p = start;
	*last_outptr++ = p;
	p += offset;
	*last_outptr++ = p;
	p += offset;
	*last_outptr++ = p;
	p += offset;
	*last_outptr++ = p;
	p += offset;
	*last_outptr++ = p;
	p += offset;
	*last_outptr++ = p;
	p += offset;
	*last_outptr++ = p;
	p += offset;
	*last_outptr++ = p;
	p += offset;

	*last_outptr++ = p;		/* <- next outptr for ycc444 and ycc422 */
	p += offset;
	*last_outptr++ = p;
	p += offset;
	*last_outptr++ = p;
	p += offset;
	*last_outptr++ = p;
	p += offset;
	*last_outptr++ = p;
	p += offset;
	*last_outptr++ = p;
	p += offset;
	*last_outptr++ = p;
	p += offset;
	*last_outptr++ = p;

	p += offset;
	*last_outptr   = p;		/* <- next outptr for ycc422v and ycc420 */
}

/***********************************************************************************************************************
* Declaration       : static int16_t _jpeg_restart_marker(struct _jpeg_working *wenv)
* Function Name     : _jpeg_restart_marker
* Description       : The judgement of a restart marker
* Argument          : wenv - Pointer to JPEG Decode Library environment variable structure.
* Return Value      : 0=success, not 0=error
***********************************************************************************************************************/
static int16_t
_jpeg_restart_marker(struct _jpeg_working *wenv)
{
	int16_t m;
	struct _jpeg_dec_FMB *decFMB;

	decFMB = wenv->decFMB;
	if (_jpeg_restart_interval(decFMB))
	{
		if (_jpeg_MCU_count == 0)
		{
			m = R_jpeg_readRST(wenv);
			if (m != _jpeg_next_restart_num)
			{
				/* user defined error-handling code */
				return -1;	/* as example */
			}
			_jpeg_next_restart_num = (_jpeg_next_restart_num + 1) & 7;
			/* initialize last dc values */
			Y_last_dc_val = Cb_last_dc_val = Cr_last_dc_val = 0;
			_jpeg_MCU_count = _jpeg_restart_interval(decFMB) - 1;
			return m;	/* from 0 to 7 */
		}
		else
		{
			--_jpeg_MCU_count;
			return 8;
		}
	}
	else
	{
		return 16;
	}
}

/***********************************************************************************************************************
* Declaration       : static void _jpeg_open(uint8_t *input, int32_t fsize, struct _jpeg_working *wenv)
* Function Name     : _jpeg_open
* Description       : Entry of JPEG file
* Argument          : input - Pointer to head of input data.
*                   : fsize - Size of input data.
*                   : wenv - Pointer to JPEG Decode Library environment variable structure.
* Return Value      : 0=success, not 0=error
***********************************************************************************************************************/
static void
_jpeg_open(uint8_t *input, int32_t fsize, struct _jpeg_working *wenv)
{
	struct _jpeg_dec_FMB *decFMB;
	struct _jpeg_dec_SMB *decSMB;

	decFMB = wenv->decFMB;
	decSMB = wenv->decSMB;
	
	_jpeg_d_free_in_buffer(decFMB) = fsize;
	_jpeg_next_read_byte(decFMB) = input;
	_jpeg_cur_bits_offset(decFMB) = 32;
	_jpeg_restart_interval(decFMB) = 0;

	_jpeg_d_num_QTBL(decSMB) = 0;
	_jpeg_d_frame_num_of_components(decSMB) = 0;

	STREAM_HEADER_FLAG_CLEAR(decSMB);
}
