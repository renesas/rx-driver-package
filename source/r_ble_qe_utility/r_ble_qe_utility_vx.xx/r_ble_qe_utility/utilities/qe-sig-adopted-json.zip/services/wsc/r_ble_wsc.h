/***********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
 * SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
 ***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_wsc.h
 * Version : 1.0
 * Description : This module implements Weight Scale Service Client.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 22.03.2019 1.00 First Release
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @file
 * @defgroup wsc Weight Scale Service Client
 * @{
 * @ingroup profile
 * @brief This file provides APIs to interface Weight Scale Service Client.
 **********************************************************************************************************************/

/***********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 ***********************************************************************************************************************/
#include "r_ble_rx23w_if.h"
#include "profile_cmn/r_ble_profile_cmn.h"

/***********************************************************************************************************************
 Macro definitions
 ***********************************************************************************************************************/
#ifndef R_BLE_WSC_H
#define R_BLE_WSC_H

/*******************************************************************************************************************//**
 * @brief Weight Scale Feature characteristic value length.
 ***********************************************************************************************************************/
#define BLE_WSC_WEIGHT_SCALE_FEATURE_LEN                               (4)
/*******************************************************************************************************************//**
 * @brief Weight Measurement characteristic value length.
 ***********************************************************************************************************************/
#define BLE_WSC_WEIGHT_MEASUREMENT_LEN                                 (20)

/*******************************************************************************************************************//**
 * @brief Time Stamp Supported bit.
 ***********************************************************************************************************************/
#define BLE_WSC_WEIGHT_SCALE_FEATURE_TIME_STAMP_SUPPORTED              (1 << 0)

/*******************************************************************************************************************//**
 * @brief Multiple Users Supported bit.
 ***********************************************************************************************************************/
#define BLE_WSC_WEIGHT_SCALE_FEATURE_MULTIPLE_USERS_SUPPORTED          (1 << 1)

/*******************************************************************************************************************//**
 * @brief BMI Supported bit.
 ***********************************************************************************************************************/
#define BLE_WSC_WEIGHT_SCALE_FEATURE_BMI_SUPPORTED                     (1 << 2)

/*******************************************************************************************************************//**
 * @brief Weight Measurement Resolution bits.
 ***********************************************************************************************************************/
#define BLE_WSC_WEIGHT_SCALE_FEATURE_WEIGHT_MEASUREMENT_RESOLUTION     (((1 << 4) - 1) << 3)
/*******************************************************************************************************************//**
 * @brief Height Measurement Resolution bits.
 ***********************************************************************************************************************/
#define BLE_WSC_WEIGHT_SCALE_FEATURE_HEIGHT_MEASUREMENT_RESOLUTION     (((1 << 3) - 1) << 7)
/*******************************************************************************************************************//**
 * @brief Reserved for future use bits.
 ***********************************************************************************************************************/
#define BLE_WSC_WEIGHT_SCALE_FEATURE_RESERVED_FOR_FUTURE_USE           (((1 << 22) - 1) << 10)
/*******************************************************************************************************************//**
 * @brief Measurement Units bit.
 ***********************************************************************************************************************/
#define BLE_WSC_WEIGHT_MEASUREMENT_FLAGS_MEASUREMENT_UNITS             (1 << 0)

/*******************************************************************************************************************//**
 * @brief Time stamp present bit.
 ***********************************************************************************************************************/
#define BLE_WSC_WEIGHT_MEASUREMENT_FLAGS_TIME_STAMP_PRESENT            (1 << 1)

/*******************************************************************************************************************//**
 * @brief User ID present bit.
 ***********************************************************************************************************************/
#define BLE_WSC_WEIGHT_MEASUREMENT_FLAGS_USER_ID_PRESENT               (1 << 2)

/*******************************************************************************************************************//**
 * @brief BMI and Height present bit.
 ***********************************************************************************************************************/
#define BLE_WSC_WEIGHT_MEASUREMENT_FLAGS_BMI_AND_HEIGHT_PRESENT        (1 << 3)

/***********************************************************************************************************************
 Typedef definitions
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @brief Weight Scale Service Client event data.
 ***********************************************************************************************************************/
typedef struct
{
    uint16_t conn_hdl; /**< Connection handle */
    uint16_t param_len; /**< Event parameter length */
    void     *p_param; /**< Event parameter */
} st_ble_wsc_evt_data_t;

/*******************************************************************************************************************//**
 * @brief Weight Scale Service Client event callback.
 ***********************************************************************************************************************/
typedef void (*ble_wsc_app_cb_t) (uint16_t type, ble_status_t result, st_ble_wsc_evt_data_t *p_data);

/*******************************************************************************************************************//**
 * @brief Weight Scale Service Client event type.
 ***********************************************************************************************************************/
typedef enum
{
    BLE_WSC_EVENT_WEIGHT_SCALE_FEATURE_READ_RSP, /**< Weight Scale Feature characteristic read response event */
    BLE_WSC_EVENT_WEIGHT_MEASUREMENT_HDL_VAL_IND, /**< Weight Measurement characteristic handle value indication event */
    BLE_WSC_EVENT_CLI_CNFG_WRITE_RSP, /**< Cli Cnfig write response */
    BLE_WSC_EVENT_ERROR_RSP, /**< error response */
} e_ble_wsc_event_t;

/*******************************************************************************************************************//**
 * @brief User ID enumeration.
 ***********************************************************************************************************************/
typedef enum
{
    BLE_WSC_WEIGHT_MEASUREMENT_USER_ID_UNKNOWN_USER = 255, /**< Unknown User */
} e_ble_wsc_weight_measurement_t;

/*******************************************************************************************************************//**
 * @brief Weight Scale Service attribute handles.
 ***********************************************************************************************************************/
typedef struct
{
    st_ble_gatt_hdl_range_t service_range; /**< Weight Scale Service range */
    uint16_t                weight_scale_feature_char_val_hdl; /**< Weight Scale Feature characteristic value handle */
    uint16_t                weight_measurement_char_val_hdl; /**< Weight Measurement characteristic value handle */
    uint16_t                weight_measurement_cli_cnfg_hdl; /**< Weight Measurement characteristic Client 
                                                                   Characteristic Configuration descriptor handle */
} st_ble_wsc_hdls_t;

/*******************************************************************************************************************//**
 * @brief Weight Scale Service initialization parameters.
 ***********************************************************************************************************************/
typedef struct
{
    ble_wsc_app_cb_t cb; /**< Weight Scale Service Client event handler */
} st_ble_wsc_init_param_t;

/*******************************************************************************************************************//**
 * @brief Weight Scale Service Client connection parameters.
 ***********************************************************************************************************************/
typedef struct
{
    st_ble_wsc_hdls_t *p_hdls; /**< Weight Scale Service handles */
} st_ble_wsc_connect_param_t;

/*******************************************************************************************************************//**
 * @brief Weight Scale Service disconnection parameters.
 ***********************************************************************************************************************/
typedef struct
{
    st_ble_wsc_hdls_t *p_hdls; /**< Weight Scale Service handles */
} st_ble_wsc_disconnect_param_t;

/*******************************************************************************************************************//**
 * @brief Weight Scale Feature characteristic parameters.
 ***********************************************************************************************************************/
typedef struct
{
    bool    is_timestamp_supported; /**< Time Stamp feature supported for Weight Scale or not */
    bool    is_multiple_users_supported; /**< Multiple Users feature supported for Weight Scale or not */
    bool    is_bmi_supported; /**< BMI feature supported in Weight Scale or not */
    uint8_t weight_measurement_resolution; /**< Weight Measurement Resolution */
    uint8_t height_measurement_resolution; /**< Height Measurement Resolution */
} st_ble_wsc_weight_scale_feature_t;

/*******************************************************************************************************************//**
 * @brief Weight Measurement characteristic parameters.
 ***********************************************************************************************************************/
typedef struct
{
    bool               is_measurement_in_imperial_units; /**< Weight and Mass in SI Units or Imperial Units */
    bool               is_timestamp_present; /**< Timestamp present or not */
    bool               is_user_id_present; /**< User ID present or not */
    bool               is_bmi_height_present; /**< BMI and Height present or not */
    uint16_t           weight; /**< Weight value */
    st_ble_date_time_t time_stamp; /**< Time Stamp value */
    uint8_t            user_id; /**< User ID value */
    uint16_t           bmi; /**< BMI value */
    uint16_t           height; /**< Height value */
} st_ble_wsc_weight_measurement_t;

/***********************************************************************************************************************
 Exported global variables (to be accessed by other files)
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @brief Weight Scale Service UUID.
 ***********************************************************************************************************************/
extern const uint8_t BLE_WSC_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Weight Scale Feature characteristic UUID.
 ***********************************************************************************************************************/
extern const uint8_t BLE_WSC_WEIGHT_SCALE_FEATURE_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Weight Measurement characteristic UUID.
 ***********************************************************************************************************************/
extern const uint8_t BLE_WSC_WEIGHT_MEASUREMENT_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/***********************************************************************************************************************
 Exported global functions (to be accessed by other files)
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @brief     Initialize Weight Scale Service  Client.
 * @details   This function shall be called once at startup.
 * @param[in] p_param Pointer to Weight Scale Service Client initialization parameters.
 * @return    @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_WSC_Init (const st_ble_wsc_init_param_t *p_param);

/*******************************************************************************************************************//**
 * @brief     Perform Weight Scale Service Client connection settings.
 * @details   This function shall be called on each connection establishment.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_param  Pointer to Connection parameters.
 * @return    @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_WSC_Connect (uint16_t conn_hdl, const st_ble_wsc_connect_param_t *p_param);

/*******************************************************************************************************************//**
 * @brief     Retrieve Weight Scale Service Client connection specific settings before disconnection.
 * @details   This function shall be called on each disconnection.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_param  Pointer to Disconnection parameters.
 * @return    @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_WSC_Disconnect (uint16_t conn_hdl, st_ble_wsc_disconnect_param_t *p_param);

/*******************************************************************************************************************//**
 * @brief      Read Weight Scale Feature characteristic value from remote GATT database.
 * @param[in]  conn_hdl Connection handle.
 * @return     @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_WSC_ReadWeightScaleFeature (uint16_t conn_hdl);

/*******************************************************************************************************************//**
 * @brief     Set Weight Measurement characteristic cli cnfg.
 * @param[in] conn_hdl Connection handle.
 * @param[in] cli_cnfg Weight Measurement characteristic cli cnfg to set.
 * @return    @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_WSC_SetWeightMeasurementCliCnfg (uint16_t conn_hdl, uint16_t cli_cnfg);

/*******************************************************************************************************************//**
 * @brief      Callback function for the Weight Scale Discovery events.
 * @param[in]  conn_hdl Connection handle.
 * @param[in] idx      Service index used to distiguish the multiple same UUID service.
 * @param[in] type     Discovery event type
 * @param[out] p_param  Pointer to GATTC event data.
 * @return    none
 ***********************************************************************************************************************/
void R_BLE_WSC_ServDiscCb (uint16_t conn_hdl, uint8_t idx, uint16_t type, void *p_param);

/*******************************************************************************************************************//**
 * @brief     Return version of the WSC service client.
 * @return    version
 ***********************************************************************************************************************/
uint32_t R_BLE_WSC_GetVersion (void);

#endif /* R_BLE_WSC_H */

/** @} */
