/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_rtuc.c
 * Version : 1.0
 * Description : The source file for Reference Time Update Service client.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 24.05.2019 1.00 First Release
 ***********************************************************************************************************************/
#include <string.h>
#include "r_ble_rtuc.h"
#include "profile_cmn/r_ble_servc_if.h"

static st_ble_servc_info_t gs_client_info;

/*----------------------------------------------------------------------------------------------------------------------
    Time Update Control Point Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Time Update Control Point characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_tucp_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

/* Time Update Control Point characteristic definition */
const st_ble_servc_char_info_t gs_tucp_char =
{
    .uuid_16      = BLE_RTUC_TUCP_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(uint8_t),
    .db_size      = BLE_RTUC_TUCP_LEN,
    .char_idx     = BLE_RTUC_TUCP_IDX,
    .p_attr_hdls  = gs_tucp_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_uint8_t,
    .encode       = (ble_servc_attr_encode_t)encode_uint8_t,
};

void R_BLE_RTUC_GetTucpAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_rtuc_tucp_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_tucp_char_ranges[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Time Update State Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Time Update State characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_tus_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

static ble_status_t decode_st_ble_rtuc_tus_t(st_ble_rtuc_tus_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;

    /* Check the length */
    if (BLE_RTUC_TUS_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    memset((uint8_t*)p_app_value, 0x00, sizeof(*p_app_value));

    /* Decode Presentation format fields */
    BT_UNPACK_LE_1_BYTE(&p_app_value->current_state, &p_gatt_value->p_value[pos]);
    pos += 1;

    BT_UNPACK_LE_1_BYTE(&p_app_value->result, &p_gatt_value->p_value[pos]);
    pos += 1;

    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_rtuc_tus_t(const st_ble_rtuc_tus_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    /* Encode Presentation format fields */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->current_state);
    pos += 1;

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->result);
    pos += 1;

    p_gatt_value->value_len = (uint16_t)pos;

    return BLE_SUCCESS;
}

/* Time Update State characteristic definition */
const st_ble_servc_char_info_t gs_tus_char =
{
    .uuid_16      = BLE_RTUC_TUS_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_rtuc_tus_t),
    .db_size      = BLE_RTUC_TUS_LEN,
    .char_idx     = BLE_RTUC_TUS_IDX,
    .p_attr_hdls  = gs_tus_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_rtuc_tus_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_rtuc_tus_t,
};

ble_status_t R_BLE_RTUC_ReadTus(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_tus_char, conn_hdl);
}

void R_BLE_RTUC_GetTusAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_rtuc_tus_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_tus_char_ranges[conn_idx];
}

ble_status_t R_BLE_RTUC_TimeUpdate_WriteWithoutRsp(uint16_t conn_hdl, const uint8_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteCmdChar(&gs_tucp_char, conn_hdl, p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Reference Time Update Service client
----------------------------------------------------------------------------------------------------------------------*/

/* Reference Time Update Service client attribute handles */
static st_ble_gatt_hdl_range_t gs_rtuc_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

const st_ble_servc_char_info_t *gspp_rtuc_chars[] = 
{
    &gs_tucp_char,
    &gs_tus_char,
};

static st_ble_servc_info_t gs_client_info = 
{
    .pp_chars     = gspp_rtuc_chars,
    .num_of_chars = ARRAY_SIZE(gspp_rtuc_chars),
    .p_attr_hdls  = gs_rtuc_ranges,
};

ble_status_t R_BLE_RTUC_Init(ble_servc_app_cb_t cb) // @suppress("API function naming")
{
    if (NULL == cb)
    {
        return BLE_ERR_INVALID_PTR;
    }

    gs_client_info.cb = cb;

    return R_BLE_SERVC_RegisterClient(&gs_client_info);
}

void R_BLE_RTUC_ServDiscCb(uint16_t conn_hdl, uint8_t serv_idx, uint16_t type, void *p_param) // @suppress("API function naming")
{
    R_BLE_SERVC_ServDiscCb(&gs_client_info, conn_hdl, serv_idx, type, p_param);
}

void R_BLE_RTUC_GetServAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_gatt_hdl_range_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    *p_hdl = gs_rtuc_ranges[conn_idx];
}
