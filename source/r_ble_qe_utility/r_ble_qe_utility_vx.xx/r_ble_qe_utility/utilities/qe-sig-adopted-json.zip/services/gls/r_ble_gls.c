/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_gls.c
 * Version : 1.0
 * Description : The source file for Glucose service.
 **********************************************************************************************************************/

#include <string.h>

#include "r_ble_gls.h"
#include "r_ble_gls_record.h"
#include "profile_cmn/r_ble_servs_if.h"
#include "gatt_db.h"

#ifndef UNUSED_ARG
#define UNUSED_ARG(arg)         (void)(arg)
#endif /* UNUSED_ARG */

static ble_status_t gls_notify_record(uint16_t conn_hdl, const st_ble_gls_record_t *p_record);
static ble_status_t gls_send_ra_ctrl_pt_resp(uint16_t conn_hdl, uint8_t op_code, uint8_t req_op_code, uint8_t resp_code, uint16_t param);

static st_ble_servs_info_t gs_servs_info;
static bool gs_is_racp_in_progress;
static uint8_t gs_num_of_sent;
static uint16_t gs_conn_hdl;
static uint16_t gs_index;

/*----------------------------------------------------------------------------------------------------------------------
    Glucose Measurement Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

static const st_ble_servs_desc_info_t gs_meas_cli_cnfg = {
    .attr_hdl = BLE_GLS_MEAS_CLI_CNFG_DESC_HDL,
    .app_size = sizeof(uint16_t),
    .desc_idx = BLE_GLS_MEAS_CLI_CNFG_IDX,
    .db_size  = BLE_GLS_MEAS_CLI_CNFG_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_uint16_t,
    .encode   = (ble_servs_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_GLS_SetMeasCliCnfg(uint16_t conn_hdl, const uint16_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_meas_cli_cnfg, conn_hdl, (const void *)p_value);
}

ble_status_t R_BLE_GLS_GetMeasCliCnfg(uint16_t conn_hdl, uint16_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_meas_cli_cnfg, conn_hdl, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Glucose Measurement characteristic
----------------------------------------------------------------------------------------------------------------------*/

static ble_status_t encode_st_ble_gls_meas_t(const st_ble_gls_meas_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 1;

    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    p_gatt_value->p_value[pos++] = (uint8_t)(p_app_value->sequence_number & 0xFF);
    p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->sequence_number >> 8) & 0xFF);

    p_gatt_value->p_value[pos++] = (uint8_t)(p_app_value->base_time.year & 0xFF);
    p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->base_time.year >> 8) & 0xFF);
    p_gatt_value->p_value[pos++] = p_app_value->base_time.month;
    p_gatt_value->p_value[pos++] = p_app_value->base_time.day;
    p_gatt_value->p_value[pos++] = p_app_value->base_time.hours;
    p_gatt_value->p_value[pos++] = p_app_value->base_time.minutes;
    p_gatt_value->p_value[pos++] = p_app_value->base_time.seconds;

    if (p_app_value->flags.is_time_offset_present)
    {
        p_gatt_value->p_value[0] |= 0x01;
        p_gatt_value->p_value[pos++] = (uint8_t)(p_app_value->time_offset & 0xFF);
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->time_offset >> 8) & 0xFF);
    }

    if (p_app_value->flags.is_glucose_concentration_type_and_sample_location_present)
    {
        p_gatt_value->p_value[0] |= 0x02;
        uint16_t sfloat = (uint16_t)((p_app_value->glucose_concentration.mantissa & 0x0FFF) |
                          (((uint16_t)p_app_value->glucose_concentration.exponent) << 12));
        p_gatt_value->p_value[pos++] = (uint8_t)(sfloat & 0xFF);
        p_gatt_value->p_value[pos++] = (uint8_t)((sfloat >> 8) & 0xFF);
    }

    if (p_app_value->flags.is_glucose_concentration_units_mol_per_liter)
    {
        p_gatt_value->p_value[0] |= 0x04;
    }

    if (p_app_value->flags.is_glucose_concentration_type_and_sample_location_present)
    {
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->type & 0x0F) | ((p_app_value->sample_location & 0x0F) << 4));
    }

    if (p_app_value->flags.is_sensor_status_annunciation_present)
    {
        p_gatt_value->p_value[0] |= 0x08;
        p_gatt_value->p_value[pos] = (uint8_t)((p_app_value->sensor_status_annunciation.is_device_battery_low_at_time_of_measurement ? 0x01 : 0x00)
                                   | (p_app_value->sensor_status_annunciation.is_sensor_malfunction_or_faulting_at_time_of_measurement ? 0x02 : 0x00)
                                   | (p_app_value->sensor_status_annunciation.is_sample_size_for_blood_or_control_solution_insufficient_at_time_of_measurement ? 0x04 : 0x00)
                                   | (p_app_value->sensor_status_annunciation.is_strip_insertion_error ? 0x08 : 0x00)
                                   | (p_app_value->sensor_status_annunciation.is_strip_type_incorrect_for_device ? 0x10 : 0x00)
                                   | (p_app_value->sensor_status_annunciation.is_sensor_result_higher_than_the_device_can_process ? 0x20 : 0x00)
                                   | (p_app_value->sensor_status_annunciation.is_sensor_result_lower_than_the_device_can_process ? 0x40 : 0x00)
                                   | (p_app_value->sensor_status_annunciation.is_sensor_temperature_too_high_for_valid_test_result_at_time_of_measurement ? 0x80 : 0x00));
        pos++;
        p_gatt_value->p_value[pos] = (uint8_t)((p_app_value->sensor_status_annunciation.is_sensor_temperature_too_low_for_valid_test_result_at_time_of_measurement ? 0x01 : 0x00)
                                   | (p_app_value->sensor_status_annunciation.is_sensor_read_interrupted_because_strip_was_pulled_too_soon_at_time_of_measurement ? 0x02 : 0x00)
                                   | (p_app_value->sensor_status_annunciation.is_general_device_fault_has_occurred_in_the_sensor ? 0x04 : 0x00)
                                   | (p_app_value->sensor_status_annunciation.is_time_fault_has_occurred_in_the_sensor_and_time_may_be_inaccurate ? 0x08 : 0x00));
        pos++;
    }

    if (p_app_value->flags.is_context_information_follows)
    {
        p_gatt_value->p_value[0] |= 0x10;
    }

    p_gatt_value->value_len = (uint16_t)pos;

    return BLE_SUCCESS;
}

/* Glucose Measurement characteristic descriptor definition */
static const st_ble_servs_desc_info_t *gspp_meas_descs[] = {
    &gs_meas_cli_cnfg,
};

/* Glucose Measurement characteristic definition */
static const st_ble_servs_char_info_t gs_meas_char = {
    .start_hdl    = BLE_GLS_MEAS_DECL_HDL,
    .end_hdl      = BLE_GLS_MEAS_CLI_CNFG_DESC_HDL,
    .char_idx     = BLE_GLS_MEAS_IDX,
    .app_size     = sizeof(st_ble_gls_meas_t),
    .db_size      = BLE_GLS_MEAS_LEN,
    .encode       = (ble_servs_attr_encode_t)encode_st_ble_gls_meas_t,
    .pp_descs     = gspp_meas_descs,
    .num_of_descs = ARRAY_SIZE(gspp_meas_descs),
};

ble_status_t R_BLE_GLS_NotifyMeas(uint16_t conn_hdl, const st_ble_gls_meas_t *p_value)
{
    return R_BLE_SERVS_SendHdlVal(&gs_meas_char, conn_hdl, (const void *)p_value, true);
}

/*----------------------------------------------------------------------------------------------------------------------
    Glucose Measurement Context Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

static const st_ble_servs_desc_info_t gs_meas_context_cli_cnfg = {
    .attr_hdl = BLE_GLS_MEAS_CONTEXT_CLI_CNFG_DESC_HDL,
    .app_size = sizeof(uint16_t),
    .desc_idx = BLE_GLS_MEAS_CONTEXT_CLI_CNFG_IDX,
    .db_size  = BLE_GLS_MEAS_CONTEXT_CLI_CNFG_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_uint16_t,
    .encode   = (ble_servs_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_GLS_SetMeasContextCliCnfg(uint16_t conn_hdl, const uint16_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_meas_context_cli_cnfg, conn_hdl, (const void *)p_value);
}

ble_status_t R_BLE_GLS_GetMeasContextCliCnfg(uint16_t conn_hdl, uint16_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_meas_context_cli_cnfg, conn_hdl, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Glucose Measurement Context characteristic
----------------------------------------------------------------------------------------------------------------------*/

static ble_status_t encode_st_ble_gls_meas_context_t(const st_ble_gls_meas_context_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 1;

    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    p_gatt_value->p_value[pos++] = (uint8_t)(p_app_value->sequence_number & 0xFF);
    p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->sequence_number >> 8) & 0xFF);

    if (p_app_value->flags.is_carbohydrate_id_and_carbohydrate_present)
    {
        p_gatt_value->p_value[0] |= 0x01;
        p_gatt_value->p_value[pos++] = p_app_value->carbohydrate_id;

        uint16_t sfloat = (uint16_t)((p_app_value->carbohydrate.mantissa & 0x0FFF) |
                          (((uint16_t)p_app_value->carbohydrate.exponent) << 12));
        p_gatt_value->p_value[pos++] = (uint8_t)(sfloat & 0xFF);
        p_gatt_value->p_value[pos++] = (uint8_t)((sfloat >> 8) & 0xFF);
    }

    if (p_app_value->flags.is_meal_present)
    {
        p_gatt_value->p_value[0] |= 0x02;
        p_gatt_value->p_value[pos++] = p_app_value->meal;
    }

    if (p_app_value->flags.is_tester_health_present)
    {
        p_gatt_value->p_value[0] |= 0x04;
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->tester & 0x0F) | ((p_app_value->health & 0x0F) << 4));
    }

    if (p_app_value->flags.is_exercise_duration_and_exercise_intensity_present)
    {
        p_gatt_value->p_value[0] |= 0x08;
        p_gatt_value->p_value[pos++] = (uint8_t) (p_app_value->exercise_duration & 0xFF);
        p_gatt_value->p_value[pos++] = (uint8_t) ((p_app_value->exercise_duration >> 8) & 0xFF);
        p_gatt_value->p_value[pos++] = p_app_value->exercise_intensity;
    }

    if (p_app_value->flags.is_medication_id_and_medication_present)
    {
        p_gatt_value->p_value[0] |= 0x10;
        p_gatt_value->p_value[pos++]  = p_app_value->medication_id;

        if (p_app_value->flags.is_medication_value_units_liters)
        {
            p_gatt_value->p_value[0] |= 0x20;
        }

        uint16_t sfloat = (uint16_t)((p_app_value->medication.mantissa & 0x0FFF) |
                          (((uint16_t)p_app_value->medication.exponent) << 12));
        p_gatt_value->p_value[pos++] = (uint8_t)(sfloat & 0xFF);
        p_gatt_value->p_value[pos++] = (uint8_t)((sfloat >> 8) & 0xFF);
    }

    if (p_app_value->flags.is_hba1c_present)
    {
        p_gatt_value->p_value[0] |= 0x40;
        uint16_t sfloat = (uint16_t)((p_app_value->hba1c.mantissa & 0x0FFF) |
                          (((uint16_t)p_app_value->hba1c.exponent) << 12));
        p_gatt_value->p_value[pos++] = (uint8_t)(sfloat & 0xFF);
        p_gatt_value->p_value[pos++] = (uint8_t)((sfloat >> 8) & 0xFF);
    }

    if (p_app_value->flags.is_extended_flags_present)
    {
        p_gatt_value->p_value[0] |= 0x80;
        p_gatt_value->p_value[pos++] = p_app_value->extended_flags;
    }

    p_gatt_value->value_len = (uint16_t)pos;

    return BLE_SUCCESS;
}

/* Glucose Measurement Context characteristic descriptor definition */
static const st_ble_servs_desc_info_t *gspp_meas_context_descs[] = {
    &gs_meas_context_cli_cnfg,
};

/* Glucose Measurement Context characteristic definition */
static const st_ble_servs_char_info_t gs_meas_context_char = {
    .start_hdl    = BLE_GLS_MEAS_CONTEXT_DECL_HDL,
    .end_hdl      = BLE_GLS_MEAS_CONTEXT_CLI_CNFG_DESC_HDL,
    .char_idx     = BLE_GLS_MEAS_CONTEXT_IDX,
    .app_size     = sizeof(st_ble_gls_meas_context_t),
    .db_size      = BLE_GLS_MEAS_CONTEXT_LEN,
    .encode       = (ble_servs_attr_encode_t)encode_st_ble_gls_meas_context_t,
    .pp_descs     = gspp_meas_context_descs,
    .num_of_descs = ARRAY_SIZE(gspp_meas_context_descs),
};

ble_status_t R_BLE_GLS_NotifyMeasContext(uint16_t conn_hdl, const st_ble_gls_meas_context_t *p_value)
{
    return R_BLE_SERVS_SendHdlVal(&gs_meas_context_char, conn_hdl, (const void *)p_value, true);
}

/*----------------------------------------------------------------------------------------------------------------------
    Glucose Feature characteristic
----------------------------------------------------------------------------------------------------------------------*/

static ble_status_t decode_st_ble_gls_feat_t(st_ble_gls_feat_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;

    p_app_value->is_low_battery_detection_during_measurement_supported = !!(p_gatt_value->p_value[pos] & 0x01);
    p_app_value->is_sensor_malfunction_detection_supported             = !!(p_gatt_value->p_value[pos] & 0x02);
    p_app_value->is_sensor_sample_size_supported                       = !!(p_gatt_value->p_value[pos] & 0x04);
    p_app_value->is_sensor_strip_insertion_error_detection_supported   = !!(p_gatt_value->p_value[pos] & 0x08);
    p_app_value->is_sensor_strip_type_error_detection_supported        = !!(p_gatt_value->p_value[pos] & 0x10);
    p_app_value->is_sensor_result_high_low_detection_supported         = !!(p_gatt_value->p_value[pos] & 0x20);
    p_app_value->is_sensor_temperature_high_low_detection_supported    = !!(p_gatt_value->p_value[pos] & 0x40);
    p_app_value->is_sensor_read_interrupt_detection_supported          = !!(p_gatt_value->p_value[pos] & 0x80);
    pos++;

    p_app_value->is_general_device_fault_supported = !!(p_gatt_value->p_value[pos] & 0x01);
    p_app_value->is_time_fault_supported           = !!(p_gatt_value->p_value[pos] & 0x02);
    p_app_value->is_multiple_bond_supported        = !!(p_gatt_value->p_value[pos] & 0x04);
    pos++;


    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_gls_feat_t(const st_ble_gls_feat_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;

    p_gatt_value->p_value[pos] = (uint8_t)((p_app_value->is_low_battery_detection_during_measurement_supported  ? 0x01 : 0x00)
                               | (p_app_value->is_sensor_malfunction_detection_supported              ? 0x02 : 0x00)
                               | (p_app_value->is_sensor_sample_size_supported                        ? 0x04 : 0x00)
                               | (p_app_value->is_sensor_strip_insertion_error_detection_supported    ? 0x08 : 0x00)
                               | (p_app_value->is_sensor_strip_type_error_detection_supported         ? 0x10 : 0x00)
                               | (p_app_value->is_sensor_result_high_low_detection_supported          ? 0x20 : 0x00)
                               | (p_app_value->is_sensor_temperature_high_low_detection_supported     ? 0x40 : 0x00)
                               | (p_app_value->is_sensor_read_interrupt_detection_supported           ? 0x80 : 0x00));
    pos++;

    p_gatt_value->p_value[pos] = (uint8_t)((p_app_value->is_general_device_fault_supported ? 0x01 : 0x00)
                               | (p_app_value->is_time_fault_supported           ? 0x02 : 0x00)
                               | (p_app_value->is_multiple_bond_supported        ? 0x04 : 0x00));
    pos++;

    return BLE_SUCCESS;
}

/* Glucose Feature characteristic definition */
static const st_ble_servs_char_info_t gs_feat_char = {
    .start_hdl    = BLE_GLS_FEAT_DECL_HDL,
    .end_hdl      = BLE_GLS_FEAT_VAL_HDL,
    .char_idx     = BLE_GLS_FEAT_IDX,
    .app_size     = sizeof(st_ble_gls_feat_t),
    .db_size      = BLE_GLS_FEAT_LEN,
    .decode       = (ble_servs_attr_decode_t)decode_st_ble_gls_feat_t,
    .encode       = (ble_servs_attr_encode_t)encode_st_ble_gls_feat_t,
};

ble_status_t R_BLE_GLS_SetFeat(const st_ble_gls_feat_t *p_value)
{
    return R_BLE_SERVS_SetChar(&gs_feat_char, BLE_GAP_INVALID_CONN_HDL,(const void *)p_value);
}

ble_status_t R_BLE_GLS_GetFeat(st_ble_gls_feat_t *p_value)
{
    return R_BLE_SERVS_GetChar(&gs_feat_char, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Record Access Control Point Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

static const st_ble_servs_desc_info_t gs_ra_ctrl_pt_cli_cnfg = {
    .attr_hdl = BLE_GLS_RA_CTRL_PT_CLI_CNFG_DESC_HDL,
    .app_size = sizeof(uint16_t),
    .desc_idx = BLE_GLS_RA_CTRL_PT_CLI_CNFG_IDX,
    .db_size  = BLE_GLS_RA_CTRL_PT_CLI_CNFG_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_uint16_t,
    .encode   = (ble_servs_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_GLS_SetRaCtrlPtCliCnfg(uint16_t conn_hdl, const uint16_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_ra_ctrl_pt_cli_cnfg, conn_hdl, (const void *)p_value);
}

ble_status_t R_BLE_GLS_GetRaCtrlPtCliCnfg(uint16_t conn_hdl, uint16_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_ra_ctrl_pt_cli_cnfg, conn_hdl, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Record Access Control Point characteristic
----------------------------------------------------------------------------------------------------------------------*/

static ble_status_t decode_st_ble_gls_ra_ctrl_pt_t(st_ble_gls_ra_ctrl_pt_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;
    p_app_value->op_code  = p_gatt_value->p_value[pos++];
    p_app_value->operator = p_gatt_value->p_value[pos++];
    memcpy(p_app_value->operand, &p_gatt_value->p_value[pos], (size_t)(p_gatt_value->value_len - pos));
    p_app_value->operand_len = (uint8_t)(p_gatt_value->value_len - pos);
    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_gls_ra_ctrl_pt_t(const st_ble_gls_ra_ctrl_pt_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;

    p_gatt_value->p_value[pos++] = p_app_value->op_code ;
    p_gatt_value->p_value[pos++] = p_app_value->operator;

    if (p_app_value->operand_len > 0)
    {
        memcpy(&p_gatt_value->p_value[pos], p_app_value->operand, p_app_value->operand_len);
        pos += p_app_value->operand_len;
    }

    p_gatt_value->value_len = (uint16_t)pos;

    return BLE_SUCCESS;
}

static void write_req_ra_ctrl_pt(const void *p_attr, uint16_t conn_hdl, ble_status_t result, st_ble_gls_ra_ctrl_pt_t *p_app_value)
{
    UNUSED_ARG(p_attr);
    UNUSED_ARG(result);

    if ((BLE_GLS_RA_CTRL_PT_OP_CODE_ABORT_OPERATION != p_app_value->op_code) &&
        gs_is_racp_in_progress)
    {
        R_BLE_GATTS_SendErrRsp(BLE_GLS_PROCEDURE_ALREADY_IN_PROGRESS_ERROR);
        return;
    }

    uint16_t cli_cnfg;
    R_BLE_GLS_GetRaCtrlPtCliCnfg(conn_hdl, &cli_cnfg);
    if (BLE_GATTS_CLI_CNFG_INDICATION != cli_cnfg)
    {
        R_BLE_GATTS_SendErrRsp(BLE_GLS_CLI_CNFG_IMPROPERLY_CONFIGURED_ERROR);
        return;
    }
}

static bool filter_record(st_ble_gls_record_t *p_record, st_ble_gls_ra_ctrl_pt_t *p_app_value)
{
    bool filtered = false;

    if ((BLE_GLS_RA_CTRL_PT_OPERATOR_LESS_THAN_OR_EQUAL_TO == p_app_value->operator) ||
        (BLE_GLS_RA_CTRL_PT_OPERATOR_GREATER_THAN_OR_EQUAL_TO == p_app_value->operator))
    {
        uint16_t param;
        uint8_t filter_type;

        filter_type = p_app_value->operand[0];
        BT_UNPACK_LE_2_BYTE(&param, &p_app_value->operand[1]);

        if (BLE_GLS_RA_CTRL_PT_OPERATOR_LESS_THAN_OR_EQUAL_TO == p_app_value->operator)
        {
            if (BLE_GLS_RA_CTRL_PT_FILTER_TYPE_SEQUENCE_NUMBER == filter_type)
            {
                filtered = (p_record->meas.sequence_number > param);
            }
            else if (BLE_GLS_RA_CTRL_PT_FILTER_TYPE_USER_FACING_TIME == filter_type)
            {
                st_ble_date_time_t user_facing_time;
                unpack_st_ble_date_time_t(&user_facing_time, &p_app_value->operand[1]);

                filtered = (p_record->meas.base_time.year > user_facing_time.year)       ||
                           (p_record->meas.base_time.month > user_facing_time.month)     ||
                           (p_record->meas.base_time.day > user_facing_time.day)         ||
                           (p_record->meas.base_time.minutes > user_facing_time.minutes) ||
                           (p_record->meas.base_time.seconds > user_facing_time.seconds);
            }
        }
        else /* if (BLE_GLS_RA_CTRL_PT_OPERATOR_GREATER_THAN_OR_EQUAL_TO == operator) */
        {
            if (BLE_GLS_RA_CTRL_PT_FILTER_TYPE_SEQUENCE_NUMBER == filter_type)
            {
                filtered = (p_record->meas.sequence_number < param);
            }
            else if (BLE_GLS_RA_CTRL_PT_FILTER_TYPE_USER_FACING_TIME == filter_type)
            {
                st_ble_date_time_t user_facing_time;
                unpack_st_ble_date_time_t(&user_facing_time, &p_app_value->operand[1]);

                filtered = (p_record->meas.base_time.year < user_facing_time.year)       ||
                           (p_record->meas.base_time.month < user_facing_time.month)     ||
                           (p_record->meas.base_time.day < user_facing_time.day)         ||
                           (p_record->meas.base_time.minutes < user_facing_time.minutes) ||
                           (p_record->meas.base_time.seconds < user_facing_time.seconds);
            }
        }
    }
    else if (BLE_GLS_RA_CTRL_PT_OPERATOR_WITHIN_RANGE_OF == p_app_value->operator)
    {
        uint16_t min_param;
        uint16_t max_param;
        uint8_t filter_type;

        filter_type = p_app_value->operand[0];
        BT_UNPACK_LE_2_BYTE(&min_param, &p_app_value->operand[1]);
        BT_UNPACK_LE_2_BYTE(&max_param, &p_app_value->operand[3]);

        if (BLE_GLS_RA_CTRL_PT_FILTER_TYPE_SEQUENCE_NUMBER == filter_type)
        {
            filtered = (p_record->meas.sequence_number < min_param) ||
                       (p_record->meas.sequence_number > max_param);
        }
        else if (BLE_GLS_RA_CTRL_PT_FILTER_TYPE_USER_FACING_TIME == filter_type)
        {
            st_ble_date_time_t start_user_facing_time;
            unpack_st_ble_date_time_t(&start_user_facing_time, &p_app_value->operand[1]);
            st_ble_date_time_t end_user_facing_time;
            unpack_st_ble_date_time_t(&end_user_facing_time, &p_app_value->operand[8]);

            filtered = (p_record->meas.base_time.year    < start_user_facing_time.year)    ||
                       (p_record->meas.base_time.year    > end_user_facing_time.year)      ||
                       (p_record->meas.base_time.month   < start_user_facing_time.month)   ||
                       (p_record->meas.base_time.month   > end_user_facing_time.month)     ||
                       (p_record->meas.base_time.day     < start_user_facing_time.day)     ||
                       (p_record->meas.base_time.day     > end_user_facing_time.day)       ||
                       (p_record->meas.base_time.minutes < start_user_facing_time.minutes) ||
                       (p_record->meas.base_time.minutes > end_user_facing_time.minutes)   ||
                       (p_record->meas.base_time.seconds < start_user_facing_time.seconds) ||
                       (p_record->meas.base_time.seconds > end_user_facing_time.seconds);
        }
    }

    return filtered;
}

static void gls_report_all_record(uint16_t conn_hdl, st_ble_gls_ra_ctrl_pt_t *p_app_value)
{
    do
    {
        ble_status_t ret;

        st_ble_gls_record_t *p_record;
        p_record = gls_db_get_record(gs_index);
        if (NULL == p_record)
        {
            break;
        }

        ret = gls_notify_record(conn_hdl, p_record);
        if (BLE_SUCCESS != ret)
        {
            return;
        }
        gs_num_of_sent++;
        gs_index = gls_db_get_next_index(gs_index);
    } while (gs_index != gls_db_get_oldest_index());

    gls_send_ra_ctrl_pt_resp(gs_conn_hdl,
                             BLE_GLS_RA_CTRL_PT_OP_CODE_RESPONSE_CODE,
                             p_app_value->op_code,
                             (0 == gs_num_of_sent) ? BLE_GLS_RA_CTRL_PT_OPERAND_NO_RECORDS_FOUND : BLE_GLS_RA_CTRL_PT_OPERAND_SUCCESS,
                             0);
}

static void gls_report_some_record(uint16_t conn_hdl, st_ble_gls_ra_ctrl_pt_t *p_app_value)
{
    do
    {
        st_ble_gls_record_t *p_record;
        p_record = gls_db_get_record(gs_index);
        if (NULL == p_record)
        {
            break;
        }

        bool filtered = filter_record(p_record, p_app_value);
        if (filtered)
        {
            gs_index = gls_db_get_next_index(gs_index);
            continue;
        }
            
        ble_status_t ret = gls_notify_record(conn_hdl, p_record);
        if (BLE_SUCCESS != ret)
        {
            return;
        }
        gs_num_of_sent++;
        gs_index = gls_db_get_next_index(gs_index);
    } while (gs_index != gls_db_get_oldest_index());

    gls_send_ra_ctrl_pt_resp(gs_conn_hdl,
                             BLE_GLS_RA_CTRL_PT_OP_CODE_RESPONSE_CODE,
                             p_app_value->op_code,
                             (0 == gs_num_of_sent) ? BLE_GLS_RA_CTRL_PT_OPERAND_NO_RECORDS_FOUND : BLE_GLS_RA_CTRL_PT_OPERAND_SUCCESS,
                             0);
}

static void gls_report_single_record(uint16_t conn_hdl, st_ble_gls_ra_ctrl_pt_t *p_app_value)
{
    if (BLE_GLS_RA_CTRL_PT_OPERATOR_FIRST_RECORD == p_app_value->operator)
    {
        gs_index = gls_db_get_oldest_index();
    }
    else if (BLE_GLS_RA_CTRL_PT_OPERATOR_LAST_RECORD == p_app_value->operator)
    {
        gs_index = gls_db_get_newest_index();
    }

    st_ble_gls_record_t *p_record;
    p_record = gls_db_get_record(gs_index);
    if (NULL != p_record)
    {
        gs_num_of_sent++;
        gls_notify_record(conn_hdl, p_record);
    }

    gls_send_ra_ctrl_pt_resp(conn_hdl,
                             BLE_GLS_RA_CTRL_PT_OP_CODE_RESPONSE_CODE,
                             p_app_value->op_code,
                             (0 == gs_num_of_sent) ? BLE_GLS_RA_CTRL_PT_OPERAND_NO_RECORDS_FOUND : BLE_GLS_RA_CTRL_PT_OPERAND_SUCCESS,
                             0);
}

static void gls_delete_all_record(uint16_t conn_hdl, st_ble_gls_ra_ctrl_pt_t *p_app_value)
{
    uint16_t record_idx = gls_db_get_oldest_index();
    uint8_t num_of_delete = 0;

    do
    {
        st_ble_gls_record_t *p_record;
        p_record = gls_db_get_record(record_idx);
        if (NULL == p_record)
        {
            break;
        }

        gls_db_mark_delete_record(record_idx);
        num_of_delete++;

        record_idx = gls_db_get_next_index(record_idx);
    } while (record_idx != gls_db_get_oldest_index());

    gls_db_delete_records();

    gls_send_ra_ctrl_pt_resp(conn_hdl,
                             BLE_GLS_RA_CTRL_PT_OP_CODE_RESPONSE_CODE,
                             p_app_value->op_code,
                             BLE_GLS_RA_CTRL_PT_OPERAND_SUCCESS,
                             0);
}

static void gls_delete_some_record(uint16_t conn_hdl, st_ble_gls_ra_ctrl_pt_t *p_app_value)
{
    uint16_t record_idx = gls_db_get_oldest_index();
    uint8_t num_of_delete = 0;

    do
    {
        st_ble_gls_record_t *p_record;
        p_record = gls_db_get_record(record_idx);
        if (NULL == p_record)
        {
            break;
        }

        bool filtered = filter_record(p_record, p_app_value);
        if (filtered)
        {
            record_idx = gls_db_get_next_index(record_idx);
            continue;
        }

        gls_db_mark_delete_record(record_idx);
        num_of_delete++;

        record_idx = gls_db_get_next_index(record_idx);
    } while (record_idx != gls_db_get_oldest_index());

    gls_db_delete_records();

    gls_send_ra_ctrl_pt_resp(conn_hdl,
                             BLE_GLS_RA_CTRL_PT_OP_CODE_RESPONSE_CODE,
                             p_app_value->op_code,
                             (0 == num_of_delete) ? BLE_GLS_RA_CTRL_PT_OPERAND_NO_RECORDS_FOUND : BLE_GLS_RA_CTRL_PT_OPERAND_SUCCESS,
                             0);
}

static void gls_delete_single_record(uint16_t conn_hdl, st_ble_gls_ra_ctrl_pt_t *p_app_value)
{
    uint16_t record_idx = 0;
    uint8_t num_of_delete = 0;

    if (BLE_GLS_RA_CTRL_PT_OPERATOR_FIRST_RECORD == p_app_value->operator)
    {
        record_idx = gls_db_get_oldest_index();
    }
    else if (BLE_GLS_RA_CTRL_PT_OPERATOR_LAST_RECORD == p_app_value->operator)
    {
        record_idx = gls_db_get_newest_index();
    }
    else
    {
        /* The operator is checked by the gls_process_operation(), so never reach here. */
    }

    st_ble_gls_record_t *p_record;
    p_record = gls_db_get_record(record_idx);
    if (NULL != p_record)
    {
        num_of_delete++;
    }

    gls_db_mark_delete_record(record_idx);
    gls_db_delete_records();

    gls_send_ra_ctrl_pt_resp(conn_hdl,
                             BLE_GLS_RA_CTRL_PT_OP_CODE_RESPONSE_CODE,
                             p_app_value->op_code,
                             (0 == num_of_delete) ? BLE_GLS_RA_CTRL_PT_OPERAND_NO_RECORDS_FOUND : BLE_GLS_RA_CTRL_PT_OPERAND_SUCCESS,
                             0);
}

static void gls_report_num_of_all_record(uint16_t conn_hdl, st_ble_gls_ra_ctrl_pt_t *p_app_value)
{
    uint16_t record_idx = gls_db_get_oldest_index();
    uint16_t num_of_records = 0;

    do
    {
        st_ble_gls_record_t *p_record;
        p_record = gls_db_get_record(record_idx);
        if (NULL == p_record)
        {
            break;
        }

        num_of_records++;
        record_idx = gls_db_get_next_index(record_idx);
    } while (record_idx != gls_db_get_oldest_index());

    gls_send_ra_ctrl_pt_resp(conn_hdl,
                             BLE_GLS_RA_CTRL_PT_OP_CODE_NUMBER_OF_STORED_RECORDS_RESPONSE,
                             p_app_value->op_code,
                             (0 == num_of_records) ? BLE_GLS_RA_CTRL_PT_OPERAND_NO_RECORDS_FOUND : BLE_GLS_RA_CTRL_PT_OPERAND_SUCCESS,
                             num_of_records);
}

static void gls_report_num_of_some_record(uint16_t conn_hdl, st_ble_gls_ra_ctrl_pt_t *p_app_value)
{
    uint16_t record_idx = gls_db_get_oldest_index();
    uint8_t num_of_records = 0;

    do
    {
        st_ble_gls_record_t *p_record;
        p_record = gls_db_get_record(record_idx);
        if (NULL == p_record)
        {
            break;
        }

        bool filtered = filter_record(p_record, p_app_value);
        if (filtered)
        {
            record_idx = gls_db_get_next_index(record_idx);
            continue;
        }

        num_of_records++;
        record_idx = gls_db_get_next_index(record_idx);
    } while (record_idx != gls_db_get_oldest_index());

    gls_send_ra_ctrl_pt_resp(conn_hdl,
                             BLE_GLS_RA_CTRL_PT_OP_CODE_NUMBER_OF_STORED_RECORDS_RESPONSE,
                             p_app_value->op_code,
                             (0 == num_of_records) ? BLE_GLS_RA_CTRL_PT_OPERAND_NO_RECORDS_FOUND : BLE_GLS_RA_CTRL_PT_OPERAND_SUCCESS,
                             num_of_records);
}

static void gls_report_num_of_single_record(uint16_t conn_hdl, st_ble_gls_ra_ctrl_pt_t *p_app_value)
{
    uint16_t record_idx = 0;
    uint8_t num_of_records = 0;

    if (BLE_GLS_RA_CTRL_PT_OPERATOR_FIRST_RECORD == p_app_value->operator)
    {
        record_idx = gls_db_get_oldest_index();
    }
    else if (BLE_GLS_RA_CTRL_PT_OPERATOR_LAST_RECORD == p_app_value->operator)
    {
        record_idx = gls_db_get_newest_index();
    }
    else
    {
        /* The operator is checked by the gls_process_operation(), so never reach here. */
    }

    st_ble_gls_record_t *p_record;
    p_record = gls_db_get_record(record_idx);
    if (NULL != p_record)
    {
        num_of_records++;
    }

    gls_send_ra_ctrl_pt_resp(conn_hdl,
                             BLE_GLS_RA_CTRL_PT_OP_CODE_RESPONSE_CODE,
                             p_app_value->op_code,
                             (0 == num_of_records) ? BLE_GLS_RA_CTRL_PT_OPERAND_NO_RECORDS_FOUND : BLE_GLS_RA_CTRL_PT_OPERAND_SUCCESS,
                             num_of_records);
}

static void gls_abort_operation(uint16_t conn_hdl, st_ble_gls_ra_ctrl_pt_t *p_app_value)
{
    UNUSED_ARG(p_app_value);

    gs_is_racp_in_progress = false;

    gls_send_ra_ctrl_pt_resp(conn_hdl,
                             BLE_GLS_RA_CTRL_PT_OP_CODE_RESPONSE_CODE,
                             BLE_GLS_RA_CTRL_PT_OP_CODE_ABORT_OPERATION,
                             BLE_GLS_RA_CTRL_PT_OPERAND_SUCCESS,
                             0);
}

static void gls_process_operation(uint16_t conn_hdl, st_ble_gls_ra_ctrl_pt_t *p_app_value, bool started)
{
    if (started)
    {
        gs_index = gls_db_get_oldest_index();
        gs_num_of_sent = 0;
    }

    /* Unsupported Op Code */
    if ((BLE_GLS_RA_CTRL_PT_OP_CODE_REPORT_STORED_RECORDS > p_app_value->op_code) ||
        (BLE_GLS_RA_CTRL_PT_OP_CODE_REPORT_NUMBER_OF_STORED_RECORDS < p_app_value->op_code))
    {
        gls_send_ra_ctrl_pt_resp(conn_hdl,
                                 BLE_GLS_RA_CTRL_PT_OP_CODE_RESPONSE_CODE,
                                 p_app_value->op_code,
                                 BLE_GLS_RA_CTRL_PT_OPERAND_OP_CODE_NOT_SUPPORTED,
                                 0);
        return;
    }

    /* Unsupported Operator */
    if (BLE_GLS_RA_CTRL_PT_OPERATOR_LAST_RECORD < p_app_value->operator)
    {
        gls_send_ra_ctrl_pt_resp(conn_hdl,
                                 BLE_GLS_RA_CTRL_PT_OP_CODE_RESPONSE_CODE,
                                 p_app_value->op_code,
                                 BLE_GLS_RA_CTRL_PT_OPERAND_OPERATOR_NOT_SUPPORTED,
                                 0);
        return;
    }

    /* Invalid Operand (The length of operand is invalid) */
    if (((BLE_GLS_RA_CTRL_PT_OPERATOR_ALL_RECORDS == p_app_value->operator) ||
         (BLE_GLS_RA_CTRL_PT_OPERATOR_FIRST_RECORD == p_app_value->operator) ||
         (BLE_GLS_RA_CTRL_PT_OPERATOR_LAST_RECORD == p_app_value->operator)) &&
        (0 != p_app_value->operand_len))
    {
        gls_send_ra_ctrl_pt_resp(conn_hdl,
                                 BLE_GLS_RA_CTRL_PT_OP_CODE_RESPONSE_CODE,
                                 p_app_value->op_code,
                                 BLE_GLS_RA_CTRL_PT_OPERAND_INVALID_OPERAND,
                                 0);
        return;
    }
    else if ((BLE_GLS_RA_CTRL_PT_OPERATOR_LESS_THAN_OR_EQUAL_TO == p_app_value->operator) ||
             (BLE_GLS_RA_CTRL_PT_OPERATOR_GREATER_THAN_OR_EQUAL_TO == p_app_value->operator) ||
             (BLE_GLS_RA_CTRL_PT_OPERATOR_WITHIN_RANGE_OF == p_app_value->operator))
    {
        /* Invalid Filter Type */
        if ((BLE_GLS_RA_CTRL_PT_FILTER_TYPE_SEQUENCE_NUMBER != p_app_value->operand[0]) &&
            (BLE_GLS_RA_CTRL_PT_FILTER_TYPE_USER_FACING_TIME != p_app_value->operand[0]))
        {
            gls_send_ra_ctrl_pt_resp(conn_hdl,
                                     BLE_GLS_RA_CTRL_PT_OP_CODE_RESPONSE_CODE,
                                     p_app_value->op_code,
                                     BLE_GLS_RA_CTRL_PT_OPERAND_OPERAND_NOT_SUPPORTED,
                                     0);
            return;
        }

        /* Invalid Operand (The length of operand is invalid) */
        if (((BLE_GLS_RA_CTRL_PT_OPERATOR_LESS_THAN_OR_EQUAL_TO == p_app_value->operator) ||
             (BLE_GLS_RA_CTRL_PT_OPERATOR_GREATER_THAN_OR_EQUAL_TO == p_app_value->operator)) &&
            ((3 != p_app_value->operand_len) && (8 != p_app_value->operand_len)))
        {
            gls_send_ra_ctrl_pt_resp(conn_hdl,
                                     BLE_GLS_RA_CTRL_PT_OP_CODE_RESPONSE_CODE,
                                     p_app_value->op_code,
                                     BLE_GLS_RA_CTRL_PT_OPERAND_INVALID_OPERAND,
                                     0);
        }
        else if (BLE_GLS_RA_CTRL_PT_OPERATOR_WITHIN_RANGE_OF == p_app_value->operator)
        {
            /* Invalid Operand (The length of operand is invalid) */
            if (5 != p_app_value->operand_len)
            {
                gls_send_ra_ctrl_pt_resp(conn_hdl,
                                         BLE_GLS_RA_CTRL_PT_OP_CODE_RESPONSE_CODE,
                                         p_app_value->op_code,
                                         BLE_GLS_RA_CTRL_PT_OPERAND_INVALID_OPERAND,
                                         0);
            }

            /* Invalid Operand (min is lager than max) */
            uint16_t min;
            uint16_t max;
            BT_UNPACK_LE_2_BYTE(&min, &p_app_value->operand[1]);
            BT_UNPACK_LE_2_BYTE(&max, &p_app_value->operand[3]);
            if (min > max)
            {
                gls_send_ra_ctrl_pt_resp(conn_hdl,
                                         BLE_GLS_RA_CTRL_PT_OP_CODE_RESPONSE_CODE,
                                         p_app_value->op_code,
                                         BLE_GLS_RA_CTRL_PT_OPERAND_INVALID_OPERAND,
                                         0);
            }
        }
    }

    if ((BLE_GLS_RA_CTRL_PT_OP_CODE_REPORT_STORED_RECORDS == p_app_value->op_code) &&
        (BLE_GLS_RA_CTRL_PT_OPERATOR_ALL_RECORDS == p_app_value->operator))
    {
        gls_report_all_record(conn_hdl, p_app_value);
    }
    else if ((BLE_GLS_RA_CTRL_PT_OP_CODE_REPORT_STORED_RECORDS == p_app_value->op_code) &&
             ((BLE_GLS_RA_CTRL_PT_OPERATOR_LESS_THAN_OR_EQUAL_TO == p_app_value->operator) ||
              (BLE_GLS_RA_CTRL_PT_OPERATOR_GREATER_THAN_OR_EQUAL_TO == p_app_value->operator) ||
              (BLE_GLS_RA_CTRL_PT_OPERATOR_WITHIN_RANGE_OF == p_app_value->operator)))
    {
        gls_report_some_record(conn_hdl, p_app_value);
    }
    else if ((BLE_GLS_RA_CTRL_PT_OP_CODE_REPORT_STORED_RECORDS == p_app_value->op_code) &&
             ((BLE_GLS_RA_CTRL_PT_OPERATOR_FIRST_RECORD == p_app_value->operator) ||
              (BLE_GLS_RA_CTRL_PT_OPERATOR_LAST_RECORD == p_app_value->operator)))
    {
        gls_report_single_record(conn_hdl, p_app_value);
    }
    else if ((BLE_GLS_RA_CTRL_PT_OP_CODE_DELETE_STORED_RECORDS == p_app_value->op_code) &&
             (BLE_GLS_RA_CTRL_PT_OPERATOR_ALL_RECORDS == p_app_value->operator))
    {
        gls_delete_all_record(conn_hdl, p_app_value);
    }
    else if ((BLE_GLS_RA_CTRL_PT_OP_CODE_DELETE_STORED_RECORDS == p_app_value->op_code) &&
             ((BLE_GLS_RA_CTRL_PT_OPERATOR_LESS_THAN_OR_EQUAL_TO == p_app_value->operator) ||
              (BLE_GLS_RA_CTRL_PT_OPERATOR_GREATER_THAN_OR_EQUAL_TO == p_app_value->operator) ||
              (BLE_GLS_RA_CTRL_PT_OPERATOR_WITHIN_RANGE_OF == p_app_value->operator)))
    {
        gls_delete_some_record(conn_hdl, p_app_value);
    }
    else if ((BLE_GLS_RA_CTRL_PT_OP_CODE_DELETE_STORED_RECORDS == p_app_value->op_code) &&
             ((BLE_GLS_RA_CTRL_PT_OPERATOR_FIRST_RECORD == p_app_value->operator) ||
              (BLE_GLS_RA_CTRL_PT_OPERATOR_LAST_RECORD == p_app_value->operator)))
    {
        gls_delete_single_record(conn_hdl, p_app_value);
    }
    else if ((BLE_GLS_RA_CTRL_PT_OP_CODE_REPORT_NUMBER_OF_STORED_RECORDS == p_app_value->op_code) &&
             (BLE_GLS_RA_CTRL_PT_OPERATOR_ALL_RECORDS == p_app_value->operator))
    {
        gls_report_num_of_all_record(conn_hdl, p_app_value);
    }
    else if ((BLE_GLS_RA_CTRL_PT_OP_CODE_REPORT_NUMBER_OF_STORED_RECORDS == p_app_value->op_code) &&
             ((BLE_GLS_RA_CTRL_PT_OPERATOR_LESS_THAN_OR_EQUAL_TO == p_app_value->operator) ||
              (BLE_GLS_RA_CTRL_PT_OPERATOR_GREATER_THAN_OR_EQUAL_TO == p_app_value->operator) ||
              (BLE_GLS_RA_CTRL_PT_OPERATOR_WITHIN_RANGE_OF == p_app_value->operator)))
    {
        gls_report_num_of_some_record(conn_hdl, p_app_value);
    }
    else if ((BLE_GLS_RA_CTRL_PT_OP_CODE_REPORT_NUMBER_OF_STORED_RECORDS == p_app_value->op_code) &&
             ((BLE_GLS_RA_CTRL_PT_OPERATOR_FIRST_RECORD == p_app_value->operator) ||
              (BLE_GLS_RA_CTRL_PT_OPERATOR_LAST_RECORD == p_app_value->operator)))
    {
        gls_report_num_of_single_record(conn_hdl, p_app_value);
    }
    else if (BLE_GLS_RA_CTRL_PT_OP_CODE_ABORT_OPERATION == p_app_value->op_code)
    {
        gls_abort_operation(conn_hdl, p_app_value);
    }
    else
    {
        gls_send_ra_ctrl_pt_resp(conn_hdl,
                                 BLE_GLS_RA_CTRL_PT_OP_CODE_RESPONSE_CODE,
                                 p_app_value->op_code,
                                 BLE_GLS_RA_CTRL_PT_OPERAND_INVALID_OPERATOR,
                                 0);
    }
}

static void write_comp_ra_ctrl_pt(const void *p_attr,
                                  uint16_t conn_hdl,
                                  ble_status_t result,
                                  st_ble_gls_ra_ctrl_pt_t *p_app_value)
{
    UNUSED_ARG(p_attr);
    UNUSED_ARG(result);

    gs_is_racp_in_progress = true;
    gs_conn_hdl = conn_hdl;
    gls_process_operation(conn_hdl, p_app_value, true);
}

static void flow_ctrl_ra_ctrl_pt(const void *p_attr)
{
    if (gs_is_racp_in_progress)
    {
        st_ble_servs_char_info_t *p_char_attr = (st_ble_servs_char_info_t *)p_attr;
        st_ble_gls_ra_ctrl_pt_t app_value;
        st_ble_gatt_value_t gatt_value;
        R_BLE_GATTS_GetAttr(gs_conn_hdl, (uint16_t)(p_char_attr->start_hdl+1), &gatt_value);
        decode_st_ble_gls_ra_ctrl_pt_t(&app_value, &gatt_value);
        gls_process_operation(gs_conn_hdl, &app_value, false);
    }
}

/* Record Access Control Point characteristic descriptor definition */
static const st_ble_servs_desc_info_t *gspp_ra_ctrl_pt_descs[] = {
    &gs_ra_ctrl_pt_cli_cnfg,
};

/* Record Access Control Point characteristic definition */
static const st_ble_servs_char_info_t gs_ra_ctrl_pt_char = {
    .start_hdl     = BLE_GLS_RA_CTRL_PT_DECL_HDL,
    .end_hdl       = BLE_GLS_RA_CTRL_PT_CLI_CNFG_DESC_HDL,
    .char_idx      = BLE_GLS_RA_CTRL_PT_IDX,
    .app_size      = sizeof(st_ble_gls_ra_ctrl_pt_t),
    .db_size       = BLE_GLS_RA_CTRL_PT_LEN,
    .write_req_cb  = (ble_servs_attr_write_req_t)write_req_ra_ctrl_pt,
    .write_comp_cb = (ble_servs_attr_write_comp_t)write_comp_ra_ctrl_pt,
    .flow_ctrl_cb  = (ble_servs_attr_flow_ctrl_t)flow_ctrl_ra_ctrl_pt,
    .decode        = (ble_servs_attr_decode_t)decode_st_ble_gls_ra_ctrl_pt_t,
    .encode        = (ble_servs_attr_encode_t)encode_st_ble_gls_ra_ctrl_pt_t,
    .pp_descs      = gspp_ra_ctrl_pt_descs,
    .num_of_descs  = ARRAY_SIZE(gspp_ra_ctrl_pt_descs),
};

ble_status_t R_BLE_GLS_IndicateRaCtrlPt(uint16_t conn_hdl, const st_ble_gls_ra_ctrl_pt_t *p_value)
{
    return R_BLE_SERVS_SendHdlVal(&gs_ra_ctrl_pt_char, conn_hdl, (const void *)p_value, false);
}

/*----------------------------------------------------------------------------------------------------------------------
    Glucose server
----------------------------------------------------------------------------------------------------------------------*/

/* Glucose characteristics definition */
static const st_ble_servs_char_info_t *gspp_chars[] = {
    &gs_meas_char,
    &gs_meas_context_char,
    &gs_feat_char,
    &gs_ra_ctrl_pt_char,
};

/* Glucose service definition */
static st_ble_servs_info_t gs_servs_info = {
    .pp_chars     = gspp_chars,
    .num_of_chars = ARRAY_SIZE(gspp_chars),
};

ble_status_t R_BLE_GLS_Init(ble_servs_app_cb_t cb)
{
    if (NULL == cb)
    {
        return BLE_ERR_INVALID_PTR;
    }

    gs_servs_info.cb = cb;

    gls_db_init();

    return R_BLE_SERVS_RegisterServer(&gs_servs_info);
}

ble_status_t R_BLE_GLS_AddNewRecord(const st_ble_gls_meas_t *p_meas,
                                    const st_ble_gls_meas_context_t *p_context)
{
    if (NULL == p_meas)
    {
        return BLE_ERR_INVALID_PTR;
    }

    gls_db_store_record(p_meas, p_context);

    return BLE_SUCCESS;
}

static ble_status_t gls_notify_record(uint16_t conn_hdl, const st_ble_gls_record_t *p_record)
{
    ble_status_t ret = BLE_ERR_INVALID_ARG;

    if (NULL != p_record)
    {
        ret = R_BLE_GLS_NotifyMeas(conn_hdl, &p_record->meas);

        if ((BLE_SUCCESS == ret) && (BLE_GLS_DB_MEAS_AND_CONTEXT_VALID_RECORD == p_record->valid))
        {
            ret = R_BLE_GLS_NotifyMeasContext(conn_hdl, &p_record->context);
        }
    }

    return ret;
}

static ble_status_t gls_send_ra_ctrl_pt_resp(uint16_t conn_hdl, uint8_t op_code, uint8_t req_op_code, uint8_t resp_code, uint16_t param)
{
    st_ble_gls_ra_ctrl_pt_t value = {
        .op_code  = op_code,
        .operator = BLE_GLS_RA_CTRL_PT_OPERATOR_NULL,
    };

    /*uint8_t operand[18] = { 0 };*/

    if (BLE_GLS_RA_CTRL_PT_OP_CODE_RESPONSE_CODE == op_code)
    {
        value.operand[0] = req_op_code;
        value.operand[1] = resp_code;
        value.operand_len = 2;
    }
    else
    {
        BT_PACK_LE_2_BYTE(&value.operand[0], &param);
        value.operand_len = 2;
    }

    R_BLE_GLS_IndicateRaCtrlPt(conn_hdl, &value);

    gs_is_racp_in_progress = false;

    return BLE_SUCCESS;
}
