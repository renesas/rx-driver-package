/***********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
 * SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2018 Renesas Electronics Corporation. All rights reserved.
 ***********************************************************************************************************************/

/**********************************************************************************************************************
 * File Name: r_ble_gls_record.h
 * Version : 1.0
 * Description: This file provides APIs to interface Glucose Service Record
 **********************************************************************************************************************/
/***********************************************************************************************************************
* History : DD.MM.YYYY Version Description
*         : 30.11.2018 1.00 First Release
**********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @file
 * @defgroup gls Glucose Service Server
 * @{
 * @ingroup profile
 * @brief   This file provides APIs to interface Glucose Service Records.
 **********************************************************************************************************************/

/***********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 ***********************************************************************************************************************/
#include "r_ble_gls.h"

/***********************************************************************************************************************
 Macro definitions
 ***********************************************************************************************************************/
#ifndef R_BLE_GLS_RECORD_H
#define R_BLE_GLS_RECORD_H

#define BLE_GLS_DB_MAX_NUM_OF_RECORDS (10)
#define BLE_GLS_DB_INVALID_INDEX      (0xFFFF)

typedef enum
{
    BLE_GLS_DB_INVALID_RECORD = 0,
    BLE_GLS_DB_MEAS_VALID_RECORD,
    BLE_GLS_DB_MEAS_AND_CONTEXT_VALID_RECORD,
    BLE_GLS_DB_WILL_DELETE,
} e_ble_gls_db_valid_t;

typedef struct
{
    uint8_t                   valid;
    uint16_t                  next_index;
    uint16_t                  prev_index;
    st_ble_gls_meas_t         meas;
    st_ble_gls_meas_context_t context;
} st_ble_gls_record_t;

/***********************************************************************************************************************
 * Function Name: gls_db_init
 * Description  : This function initializes the GLS record database.
 * Arguments    : none
 * Return Value : none
 **********************************************************************************************************************/
void gls_db_init(void);

/***********************************************************************************************************************
 * Function Name: gls_db_get_oldest_index
 * Description  : This function returns the oldest record index.
 * Arguments    : none
 * Return Value : oldest record index
 **********************************************************************************************************************/
uint16_t gls_db_get_oldest_index(void);

/***********************************************************************************************************************
 * Function Name: gls_db_get_newest_index
 * Description  : This function returns the newest record index.
 * Arguments    : none
 * Return Value : newest record index
 **********************************************************************************************************************/
uint16_t gls_db_get_newest_index(void);

/***********************************************************************************************************************
 * Function Name: gls_db_get_next_index
 * Description  : This function returns the next record index of the specified index.
 * Arguments    : index - record index
 * Return Value : next record index
 **********************************************************************************************************************/
uint16_t gls_db_get_next_index(uint16_t index);

/***********************************************************************************************************************
 * Function Name: gls_db_get_record
 * Description  : This function returns the record at the given index.
 * Arguments    : index - record index in the database
 * Return Value : record
 **********************************************************************************************************************/
st_ble_gls_record_t *gls_db_get_record(uint16_t index);

/***********************************************************************************************************************
 * Function Name: gls_db_store_record
 * Description  : This function adds the given record to the database.
 * Arguments    : p_meas - glucose measurement
 *                p_context     - glucose measurement context
 * Return Value : none
 **********************************************************************************************************************/
void gls_db_store_record(const st_ble_gls_meas_t *p_meas,
                         const st_ble_gls_meas_context_t *p_context);

/***********************************************************************************************************************
 * Function Name: gls_db_delete_records
 * Description  : This function delete records at the given index from the database.
 * Arguments    : index - record index to delete
 * Return Value : none
 **********************************************************************************************************************/
void gls_db_mark_delete_record(uint16_t index);

/***********************************************************************************************************************
 * Function Name: gls_db_delete_records
 * Description  : This function delete all records from the database.
 * Arguments    : index - record index to delete
 * Return Value : none
 **********************************************************************************************************************/
void gls_db_delete_records(void);

#endif /* R_BLE_GLS_RECORD_H */

/** @} */
