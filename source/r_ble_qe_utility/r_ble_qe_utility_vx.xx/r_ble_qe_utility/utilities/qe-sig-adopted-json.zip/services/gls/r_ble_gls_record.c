/***********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
 * SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2018 Renesas Electronics Corporation. All rights reserved.
 ***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_gls_record.c
 * Version : 1.0
 * Description : This module implements Glucose Service Records
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 30.11.2018 1.00 First Release
 ***********************************************************************************************************************/

/***********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 ***********************************************************************************************************************/
#include <string.h>
#include "r_ble_gls_record.h"

#include "gatt_db.h"

/***********************************************************************************************************************
 Private global variables and functions
 ***********************************************************************************************************************/
static uint16_t             gs_next_sequence_number;
static uint16_t             gs_root_index;
static uint16_t             gs_num_of_records;
static st_ble_gls_record_t  gs_records[BLE_GLS_DB_MAX_NUM_OF_RECORDS];

void gls_db_init(void)
{
    gs_root_index     = BLE_GLS_DB_INVALID_INDEX;
    gs_num_of_records = 0;

    for (uint16_t i = 0; i < BLE_GLS_DB_MAX_NUM_OF_RECORDS; i++)
    {
        gs_records[i].valid      = BLE_GLS_DB_INVALID_RECORD;
        gs_records[i].next_index = BLE_GLS_DB_INVALID_INDEX;
        gs_records[i].prev_index = BLE_GLS_DB_INVALID_INDEX;

        memset(&gs_records[i].meas, 0x00, sizeof(gs_records[i].meas));
        memset(&gs_records[i].context, 0x00, sizeof(gs_records[i].context));
    }

    gs_next_sequence_number = 0;
}

uint16_t gls_db_get_newest_index(void)
{
    st_ble_gls_record_t *p_record = gls_db_get_record(gs_root_index);
    return p_record->prev_index;
}

uint16_t gls_db_get_oldest_index(void)
{
    return gs_root_index;
}

uint16_t gls_db_get_next_index(uint16_t index)
{
    st_ble_gls_record_t *p_record = gls_db_get_record(index);
    return p_record->next_index;
}

st_ble_gls_record_t *gls_db_get_record(uint16_t index)
{
    if (BLE_GLS_DB_MAX_NUM_OF_RECORDS <= index)
    {
        return NULL;
    }

    if (BLE_GLS_DB_INVALID_RECORD == gs_records[index].valid)
    {
        return NULL;
    }

    return &gs_records[index];

}

static void gls_db_copy_record(uint16_t index, const st_ble_gls_meas_t *p_meas, const st_ble_gls_meas_context_t *p_context)
{
    memcpy(&gs_records[index].meas, p_meas, sizeof(gs_records[index].meas));
    gs_records[index].meas.sequence_number = gs_next_sequence_number;
    gs_records[index].valid = BLE_GLS_DB_MEAS_VALID_RECORD;

    if (NULL != p_context)
    {
        memcpy(&gs_records[index].context, p_context, sizeof(gs_records[index].context));
        gs_records[index].context.sequence_number = gs_next_sequence_number;
        gs_records[index].valid = BLE_GLS_DB_MEAS_AND_CONTEXT_VALID_RECORD;
    }

    gs_next_sequence_number++;
}

void gls_db_store_record(const st_ble_gls_meas_t *p_meas,
                         const st_ble_gls_meas_context_t *p_context)
{
    /* First record. */
    if (BLE_GLS_DB_INVALID_INDEX == gs_root_index)
    {
        gs_records[0].prev_index = 0;
        gs_records[0].next_index = 0;
        gls_db_copy_record(0, p_meas, p_context);
        gs_root_index = 0;
        gs_num_of_records++;
    }
    /* No space to save a new record, hence remove oldest one. */
    else if (BLE_GLS_DB_MAX_NUM_OF_RECORDS <= gs_num_of_records)
    {
        uint16_t newest_index = gls_db_get_newest_index();
        uint16_t next_index = gls_db_get_next_index(gs_root_index);

        gs_records[gs_root_index].prev_index = newest_index;
        gs_records[gs_root_index].next_index = next_index;
        gs_records[next_index].prev_index = gs_root_index;
        gls_db_copy_record(gs_root_index, p_meas, p_context);
        gs_root_index = next_index;
    }
    /* Free space exist, save the new record on it. */
    else
    {
        for (uint8_t i = 0; i < BLE_GLS_DB_MAX_NUM_OF_RECORDS; i++)
        {
            if (BLE_GLS_DB_INVALID_RECORD == gs_records[i].valid)
            {
                uint16_t newest_index = gls_db_get_newest_index();
                gs_records[i].prev_index = newest_index;
                gs_records[i].next_index = gs_root_index;
                gls_db_copy_record(i, p_meas, p_context);
                gs_records[newest_index].next_index = i;
                gs_records[gs_root_index].prev_index = i;
                gs_num_of_records++;
                break;
            }
        }
    }
}

void gls_db_mark_delete_record(uint16_t index)
{
    st_ble_gls_record_t *p_record;

    p_record = gls_db_get_record(index);

    if (NULL != p_record)
    {
        p_record->valid = BLE_GLS_DB_WILL_DELETE;
    }
}

static void gls_db_delete_record(uint16_t index)
{
    st_ble_gls_record_t *p_record;

    p_record = gls_db_get_record(index);

    if (NULL != p_record)
    {
        if (index == gls_db_get_oldest_index())
        {
            uint16_t newest_index = gls_db_get_newest_index();
            gs_records[p_record->next_index].prev_index = newest_index;
            gs_root_index = p_record->next_index;
        }
        else if (index == gls_db_get_newest_index())
        {
            gs_records[p_record->prev_index].next_index = gs_root_index;
        }
        else
        {
            gs_records[p_record->prev_index].next_index = p_record->next_index;
            gs_records[p_record->next_index].prev_index = p_record->prev_index;
        }

        p_record->valid = BLE_GLS_DB_INVALID_RECORD;
    }
}

void gls_db_delete_records(void)
{
    for (uint16_t i = 0; i < BLE_GLS_DB_MAX_NUM_OF_RECORDS; i++)
    {
        if (gs_records[i].valid == BLE_GLS_DB_WILL_DELETE)
        {
            gls_db_delete_record(i);
            gs_num_of_records--;
        }
    }

    if (0 == gs_num_of_records)
    {
        gs_root_index = BLE_GLS_DB_INVALID_INDEX;
    }
}
