/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_gls.h
 * Version : 1.0
 * Description : The header file for Glucose service.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 31.12.2999 1.00 First Release
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @file
 * @defgroup gls Glucose Service Server
 * @{
 * @ingroup profile
 * @brief   This service exposes glucose and other data from a glucose sensor for use in consumer and professional healthcare applications.
 **********************************************************************************************************************/

#include "profile_cmn/r_ble_servs_if.h"
#include "gatt_db.h"

#ifndef R_BLE_GLS_H
#define R_BLE_GLS_H

/*----------------------------------------------------------------------------------------------------------------------
    Glucose Measurement Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/***************************************************************************//**
 * @brief Glucose Measurement Type enumeration.
*******************************************************************************/
typedef enum {
    BLE_GLS_MEAS_TYPE_CAPILLARY_WHOLE_BLOOD = 1, /**< Capillary Whole blood */
    BLE_GLS_MEAS_TYPE_CAPILLARY_PLASMA = 2, /**< Capillary Plasma */
    BLE_GLS_MEAS_TYPE_VENOUS_WHOLE_BLOOD = 3, /**< Venous Whole blood */
    BLE_GLS_MEAS_TYPE_VENOUS_PLASMA = 4, /**< Venous Plasma */
    BLE_GLS_MEAS_TYPE_ARTERIAL_WHOLE_BLOOD = 5, /**< Arterial Whole blood */
    BLE_GLS_MEAS_TYPE_ARTERIAL_PLASMA = 6, /**< Arterial Plasma */
    BLE_GLS_MEAS_TYPE_UNDETERMINED_WHOLE_BLOOD = 7, /**< Undetermined Whole blood */
    BLE_GLS_MEAS_TYPE_UNDETERMINED_PLASMA = 8, /**< Undetermined Plasma */
    BLE_GLS_MEAS_TYPE_INTERSTITIAL_FLUID = 9, /**< Interstitial Fluid (ISF) */
    BLE_GLS_MEAS_TYPE_CONTROL_SOLUTION = 10, /**< Control Solution */
} e_ble_gls_meas_type_t;

/***************************************************************************//**
 * @brief Glucose Measurement Sample Location enumeration.
*******************************************************************************/
typedef enum {
    BLE_GLS_MEAS_SAMPLE_LOCATION_FINGER = 1, /**< Finger */
    BLE_GLS_MEAS_SAMPLE_LOCATION_ALTERNATE_SITE_TEST = 2, /**< Alternate Site Test */
    BLE_GLS_MEAS_SAMPLE_LOCATION_EARLOBE = 3, /**< Earlobe */
    BLE_GLS_MEAS_SAMPLE_LOCATION_CONTROL_SOLUTION = 4, /**< Control solution */
    BLE_GLS_MEAS_SAMPLE_LOCATION_SAMPLE_LOCATION_VALUE_NOT_AVAILABLE = 15, /**< Sample Location value not available */
} e_ble_gls_meas_sample_location_t;

/***************************************************************************//**
 * @brief Glucose Measurement Flags value structure.
*******************************************************************************/
typedef struct {
    bool is_time_offset_present; /**< Time Offset Present */
    bool is_glucose_concentration_type_and_sample_location_present; /**< Glucose Concentration, Type and Sample Location Present */
    bool is_glucose_concentration_units_mol_per_liter; /**< Glucose Concentration Units (mol/L) */
    bool is_sensor_status_annunciation_present; /**< Sensor Status Annunciation Present */
    bool is_context_information_follows; /**< Context Information Follows */
} st_ble_gls_meas_flags_t;

/***************************************************************************//**
 * @brief Glucose Measurement Sensor Status Annunciation value structure.
*******************************************************************************/
typedef struct {
    bool is_device_battery_low_at_time_of_measurement; /**< Device battery low at time of measurement */
    bool is_sensor_malfunction_or_faulting_at_time_of_measurement; /**< Sensor malfunction or faulting at time of measurement */
    bool is_sample_size_for_blood_or_control_solution_insufficient_at_time_of_measurement; /**< Sample size for blood or control solution insufficient at time of measurement */
    bool is_strip_insertion_error; /**< Strip insertion error */
    bool is_strip_type_incorrect_for_device; /**< Strip type incorrect for device */
    bool is_sensor_result_higher_than_the_device_can_process; /**< Sensor result higher than the device can process */
    bool is_sensor_result_lower_than_the_device_can_process; /**< Sensor result lower than the device can process */
    bool is_sensor_temperature_too_high_for_valid_test_result_at_time_of_measurement; /**< Sensor temperature too high for valid test/result at time of measurement */
    bool is_sensor_temperature_too_low_for_valid_test_result_at_time_of_measurement; /**< Sensor temperature too low for valid test/result at time of measurement */
    bool is_sensor_read_interrupted_because_strip_was_pulled_too_soon_at_time_of_measurement; /**< Sensor read interrupted because strip was pulled too soon at time of measurement */
    bool is_general_device_fault_has_occurred_in_the_sensor; /**< General device fault has occurred in the sensor */
    bool is_time_fault_has_occurred_in_the_sensor_and_time_may_be_inaccurate; /**< Time fault has occurred in the sensor and time may be inaccurate */
} st_ble_gls_meas_sensor_status_annunciation_t;

/***************************************************************************//**
 * @brief Glucose Measurement value structure.
*******************************************************************************/
typedef struct {
    st_ble_gls_meas_flags_t flags; /**< Flags */
    uint16_t sequence_number; /**< Sequence Number */
    st_ble_date_time_t base_time; /**< Base Time */
    int16_t time_offset; /**< Time Offset */
    st_ble_ieee11073_sfloat_t glucose_concentration; /**< Glucose Concentration - units is kg/L or mol/L */
    uint8_t type; /**< Type */
    uint8_t sample_location; /**< Sample Location */
    st_ble_gls_meas_sensor_status_annunciation_t sensor_status_annunciation; /**< Sensor Status Annunciation */
} st_ble_gls_meas_t;

/***************************************************************************//**
 * @brief     Set Glucose Measurement cli cnfg descriptor value to the local GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_GLS_SetMeasCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Get Glucose Measurement cli cnfg descriptor value from the local GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_GLS_GetMeasCliCnfg(uint16_t conn_hdl, uint16_t *p_value);

/*----------------------------------------------------------------------------------------------------------------------
    Glucose Measurement Context Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/***************************************************************************//**
 * @brief Glucose Measurement Context Carbohydrate ID enumeration.
*******************************************************************************/
typedef enum {
    BLE_GLS_MEAS_CONTEXT_CARBOHYDRATE_ID_BREAKFAST = 1, /**< Breakfast */
    BLE_GLS_MEAS_CONTEXT_CARBOHYDRATE_ID_LUNCH = 2, /**< Lunch */
    BLE_GLS_MEAS_CONTEXT_CARBOHYDRATE_ID_DINNER = 3, /**< Dinner */
    BLE_GLS_MEAS_CONTEXT_CARBOHYDRATE_ID_SNACK = 4, /**< Snack */
    BLE_GLS_MEAS_CONTEXT_CARBOHYDRATE_ID_DRINK = 5, /**< Drink */
    BLE_GLS_MEAS_CONTEXT_CARBOHYDRATE_ID_SUPPER = 6, /**< Supper */
    BLE_GLS_MEAS_CONTEXT_CARBOHYDRATE_ID_BRUNCH = 7, /**< Brunch */
} e_ble_gls_meas_context_carbohydrate_id_t;

/***************************************************************************//**
 * @brief Glucose Measurement Context Meal enumeration.
*******************************************************************************/
typedef enum {
    BLE_GLS_MEAS_CONTEXT_MEAL_PREPRANDIAL_BEFORE_MEAL = 1, /**< Preprandial (before meal) */
    BLE_GLS_MEAS_CONTEXT_MEAL_POSTPRANDIAL_AFTER_MEAL = 2, /**< Postprandial (after meal) */
    BLE_GLS_MEAS_CONTEXT_MEAL_FASTING = 3, /**< Fasting */
    BLE_GLS_MEAS_CONTEXT_MEAL_CASUAL = 4, /**< Casual (snacks, drinks, etc.) */
    BLE_GLS_MEAS_CONTEXT_MEAL_BEDTIME = 5, /**< Bedtime */
} e_ble_gls_meas_context_meal_t;

/***************************************************************************//**
 * @brief Glucose Measurement Context Tester enumeration.
*******************************************************************************/
typedef enum {
    BLE_GLS_MEAS_CONTEXT_TESTER_SELF = 1, /**< Self */
    BLE_GLS_MEAS_CONTEXT_TESTER_HEALTH_CARE_PROFESSIONAL = 2, /**< Health Care Professional */
    BLE_GLS_MEAS_CONTEXT_TESTER_LAB_TEST = 3, /**< Lab test */
    BLE_GLS_MEAS_CONTEXT_TESTER_TESTER_VALUE_NOT_AVAILABLE = 15, /**< Tester value not available */
} e_ble_gls_meas_context_tester_t;

/***************************************************************************//**
 * @brief Glucose Measurement Context Health enumeration.
*******************************************************************************/
typedef enum {
    BLE_GLS_MEAS_CONTEXT_HEALTH_MINOR_HEALTH_ISSUES = 1, /**< Minor health issues */
    BLE_GLS_MEAS_CONTEXT_HEALTH_MAJOR_HEALTH_ISSUES = 2, /**< Major health issues */
    BLE_GLS_MEAS_CONTEXT_HEALTH_DURING_MENSES = 3, /**< During menses */
    BLE_GLS_MEAS_CONTEXT_HEALTH_UNDER_STRESS = 4, /**< Under stress */
    BLE_GLS_MEAS_CONTEXT_HEALTH_NO_HEALTH_ISSUES = 5, /**< No health issues */
    BLE_GLS_MEAS_CONTEXT_HEALTH_HEALTH_VALUE_NOT_AVAILABLE = 15, /**< Health value not available */
} e_ble_gls_meas_context_health_t;

/***************************************************************************//**
 * @brief Glucose Measurement Context Exercise Duration enumeration.
*******************************************************************************/
typedef enum {
    BLE_GLS_MEAS_CONTEXT_EXERCISE_DURATION_OVERRUN = 65535, /**< Overrun */
} e_ble_gls_meas_context_exercise_duration_t;

/***************************************************************************//**
 * @brief Glucose Measurement Context Medication ID enumeration.
*******************************************************************************/
typedef enum {
    BLE_GLS_MEAS_CONTEXT_MEDICATION_ID_RAPID_ACTING_INSULIN = 1, /**< Rapid acting insulin */
    BLE_GLS_MEAS_CONTEXT_MEDICATION_ID_SHORT_ACTING_INSULIN = 2, /**< Short acting insulin */
    BLE_GLS_MEAS_CONTEXT_MEDICATION_ID_INTERMEDIATE_ACTING_INSULIN = 3, /**< Intermediate acting insulin */
    BLE_GLS_MEAS_CONTEXT_MEDICATION_ID_LONG_ACTING_INSULIN = 4, /**< Long acting insulin */
    BLE_GLS_MEAS_CONTEXT_MEDICATION_ID_PRE_MIXED_INSULIN = 5, /**< Pre-mixed insulin */
} e_ble_gls_meas_context_medication_id_t;

/***************************************************************************//**
 * @brief Glucose Measurement Context Flags value structure.
*******************************************************************************/
typedef struct {
    bool is_carbohydrate_id_and_carbohydrate_present; /**< Carbohydrate ID And Carbohydrate Present */
    bool is_meal_present; /**< Meal Present */
    bool is_tester_health_present; /**< Tester-Health Present */
    bool is_exercise_duration_and_exercise_intensity_present; /**< Exercise Duration And Exercise Intensity Present */
    bool is_medication_id_and_medication_present; /**< Medication ID And Medication Present */
    bool is_medication_value_units_liters; /**< Medication Value Units (liters) */
    bool is_hba1c_present; /**< HbA1c Present */
    bool is_extended_flags_present; /**< Extended Flags Present */
} st_ble_gls_meas_context_flags_t;

/***************************************************************************//**
 * @brief Glucose Measurement Context value structure.
*******************************************************************************/
typedef struct {
    st_ble_gls_meas_context_flags_t flags; /**< Flags */
    uint16_t sequence_number; /**< Sequence Number */
    uint8_t extended_flags; /**< Extended Flags */
    uint8_t carbohydrate_id; /**< Carbohydrate ID */
    st_ble_ieee11073_sfloat_t carbohydrate; /**< Carbohydrate - units of kilograms */
    uint8_t meal; /**< Meal */
    uint8_t tester; /**< Tester */
    uint8_t health; /**< Health */
    uint16_t exercise_duration; /**< Exercise Duration */
    uint8_t exercise_intensity; /**< Exercise Intensity */
    uint8_t medication_id; /**< Medication ID */
    st_ble_ieee11073_sfloat_t medication; /**< Medication - units is kilograms or liters */
    st_ble_ieee11073_sfloat_t hba1c; /**< HbA1c */
} st_ble_gls_meas_context_t;

/***************************************************************************//**
 * @brief     Set Glucose Measurement Context cli cnfg descriptor value to the local GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_GLS_SetMeasContextCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Get Glucose Measurement Context cli cnfg descriptor value from the local GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_GLS_GetMeasContextCliCnfg(uint16_t conn_hdl, uint16_t *p_value);

/*----------------------------------------------------------------------------------------------------------------------
    Glucose Feature Characteristic
----------------------------------------------------------------------------------------------------------------------*/
/***************************************************************************//**
 * @brief Glucose Feature value structure.
*******************************************************************************/
typedef struct {
    bool is_low_battery_detection_during_measurement_supported; /**< Low Battery Detection During Measurement Supported */
    bool is_sensor_malfunction_detection_supported; /**< Sensor Malfunction Detection Supported */
    bool is_sensor_sample_size_supported; /**< Sensor Sample Size Supported */
    bool is_sensor_strip_insertion_error_detection_supported; /**< Sensor Strip Insertion Error Detection Supported */
    bool is_sensor_strip_type_error_detection_supported; /**< Sensor Strip Type Error Detection Supported */
    bool is_sensor_result_high_low_detection_supported; /**< Sensor Result High-Low Detection Supported */
    bool is_sensor_temperature_high_low_detection_supported; /**< Sensor Temperature High-Low Detection Supported */
    bool is_sensor_read_interrupt_detection_supported; /**< Sensor Read Interrupt Detection Supported */
    bool is_general_device_fault_supported; /**< General Device Fault Supported */
    bool is_time_fault_supported; /**< Time Fault Supported */
    bool is_multiple_bond_supported; /**< Multiple Bond Supported */
} st_ble_gls_feat_t;

/***************************************************************************//**
 * @brief     Set Glucose Feature characteristic value to the local GATT database.
 * @param[in] p_value  Characteristic value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_GLS_SetFeat(const st_ble_gls_feat_t *p_value);


/***************************************************************************//**
 * @brief     Get Glucose Feature characteristic value from the local GATT database.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_GLS_GetFeat(st_ble_gls_feat_t *p_value);

/*----------------------------------------------------------------------------------------------------------------------
    Record Access Control Point Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/***************************************************************************//**
 * @brief Record Access Control Point Op Code enumeration.
*******************************************************************************/
typedef enum {
    BLE_GLS_RA_CTRL_PT_OP_CODE_REPORT_STORED_RECORDS = 1, /**< Report stored records (Operator: Value from Operator Table) */
    BLE_GLS_RA_CTRL_PT_OP_CODE_DELETE_STORED_RECORDS = 2, /**< Delete stored records (Operator: Value from Operator Table) */
    BLE_GLS_RA_CTRL_PT_OP_CODE_ABORT_OPERATION = 3, /**< Abort operation (Operator: Null 'value of 0x00 from Operator Table') */
    BLE_GLS_RA_CTRL_PT_OP_CODE_REPORT_NUMBER_OF_STORED_RECORDS = 4, /**< Report number of stored records (Operator: Value from Operator Table) */
    BLE_GLS_RA_CTRL_PT_OP_CODE_NUMBER_OF_STORED_RECORDS_RESPONSE = 5, /**< Number of stored records response (Operator: Null 'value of 0x00 from Operator Table') */
    BLE_GLS_RA_CTRL_PT_OP_CODE_RESPONSE_CODE = 6, /**< Response Code (Operator: Null 'value of 0x00 from Operator Table') */
} e_ble_gls_ra_ctrl_pt_op_code_t;

/***************************************************************************//**
 * @brief Record Access Control Point Operator enumeration.
*******************************************************************************/
typedef enum {
    BLE_GLS_RA_CTRL_PT_OPERATOR_NULL = 0, /**< Null */
    BLE_GLS_RA_CTRL_PT_OPERATOR_ALL_RECORDS = 1, /**< All records */
    BLE_GLS_RA_CTRL_PT_OPERATOR_LESS_THAN_OR_EQUAL_TO = 2, /**< Less than or equal to */
    BLE_GLS_RA_CTRL_PT_OPERATOR_GREATER_THAN_OR_EQUAL_TO = 3, /**< Greater than or equal to */
    BLE_GLS_RA_CTRL_PT_OPERATOR_WITHIN_RANGE_OF = 4, /**< Within range of (inclusive) */
    BLE_GLS_RA_CTRL_PT_OPERATOR_FIRST_RECORD = 5, /**< First record(i.e. oldest record) */
    BLE_GLS_RA_CTRL_PT_OPERATOR_LAST_RECORD = 6, /**< Last record (i.e. most recent record) */
} e_ble_gls_ra_ctrl_pt_operator_t;

/***************************************************************************//**
 * @brief Record Access Control Point Operand enumeration.
*******************************************************************************/
typedef enum {
    BLE_GLS_RA_CTRL_PT_OPERAND_SUCCESS = 1, /**< Normal response for successful operation */
    BLE_GLS_RA_CTRL_PT_OPERAND_OP_CODE_NOT_SUPPORTED = 2, /**< Normal response if unsupported Op Code is received */
    BLE_GLS_RA_CTRL_PT_OPERAND_INVALID_OPERATOR = 3, /**< Normal response if Operator received does not meet the requirements of the service (e.g. Null was expected) */
    BLE_GLS_RA_CTRL_PT_OPERAND_OPERATOR_NOT_SUPPORTED = 4, /**< Normal response if unsupported Operator is received */
    BLE_GLS_RA_CTRL_PT_OPERAND_INVALID_OPERAND = 5, /**< Normal response if Operand received does not meet the requirements of the service */
    BLE_GLS_RA_CTRL_PT_OPERAND_NO_RECORDS_FOUND = 6, /**< Normal response if request to report stored records or request to delete stored records resulted in no records meeting criteria. */
    BLE_GLS_RA_CTRL_PT_OPERAND_ABORT_UNSUCCESSFUL = 7, /**< Normal response if request for Abort cannot be completed */
    BLE_GLS_RA_CTRL_PT_OPERAND_PROCEDURE_NOT_COMPLETED = 8, /**< Normal response if unable to complete a procedure for any reason */
    BLE_GLS_RA_CTRL_PT_OPERAND_OPERAND_NOT_SUPPORTED = 9, /**< Normal response if unsupported Operand is received */
} e_ble_gls_ra_ctrl_pt_operand_t;

/***************************************************************************//**
 * @brief Record Access Control Point Filtrer Type enumeration.
*******************************************************************************/
typedef enum {
    BLE_GLS_RA_CTRL_PT_FILTER_TYPE_SEQUENCE_NUMBER = 1,
    BLE_GLS_RA_CTRL_PT_FILTER_TYPE_USER_FACING_TIME = 2,
} e_ble_gls_ra_ctrl_pt_filter_type_t;

/***************************************************************************//**
 * @brief Record Access Control Point value structure.
*******************************************************************************/
typedef struct {
    uint8_t op_code; /**< Op Code */
    uint8_t operator; /**< Operator */
    uint8_t operand[18]; /**< Operand */
    uint8_t operand_len;
} st_ble_gls_ra_ctrl_pt_t;

/***************************************************************************//**
 * @brief     Set Record Access Control Point cli cnfg descriptor value to the local GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_GLS_SetRaCtrlPtCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Get Record Access Control Point cli cnfg descriptor value from the local GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_GLS_GetRaCtrlPtCliCnfg(uint16_t conn_hdl, uint16_t *p_value);

/*----------------------------------------------------------------------------------------------------------------------
    Glucose Service
----------------------------------------------------------------------------------------------------------------------*/

/***************************************************************************//**
 * @brief A Record Access Control Point request cannot be serviced because a previously triggered RACP operation is still in progress
*******************************************************************************/
#define BLE_GLS_PROCEDURE_ALREADY_IN_PROGRESS_ERROR (BLE_ERR_GROUP_GATT | 0x80)

/***************************************************************************//**
 * @brief The Client Characteristic Configuration descriptor is not configured according to the requirements of the service.
*******************************************************************************/
#define BLE_GLS_CLI_CNFG_IMPROPERLY_CONFIGURED_ERROR (BLE_ERR_GROUP_GATT | 0x81)

/***************************************************************************//**
 * @brief Glucose characteristic Index.
*******************************************************************************/
typedef enum {
    BLE_GLS_MEAS_IDX,
    BLE_GLS_MEAS_CLI_CNFG_IDX,
    BLE_GLS_MEAS_CONTEXT_IDX,
    BLE_GLS_MEAS_CONTEXT_CLI_CNFG_IDX,
    BLE_GLS_FEAT_IDX,
    BLE_GLS_RA_CTRL_PT_IDX,
    BLE_GLS_RA_CTRL_PT_CLI_CNFG_IDX,
} st_ble_gls_char_idx_t;

/***************************************************************************//**
 * @brief Glucose event type.
*******************************************************************************/
typedef enum {
    /* Glucose Measurement */
    /* Glucose Measurement Context */
    /* Glucose Feature */
    BLE_GLS_EVENT_FEAT_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_GLS_FEAT_IDX, BLE_SERVS_READ_REQ),
    /* Record Access Control Point */
    BLE_GLS_EVENT_RA_CTRL_PT_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_GLS_RA_CTRL_PT_IDX, BLE_SERVS_WRITE_REQ),
    BLE_GLS_EVENT_RA_CTRL_PT_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_GLS_RA_CTRL_PT_IDX, BLE_SERVS_WRITE_COMP),
    BLE_GLS_EVENT_RA_CTRL_PT_HDL_VAL_CNF = BLE_SERVS_ATTR_EVENT(BLE_GLS_RA_CTRL_PT_IDX, BLE_SERVS_HDL_VAL_CNF),
    BLE_GLS_EVENT_RA_CTRL_PT_CLI_CNFG_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_GLS_RA_CTRL_PT_CLI_CNFG_IDX, BLE_SERVS_WRITE_REQ),
    BLE_GLS_EVENT_RA_CTRL_PT_CLI_CNFG_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_GLS_RA_CTRL_PT_CLI_CNFG_IDX, BLE_SERVS_WRITE_COMP),
} e_ble_gls_event_t;

/***************************************************************************//**
 * @brief     Initialize Glucose service.
 * @param[in] cb Service callback.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_GLS_Init(ble_servs_app_cb_t cb);

/***************************************************************************//**
 * @brief     Adds a new record to the record database.
 * @param[in] p_measurement Glucose Measurement characteristic value
 * @param[in] p_context Glucose Measurement context characteristic value
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_GLS_AddNewRecord(const st_ble_gls_meas_t *p_meas,
                                    const st_ble_gls_meas_context_t *p_context);

/***************************************************************************//**
 * @brief     Send indication of Record Access Control Point value to the remote device.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value  Characteristic value to send.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_GLS_IndicateRaCtrlPt(uint16_t conn_hdl, const st_ble_gls_ra_ctrl_pt_t *p_value);

/***************************************************************************//**
 * @brief     Send notification of Glucose Measurement value to the remote device.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value  Characteristic value to send.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_GLS_NotifyMeas(uint16_t conn_hdl, const st_ble_gls_meas_t *p_value);

/***************************************************************************//**
 * @brief     Send notification of Glucose Measurement Context value to the remote device.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value  Characteristic value to send.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_GLS_NotifyMeasContext(uint16_t conn_hdl, const st_ble_gls_meas_context_t *p_value);

#endif /* R_BLE_GLS_H */

/** @} */
