/**************************************************************************gs_rcs_is_rccp_in_progress*********************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
 * SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
 ***********************************************************************************************************************/
 /***********************************************************************************************************************
  * File Name: r_ble_rcs.c
  * Version : 1.0
  * Description : The source file for Reconnection Configuration service.
  **********************************************************************************************************************/
#include <string.h>
#include "r_ble_rcs.h"
#include "profile_cmn/r_ble_servs_if.h"
#include "gatt_db.h"

#ifndef UNUSED_ARG
#define UNUSED_ARG(arg)         (void)(arg)
#endif /* UNUSED_ARG */
#ifndef UNUSED_RET
#define UNUSED_RET(ret)         (void)(ret)
#endif /* UNUSED_RET */

/*******************************************************************************************************************//**
 * RC Features Field - RC Features Fields Bits Defination.
 ***********************************************************************************************************************/
#define BLE_RCS_PRV_RC_FEATURES_FIELD_E2ECRC_SUPPORTED (1 << 0)
#define BLE_RCS_PRV_RC_FEATURES_FIELD_ENABLE_DISCONNECT_SUPPORTED (1 << 1)
#define BLE_RCS_PRV_RC_FEATURES_FIELD_READY_FOR_DISCONNECT_SUPPORTED (1 << 2)
#define BLE_RCS_PRV_RC_FEATURES_FIELD_PROPOSE_RECONNECTION_TIMEOUT_SUPPORTED (1 << 3)
#define BLE_RCS_PRV_RC_FEATURES_FIELD_PROPOSE_CONNECTION_INTERVAL_SUPPORTED (1 << 4)
#define BLE_RCS_PRV_RC_FEATURES_FIELD_PROPOSE_SLAVE_LATENCY_SUPPORTED (1 << 5)
#define BLE_RCS_PRV_RC_FEATURES_FIELD_PROPOSE_SUPERVISION_TIMEOUT_SUPPORTED	(1 << 6)
#define BLE_RCS_PRV_RC_FEATURES_FIELD_PROPOSE_ADVERTISEMENT_INTERVAL_SUPPORTED (1 << 7)
#define BLE_RCS_PRV_RC_FEATURES_FIELD_PROPOSE_ADVERTISEMENT_COUNT_SUPPORTED	(1 << 8)
#define BLE_RCS_PRV_RC_FEATURES_FIELD_PROPOSE_ADVERTISEMENT_REPETETION_TIME_SUPPORTED (1 << 9)
#define BLE_RCS_PRV_RC_FEATURES_FIELD_ADVERTISEMENT_CONFIGURATION_1_SUPPORTED (1 << 10)
#define BLE_RCS_PRV_RC_FEATURES_FIELD_ADVERTISEMENT_CONFIGURATION_2_SUPPORTED (1 << 11)
#define BLE_RCS_PRV_RC_FEATURES_FIELD_ADVERTISEMENT_CONFIGURATION_3_SUPPORTED (1 << 12)
#define BLE_RCS_PRV_RC_FEATURES_FIELD_ADVERTISEMENT_CONFIGURATION_4_SUPPORTED (1 << 13)
#define BLE_RCS_PRV_RC_FEATURES_FIELD_UPGRADE_TO_LESC_ONLY_SUPPORTED (1 << 14)
#define BLE_RCS_PRV_RC_FEATURES_FIELD_NEXT_PAIRING_OOB_SUPPORTED (1 << 15)
#define BLE_RCS_PRV_RC_FEATURES_FIELD_USE_OF_WHITE_LIST_SUPPORTED (1 << 16)
#define BLE_RCS_PRV_RC_FEATURES_FIELD_LIMITED_ACCESS_SUPPORTED (1 << 17)
#define BLE_RCS_PRV_RC_FEATURES_FIELD_FEATURE_EXTENSION (1 << 23)

/*******************************************************************************************************************//**
* RC Settings Field - RC Settings Fields Bits Definition.
***********************************************************************************************************************/
#define BLE_RCS_PRV_RC_SETTINGS_FIELD_RFU (1 << 0)
#define BLE_RCS_PRV_RC_SETTINGS_FIELD_LESC_ONLY (1 << 1)
#define BLE_RCS_PRV_RC_SETTINGS_FIELD_USE_OOB_PAIRING (1 << 2)
#define BLE_RCS_PRV_RC_SETTINGS_FIELD_READY_FOR_DISCONNECT (1 << 4)
#define BLE_RCS_PRV_RC_SETTINGS_FIELD_LIMITED_ACCESS (1 << 5)
#define BLE_RCS_PRV_RC_SETTINGS_FIELD_ACCESS_PERMITTED (1 << 6)
#define BLE_RCS_PRV_RC_SETTINGS_FIELD_ADVT_MODE_0 (1 << 8)
#define BLE_RCS_PRV_RC_SETTINGS_FIELD_ADVT_MODE_1 (1 << 9)

/***************************************************************************//**
* @brief The Client Characteristic Configuration descriptor is not configured according to the requirements of the service.
*******************************************************************************/
#define BLE_RCS_CLI_CNFG_IMPROPERLY_CONFIGURED_ERROR (BLE_ERR_GROUP_GATT | 0xFD)

/***************************************************************************//**
* @brief Typedefs
*******************************************************************************/

uint8_t g_advt_config;
e_ble_rcs_cleint_param_indctn_t gs_ind_data = { 0 };

static st_ble_servs_info_t gs_servs_info;
static bool gs_error_response = 0;
static bool gs_stored_param_set = 0;

static ble_status_t stored_settings(uint16_t conn_hdl, st_ble_rcs_rccp_t *p_app_value);
static ble_status_t set_advt_config(uint16_t conn_hdl, st_ble_rcs_rccp_t *p_app_value);
static void rccp_process_operation(uint16_t conn_hdl, st_ble_rcs_rccp_t *p_app_value);
static void client_param_indcatn(uint16_t conn_hdl, st_ble_rcs_rccp_t *p_app_value);
static ble_status_t check_setting_ranges(uint16_t conn_hdl, st_ble_rcs_rccp_t *p_app_value);
static ble_status_t white_list_timer(uint16_t conn_hdl, st_ble_rcs_rccp_t *p_app_value);
static void write_comp_rc_ctrl_pt(const void *p_attr, uint16_t conn_hdl, ble_status_t result,
    st_ble_rcs_rccp_t *p_app_value);
static void write_req_rc_ctrl_pt(const void *p_attr, uint16_t conn_hdl, ble_status_t result,
    st_ble_rcs_rccp_t *p_app_value);
static void flow_ctrl_rc_ctrl_pt(const void *p_attr);
static ble_status_t decode_st_ble_rcs_rccp_t(st_ble_rcs_rccp_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value);
static ble_status_t encode_st_ble_rcs_rccp_t(const st_ble_rcs_rccp_t *p_app_value, st_ble_gatt_value_t *p_gatt_value);

static bool gs_e2ecrc_supported = false;
static bool gs_is_rccp_in_progress;
static bool gs_crc_error = false;
static uint16_t gs_conn_hdl;
static uint8_t gs_recon_timer = 0;


/***********************************************************************************************************************
 * Function Name: e2e_crc_calculation
 * Description  : to calculate e2e crc.
 * Arguments    : message - message data.
 *                length - message length
 * Return Value : uint16_t
 **********************************************************************************************************************/
static uint16_t e2e_crc_calculation(uint8_t *message, uint16_t length)
{
    uint32_t i = 0;
    uint8_t data = 0;
    uint8_t msb;
    uint16_t crc_result;
    uint8_t crc_calc[2] = { 0xff, 0xff };

    while (length--)
    {
        data = *message++;
        for (i = 0; i < 8; i++, data >>= 1)
        {
            msb = crc_calc[0] >> 7;
            crc_calc[0] = (uint8_t)(crc_calc[0] << 1);

            if (crc_calc[1] & 0x80)
            {
                crc_calc[0] |= 1;
            }
            crc_calc[1] = (uint8_t)(crc_calc[1] << 1);

            if (msb != (data & 1))
            {
                crc_calc[1] ^= 0x21;
                crc_calc[0] ^= 0x10;
            }
        }
    }

    crc_result = (uint16_t)(((((crc_calc[1] & 0x01) << 7) |
        ((crc_calc[1] & 0x02) << 5) |
        ((crc_calc[1] & 0x04) << 3) |
        ((crc_calc[1] & 0x08) << 1) |
        ((crc_calc[1] & 0x10) >> 1) |
        ((crc_calc[1] & 0x20) >> 3) |
        ((crc_calc[1] & 0x40) >> 5) |
        ((crc_calc[1] & 0x80) >> 7)) << 8) |
        (((crc_calc[0] & 0x01) << 7) |
        ((crc_calc[0] & 0x02) << 5) |
            ((crc_calc[0] & 0x04) << 3) |
            ((crc_calc[0] & 0x08) << 1) |
            ((crc_calc[0] & 0x10) >> 1) |
            ((crc_calc[0] & 0x20) >> 3) |
            ((crc_calc[0] & 0x40) >> 5) |
            ((crc_calc[0] & 0x80) >> 7)));
            
    return (crc_result & 0xffff);
}

/***********************************************************************************************************************
 * Function Name: e2e_crc_check
 * Description  : to check crc.
 * Arguments    : message - message data.
 *                length - message length
 *                rec_crc - received crc value
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t e2e_crc_check(uint8_t *message, uint8_t length, uint16_t rec_crc)
{
    ble_status_t ret;
    uint16_t crc = e2e_crc_calculation(message, length);

    if (rec_crc == crc)
    {
        ret = BLE_SUCCESS;
    }
    else
    {
        ret = BLE_RCS_INVALID_CRC_ERROR;
    }
  
    return ret;
}

/***********************************************************************************************************************
 * Function Name: pack_e2e_crc
 * Description  : pack e2e crc for sending
 * Arguments    : input - pointer to uint16_t e2e data.
 *                output - uint8_t data of e2e data
 * Return Value : ble_status_t
 **********************************************************************************************************************/
#if 0 /* unused function */
static ble_status_t pack_e2e_crc(uint16_t input, uint8_t *output)
{
    ble_status_t ret = BLE_SUCCESS;

    output[1] = ((((input & 0xff00) >> 8) & 0x01) << 7) |
        ((((input & 0xff00) >> 8) & 0x02) << 5) |
        ((((input & 0xff00) >> 8) & 0x04) << 3) |
        ((((input & 0xff00) >> 8) & 0x08) << 1) |
        ((((input & 0xff00) >> 8) & 0x10) >> 1) |
        ((((input & 0xff00) >> 8) & 0x20) >> 3) |
        ((((input & 0xff00) >> 8) & 0x40) >> 5) |
        ((((input & 0xff00) >> 8) & 0x80) >> 7);
    
    output[0] = (((input & 0xff) & 0x01) << 7) |
        (((input & 0xff) & 0x02) << 5) |
        (((input & 0xff) & 0x04) << 3) |
        (((input & 0xff) & 0x08) << 1) |
        (((input & 0xff) & 0x10) >> 1) |
        (((input & 0xff) & 0x20) >> 3) |
        (((input & 0xff) & 0x40) >> 5) |
        (((input & 0xff) & 0x80) >> 7);

    return ret;
}
#endif /* unused function */

/*----------------------------------------------------------------------------------------------------------------------
 RC Feature characteristic
 ----------------------------------------------------------------------------------------------------------------------*/
 /***********************************************************************************************************************//**
  * Function Name: decode_st_ble_rcs_feat_t
  * Description  : This function converts RC Features characteristic value representation in
  *                GATT (uint8_t[]) to representation in application layer (struct).
  * Arguments    : p_app_value - pointer to the RC Features value in the application layer
  *                p_gatt_value - pointer to the characteristic value in the GATT database
  * Return Value : ble_status_t
  **********************************************************************************************************************/
static ble_status_t decode_st_ble_rcs_feat_t(st_ble_rcs_feat_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;
    ble_status_t crc_ok;
    uint32_t feature_byte = 0;
    uint16_t rec_crc = 0;
    /*uint16_t crc_default = 0xFFFF;*/

    if (BLE_RCS_FEAT_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    memset((uint8_t *)p_app_value, 0x00, sizeof(*p_app_value));
    pos = 0;
    BT_UNPACK_LE_2_BYTE(&p_app_value->e2e_crc, &p_gatt_value->p_value[pos]);
    pos = 2;
    for (uint8_t i = 0; i < 3; i++)
    {
        p_app_value->feature_bytes[i] = p_gatt_value->p_value[pos];
        pos += 1;
    }

    /*Check crc and report*/
    rec_crc = p_app_value->e2e_crc;
    crc_ok = e2e_crc_check(&p_gatt_value->p_value[2], (uint8_t)(p_gatt_value->value_len - 2), rec_crc);
    pos += 2;
    BT_UNPACK_LE_3_BYTE(&feature_byte, &p_gatt_value->p_value[pos]);
    /* unused variable */
    (void)feature_byte;

    if (0xFFFF != rec_crc)
    {
        if (BLE_SUCCESS != crc_ok)
        {
            return BLE_RCS_INVALID_CRC_ERROR;
        }
    }

    return BLE_SUCCESS;
}

/***********************************************************************************************************************//**
 * Function Name: encode_rcs_features
 * Description  : This function converts rc features characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the Record Access Control Point  value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_rcs_feat_t(const st_ble_rcs_feat_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    /* app data to byte sequence. */
    uint32_t pos = 0;
    uint8_t crc_present = 0;
    /*uint16_t e2e_crc = 0xFFFF;*/

    memset(&p_gatt_value->p_value[0], 0x00, p_gatt_value->value_len);

    /*check crc presence*/
    crc_present = p_app_value->feature_bytes[0];
    if ((crc_present & BLE_RCS_PRV_RC_FEATURES_FIELD_E2ECRC_SUPPORTED) == 1)
    {
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos],&p_app_value->e2e_crc);
        pos = +2;
        p_gatt_value->p_value[pos++] = p_app_value->feature_bytes[0];
        p_gatt_value->p_value[pos++] = p_app_value->feature_bytes[1];
        p_gatt_value->p_value[pos++] = p_app_value->feature_bytes[2];
    }
    else
    {
        p_gatt_value->p_value[pos++] = p_app_value->feature_bytes[0];
        p_gatt_value->p_value[pos++] = p_app_value->feature_bytes[1];
        p_gatt_value->p_value[pos++] = p_app_value->feature_bytes[2];
    }

    p_gatt_value->value_len = (uint16_t)pos;

    return BLE_SUCCESS;
}

/* RC Feature characteristic definition */
static const st_ble_servs_char_info_t gs_feat_char = {
    .start_hdl = BLE_RCS_FEAT_DECL_HDL,
    .end_hdl = BLE_RCS_FEAT_VAL_HDL,
    .char_idx = BLE_RCS_FEAT_IDX,
    .app_size = sizeof(st_ble_rcs_feat_t),
    .db_size = BLE_RCS_FEAT_LEN,
    .decode = (ble_servs_attr_decode_t)decode_st_ble_rcs_feat_t,
    .encode = (ble_servs_attr_encode_t)encode_st_ble_rcs_feat_t,
};

ble_status_t R_BLE_RCS_SetFeat(const st_ble_rcs_feat_t *p_value)
{
    return R_BLE_SERVS_SetChar(&gs_feat_char, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_RCS_GetFeat(st_ble_rcs_feat_t *p_value)
{
    return R_BLE_SERVS_GetChar(&gs_feat_char, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    RC Settings Client Characteristic Configuration descriptor
 ----------------------------------------------------------------------------------------------------------------------*/

static const st_ble_servs_desc_info_t gs_setting_cli_cnfg = {
    .attr_hdl = BLE_RCS_SETTING_CLI_CNFG_DESC_HDL,
    .app_size = sizeof(uint16_t),
    .desc_idx = BLE_RCS_SETTING_CLI_CNFG_IDX,
    .db_size = BLE_RCS_SETTING_CLI_CNFG_LEN,
    .decode = (ble_servs_attr_decode_t)decode_uint16_t,
    .encode = (ble_servs_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_RCS_SetSettingCliCnfg(uint16_t conn_hdl, const uint16_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_setting_cli_cnfg, conn_hdl, (const void *)p_value);
}

ble_status_t R_BLE_RCS_GetSettingCliCnfg(uint16_t conn_hdl, uint16_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_setting_cli_cnfg, conn_hdl, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    RC Settings characteristic
 ----------------------------------------------------------------------------------------------------------------------*/
 /***********************************************************************************************************************//**
  * Function Name: decode_rcs_setting_t
  * Description  : This function converts RC Settings characteristic value representation in
  *                GATT (uint8_t[]) to representation in application layer (struct).
  * Arguments    : p_app_value - pointer to the RC Features value in the application layer
  *                p_gatt_value - pointer to the characteristic value in the GATT database
  * Return Value : ble_status_t
  **********************************************************************************************************************/
static ble_status_t decode_st_ble_rcs_setting_t(st_ble_rcs_setting_t *p_app_value,
    const st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;
    /*uint8_t settings_byte = 0;*/
    /*uint16_t e2e_crc = 0xFFFF;*/
    uint16_t rec_crc = 0;
    uint16_t check_crc = 0;
    
    if (BLE_RCS_SETTING_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    memset((uint8_t *)p_app_value, 0x00, sizeof(st_ble_rcs_setting_t));
    
    p_app_value->length = p_gatt_value->p_value[pos++];
    BT_UNPACK_LE_2_BYTE(&p_app_value->setting_bytes[0], &p_gatt_value->p_value[pos]);
    pos += 2;
    
    if (p_app_value->length > 3)
    {
        BT_UNPACK_LE_2_BYTE(&rec_crc, &p_gatt_value->p_value[pos]);
        check_crc = e2e_crc_check(&p_gatt_value->p_value[0], (uint8_t)(p_gatt_value->value_len - 2), rec_crc);
        if (BLE_SUCCESS == check_crc)
        {
            BT_UNPACK_LE_2_BYTE(&p_app_value->e2e_crc, &p_gatt_value->p_value[pos]);
            pos += 2;
        }
        else
        {
            pos += 2;
            return BLE_RCS_INVALID_CRC_ERROR;
        }
    }
  
    return BLE_SUCCESS;
}

/***********************************************************************************************************************//**
 * Function Name: encode_rcs_setting_t
 * Description  : This function converts RC Settings characteristic value representation in
 *                application layer (struct) to representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the RC settings value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_rcs_setting_t(const st_ble_rcs_setting_t *p_app_value,
    st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;
    /*uint16_t rcs_setting = 0;*/
    uint16_t e2e_crc = 0xFFFF;

    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    /*Copy the bytes*/
    p_gatt_value->p_value[pos++] = p_app_value->length;
    p_gatt_value->p_value[pos++] = p_app_value->setting_bytes[0];
    p_gatt_value->p_value[pos++] = p_app_value->setting_bytes[1];

    if (pos < p_app_value->length)
    {
        e2e_crc = e2e_crc_calculation(&p_gatt_value->p_value[0], 3);
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &e2e_crc);
        pos += 2;
    }

    p_gatt_value->value_len = (uint16_t)pos;
    
    return BLE_SUCCESS;
}

/* RC Settings characteristic descriptor definition */
static const st_ble_servs_desc_info_t *gspp_setting_descs[] =
{ &gs_setting_cli_cnfg, };

/* RC Settings characteristic definition */
static const st_ble_servs_char_info_t gs_setting_char = {
    .start_hdl = BLE_RCS_SETTING_DECL_HDL,
    .end_hdl = BLE_RCS_SETTING_CLI_CNFG_DESC_HDL,
    .char_idx = BLE_RCS_SETTING_IDX,
    .app_size = sizeof(st_ble_rcs_setting_t),
    .db_size = BLE_RCS_SETTING_LEN,
    .decode = (ble_servs_attr_decode_t)decode_st_ble_rcs_setting_t,
    .encode = (ble_servs_attr_encode_t)encode_st_ble_rcs_setting_t,
    .pp_descs = gspp_setting_descs,
    .num_of_descs = ARRAY_SIZE(gspp_setting_descs),
};

ble_status_t R_BLE_RCS_SetSetting(const st_ble_rcs_setting_t *p_value)
{
    return R_BLE_SERVS_SetChar(&gs_setting_char, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_RCS_GetSetting(st_ble_rcs_setting_t *p_value)
{
    return R_BLE_SERVS_GetChar(&gs_setting_char, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

ble_status_t R_BLE_RCS_NotifySetting(uint16_t conn_hdl, const st_ble_rcs_setting_t *p_value)
{
    return R_BLE_SERVS_SendHdlVal(&gs_setting_char, conn_hdl, (const void *)p_value, true);
}

/*----------------------------------------------------------------------------------------------------------------------
    Reconnection Configuration Control Point Client Characteristic Configuration descriptor
 ----------------------------------------------------------------------------------------------------------------------*/

static const st_ble_servs_desc_info_t gs_rccp_cli_cnfg = {
    .attr_hdl = BLE_RCS_RCCP_CLI_CNFG_DESC_HDL,
    .app_size = sizeof(uint16_t),
    .desc_idx = BLE_RCS_RCCP_CLI_CNFG_IDX,
    .db_size = BLE_RCS_RCCP_CLI_CNFG_LEN,
    .decode = (ble_servs_attr_decode_t)decode_uint16_t,
    .encode = (ble_servs_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_RCS_SetRccpCliCnfg(uint16_t conn_hdl, const uint16_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_rccp_cli_cnfg, conn_hdl, (const void *)p_value);
}

ble_status_t R_BLE_RCS_GetRccpCliCnfg(uint16_t conn_hdl, uint16_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_rccp_cli_cnfg, conn_hdl, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Reconnection Configuration Control Point characteristic
 ----------------------------------------------------------------------------------------------------------------------*/
 /* Reconnection Configuration Control Point characteristic descriptor definition */
static const st_ble_servs_desc_info_t *gspp_rccp_descs[] = { &gs_rccp_cli_cnfg, };

/* Reconnection Configuration Control Point characteristic definition */
static const st_ble_servs_char_info_t gs_rccp_char =
{
    .start_hdl = BLE_RCS_RCCP_DECL_HDL,
    .end_hdl = BLE_RCS_RCCP_CLI_CNFG_DESC_HDL,
    .char_idx = BLE_RCS_RCCP_IDX,
    .app_size = sizeof(st_ble_rcs_rccp_t),
    .db_size = BLE_RCS_RCCP_LEN,
    .write_req_cb = (ble_servs_attr_write_req_t)write_req_rc_ctrl_pt,
    .write_comp_cb = (ble_servs_attr_write_comp_t)write_comp_rc_ctrl_pt,
    .flow_ctrl_cb = (ble_servs_attr_flow_ctrl_t)flow_ctrl_rc_ctrl_pt,
    .decode = (ble_servs_attr_decode_t)decode_st_ble_rcs_rccp_t,
    .encode = (ble_servs_attr_encode_t)encode_st_ble_rcs_rccp_t,
    .pp_descs = gspp_rccp_descs,
    .num_of_descs = ARRAY_SIZE(gspp_rccp_descs),
};

/***********************************************************************************************************************//**
 * Function Name: decode_st_ble_rcs_rccp_t
 * Description  : This function converts RC Control Point characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - pointer to the RC Control Point value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_rcs_rccp_t(st_ble_rcs_rccp_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;
    ble_status_t ret;
    uint16_t rec_crc = 0;
    /*uint16_t check_crc = 0;*/
    
    /* app data to byte sequence. */
    if( (BLE_RCS_RCCP_LEN < p_gatt_value->value_len) || (0 == p_gatt_value->value_len))
    {
        return BLE_ERR_INVALID_DATA;
    }

    memset((uint8_t*)p_app_value, 0x00, sizeof(st_ble_rcs_rccp_t));
    p_app_value->op_code = p_gatt_value->p_value[pos++];

    /*Check the opcode received and receive operand*/
    switch(p_app_value->op_code)
    {
        case BLE_RCS_RCCP_OP_CODE_PROPOSE_SETTINGS:
        {
            for (int8_t i = 0; (i < 16); i++)
            {
                p_app_value->operand[i] = p_gatt_value->p_value[pos++];
            }
        }
        break;

        case BLE_RCS_RCCP_OP_CODE_SET_WHITE_LIST_TIMER:
        {
            for (int8_t i = 0; (i < 4); i++)
            {
                p_app_value->operand[i] = p_gatt_value->p_value[pos++];
            }
        }
        break;
        
        case BLE_RCS_RCCP_OP_CODE_ACTIVATE_STORED_SETTINGS:
        case BLE_RCS_RCCP_OP_CODE_GET_STORED_VALUES:
        case BLE_RCS_RCCP_OP_CODE_SET_ADVERTISEMENT_CONFIGURATION:
        case BLE_RCS_RCCP_OP_CODE_UPGRADE_TO_LESC_ONLY:
        case BLE_RCS_RCCP_OP_CODE_SWITCH_OOB_PAIRING:
        case BLE_RCS_RCCP_OP_CODE_LIMITED_ACCESS:
        {
            p_app_value->operand[0] = p_gatt_value->p_value[pos++];
        }
        break;

        default:
        {
            /* do nothing */
        }
        break;

    }

    st_ble_rcs_feat_t rc_features = { 0 };
    R_BLE_RCS_GetFeat(&rc_features);

    if (1 == (rc_features.feature_bytes[0] & BLE_RCS_PRV_RC_FEATURES_FIELD_E2ECRC_SUPPORTED))
    {
        /* Check whether E2ECRC is supported in RC Features*/
        BT_UNPACK_LE_2_BYTE(&rec_crc, &p_gatt_value->p_value[pos]);
        ret = e2e_crc_check(p_gatt_value->p_value, (uint8_t)(p_gatt_value->value_len - 2), rec_crc);
        if (BLE_SUCCESS == ret)
        {
            memcpy(&p_app_value->e2e_crc[0], &p_gatt_value->p_value[pos], (size_t)(p_gatt_value->value_len - pos));
            pos += 2;
            return BLE_SUCCESS;
        }
        else
        {
            memset((uint8_t*)p_app_value, 0x00, sizeof(st_ble_rcs_rccp_t));
            gs_crc_error = 1;
            return BLE_RCS_MISSING_CRC_ERROR;
        }
    }
        
    return BLE_SUCCESS;
}

/***********************************************************************************************************************//**
 * Function Name: encode_st_ble_rcs_rccp_t
 * Description  : This function converts RC Control Point characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the RC Control Point  value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_rcs_rccp_t(const st_ble_rcs_rccp_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;
    uint16_t e2e_crc = 0;
    st_ble_rcs_feat_t rc_features =  { 0 };
    R_BLE_RCS_GetFeat(&rc_features);
    memset(&p_gatt_value->p_value[0], 0x00, p_gatt_value->value_len);
    
    /* response code */
    p_gatt_value->p_value[pos++] = p_app_value->op_code;
    p_gatt_value->p_value[pos++] = p_app_value->operand[0];
    p_gatt_value->p_value[pos++] = p_app_value->operand[1];
    
    /*Check the opcode received and receive operand*/
    if ((0 == gs_error_response) &&
        ((BLE_RCS_RCCP_OPERAND_SUCCESS != p_app_value->operand[0]) &&
        (BLE_RCS_RCCP_OPERAND_SUCCESS != p_app_value->operand[1])))
    {
        
        /*communication parameter response*/
        if (p_gatt_value->p_value[0] == BLE_RCS_RCCP_OP_CODE_COMMUNICATION_PARAMETER_RESPONSE)
        {
           for (uint8_t i = 2; i < 17; i++)
            {
                p_gatt_value->p_value[pos] = p_app_value->operand[i];
                pos += 1;
            }
        }
        else if (BLE_RCS_RCCP_OP_CODE_CLIENT_PARAMETER_INDICATION == p_gatt_value->p_value[0]) /*client parameter indication*/
        {
            if ((BLE_RCS_RCCP_OP_CODE_ACTIVATE_STORED_SETTINGS == p_gatt_value->p_value[1]))
            {
                if(0 == gs_stored_param_set)
                {
                    for (uint8_t i = 2; i < 9; i++)
                    {
                        p_gatt_value->p_value[pos] = p_app_value->operand[i];
                        pos += 1;
                    }
                }
                else //if (gs_stored_param_set == 1)
                {
                    for (uint8_t i = 2; i < 7; i++)
                    {
                        p_gatt_value->p_value[pos] = p_app_value->operand[i];
                        pos += 1;
                    }
                }
            }
        }
        else if (BLE_RCS_RCCP_OP_CODE_WHITE_LIST_TIMER_RESPONSE == p_gatt_value->p_value[0])
        {
            for (uint8_t i = 2; i <12; i++)
            {
                p_gatt_value->p_value[pos] = p_app_value->operand[i];
                pos += 1;
            }
        }
        else
        {
            for (uint8_t i = 2; i < 16; i++)
            {
                p_gatt_value->p_value[pos] = p_app_value->operand[i];
                pos += 1;
            }
        }  
    }
    
    /* Check whether E2ECRC is supported in RC Features */
    if (gs_e2ecrc_supported)
    {
        e2e_crc = e2e_crc_calculation(&p_gatt_value->p_value[0], (uint16_t)pos);
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &e2e_crc);
        pos += 2;
    }

    p_gatt_value->value_len = (uint16_t)pos;
    gs_stored_param_set = 0;
    gs_error_response = 0;
    
    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: rccp_process_operation
 * Description  : This function performs the procedure for RC control point
 * Arguments    : uint16_t conn_hdl,
 *				  st_ble_rcs_rccp_t *p_app_value
 * Return Value : none
 **********************************************************************************************************************/
static void rccp_process_operation(uint16_t conn_hdl, st_ble_rcs_rccp_t *p_app_value)
{
    ble_status_t ret;
    ble_status_t status;
    st_ble_rcs_setting_t set_value = { 0 };
    st_ble_rcs_rccp_t temp_app_value = { 0 };
    gs_conn_hdl = conn_hdl;
    gs_error_response = 0;

    if (1 == p_app_value->operand[0])
    {
        gs_stored_param_set = 1;
    }

    /*Check the opcode received and process and indicate*/
    switch(p_app_value->op_code)
    {
        case (BLE_RCS_RCCP_OP_CODE_ENABLE_DISCONNECT):
        {
            temp_app_value.op_code = BLE_RCS_RCCP_OP_CODE_PROCEDURE_RESPONSE;
            temp_app_value.operand[0] = BLE_RCS_RCCP_OP_CODE_ENABLE_DISCONNECT;
            temp_app_value.operand[1] = BLE_RCS_RCCP_OPERAND_SUCCESS;
            R_BLE_RCS_IndicateRccp(gs_conn_hdl, &temp_app_value);

            /* Note : For Device Busy *//*
            temp_app_value.op_code = BLE_RCS_RCCP_OP_CODE_PROCEDURE_RESPONSE;
            temp_app_value.operand[0] = BLE_RCS_RCCP_OP_CODE_ENABLE_DISCONNECT;
            temp_app_value.operand[1] = BLE_RCS_RCCP_OPERAND_DEVICE_BUSY;
            R_BLE_RCS_IndicateRccp(gs_conn_hdl, &temp_app_value);
            */
        }
        break;

        case BLE_RCS_RCCP_OP_CODE_GET_ACTUAL_COMMUNICATION_PARAMETERS:
        {
            client_param_indcatn(gs_conn_hdl, p_app_value);
        }
        break;

        case BLE_RCS_RCCP_OP_CODE_PROPOSE_SETTINGS:
        {
            (void)check_setting_ranges(gs_conn_hdl, p_app_value);
        }
        break;

        case BLE_RCS_RCCP_OP_CODE_ACTIVATE_STORED_SETTINGS:
        {
            (void)stored_settings(gs_conn_hdl, p_app_value);
        }
        break;

        case BLE_RCS_RCCP_OP_CODE_GET_MAX_VALUES:
        {
            client_param_indcatn(gs_conn_hdl, p_app_value);
        }
        break;

        case BLE_RCS_RCCP_OP_CODE_GET_MIN_VALUES:
        {
            client_param_indcatn(gs_conn_hdl, p_app_value);
        }
        break;

        case BLE_RCS_RCCP_OP_CODE_GET_STORED_VALUES:
        {
            client_param_indcatn(gs_conn_hdl, p_app_value);
        }
        break;

        case BLE_RCS_RCCP_OP_CODE_SET_WHITE_LIST_TIMER:
        {
            (void)white_list_timer(gs_conn_hdl, p_app_value);
        }
        break;

        case BLE_RCS_RCCP_OP_CODE_GET_WHITE_LIST_TIMER:
        {
            temp_app_value.op_code = BLE_RCS_RCCP_OP_CODE_WHITE_LIST_TIMER_RESPONSE;
            for (uint8_t i = 0; i < 12; i++)
            {
                temp_app_value.operand[i] = 0xFF;
            }
            R_BLE_RCS_IndicateRccp(gs_conn_hdl, &temp_app_value);
        }
        break;

        case BLE_RCS_RCCP_OP_CODE_SET_ADVERTISEMENT_CONFIGURATION:
        {
            (void)set_advt_config(gs_conn_hdl, p_app_value);
        }
        break;

        case BLE_RCS_RCCP_OP_CODE_UPGRADE_TO_LESC_ONLY:
        {
            /*Set or reset the LESC bit in settings and indicate RCCP*/
            status = R_BLE_RCS_GetSetting(&set_value);
            UNUSED_RET(status);
            if (0xFF == p_app_value->operand[0])
            {
                set_value.setting_bytes[0] |= (0xFF & BLE_RCS_PRV_RC_SETTINGS_FIELD_LESC_ONLY);
            }
            else if (0 == p_app_value->operand[0])
            {
                set_value.setting_bytes[0] |= (0 & BLE_RCS_PRV_RC_SETTINGS_FIELD_LESC_ONLY);
            }
            else
            {
                temp_app_value.op_code = BLE_RCS_RCCP_OP_CODE_PROCEDURE_RESPONSE;
                temp_app_value.operand[0] = BLE_RCS_RCCP_OP_CODE_UPGRADE_TO_LESC_ONLY;
                temp_app_value.operand[1] = BLE_RCS_RCCP_OPERAND_INVALID_OPERAND;
                gs_error_response = 1;
                R_BLE_RCS_IndicateRccp(gs_conn_hdl, &temp_app_value);
                gs_is_rccp_in_progress = false;
                return;
            }

            ret = R_BLE_RCS_SetSetting(&set_value);
            if (BLE_SUCCESS == ret)
            {
                temp_app_value.op_code = BLE_RCS_RCCP_OP_CODE_PROCEDURE_RESPONSE;
                temp_app_value.operand[0] = BLE_RCS_RCCP_OP_CODE_UPGRADE_TO_LESC_ONLY;
                temp_app_value.operand[1] = BLE_RCS_RCCP_OPERAND_SUCCESS;
                R_BLE_RCS_IndicateRccp(gs_conn_hdl, &temp_app_value);
            }
            else
            {
                temp_app_value.op_code = BLE_RCS_RCCP_OP_CODE_PROCEDURE_RESPONSE;
                temp_app_value.operand[0] = BLE_RCS_RCCP_OP_CODE_UPGRADE_TO_LESC_ONLY;
                temp_app_value.operand[1] = BLE_RCS_RCCP_OPERAND_DEVICE_BUSY;
                gs_error_response = 1;
                R_BLE_RCS_IndicateRccp(gs_conn_hdl, &temp_app_value);
            }
        }
        break;

        case BLE_RCS_RCCP_OP_CODE_SWITCH_OOB_PAIRING:
        {
            /*Set or reset the OOB pairing bit in settings and indicate RCCP*/
            status = R_BLE_RCS_GetSetting(&set_value);
            UNUSED_RET(status);
            if (0xFF == p_app_value->operand[0])
            {
                set_value.setting_bytes[0] |= (0xFF & BLE_RCS_PRV_RC_SETTINGS_FIELD_USE_OOB_PAIRING);
            }
            else if (0 == p_app_value->operand[0])
            {
                set_value.setting_bytes[0] |= (0 & BLE_RCS_PRV_RC_SETTINGS_FIELD_USE_OOB_PAIRING);
            }
            else
            {
                temp_app_value.op_code = BLE_RCS_RCCP_OP_CODE_PROCEDURE_RESPONSE;
                temp_app_value.operand[0] = BLE_RCS_RCCP_OP_CODE_SWITCH_OOB_PAIRING;
                temp_app_value.operand[1] = BLE_RCS_RCCP_OPERAND_INVALID_OPERAND;
                gs_error_response = 1;
                R_BLE_RCS_IndicateRccp(gs_conn_hdl, &temp_app_value);
                gs_is_rccp_in_progress = false;
                return;
            }
            ret = R_BLE_RCS_SetSetting(&set_value);
            if (BLE_SUCCESS == ret)
            {
                temp_app_value.op_code = BLE_RCS_RCCP_OP_CODE_PROCEDURE_RESPONSE;
                temp_app_value.operand[0] = BLE_RCS_RCCP_OP_CODE_SWITCH_OOB_PAIRING;
                temp_app_value.operand[1] = BLE_RCS_RCCP_OPERAND_SUCCESS;
                R_BLE_RCS_IndicateRccp(gs_conn_hdl, &temp_app_value);
            }
            else
            {
                temp_app_value.op_code = BLE_RCS_RCCP_OP_CODE_PROCEDURE_RESPONSE;
                temp_app_value.operand[0] = BLE_RCS_RCCP_OP_CODE_SWITCH_OOB_PAIRING;
                temp_app_value.operand[1] = BLE_RCS_RCCP_OPERAND_DEVICE_BUSY;
                R_BLE_RCS_IndicateRccp(gs_conn_hdl, &temp_app_value);
            }
        }
        break;

        case BLE_RCS_RCCP_OP_CODE_LIMITED_ACCESS:
        {
            /*Set or reset the limited access bit in settings and indicate RCCP*/
            status = R_BLE_RCS_GetSetting(&set_value);
            UNUSED_RET(status);
            if (0xFF == p_app_value->operand[0])
            {
                set_value.setting_bytes[0] |= (0xFF & BLE_RCS_PRV_RC_SETTINGS_FIELD_LIMITED_ACCESS);
            }
            else if(0 == p_app_value->operand[0])
            {
                set_value.setting_bytes[0] |= (0 & BLE_RCS_PRV_RC_SETTINGS_FIELD_LIMITED_ACCESS);
            }
            else
            {
                temp_app_value.op_code = BLE_RCS_RCCP_OP_CODE_PROCEDURE_RESPONSE;
                temp_app_value.operand[0] = BLE_RCS_RCCP_OP_CODE_LIMITED_ACCESS;
                temp_app_value.operand[1] = BLE_RCS_RCCP_OPERAND_INVALID_OPERAND;
                gs_error_response = 1;
                R_BLE_RCS_IndicateRccp(gs_conn_hdl, &temp_app_value);
                gs_is_rccp_in_progress = false;
                return;
            }
            ret = R_BLE_RCS_SetSetting(&set_value);
            if (BLE_SUCCESS == ret)
            {
                temp_app_value.op_code = BLE_RCS_RCCP_OP_CODE_PROCEDURE_RESPONSE;
                temp_app_value.operand[0] = BLE_RCS_RCCP_OP_CODE_LIMITED_ACCESS;
                temp_app_value.operand[1] = BLE_RCS_RCCP_OPERAND_SUCCESS;
                R_BLE_RCS_IndicateRccp(gs_conn_hdl, &temp_app_value);
            }
            else
            {
                temp_app_value.op_code = BLE_RCS_RCCP_OP_CODE_PROCEDURE_RESPONSE;
                temp_app_value.operand[0] = BLE_RCS_RCCP_OP_CODE_LIMITED_ACCESS;
                temp_app_value.operand[1] = BLE_RCS_RCCP_OPERAND_DEVICE_BUSY;
                gs_error_response = 1;
                R_BLE_RCS_IndicateRccp(gs_conn_hdl, &temp_app_value);
            }
        }
        break;

        default:
        {
            temp_app_value.op_code = BLE_RCS_RCCP_OP_CODE_PROCEDURE_RESPONSE;
            temp_app_value.operand[0] = 0xF0; // request opcode not supported
            temp_app_value.operand[1] = BLE_RCS_RCCP_OPERAND_OPCODE_NOT_SUPPORTED;
            gs_error_response = 1;
            R_BLE_RCS_IndicateRccp(gs_conn_hdl, &temp_app_value);
        }
        break;
    }

    gs_is_rccp_in_progress = false;
    
    return;

}

/***********************************************************************************************************************
 * Function Name: write_req_rc_ctrl_pt
 * Description  : This function
 * Arguments    :
 * Return Value : none
 **********************************************************************************************************************/
static void write_req_rc_ctrl_pt(const void *p_attr, uint16_t conn_hdl, ble_status_t result,
    st_ble_rcs_rccp_t *p_app_value)
{
    UNUSED_ARG(p_attr);
    UNUSED_ARG(result);
    UNUSED_ARG(p_app_value);

    /*uint8_t pos = 0;*/
    uint16_t cli_cnfg;
    R_BLE_RCS_GetRccpCliCnfg(conn_hdl, &cli_cnfg);
    if (BLE_GATTS_CLI_CNFG_INDICATION != cli_cnfg)
    {
        gs_error_response = 1;
        R_BLE_GATTS_SendErrRsp(BLE_RCS_CLI_CNFG_IMPROPERLY_CONFIGURED_ERROR);
        return;
    }
    
    if (gs_crc_error)
    {
        gs_error_response = 1;
        R_BLE_GATTS_SendErrRsp(BLE_RCS_MISSING_CRC_ERROR);
        return;
    }
}

/***********************************************************************************************************************
 * Function Name: write_comp_rc_ctrl_pt
 * Description  : This function
 * Arguments    :const void *p_attr,uint16_t conn_hdl,ble_status_t result,st_ble_rcs_rccp_t *p_app_value
 * Return Value : none
 **********************************************************************************************************************/
static void write_comp_rc_ctrl_pt(const void *p_attr, uint16_t conn_hdl, ble_status_t result,
    st_ble_rcs_rccp_t *p_app_value)
{
    UNUSED_ARG(p_attr);

    gs_is_rccp_in_progress = true;
    gs_conn_hdl = conn_hdl;
    
    if ((BLE_SUCCESS == result) && (1 != gs_error_response))
    {
        rccp_process_operation(gs_conn_hdl, p_app_value);
    }

    st_ble_servs_evt_data_t evt_data = {
        .conn_hdl  = conn_hdl,
        .param_len = gs_rccp_char.app_size,
        .p_param   = p_app_value,
    };

    gs_servs_info.cb(BLE_SERVS_MULTI_ATTR_EVENT(gs_rccp_char.char_idx, gs_rccp_char.inst_idx, BLE_SERVS_WRITE_COMP), result, &evt_data);
}
   
/***********************************************************************************************************************
 * Function Name: flow_ctrl_rc_ctrl_pt
 * Description  : This function sends the status update of event
 * Arguments    : *p_attr
 * Return Value : none
 **********************************************************************************************************************/
static void flow_ctrl_rc_ctrl_pt(const void *p_attr)
{
    if (gs_is_rccp_in_progress)
    {
        st_ble_servs_char_info_t *ps_char_attr = (st_ble_servs_char_info_t *)p_attr;
        st_ble_rcs_rccp_t app_value;
        st_ble_gatt_value_t gatt_value;
        R_BLE_GATTS_GetAttr(gs_conn_hdl, (uint16_t)(ps_char_attr->start_hdl + 1), &gatt_value);
        decode_st_ble_rcs_rccp_t(&app_value, &gatt_value);
        rccp_process_operation(gs_conn_hdl, &app_value);
    }
}

/***********************************************************************************************************************
 * Function Name: client_param_indcatn
 * Description  : Indication from server to the Client
 * Arguments    : *p_app_value - pointer to the client parameter structure
 * Return Value : none
 **********************************************************************************************************************/
static void client_param_indcatn(uint16_t conn_hdl, st_ble_rcs_rccp_t *p_app_value)
{
    UNUSED_ARG(conn_hdl);

    st_ble_rcs_rccp_t app_value = { 0 };
    /*st_ble_gap_conn_param_t conn_param = { 0 };*/

    /*
    conn_param.conn_intv_max = gs_ind_data.max_connection_interval;
    conn_param.conn_intv_min = gs_ind_data.min_connection_interval;
    conn_param.conn_latency = gs_ind_data.slave_latency;
    conn_param.sup_to = gs_ind_data.supervision_timeout_multiplier;
    */
    gs_ind_data.reconnection_timeout = 0x4E10;
    gs_ind_data.advt_interval = 0x300;
    gs_ind_data.advt_count = 1;
    gs_ind_data.advt_repttn_time = 0x300;

    if (1 == p_app_value->operand[0])
    {
        gs_stored_param_set = 1;
    }

    app_value.operand[0] = (uint8_t)(gs_ind_data.reconnection_timeout & 0xFF);
    app_value.operand[1] = (uint8_t)((gs_ind_data.reconnection_timeout >> 8) & 0xFF);
    app_value.operand[2] = (uint8_t)(gs_ind_data.min_connection_interval & 0xFF);
    app_value.operand[3] = (uint8_t)((gs_ind_data.min_connection_interval >> 8) & 0xFF);
    app_value.operand[4] = (uint8_t)(gs_ind_data.max_connection_interval & 0xFF);
    app_value.operand[5] = (uint8_t)((gs_ind_data.max_connection_interval >> 8) & 0xFF);
    app_value.operand[6] = (uint8_t)(gs_ind_data.slave_latency & 0xFF);
    app_value.operand[7] = (uint8_t)((gs_ind_data.slave_latency >> 8) & 0xFF);
    app_value.operand[8] = (uint8_t)(gs_ind_data.supervision_timeout_multiplier & 0xFF);
    app_value.operand[9] = (uint8_t)((gs_ind_data.supervision_timeout_multiplier >> 8) & 0xFF);
    app_value.operand[10] = (uint8_t)(gs_ind_data.advt_interval & 0xFF);
    app_value.operand[11] = (uint8_t)((gs_ind_data.advt_interval >> 8) & 0xFF);
    app_value.operand[12] = (uint8_t)(gs_ind_data.advt_count & 0xFF);
    app_value.operand[13] = (uint8_t)((gs_ind_data.advt_count >> 8) & 0xFF);
    app_value.operand[14] = (uint8_t)(gs_ind_data.advt_repttn_time & 0xFF);
    app_value.operand[15] = (uint8_t)((gs_ind_data.advt_repttn_time >> 8) & 0xFF);

    /*copy to the rccp structure*/
    /*stored connection parameters - 0*/
    switch (p_app_value->op_code)
    {
        case BLE_RCS_RCCP_OP_CODE_GET_ACTUAL_COMMUNICATION_PARAMETERS:
        {
            app_value.op_code = BLE_RCS_RCCP_OP_CODE_CLIENT_PARAMETER_INDICATION;            
        }
        break;

        case BLE_RCS_RCCP_OP_CODE_GET_MAX_VALUES:
        {
            app_value.op_code = BLE_RCS_RCCP_OP_CODE_COMMUNICATION_PARAMETER_RESPONSE;
            app_value.operand[0] = BLE_RCS_RCCP_OP_CODE_GET_MAX_VALUES;
            app_value.operand[1] = 0x20;
            app_value.operand[2] = 0x4E;
            app_value.operand[3] = 0x80;
            app_value.operand[4] = 0x0C;
            app_value.operand[5] = 0x80;
            app_value.operand[6] = 0x0C;
            app_value.operand[7] = 0xF3;
            app_value.operand[8] = 0x01;
            app_value.operand[9] = 0x80;
            app_value.operand[10] = 0x0C;
            app_value.operand[11] = 0x00;
            app_value.operand[12] = 0x40;
            app_value.operand[13] = 0xE8;
            app_value.operand[14] = 0x03;
            app_value.operand[15] = 0x10;
            app_value.operand[16] = 0x27;
        }
        break;

        case BLE_RCS_RCCP_OP_CODE_GET_MIN_VALUES:
        {
            app_value.op_code = BLE_RCS_RCCP_OP_CODE_COMMUNICATION_PARAMETER_RESPONSE;
            app_value.operand[0] = BLE_RCS_RCCP_OP_CODE_GET_MIN_VALUES;
            app_value.operand[1] = 0x00;
            app_value.operand[2] = 0x00;
            app_value.operand[3] = 0x06;
            app_value.operand[4] = 0x00;
            app_value.operand[5] = 0x06;
            app_value.operand[6] = 0x00;
            app_value.operand[7] = 0x00;
            app_value.operand[8] = 0x00;
            app_value.operand[9] = 0x0A;
            app_value.operand[10] = 0x00;
            app_value.operand[11] = 0x20;
            app_value.operand[12] = 0x00;
            app_value.operand[13] = 0x01;
            app_value.operand[14] = 0x00;
            app_value.operand[15] = 0x00;
            app_value.operand[16] = 0x00;
        }
        break;

        case BLE_RCS_RCCP_OP_CODE_GET_STORED_VALUES:
        {
            app_value.op_code = BLE_RCS_RCCP_OP_CODE_COMMUNICATION_PARAMETER_RESPONSE;
            app_value.operand[0] = BLE_RCS_RCCP_OP_CODE_GET_STORED_VALUES;
            if (0 == p_app_value->operand[0])
            {
                gs_stored_param_set = 0;
                app_value.operand[1] = (uint8_t)(gs_ind_data.reconnection_timeout & 0xFF);
                app_value.operand[2] = (uint8_t)((gs_ind_data.reconnection_timeout >> 8) & 0xFF);
                app_value.operand[3] = (uint8_t)(gs_ind_data.max_connection_interval & 0xFF);
                app_value.operand[4] = (uint8_t)((gs_ind_data.max_connection_interval >> 8) & 0xFF);
                app_value.operand[5] = (uint8_t)(gs_ind_data.max_connection_interval & 0xFF);
                app_value.operand[6] = (uint8_t)((gs_ind_data.max_connection_interval >> 8) & 0xFF);
                app_value.operand[7] = (uint8_t)(gs_ind_data.slave_latency & 0xFF);
                app_value.operand[8] = (uint8_t)((gs_ind_data.slave_latency >> 8) & 0xFF);
                app_value.operand[9] = (uint8_t)(gs_ind_data.supervision_timeout_multiplier & 0xFF);
                app_value.operand[10] = (uint8_t)((gs_ind_data.supervision_timeout_multiplier >> 8) & 0xFF);
                app_value.operand[11] = (uint8_t)(gs_ind_data.advt_interval & 0xFF);
                app_value.operand[12] = (uint8_t)((gs_ind_data.advt_interval >> 8) & 0xFF);
                app_value.operand[13] = (uint8_t)(gs_ind_data.advt_count & 0xFF);
                app_value.operand[14] = (uint8_t)((gs_ind_data.advt_count >> 8) & 0xFF);
                app_value.operand[15] = (uint8_t)(gs_ind_data.advt_repttn_time & 0xFF);
                app_value.operand[16] = (uint8_t)((gs_ind_data.advt_repttn_time >> 8) & 0xFF);
            }
            else if (1 == p_app_value->operand[0])
            {
                gs_stored_param_set = 1;
                app_value.operand[1] = (uint8_t)(gs_ind_data.reconnection_timeout & 0xFF);
                app_value.operand[2] = (uint8_t)((gs_ind_data.reconnection_timeout >> 8) & 0xFF);
                app_value.operand[3] = (uint8_t)(gs_ind_data.max_connection_interval & 0xFF);
                app_value.operand[4] = (uint8_t)((gs_ind_data.max_connection_interval >> 8) & 0xFF);
                app_value.operand[5] = (uint8_t)(gs_ind_data.max_connection_interval & 0xFF);
                app_value.operand[6] = (uint8_t)((gs_ind_data.max_connection_interval >> 8) & 0xFF);
                app_value.operand[7] = (uint8_t)(gs_ind_data.slave_latency & 0xFF);
                app_value.operand[8] = (uint8_t)((gs_ind_data.slave_latency >> 8) & 0xFF);
                app_value.operand[9] = (uint8_t)(gs_ind_data.supervision_timeout_multiplier & 0xFF);
                app_value.operand[10] = (uint8_t)((gs_ind_data.supervision_timeout_multiplier >> 8) & 0xFF);
                app_value.operand[11] = (uint8_t)(gs_ind_data.advt_interval & 0xFF);
                app_value.operand[12] = (uint8_t)((gs_ind_data.advt_interval >> 8) & 0xFF);
                app_value.operand[13] = (uint8_t)(gs_ind_data.advt_count & 0xFF);
                app_value.operand[14] = (uint8_t)((gs_ind_data.advt_count >> 8) & 0xFF);
                app_value.operand[15] = (uint8_t)(gs_ind_data.advt_repttn_time & 0xFF);
                app_value.operand[16] = (uint8_t)((gs_ind_data.advt_repttn_time >> 8) & 0xFF);
            }
            else
            {
                app_value.op_code = BLE_RCS_RCCP_OP_CODE_PROCEDURE_RESPONSE;
                app_value.operand[0] = BLE_RCS_RCCP_OP_CODE_GET_STORED_VALUES; 
                app_value.operand[1] = BLE_RCS_RCCP_OPERAND_INVALID_OPERAND;
                gs_error_response = 1;
            }
        }
        break;

        case BLE_RCS_RCCP_OP_CODE_ACTIVATE_STORED_SETTINGS:
        {
            app_value.op_code = BLE_RCS_RCCP_OP_CODE_PROCEDURE_RESPONSE;
            app_value.operand[0] = BLE_RCS_RCCP_OP_CODE_ACTIVATE_STORED_SETTINGS;
            app_value.operand[1] = BLE_RCS_RCCP_OPERAND_SUCCESS;
            if (0 == p_app_value->operand[0])
            {
                gs_stored_param_set = 0;
            }
            else if (1 == p_app_value->operand[0])
            {
                gs_stored_param_set = 1;
            }
            else
            {
                app_value.operand[1] = BLE_RCS_RCCP_OPERAND_INVALID_OPERAND;
                gs_error_response = 1;
            }
        }
        break;

        default:
        {
            /* Do Nothing */
        }
        break;
    }

    R_BLE_RCS_IndicateRccp(gs_conn_hdl, &app_value);
    gs_is_rccp_in_progress = false;
    
}

/***********************************************************************************************************************
 * Function Name: set_advt_config
 * Description  : set the advertisement configuration bits and do advertising
 * Arguments    : conn_hdl
                *p_app_value - pointer to the client parameter structure
 * Return Value : ble_status_t
 **********************************************************************************************************************/
ble_status_t set_advt_config(uint16_t conn_hdl, st_ble_rcs_rccp_t *p_app_value)
{
    UNUSED_ARG(conn_hdl);

    st_ble_rcs_rccp_t temp_app_value = { 0 };
    g_advt_config = p_app_value->operand[0];
   
    if(p_app_value->operand[0] > 3)
    {
        temp_app_value.op_code = BLE_RCS_RCCP_OP_CODE_PROCEDURE_RESPONSE;
        temp_app_value.operand[0] = BLE_RCS_RCCP_OP_CODE_SET_ADVERTISEMENT_CONFIGURATION;
        temp_app_value.operand[1] = BLE_RCS_RCCP_OPERAND_INVALID_OPERAND;
        gs_error_response = 1;
        R_BLE_RCS_IndicateRccp(gs_conn_hdl, &temp_app_value);
    }
    else
    {
        temp_app_value.op_code = BLE_RCS_RCCP_OP_CODE_PROCEDURE_RESPONSE;
        temp_app_value.operand[0] = BLE_RCS_RCCP_OP_CODE_SET_ADVERTISEMENT_CONFIGURATION;
        temp_app_value.operand[1] = BLE_RCS_RCCP_OPERAND_SUCCESS;
        R_BLE_RCS_IndicateRccp(gs_conn_hdl, &temp_app_value);
    }
    
    return BLE_SUCCESS;
    
}


/***********************************************************************************************************************
 * Function Name: check_setting_ranges
 * Description  : check whether the received setting values are within the ranges
 * Arguments    : conn_hdl
                *p_app_value - pointer to the client parameter structure
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t check_setting_ranges(uint16_t conn_hdl, st_ble_rcs_rccp_t *p_app_value)
{
    UNUSED_ARG(conn_hdl);

    uint8_t param = 0;
    /*uint8_t ret = 0;*/
    uint8_t error_counter = 0;
    e_ble_rcs_cleint_param_indctn_t rec_value = { 0 };
    st_ble_rcs_rccp_t temp_app_value = { 0 };

    /*copy and check values*/
    rec_value.reconnection_timeout =
        (uint16_t)(((p_app_value->operand[1] << 8) & 0xFF00) | (p_app_value->operand[0] & 0xFF));
    rec_value.min_connection_interval = 
        (uint16_t)(((p_app_value->operand[3] << 8) & 0xFF00) | (p_app_value->operand[2] & 0xFF));
    rec_value.max_connection_interval =
        (uint16_t)(((p_app_value->operand[5] << 8) & 0xFF00) | (p_app_value->operand[4] & 0xFF));
    rec_value.slave_latency = 
        (uint16_t)(((p_app_value->operand[7] << 8) & 0xFF00) | (p_app_value->operand[6] & 0xFF));
    rec_value.supervision_timeout_multiplier =
        (uint16_t)(((p_app_value->operand[9] << 8) & 0xFF00) | (p_app_value->operand[8] & 0xFF));
    rec_value.advt_interval =
        (uint16_t)(((p_app_value->operand[11] << 8) & 0xFF00) | (p_app_value->operand[10] & 0xFF));
    rec_value.advt_count =
        (uint16_t)(((p_app_value->operand[13] << 8) & 0xFF00) | (p_app_value->operand[12] & 0xFF));
    rec_value.advt_repttn_time =
        (uint16_t)(((p_app_value->operand[15] << 8) & 0xFF00) | (p_app_value->operand[14] & 0xFF));

    switch (p_app_value->op_code)
    {
        case BLE_RCS_RCCP_OP_CODE_PROPOSE_SETTINGS:
        {
            if (0xFFFF != rec_value.reconnection_timeout)
            {
                if (/*(rec_value.reconnection_timeout >= 0) &&*/ (rec_value.reconnection_timeout < BLE_RCS_RC_TIMEOUT_MAX_RANGE))
                {
                    gs_recon_timer++;
                    temp_app_value.op_code = BLE_RCS_RCCP_OP_CODE_PROCEDURE_RESPONSE;
                    temp_app_value.operand[0] = BLE_RCS_RCCP_OP_CODE_PROPOSE_SETTINGS;
                    temp_app_value.operand[1] = BLE_RCS_RCCP_OPERAND_SUCCESS;
                    R_BLE_RCS_IndicateRccp(gs_conn_hdl, &temp_app_value);
                }
                else
                {                    
                    /*set up response rccp structure*/
                    error_counter++;
                    param = param | 0x01;
                }
            }
            
            if (0xFFFF != rec_value.min_connection_interval)
            {
                if ((rec_value.min_connection_interval > BLE_RCS_MIN_CON_INTERVAL_MIN) &&
                    (rec_value.min_connection_interval < BLE_RCS_MIN_CON_INTERVAL_MAX))
                {
                    /* Do Nothing */
                }
                else
                {                    
                    /*set up response rccp structure*/
                    error_counter++;
                    param |= 0x02;
                }
            }

            if (0xFFFF != rec_value.max_connection_interval)
            {
                if ((rec_value.max_connection_interval > BLE_RCS_MAX_CON_INTERVAL_MIN) &&
                    (rec_value.max_connection_interval < BLE_RCS_MAX_CON_INTERVAL_MAX))
                {
                    /* Do Nothing */ 
                }
                else
                {                    
                    /*set up response rccp structure*/
                    error_counter++;
                    param |= 0x04;
                }
            }

            if (0xFFFF != rec_value.slave_latency)
            {
                if (/*(rec_value.slave_latency >= 0) &&*/
                    (rec_value.slave_latency < BLE_RCS_SLAVE_LATENCY_MAX))
                {
                    /* Do Nothing */
                }
                else
                {
                    /*set up response rccp structure*/
                    error_counter++;
                    param |= 0x08;
                }
            }

            if (0xFFFF != rec_value.supervision_timeout_multiplier)
            {
                if ((rec_value.supervision_timeout_multiplier > BLE_RCS_SUPVSN_TIMOUT_MULTPLR_MIN) &&
                    (rec_value.supervision_timeout_multiplier < BLE_RCS_SUPVSN_TIMOUT_MULTPLR_MAX))
                {
                    /* Do Nothing */
                }
                else
                {
                    /*set up response rccp structure*/
                    error_counter++;
                    param |= 0x10;
                }
            }

            if (0xFFFF != rec_value.advt_interval)
            {
                if ((rec_value.advt_interval > BLE_RCS_ADVT_INTERVAL_MIN) &&
                    (rec_value.advt_interval < BLE_RCS_ADVT_INTERVAL_MAX))
                {
                    /* Do Nothing */
                }
                else
                {
                    /*set up response rccp structure*/
                    error_counter++;
                    param |= 0x20;
                }
            }

            if (0xFFFF != rec_value.advt_count)
            {
                if ((rec_value.advt_count > BLE_RCS_ADVT_COUNT_MIN) &&
                    (rec_value.advt_count < BLE_RCS_ADVT_COUNT_MAX))
                {
                    /* Do Nothing */
                }
                else
                {
                    /*set up response rccp structure*/
                    error_counter++;
                    param |= 0x40;
                }
            }
            
            if (0xFFFF != rec_value.advt_repttn_time)
            {
                if (/*(rec_value.advt_repttn_time >= 0) &&*/
                    (rec_value.advt_repttn_time < BLE_RCS_ADVT_REPTTN_TIME_MAX))
                {
                    /* Do Nothing */
                }
                else
                {
                    /*set up response rccp structure*/
                    error_counter++;
                    param |= 0x80;
                }
            }
            else
            {
                temp_app_value.op_code = BLE_RCS_RCCP_OP_CODE_PROCEDURE_RESPONSE;
                temp_app_value.operand[0] = BLE_RCS_RCCP_OP_CODE_PROPOSE_SETTINGS;
                temp_app_value.operand[1] = BLE_RCS_RCCP_OPERAND_SUCCESS;
            }
        }
        break;

        default:
        {
            /* Do Nothing */
        }
        break;
    }

    gs_recon_timer = 0;
    gs_is_rccp_in_progress = false;
    
    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: stored_settings
 * Description  : check whether the recieved setting values are within the ranges
 * Arguments    : conn_hdl
                *p_app_value - pointer to the client parameter structure
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t stored_settings(uint16_t conn_hdl, st_ble_rcs_rccp_t *p_app_value)
{
    UNUSED_ARG(conn_hdl);

    /*uint8_t param = 0;*/
    /*uint8_t advt_only = 0;*/
    /*uint8_t error_counter = 0;*/
    st_ble_rcs_rccp_t temp_app_value = { 0 };
    
    switch (p_app_value->op_code)
    {
        case BLE_RCS_RCCP_OP_CODE_ACTIVATE_STORED_SETTINGS:
        {
            if ((0 != p_app_value->operand[0]) && (1 != p_app_value->operand[0])) //invalid operand
            {
                temp_app_value.op_code = BLE_RCS_RCCP_OP_CODE_PROCEDURE_RESPONSE;
                temp_app_value.operand[0] = BLE_RCS_RCCP_OP_CODE_ACTIVATE_STORED_SETTINGS;
                temp_app_value.operand[1] = BLE_RCS_RCCP_OPERAND_INVALID_OPERAND;
                gs_error_response = 1;
                R_BLE_RCS_IndicateRccp(gs_conn_hdl, &temp_app_value);
            }
            else
            {
                client_param_indcatn(gs_conn_hdl, p_app_value);
            }
        }
        break;
    
        default:
        {
            /* Do Nothing */
        }
        break;
    }

    gs_is_rccp_in_progress = false;
    
    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: white_list_timer
 * Description  : this function sets and gets the white list timer values
 * Arguments    : conn_hdl
                *p_app_value - pointer to the client parameter structure
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t white_list_timer(uint16_t conn_hdl, st_ble_rcs_rccp_t *p_app_value)
{
    UNUSED_ARG(conn_hdl);

    uint32_t white_timer = 0; 
    st_ble_rcs_rccp_t temp_app_value = { 0 };

    BT_UNPACK_LE_4_BYTE(&white_timer, &p_app_value->operand[0]);

    if (0 == white_timer)
    {
        white_timer = 0xFFFFFFFE;
        temp_app_value.op_code = BLE_RCS_RCCP_OP_CODE_PROCEDURE_RESPONSE;
        temp_app_value.operand[0] = BLE_RCS_RCCP_OP_CODE_SET_WHITE_LIST_TIMER;
        temp_app_value.operand[1] = BLE_RCS_RCCP_OPERAND_SUCCESS;
        R_BLE_RCS_IndicateRccp(gs_conn_hdl, &temp_app_value);
    }
    else
    {

    }

    return BLE_SUCCESS;
}

ble_status_t R_BLE_RCS_IndicateRccp(uint16_t conn_hdl, const st_ble_rcs_rccp_t *p_value)
{
    return R_BLE_SERVS_SendHdlVal(&gs_rccp_char, conn_hdl, (const void *)p_value, false);
}

/*----------------------------------------------------------------------------------------------------------------------
    Reconnection Configuration server
 ----------------------------------------------------------------------------------------------------------------------*/
 /* Reconnection Configuration characteristics definition */
static const st_ble_servs_char_info_t *gspp_chars[] = { 
    &gs_feat_char, 
    &gs_setting_char, 
    &gs_rccp_char, 
};

/* Reconnection Configuration service definition */
static st_ble_servs_info_t gs_servs_info = { 
    .pp_chars = gspp_chars,
    .num_of_chars = ARRAY_SIZE(gspp_chars), 
};

ble_status_t R_BLE_RCS_Init(ble_servs_app_cb_t cb)
{
    if (NULL == cb)
    {
        return BLE_ERR_INVALID_PTR;
    }

    gs_servs_info.cb = cb;
    return R_BLE_SERVS_RegisterServer(&gs_servs_info);
}

