/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_cgms.h
 * Version : 1.0
 * Description : The header file for Continuous Glucose Monitoring service.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 24.05.2019 1.00 First Release
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @file
 * @defgroup cgms Continuous Glucose Monitoring Service
 * @{
 * @ingroup profile
 * @brief   This service exposes glucose and other data from a personal Continuous Glucose Monitoring (CGM) sensor 
            for use in consumer healthcare applications.
 **********************************************************************************************************************/
#include "r_ble_rx23w_if.h"
#include "profile_cmn/r_ble_servs_if.h"
#include "gatt_db.h"

#ifndef R_BLE_CGMS_H
#define R_BLE_CGMS_H
#define BLE_CGMS_SESSION_START_TIMEINVALID_TIME_ZONE_ERROR (BLE_ERR_GROUP_GATT | 0xFF)

 /************************************************************************************************************************//**
  * @brief A Record Access Control Point request cannot be serviced because a previously triggered RACP operation is still in progress
 ****************************************************************************************************************************/
#define BLE_CGMS_PROCEDURE_ALREADY_IN_PROGRESS_ERROR (BLE_ERR_GROUP_GATT | 0xFE)

 /************************************************************************************************************************//**
  * @brief The Client Characteristic Configuration descriptor is not configured according to the requirements of the service.
 ***************************************************************************************************************************/
#define BLE_CGMS_CLI_CNFG_IMPROPERLY_CONFIGURED_ERROR (BLE_ERR_GROUP_GATT | 0xFD)

/*----------------------------------------------------------------------------------------------------------------------
    CGM Measurement Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/************************************************************************************************************************//**
 * @brief CGM Measurement Flags value structure.
****************************************************************************************************************************/
typedef struct
{
    bool is_cgm_trend_information_present;

    /**< CGM Trend Information Present */

    bool is_cgm_quality_present;

    /**< CGM Quality Present */

    bool is_sensor_status_annunciation_field__warning_octet_present;

    /**< Sensor Status Annunciation Field, Warning-Octet present */

    bool is_sensor_status_annunciation_field__cal_temp_octet_present;

    /**< Sensor Status Annunciation Field, Cal/Temp-Octet present */

    bool is_sensor_status_annunciation_field__status_octet_present;

    /**< Sensor Status Annunciation Field, Status-Octet present */

} st_ble_cgms_meas_flags_t;

/************************************************************************************************************************//**
 * @brief CGM Measurement Sensor Status Annunciation value structure.
***************************************************************************************************************************/
typedef struct 
{
    bool is_session_stopped;

    /**< Session Stopped */

    bool is_device_battery_low; 

    /**< Device Battery Low */

    bool is_sensor_type_incorrect_for_device;

    /**< Sensor type incorrect for device */

    bool is_sensor_malfunction;

    /**< Sensor malfunction */

    bool is_device_specific_alert; 

    /**< Device Specific Alert */

    bool is_general_device_fault_has_occurred_in_the_sensor;

    /**< General device fault has occurred in the sensor */

    bool is_time_synchronization_between_sensor_and_collector_required;

    /**< Time synchronization between sensor and collector required */

    bool is_calibration_not_allowed; 

    /**< Calibration not allowed */

    bool is_calibration_recommended;

    /**< Calibration recommended */

    bool is_calibration_required;

    /**< Calibration required */

    bool is_sensor_temperature_too_high_for_valid_test_result_at_time_of_measurement;

    /**< Sensor Temperature too high for valid test/result at time of measurement */

    bool is_sensor_temperature_too_low_for_valid_test_result_at_time_of_measurement;

    /**< Sensor temperature too low for valid test/result at time of measurement */

    bool is_sensor_result_lower_than_the_patient_low_level;

    /**< Sensor result lower than the Patient Low level */

    bool is_sensor_result_higher_than_the_patient_high_level;

    /**< Sensor result higher than the Patient High level */

    bool is_sensor_result_lower_than_the_hypo_level;

    /**< Sensor result lower than the Hypo level */

    bool is_sensor_result_higher_than_the_hyper_level;

    /**< Sensor result higher than the Hyper level */

    bool is_sensor_rate_of_decrease_exceeded;

    /**< Sensor Rate of Decrease exceeded */

    bool is_sensor_rate_of_increase_exceeded;

    /**< Sensor Rate of Increase exceeded */

    bool is_sensor_result_lower_than_the_device_can_process;

    /**< Sensor result lower than the device can process */

    bool is_sensor_result_higher_than_the_device_can_process;

    /**< Sensor result higher than the device can process */

} st_ble_meas_sensor_status_annunciation_t;

/**********************************************************************************************************************//**
 * @brief CGM Measurement value structure.
**************************************************************************************************************************/
typedef struct
{
    uint8_t size; /**< Size */
    st_ble_cgms_meas_flags_t flags; /**< Flags */
    st_ble_ieee11073_sfloat_t cgm_glucose_concentration;

    /**< CGM Glucose Concentration */

    uint16_t time_offset; /**< Time Offset */
    st_ble_meas_sensor_status_annunciation_t sensor_status_annunciation;

    /**< Sensor Status Annunciation */

    st_ble_ieee11073_sfloat_t cgm_trend_information;

    /**< CGM Trend Information */

    st_ble_ieee11073_sfloat_t cgm_quality; /**< CGM Quality */
    uint16_t e2e_crc; /**< E2E-CRC */
} st_ble_cgms_meas_t;

/**************************************************************************************************************************//**
 * @brief     Send notification of  CGM Measurement characteristic value to the remote device.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value  Characteristic value to send.
 * @return    @ref ble_status_t
******************************************************************************************************************************/
ble_status_t R_BLE_CGMS_NotifyMeas(uint16_t conn_hdl, const st_ble_cgms_meas_t *p_value);

/**************************************************************************************************************************//**
 * @brief     Set CGM Measurement cli cnfg descriptor value to the local GATT database.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
******************************************************************************************************************************/
ble_status_t R_BLE_CGMS_SetMeasCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/*************************************************************************************************************************//**
 * @brief     Get CGM Measurement cli cnfg descriptor value from the local GATT database.
 * @param[in] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
******************************************************************************************************************************/
ble_status_t R_BLE_CGMS_GetMeasCliCnfg(uint16_t conn_hdl, uint16_t *p_value);

/*----------------------------------------------------------------------------------------------------------------------
    CGM Feature Characteristic
----------------------------------------------------------------------------------------------------------------------*/
      
/******************************************************************************************************************************//**
 * @brief CGM Feature CGM Type enumeration.
********************************************************************************************************************************/
typedef enum 
{
    BLE_CGMS_FEAT_CGM_TYPE_CAPILLARY_WHOLE_BLOOD_1 = 1, /**< Capillary Whole blood */
    BLE_CGMS_FEAT_CGM_TYPE_CAPILLARY_PLASMA = 2, /**< Capillary Plasma */
    BLE_CGMS_FEAT_CGM_TYPE_CAPILLARY_WHOLE_BLOOD_2 = 3, /**< Capillary Whole blood */
    BLE_CGMS_FEAT_CGM_TYPE_VENOUS_PLASMA = 4, /**< Venous Plasma */
    BLE_CGMS_FEAT_CGM_TYPE_ARTERIAL_WHOLE_BLOOD = 5, /**< Arterial Whole blood */
    BLE_CGMS_FEAT_CGM_TYPE_ARTERIAL_PLASMA = 6, /**< Arterial Plasma */
    BLE_CGMS_FEAT_CGM_TYPE_UNDETERMINED_WHOLE_BLOOD = 7, /**< Undetermined Whole blood */
    BLE_CGMS_FEAT_CGM_TYPE_UNDETERMINED_PLASMA = 8, /**< Undetermined Plasma */
    BLE_CGMS_FEAT_CGM_TYPE_INTERSTITIAL_FLUID = 9, /**< Interstitial Fluid (ISF) */
    BLE_CGMS_FEAT_CGM_TYPE_CONTROL_SOLUTION = 10, /**< Control Solution */
} e_ble_cgms_feat_cgm_type_t;

/*****************************************************************************************************************************//**
 * @brief CGM Feature CGM Sample Location enumeration.
*********************************************************************************************************************************/
typedef enum 
{
    BLE_CGMS_FEAT_CGM_SAMPLE_LOCATION_FINGER = 1, /**< Finger */
    BLE_CGMS_FEAT_CGM_SAMPLE_LOCATION_ALTERNATE_SITE_TEST = 2, /**< Alternate Site Test (AST) */
    BLE_CGMS_FEAT_CGM_SAMPLE_LOCATION_EARLOBE = 3, /**< Earlobe */
    BLE_CGMS_FEAT_CGM_SAMPLE_LOCATION_CONTROL_SOLUTION = 4, /**< Control solution */
    BLE_CGMS_FEAT_CGM_SAMPLE_LOCATION_SUBCUTANEOUS_TISSUE = 5, /**< Subcutaneous tissue */
    BLE_CGMS_FEAT_CGM_SAMPLE_LOCATION_SAMPLE_LOCATION_VALUE_NOT_AVAILABLE = 15,
    /**< Sample Location value not available */
} e_ble_cgms_feat_cgm_sample_location_t;

/****************************************************************************************************************************//**
 * @brief CGM Feature CGM Feature value structure.
*******************************************************************************************************************************/
typedef struct
{
    bool is_calibration_supported;

    /**< Calibration Supported */

    bool is_patient_high_low_alerts_supported;

    /**< Patient High/Low Alerts supported */

    bool is_hypo_alerts_supported; /**< Hypo Alerts supported */

    bool is_hyper_alerts_supported; /**< Hyper Alerts supported */

    bool is_rate_of_increase_decrease_alerts_supported;

    /**< Rate of Increase/Decrease Alerts supported */

    bool is_device_specific_alert_supported;

    /**< Device Specific Alert supported */

    bool is_sensor_malfunction_detection_supported;

    /**< Sensor Malfunction Detection supported */

    bool is_sensor_temperature_high_low_detection_supported;

    /**< Sensor Temperature High-Low Detection supported */

    bool is_sensor_result_high_low_detection_supported;

    /**< Sensor Result High-Low Detection supported */

    bool is_low_battery_detection_supported;

    /**< Low Battery Detection supported */

    bool is_sensor_type_error_detection_supported;

    /**< Sensor Type Error Detection supported */

    bool is_general_device_fault_supported;

    /**< General Device Fault supported */

    bool is_e2e_crc_supported;

    /**< E2E-CRC supported */

    bool is_multiple_bond_supported;

    /**< Multiple Bond supported */

    bool is_multiple_sessions_supported;

    /**< Multiple Sessions supported */

    bool is_cgm_trend_information_supported;

    /**< CGM Trend Information supported */

    bool is_cgm_quality_supported; /**< CGM Quality supported */

} st_ble_feat_cgm_feature_t;

/***************************************************************************************************************************//**
 * @brief CGM Feature value structure.
******************************************************************************************************************************/
typedef struct 
{
    st_ble_feat_cgm_feature_t cgm_feature; /**< CGM Feature */
    uint8_t cgm_type; /**< CGM Type */
    uint8_t cgm_sample_location; /**< CGM Sample Location */
    uint16_t e2e_crc; /**< E2E-CRC */
} st_ble_cgms_feat_t;

/*****************************************************************************************************************************//**
 * @brief     Set CGM Feature characteristic value to the local GATT database.
 * @param[in] p_value  Characteristic value to set.
 * @return    @ref ble_status_t
*********************************************************************************************************************************/
ble_status_t R_BLE_CGMS_SetFeat(const st_ble_cgms_feat_t *p_value);

/***************************************************************************//**
 * @brief     Get CGM Feature characteristic value from the local GATT database.
 * @param[in] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_CGMS_GetFeat(st_ble_cgms_feat_t *p_value);

/*----------------------------------------------------------------------------------------------------------------------
    CGM Status Characteristic
----------------------------------------------------------------------------------------------------------------------*/
/***************************************************************************//**
 * @brief CGM Status value structure.
*******************************************************************************/
typedef struct 
{
    uint16_t time_offset; /**< Time Offset */
    st_ble_meas_sensor_status_annunciation_t cgm_status; /**< CGM Status */
    uint16_t e2e_crc; /**< E2E-CRC */
} st_ble_cgms_status_t;

/***************************************************************************//**
 * @brief     Set CGM Status characteristic value to the local GATT database.
 * @param[in] p_value  Characteristic value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_CGMS_SetStatus(const st_ble_cgms_status_t *p_value);

/***************************************************************************//**
 * @brief     Get CGM Status characteristic value from the local GATT database.
 * @param[in] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_CGMS_GetStatus(st_ble_cgms_status_t *p_value);

/*----------------------------------------------------------------------------------------------------------------------
    CGM Session Start Time Characteristic
----------------------------------------------------------------------------------------------------------------------*/
/***************************************************************************//**
 * @brief CGM Session Start Time DST-Offset enumeration.
*******************************************************************************/
typedef enum 
{
    BLE_CGMS_SESSION_START_TIME_DST_OFFSET_STANDARD_TIME = 0,

    /**< Standard Time */

    BLE_CGMS_SESSION_START_TIME_DST_OFFSET_HALF_AN_HOUR_DAYLIGHT_TIME = 2,

    /**< Half An Hour Daylight Time (+0.5h) */

    BLE_CGMS_SESSION_START_TIME_DST_OFFSET_DAYLIGHT_TIME = 4,

    /**< Daylight Time (+1h) */

    BLE_CGMS_SESSION_START_TIME_DST_OFFSET_DOUBLE_DAYLIGHT_TIME = 8,

    /**< Double Daylight Time (+2h) */

} e_ble_cgms_session_start_time_dst_offset_t;

/***************************************************************************//**
 * @brief CGM Session Start Time value structure.
*******************************************************************************/
typedef struct 
{
    st_ble_date_time_t session_start_time; /**< Session Start Time */
    int8_t time_zone; /**< Time Zone */
    uint8_t dst_offset; /**< DST-Offset */
    uint16_t e2e_crc; /**< E2E-CRC */
} st_ble_cgms_session_start_time_t;

/*******************************************************************************************************************//**
 * @brief     Set CGM Session Start Time characteristic value to the local GATT database.
 * @param[in] p_value  Characteristic value to set.
 * @return    @ref ble_status_t
**********************************************************************************************************************/
ble_status_t R_BLE_CGMS_SetSessionStartTime(const st_ble_cgms_session_start_time_t *p_value);

/*********************************************************************************************************************//**
 * @brief     Get CGM Session Start Time characteristic value from the local GATT database.
 * @param[in] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*************************************************************************************************************************/
ble_status_t R_BLE_CGMS_GetSessionStartTime(st_ble_cgms_session_start_time_t *p_value);

/*----------------------------------------------------------------------------------------------------------------------
    CGM Session Run Time Characteristic
----------------------------------------------------------------------------------------------------------------------*/
/***************************************************************************//**
 * @brief CGM Session Run Time value structure.
*******************************************************************************/
typedef struct 
{
    uint16_t cgm_session_run_time; /**< CGM Session Run Time */
    uint16_t e2e_crc; /**< E2E-CRC */
} st_ble_cgms_session_run_time_t;

/********************************************************************************************************************//**
 * @brief     Set CGM Session Run Time characteristic value to the local GATT database.
 * @param[in] p_value  Characteristic value to set.
 * @return    @ref ble_status_t
***************************************************************************************************************************/
ble_status_t R_BLE_CGMS_SetSessionRunTime(const st_ble_cgms_session_run_time_t *p_value);

/*********************************************************************************************************************//**
 * @brief     Get CGM Session Run Time characteristic value from the local GATT database.
 * @param[in] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
**************************************************************************************************************************/
ble_status_t R_BLE_CGMS_GetSessionRunTime(st_ble_cgms_session_run_time_t *p_value);

/*----------------------------------------------------------------------------------------------------------------------
    Record Access Control Point Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/***************************************************************************//**
 * @brief Record Access Control Point Op Code enumeration.
*******************************************************************************/
typedef enum 
{
    BLE_CGMS_RECORD_ACCESS_CP_OP_CODE_REPORT_STORED_RECORDS = 1,

    /**< Report stored records (Operator: Value from Operator Table) */

    BLE_CGMS_RECORD_ACCESS_CP_OP_CODE_DELETE_STORED_RECORDS = 2,

    /**< Delete stored records (Operator: Value from Operator Table) */

    BLE_CGMS_RECORD_ACCESS_CP_OP_CODE_ABORT_OPERATION = 3,

    /**< Abort operation (Operator: Null 'value of 0x00 from Operator Table') */

    BLE_CGMS_RECORD_ACCESS_CP_OP_CODE_REPORT_NUMBER_OF_STORED_RECORDS = 4,

    /**< Report number of stored records (Operator: Value from Operator Table) */

    BLE_CGMS_RECORD_ACCESS_CP_OP_CODE_NUMBER_OF_STORED_RECORDS_RESPONSE = 5,

    /**< Number of stored records response (Operator: Null 'value of 0x00 from Operator Table') */

    BLE_CGMS_RECORD_ACCESS_CP_OP_CODE_RESPONSE_CODE = 6,

    /**< Response Code (Operator: Null 'value of 0x00 from Operator Table') */

} e_ble_cgms_record_access_cp_op_code_t;

/***************************************************************************//**
 * @brief Record Access Control Point Operator enumeration.
*******************************************************************************/
typedef enum 
{
    BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_NULL = 0, /**< Null */
    BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_ALL_RECORDS = 1, /**< All records */
    BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_LESS_THAN_OR_EQUAL_TO = 2,

    /**< Less than or equal to */

    BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_GREATER_THAN_OR_EQUAL_TO = 3,

    /**< Greater than or equal to */

    BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_WITHIN_RANGE_OF = 4,

    /**< Within range of (inclusive) */

    BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_FIRST_RECORD = 5,

    /**< First record(i.e. oldest record) */

    BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_LAST_RECORD = 6,

    /**< Last record (i.e. most recent record) */

} e_ble_cgms_record_access_cp_operator_t;

/***************************************************************************//**
 * @brief Record Access Control Point Operand enumeration.
*******************************************************************************/
typedef enum 
{
    BLE_CGMS_RECORD_ACCESS_CP_OPERAND_FILTER_PARAMETERS_1 = 1,

    /**< Filter parameters (as appropriate to Operator and Service) */

    BLE_CGMS_RECORD_ACCESS_CP_OPERAND_FILTER_PARAMETERS_2 = 2,

    /**< Filter parameters (as appropriate to Operator and Service) */

    BLE_CGMS_RECORD_ACCESS_CP_OPERAND_NOT_INCLUDED = 3,

    /**< Not included */

    BLE_CGMS_RECORD_ACCESS_CP_OPERAND_FILTER_PARAMETERS_4 = 4,

    /**< Filter parameters (as appropriate to Operator and Service) */

    BLE_CGMS_RECORD_ACCESS_CP_OPERAND_NUMBER_OF_RECORDS = 5,

    /**< Number of Records (Field size defined per service) */

    BLE_CGMS_RECORD_ACCESS_CP_OPERAND_REQUEST_OP_CODE__RESPONSE_CODE_VALUE = 6,

    /**< Request Op Code, Response Code Value */

} e_ble_cgms_record_access_cp_operand_t;

/***************************************************************************//**
 * @brief Record Access Control Point Response Code enumeration.
*******************************************************************************/
typedef enum 
{
    BLE_CGMS_RECORD_ACCESS_CP_RESPONSE_CODE_SUCCESS = 1,

    /**< Normal response for successful operation */

    BLE_CGMS_RECORD_ACCESS_CP_RESPONSE_CODE_OP_CODE_NOT_SUPPORTED = 2,

    /**< Normal response if unsupported Op Code is received */

    BLE_CGMS_RECORD_ACCESS_CP_RESPONSE_CODE_INVALID_OPERATOR = 3,

    /**< Normal response if Operator received does not meet the requirements 

    of the service (e.g. Null was expected) */

    BLE_CGMS_RECORD_ACCESS_CP_RESPONSE_CODE_OPERATOR_NOT_SUPPORTED = 4,

    /**< Normal response if unsupported Operator is received */

    BLE_CGMS_RECORD_ACCESS_CP_RESPONSE_CODE_INVALID_OPERAND = 5,

    /**< Normal response if Operand received does not meet the requirements of the service */

    BLE_CGMS_RECORD_ACCESS_CP_RESPONSE_CODE_NO_RECORDS_FOUND = 6,

    /**< Normal response if request to report stored records or request to
        delete stored records resulted in no records meeting criteria. */

    BLE_CGMS_RECORD_ACCESS_CP_RESPONSE_CODE_ABORT_UNSUCCESSFUL = 7,

    /**< Normal response if request for Abort cannot be completed */

    BLE_CGMS_RECORD_ACCESS_CP_RESPONSE_CODE_PROCEDURE_NOT_COMPLETED = 8,

    /**< Normal response if unable to complete a procedure for any reason */

    BLE_CGMS_RECORD_ACCESS_CP_OP_CODE_RESPONSE_CODE_9 = 9,

    /**< Normal response if unsupported Operand is received */

} e_ble_cgms_record_access_cp_response_code_t;

/***************************************************************************//**
 * @brief Record Access Control Point Filtrer Type enumeration.
*******************************************************************************/
typedef enum 
{
    BLE_CGMS_RA_CTRL_PT_FILTER_TYPE_TIME_OFFSET      = 1,
    BLE_CGMS_RA_CTRL_PT_FILTER_TYPE_USER_FACING_TIME = 2,
} e_ble_cgms_cgm_ra_ctrl_pt_filter_type_t;

/***************************************************************************//**
 * @brief Record Access Control Point value structure.
*******************************************************************************/
typedef struct 
{
    uint8_t op_code; /**< Op Code */
    uint8_t racp_operator; /**< Operator */
    uint8_t operand[18]; /**< Operand */
    uint8_t operand_len; /**< operand length */
} st_ble_cgms_record_access_cp_t;

/*******************************************************************************************************************//**
 * @brief     Send indication of  Record Access Control Point characteristic value to the remote device.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value  Characteristic value to send.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_CGMS_IndicateRecordAccessCp(uint16_t conn_hdl, const st_ble_cgms_record_access_cp_t *p_value);

/*******************************************************************************************************************//**
 * @brief     Set Record Access Control Point cli cnfg descriptor value to the local GATT database.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
**********************************************************************************************************************/
ble_status_t R_BLE_CGMS_SetRecordAccessCpCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/*******************************************************************************************************************//**
 * @brief     Get Record Access Control Point cli cnfg descriptor value from the local GATT database.
 * @param[in] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
**********************************************************************************************************************/
ble_status_t R_BLE_CGMS_GetRecordAccessCpCliCnfg(uint16_t conn_hdl, uint16_t *p_value);

/*----------------------------------------------------------------------------------------------------------------------
    CGM Specific Ops Control Point Characteristic
----------------------------------------------------------------------------------------------------------------------*/

      
/****************************************************************************************************//**
 * @brief CGM Specific Ops Control Point Op Code enumeration.
**********************************************************************************************************/
typedef enum 
{
    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_SET_CGM_COMMUNICATION_INTERVAL = 1, 

    /**< Set CGM Communication Interval */

    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_GET_CGM_COMMUNICATION_INTERVAL = 2, 

    /**< Get CGM Communication Interval */

    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_CGM_COMMUNICATION_INTERVAL_RESPONSE = 3, 

    /**< CGM Communication Interval response */

    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_SET_GLUCOSE_CALIBRATION_VALUE = 4,

    /**< Set Glucose Calibration Value */

    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_GET_GLUCOSE_CALIBRATION_VALUE = 5, 

    /**< Get Glucose Calibration Value */

    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_GLUCOSE_CALIBRATION_VALUE_RESPONSE = 6, 

    /**< Glucose Calibration Value response */

    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_SET_PATIENT_HIGH_ALERT_LEVEL = 7,

    /**< Set Patient High Alert Level */

    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_GET_PATIENT_HIGH_ALERT_LEVEL = 8, 

    /**< Get Patient High Alert Level */

    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_PATIENT_HIGH_ALERT_LEVEL_RESPONSE = 9, 

    /**< Patient High Alert Level Response */

    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_SET_PATIENT_LOW_ALERT_LEVEL = 10,

    /**< Set Patient Low Alert Level */

    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_GET_PATIENT_LOW_ALERT_LEVEL = 11, 

    /**< Get Patient Low Alert Level */

    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_PATIENT_LOW_ALERT_LEVEL_RESPONSE = 12,

    /**< Patient Low Alert Level Response */

    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_SET_HYPO_ALERT_LEVEL = 13,

    /**< Set Hypo Alert Level */

    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_GET_HYPO_ALERT_LEVEL = 14, 

    /**< Get Hypo Alert Level */

    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_HYPO_ALERT_LEVEL_RESPONSE = 15,

    /**< Hypo Alert Level Response */

    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_SET_HYPER_ALERT_LEVEL = 16,

    /**< Set Hyper Alert Level */

    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_GET_HYPER_ALERT_LEVEL = 17,

    /**< Get Hyper Alert Level */

    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_HYPER_ALERT_LEVEL_RESPONSE = 18,

    /**< Hyper Alert Level Response */

    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_SET_RATE_OF_DECREASE_ALERT_LEVEL = 19,

    /**< Set Rate of Decrease Alert Level */

    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_GET_RATE_OF_DECREASE_ALERT_LEVEL = 20,

    /**< Get Rate of Decrease Alert Level */

    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_RATE_OF_DECREASE_ALERT_LEVEL_RESPONSE = 21,

    /**< Rate of Decrease Alert Level Response */

    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_SET_RATE_OF_INCREASE_ALERT_LEVEL = 22,

    /**< Set Rate of Increase Alert Level */

    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_GET_RATE_OF_INCREASE_ALERT_LEVEL = 23,

    /**< Get Rate of Increase Alert Level */

    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_RATE_OF_INCREASE_ALERT_LEVEL_RESPONSE = 24,

    /**< Rate of Increase Alert Level Response */

    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_RESET_DEVICE_SPECIFIC_ALERT = 25,

    /**< Reset Device Specific Alert */

    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_START_THE_SESSION = 26,

    /**< Start the Session */

    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_STOP_THE_SESSION = 27,

    /**< Stop the Session */

    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_RESPONSE_CODE = 28,

    /**< Response Code */

} e_ble_cgms_specific_ops_cp_op_code_t;

/***********************************************************************************************//**
 * @brief CGM Specific Ops Control Point Op Code - Response Codes enumeration.
**************************************************************************************************/
typedef enum 
{
    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_RESPONSE_CODES_SUCCESS = 1,

    /**< Success */

    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_RESPONSE_CODES_OP_CODE_NOT_SUPPORTED = 2,

    /**< Op Code not supported */

    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_RESPONSE_CODES_INVALID_OPERAND = 3,

    /**< Invalid Operand */

    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_RESPONSE_CODES_PROCEDURE_NOT_COMPLETED = 4, 

    /**< Procedure not completed */

    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_RESPONSE_CODES_PARAMETER_OUT_OF_RANGE = 5, 

    /**< Parameter out of range */

} e_ble_cgms_specific_ops_cp_op_code_response_codes_t;

/******************************************************************************************************************//**
 * @brief CGM Specific Ops Control Point Operand enumeration.
*******************************************************************************************************************/
typedef enum 
{
    BLE_CGMS_SPECIFIC_OPS_CP_OPERAND_COMMUNICATION_INTERVAL_IN_MINUTES_1 = 1,

    /**< Communication interval in minutes */

    BLE_CGMS_SPECIFIC_OPS_CP_OPERAND_COMMUNICATION_INTERVAL_IN_MINUTES_2 = 3, 

    /**< Communication Interval in minutes */

    BLE_CGMS_SPECIFIC_OPS_CP_OPERAND_OPERAND_VALUE_AS_DEFINED_IN_THE_CALIBRATION_VALUE_FIELDS_ = 4, 

    /**< Operand value as defined in the Calibration Value Fields. */

    BLE_CGMS_SPECIFIC_OPS_CP_OPERAND_CALIBRATION_DATA_RECORD_NUMBER = 5,

    /**< Calibration Data Record Number */

    BLE_CGMS_SPECIFIC_OPS_CP_OPERAND_CALIBRATION_DATA = 6,

    /**< Calibration Data */

    BLE_CGMS_SPECIFIC_OPS_CP_OPERAND_PATIENT_HIGH_BG_VALUE_IN_MG_DL_1 = 7,

    /**< Patient High bG value in mg/dL */

    BLE_CGMS_SPECIFIC_OPS_CP_OPERAND_PATIENT_HIGH_BG_VALUE_IN_MG_DL_2 = 9,

    /**< Patient High bG value in mg/dL */

    BLE_CGMS_SPECIFIC_OPS_CP_OPERAND_PATIENT_LOW_BG_VALUE_IN_MG_DL_1 = 10,

    /**< Patient Low bG value in mg/dL */

    BLE_CGMS_SPECIFIC_OPS_CP_OPERAND_PATIENT_LOW_BG_VALUE_IN_MG_DL_2 = 12,

    /**< Patient Low bG value in mg/dL */

    BLE_CGMS_SPECIFIC_OPS_CP_OPERAND_HYPO_ALERT_LEVEL_VALUE_IN_MG_DL_1 = 13,

    /**< Hypo Alert Level value in mg/dL */

    BLE_CGMS_SPECIFIC_OPS_CP_OPERAND_HYPO_ALERT_LEVEL_VALUE_IN_MG_DL_2 = 15,

    /**< Hypo Alert Level value in mg/dL */

    BLE_CGMS_SPECIFIC_OPS_CP_OPERAND_HYPER_ALERT_LEVEL_VALUE_IN_MG_DL_1 = 16,

    /**< Hyper Alert Level value in mg/dL */

    BLE_CGMS_SPECIFIC_OPS_CP_OPERAND_HYPER_ALERT_LEVEL_VALUE_IN_MG_DL_2 = 18,

    /**< Hyper Alert Level value in mg/dL */

    BLE_CGMS_SPECIFIC_OPS_CP_OPERAND_RATE_OF_DECREASE_ALERT_LEVEL_VALUE_IN_MG_DL_MIN_1 = 19,

    /**< Rate of Decrease Alert Level value in mg/dL/min */

    BLE_CGMS_SPECIFIC_OPS_CP_OPERAND_RATE_OF_DECREASE_ALERT_LEVEL_VALUE_IN_MG_DL_MIN_2 = 21,

    /**< Rate of Decrease Alert Level value in mg/dL/min */

    BLE_CGMS_SPECIFIC_OPS_CP_OPERAND_RATE_OF_INCREASE_ALERT_LEVEL_VALUE_IN_MG_DL_MIN_1 = 22,

    /**< Rate of Increase Alert Level value in mg/dL/min */

    BLE_CGMS_SPECIFIC_OPS_CP_OPERAND_RATE_OF_INCREASE_ALERT_LEVEL_VALUE_IN_MG_DL_MIN_2 = 24,

    /**< Rate of Increase Alert Level value in mg/dL/min */

    BLE_CGMS_SPECIFIC_OPS_CP_OPERAND_REQUEST_OP_CODE__RESPONSE_CODE_VALUE = 28,

    /**< Request Op Code, Response Code Value */

} e_ble_cgms_specific_ops_cp_operand_t;

/********************************************************************************************************************//**
 * @brief CGM Specific Ops Control Point Calibration Value - Calibration Status value structure.
*************************************************************************************************************************/
typedef struct 
{
    bool is_calibration_data_rejected; /**< Calibration Data rejected (Calibration failed) */
    bool is_calibration_data_out_of_range; /**< Calibration Data out of range */
    bool is_calibration_process_pending; /**< Calibration Process Pending */
} st_ble_specific_ops_cp_calibration_value_calibration_status_t;

/*******************************************************************************************************************//**
 * @brief CGM Specific Ops Control Point value structure.
*************************************************************************************************************************/
typedef struct 
{
    st_ble_ieee11073_sfloat_t calibration_value_glucose_concentration_of_calibration;

    /**< Calibration Value - Glucose Concentration of Calibration */

    uint16_t calibration_value_calibration_time;

    /**< Calibration Value - Calibration Time */

    uint8_t calibration_value_calibration_type;

    /**< Calibration Value - Calibration Type */

    uint8_t calibration_value_calibration_sample_location;

    /**< Calibration Value - Calibration Sample Location */

    uint16_t calibration_value_next_calibration_time;

    /**< Calibration Value - Next Calibration Time */

    uint16_t calibration_value_calibration_data_record_number;

    /**< Calibration Value - Calibration Data Record Number */

    st_ble_specific_ops_cp_calibration_value_calibration_status_t calibration_value_calibration_status;

    /**< Calibration Value - Calibration Status */

} st_ble_cgms_calibration_data_record_t;

/*******************************************************************************************************************//**
 * @brief CGM Specific Ops Control Point value structure.
*************************************************************************************************************************/
typedef struct 
{
    uint8_t op_code; /**< Op Code */
    uint8_t op_code_response_codes; /**< Op Code - Response Codes */
    uint8_t operand; /**< operand */
    uint16_t e2e_crc; /**< E2E-CRC */
    st_ble_cgms_calibration_data_record_t calibration_data_record;
} st_ble_cgms_specific_ops_cp_t;

/**********************************************************************************************************************//**
 * @brief     Send indication of  CGM Specific Ops Control Point characteristic value to the remote device.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value  Characteristic value to send.
 * @return    @ref ble_status_t
*****************************************************************************************************************************/
ble_status_t R_BLE_CGMS_IndicateSpecificOpsCp(uint16_t conn_hdl, const st_ble_cgms_specific_ops_cp_t *p_value);

/************************************************************************************************************************//**
 * @brief     Set CGM Specific Ops Control Point cli cnfg descriptor value to the local GATT database.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
****************************************************************************************************************************/
ble_status_t R_BLE_CGMS_SetSpecificOpsCpCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/*************************************************************************************************************************//**
 * @brief     Get CGM Specific Ops Control Point cli cnfg descriptor value from the local GATT database.
 * @param[in] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************************************************************/
ble_status_t R_BLE_CGMS_GetSpecificOpsCpCliCnfg(uint16_t conn_hdl, uint16_t *p_value);

/*----------------------------------------------------------------------------------------------------------------------
    Continuous Glucose Monitoring Service
----------------------------------------------------------------------------------------------------------------------*/

/*******************************************************************************************************************//**
 * @brief If E2E-CRC is supported and a Write procedure is processed without CRC attached 
***********************************************************************************************************************/
#define BLE_CGMS_MISSING_CRC_ERROR (BLE_ERR_GROUP_GATT | 0x80)

/******************************************************************************************************************//**
 * @brief If E2E-CRC is supported and a Write procedure is processed with incorrect or invalid CRC value attached
**********************************************************************************************************************/
#define BLE_CGMS_INVALID_CRC_ERROR (BLE_ERR_GROUP_GATT | 0x81)

/******************************************************************************************************************//**
 * @brief Continuous Glucose Monitoring characteristic Index.
**********************************************************************************************************************/
typedef enum 
{
    BLE_CGMS_MEAS_IDX,
    BLE_CGMS_MEAS_CLI_CNFG_IDX,
    BLE_CGMS_FEAT_IDX,
    BLE_CGMS_STATUS_IDX,
    BLE_CGMS_SESSION_START_TIME_IDX,
    BLE_CGMS_SESSION_RUN_TIME_IDX,
    BLE_CGMS_RECORD_ACCESS_CP_IDX,
    BLE_CGMS_RECORD_ACCESS_CP_CLI_CNFG_IDX,
    BLE_CGMS_SPECIFIC_OPS_CP_IDX,
    BLE_CGMS_SPECIFIC_OPS_CP_CLI_CNFG_IDX,
} e_ble_cgms_char_idx_t;

/************************************************************************************************************************//**
 * @brief Continuous Glucose Monitoring event type.
****************************************************************************************************************************/
typedef enum
{
    /* CGM Measurement */
    BLE_CGMS_EVENT_MEAS_CLI_CNFG_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_CGMS_MEAS_CLI_CNFG_IDX, BLE_SERVS_WRITE_REQ),
    BLE_CGMS_EVENT_MEAS_CLI_CNFG_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_CGMS_MEAS_CLI_CNFG_IDX, BLE_SERVS_WRITE_COMP),
    BLE_CGMS_EVENT_MEAS_CLI_CNFG_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_CGMS_MEAS_CLI_CNFG_IDX, BLE_SERVS_READ_REQ),

    /* CGM Feature */
    BLE_CGMS_EVENT_FEAT_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_CGMS_FEAT_IDX, BLE_SERVS_READ_REQ),

    /* CGM Status */
    BLE_CGMS_EVENT_STATUS_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_CGMS_STATUS_IDX, BLE_SERVS_READ_REQ),

    /* CGM Session Start Time */
    BLE_CGMS_EVENT_SESSION_START_TIME_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_CGMS_SESSION_START_TIME_IDX, BLE_SERVS_WRITE_REQ),
    BLE_CGMS_EVENT_SESSION_START_TIME_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_CGMS_SESSION_START_TIME_IDX, BLE_SERVS_WRITE_COMP),
    BLE_CGMS_EVENT_SESSION_START_TIME_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_CGMS_SESSION_START_TIME_IDX, BLE_SERVS_READ_REQ),

    /* CGM Session Run Time */
    BLE_CGMS_EVENT_SESSION_RUN_TIME_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_CGMS_SESSION_RUN_TIME_IDX, BLE_SERVS_READ_REQ),

    /* Record Access Control Point */
    BLE_CGMS_EVENT_RECORD_ACCESS_CP_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_CGMS_RECORD_ACCESS_CP_IDX, BLE_SERVS_WRITE_REQ),
    BLE_CGMS_EVENT_RECORD_ACCESS_CP_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_CGMS_RECORD_ACCESS_CP_IDX, BLE_SERVS_WRITE_COMP),
    BLE_CGMS_EVENT_RECORD_ACCESS_CP_HDL_VAL_CNF = BLE_SERVS_ATTR_EVENT(BLE_CGMS_RECORD_ACCESS_CP_IDX, BLE_SERVS_HDL_VAL_CNF),
    BLE_CGMS_EVENT_RECORD_ACCESS_CP_CLI_CNFG_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_CGMS_RECORD_ACCESS_CP_CLI_CNFG_IDX, BLE_SERVS_WRITE_REQ),
    BLE_CGMS_EVENT_RECORD_ACCESS_CP_CLI_CNFG_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_CGMS_RECORD_ACCESS_CP_CLI_CNFG_IDX, BLE_SERVS_WRITE_COMP),
    BLE_CGMS_EVENT_RECORD_ACCESS_CP_CLI_CNFG_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_CGMS_RECORD_ACCESS_CP_CLI_CNFG_IDX, BLE_SERVS_READ_REQ),

    /* CGM Specific Ops Control Point */
    BLE_CGMS_EVENT_SPECIFIC_OPS_CP_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_CGMS_SPECIFIC_OPS_CP_IDX, BLE_SERVS_WRITE_REQ),
    BLE_CGMS_EVENT_SPECIFIC_OPS_CP_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_CGMS_SPECIFIC_OPS_CP_IDX, BLE_SERVS_WRITE_COMP),
    BLE_CGMS_EVENT_SPECIFIC_OPS_CP_HDL_VAL_CNF = BLE_SERVS_ATTR_EVENT(BLE_CGMS_SPECIFIC_OPS_CP_IDX, BLE_SERVS_HDL_VAL_CNF),
    BLE_CGMS_EVENT_SPECIFIC_OPS_CP_CLI_CNFG_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_CGMS_SPECIFIC_OPS_CP_CLI_CNFG_IDX, BLE_SERVS_WRITE_REQ),
    BLE_CGMS_EVENT_SPECIFIC_OPS_CP_CLI_CNFG_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_CGMS_SPECIFIC_OPS_CP_CLI_CNFG_IDX, BLE_SERVS_WRITE_COMP),
    BLE_CGMS_EVENT_SPECIFIC_OPS_CP_CLI_CNFG_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_CGMS_SPECIFIC_OPS_CP_CLI_CNFG_IDX, BLE_SERVS_READ_REQ),
} e_ble_cgms_event_t;

/*******************************************************************************************************************************//**
 * @brief     Initialize Continuous Glucose Monitoring service.
 * @param[in] cb Service callback.
 * @return    @ref ble_status_t
***********************************************************************************************************************************/
ble_status_t R_BLE_CGMS_Init(ble_servs_app_cb_t cb);

/******************************************************************************************************************************//**
 * @brief     Adds a new record to the record database.
 * @param[in] p_measurement Glucose Measurement characteristic value
 * @param[in] p_context Glucose Measurement context characteristic value
 * @return    @ref ble_status_t
**********************************************************************************************************************************/
ble_status_t R_BLE_CGMS_AddNewRecord(st_ble_cgms_meas_t *p_meas);

#endif /* R_BLE_CGMS_H */

/** @} */
