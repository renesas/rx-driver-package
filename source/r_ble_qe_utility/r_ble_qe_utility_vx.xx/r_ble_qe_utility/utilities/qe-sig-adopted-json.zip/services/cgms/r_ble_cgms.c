/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************//**
 * File Name: r_ble_cgms.c
 * Version : 1.0
 * Description : The source file for Continuous Glucose Monitoring server.
 **********************************************************************************************************************/
 /************************************************************************************************************************//**
 * History : DD.MM.YYYY Version Description
 *         : 24.05.2019 1.00 First Release
 ***********************************************************************************************************************/
#include <string.h>
#include "r_ble_rx23w_if.h"
#include "r_ble_cgms.h"
#include "r_ble_cgms_record.h"
#include "profile_cmn/r_ble_servs_if.h"
#include "gatt_db.h"

/*******************************************************************************************************************//**
* @brief Control Point Event ID
***********************************************************************************************************************/
#define BLE_RSCS_PRV_CGMP_EVENT_ID                                                         (11)
#define BLE_CGMS_PRV_CGM_SESSION_START_TIME_INVALID_TIME_ZONE                              (126)

/*----------------------------------------------------------------------------------------------------------------------
    CGM Measurement FLAGS
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_CGMS_PRV_CGM_MEASUREMENT_FLAG_CGM_TREND_INFORMATION_PRESENT                                   (1 << 0)
#define BLE_CGMS_PRV_CGM_MEASUREMENT_FLAG_CGM_QUALITY_PRESENT                                             (1 << 1)
#define BLE_CGMS_PRV_CGM_MEASUREMENT_FLAG_CGM_SENSOR_STATUS_ANNUNCIATION_FIELD_WARNING_OCTECT_PRESENT     (1 << 5)
#define BLE_CGMS_PRV_CGM_MEASUREMENT_FLAG_CGM_SENSOR_STATUS_ANNUNCIATION_FIELD_CAL_TEMP_OCTECT_PRESENT    (1 << 6)
#define BLE_CGMS_PRV_CGM_MEASUREMENT_FLAG_CGM_SENSOR_STATUS_ANNUCIATION_FIELD_STATUS_OCTECT_PRESENT       (1 << 7)
#define BLE_CGMS_PRV_START_SESSION_RESPONSE                                                               (92)
#define BLE_CGMS_PRV_RATE_OF_INCREASE_ALERT_RESPONSE                                                      (85)
#define BLE_CGMS_PRV_LOW_ALERT_RESPONSE                                                                   (54)
#define BLE_CGMS_PRV_CALIBRATION_VALUE_RESPONSE                                                           (78)
#define BLE_CGMS_PRV_RESPONSE_CODE_TWO                                                                    (2)
#define BLE_CGMS_PRV_RESPONSE_CODE_FE                                                                     (254)

/*----------------------------------------------------------------------------------------------------------------------
     CGM Measurement Sensor Status Annunciation
 ----------------------------------------------------------------------------------------------------------------------*/
#define BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SESSION_STOPPED                                             (1 << 0)
#define BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_DEVICE_BATTERY_LOW                                          (1 << 1)
#define BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_TYPE_INCORRECT_FOR_DEVICE                            (1 << 2)
#define BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_MALFUNCTION                                          (1 << 3)
#define BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_DEVICE_SPECIFIC_ALERT                                       (1 << 4)
#define BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_GENERAL_DEVICE_FAULT_HAS_OCCURED_IN_THE_SENSOR              (1 << 5)
#define BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_TIME_SYNCHRONIZATION_BETWEEN_SENSOR_AND_COLLECTOR_REQUIRED  (1 << 8)
#define BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_CALIBRATION_NOT_ALLOWED                                     (1 << 9)
#define BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_CALIBRATION_RECOMMENDED                                     (1 << 10)
#define BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_CALIBRATION_REQUIRED                                        (1 << 11)
#define BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_TEMP_TOO_HIGH_FOR_VALID_TEST_RESULT_AT_MEASUREMENT   (1 << 12)
#define BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_TEMP_TOO_LOW_FOR_VALID_TEST_RESULT_AT_MEASUREMENT    (1 << 13)
#define BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_LOWER_THAN_THE_PATIENT_LOW_LEVEL              (1 << 16)
#define BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_HIGHER_THAN_THE_PATIENT_HIGH_LEVEL            (1 << 17)
#define BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_LOWER_THAN_HYPO_LEVEL                         (1 << 18)
#define BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_HIGHER_THAN_HYPER_LEVEL                       (1 << 19)
#define BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RATE_OF_DECREASE_EXCEEDED                            (1 << 20)
#define BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RATE_OF_INCREASE_EXCEEDED                            (1 << 21)
#define BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_LOWER_THAN_DEVICE_CAN_PROCESS                 (1 << 22)
#define BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_HIGHER_THAN_DEVICE_CAN_PROCESS                (1 << 23)

 /*----------------------------------------------------------------------------------------------------------------------
     CGM Measurement Features
 ----------------------------------------------------------------------------------------------------------------------*/
#define BLE_CGMS_PRV_CGM_FEATURES_CALIBRATION_SUPPORTED                                      (1 << 0)
#define BLE_CGMS_PRV_CGM_FEATURES_PATIENT_HIGH_LOW_ALERTS_SUPPORTED                          (1 << 1)
#define BLE_CGMS_PRV_CGM_FEATURES_HYPO_ALERTS_SUPPORTED                                      (1 << 2)
#define BLE_CGMS_PRV_CGM_FEATURES_HYPER_ALERTS_SUPPORTED                                     (1 << 3)
#define BLE_CGMS_PRV_CGM_FEATURES_RATE_OF_INCREASE_DECREASE_ALERTS_SUPPORTED                 (1 << 4)
#define BLE_CGMS_PRV_CGM_FEATURES_DEVICE_SPECIFIC_ALERTS_SUPPORTED                           (1 << 5)
#define BLE_CGMS_PRV_CGM_FEATURES_SENSOR_MALFUNCTION_DETECTION_SUPPORTED                     (1 << 6)
#define BLE_CGMS_PRV_CGM_FEATURES_SENSOR_TEMPERATURE_HIGH_LOW_DETECTION_SUPPORTED            (1 << 7)
#define BLE_CGMS_PRV_CGM_FEATURES_SENSOR_RESULT_HIGH_LOW_DETECTION_SUPPORTED                 (1 << 8)
#define BLE_CGMS_PRV_CGM_FEATURES_LOW_BATTERY_DETECTION_SUPPORTED                            (1 << 9)
#define BLE_CGMS_PRV_CGM_FEATURES_SENSOR_TYPE_ERROR_DETECTION_SUPPORTED                      (1 << 10)
#define BLE_CGMS_PRV_CGM_FEATURES_GENERAL_DEVICE_FAULT_SUPPORTED                             (1 << 11)
#define BLE_CGMS_PRV_CGM_FEATURES_E2E_CRC_SUPPORTED                                          (1 << 12)
#define BLE_CGMS_PRV_CGM_FEATURES_MULTIPLE_BOND_SUPPORTED                                    (1 << 13)
#define BLE_CGMS_PRV_CGM_FEATURES_MULTIPLE_SESSIONS_SUPPORTED                                (1 << 14)
#define BLE_CGMS_PRV_CGM_FEATURES_CGM_TREND_INFORMATION_SUPPORTED                            (1 << 15)
#define BLE_CGMS_PRV_CGM_FEATURES_CGM_QUALITY_SUPPORTED                                      (1 << 16)

 /***************************************************************************//**
 CGM Specific Ops Control Point Calibration Value - Calibration Status value structure.
 *******************************************************************************/
#define BLE_CGMS_PRV_CGM_SPECIFIC_CP_CAL_VALUE_CAL_STATUS_CAL_DATA_REJECTED_OR_CAL_FAILED       (1 << 0)
#define BLE_CGMS_PRV_CGM_SPECIFIC_CP_CAL_VALUE_CAL_STATUS_CAL_DATA_OUT_OFF_RANGE                (1 << 1)
#define BLE_CGMS_PRV_CGM_SPECIFIC_CP_CAL_VALUE_CAL_STATUS_CAL_DATA_PROCESS_PENDING              (1 << 2)

 /***************************************************************************//**
 CGM Characteristics Lengths
 *******************************************************************************/
#define BLE_CGMS_PRV_CGM_MEASUREMENT_LEN      (15)
#define BLE_CGMS_PRV_CGM_FEATURES_LEN         (06)
#define BLE_CGMS_PRV_CGM_SESSION_START_LEN    (11)
#define BLE_CGMS_PRV_CGM_SESSION_RUN_LEN      (04)
#define BLE_CGMS_PRV_CGM_SPECIFIC_CP_LEN      (18)

static uint8_t                            gs_num_of_records;
static bool                               gs_report_num_of_stored_records_flag;
static uint8_t                            gs_num_of_delete;
static ble_servs_app_cb_t                 gs_cgms_cb;
static st_ble_cgms_record_access_cp_t     gs_cgms_record_access_cp;
static st_ble_cgms_specific_ops_cp_t      gs_specific_ops_cp;
static st_ble_servs_info_t                gs_servs_info;
static uint16_t                           gs_conn_hdl;
static st_ble_cgms_feat_t                 cgm_features;
static bool                               gs_is_racp_in_progress;
static uint8_t                            gs_num_of_sent;
static uint16_t                           gs_index;
static uint16_t e2e_crc_calculation(uint8_t* meassage, uint16_t length);
static st_ble_cgms_calibration_data_record_t gs_socp_calibration_data;
static bool gs_crc_error = 0;
static void cgms_racp_cb(void);
static ble_status_t e2e_crc_check(uint8_t *meassage, uint8_t length, uint16_t rec_crc);
static ble_status_t cgm_notify_record(uint16_t conn_hdl, st_ble_cgms_record_t *p_record);
static ble_status_t cgm_send_ra_ctrl_pt_resp(uint16_t conn_hdl, 
                                             uint8_t op_code, 
                                             uint8_t req_op_code,
                                             uint8_t resp_code,
                                             uint16_t param);

static st_ble_cgms_status_t cgm_status =
{
    .time_offset = 0x0001,
    .cgm_status =
    {
        .is_session_stopped                                                             = false,
        .is_device_battery_low                                                          = false,
        .is_sensor_type_incorrect_for_device                                            = false,
        .is_sensor_malfunction                                                          = false,
        .is_device_specific_alert                                                       = false,
        .is_general_device_fault_has_occurred_in_the_sensor                             = false,
        .is_time_synchronization_between_sensor_and_collector_required                  = true,
        .is_calibration_not_allowed                                                     = false,
        .is_calibration_recommended                                                     = false,
        .is_calibration_required                                                        = true,
        .is_sensor_temperature_too_high_for_valid_test_result_at_time_of_measurement    = false,
        .is_sensor_temperature_too_low_for_valid_test_result_at_time_of_measurement     = false,
        .is_sensor_result_lower_than_the_patient_low_level                              = true,
        .is_sensor_result_higher_than_the_patient_high_level                            = true,
        .is_sensor_result_lower_than_the_hypo_level                                     = true,
        .is_sensor_result_higher_than_the_hyper_level                                   = true,
        .is_sensor_rate_of_decrease_exceeded                                            = true,
        .is_sensor_rate_of_increase_exceeded                                            = true,
        .is_sensor_result_lower_than_the_device_can_process                             = false,
        .is_sensor_result_higher_than_the_device_can_process                            = false,
    },
    .e2e_crc = 0x0001,
};

/*----------------------------------------------------------------------------------------------------------------------
    CGM Measurement Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

static const st_ble_servs_desc_info_t gs_meas_cli_cnfg =
{
    .attr_hdl = BLE_CGMS_MEAS_CLI_CNFG_DESC_HDL,
    .app_size = sizeof(uint16_t),
    .desc_idx = BLE_CGMS_MEAS_CLI_CNFG_IDX,
    .db_size  = BLE_CGMS_MEAS_CLI_CNFG_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_uint16_t,
    .encode   = (ble_servs_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_CGMS_SetMeasCliCnfg(uint16_t conn_hdl, const uint16_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_meas_cli_cnfg, conn_hdl, (const void *)p_value);
}

ble_status_t R_BLE_CGMS_GetMeasCliCnfg(uint16_t conn_hdl, uint16_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_meas_cli_cnfg, conn_hdl, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    CGM Measurement characteristic
----------------------------------------------------------------------------------------------------------------------*/
/***********************************************************************************************************************//**
* Function Name: decode_st_ble_cgms_meas_t
* Description  : This function converts CGM Measurement characteristic value representation in
*                GATT (uint8_t[]) to representation in application layer (struct).
* Arguments    : p_app_value - pointer to the CGM Measurement value in the application layer
*                p_gatt_value - pointer to the characteristic value in the GATT database
* Return Value : ble_status_t
**********************************************************************************************************************/
static ble_status_t decode_st_ble_cgms_meas_t(st_ble_cgms_meas_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos           = 1;
    uint8_t feature_byte0 = 0;
    uint32_t flag_1       = 0;

    if (BLE_CGMS_PRV_CGM_MEASUREMENT_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    memset((uint8_t*)p_app_value, 0x00, sizeof(*p_app_value));

    BT_UNPACK_LE_1_BYTE(&feature_byte0, &p_gatt_value->p_value[0]);

    /*Copy the size*/
    BT_UNPACK_LE_2_BYTE(&p_app_value->size, &p_gatt_value->p_value[pos]);

    pos += 1;

    /*Copy the cgm_glucose_concentration*/
    BT_UNPACK_LE_2_BYTE(&p_app_value->cgm_glucose_concentration.mantissa, &p_gatt_value->p_value[pos]);
    p_app_value->cgm_glucose_concentration.exponent = (int8_t)(((int16_t)p_app_value->cgm_glucose_concentration.mantissa) >> 12);
    p_app_value->cgm_glucose_concentration.mantissa = (int16_t)(p_app_value->cgm_glucose_concentration.mantissa & 0x0FFF);

    pos += 2;

    /*Copy the cgm_glucose_concentration*/
    BT_UNPACK_LE_2_BYTE(&p_app_value->time_offset, &p_gatt_value->p_value[pos]);

    pos += 2;

    /* sensor_status_annunciation */
    BT_UNPACK_LE_3_BYTE(&flag_1, &p_gatt_value->p_value[pos]);
    
    /*is_session_stopped bit */
    if (flag_1 & BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SESSION_STOPPED)
    {
        p_app_value->sensor_status_annunciation.is_session_stopped = true;
    }
    else
    {
        p_app_value->sensor_status_annunciation.is_session_stopped = false;
    }

    /*is_device_battery_low bit */
    if (flag_1 & BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_DEVICE_BATTERY_LOW)
    {
        p_app_value->sensor_status_annunciation.is_device_battery_low = true;
    }
    else
    {
        p_app_value->sensor_status_annunciation.is_device_battery_low = false;
    }

    /*is_sensor_type_incorrect_for_device bit */
    if (flag_1 & BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_TYPE_INCORRECT_FOR_DEVICE)
    {
        p_app_value->sensor_status_annunciation.is_sensor_type_incorrect_for_device = true;
    }
    else
    {
        p_app_value->sensor_status_annunciation.is_sensor_type_incorrect_for_device = false;
    }

    /*is_sensor_malfunction bit */
    if (flag_1 & BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_MALFUNCTION)
    {
        p_app_value->sensor_status_annunciation.is_sensor_malfunction = true;
    }
    else
    {
        p_app_value->sensor_status_annunciation.is_sensor_malfunction = false;
    }
    
    /*is_device_specific_alert bit */
    if (flag_1 & BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_DEVICE_SPECIFIC_ALERT)
    {
        p_app_value->sensor_status_annunciation.is_device_specific_alert = true;
    }
    else
    {
        p_app_value->sensor_status_annunciation.is_device_specific_alert = false;
    }
    
    /*is_general_device_fault_has_occurred_in_the_sensor bit */
    if (flag_1 & BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_GENERAL_DEVICE_FAULT_HAS_OCCURED_IN_THE_SENSOR)
    {
        p_app_value->sensor_status_annunciation.is_general_device_fault_has_occurred_in_the_sensor = true;
    }
    else
    {
        p_app_value->sensor_status_annunciation.is_general_device_fault_has_occurred_in_the_sensor = false;
    }

    /*is_time_synchronization_between_sensor_and_collector_required bit */
    if (flag_1 & BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_TIME_SYNCHRONIZATION_BETWEEN_SENSOR_AND_COLLECTOR_REQUIRED)
    {
        p_app_value->sensor_status_annunciation.is_time_synchronization_between_sensor_and_collector_required = true;
    }
    else
    {
        p_app_value->sensor_status_annunciation.is_time_synchronization_between_sensor_and_collector_required = false;
    }

    /*is_calibration_not_allowed bit */
    if (flag_1 & BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_CALIBRATION_NOT_ALLOWED)
    {
        p_app_value->sensor_status_annunciation.is_calibration_not_allowed = true;
    }
    else
    {
        p_app_value->sensor_status_annunciation.is_calibration_not_allowed = false;
    }

    /*is_calibration_recommended bit */
    if (flag_1 & BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_CALIBRATION_RECOMMENDED)
    {
        p_app_value->sensor_status_annunciation.is_calibration_recommended = true;
    }
    else
    {
        p_app_value->sensor_status_annunciation.is_calibration_recommended = false;
    }

    /*is_calibration_required bit */
    if (flag_1 & BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_CALIBRATION_REQUIRED)
    {
        p_app_value->sensor_status_annunciation.is_calibration_required = true;
    }
    else
    {
        p_app_value->sensor_status_annunciation.is_calibration_required = false;
    }

    /*is_sensor_temperature_too_high_for_valid_test_result_at_time_of_measurement bit */
    if (flag_1 & BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_TEMP_TOO_HIGH_FOR_VALID_TEST_RESULT_AT_MEASUREMENT)
    {
        p_app_value->sensor_status_annunciation.is_sensor_temperature_too_high_for_valid_test_result_at_time_of_measurement = true;
    }
    else
    {
        p_app_value->sensor_status_annunciation.is_sensor_temperature_too_high_for_valid_test_result_at_time_of_measurement = false;
    }

    /*is_sensor_temperature_too_low_for_valid_test_result_at_time_of_measurement bit */
    if (flag_1 & BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_TEMP_TOO_LOW_FOR_VALID_TEST_RESULT_AT_MEASUREMENT)
    {
        p_app_value->sensor_status_annunciation.is_sensor_temperature_too_low_for_valid_test_result_at_time_of_measurement = true;
    }
    else
    {
        p_app_value->sensor_status_annunciation.is_sensor_temperature_too_low_for_valid_test_result_at_time_of_measurement = false;
    }

    /*is_sensor_result_lower_than_the_patient_low_level bit */
    if (flag_1 & BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_LOWER_THAN_THE_PATIENT_LOW_LEVEL)
    {
        p_app_value->sensor_status_annunciation.is_sensor_result_lower_than_the_patient_low_level = true;
    }
    else
    {
        p_app_value->sensor_status_annunciation.is_sensor_result_lower_than_the_patient_low_level = false;
    }

    /*is_sensor_result_higher_than_the_patient_high_level bit */
    if (flag_1 & BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_HIGHER_THAN_THE_PATIENT_HIGH_LEVEL)
    {
        p_app_value->sensor_status_annunciation.is_sensor_result_higher_than_the_patient_high_level = true;
    }
    else
    {
        p_app_value->sensor_status_annunciation.is_sensor_result_higher_than_the_patient_high_level = false;
    }

    /*is_sensor_result_lower_than_the_hypo_level bit */
    if (flag_1 & BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_LOWER_THAN_HYPO_LEVEL)
    {
        p_app_value->sensor_status_annunciation.is_sensor_result_lower_than_the_hypo_level = true;
    }
    else
    {
        p_app_value->sensor_status_annunciation.is_sensor_result_lower_than_the_hypo_level = false;
    }

    /*is_sensor_result_higher_than_the_hyper_level bit */
    if (flag_1 & BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_HIGHER_THAN_HYPER_LEVEL)
    {
        p_app_value->sensor_status_annunciation.is_sensor_result_higher_than_the_hyper_level = true;
    }
    else
    {
        p_app_value->sensor_status_annunciation.is_sensor_result_higher_than_the_hyper_level = false;
    }

    /*is_sensor_rate_of_decrease_exceeded bit */
    if (flag_1 & BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RATE_OF_DECREASE_EXCEEDED)
    {
        p_app_value->sensor_status_annunciation.is_sensor_rate_of_decrease_exceeded = true;
    }
    else
    {
        p_app_value->sensor_status_annunciation.is_sensor_rate_of_decrease_exceeded = false;
    }

    /*is_sensor_rate_of_increase_exceeded bit */
    if (flag_1 & BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RATE_OF_INCREASE_EXCEEDED)
    {
        p_app_value->sensor_status_annunciation.is_sensor_rate_of_increase_exceeded = true;
    }
    else
    {
        p_app_value->sensor_status_annunciation.is_sensor_rate_of_increase_exceeded = false;
    }

    /*is_sensor_result_lower_than_the_device_can_process bit */
    if (flag_1 & BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_LOWER_THAN_DEVICE_CAN_PROCESS)
    {
        p_app_value->sensor_status_annunciation.is_sensor_result_lower_than_the_device_can_process = true;
    }
    else
    {
        p_app_value->sensor_status_annunciation.is_sensor_result_lower_than_the_device_can_process = false;
    }

    /*is_sensor_result_higher_than_the_device_can_process bit */
    if (flag_1 & BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_HIGHER_THAN_DEVICE_CAN_PROCESS)
    {
        p_app_value->sensor_status_annunciation.is_sensor_result_higher_than_the_device_can_process = true;
    }
    else
    {
        p_app_value->sensor_status_annunciation.is_sensor_result_higher_than_the_device_can_process = false;
    }
    pos += 2;

    /*Copy the cgm_trend_information_value*/
    if (feature_byte0 & BLE_CGMS_PRV_CGM_MEASUREMENT_FLAG_CGM_TREND_INFORMATION_PRESENT)
    {
        BT_UNPACK_LE_2_BYTE(&p_app_value->cgm_trend_information.mantissa, &p_gatt_value->p_value[pos]);
        p_app_value->cgm_trend_information.exponent = (int8_t)(((int16_t)p_app_value->cgm_trend_information.mantissa) >> 12);
        p_app_value->cgm_trend_information.mantissa = (int16_t)(p_app_value->cgm_trend_information.mantissa & 0x0FFF);

        pos += 2;
    }

    if (feature_byte0 & BLE_CGMS_PRV_CGM_MEASUREMENT_FLAG_CGM_QUALITY_PRESENT)
    {
        /*Copy the cgm_quality_value*/
        BT_UNPACK_LE_2_BYTE(&p_app_value->cgm_quality.mantissa, &p_gatt_value->p_value[pos]);
        p_app_value->cgm_quality.exponent = (int8_t)(((int16_t)p_app_value->cgm_quality.mantissa) >> 12);
        p_app_value->cgm_quality.mantissa = (int16_t)(p_app_value->cgm_quality.mantissa & 0x0FFF);

        pos += 2;
    }

    if (cgm_features.cgm_feature.is_e2e_crc_supported)
    {
        /*Copy the e2e_crc*/
        BT_UNPACK_LE_2_BYTE(&p_app_value->e2e_crc, &p_gatt_value->p_value[pos]);

        pos += 2;
    }

    return BLE_SUCCESS;
}

/***********************************************************************************************************************//**
* Function Name: encode_st_ble_cgms_meas_t
* Description  : This function converts CGM Measurement characteristic value representation in
*                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
* Arguments    : p_app_value - pointer to the CGM Measurement  value in the application layer
*                p_gatt_value - pointer to the characteristic value in the GATT database
* Return Value : ble_status_t
**********************************************************************************************************************/
static ble_status_t encode_st_ble_cgms_meas_t(const st_ble_cgms_meas_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 1;
    uint32_t flag_1 = 0;
    uint16_t e2e_crc = 0xFFFF;

    st_ble_cgms_feat_t cgm_feature;
    R_BLE_CGMS_GetFeat(&cgm_feature);

    /* Clear the bytes array */
    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    /*Copy the Size Value*/
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->size);

    /*Copy the cgm_glucose_concentration Value*/
    /*variable to copy the exponent and mantisa values of cgm_glucose_concentration VALUE*/
    uint16_t value_to_copy_cgm_glucose_concentration = 0;

    value_to_copy_cgm_glucose_concentration = (uint16_t)((((((int16_t)
        (p_app_value->cgm_glucose_concentration.exponent)) << 12) & 0xF000)
        | (p_app_value->cgm_glucose_concentration.mantissa & 0x0FFF)));

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], (uint8_t*)&value_to_copy_cgm_glucose_concentration);
    pos += 2;

    /*Copy the time_offset Value*/
    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->time_offset);
    pos += 2;

    if ((p_app_value->flags.is_sensor_status_annunciation_field__cal_temp_octet_present)
        || (p_app_value->flags.is_sensor_status_annunciation_field__status_octet_present)
        || (p_app_value->flags.is_sensor_status_annunciation_field__warning_octet_present))
    {
        p_gatt_value->p_value[0] |= BLE_CGMS_PRV_CGM_MEASUREMENT_FLAG_CGM_SENSOR_STATUS_ANNUNCIATION_FIELD_WARNING_OCTECT_PRESENT;
        p_gatt_value->p_value[0] |= BLE_CGMS_PRV_CGM_MEASUREMENT_FLAG_CGM_SENSOR_STATUS_ANNUNCIATION_FIELD_CAL_TEMP_OCTECT_PRESENT;
        p_gatt_value->p_value[0] |= BLE_CGMS_PRV_CGM_MEASUREMENT_FLAG_CGM_SENSOR_STATUS_ANNUCIATION_FIELD_STATUS_OCTECT_PRESENT;
        if (p_app_value->sensor_status_annunciation.is_session_stopped)
        {
            flag_1 |= BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SESSION_STOPPED;
        }

        if (p_app_value->sensor_status_annunciation.is_device_battery_low)
        {
            flag_1 |= BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_DEVICE_BATTERY_LOW;
        }

        if (p_app_value->sensor_status_annunciation.is_sensor_type_incorrect_for_device)
        {
            flag_1 |= BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_TYPE_INCORRECT_FOR_DEVICE;
        }

        if (p_app_value->sensor_status_annunciation.is_sensor_malfunction)
        {
            flag_1 |= BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_MALFUNCTION;
        }

        if (p_app_value->sensor_status_annunciation.is_device_specific_alert)
        {
            flag_1 |= BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_DEVICE_SPECIFIC_ALERT;
        }

        if (p_app_value->sensor_status_annunciation.is_general_device_fault_has_occurred_in_the_sensor)
        {
            flag_1 |= BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_GENERAL_DEVICE_FAULT_HAS_OCCURED_IN_THE_SENSOR;
        }

        if (p_app_value->sensor_status_annunciation.is_time_synchronization_between_sensor_and_collector_required)
        {
            flag_1 |= BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_TIME_SYNCHRONIZATION_BETWEEN_SENSOR_AND_COLLECTOR_REQUIRED;
        }

        if (p_app_value->sensor_status_annunciation.is_calibration_not_allowed)
        {
            flag_1 |= BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_CALIBRATION_NOT_ALLOWED;
        }

        if (p_app_value->sensor_status_annunciation.is_calibration_recommended)
        {
            flag_1 |= BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_CALIBRATION_RECOMMENDED;
        }

        if (p_app_value->sensor_status_annunciation.is_calibration_required)
        {
            flag_1 |= BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_CALIBRATION_REQUIRED;
        }

        if (p_app_value->sensor_status_annunciation.is_sensor_temperature_too_high_for_valid_test_result_at_time_of_measurement)
        {
            flag_1 |= BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_TEMP_TOO_HIGH_FOR_VALID_TEST_RESULT_AT_MEASUREMENT;
        }

        if (p_app_value->sensor_status_annunciation.is_sensor_temperature_too_low_for_valid_test_result_at_time_of_measurement)
        {
            flag_1 |= BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_TEMP_TOO_LOW_FOR_VALID_TEST_RESULT_AT_MEASUREMENT;
        }

        if (p_app_value->sensor_status_annunciation.is_sensor_result_lower_than_the_patient_low_level)
        {
            flag_1 |= BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_LOWER_THAN_THE_PATIENT_LOW_LEVEL;
        }

        if (p_app_value->sensor_status_annunciation.is_sensor_result_higher_than_the_patient_high_level)
        {
            flag_1 |= BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_HIGHER_THAN_THE_PATIENT_HIGH_LEVEL;
        }

        if (p_app_value->sensor_status_annunciation.is_sensor_result_lower_than_the_hypo_level)
        {
            flag_1 |= BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_LOWER_THAN_HYPO_LEVEL;
        }

        if (p_app_value->sensor_status_annunciation.is_sensor_result_higher_than_the_hyper_level)
        {
            flag_1 |= BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_HIGHER_THAN_HYPER_LEVEL;
        }

        if (p_app_value->sensor_status_annunciation.is_sensor_rate_of_decrease_exceeded)
        {
            flag_1 |= BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RATE_OF_DECREASE_EXCEEDED;
        }
        if (p_app_value->sensor_status_annunciation.is_sensor_rate_of_increase_exceeded)
        {
            flag_1 |= BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RATE_OF_INCREASE_EXCEEDED;
        }

        if (p_app_value->sensor_status_annunciation.is_sensor_result_lower_than_the_device_can_process)
        {
            flag_1 |= BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_LOWER_THAN_DEVICE_CAN_PROCESS;
        }

        if (p_app_value->sensor_status_annunciation.is_sensor_result_higher_than_the_device_can_process)
        {
            flag_1 |= BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_HIGHER_THAN_DEVICE_CAN_PROCESS;
        }

        BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], &flag_1);
        pos += 3;
    }

    /*Copy the cgm_trend_information Value*/
    /*variable to copy the exponent and mantisa values of cgm_trend_information VALUE*/
    p_gatt_value->p_value[0] |= BLE_CGMS_PRV_CGM_MEASUREMENT_FLAG_CGM_TREND_INFORMATION_PRESENT;
    uint16_t value_to_copy_cgm_trend_information = 0;

    value_to_copy_cgm_trend_information = (uint16_t)((((((int16_t)(p_app_value->cgm_trend_information.exponent)) << 12) & 0xF000)
        | (p_app_value->cgm_trend_information.mantissa & 0x0FFF)));

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], (uint8_t*)&value_to_copy_cgm_trend_information);
    pos += 2;

    /*Copy the cgm_quality Value*/
    /*variable to copy the exponent and mantisa values of cgm_quality VALUE*/ 
    p_gatt_value->p_value[0] |= BLE_CGMS_PRV_CGM_MEASUREMENT_FLAG_CGM_QUALITY_PRESENT;
    uint16_t value_to_copy_cgm_quality = 0;

    value_to_copy_cgm_quality = (uint16_t)((((((int16_t)(p_app_value->cgm_quality.exponent)) << 12) & 0xF000)
       | (p_app_value->cgm_quality.mantissa & 0x0FFF)));

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], (uint8_t*)&value_to_copy_cgm_quality);
    pos += 2;
    
    /*Copy the e2e_crc Value*/
    e2e_crc = e2e_crc_calculation(p_gatt_value->p_value, pos);
    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &e2e_crc);
    pos += 2;

    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

/* CGM Measurement characteristic descriptor definition */
static const st_ble_servs_desc_info_t *gspp_meas_descs[] = 
{
    &gs_meas_cli_cnfg,
};

/* CGM Measurement characteristic definition */
static const st_ble_servs_char_info_t gs_meas_char = 
{
    .start_hdl    = BLE_CGMS_MEAS_DECL_HDL,
    .end_hdl      = BLE_CGMS_MEAS_CLI_CNFG_DESC_HDL,
    .char_idx     = BLE_CGMS_MEAS_IDX,
    .app_size     = sizeof(st_ble_cgms_meas_t),
    .db_size      = BLE_CGMS_MEAS_LEN,
    .decode       = (ble_servs_attr_decode_t)decode_st_ble_cgms_meas_t,
    .encode       = (ble_servs_attr_encode_t)encode_st_ble_cgms_meas_t,
    .pp_descs     = gspp_meas_descs,
    .num_of_descs = ARRAY_SIZE(gspp_meas_descs),
};

ble_status_t R_BLE_CGMS_NotifyMeas(uint16_t conn_hdl, const st_ble_cgms_meas_t *p_value)
{
    return R_BLE_SERVS_SendHdlVal(&gs_meas_char, conn_hdl, (const void *)p_value, true);
}

/*----------------------------------------------------------------------------------------------------------------------
    CGM Feature characteristic
----------------------------------------------------------------------------------------------------------------------*/
/***********************************************************************************************************************//**
* Function Name: decode_st_ble_cgms_feat_t
* Description  : This function converts CGM Feature value representation in
*                GATT (uint8_t[]) to representation in application layer (struct).
* Arguments    : p_app_value - pointer to the CGM Feature value in the application layer
*                p_gatt_value - pointer to the characteristic value in the GATT database
* Return Value : ble_status_t
**********************************************************************************************************************/
static ble_status_t decode_st_ble_cgms_feat_t(st_ble_cgms_feat_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos      = 0;
    uint16_t e2e_crc = 0xFFFF;

    if (BLE_CGMS_PRV_CGM_FEATURES_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    memset((uint8_t*)p_app_value, 0x00, sizeof(*p_app_value));

    uint32_t feature_byte0 = 0;
    BT_UNPACK_LE_3_BYTE(&feature_byte0, &p_gatt_value->p_value[0]);
    pos += 3;

    /* CGMS SUPPORTED FEATURES SUPPORTED BITS */
    /* is_calibration_supported bit */
    if (feature_byte0 & BLE_CGMS_PRV_CGM_FEATURES_CALIBRATION_SUPPORTED)
    {
        p_app_value->cgm_feature.is_calibration_supported = true;
    }
    else
    {
        p_app_value->cgm_feature.is_calibration_supported = false;
    }

    /* is_patient_high_low_alerts_supported bit */
    if (feature_byte0 & BLE_CGMS_PRV_CGM_FEATURES_PATIENT_HIGH_LOW_ALERTS_SUPPORTED)
    {
        p_app_value->cgm_feature.is_patient_high_low_alerts_supported = true;
    }
    else
    {
        p_app_value->cgm_feature.is_patient_high_low_alerts_supported = false;
    }

    /* is_hypo_alerts_supported bit */
    if (feature_byte0 & BLE_CGMS_PRV_CGM_FEATURES_HYPO_ALERTS_SUPPORTED)
    {
        p_app_value->cgm_feature.is_hypo_alerts_supported = true;
    }
    else
    {
        p_app_value->cgm_feature.is_hypo_alerts_supported = false;
    }

    /* is_hyper_alerts_supported bit */
    if (feature_byte0 & BLE_CGMS_PRV_CGM_FEATURES_HYPER_ALERTS_SUPPORTED)
    {
        p_app_value->cgm_feature.is_hyper_alerts_supported = true;
    }
    else
    {
        p_app_value->cgm_feature.is_hyper_alerts_supported = false;
    }

    /* is_rate_of_increase_decrease_alerts_supported bit */
    if (feature_byte0 & BLE_CGMS_PRV_CGM_FEATURES_RATE_OF_INCREASE_DECREASE_ALERTS_SUPPORTED)
    {
        p_app_value->cgm_feature.is_rate_of_increase_decrease_alerts_supported = true;
    }
    else
    {
        p_app_value->cgm_feature.is_rate_of_increase_decrease_alerts_supported = false;
    }

    /* is_device_specific_alert_supported bit */
    if (feature_byte0 & BLE_CGMS_PRV_CGM_FEATURES_DEVICE_SPECIFIC_ALERTS_SUPPORTED)
    {
        p_app_value->cgm_feature.is_device_specific_alert_supported = true;
    }
    else
    {
        p_app_value->cgm_feature.is_device_specific_alert_supported = false;
    }

    /* is_sensor_malfunction_detection_supported bit */
    if (feature_byte0 & BLE_CGMS_PRV_CGM_FEATURES_SENSOR_MALFUNCTION_DETECTION_SUPPORTED)
    {
        p_app_value->cgm_feature.is_sensor_malfunction_detection_supported = true;
    }
    else
    {
        p_app_value->cgm_feature.is_sensor_malfunction_detection_supported = false;
    }

    /* is_sensor_temperature_high_low_detection_supported bit */
    if (feature_byte0 & BLE_CGMS_PRV_CGM_FEATURES_SENSOR_TEMPERATURE_HIGH_LOW_DETECTION_SUPPORTED)
    {
        p_app_value->cgm_feature.is_sensor_temperature_high_low_detection_supported = true;
    }
    else
    {
        p_app_value->cgm_feature.is_sensor_temperature_high_low_detection_supported = false;
    }

    /* is_sensor_result_high_low_detection_supported bit */
    if (feature_byte0 & BLE_CGMS_PRV_CGM_FEATURES_SENSOR_RESULT_HIGH_LOW_DETECTION_SUPPORTED)
    {
        p_app_value->cgm_feature.is_sensor_result_high_low_detection_supported = true;
    }
    else
    {
        p_app_value->cgm_feature.is_sensor_result_high_low_detection_supported = false;
    }

    /* is_low_battery_detection_supported bit */
    if (feature_byte0 & BLE_CGMS_PRV_CGM_FEATURES_LOW_BATTERY_DETECTION_SUPPORTED)
    {
        p_app_value->cgm_feature.is_low_battery_detection_supported = true;
    }
    else
    {
        p_app_value->cgm_feature.is_low_battery_detection_supported = false;
    }

    /* is_sensor_type_error_detection_supported bit */
    if (feature_byte0 & BLE_CGMS_PRV_CGM_FEATURES_SENSOR_TYPE_ERROR_DETECTION_SUPPORTED)
    {
        p_app_value->cgm_feature.is_sensor_type_error_detection_supported = true;
    }
    else
    {
        p_app_value->cgm_feature.is_sensor_type_error_detection_supported = false;
    }

    /* is_general_device_fault_supported bit */
    if (feature_byte0 & BLE_CGMS_PRV_CGM_FEATURES_GENERAL_DEVICE_FAULT_SUPPORTED)
    {
        p_app_value->cgm_feature.is_general_device_fault_supported = true;
    }
    else
    {
        p_app_value->cgm_feature.is_general_device_fault_supported = false;
    }

    /* is_e2e_crc_supported bit */
    if (feature_byte0 & BLE_CGMS_PRV_CGM_FEATURES_E2E_CRC_SUPPORTED)
    {
        p_app_value->cgm_feature.is_e2e_crc_supported = true;
    }
    else
    {
        p_app_value->cgm_feature.is_e2e_crc_supported = false;
    }

    /* is_multiple_bond_supported bit */
    if (feature_byte0 & BLE_CGMS_PRV_CGM_FEATURES_MULTIPLE_BOND_SUPPORTED)
    {
        p_app_value->cgm_feature.is_multiple_bond_supported = true;
    }
    else
    {
        p_app_value->cgm_feature.is_multiple_bond_supported = false;
    }

    /* is_multiple_sessions_supported bit */
    if (feature_byte0 & BLE_CGMS_PRV_CGM_FEATURES_MULTIPLE_SESSIONS_SUPPORTED)
    {
        p_app_value->cgm_feature.is_multiple_sessions_supported = true;
    }
    else
    {
        p_app_value->cgm_feature.is_multiple_sessions_supported = false;
    }

    /* is_cgm_trend_information_supported bit */
    if (feature_byte0 & BLE_CGMS_PRV_CGM_FEATURES_CGM_TREND_INFORMATION_SUPPORTED)
    {
        p_app_value->cgm_feature.is_cgm_trend_information_supported = true;
    }
    else
    {
        p_app_value->cgm_feature.is_cgm_trend_information_supported = false;
    }

    /* is_cgm_quality_supported bit */
    if (feature_byte0 & BLE_CGMS_PRV_CGM_FEATURES_CGM_QUALITY_SUPPORTED)
    {
        p_app_value->cgm_feature.is_cgm_quality_supported = true;
    }
    else
    {
        p_app_value->cgm_feature.is_cgm_quality_supported = false;
    }

    /* cgm_type value */
    BT_UNPACK_LE_1_BYTE(&p_app_value->cgm_type, &p_gatt_value->p_value[pos]);
    p_app_value->cgm_type = (p_app_value->cgm_type & 0x0F);
    p_app_value->cgm_sample_location = (p_app_value->cgm_type & 0xF0);
    pos += 1;

    /* e2e_crc value */
    BT_UNPACK_LE_2_BYTE(&p_app_value->e2e_crc, &p_gatt_value->p_value[pos]);
    pos += 2;

    return BLE_SUCCESS;
}

/***********************************************************************************************************************//**
 * Function Name: encode_st_ble_cgms_feat_t
 * Description  : This function converts CGM Features characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the CGM Features  value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_cgms_feat_t(const st_ble_cgms_feat_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos      = 0;
    uint32_t flag_1  = 0;
    uint16_t e2e_crc = 0xFFFF;

    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    /* Copy the supported_features Value of CGM Features  */
    if (p_app_value->cgm_feature.is_calibration_supported)
    {
        flag_1 |= BLE_CGMS_PRV_CGM_FEATURES_CALIBRATION_SUPPORTED;
    }

    if (p_app_value->cgm_feature.is_patient_high_low_alerts_supported)
    {
        flag_1 |= BLE_CGMS_PRV_CGM_FEATURES_PATIENT_HIGH_LOW_ALERTS_SUPPORTED;
    }

    if (p_app_value->cgm_feature.is_hypo_alerts_supported)
    {
        flag_1 |= BLE_CGMS_PRV_CGM_FEATURES_HYPO_ALERTS_SUPPORTED;
    }

    if (p_app_value->cgm_feature.is_hyper_alerts_supported)
    {
        flag_1 |= BLE_CGMS_PRV_CGM_FEATURES_HYPER_ALERTS_SUPPORTED;
    }

    if (p_app_value->cgm_feature.is_rate_of_increase_decrease_alerts_supported)
    {
        flag_1 |= BLE_CGMS_PRV_CGM_FEATURES_RATE_OF_INCREASE_DECREASE_ALERTS_SUPPORTED;
    }

    if (p_app_value->cgm_feature.is_device_specific_alert_supported)
    {
        flag_1 |= BLE_CGMS_PRV_CGM_FEATURES_DEVICE_SPECIFIC_ALERTS_SUPPORTED;
    }

    if (p_app_value->cgm_feature.is_sensor_malfunction_detection_supported)
    {
        flag_1 |= BLE_CGMS_PRV_CGM_FEATURES_SENSOR_MALFUNCTION_DETECTION_SUPPORTED;
    }

    if (p_app_value->cgm_feature.is_sensor_temperature_high_low_detection_supported)
    {
        flag_1 |= BLE_CGMS_PRV_CGM_FEATURES_SENSOR_TEMPERATURE_HIGH_LOW_DETECTION_SUPPORTED;
    }

    if (p_app_value->cgm_feature.is_sensor_result_high_low_detection_supported)
    {
        flag_1 |= BLE_CGMS_PRV_CGM_FEATURES_SENSOR_RESULT_HIGH_LOW_DETECTION_SUPPORTED;
    }

    if (p_app_value->cgm_feature.is_low_battery_detection_supported)
    {
        flag_1 |= BLE_CGMS_PRV_CGM_FEATURES_LOW_BATTERY_DETECTION_SUPPORTED;
    }

    if (p_app_value->cgm_feature.is_sensor_type_error_detection_supported)
    {
        flag_1 |= BLE_CGMS_PRV_CGM_FEATURES_SENSOR_TYPE_ERROR_DETECTION_SUPPORTED;
    }

    if (p_app_value->cgm_feature.is_general_device_fault_supported)
    {
        flag_1 |= BLE_CGMS_PRV_CGM_FEATURES_GENERAL_DEVICE_FAULT_SUPPORTED;
    }

    if (p_app_value->cgm_feature.is_e2e_crc_supported)
    {
        flag_1 |= BLE_CGMS_PRV_CGM_FEATURES_E2E_CRC_SUPPORTED;
    }

    if (p_app_value->cgm_feature.is_multiple_bond_supported)
    {
        flag_1 |= BLE_CGMS_PRV_CGM_FEATURES_MULTIPLE_BOND_SUPPORTED;
    }

    if (p_app_value->cgm_feature.is_multiple_sessions_supported)
    {
        flag_1 |= BLE_CGMS_PRV_CGM_FEATURES_MULTIPLE_SESSIONS_SUPPORTED;
    }

    if (p_app_value->cgm_feature.is_cgm_trend_information_supported)
    {
        flag_1 |= BLE_CGMS_PRV_CGM_FEATURES_CGM_TREND_INFORMATION_SUPPORTED;
    }

    if (p_app_value->cgm_feature.is_cgm_quality_supported)
    {
        flag_1 |= BLE_CGMS_PRV_CGM_FEATURES_CGM_QUALITY_SUPPORTED;
    }

    BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], &flag_1);
    pos += 3;

    /* copy the value of cgm_type*/
    uint8_t value_to_copy_cgm_type = 0;
    value_to_copy_cgm_type = (uint8_t)((((((uint8_t)(p_app_value->cgm_type))) & 0xF0)
        | (p_app_value->cgm_sample_location & 0x0F)));
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &value_to_copy_cgm_type);

    /* copy the value of e2e_crc*/
    e2e_crc = e2e_crc_calculation(p_gatt_value->p_value, pos);
    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &e2e_crc);
    pos += 2;

    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

/* CGM Feature characteristic definition */
static const st_ble_servs_char_info_t gs_feat_char = 
{
    .start_hdl    = BLE_CGMS_FEAT_DECL_HDL,
    .end_hdl      = BLE_CGMS_FEAT_VAL_HDL,
    .char_idx     = BLE_CGMS_FEAT_IDX,
    .app_size     = sizeof(st_ble_cgms_feat_t),
    .db_size      = BLE_CGMS_FEAT_LEN,
    .decode       = (ble_servs_attr_decode_t)decode_st_ble_cgms_feat_t,
    .encode       = (ble_servs_attr_encode_t)encode_st_ble_cgms_feat_t,
};

ble_status_t R_BLE_CGMS_SetFeat(const st_ble_cgms_feat_t *p_value)
{
    return R_BLE_SERVS_SetChar(&gs_feat_char, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_CGMS_GetFeat(st_ble_cgms_feat_t *p_value)
{
    return R_BLE_SERVS_GetChar(&gs_feat_char, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    CGM Status characteristic
----------------------------------------------------------------------------------------------------------------------*/
/***********************************************************************************************************************//**
* Function Name: decode_st_ble_cgms_status_t
* Description  : This function converts CGM Status characteristic value representation in
*                GATT (uint8_t[]) to representation in application layer (struct).
* Arguments    : p_app_value - pointer to the CGM Status value in the application layer
*                p_gatt_value - pointer to the characteristic value in the GATT database
* Return Value : ble_status_t
**********************************************************************************************************************/
static ble_status_t decode_st_ble_cgms_status_t(st_ble_cgms_status_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos      = 0;
    uint16_t e2e_crc = 0xFFFF;
    uint32_t flag_1  = 0;

    if (BLE_CGMS_STATUS_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    memset((uint8_t*)p_app_value, 0x00, sizeof(st_ble_cgms_status_t));

    /*Copy the CGM_STATUS time_offset value*/
    BT_UNPACK_LE_2_BYTE(&p_app_value->time_offset, &p_gatt_value->p_value[pos]);
    pos += 2;

    /*Copy the CGM_STATUS cgm_status value*/
    BT_UNPACK_LE_3_BYTE(&flag_1, &p_gatt_value->p_value[pos]);

    /*is_session_stopped bit */
    if (flag_1 & BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SESSION_STOPPED)
    {
        p_app_value->cgm_status.is_session_stopped = true;
    }
    else
    {
        p_app_value->cgm_status.is_session_stopped = false;
    }

    /*is_device_battery_low bit */
    if (flag_1 & BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_DEVICE_BATTERY_LOW)
    {
        p_app_value->cgm_status.is_device_battery_low = true;
    }
    else
    {
        p_app_value->cgm_status.is_device_battery_low = false;
    }

    /*is_sensor_type_incorrect_for_device bit */
    if (flag_1 & BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_TYPE_INCORRECT_FOR_DEVICE)
    {
        p_app_value->cgm_status.is_sensor_type_incorrect_for_device = true;
    }
    else
    {
        p_app_value->cgm_status.is_sensor_type_incorrect_for_device = false;
    }

    /*is_sensor_malfunction bit */
    if (flag_1 & BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_MALFUNCTION)
    {
        p_app_value->cgm_status.is_sensor_malfunction = true;
    }
    else
    {
        p_app_value->cgm_status.is_sensor_malfunction = false;
    }

    /*is_device_specific_alert bit */
    if (flag_1 & BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_DEVICE_SPECIFIC_ALERT)
    {
        p_app_value->cgm_status.is_device_specific_alert = true;
    }
    else
    {
        p_app_value->cgm_status.is_device_specific_alert = false;
    }

    /*is_general_device_fault_has_occurred_in_the_sensor bit */
    if (flag_1 & BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_GENERAL_DEVICE_FAULT_HAS_OCCURED_IN_THE_SENSOR)
    {
        p_app_value->cgm_status.is_general_device_fault_has_occurred_in_the_sensor = true;
    }
    else
    {
        p_app_value->cgm_status.is_general_device_fault_has_occurred_in_the_sensor = false;
    }

    /*is_time_synchronization_between_sensor_and_collector_required bit */
    if (flag_1 & BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_TIME_SYNCHRONIZATION_BETWEEN_SENSOR_AND_COLLECTOR_REQUIRED)
    {
        p_app_value->cgm_status.is_time_synchronization_between_sensor_and_collector_required = true;
    }
    else
    {
        p_app_value->cgm_status.is_time_synchronization_between_sensor_and_collector_required = false;
    }

    /*is_calibration_not_allowed bit */
    if (flag_1 & BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_CALIBRATION_NOT_ALLOWED)
    {
        p_app_value->cgm_status.is_calibration_not_allowed = true;
    }
    else
    {
        p_app_value->cgm_status.is_calibration_not_allowed = false;
    }

    /*is_calibration_recommended bit */
    if (flag_1 & BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_CALIBRATION_RECOMMENDED)
    {
        p_app_value->cgm_status.is_calibration_recommended = true;
    }
    else
    {
        p_app_value->cgm_status.is_calibration_recommended = false;
    }

    /*is_calibration_required bit */
    if (flag_1 & BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_CALIBRATION_REQUIRED)
    {
        p_app_value->cgm_status.is_calibration_required = true;
    }
    else
    {
        p_app_value->cgm_status.is_calibration_required = false;
    }

    /*is_sensor_temperature_too_high_for_valid_test_result_at_time_of_measurement bit */
    if (flag_1 & BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_TEMP_TOO_HIGH_FOR_VALID_TEST_RESULT_AT_MEASUREMENT)
    {
        p_app_value->cgm_status.is_sensor_temperature_too_high_for_valid_test_result_at_time_of_measurement = true;
    }
    else
    {
        p_app_value->cgm_status.is_sensor_temperature_too_high_for_valid_test_result_at_time_of_measurement = false;
    }

    /*is_sensor_temperature_too_low_for_valid_test_result_at_time_of_measurement bit */
    if (flag_1 & BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_TEMP_TOO_LOW_FOR_VALID_TEST_RESULT_AT_MEASUREMENT)
    {
        p_app_value->cgm_status.is_sensor_temperature_too_low_for_valid_test_result_at_time_of_measurement = true;
    }
    else
    {
        p_app_value->cgm_status.is_sensor_temperature_too_low_for_valid_test_result_at_time_of_measurement = false;
    }

    /*is_sensor_result_lower_than_the_patient_low_level bit */
    if (flag_1 & BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_LOWER_THAN_THE_PATIENT_LOW_LEVEL)
    {
        p_app_value->cgm_status.is_sensor_result_lower_than_the_patient_low_level = true;
    }
    else
    {
        p_app_value->cgm_status.is_sensor_result_lower_than_the_patient_low_level = false;
    }

    /*is_sensor_result_higher_than_the_patient_high_level bit */
    if (flag_1 & BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_HIGHER_THAN_THE_PATIENT_HIGH_LEVEL)
    {
        p_app_value->cgm_status.is_sensor_result_higher_than_the_patient_high_level = true;
    }
    else
    {
        p_app_value->cgm_status.is_sensor_result_higher_than_the_patient_high_level = false;
    }

    /*is_sensor_result_lower_than_the_hypo_level bit */
    if (flag_1 & BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_LOWER_THAN_HYPO_LEVEL)
    {
        p_app_value->cgm_status.is_sensor_result_lower_than_the_hypo_level = true;
    }
    else
    {
        p_app_value->cgm_status.is_sensor_result_lower_than_the_hypo_level = false;
    }

    /*is_sensor_result_higher_than_the_hyper_level bit */
    if (flag_1 & BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_HIGHER_THAN_HYPER_LEVEL)
    {
        p_app_value->cgm_status.is_sensor_result_higher_than_the_hyper_level = true;
    }
    else
    {
        p_app_value->cgm_status.is_sensor_result_higher_than_the_hyper_level = false;
    }

    /*is_sensor_rate_of_decrease_exceeded bit */
    if (flag_1 & BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RATE_OF_DECREASE_EXCEEDED)
    {
        p_app_value->cgm_status.is_sensor_rate_of_decrease_exceeded = true;
    }
    else
    {
        p_app_value->cgm_status.is_sensor_rate_of_decrease_exceeded = false;
    }

    /*is_sensor_rate_of_increase_exceeded bit */
    if (flag_1 & BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RATE_OF_INCREASE_EXCEEDED)
    {
        p_app_value->cgm_status.is_sensor_rate_of_increase_exceeded = true;
    }
    else
    {
        p_app_value->cgm_status.is_sensor_rate_of_increase_exceeded = false;
    }

    /*is_sensor_result_lower_than_the_device_can_process bit */
    if (flag_1 & BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_LOWER_THAN_DEVICE_CAN_PROCESS)
    {
        p_app_value->cgm_status.is_sensor_result_lower_than_the_device_can_process = true;
    }
    else
    {
        p_app_value->cgm_status.is_sensor_result_lower_than_the_device_can_process = false;
    }

    /*is_sensor_result_higher_than_the_device_can_process bit */
    if (flag_1 & BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_HIGHER_THAN_DEVICE_CAN_PROCESS)
    {
        p_app_value->cgm_status.is_sensor_result_higher_than_the_device_can_process = true;
    }
    else
    {
        p_app_value->cgm_status.is_sensor_result_higher_than_the_device_can_process = false;
    }
    pos += 3;

    e2e_crc = e2e_crc_calculation(p_gatt_value->p_value, pos);
    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &e2e_crc);
    pos += 2;

    return BLE_SUCCESS;
}

/***********************************************************************************************************************//**
 * Function Name: encode_st_ble_cgms_status_t
 * Description  : This function converts CGM Status characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the CGM Status value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_cgms_status_t(const st_ble_cgms_status_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos      = 0;
    uint16_t e2e_crc = 0xFFFF;
    uint32_t flag_1 = 0;

    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    /* copy the value of time_offset*/
    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->time_offset);
    pos += 2;

    /* copy the value of cgm_status*/
    if (p_app_value->cgm_status.is_session_stopped)
    {
        flag_1 |= BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SESSION_STOPPED;
    }

    if (p_app_value->cgm_status.is_device_battery_low)
    {
        flag_1 |= BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_DEVICE_BATTERY_LOW;
    }

    if (p_app_value->cgm_status.is_sensor_type_incorrect_for_device)
    {
        flag_1 |= BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_TYPE_INCORRECT_FOR_DEVICE;
    }

    if (p_app_value->cgm_status.is_sensor_malfunction)
    {
        flag_1 |= BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_MALFUNCTION;
    }

    if (p_app_value->cgm_status.is_device_specific_alert)
    {
        flag_1 |= BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_DEVICE_SPECIFIC_ALERT;
    }

    if (p_app_value->cgm_status.is_general_device_fault_has_occurred_in_the_sensor)
    {
        flag_1 |= BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_GENERAL_DEVICE_FAULT_HAS_OCCURED_IN_THE_SENSOR;
    }

    if (p_app_value->cgm_status.is_time_synchronization_between_sensor_and_collector_required)
    {
        flag_1 |= BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_TIME_SYNCHRONIZATION_BETWEEN_SENSOR_AND_COLLECTOR_REQUIRED;
    }

    if (p_app_value->cgm_status.is_calibration_not_allowed)
    {
        flag_1 |= BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_CALIBRATION_NOT_ALLOWED;
    }

    if (p_app_value->cgm_status.is_calibration_recommended)
    {
        flag_1 |= BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_CALIBRATION_RECOMMENDED;
    }

    if (p_app_value->cgm_status.is_calibration_required)
    {
        flag_1 |= BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_CALIBRATION_REQUIRED;
    }

    if (p_app_value->cgm_status.is_sensor_temperature_too_high_for_valid_test_result_at_time_of_measurement)
    {
        flag_1 |= BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_TEMP_TOO_HIGH_FOR_VALID_TEST_RESULT_AT_MEASUREMENT;
    }

    if (p_app_value->cgm_status.is_sensor_temperature_too_low_for_valid_test_result_at_time_of_measurement)
    {
        flag_1 |= BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_TEMP_TOO_LOW_FOR_VALID_TEST_RESULT_AT_MEASUREMENT;
    }

    if (p_app_value->cgm_status.is_sensor_result_lower_than_the_patient_low_level)
    {
        flag_1 |= BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_LOWER_THAN_THE_PATIENT_LOW_LEVEL;
    }

    if (p_app_value->cgm_status.is_sensor_result_higher_than_the_patient_high_level)
    {
        flag_1 |= BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_HIGHER_THAN_THE_PATIENT_HIGH_LEVEL;
    }

    if (p_app_value->cgm_status.is_sensor_result_lower_than_the_hypo_level)
    {
        flag_1 |= BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_LOWER_THAN_HYPO_LEVEL;
    }

    if (p_app_value->cgm_status.is_sensor_result_higher_than_the_hyper_level)
    {
        flag_1 |= BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_HIGHER_THAN_HYPER_LEVEL;
    }

    if (p_app_value->cgm_status.is_sensor_rate_of_decrease_exceeded)
    {
        flag_1 |= BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RATE_OF_DECREASE_EXCEEDED;
    }
    if (p_app_value->cgm_status.is_sensor_rate_of_increase_exceeded)
    {
        flag_1 |= BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RATE_OF_INCREASE_EXCEEDED;
    }

    if (p_app_value->cgm_status.is_sensor_result_lower_than_the_device_can_process)
    {
        flag_1 |= BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_LOWER_THAN_DEVICE_CAN_PROCESS;
    }

    if (p_app_value->cgm_status.is_sensor_result_higher_than_the_device_can_process)
    {
        flag_1 |= BLE_CGMS_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_HIGHER_THAN_DEVICE_CAN_PROCESS;
    }

    BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], &flag_1);
    pos += 3;

    /* copy the value of e2e_crc*/
    e2e_crc = e2e_crc_calculation(p_gatt_value->p_value, pos);
    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &e2e_crc);
    pos += 2;

    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

/* CGM Status characteristic definition */
static const st_ble_servs_char_info_t gs_status_char = 
{
    .start_hdl    = BLE_CGMS_STATUS_DECL_HDL,
    .end_hdl      = BLE_CGMS_STATUS_VAL_HDL,
    .char_idx     = BLE_CGMS_STATUS_IDX,
    .app_size     = sizeof(st_ble_cgms_status_t),
    .db_size      = BLE_CGMS_STATUS_LEN,
    .decode       = (ble_servs_attr_decode_t)decode_st_ble_cgms_status_t,
    .encode       = (ble_servs_attr_encode_t)encode_st_ble_cgms_status_t,
};

ble_status_t R_BLE_CGMS_SetStatus(const st_ble_cgms_status_t *p_value)
{
    return R_BLE_SERVS_SetChar(&gs_status_char, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_CGMS_GetStatus(st_ble_cgms_status_t *p_value)
{
    return R_BLE_SERVS_GetChar(&gs_status_char, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    CGM Session Start Time characteristic
----------------------------------------------------------------------------------------------------------------------*/
/***********************************************************************************************************************//**
* Function Name: decode_st_ble_cgms_session_start_time_t
* Description  : This function converts CGM Session Start Time characteristic value representation in
*                GATT (uint8_t[]) to representation in application layer (struct).
* Arguments    : p_app_value - pointer to the CGM Session Start Time value in the application layer
*                p_gatt_value - pointer to the characteristic value in the GATT database
* Return Value : ble_status_t
**********************************************************************************************************************/
static ble_status_t decode_st_ble_cgms_session_start_time_t(st_ble_cgms_session_start_time_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;
    uint16_t rec_crc = 0;
    ble_status_t ret = 0;
    
    if (BLE_CGMS_PRV_CGM_SESSION_START_LEN == p_gatt_value->value_len)
    {    
        memset((uint8_t*)p_app_value, 0x00, sizeof(st_ble_cgms_session_start_time_t));

        /*Copy the CGM_SESSION_START_TIME_Value*/
        BT_UNPACK_LE_2_BYTE(&p_app_value->session_start_time.year, &p_gatt_value->p_value[pos]);
        pos += (sizeof(p_app_value->session_start_time.year));

        p_app_value->session_start_time.month = p_gatt_value->p_value[pos++];
        p_app_value->session_start_time.day = p_gatt_value->p_value[pos++];
        p_app_value->session_start_time.hours = p_gatt_value->p_value[pos++];
        p_app_value->session_start_time.minutes = p_gatt_value->p_value[pos++];
        p_app_value->session_start_time.seconds = p_gatt_value->p_value[pos++];

        /*Copy the CGM_SESSION_START time_zone value*/
        BT_UNPACK_LE_1_BYTE(&p_app_value->time_zone, &p_gatt_value->p_value[pos++]);

        /*Copy the CGM_SESSION_START dst_offset value*/
        BT_UNPACK_LE_1_BYTE(&p_app_value->dst_offset, &p_gatt_value->p_value[pos++]);

        /*Copy the CGM_STATUS e2e_crc value*/
        BT_UNPACK_LE_2_BYTE(&p_app_value->e2e_crc, &p_gatt_value->p_value[pos]);
        pos += 2;
    }
    else
    {
        gs_crc_error = 1;
    }
    
    return BLE_SUCCESS;
}

/***********************************************************************************************************************//**
 * Function Name: encode_st_ble_cgms_session_start_time_t
 * Description  : This function converts CGM Session Start Time characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the CGM Session Start Time value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_cgms_session_start_time_t(const st_ble_cgms_session_start_time_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    st_ble_cgms_feat_t cgm_features;

    /* Get the CGMS FEATURES*/
    R_BLE_CGMS_GetFeat(&cgm_features);

    /* copy the value of session_start_time value*/
    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->session_start_time.year);
    pos += (sizeof(p_app_value->session_start_time.year));

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->session_start_time.month);
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->session_start_time.day);
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->session_start_time.hours);
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->session_start_time.minutes);
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->session_start_time.seconds);

    /* copy the value of time_zone value*/
    p_gatt_value->p_value[pos++] = p_app_value->time_zone;

    /* copy the value of dst_offset value*/
    p_gatt_value->p_value[pos++] = p_app_value->dst_offset;

    /* copy the value of e2e_crc value*/
    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->e2e_crc);
    pos += 2;

    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

/***********************************************************************************************************************//**
* Function Name: write_req_session_start_time
* Description  : This function handles the CGMS Session Start Time characteristic write request event.
* Arguments    : p_attr      - pointer to the attribute handle
                 conn_hdl    - connection handle
                 result      - BLE_STATUS
                 p_app_value - pointer to the CGM Session Start Time value in the application layer
* Return Value : None
**********************************************************************************************************************/
static void write_req_session_start_time(const void *p_attr, uint16_t conn_hdl, ble_status_t result, st_ble_cgms_session_start_time_t *p_app_value)
{
    st_ble_cgms_session_start_time_t session_start_time;

    session_start_time.time_zone = p_app_value->time_zone;

    if (BLE_CGMS_PRV_CGM_SESSION_START_TIME_INVALID_TIME_ZONE == session_start_time.time_zone)
    {
        R_BLE_GATTS_SendErrRsp(BLE_CGMS_SESSION_START_TIMEINVALID_TIME_ZONE_ERROR);
        return;
    }
    if (gs_crc_error)
    {
        R_BLE_GATTS_SendErrRsp(BLE_CGMS_MISSING_CRC_ERROR);
        gs_crc_error = 0;
        return;
    }

}

/* CGM Session Start Time characteristic definition */
static const st_ble_servs_char_info_t gs_session_start_time_char = 
{
    .start_hdl    = BLE_CGMS_SESSION_START_TIME_DECL_HDL,
    .end_hdl      = BLE_CGMS_SESSION_START_TIME_VAL_HDL,
    .char_idx     = BLE_CGMS_SESSION_START_TIME_IDX,
    .app_size     = sizeof(st_ble_cgms_session_start_time_t),
    .db_size      = BLE_CGMS_SESSION_START_TIME_LEN,
    .write_req_cb = (ble_servs_attr_write_req_t)write_req_session_start_time,
    .decode       = (ble_servs_attr_decode_t)decode_st_ble_cgms_session_start_time_t,
    .encode       = (ble_servs_attr_encode_t)encode_st_ble_cgms_session_start_time_t,
};

ble_status_t R_BLE_CGMS_SetSessionStartTime(const st_ble_cgms_session_start_time_t *p_value)
{
    return R_BLE_SERVS_SetChar(&gs_session_start_time_char, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_CGMS_GetSessionStartTime(st_ble_cgms_session_start_time_t *p_value)
{
    return R_BLE_SERVS_GetChar(&gs_session_start_time_char, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    CGM Session Run Time characteristic
----------------------------------------------------------------------------------------------------------------------*/
/***********************************************************************************************************************//**
* Function Name: decode_st_ble_cgms_session_run_time_t
* Description  : This function converts CGM Session Run Time characteristic value representation in
*                GATT (uint8_t[]) to representation in application layer (struct).
* Arguments    : p_app_value - pointer to the CGM Session Run Time value in the application layer
*                p_gatt_value - pointer to the characteristic value in the GATT database
* Return Value : ble_status_t
**********************************************************************************************************************/
static ble_status_t decode_st_ble_cgms_session_run_time_t(st_ble_cgms_session_run_time_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    if (BLE_CGMS_PRV_CGM_SESSION_RUN_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    memset((uint8_t*)p_app_value, 0x00, sizeof(*p_app_value));

    /*Copy the CGM_SESSION_RUN cgm_session_run_time value*/
    BT_UNPACK_LE_2_BYTE(&p_app_value->cgm_session_run_time, &p_gatt_value->p_value[pos]);
    pos += 2;

    /*Copy the CGM_SESSION_RUN e2e_crc value*/
    BT_UNPACK_LE_2_BYTE(&p_app_value->e2e_crc, &p_gatt_value->p_value[pos]);
    pos += 2;

    return BLE_SUCCESS;
}

/***********************************************************************************************************************//**
 * Function Name: encode_st_ble_cgms_session_run_time_t
 * Description  : This function converts CGM Session Run Time  characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the CGM Session Run Time value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_cgms_session_run_time_t(const st_ble_cgms_session_run_time_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    st_ble_cgms_feat_t cgm_features;

    /* Get the CGMS FEATURES*/
    R_BLE_CGMS_GetFeat(&cgm_features);

    /* copy the value of cgm_session_run_time value*/
    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->cgm_session_run_time);
    pos += 2;

    /* copy the value of e2e_crc value*/
    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->e2e_crc);
    pos += 2;

    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

/* CGM Session Run Time characteristic definition */
static const st_ble_servs_char_info_t gs_session_run_time_char = 
{
    .start_hdl    = BLE_CGMS_SESSION_RUN_TIME_DECL_HDL,
    .end_hdl      = BLE_CGMS_SESSION_RUN_TIME_VAL_HDL,
    .char_idx     = BLE_CGMS_SESSION_RUN_TIME_IDX,
    .app_size     = sizeof(st_ble_cgms_session_run_time_t),
    .db_size      = BLE_CGMS_SESSION_RUN_TIME_LEN,
    .decode       = (ble_servs_attr_decode_t)decode_st_ble_cgms_session_run_time_t,
    .encode       = (ble_servs_attr_encode_t)encode_st_ble_cgms_session_run_time_t,
};

ble_status_t R_BLE_CGMS_SetSessionRunTime(const st_ble_cgms_session_run_time_t *p_value)
{
    return R_BLE_SERVS_SetChar(&gs_session_run_time_char, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_CGMS_GetSessionRunTime(st_ble_cgms_session_run_time_t *p_value)
{
    return R_BLE_SERVS_GetChar(&gs_session_run_time_char, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Record Access Control Point Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

static const st_ble_servs_desc_info_t gs_record_access_cp_cli_cnfg = 
{
    .attr_hdl = BLE_CGMS_RECORD_ACCESS_CP_CLI_CNFG_DESC_HDL,
    .app_size = sizeof(uint16_t),
    .desc_idx = BLE_CGMS_RECORD_ACCESS_CP_CLI_CNFG_IDX,
    .db_size  = BLE_CGMS_RECORD_ACCESS_CP_CLI_CNFG_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_uint16_t,
    .encode   = (ble_servs_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_CGMS_SetRecordAccessCpCliCnfg(uint16_t conn_hdl, const uint16_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_record_access_cp_cli_cnfg, conn_hdl, (const void *)p_value);
}

ble_status_t R_BLE_CGMS_GetRecordAccessCpCliCnfg(uint16_t conn_hdl, uint16_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_record_access_cp_cli_cnfg, conn_hdl, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Record Access Control Point characteristic
----------------------------------------------------------------------------------------------------------------------*/
/***********************************************************************************************************************//**
* Function Name: decode_st_ble_cgms_record_access_cp_t
* Description  : This function converts CGM Record Access Control Point characteristic value representation in
*                GATT (uint8_t[]) to representation in application layer (struct).
* Arguments    : p_app_value - pointer to the CGM Record Access Control Point value in the application layer
*                p_gatt_value - pointer to the characteristic value in the GATT database
* Return Value : ble_status_t
**********************************************************************************************************************/
static ble_status_t decode_st_ble_cgms_record_access_cp_t(st_ble_cgms_record_access_cp_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    p_app_value->op_code = p_gatt_value->p_value[pos++];
    p_app_value->racp_operator = p_gatt_value->p_value[pos++];
    memcpy(p_app_value->operand, &p_gatt_value->p_value[pos], p_gatt_value->value_len - pos);
    p_app_value->operand_len = p_gatt_value->value_len - pos;

    return BLE_SUCCESS;
}

/***********************************************************************************************************************//**
* Function Name: encode_st_ble_cgms_record_access_cp_t
* Description  : This function converts CGM Record Access Control Point characteristic value representation in
*                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
* Arguments    : p_app_value - pointer to the CGM Record Access Control Point  value in the application layer
*                p_gatt_value - pointer to the characteristic value in the GATT database
* Return Value : ble_status_t
**********************************************************************************************************************/
static ble_status_t encode_st_ble_cgms_record_access_cp_t(const st_ble_cgms_record_access_cp_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    p_gatt_value->p_value[pos++] = p_app_value->op_code;
    p_gatt_value->p_value[pos++] = p_app_value->racp_operator;

    if (p_app_value->operand_len > 0)
    {
        uint32_t i = 0;
        for (i = 0; i < (p_app_value->operand_len); i++)
        {
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->operand[i]);
            pos += 1;
        }
    }

    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

/***********************************************************************************************************************//**
* Function Name: write_req_ra_ctrl_pt
* Description  : This function handles the Record Access Control Point characteristic write request event.
* Arguments    : p_attr      - pointer to the attribute handle
                 conn_hdl    - connection handle
                 result      - BLE_STATUS
                 p_app_value - pointer to the CGM Record Access Control Point  value in the application layer
* Return Value : None
**********************************************************************************************************************/
static void write_req_ra_ctrl_pt(const void *p_attr, uint16_t conn_hdl, ble_status_t result, st_ble_cgms_record_access_cp_t *p_app_value)
{
    static uint8_t count = 0;
    if ((0x01 == p_app_value->op_code) && (0x01 == p_app_value->racp_operator))
    {
        count++;
        if (2 == count)
        {
            gs_is_racp_in_progress = true;
        }
    }

    if (gs_is_racp_in_progress)
    {
        R_BLE_GATTS_SendErrRsp(BLE_CGMS_PROCEDURE_ALREADY_IN_PROGRESS_ERROR);
        return;
    }

    uint16_t cli_cnfg;
    R_BLE_CGMS_GetRecordAccessCpCliCnfg(conn_hdl,&cli_cnfg);
    if (BLE_GATTS_CLI_CNFG_INDICATION != cli_cnfg)
    {
        R_BLE_GATTS_SendErrRsp(BLE_CGMS_CLI_CNFG_IMPROPERLY_CONFIGURED_ERROR);
        return;
    }
}

/***********************************************************************************************************************//**
* Function Name: filter_record
* Description  : This function handles the Record Access Control Point characteristic write request event fliter records.
* Arguments    : p_record      - pointer to the cgm record
                 p_app_value - pointer to the CGM Record Access Control Point  value in the application layer
* Return Value : filterd record
**********************************************************************************************************************/
static bool filter_record(st_ble_cgms_record_t *p_record, st_ble_cgms_record_access_cp_t *p_app_value)
{
    bool filtered = false;
    if(NULL == p_record)
    {
        return filtered;
    }

    if ((BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_LESS_THAN_OR_EQUAL_TO == p_app_value->racp_operator) ||
        (BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_GREATER_THAN_OR_EQUAL_TO == p_app_value->racp_operator))
    {
        uint16_t param;
        uint8_t filter_type;

        filter_type = p_app_value->operand[0];
        BT_UNPACK_LE_2_BYTE(&param, &p_app_value->operand[1]);

        if (BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_LESS_THAN_OR_EQUAL_TO == p_app_value->racp_operator)
        {
            if (BLE_CGMS_RA_CTRL_PT_FILTER_TYPE_TIME_OFFSET == filter_type)
            {
                filtered = (p_record->meas.time_offset > param);
            }
            else //if (BLE_CGMS_RA_CTRL_PT_FILTER_TYPE_USER_FACING_TIME == filter_type)
            {
                /* Do Nothing */
            }
        }
        else //if (BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_GREATER_THAN_OR_EQUAL_TO == p_app_value->racp_operator)
        {
            if (BLE_CGMS_RA_CTRL_PT_FILTER_TYPE_TIME_OFFSET == filter_type)
            {
                filtered = (p_record->meas.time_offset < param);
            }
            else //if (BLE_CGMS_RA_CTRL_PT_FILTER_TYPE_USER_FACING_TIME == filter_type)
            {
                /* Do Nothing */
            }
        }
    }
    else if (BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_WITHIN_RANGE_OF == p_app_value->racp_operator)
    {
        uint16_t min_param;
        uint16_t max_param;
        uint8_t filter_type;

        filter_type = p_app_value->operand[0];
        BT_UNPACK_LE_2_BYTE(&min_param, &p_app_value->operand[1]);
        BT_UNPACK_LE_2_BYTE(&max_param, &p_app_value->operand[3]);

        if (BLE_CGMS_RA_CTRL_PT_FILTER_TYPE_TIME_OFFSET == filter_type)
        {
            filtered = (p_record->meas.time_offset < min_param) ||
                (p_record->meas.time_offset > max_param);
        }
        else //if (BLE_CGMS_RA_CTRL_PT_FILTER_TYPE_USER_FACING_TIME == filter_type)
        {
            /* Do Nothing */
        }
    }

    return filtered;
}

/***********************************************************************************************************************//**
 * Function Name: cgm_report_single_record
 * Description  : This function reports Single Stored record of CGM characteristic.
 * Arguments    : conn_hdl    - connection handle
 *                p_app_value - pointer to the characteristic value in the application database
 * Return Value : none
 **********************************************************************************************************************/
static void cgm_report_single_record(uint16_t conn_hdl, st_ble_cgms_record_access_cp_t *p_app_value)
{
    if (BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_FIRST_RECORD == p_app_value->racp_operator)
    {
        gs_index = cgms_db_get_oldest_index();
    }
    else if (BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_LAST_RECORD == p_app_value->racp_operator)
    {
        gs_index = cgms_db_get_newest_index();
    }

    st_ble_cgms_record_t *p_record;
    p_record = cgms_db_get_record(gs_index);
    if (NULL != p_record)
    {
        gs_num_of_sent++;
        cgm_notify_record(gs_conn_hdl, p_record);
    }

    cgm_send_ra_ctrl_pt_resp(gs_conn_hdl,
        BLE_CGMS_RECORD_ACCESS_CP_OP_CODE_RESPONSE_CODE,
        p_app_value->op_code,
        (0 == gs_num_of_sent) ? BLE_CGMS_RECORD_ACCESS_CP_RESPONSE_CODE_NO_RECORDS_FOUND :
        BLE_CGMS_RECORD_ACCESS_CP_RESPONSE_CODE_SUCCESS,
        0);
}

/***********************************************************************************************************************//**
 * Function Name: cgm_delete_single_record
 * Description  : This function deletes Single Stored record of CGM characteristic.
 * Arguments    : conn_hdl    - connection handle
 *                p_app_value - pointer to the characteristic value in the application database
 * Return Value : none
 **********************************************************************************************************************/
static void cgm_delete_single_record(uint16_t conn_hdl, st_ble_cgms_record_access_cp_t *p_app_value)
{
    uint16_t record_idx;
    uint8_t num_of_delete = 0;

    if (BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_FIRST_RECORD == p_app_value->racp_operator)
    {
        record_idx = cgms_db_get_oldest_index();
    }
    else if (BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_LAST_RECORD == p_app_value->racp_operator)
    {
        record_idx = cgms_db_get_newest_index();
    }

    st_ble_cgms_record_t *p_record;
    p_record = cgms_db_get_record(record_idx);
    if (NULL != p_record)
    {
        num_of_delete++;
    }

    cgms_db_mark_delete_record(record_idx);
    cgms_db_delete_records();

    cgm_send_ra_ctrl_pt_resp(gs_conn_hdl,
        BLE_CGMS_RECORD_ACCESS_CP_OP_CODE_RESPONSE_CODE,
        p_app_value->op_code,
        (0 == num_of_delete) ? BLE_CGMS_RECORD_ACCESS_CP_RESPONSE_CODE_NO_RECORDS_FOUND :
        BLE_CGMS_RECORD_ACCESS_CP_RESPONSE_CODE_SUCCESS,
        0);
}

/***********************************************************************************************************************//**
 * Function Name: cgm_report_num_of_single_record
 * Description  : This function reports the number of Single Stored records of CGM characteristic.
 * Arguments    : conn_hdl    - connection handle
 *                p_app_value - pointer to the characteristic value in the application database
 * Return Value : none
 **********************************************************************************************************************/
static void cgm_report_num_of_single_record(uint16_t conn_hdl, st_ble_cgms_record_access_cp_t *p_app_value)
{
    uint16_t record_idx;
    uint8_t num_of_records = 0;

    if (BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_FIRST_RECORD == p_app_value->racp_operator)
    {
        record_idx = cgms_db_get_oldest_index();
    }
    else if (BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_LAST_RECORD == p_app_value->racp_operator)
    {
        record_idx = cgms_db_get_newest_index();
    }

    st_ble_cgms_record_t *p_record;
    p_record = cgms_db_get_record(record_idx);
    if (NULL != p_record)
    {
        num_of_records++;
    }

    cgm_send_ra_ctrl_pt_resp(gs_conn_hdl,
        BLE_CGMS_RECORD_ACCESS_CP_OP_CODE_RESPONSE_CODE,
        p_app_value->op_code,
        (0 == num_of_records) ? BLE_CGMS_RECORD_ACCESS_CP_RESPONSE_CODE_NO_RECORDS_FOUND : 
        BLE_CGMS_RECORD_ACCESS_CP_RESPONSE_CODE_SUCCESS,
        num_of_records);
}


/***********************************************************************************************************************//**
 * Function Name: cgm_process_operation
 * Description  : This function handles the write request events and process the operation and sends the response .
 * Arguments    : conn_hdl    - connection handle
 *                p_app_value - pointer to the characteristic value in the application database
                  started     - process started indication
 * Return Value : none
 **********************************************************************************************************************/
static void cgm_process_operation(uint16_t conn_hdl, st_ble_cgms_record_access_cp_t *p_app_value, bool started)
{
    if (started)
    {
        gs_index = cgms_db_get_oldest_index();
        gs_num_of_sent = 0;
    }

    memcpy(&gs_cgms_record_access_cp, p_app_value, sizeof(gs_cgms_record_access_cp));

    gs_cgms_record_access_cp.op_code = p_app_value->op_code;
    gs_cgms_record_access_cp.operand[0] = p_app_value->operand[0];
    gs_cgms_record_access_cp.racp_operator = p_app_value->racp_operator;

    /* Unsupported Op Code */
    if ((BLE_CGMS_RECORD_ACCESS_CP_OP_CODE_REPORT_STORED_RECORDS > p_app_value->op_code) ||
        (BLE_CGMS_RECORD_ACCESS_CP_OP_CODE_REPORT_NUMBER_OF_STORED_RECORDS < p_app_value->op_code))
    {
        cgm_send_ra_ctrl_pt_resp(conn_hdl,
            BLE_CGMS_RECORD_ACCESS_CP_OP_CODE_RESPONSE_CODE,
            p_app_value->op_code,
            BLE_CGMS_RECORD_ACCESS_CP_RESPONSE_CODE_OP_CODE_NOT_SUPPORTED,
            0);
        return;
    }

    /* Unsupported Operator */
    if (BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_LAST_RECORD < p_app_value->racp_operator)
    {
        cgm_send_ra_ctrl_pt_resp(conn_hdl,
            BLE_CGMS_RECORD_ACCESS_CP_OP_CODE_RESPONSE_CODE,
            p_app_value->op_code,
            BLE_CGMS_RECORD_ACCESS_CP_RESPONSE_CODE_OPERATOR_NOT_SUPPORTED,
            0);
        return;
    }

    /* Unsupported Filter Type */
    if ((BLE_CGMS_RA_CTRL_PT_FILTER_TYPE_TIME_OFFSET != p_app_value->operand[0])
        && (BLE_CGMS_RECORD_ACCESS_CP_OP_CODE_REPORT_STORED_RECORDS == p_app_value->op_code)
        && (BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_GREATER_THAN_OR_EQUAL_TO == p_app_value->racp_operator))
    {
        cgm_send_ra_ctrl_pt_resp(conn_hdl,
            BLE_CGMS_RECORD_ACCESS_CP_OP_CODE_RESPONSE_CODE,
            p_app_value->op_code,
            BLE_CGMS_RECORD_ACCESS_CP_OP_CODE_RESPONSE_CODE_9,
            0);
        return;
    }

    if (((BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_WITHIN_RANGE_OF == p_app_value->racp_operator)) &&
        (BLE_CGMS_RECORD_ACCESS_CP_OP_CODE_REPORT_STORED_RECORDS == p_app_value->op_code) &&
        (0x01 == p_app_value->operand[0]) && (0xFF == p_app_value->operand[1]) && (0xFF == p_app_value->operand[2])
        && (0x00 == p_app_value->operand[3]) && (0x00 == p_app_value->operand[4]))
    {
        gs_cgms_record_access_cp.racp_operator = 0x00;
        cgm_send_ra_ctrl_pt_resp(conn_hdl,
            BLE_CGMS_RECORD_ACCESS_CP_OP_CODE_RESPONSE_CODE,
            p_app_value->op_code,
            BLE_CGMS_RECORD_ACCESS_CP_RESPONSE_CODE_INVALID_OPERAND,
            0);
        return;
    }

    /* Invalid Operand (The length of operand is invalid) */
    if (((BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_ALL_RECORDS == p_app_value->racp_operator)) &&
        (BLE_CGMS_RECORD_ACCESS_CP_OP_CODE_REPORT_STORED_RECORDS == p_app_value->op_code) &&
        (0x01 == p_app_value->operand[0]) && (0x01 == p_app_value->operand[1]) && (0x00 == p_app_value->operand[2]))
    {
        cgm_send_ra_ctrl_pt_resp(conn_hdl,
            BLE_CGMS_RECORD_ACCESS_CP_OP_CODE_RESPONSE_CODE,
            p_app_value->op_code,
            BLE_CGMS_RECORD_ACCESS_CP_RESPONSE_CODE_INVALID_OPERAND,
            0);
        return;
    }

    if ((BLE_CGMS_RECORD_ACCESS_CP_OP_CODE_REPORT_STORED_RECORDS == p_app_value->op_code) &&
        (BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_ALL_RECORDS == p_app_value->racp_operator))
    {
        R_BLE_SetEvent(cgms_racp_cb);
    }
    else if ((BLE_CGMS_RECORD_ACCESS_CP_OP_CODE_REPORT_STORED_RECORDS == p_app_value->op_code) &&
        ((BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_LESS_THAN_OR_EQUAL_TO == p_app_value->racp_operator) ||
        (BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_GREATER_THAN_OR_EQUAL_TO == p_app_value->racp_operator) ||
            (BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_WITHIN_RANGE_OF == p_app_value->racp_operator)))
    {
        R_BLE_SetEvent(cgms_racp_cb);
    }
    else if ((BLE_CGMS_RECORD_ACCESS_CP_OP_CODE_REPORT_STORED_RECORDS == p_app_value->op_code) &&
        ((BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_FIRST_RECORD == p_app_value->racp_operator) ||
        (BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_LAST_RECORD == p_app_value->racp_operator)))
    {
        cgm_report_single_record(conn_hdl, p_app_value);
    }
    else if ((BLE_CGMS_RECORD_ACCESS_CP_OP_CODE_DELETE_STORED_RECORDS == p_app_value->op_code) &&
        (BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_ALL_RECORDS == p_app_value->racp_operator))
    {
        R_BLE_SetEvent(cgms_racp_cb);
    }
    else if ((BLE_CGMS_RECORD_ACCESS_CP_OP_CODE_DELETE_STORED_RECORDS == p_app_value->op_code) &&
        ((BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_LESS_THAN_OR_EQUAL_TO == p_app_value->racp_operator) ||
        (BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_GREATER_THAN_OR_EQUAL_TO == p_app_value->racp_operator) ||
            (BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_WITHIN_RANGE_OF == p_app_value->racp_operator)))
    {
        R_BLE_SetEvent(cgms_racp_cb);
    }
    else if ((BLE_CGMS_RECORD_ACCESS_CP_OP_CODE_DELETE_STORED_RECORDS == p_app_value->op_code) &&
        ((BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_FIRST_RECORD == p_app_value->racp_operator) ||
        (BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_LAST_RECORD == p_app_value->racp_operator)))
    {
        cgm_delete_single_record(conn_hdl, p_app_value);
    }
    else if ((BLE_CGMS_RECORD_ACCESS_CP_OP_CODE_REPORT_NUMBER_OF_STORED_RECORDS == p_app_value->op_code) &&
        (BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_ALL_RECORDS == p_app_value->racp_operator))
    {
        R_BLE_SetEvent(cgms_racp_cb);
    }
    else if ((BLE_CGMS_RECORD_ACCESS_CP_OP_CODE_REPORT_NUMBER_OF_STORED_RECORDS == p_app_value->op_code) &&
        ((BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_LESS_THAN_OR_EQUAL_TO == p_app_value->racp_operator) ||
        (BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_GREATER_THAN_OR_EQUAL_TO == p_app_value->racp_operator) ||
            (BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_WITHIN_RANGE_OF == p_app_value->racp_operator)))
    {
        R_BLE_SetEvent(cgms_racp_cb);
    }
    else if ((BLE_CGMS_RECORD_ACCESS_CP_OP_CODE_REPORT_NUMBER_OF_STORED_RECORDS == p_app_value->op_code) &&
        ((BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_FIRST_RECORD == p_app_value->racp_operator) ||
        (BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_LAST_RECORD == p_app_value->racp_operator)))
    {
        cgm_report_num_of_single_record(conn_hdl, p_app_value);
    }
    else if (BLE_CGMS_RECORD_ACCESS_CP_OP_CODE_ABORT_OPERATION == p_app_value->op_code)
    {
        R_BLE_SetEvent(cgms_racp_cb);
    }
    else
    {
        cgm_send_ra_ctrl_pt_resp(conn_hdl,
            BLE_CGMS_RECORD_ACCESS_CP_OP_CODE_RESPONSE_CODE,
            p_app_value->op_code,
            BLE_CGMS_RECORD_ACCESS_CP_RESPONSE_CODE_INVALID_OPERATOR,
            0);
    }
}

/***********************************************************************************************************************//**
 * Function Name: cgms_racp_cb
 * Description  : This function is callback to the RACP events.
 * Arguments    : none
 * Return Value : none
 **********************************************************************************************************************/
static void cgms_racp_cb(void)
{
    ble_status_t ret;
    static uint8_t flag = 0;

    switch (gs_cgms_record_access_cp.op_code)
    {
        case BLE_CGMS_RECORD_ACCESS_CP_OP_CODE_REPORT_STORED_RECORDS:
        {
            if ((BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_ALL_RECORDS == gs_cgms_record_access_cp.racp_operator))
            {
                st_ble_cgms_record_t *p_record;
                p_record = cgms_db_get_record(gs_index);
                if ((NULL == p_record) || (p_record->next_index == cgms_db_get_oldest_index()))
                {
                    ret = cgm_notify_record(gs_conn_hdl, p_record);
                    if (BLE_SUCCESS != ret)
                    {
                        return;
                    }
                    gs_num_of_sent++;
                    gs_index = cgms_db_get_next_index(gs_index);
                    cgm_send_ra_ctrl_pt_resp(gs_conn_hdl,
                        BLE_CGMS_RECORD_ACCESS_CP_OP_CODE_RESPONSE_CODE,
                        gs_cgms_record_access_cp.op_code,
                        BLE_CGMS_RECORD_ACCESS_CP_RESPONSE_CODE_SUCCESS,
                        0);
                    gs_num_of_sent = 0;
                }
                else
                {
                
                    ret = cgm_notify_record(gs_conn_hdl, p_record);
                    if (BLE_SUCCESS != ret)
                    {
                        return;
                    }
                    gs_num_of_sent++;
                    gs_index = cgms_db_get_next_index(gs_index);
                    R_BLE_SetEvent(cgms_racp_cb);
                }
            }
            else if (((BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_LESS_THAN_OR_EQUAL_TO == gs_cgms_record_access_cp.racp_operator) ||
                (BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_GREATER_THAN_OR_EQUAL_TO == gs_cgms_record_access_cp.racp_operator) ||
                (BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_WITHIN_RANGE_OF == gs_cgms_record_access_cp.racp_operator)))
            {
                st_ble_cgms_record_t *p_record;
                p_record = cgms_db_get_record(gs_index);
                if ((NULL == p_record) || (p_record->next_index == cgms_db_get_oldest_index()))
                {
                    bool filtered = filter_record(p_record, &gs_cgms_record_access_cp);
                    if (filtered)
                    {
                        gs_index = cgms_db_get_next_index(gs_index);
                        flag = 1;
                    }

                    if (1 == flag)
                    {
                        R_BLE_SetEvent(cgms_racp_cb);
                        flag = 0;
                    }
                    else
                    {
                        ble_status_t ret = cgm_notify_record(gs_conn_hdl, p_record);
                        if (BLE_SUCCESS != ret)
                        {
                            return;
                        }
                        gs_num_of_sent++;
                        gs_index = cgms_db_get_next_index(gs_index);
                    }

                    cgm_send_ra_ctrl_pt_resp(gs_conn_hdl,
                        BLE_CGMS_RECORD_ACCESS_CP_OP_CODE_RESPONSE_CODE,
                        gs_cgms_record_access_cp.op_code,
                        (0 == gs_num_of_sent) ? BLE_CGMS_RECORD_ACCESS_CP_RESPONSE_CODE_NO_RECORDS_FOUND :
                        BLE_CGMS_RECORD_ACCESS_CP_RESPONSE_CODE_SUCCESS,
                        0);
                    gs_num_of_sent = 0;
                }
                else
                {
                    bool filtered = filter_record(p_record, &gs_cgms_record_access_cp);
                    if (filtered)
                    {
                        gs_index = cgms_db_get_next_index(gs_index);
                        flag = 1;
                    }

                    if (1 == flag)
                    {
                        R_BLE_SetEvent(cgms_racp_cb);
                        flag = 0;
                    }
                    else
                    {
                        ble_status_t ret = cgm_notify_record(gs_conn_hdl, p_record);
                        if (BLE_SUCCESS != ret)
                        {
                            return;
                        }
                        gs_num_of_sent++;
                        gs_index = cgms_db_get_next_index(gs_index);
                        R_BLE_SetEvent(cgms_racp_cb);
                    }
                }
            }
        }
        break;

        case BLE_CGMS_RECORD_ACCESS_CP_OP_CODE_DELETE_STORED_RECORDS:
        {
            if (BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_ALL_RECORDS == gs_cgms_record_access_cp.racp_operator)
            {
                st_ble_cgms_record_t *p_record;
                p_record = cgms_db_get_record(gs_index);
                if ((NULL == p_record) || (p_record->next_index == cgms_db_get_oldest_index()))
                {
                    cgms_db_mark_delete_record(gs_index);
                    gs_num_of_delete++;
                    gs_index = cgms_db_get_next_index(gs_index);
                    cgms_db_delete_records();

                    cgm_send_ra_ctrl_pt_resp(gs_conn_hdl,
                        BLE_CGMS_RECORD_ACCESS_CP_OP_CODE_RESPONSE_CODE,
                        gs_cgms_record_access_cp.op_code,
                        BLE_CGMS_RECORD_ACCESS_CP_RESPONSE_CODE_SUCCESS,
                        0);
                    gs_num_of_delete = 0;
                }
                else
                {
                    cgms_db_mark_delete_record(gs_index);
                    gs_num_of_delete++;
                    gs_index = cgms_db_get_next_index(gs_index);
                    R_BLE_SetEvent(cgms_racp_cb);
                }
            }
            else if ((BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_LESS_THAN_OR_EQUAL_TO == gs_cgms_record_access_cp.racp_operator) ||
                (BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_GREATER_THAN_OR_EQUAL_TO == gs_cgms_record_access_cp.racp_operator) ||
                    (BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_WITHIN_RANGE_OF == gs_cgms_record_access_cp.racp_operator))
            {
                st_ble_cgms_record_t *p_record;
                p_record = cgms_db_get_record(gs_index);
                if ((NULL == p_record) || (p_record->next_index == cgms_db_get_oldest_index()))
                {
                    cgms_db_mark_delete_record(gs_index);
                    gs_num_of_delete++;
                    gs_index = cgms_db_get_next_index(gs_index);
                    cgms_db_delete_records();

                    cgm_send_ra_ctrl_pt_resp(gs_conn_hdl,
                        BLE_CGMS_RECORD_ACCESS_CP_OP_CODE_RESPONSE_CODE,
                        gs_cgms_record_access_cp.op_code,
                        BLE_CGMS_RECORD_ACCESS_CP_RESPONSE_CODE_SUCCESS,
                        0);
                }
                else
                {
                    bool filtered = filter_record(p_record, &gs_cgms_record_access_cp);
                    if (filtered)
                    {
                        gs_index = cgms_db_get_next_index(gs_index);
                        flag = 1;
                    }

                    if (1 == flag)
                    {
                        R_BLE_SetEvent(cgms_racp_cb);
                        flag = 0;
                    }
                    else
                    {
                        cgms_db_mark_delete_record(gs_index);
                        gs_num_of_delete++;

                        gs_index = cgms_db_get_next_index(gs_index);
                        R_BLE_SetEvent(cgms_racp_cb);
                    }
                }
            }
        }
        break;

        case BLE_CGMS_RECORD_ACCESS_CP_OP_CODE_ABORT_OPERATION:
        {
            cgm_send_ra_ctrl_pt_resp(gs_conn_hdl,
                BLE_CGMS_RECORD_ACCESS_CP_OP_CODE_RESPONSE_CODE,
                BLE_CGMS_RECORD_ACCESS_CP_OP_CODE_ABORT_OPERATION,
                BLE_CGMS_RECORD_ACCESS_CP_RESPONSE_CODE_SUCCESS,
                0);
        }
        break;

        case BLE_CGMS_RECORD_ACCESS_CP_OP_CODE_REPORT_NUMBER_OF_STORED_RECORDS:
        {
            if (BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_ALL_RECORDS == gs_cgms_record_access_cp.racp_operator)
            {
                st_ble_cgms_record_t *p_record;
                p_record = cgms_db_get_record(gs_index);
                if ((NULL == p_record) || (p_record->next_index == cgms_db_get_oldest_index()))
                {
                    if (1 == gs_report_num_of_stored_records_flag)
                    {
                        gs_num_of_records++;
                        gs_index = cgms_db_get_next_index(gs_index);
                    }
                    cgm_send_ra_ctrl_pt_resp(gs_conn_hdl,
                        BLE_CGMS_RECORD_ACCESS_CP_OP_CODE_NUMBER_OF_STORED_RECORDS_RESPONSE,
                        gs_cgms_record_access_cp.op_code,
                        (0 == gs_num_of_records) ? BLE_CGMS_RECORD_ACCESS_CP_RESPONSE_CODE_NO_RECORDS_FOUND : BLE_CGMS_RECORD_ACCESS_CP_RESPONSE_CODE_SUCCESS,
                        gs_num_of_records);
                    gs_num_of_records = 0;
                    gs_report_num_of_stored_records_flag = 0;
                }
                else
                {
                    gs_num_of_records++;
                    gs_index = cgms_db_get_next_index(gs_index);
                    gs_report_num_of_stored_records_flag = 1;
                    R_BLE_SetEvent(cgms_racp_cb);
                }
            }
            else if ((BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_LESS_THAN_OR_EQUAL_TO == gs_cgms_record_access_cp.racp_operator) ||
                (BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_GREATER_THAN_OR_EQUAL_TO == gs_cgms_record_access_cp.racp_operator) ||
                    (BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_WITHIN_RANGE_OF == gs_cgms_record_access_cp.racp_operator))
            {
                st_ble_cgms_record_t *p_record;
                p_record = cgms_db_get_record(gs_index);
                if ((NULL == p_record) || (p_record->next_index == cgms_db_get_oldest_index()))
                {
                    if (1 == gs_report_num_of_stored_records_flag)
                    {
                        bool filtered = filter_record(p_record, &gs_cgms_record_access_cp);
                        if (filtered)
                        {
                            gs_index = cgms_db_get_next_index(gs_index);
                            flag = 1;
                        }

                        if (1 == flag)
                        {
                            R_BLE_SetEvent(cgms_racp_cb);
                            flag = 0;
                        }
                        else
                        {
                            gs_num_of_records++;
                            gs_index = cgms_db_get_next_index(gs_index);
                        }
                    }
                    cgm_send_ra_ctrl_pt_resp(gs_conn_hdl,
                        BLE_CGMS_RECORD_ACCESS_CP_OP_CODE_NUMBER_OF_STORED_RECORDS_RESPONSE,
                        gs_cgms_record_access_cp.op_code,
                        (0 == gs_num_of_records) ? BLE_CGMS_RECORD_ACCESS_CP_RESPONSE_CODE_NO_RECORDS_FOUND :
                        BLE_CGMS_RECORD_ACCESS_CP_RESPONSE_CODE_SUCCESS,
                        gs_num_of_records);
                    gs_num_of_records = 0;
                    gs_report_num_of_stored_records_flag = 0;
                }
                else
                {
                    bool filtered = filter_record(p_record, &gs_cgms_record_access_cp);
                    if (filtered)
                    {
                        gs_index = cgms_db_get_next_index(gs_index);
                        flag = 1;
                    }

                    if (1 == flag)
                    {
                        R_BLE_SetEvent(cgms_racp_cb);
                        flag = 0;
                    }
                    else
                    {
                        gs_num_of_records++;
                        gs_index = cgms_db_get_next_index(gs_index);
                        gs_report_num_of_stored_records_flag = 1;
                        R_BLE_SetEvent(cgms_racp_cb);
                    }
                }
            }
        }
        break;

        default:
        {
            /* Do Nothing */
        } 
        break;
    }

    gs_is_racp_in_progress = false;
}

/***********************************************************************************************************************//**
* Function Name: write_comp_ra_ctrl_pt
* Description  : This function handles the Record Access Control Point characteristic write complete event.
* Arguments    : p_attr      - pointer to the attribute handle
                 conn_hdl    - connection handle
                 result      - BLE_STATUS
                 p_app_value - pointer to the CGM Record Access Control Point  value in the application layer
* Return Value : None
**********************************************************************************************************************/
static void write_comp_ra_ctrl_pt(const void *p_attr,
    uint16_t conn_hdl,
    ble_status_t result,
    st_ble_cgms_record_access_cp_t *p_app_value)
{
    gs_is_racp_in_progress = true;
    gs_conn_hdl = conn_hdl;
    cgm_process_operation(conn_hdl, p_app_value, true);
}

/***********************************************************************************************************************//**
* Function Name: flow_ctrl_ra_ctrl_pt
* Description  : This function handles the Record Access Control Point characteristic write flow event.
* Arguments    : p_attr      - pointer to the attribute handle
* Return Value : None
**********************************************************************************************************************/
static void flow_ctrl_ra_ctrl_pt(const void *p_attr)
{
    if (gs_is_racp_in_progress)
    {
        st_ble_servs_char_info_t *p_char_attr = (st_ble_servs_char_info_t *)p_attr;
        st_ble_cgms_record_access_cp_t app_value;
        st_ble_gatt_value_t gatt_value;
        R_BLE_GATTS_GetAttr(gs_conn_hdl, p_char_attr->start_hdl + 1, &gatt_value);
        decode_st_ble_cgms_record_access_cp_t(&app_value, &gatt_value);
        cgm_process_operation(gs_conn_hdl, &app_value, false);
    }
}

/* Record Access Control Point characteristic descriptor definition */
static const st_ble_servs_desc_info_t *gspp_record_access_cp_descs[] =
{
    &gs_record_access_cp_cli_cnfg,
};

/* Record Access Control Point characteristic definition */
static const st_ble_servs_char_info_t gs_record_access_cp_char = 
{
    .start_hdl       = BLE_CGMS_RECORD_ACCESS_CP_DECL_HDL,
    .end_hdl         = BLE_CGMS_RECORD_ACCESS_CP_CLI_CNFG_DESC_HDL,
    .char_idx        = BLE_CGMS_RECORD_ACCESS_CP_IDX,
    .app_size        = sizeof(st_ble_cgms_record_access_cp_t),
    .db_size         = BLE_CGMS_RECORD_ACCESS_CP_LEN,
    .write_req_cb    = (ble_servs_attr_write_req_t)write_req_ra_ctrl_pt,
    .write_comp_cb   = (ble_servs_attr_write_comp_t)write_comp_ra_ctrl_pt,
    .flow_ctrl_cb    = (ble_servs_attr_flow_ctrl_t)flow_ctrl_ra_ctrl_pt,
    .decode          = (ble_servs_attr_decode_t)decode_st_ble_cgms_record_access_cp_t,
    .encode          = (ble_servs_attr_encode_t)encode_st_ble_cgms_record_access_cp_t,
    .pp_descs        = gspp_record_access_cp_descs,
    .num_of_descs    = ARRAY_SIZE(gspp_record_access_cp_descs),
};

ble_status_t R_BLE_CGMS_IndicateRecordAccessCp(uint16_t conn_hdl, const st_ble_cgms_record_access_cp_t *p_value)
{
    return R_BLE_SERVS_SendHdlVal(&gs_record_access_cp_char, conn_hdl, (const void *)p_value, false);
}

/*----------------------------------------------------------------------------------------------------------------------
    CGM Specific Ops Control Point Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

static const st_ble_servs_desc_info_t gs_specific_ops_cp_cli_cnfg = 
{
    .attr_hdl = BLE_CGMS_SPECIFIC_OPS_CP_CLI_CNFG_DESC_HDL,
    .app_size = sizeof(uint16_t),
    .desc_idx = BLE_CGMS_SPECIFIC_OPS_CP_CLI_CNFG_IDX,
    .db_size  = BLE_CGMS_SPECIFIC_OPS_CP_CLI_CNFG_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_uint16_t,
    .encode   = (ble_servs_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_CGMS_SetSpecificOpsCpCliCnfg(uint16_t conn_hdl, const uint16_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_specific_ops_cp_cli_cnfg, conn_hdl, (const void *)p_value);
}

ble_status_t R_BLE_CGMS_GetSpecificOpsCpCliCnfg(uint16_t conn_hdl, uint16_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_specific_ops_cp_cli_cnfg, conn_hdl, (void *)p_value);
}

/***********************************************************************************************************************
 * Function Name: e2e_crc_calculation
 * Description  : to calculate e2e crc.
 * Arguments    : message - message data.
 *                length - message length
 * Return Value : uint16_t
 **********************************************************************************************************************/
static uint16_t e2e_crc_calculation(uint8_t* meassage, uint16_t length)
{
    unsigned crc = 0xFFFF;
    while (length--)
    {
        crc ^= *meassage++;
        for (uint32_t k = 0; k < 8; k++)
            crc = crc & 1 ? (crc >> 1) ^ 0x8408 : crc >> 1;
    }
    return crc;
}

/***********************************************************************************************************************
 * Function Name: e2e_crc_check
 * Description  : to check crc.
 * Arguments    : message - message data.
 *                length - message length
 *                rec_crc - received crc value
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t e2e_crc_check(uint8_t* meassage, uint8_t length, uint16_t rec_crc)
{
    ble_status_t ret;
    st_ble_cgms_feat_t cgm_e2e_feature = { 0 };
    R_BLE_CGMS_GetFeat(&cgm_e2e_feature);

    uint16_t crc = e2e_crc_calculation(meassage, length);
    if (rec_crc == crc)
    {
        ret = BLE_SUCCESS;
    }
    else
    {
        ret = BLE_ERR_INVALID_DATA;
    }

    return ret;
}

/*----------------------------------------------------------------------------------------------------------------------
    CGM Specific Ops Control Point characteristic
----------------------------------------------------------------------------------------------------------------------*/
/***********************************************************************************************************************//**
* Function Name: decode_st_ble_cgms_specific_ops_cp_t
* Description  : This function converts CGM Specific Opcodes Control Point characteristic value representation in
*                GATT (uint8_t[]) to representation in application layer (struct).
* Arguments    : p_app_value - pointer to the CGM Specific Opcodes Control Point value in the application layer
*                p_gatt_value - pointer to the characteristic value in the GATT database
* Return Value : ble_status_t
**********************************************************************************************************************/
static ble_status_t decode_st_ble_cgms_specific_ops_cp_t(st_ble_cgms_specific_ops_cp_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;
    ble_status_t ret = 0;
    uint16_t e2e_crc = 0xFFFF;
    uint16_t rec_crc = 0;
    uint16_t check_crc = 0;

    if (BLE_CGMS_PRV_CGM_SPECIFIC_CP_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    memset((uint8_t*)p_app_value, 0x00, sizeof(st_ble_cgms_specific_ops_cp_t));

    /*Copy the CGM_SPECIFIC_CONTROL_POINT op_code value*/
    BT_UNPACK_LE_1_BYTE(&p_app_value->op_code, &p_gatt_value->p_value[pos++]);

    /*Copy the CGM_SPECIFIC_CONTROL_POINT op_code___response_codes value*/
    BT_UNPACK_LE_1_BYTE(&p_app_value->op_code_response_codes, &p_gatt_value->p_value[pos++]);

    /*Copy the CGM_SPECIFIC_CONTROL_POINT spec_cp_operand value*/
    BT_UNPACK_LE_1_BYTE(&p_app_value->operand, &p_gatt_value->p_value[pos++]);

    /*Copy the CGM_SPECIFIC_CONTROL_POINT calibration_value___glucose_concentration_of_calibration value*/
    BT_UNPACK_LE_2_BYTE(&p_app_value->calibration_data_record.calibration_value_glucose_concentration_of_calibration.mantissa, &p_gatt_value->p_value[pos]);
    p_app_value->calibration_data_record.calibration_value_glucose_concentration_of_calibration.exponent = (int8_t)(((int16_t)p_app_value->calibration_data_record.calibration_value_glucose_concentration_of_calibration.mantissa) >> 12);
    p_app_value->calibration_data_record.calibration_value_glucose_concentration_of_calibration.mantissa = (int16_t)(p_app_value->calibration_data_record.calibration_value_glucose_concentration_of_calibration.mantissa & 0x0FFF);

    pos += 2;

    /*Copy the CGM_SPECIFIC_CONTROL_POINT calibration_value___calibration_time value*/
    BT_UNPACK_LE_2_BYTE(&p_app_value->calibration_data_record.calibration_value_calibration_time, &p_gatt_value->p_value[pos]);
    pos += 2;

    /*Copy the CGM_SPECIFIC_CONTROL_POINT calibration_value___calibration_type value*/
    BT_UNPACK_LE_1_BYTE(&p_app_value->calibration_data_record.calibration_value_calibration_type, &p_gatt_value->p_value[pos++]);

    /*Copy the CGM_SPECIFIC_CONTROL_POINT calibration_value___calibration_sample_location value*/
    BT_UNPACK_LE_1_BYTE(&p_app_value->calibration_data_record.calibration_value_calibration_sample_location, &p_gatt_value->p_value[pos++]);

    /*Copy the CGM_SPECIFIC_CONTROL_POINT calibration_value___next_calibration_time value*/
    BT_UNPACK_LE_1_BYTE(&p_app_value->calibration_data_record.calibration_value_next_calibration_time, &p_gatt_value->p_value[pos]);
    pos += 2;

    /*Copy the CGM_SPECIFIC_CONTROL_POINT calibration_value___calibration_data_record_number value*/
    BT_UNPACK_LE_1_BYTE(&p_app_value->calibration_data_record.calibration_value_calibration_data_record_number, &p_gatt_value->p_value[pos]);
    pos += 2;

    uint8_t feature_byte1 = 0;
    BT_UNPACK_LE_1_BYTE(&feature_byte1, &p_gatt_value->p_value[pos++]);

    /* is_calibration_data_rejected__calibration_failed bit */
    if (feature_byte1 & BLE_CGMS_PRV_CGM_SPECIFIC_CP_CAL_VALUE_CAL_STATUS_CAL_DATA_REJECTED_OR_CAL_FAILED)
    {
        p_app_value->calibration_data_record.calibration_value_calibration_status.is_calibration_data_rejected = true;
    }
    else
    {
        p_app_value->calibration_data_record.calibration_value_calibration_status.is_calibration_data_rejected = false;
    }

    /* is_calibration_data_out_of_range bit */
    if (feature_byte1 & BLE_CGMS_PRV_CGM_SPECIFIC_CP_CAL_VALUE_CAL_STATUS_CAL_DATA_OUT_OFF_RANGE)
    {
        p_app_value->calibration_data_record.calibration_value_calibration_status.is_calibration_data_out_of_range = true;
    }
    else
    {
        p_app_value->calibration_data_record.calibration_value_calibration_status.is_calibration_data_out_of_range = false;
    }

    /* is_calibration_process_pending bit */
    if (feature_byte1 & BLE_CGMS_PRV_CGM_SPECIFIC_CP_CAL_VALUE_CAL_STATUS_CAL_DATA_PROCESS_PENDING)
    {
        p_app_value->calibration_data_record.calibration_value_calibration_status.is_calibration_process_pending = true;
    }
    else
    {
        p_app_value->calibration_data_record.calibration_value_calibration_status.is_calibration_process_pending = false;
    }

    /*Copy the CGM_SPECIFIC_CONTROL_POINT e2e_crc value*/
    ret = e2e_crc_check(p_gatt_value->p_value, p_gatt_value->value_len - 2, gs_specific_ops_cp.e2e_crc);
    if (BLE_SUCCESS == ret)
    {
        BT_UNPACK_LE_2_BYTE(&p_app_value->e2e_crc, &p_gatt_value->p_value[pos]);
        pos += 2;
    }
    else
    {
        R_BLE_GATTS_SendErrRsp(BLE_CGMS_INVALID_CRC_ERROR);
        return ret;
    }

    return BLE_SUCCESS;
}

/***********************************************************************************************************************//**
* Function Name: encode_st_ble_cgms_specific_ops_cp_t
* Description  : This function converts CGM Specific Opcodes Control Point characteristic value representation in
*                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
* Arguments    : p_app_value - pointer to the CGM Specific Opcodes Control Point value in the application layer
*                p_gatt_value - pointer to the characteristic value in the GATT database
* Return Value : ble_status_t
**********************************************************************************************************************/
static ble_status_t encode_st_ble_cgms_specific_ops_cp_t(const st_ble_cgms_specific_ops_cp_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;
    uint8_t flag = 0;
    uint16_t e2e_crc = 0xFFFF;
    ble_status_t ret = 0;

    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    if ((BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_CGM_COMMUNICATION_INTERVAL_RESPONSE == p_app_value->op_code))
    {
        /* copy the value of op_code value*/
        BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->op_code);

        /* copy the value of spec_cp_operand value*/
        BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->operand);
        
        /* copy the value of e2e_crc value*/
        e2e_crc = e2e_crc_calculation(p_gatt_value->p_value, pos);
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &e2e_crc);
        pos += 2;
    }
    else if ((BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_GLUCOSE_CALIBRATION_VALUE_RESPONSE == p_app_value->op_code) && 
        (BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_SET_CGM_COMMUNICATION_INTERVAL == p_app_value->operand))
    { 
        /* copy the value of op_code value*/
        BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->op_code);

        /* copy the value of spec_cp_operand value*/
        BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->operand);

        /* copy the value of calibration_value___glucose_concentration_of_calibration value*/
        uint16_t value_to_copy_calibration_value_glucose_concentration_of_calibration = 0;

        value_to_copy_calibration_value_glucose_concentration_of_calibration = (uint16_t)((((
            ((int16_t)(p_app_value->calibration_data_record.calibration_value_glucose_concentration_of_calibration.exponent)) << 12) & 0xF000)
            | (p_app_value->calibration_data_record.calibration_value_glucose_concentration_of_calibration.mantissa & 0x0FFF)));

        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], (uint8_t*)&value_to_copy_calibration_value_glucose_concentration_of_calibration);
        pos += 2;

        /* copy the value of calibration_value___calibration_time value*/
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->calibration_data_record.calibration_value_calibration_time);
        pos += 2;

        /* copy the value of calibration_value___calibration_sample_location value*/
        BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++],
            &p_app_value->calibration_data_record.calibration_value_calibration_sample_location);

        /* copy the value of calibration_value___next_calibration_time value*/
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->calibration_data_record.calibration_value_next_calibration_time);
        pos += 2;

        /* copy the value of calibration_value___calibration_data_record_number value*/
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], 
            &p_app_value->calibration_data_record.calibration_value_calibration_data_record_number);
        pos += 2;

        /* copy the value of e2e_crc value*/
        e2e_crc = e2e_crc_calculation(p_gatt_value->p_value, pos);
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &e2e_crc);
        pos += 2;
    }
    else if ((BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_GLUCOSE_CALIBRATION_VALUE_RESPONSE == p_app_value->op_code))
    {
        /* copy the value of op_code value*/
        BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->op_code);

        /* copy the value of calibration_value___glucose_concentration_of_calibration value*/
        uint16_t value_to_copy_calibration_value_glucose_concentration_of_calibration = 0;

        value_to_copy_calibration_value_glucose_concentration_of_calibration = (uint16_t)((((
            ((int16_t)(p_app_value->calibration_data_record.calibration_value_glucose_concentration_of_calibration.exponent)) << 12) & 0xF000)
            | (p_app_value->calibration_data_record.calibration_value_glucose_concentration_of_calibration.mantissa & 0x0FFF)));

        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &value_to_copy_calibration_value_glucose_concentration_of_calibration);
        pos += 2;

        /* copy the value of calibration_value___calibration_time value*/
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->calibration_data_record.calibration_value_calibration_time);
        pos += 2;

        /* copy the value of calibration_value___calibration_sample_location value*/
        p_gatt_value->p_value[pos++] = ((p_app_value->calibration_data_record.calibration_value_calibration_type) & 0x0f) | ((p_app_value->calibration_data_record.calibration_value_calibration_sample_location << 4) & 0xf0);

        /* copy the value of calibration_value___next_calibration_time value*/
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->calibration_data_record.calibration_value_next_calibration_time);
        pos += 2;

        /* copy the value of calibration_value___calibration_data_record_number value*/
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos],
            &p_app_value->calibration_data_record.calibration_value_calibration_data_record_number);
        pos += 2;

        uint8_t temp_status = (p_app_value->calibration_data_record.calibration_value_calibration_status.is_calibration_data_rejected & 0x01) |
            ((p_app_value->calibration_data_record.calibration_value_calibration_status.is_calibration_data_out_of_range & 0x01) << 1) |
            ((p_app_value->calibration_data_record.calibration_value_calibration_status.is_calibration_process_pending & 0x01) << 2);
        p_gatt_value->p_value[pos++] = temp_status;

        /* copy the value of e2e_crc value*/
        e2e_crc = e2e_crc_calculation(p_gatt_value->p_value, pos);
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &e2e_crc);
        pos += 2;
    }
    else if ((BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_PATIENT_HIGH_ALERT_LEVEL_RESPONSE == p_app_value->op_code) ||
             (BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_PATIENT_LOW_ALERT_LEVEL_RESPONSE == p_app_value->op_code) ||
             (BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_HYPER_ALERT_LEVEL_RESPONSE == p_app_value->op_code) || 
             (BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_RATE_OF_DECREASE_ALERT_LEVEL_RESPONSE == p_app_value->op_code) ||
             (BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_RATE_OF_INCREASE_ALERT_LEVEL_RESPONSE == p_app_value->op_code) || 
             (BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_HYPO_ALERT_LEVEL_RESPONSE == p_app_value->op_code) ||
             (BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_RESPONSE_CODE == p_app_value->op_code))
    {
        /* copy the value of op_code value*/
        BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->op_code);

        /* copy the value of spec_cp_operand value*/
        BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->operand);

         /* copy the value of spec_cp_operand value*/
        BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->op_code_response_codes);

        /* copy the value of e2e_crc value*/
        e2e_crc = e2e_crc_calculation(p_gatt_value->p_value, pos);
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &e2e_crc);
        pos += 2;
    }

    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

/***********************************************************************************************************************//**
* Function Name: write_req_specific_ops_ctrl_pt
* Description  : This function handles the CGM Specific Op_Code Control Point characteristic write request event.
* Arguments    : p_attr      - pointer to the attribute handle
                 conn_hdl    - connection handle
                 result      - BLE_STATUS
                 p_app_value - pointer to the CGM Record Access Control Point  value in the application layer
* Return Value : None
**********************************************************************************************************************/
static void write_req_specific_ops_ctrl_pt(const void *p_attr, uint16_t conn_hdl, ble_status_t result, st_ble_cgms_specific_ops_cp_t *p_app_value)
{
    ble_status_t ret = 0;
    st_ble_cgms_specific_ops_cp_t cgms_specific_ops_cp_res = { 0 };
    if (gs_is_racp_in_progress)
    {
        R_BLE_GATTS_SendErrRsp(BLE_CGMS_PROCEDURE_ALREADY_IN_PROGRESS_ERROR);
        return;
    }

    uint16_t cli_cnfg;
    R_BLE_CGMS_GetSpecificOpsCpCliCnfg(conn_hdl,&cli_cnfg);
    if (BLE_GATTS_CLI_CNFG_INDICATION != cli_cnfg)
    {
        R_BLE_GATTS_SendErrRsp(BLE_CGMS_CLI_CNFG_IMPROPERLY_CONFIGURED_ERROR);
        return;
    }

    if ((BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_SET_CGM_COMMUNICATION_INTERVAL == p_app_value->op_code)
        && BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_RESPONSE_CODES_PARAMETER_OUT_OF_RANGE == p_app_value->op_code_response_codes)
    {
        ret = e2e_crc_check((uint8_t *)p_app_value, BLE_CGMS_PRV_CGM_SPECIFIC_CP_LEN - 2, gs_specific_ops_cp.e2e_crc);
        if (BLE_SUCCESS == ret)
        {
            /* Do Nothing */
        }
        else
        {
            R_BLE_GATTS_SendErrRsp(BLE_CGMS_INVALID_CRC_ERROR);
        }
    }
    
}

/***********************************************************************************************************************
 * Function Name: rscs_cp_event_cb
 * Description  : This function is callback to the Specific OP_CODES Control Point events.
 * Arguments    : None
 * Return Value : none
 **********************************************************************************************************************/
static void rscs_cp_event_cb(void)
{
    static uint8_t communication_interval = 0;
    static uint8_t calibration_data_instanc = 0;
    static uint8_t high_alert_instanc = 0;
    static uint8_t low_alert__instanc = 0;
    static uint8_t hypo_alert_instanc = 0;
    static uint8_t hyper_alert_instanc = 0;
    static uint8_t rate_of_decrease_alert_instanc = 0;
    static uint8_t rate_of_increase_alert_instanc = 0;
    st_ble_cgms_specific_ops_cp_t cgms_specific_ops_cp_res = { 0 };
    st_ble_cgms_calibration_data_record_t cgms_calibration_data;

    st_ble_servs_evt_data_t evt_data =
    {
        .conn_hdl = gs_conn_hdl,
        .param_len = sizeof(gs_specific_ops_cp),
        .p_param = &gs_specific_ops_cp,
    };

    cgms_specific_ops_cp_res.op_code = gs_specific_ops_cp.op_code;
    cgms_specific_ops_cp_res.operand = gs_specific_ops_cp.operand;
    cgms_specific_ops_cp_res.e2e_crc = gs_specific_ops_cp.e2e_crc;
    cgms_specific_ops_cp_res.calibration_data_record = gs_specific_ops_cp.calibration_data_record;
    cgms_specific_ops_cp_res.op_code_response_codes = BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_RESPONSE_CODE;
    
    switch (gs_specific_ops_cp.op_code)
    {
        case BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_SET_CGM_COMMUNICATION_INTERVAL:
        {
            if (true == gs_specific_ops_cp.operand)
            {
                cgms_specific_ops_cp_res.op_code = 0x06;
                cgms_specific_ops_cp_res.operand = BLE_CGMS_SPECIFIC_OPS_CP_OPERAND_COMMUNICATION_INTERVAL_IN_MINUTES_1;
                cgms_specific_ops_cp_res.op_code_response_codes =
                    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_RESPONSE_CODES_INVALID_OPERAND;

                R_BLE_CGMS_IndicateSpecificOpsCp(gs_conn_hdl, &cgms_specific_ops_cp_res);
            }
            else if (false == gs_specific_ops_cp.op_code_response_codes)
            {
                communication_interval = 0x01;

                cgms_specific_ops_cp_res.op_code = 0x1C;
                cgms_specific_ops_cp_res.operand = BLE_CGMS_SPECIFIC_OPS_CP_OPERAND_COMMUNICATION_INTERVAL_IN_MINUTES_1;
                cgms_specific_ops_cp_res.op_code_response_codes =
                    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_RESPONSE_CODES_SUCCESS;

                R_BLE_CGMS_IndicateSpecificOpsCp(gs_conn_hdl, &cgms_specific_ops_cp_res);
            }
            else if (BLE_CGMS_PRV_RESPONSE_CODE_TWO == gs_specific_ops_cp.op_code_response_codes)
            {
                communication_interval = 0x02;

                cgms_specific_ops_cp_res.op_code = 0x1C;
                cgms_specific_ops_cp_res.operand = BLE_CGMS_SPECIFIC_OPS_CP_OPERAND_COMMUNICATION_INTERVAL_IN_MINUTES_1;
                cgms_specific_ops_cp_res.op_code_response_codes =
                   BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_RESPONSE_CODES_SUCCESS;

                R_BLE_CGMS_IndicateSpecificOpsCp(gs_conn_hdl, &cgms_specific_ops_cp_res);
            }
            else
            {
                cgms_specific_ops_cp_res.op_code = 0x1C;
                cgms_specific_ops_cp_res.operand = BLE_CGMS_SPECIFIC_OPS_CP_OPERAND_COMMUNICATION_INTERVAL_IN_MINUTES_1;
                cgms_specific_ops_cp_res.op_code_response_codes =
                    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_RESPONSE_CODES_SUCCESS;

                R_BLE_CGMS_IndicateSpecificOpsCp(gs_conn_hdl, &cgms_specific_ops_cp_res);
            }
        }
        break;
        
        case BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_GET_CGM_COMMUNICATION_INTERVAL:
        {
            if (true == communication_interval)
            {
                communication_interval = 0;
                cgms_specific_ops_cp_res.op_code = BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_CGM_COMMUNICATION_INTERVAL_RESPONSE;
                cgms_specific_ops_cp_res.operand = 0x00;

                R_BLE_CGMS_IndicateSpecificOpsCp(gs_conn_hdl, &cgms_specific_ops_cp_res);
            }
            else if (BLE_CGMS_PRV_RESPONSE_CODE_TWO == communication_interval)
            {
                communication_interval = 0;
                cgms_specific_ops_cp_res.op_code = BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_CGM_COMMUNICATION_INTERVAL_RESPONSE;
                cgms_specific_ops_cp_res.operand = 0x02;

                R_BLE_CGMS_IndicateSpecificOpsCp(gs_conn_hdl, &cgms_specific_ops_cp_res);
            }
            else
            {
                cgms_specific_ops_cp_res.op_code = BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_CGM_COMMUNICATION_INTERVAL_RESPONSE;
                cgms_specific_ops_cp_res.operand = BLE_CGMS_SPECIFIC_OPS_CP_OPERAND_COMMUNICATION_INTERVAL_IN_MINUTES_1;

                R_BLE_CGMS_IndicateSpecificOpsCp(gs_conn_hdl, &cgms_specific_ops_cp_res);
            }
        }
        break;

        case BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_SET_GLUCOSE_CALIBRATION_VALUE:
        {
            if (BLE_CGMS_PRV_CALIBRATION_VALUE_RESPONSE == gs_specific_ops_cp.op_code_response_codes)
            {
                calibration_data_instanc = gs_specific_ops_cp.op_code_response_codes;
                gs_socp_calibration_data = gs_specific_ops_cp.calibration_data_record;
                gs_socp_calibration_data.calibration_value_calibration_data_record_number = 0x01;
                cgms_specific_ops_cp_res.op_code = 0x1C;
                cgms_specific_ops_cp_res.operand =
                    BLE_CGMS_SPECIFIC_OPS_CP_OPERAND_OPERAND_VALUE_AS_DEFINED_IN_THE_CALIBRATION_VALUE_FIELDS_;
                cgms_specific_ops_cp_res.op_code_response_codes =
                    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_RESPONSE_CODES_SUCCESS;

                R_BLE_CGMS_IndicateSpecificOpsCp(gs_conn_hdl, &cgms_specific_ops_cp_res);
            }
        }
        break;

        case BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_GET_GLUCOSE_CALIBRATION_VALUE:
        {
            if (BLE_CGMS_PRV_CALIBRATION_VALUE_RESPONSE == calibration_data_instanc)
            {
                if (false == gs_specific_ops_cp.operand)
                {
                    calibration_data_instanc = 0;
                    cgms_specific_ops_cp_res.op_code = BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_GLUCOSE_CALIBRATION_VALUE_RESPONSE;
                    cgms_specific_ops_cp_res.operand = 0x04;
                    cgms_specific_ops_cp_res.calibration_data_record = gs_socp_calibration_data;
                    cgms_specific_ops_cp_res.op_code_response_codes = 0x01;

                    R_BLE_CGMS_IndicateSpecificOpsCp(gs_conn_hdl, &cgms_specific_ops_cp_res);
                }
                else
                {
                    calibration_data_instanc = 0;
                    cgms_specific_ops_cp_res.op_code = BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_GLUCOSE_CALIBRATION_VALUE_RESPONSE;
                    cgms_specific_ops_cp_res.operand = 0x5F;
                    cgms_specific_ops_cp_res.calibration_data_record.calibration_value_glucose_concentration_of_calibration.exponent = 0x00;
                    cgms_specific_ops_cp_res.calibration_data_record.calibration_value_glucose_concentration_of_calibration.mantissa = 0x04E;
                    cgms_specific_ops_cp_res.calibration_data_record.calibration_value_calibration_time = 0x0005;
                    cgms_specific_ops_cp_res.calibration_data_record.calibration_value_calibration_sample_location = 0x06;
                    cgms_specific_ops_cp_res.calibration_data_record.calibration_value_next_calibration_time = 0x0005;
                    cgms_specific_ops_cp_res.calibration_data_record.calibration_value_calibration_data_record_number = 0x0001;
                    cgms_specific_ops_cp_res.calibration_data_record.calibration_value_calibration_status.is_calibration_data_out_of_range = 0x00;
                    cgms_specific_ops_cp_res.calibration_data_record.calibration_value_calibration_status.is_calibration_data_rejected = 0x00;
                    cgms_specific_ops_cp_res.calibration_data_record.calibration_value_calibration_status.is_calibration_process_pending = 0x00;
                    cgms_specific_ops_cp_res.e2e_crc = 1;

                    R_BLE_CGMS_IndicateSpecificOpsCp(gs_conn_hdl, &cgms_specific_ops_cp_res);
                }
            }
            else if (BLE_CGMS_PRV_RESPONSE_CODE_FE == gs_specific_ops_cp.op_code_response_codes)
            {
                cgms_specific_ops_cp_res.op_code = 0x1C;
                cgms_specific_ops_cp_res.operand =
                    BLE_CGMS_SPECIFIC_OPS_CP_OPERAND_CALIBRATION_DATA_RECORD_NUMBER;
                cgms_specific_ops_cp_res.op_code_response_codes =
                    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_RESPONSE_CODES_PARAMETER_OUT_OF_RANGE;

                R_BLE_CGMS_IndicateSpecificOpsCp(gs_conn_hdl, &cgms_specific_ops_cp_res);
            }
            else
            {
                cgms_specific_ops_cp_res.op_code = BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_GLUCOSE_CALIBRATION_VALUE_RESPONSE;
                cgms_specific_ops_cp_res.operand = 0x5E;
                cgms_specific_ops_cp_res.calibration_data_record.calibration_value_glucose_concentration_of_calibration.exponent = 0x00;
                cgms_specific_ops_cp_res.calibration_data_record.calibration_value_glucose_concentration_of_calibration.mantissa = 0x04E;
                cgms_specific_ops_cp_res.calibration_data_record.calibration_value_calibration_time = 0x0005;
                cgms_specific_ops_cp_res.calibration_data_record.calibration_value_calibration_sample_location = 0x06;
                cgms_specific_ops_cp_res.calibration_data_record.calibration_value_next_calibration_time = 0x0005;
                cgms_specific_ops_cp_res.calibration_data_record.calibration_value_calibration_data_record_number = 0x0000;
                cgms_specific_ops_cp_res.calibration_data_record.calibration_value_calibration_status.is_calibration_data_out_of_range = 0x00;
                cgms_specific_ops_cp_res.calibration_data_record.calibration_value_calibration_status.is_calibration_data_rejected = 0x00;
                cgms_specific_ops_cp_res.calibration_data_record.calibration_value_calibration_status.is_calibration_process_pending = 0x00;
                cgms_specific_ops_cp_res.e2e_crc = 01;
                R_BLE_CGMS_IndicateSpecificOpsCp(gs_conn_hdl, &cgms_specific_ops_cp_res);
            }
        }
        break;

        case BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_SET_PATIENT_LOW_ALERT_LEVEL:
        {
            if ((BLE_CGMS_PRV_LOW_ALERT_RESPONSE == gs_specific_ops_cp.op_code_response_codes))
            {
                low_alert__instanc = 54;
                cgms_specific_ops_cp_res.op_code = 0x1C;
                cgms_specific_ops_cp_res.operand = 0x0A;
                cgms_specific_ops_cp_res.op_code_response_codes =
                    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_RESPONSE_CODES_SUCCESS;

                R_BLE_CGMS_IndicateSpecificOpsCp(gs_conn_hdl, &cgms_specific_ops_cp_res);
            }
            else
            {
                cgms_specific_ops_cp_res.op_code = 0x1C;
                cgms_specific_ops_cp_res.operand = 0x0A;
                cgms_specific_ops_cp_res.op_code_response_codes =
                    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_RESPONSE_CODES_PARAMETER_OUT_OF_RANGE;

                R_BLE_CGMS_IndicateSpecificOpsCp(gs_conn_hdl, &cgms_specific_ops_cp_res);
            }
        }
        break;

        case BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_GET_PATIENT_LOW_ALERT_LEVEL:
        {
            if (BLE_CGMS_PRV_LOW_ALERT_RESPONSE == low_alert__instanc)
            {
                low_alert__instanc = 0;
                cgms_specific_ops_cp_res.op_code = 0x0C;
                cgms_specific_ops_cp_res.operand = 54;
                cgms_specific_ops_cp_res.op_code_response_codes = 0x00;

                R_BLE_CGMS_IndicateSpecificOpsCp(gs_conn_hdl, &cgms_specific_ops_cp_res);
            }
            else
            {
                cgms_specific_ops_cp_res.op_code = 0x0C;
                cgms_specific_ops_cp_res.operand = BLE_CGMS_SPECIFIC_OPS_CP_OPERAND_PATIENT_LOW_BG_VALUE_IN_MG_DL_1;

                R_BLE_CGMS_IndicateSpecificOpsCp(gs_conn_hdl, &cgms_specific_ops_cp_res);
            }
        }
        break;

        case BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_SET_PATIENT_HIGH_ALERT_LEVEL:
        {
            if (BLE_CGMS_PRV_RATE_OF_INCREASE_ALERT_RESPONSE == gs_specific_ops_cp.op_code_response_codes)
            {
                high_alert_instanc = 85;
                cgms_specific_ops_cp_res.op_code = 0x1C;
                cgms_specific_ops_cp_res.operand = 0x07;
                cgms_specific_ops_cp_res.op_code_response_codes =
                    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_RESPONSE_CODES_SUCCESS;

                R_BLE_CGMS_IndicateSpecificOpsCp(gs_conn_hdl, &cgms_specific_ops_cp_res);
            }
            else
            {
                cgms_specific_ops_cp_res.op_code = 0x1C;
                cgms_specific_ops_cp_res.operand = 0x07;
                cgms_specific_ops_cp_res.op_code_response_codes =
                    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_RESPONSE_CODES_PARAMETER_OUT_OF_RANGE;

                R_BLE_CGMS_IndicateSpecificOpsCp(gs_conn_hdl, &cgms_specific_ops_cp_res);
            }
        }
        break;

        case BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_GET_PATIENT_HIGH_ALERT_LEVEL:
        {
            if (BLE_CGMS_PRV_RATE_OF_INCREASE_ALERT_RESPONSE == high_alert_instanc)
            {
                high_alert_instanc = 0;
                cgms_specific_ops_cp_res.op_code = BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_PATIENT_HIGH_ALERT_LEVEL_RESPONSE;
                cgms_specific_ops_cp_res.operand = 0x55;
                cgms_specific_ops_cp_res.op_code_response_codes = 0x02;

                R_BLE_CGMS_IndicateSpecificOpsCp(gs_conn_hdl, &cgms_specific_ops_cp_res);
            }
            else
            {
                cgms_specific_ops_cp_res.op_code = BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_PATIENT_HIGH_ALERT_LEVEL_RESPONSE;
                cgms_specific_ops_cp_res.operand = BLE_CGMS_SPECIFIC_OPS_CP_OPERAND_PATIENT_HIGH_BG_VALUE_IN_MG_DL_2;

                R_BLE_CGMS_IndicateSpecificOpsCp(gs_conn_hdl, &cgms_specific_ops_cp_res);
            }
        }
        break;

        case BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_SET_HYPO_ALERT_LEVEL:
        {
            if (BLE_CGMS_PRV_LOW_ALERT_RESPONSE == gs_specific_ops_cp.op_code_response_codes)
            {
                hypo_alert_instanc = 54;
                cgms_specific_ops_cp_res.op_code = 0x1C;
                cgms_specific_ops_cp_res.operand = 0x0D;
                cgms_specific_ops_cp_res.op_code_response_codes =
                    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_RESPONSE_CODES_SUCCESS;

                R_BLE_CGMS_IndicateSpecificOpsCp(gs_conn_hdl, &cgms_specific_ops_cp_res);
            }
            else
            {
                cgms_specific_ops_cp_res.op_code = 0x1C;
                cgms_specific_ops_cp_res.operand = 0x0D;
                cgms_specific_ops_cp_res.op_code_response_codes =
                    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_RESPONSE_CODES_PARAMETER_OUT_OF_RANGE;

                R_BLE_CGMS_IndicateSpecificOpsCp(gs_conn_hdl, &cgms_specific_ops_cp_res);
            }
        }
        break;

        case BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_GET_HYPO_ALERT_LEVEL:
        {
            if (BLE_CGMS_PRV_LOW_ALERT_RESPONSE == hypo_alert_instanc)
            {
                hypo_alert_instanc = 0;
                cgms_specific_ops_cp_res.op_code = BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_HYPO_ALERT_LEVEL_RESPONSE;
                cgms_specific_ops_cp_res.operand = 54;
                cgms_specific_ops_cp_res.op_code_response_codes =0x00;

                R_BLE_CGMS_IndicateSpecificOpsCp(gs_conn_hdl, &cgms_specific_ops_cp_res);
            }
            else
            {
                cgms_specific_ops_cp_res.op_code = BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_HYPO_ALERT_LEVEL_RESPONSE;
                cgms_specific_ops_cp_res.operand = BLE_CGMS_SPECIFIC_OPS_CP_OPERAND_HYPER_ALERT_LEVEL_VALUE_IN_MG_DL_2;
                cgms_specific_ops_cp_res.op_code_response_codes =
                    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_RESPONSE_CODES_SUCCESS;

                R_BLE_CGMS_IndicateSpecificOpsCp(gs_conn_hdl, &cgms_specific_ops_cp_res);
            }
        }
        break;

        case BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_SET_HYPER_ALERT_LEVEL:
        {
            if (BLE_CGMS_PRV_RATE_OF_INCREASE_ALERT_RESPONSE == gs_specific_ops_cp.op_code_response_codes)
            {
                hyper_alert_instanc = 85;
                cgms_specific_ops_cp_res.op_code = 0x1C;
                cgms_specific_ops_cp_res.operand = 0x10;
                cgms_specific_ops_cp_res.op_code_response_codes =
                    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_RESPONSE_CODES_SUCCESS;

                R_BLE_CGMS_IndicateSpecificOpsCp(gs_conn_hdl, &cgms_specific_ops_cp_res);
            }
            else
            {
                cgms_specific_ops_cp_res.op_code = 0x1C;
                cgms_specific_ops_cp_res.operand = 0x10;
                cgms_specific_ops_cp_res.op_code_response_codes =
                    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_RESPONSE_CODES_PARAMETER_OUT_OF_RANGE;

                R_BLE_CGMS_IndicateSpecificOpsCp(gs_conn_hdl, &cgms_specific_ops_cp_res);
            }
        }
        break;

        case BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_GET_HYPER_ALERT_LEVEL:
        {
            if (BLE_CGMS_PRV_RATE_OF_INCREASE_ALERT_RESPONSE == hyper_alert_instanc)
            {
                hyper_alert_instanc = 0;
                cgms_specific_ops_cp_res.op_code = BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_HYPER_ALERT_LEVEL_RESPONSE;
                cgms_specific_ops_cp_res.operand = 0x55;
                cgms_specific_ops_cp_res.op_code_response_codes = 0x02;

                R_BLE_CGMS_IndicateSpecificOpsCp(gs_conn_hdl, &cgms_specific_ops_cp_res);
            }
            else
            {
                cgms_specific_ops_cp_res.op_code = BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_HYPER_ALERT_LEVEL_RESPONSE;
                cgms_specific_ops_cp_res.operand = BLE_CGMS_SPECIFIC_OPS_CP_OPERAND_HYPER_ALERT_LEVEL_VALUE_IN_MG_DL_2;
                cgms_specific_ops_cp_res.op_code_response_codes =
                    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_RESPONSE_CODES_SUCCESS;

                R_BLE_CGMS_IndicateSpecificOpsCp(gs_conn_hdl, &cgms_specific_ops_cp_res);
            }
        }
        break;

        case BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_SET_RATE_OF_DECREASE_ALERT_LEVEL:
        {
            if (BLE_CGMS_PRV_LOW_ALERT_RESPONSE == gs_specific_ops_cp.op_code_response_codes)
            {
                rate_of_decrease_alert_instanc = 54;
                cgms_specific_ops_cp_res.op_code = 0x1C;
                cgms_specific_ops_cp_res.operand = 0x13;
                cgms_specific_ops_cp_res.op_code_response_codes =
                    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_RESPONSE_CODES_SUCCESS;

                R_BLE_CGMS_IndicateSpecificOpsCp(gs_conn_hdl, &cgms_specific_ops_cp_res);
            }
            else
            {
                cgms_specific_ops_cp_res.op_code = 0x1C;
                cgms_specific_ops_cp_res.operand = 0x13;
                cgms_specific_ops_cp_res.op_code_response_codes =
                    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_RESPONSE_CODES_PARAMETER_OUT_OF_RANGE;

                R_BLE_CGMS_IndicateSpecificOpsCp(gs_conn_hdl, &cgms_specific_ops_cp_res);
            }
        }
        break;

        case BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_GET_RATE_OF_DECREASE_ALERT_LEVEL:
        {
            if (BLE_CGMS_PRV_LOW_ALERT_RESPONSE == rate_of_decrease_alert_instanc)
            {
                rate_of_decrease_alert_instanc = 0;
                cgms_specific_ops_cp_res.op_code = BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_RATE_OF_DECREASE_ALERT_LEVEL_RESPONSE;
                cgms_specific_ops_cp_res.operand = 54;
                cgms_specific_ops_cp_res.op_code_response_codes = 0x00;

                R_BLE_CGMS_IndicateSpecificOpsCp(gs_conn_hdl, &cgms_specific_ops_cp_res);
            }
            else
            {
                cgms_specific_ops_cp_res.op_code = BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_RATE_OF_DECREASE_ALERT_LEVEL_RESPONSE;
                cgms_specific_ops_cp_res.operand = BLE_CGMS_SPECIFIC_OPS_CP_OPERAND_RATE_OF_DECREASE_ALERT_LEVEL_VALUE_IN_MG_DL_MIN_2;
                cgms_specific_ops_cp_res.op_code_response_codes =
                    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_RESPONSE_CODES_SUCCESS;

                R_BLE_CGMS_IndicateSpecificOpsCp(gs_conn_hdl, &cgms_specific_ops_cp_res);
            }
        }
        break;

        case BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_SET_RATE_OF_INCREASE_ALERT_LEVEL:
        {
            if (BLE_CGMS_PRV_RATE_OF_INCREASE_ALERT_RESPONSE == gs_specific_ops_cp.op_code_response_codes)
            {
                rate_of_increase_alert_instanc = 85;
                cgms_specific_ops_cp_res.op_code = 0x1C;
                cgms_specific_ops_cp_res.operand = 0x16;
                cgms_specific_ops_cp_res.op_code_response_codes =
                    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_RESPONSE_CODES_SUCCESS;

                R_BLE_CGMS_IndicateSpecificOpsCp(gs_conn_hdl, &cgms_specific_ops_cp_res);
            }
            else
            {
                cgms_specific_ops_cp_res.op_code = 0x1C;
                cgms_specific_ops_cp_res.operand = 0x16;
                cgms_specific_ops_cp_res.op_code_response_codes =
                    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_RESPONSE_CODES_PARAMETER_OUT_OF_RANGE;

                R_BLE_CGMS_IndicateSpecificOpsCp(gs_conn_hdl, &cgms_specific_ops_cp_res);
            }
        }
        break;

        case BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_GET_RATE_OF_INCREASE_ALERT_LEVEL:
        {
            if (BLE_CGMS_PRV_RATE_OF_INCREASE_ALERT_RESPONSE == rate_of_increase_alert_instanc)
            {
                rate_of_increase_alert_instanc = 0;
                cgms_specific_ops_cp_res.op_code = BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_RATE_OF_INCREASE_ALERT_LEVEL_RESPONSE;
                cgms_specific_ops_cp_res.operand = 0x55;
                cgms_specific_ops_cp_res.op_code_response_codes = 0x02;

                R_BLE_CGMS_IndicateSpecificOpsCp(gs_conn_hdl, &cgms_specific_ops_cp_res);
            }
            else
            {
                cgms_specific_ops_cp_res.op_code = BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_RATE_OF_INCREASE_ALERT_LEVEL_RESPONSE;
                cgms_specific_ops_cp_res.operand = BLE_CGMS_SPECIFIC_OPS_CP_OPERAND_RATE_OF_INCREASE_ALERT_LEVEL_VALUE_IN_MG_DL_MIN_2;
                cgms_specific_ops_cp_res.op_code_response_codes =
                    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_RESPONSE_CODES_SUCCESS;

                R_BLE_CGMS_IndicateSpecificOpsCp(gs_conn_hdl, &cgms_specific_ops_cp_res);
            }
        }
        break;

        case BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_RESET_DEVICE_SPECIFIC_ALERT:
        {
            cgms_specific_ops_cp_res.op_code = 0x1C;
            cgms_specific_ops_cp_res.operand = 0x19;
            cgms_specific_ops_cp_res.op_code_response_codes =
                BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_RESPONSE_CODES_SUCCESS;
            
            R_BLE_CGMS_IndicateSpecificOpsCp(gs_conn_hdl, &cgms_specific_ops_cp_res);

            cgm_status.cgm_status.is_device_specific_alert = 0;
            R_BLE_CGMS_SetStatus(&cgm_status);
        }
        break;

        /*  CGMS/SEN/CGMCP/BV-22-C    CGMS/SEN/CGMCP/BI-08-C*/
        case BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_START_THE_SESSION:
        {
            if (false == cgm_status.cgm_status.is_session_stopped)
            {
                cgms_specific_ops_cp_res.op_code = 0x1C;
                cgms_specific_ops_cp_res.operand = 0x1A;
                cgms_specific_ops_cp_res.op_code_response_codes =
                    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_RESPONSE_CODES_PROCEDURE_NOT_COMPLETED;

                R_BLE_CGMS_IndicateSpecificOpsCp(gs_conn_hdl, &cgms_specific_ops_cp_res);
            }
            if (BLE_CGMS_PRV_START_SESSION_RESPONSE == gs_specific_ops_cp.op_code_response_codes)
            {
                cgms_specific_ops_cp_res.op_code = 0x1C;
                cgms_specific_ops_cp_res.operand = 0x1A;
                cgms_specific_ops_cp_res.op_code_response_codes =
                    BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_RESPONSE_CODES_SUCCESS;

                R_BLE_CGMS_IndicateSpecificOpsCp(gs_conn_hdl, &cgms_specific_ops_cp_res);

                cgm_status.cgm_status.is_session_stopped = 0;
                R_BLE_CGMS_SetStatus(&cgm_status);
            }
            else
            {
                /* DO Nothing */
            }
        }
        break;

        case BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_STOP_THE_SESSION:
        {
            cgms_specific_ops_cp_res.op_code = 0x1C;
            cgms_specific_ops_cp_res.operand = 0x1B;
            cgms_specific_ops_cp_res.op_code_response_codes =
                BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_RESPONSE_CODES_SUCCESS;
            
            R_BLE_CGMS_IndicateSpecificOpsCp(gs_conn_hdl, &cgms_specific_ops_cp_res);

            cgm_status.cgm_status.is_session_stopped = 1;
            R_BLE_CGMS_SetStatus(&cgm_status);
        }
        break;
    }
}

/***********************************************************************************************************************//**
 * Function Name: cgm_specific_ops_process_operation
 * Description  : This function handles the write request events and process the operation and sends the response .
 * Arguments    : conn_hdl    - connection handle
 *                p_app_value - pointer to the characteristic value in the application database
                  started     - process started indication
 * Return Value : none
 **********************************************************************************************************************/
static void cgm_specific_ops_process_operation(uint16_t conn_hdl, st_ble_cgms_specific_ops_cp_t *p_app_value, bool started)
{
    ble_status_t ret = 0;
    if (started)
    {
        gs_index = cgms_db_get_oldest_index();
        gs_num_of_sent = 0;
    }

    gs_specific_ops_cp.op_code = p_app_value->op_code;
    gs_specific_ops_cp.operand = p_app_value->operand;
    gs_specific_ops_cp.op_code_response_codes = p_app_value->op_code_response_codes;
    gs_specific_ops_cp.calibration_data_record = p_app_value->calibration_data_record;
    gs_specific_ops_cp.e2e_crc = p_app_value->e2e_crc;

    if ((BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_SET_CGM_COMMUNICATION_INTERVAL == p_app_value->op_code)
        && BLE_CGMS_SPECIFIC_OPS_CP_OP_CODE_RESPONSE_CODES_PARAMETER_OUT_OF_RANGE == p_app_value->op_code_response_codes)
    {
        R_BLE_GATTS_SendErrRsp(BLE_CGMS_INVALID_CRC_ERROR);
        return;
    }

    R_BLE_SetEvent(rscs_cp_event_cb);
    gs_is_racp_in_progress = false;
}

/***********************************************************************************************************************//**
* Function Name: write_comp_specific__ops_ctrl_pt
* Description  : This function handles the CGM Specific Op_Code Control Point characteristic write complete event.
* Arguments    : p_attr      - pointer to the attribute handle
                 conn_hdl    - connection handle
                 result      - BLE_STATUS
                 p_app_value - pointer to the CGM Record Access Control Point  value in the application layer
* Return Value : None
**********************************************************************************************************************/
static void write_comp_specific__ops_ctrl_pt(const void *p_attr,
    uint16_t conn_hdl,
    ble_status_t result,
    st_ble_cgms_specific_ops_cp_t *p_app_value)
{
    gs_is_racp_in_progress = true;
    gs_conn_hdl = conn_hdl;
    cgm_specific_ops_process_operation(conn_hdl, p_app_value, true);
}

/***********************************************************************************************************************//**
* Function Name: flow_ctrl_specific_ops_ctrl_pt
* Description  : This function handles the CGM Specific OP_CODE Control Point characteristic write flow event.
* Arguments    : p_attr      - pointer to the attribute handle
* Return Value : None
**********************************************************************************************************************/
static void flow_ctrl_specific_ops_ctrl_pt(const void *p_attr)
{
    if (gs_is_racp_in_progress)
    {
        st_ble_servs_char_info_t *p_char_attr = (st_ble_servs_char_info_t *)p_attr;
        st_ble_cgms_specific_ops_cp_t app_value;
        st_ble_gatt_value_t gatt_value;
        R_BLE_GATTS_GetAttr(gs_conn_hdl, p_char_attr->start_hdl + 1, &gatt_value);
        decode_st_ble_cgms_specific_ops_cp_t(&app_value, &gatt_value);
        cgm_specific_ops_process_operation(gs_conn_hdl, &app_value, false);
    }
}

/* CGM Specific Ops Control Point characteristic descriptor definition */
static const st_ble_servs_desc_info_t *gspp_specific_ops_cp_descs[] = 
{
    &gs_specific_ops_cp_cli_cnfg,
};

/* CGM Specific Ops Control Point characteristic definition */
static const st_ble_servs_char_info_t gs_specific_ops_cp_char =
{
    .start_hdl    = BLE_CGMS_SPECIFIC_OPS_CP_DECL_HDL,
    .end_hdl      = BLE_CGMS_SPECIFIC_OPS_CP_CLI_CNFG_DESC_HDL,
    .char_idx     = BLE_CGMS_SPECIFIC_OPS_CP_IDX,
    .app_size     = sizeof(st_ble_cgms_specific_ops_cp_t),
    .db_size      = BLE_CGMS_SPECIFIC_OPS_CP_LEN,
    .write_req_cb = (ble_servs_attr_write_req_t)write_req_specific_ops_ctrl_pt,
    .write_comp_cb = (ble_servs_attr_write_comp_t)write_comp_specific__ops_ctrl_pt,
    .flow_ctrl_cb = (ble_servs_attr_flow_ctrl_t)flow_ctrl_specific_ops_ctrl_pt,
    .decode       = (ble_servs_attr_decode_t)decode_st_ble_cgms_specific_ops_cp_t,
    .encode       = (ble_servs_attr_encode_t)encode_st_ble_cgms_specific_ops_cp_t,
    .pp_descs     = gspp_specific_ops_cp_descs,
    .num_of_descs = ARRAY_SIZE(gspp_specific_ops_cp_descs),
};

ble_status_t R_BLE_CGMS_IndicateSpecificOpsCp(uint16_t conn_hdl, const st_ble_cgms_specific_ops_cp_t *p_value)
{
    return R_BLE_SERVS_SendHdlVal(&gs_specific_ops_cp_char, conn_hdl, (const void *)p_value, false);
}

/*----------------------------------------------------------------------------------------------------------------------
    Continuous Glucose Monitoring server
----------------------------------------------------------------------------------------------------------------------*/

/* Continuous Glucose Monitoring characteristics definition */
static const st_ble_servs_char_info_t *gspp_chars[] = 
{
    &gs_meas_char,
    &gs_feat_char,
    &gs_status_char,
    &gs_session_start_time_char,
    &gs_session_run_time_char,
    &gs_record_access_cp_char,
    &gs_specific_ops_cp_char,
};

/* Continuous Glucose Monitoring service definition */
static st_ble_servs_info_t gs_servs_info = 
{
    .pp_chars     = gspp_chars,
    .num_of_chars = ARRAY_SIZE(gspp_chars),
};

/***********************************************************************************************************************//**
* Function Name: R_BLE_CGMS_Init
* Description  : This function initializes the GATTS Server and CGM Service, registers the callback function for
*                GATTS.
* Arguments    : cb - cal back to the initialization parameters data
* Return Value : BLE_SUCCESS               - Success
*                BLE_ERR_INVALID_PTR       - The p_ntf_data parameter or the value field in the value field in
*                                            the p_ntf_data parameter is NULL.
*                BLE_ERR_INVALID_ARG       - The value_len field in the value field in the p_ntf_data parameter is 0
*                                            or the attr_hdl field in the p_ntf_data parameters is 0.
**********************************************************************************************************************/
ble_status_t R_BLE_CGMS_Init(ble_servs_app_cb_t cb)
{
    if (NULL == cb)
    {
        return BLE_ERR_INVALID_PTR;
    }

    gs_servs_info.cb = cb;

    return R_BLE_SERVS_RegisterServer(&gs_servs_info);
}

/***********************************************************************************************************************//**
* Function Name: R_BLE_CGMS_AddNewRecord
* Description  : This function adds the records of CGM characteristic.
* Arguments    : p_meas      - pointer to the CGM Characteristic
* Return Value : BLE_SUCCESS
**********************************************************************************************************************/
ble_status_t R_BLE_CGMS_AddNewRecord(st_ble_cgms_meas_t *p_meas)
{
    if (NULL == p_meas)
    {
        return BLE_ERR_INVALID_PTR;
    }

    cgms_db_store_record(p_meas);

    return BLE_SUCCESS;
}

/***********************************************************************************************************************//**
* Function Name: cgm_notify_record
* Description  : This function notify or indicate the particular record of CGM characteristic.
* Arguments    : p_meas      - pointer to the CGM Characteristic
* Return Value : BLE_STATUS
**********************************************************************************************************************/
static ble_status_t cgm_notify_record(uint16_t conn_hdl, st_ble_cgms_record_t *p_record)
{
    ble_status_t ret = BLE_SUCCESS;

    if (NULL != p_record)
    {
        p_record->meas.e2e_crc = 0xFFFF;
        ret = R_BLE_CGMS_NotifyMeas(conn_hdl, &p_record->meas);
    }

    return ret;
}

/***********************************************************************************************************************//**
* Function Name: cgm_send_ra_ctrl_pt_resp
* Description  : This function send the responsse of RACP of CGM characteristic.
* Arguments    : conn_hdl      - connection handle
                 op_code       - op_code of response of success
                 req_op_code   - request op_code (op_code)
                 resp_code     - operand
                 param         - number of records parameter
* Return Value : BLE_STATUS
**********************************************************************************************************************/
static ble_status_t cgm_send_ra_ctrl_pt_resp(uint16_t conn_hdl, uint8_t op_code, uint8_t req_op_code, uint8_t resp_code, uint16_t param)
{
    ble_status_t ret = 0;
    st_ble_cgms_record_access_cp_t value = 
    {
        .op_code = op_code,
        .racp_operator = BLE_CGMS_RECORD_ACCESS_CP_OPERATOR_NULL,
    };

    uint8_t operand[18] = { 0 };

    if (BLE_CGMS_RECORD_ACCESS_CP_OP_CODE_RESPONSE_CODE == op_code)
    {
        value.operand[0] = req_op_code;
        value.operand[1] = resp_code;
        value.operand_len = 2;
    }
    else
    {
        BT_PACK_LE_2_BYTE(&value.operand[0], &param);
        value.operand_len = 2;
    }

    ret = R_BLE_CGMS_IndicateRecordAccessCp(conn_hdl, &value);
    if (BLE_SUCCESS == ret)
    {
        gs_is_racp_in_progress = false;
    }
    else
    {
        gs_is_racp_in_progress = true;
    }

    return BLE_SUCCESS;
}
