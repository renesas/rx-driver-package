/***********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
 * SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
 ***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_cgms_record.c
 * Version : 1.0
 * Description : This module implements Continuous Glucose Monitoring Service Records
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 24.05.2019 1.00 First Release
 ***********************************************************************************************************************/

/***********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 ***********************************************************************************************************************/
#include <string.h>
#include "r_ble_cgms_record.h"

/***********************************************************************************************************************
 Private global variables and functions
 ***********************************************************************************************************************/
static uint16_t   gs_num_of_records;
static uint16_t   gs_root_index;
static uint16_t   gs_next_sequence_number;
static st_ble_cgms_record_t  gs_records[BLE_CGMS_DB_MAX_NUM_OF_RECORDS];

void cgms_db_init (void)
{
    gs_root_index     = BLE_CGMS_DB_INVALID_INDEX;
    gs_num_of_records = 0;

    for (uint16_t i = 0; i < BLE_CGMS_DB_MAX_NUM_OF_RECORDS; i++)
    {
        gs_records[i].valid      = BLE_CGMS_DB_INVALID_RECORD;
        gs_records[i].next_index = BLE_CGMS_DB_INVALID_INDEX;
        gs_records[i].prev_index = BLE_CGMS_DB_INVALID_INDEX;

        memset(&gs_records[i].meas, 0x00, sizeof(gs_records[i].meas));
    }

    gs_next_sequence_number = 0;
}

uint16_t cgms_db_get_newest_index(void)
{
    st_ble_cgms_record_t *p_record = cgms_db_get_record(gs_root_index);
    return p_record->prev_index;
}

uint16_t cgms_db_get_oldest_index(void)
{
    return gs_root_index;
}

uint16_t cgms_db_get_next_index(uint16_t index)
{
    st_ble_cgms_record_t *p_record = cgms_db_get_record(index);
    if (NULL != p_record)
    {
       return p_record->next_index;
    }
    
    else
    {
        return BLE_CGMS_DB_INVALID_INDEX;
    }
  
}

st_ble_cgms_record_t *cgms_db_get_record(uint16_t index)
{
    if (BLE_CGMS_DB_MAX_NUM_OF_RECORDS <= index)
    {
        
        return NULL;
    }

    if (BLE_CGMS_DB_INVALID_RECORD == gs_records[index].valid)
    {
        
        return NULL;
    }

    return &gs_records[index];

}

static void cgms_db_copy_record(uint16_t index, const st_ble_cgms_meas_t *p_meas)
{
    memcpy(&gs_records[index].meas, p_meas, sizeof(gs_records[index].meas));
    gs_records[index].meas.time_offset = gs_next_sequence_number;
    gs_records[index].valid = BLE_CGMS_DB_MEAS_VALID_RECORD;

    gs_next_sequence_number++;
}

void cgms_db_store_record(const st_ble_cgms_meas_t *p_meas)
{
    /* First record. */
    if (BLE_CGMS_DB_INVALID_INDEX == gs_root_index)
    {
        gs_records[0].prev_index = 0;
        gs_records[0].next_index = 0;
        cgms_db_copy_record(0, p_meas);
        gs_root_index = 0;
        gs_num_of_records++;
    }

    /* No space to save a new record, hence remove oldest one. */
    else if (BLE_CGMS_DB_MAX_NUM_OF_RECORDS <= gs_num_of_records)
    {
        uint16_t newest_index = cgms_db_get_newest_index();
        uint16_t next_index = cgms_db_get_next_index(gs_root_index);

        gs_records[gs_root_index].prev_index = newest_index;
        gs_records[gs_root_index].next_index = next_index;
        gs_records[next_index].prev_index = gs_root_index;
        cgms_db_copy_record(gs_root_index, p_meas);
        gs_root_index = next_index;
    }

    /* Free space exist, save the new record on it. */
    else
    {
        for (uint8_t i = 0; i < BLE_CGMS_DB_MAX_NUM_OF_RECORDS; i++)
        {
            if (BLE_CGMS_DB_INVALID_RECORD == gs_records[i].valid)
            {
                uint16_t newest_index = cgms_db_get_newest_index();
                gs_records[i].prev_index = newest_index;
                gs_records[i].next_index = gs_root_index;
                cgms_db_copy_record(i, p_meas);
                gs_records[newest_index].next_index = i;
                gs_records[gs_root_index].prev_index = i;
                gs_num_of_records++;
                break;
            }
        }
    }
}

void cgms_db_mark_delete_record(uint16_t index)
{
    st_ble_cgms_record_t *p_record;

    p_record = cgms_db_get_record(index);

    if (NULL != p_record)
    {
        p_record->valid = BLE_CGMS_DB_WILL_DELETE;
    }
}

static void cgms_db_delete_record(uint16_t index)
{
    st_ble_cgms_record_t *p_record;

    p_record = cgms_db_get_record(index);

    if (NULL != p_record)
    {
        if (cgms_db_get_oldest_index() == index)
        {
            uint16_t newest_index = cgms_db_get_newest_index();
            gs_records[p_record->next_index].prev_index = newest_index;
            gs_root_index = p_record->next_index;
        }
        else if (cgms_db_get_newest_index() == index)
        {
            gs_records[p_record->prev_index].next_index = gs_root_index;
        }
        else
        {
            gs_records[p_record->prev_index].next_index = p_record->next_index;
            gs_records[p_record->next_index].prev_index = p_record->prev_index;
        }

        p_record->valid = BLE_CGMS_DB_INVALID_RECORD;
    }
}

void cgms_db_delete_records(void)
{
    for (uint16_t i = 0; i < BLE_CGMS_DB_MAX_NUM_OF_RECORDS; i++)
    {
        if (BLE_CGMS_DB_WILL_DELETE == gs_records[i].valid)
        {
            cgms_db_delete_record(i);
            gs_num_of_records--;
        }
    }

    if (0 == gs_num_of_records)
    {
        gs_root_index = BLE_CGMS_DB_INVALID_INDEX;
    }
}
