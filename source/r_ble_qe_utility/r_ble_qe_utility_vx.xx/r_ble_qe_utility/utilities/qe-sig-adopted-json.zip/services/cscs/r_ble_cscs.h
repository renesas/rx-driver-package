/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_cscs.h
 * Version : 1.0
 * Description : This module implements Cycling Speed and Cadence Service Server.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 22.03.2019 1.00 First Release
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @file
 * @defgroup cscs Cycling Speed and Cadence Service 
 * @{
 * @ingroup profile
 * @brief   This file provides APIs to interface Cycling Speed and Cadence Service.
 **********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_ble_rx23w_if.h"

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
#ifndef R_BLE_CSCS_H
#define R_BLE_CSCS_H

/*******************************************************************************************************************//**
 * @brief Cumulative_value length .
***********************************************************************************************************************/
#define BLE_CSCS_SC_CONTROL_POINT_CUMULATIVE_VALUE_LEN                                  (17)

/*******************************************************************************************************************//**
 * @brief Response Parameter length .
***********************************************************************************************************************/
#define BLE_CSCS_SC_CONTROL_POINT_RESPONSE_PARAMETER_LEN                                (17)

/*******************************************************************************************************************//**
 * @brief Max No of Supported Sensor Locations
***********************************************************************************************************************/
#define BLE_CSCS_MAX_SENSOR_LOCATIONS_SUPPORTED                                         (17)
            
/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @brief Cycling Speed and Cadence Service event data.
***********************************************************************************************************************/
typedef struct
{
    uint16_t  conn_hdl;  /**< Connection handle */
    uint16_t  param_len; /**< Event parameter length */
    void     *p_param;    /**< Event parameter */
} st_ble_cscs_evt_data_t;

/*******************************************************************************************************************//**
 * @brief Cycling Speed and Cadence Service event callback.
***********************************************************************************************************************/
typedef void (*ble_cscs_app_cb_t)(uint16_t type, ble_status_t result, st_ble_cscs_evt_data_t *p_data);

/*******************************************************************************************************************//**
 * @brief Cycling Speed and Cadence Service event type.
***********************************************************************************************************************/
typedef enum 
{
    BLE_CSCS_EVENT_SC_CONTROL_POINT_CLI_CNFG_ENABLED, /**< SC Control Point characteristic cli cnfg enabled event */
    BLE_CSCS_EVENT_SC_CONTROL_POINT_CLI_CNFG_DISABLED, /**< SC Control Point characteristic cli cnfg disabled event */
    BLE_CSCS_EVENT_SC_CONTROL_POINT_HDL_VAL_CNF, /**< SC Control Point characteristic handle value confiration event */
    BLE_CSCS_EVENT_CSC_MEASUREMENT_CLI_CNFG_ENABLED, /**< CSC Measurement characteristic cli cnfg enabled event */
    BLE_CSCS_EVENT_CSC_MEASUREMENT_CLI_CNFG_DISABLED, /**< CSC Measurement characteristic cli cnfg disabled event */
    BLE_CSCS_EVENT_SC_CONTROL_POINT_WRITE_REQ, /**< SC Control Point characteristic write request event */
    BLE_CSCS_EVENT_CSC_FEATURE_READ_REQ, /**< CSC Feature characteristic read request event */
    BLE_CSCS_EVENT_SENSOR_LOCATION_READ_REQ, /**< Sensor Location characteristic read request event */
} e_ble_cscs_event_t;

/*******************************************************************************************************************//**
 * @brief Sensor Location enumeration.
***********************************************************************************************************************/
typedef enum 
{
    BLE_CSCS_SENSOR_LOCATION_SENSOR_LOCATION_OTHER        = 0, /**< Sensor Location - Other */
    BLE_CSCS_SENSOR_LOCATION_SENSOR_LOCATION_TOP_OF_SHOE  = 1, /**< Sensor Location - Top of Shoe */
    BLE_CSCS_SENSOR_LOCATION_SENSOR_LOCATION_IN_SHOE      = 2, /**< Sensor Location - In Shoe */
    BLE_CSCS_SENSOR_LOCATION_SENSOR_LOCATION_HIP          = 3, /**< Sensor Location - Hip */
    BLE_CSCS_SENSOR_LOCATION_SENSOR_LOCATION_FRONT_WHEEL  = 4, /**< Sensor Location - Front Wheel */
    BLE_CSCS_SENSOR_LOCATION_SENSOR_LOCATION_LEFT_CRANK   = 5, /**< Sensor Location - Left Crank */
    BLE_CSCS_SENSOR_LOCATION_SENSOR_LOCATION_RIGHT_CRANK  = 6, /**< Sensor Location - Right Crank */
    BLE_CSCS_SENSOR_LOCATION_SENSOR_LOCATION_LEFT_PEDAL   = 7, /**< Sensor Location - Left Pedal */
    BLE_CSCS_SENSOR_LOCATION_SENSOR_LOCATION_RIGHT_PEDAL  = 8, /**< Sensor Location - Right Pedal */
    BLE_CSCS_SENSOR_LOCATION_SENSOR_LOCATION_FRONT_HUB    = 9, /**< Sensor Location - Front Hub */
    BLE_CSCS_SENSOR_LOCATION_SENSOR_LOCATION_REAR_DROPOUT = 10, /**< Sensor Location - Rear Dropout */
    BLE_CSCS_SENSOR_LOCATION_SENSOR_LOCATION_CHAINSTAY    = 11, /**< Sensor Location - Chainstay */
    BLE_CSCS_SENSOR_LOCATION_SENSOR_LOCATION_REAR_WHEEL   = 12, /**< Sensor Location - Rear Wheel */
    BLE_CSCS_SENSOR_LOCATION_SENSOR_LOCATION_REAR_HUB     = 13, /**< Sensor Location - Rear Hub */
    BLE_CSCS_SENSOR_LOCATION_SENSOR_LOCATION_CHEST        = 14, /**< Sensor Location - Chest */
    BLE_CSCS_SENSOR_LOCATION_SENSOR_LOCATION_SPIDER       = 15, /**< Sensor Location - Spider */
    BLE_CSCS_SENSOR_LOCATION_SENSOR_LOCATION_CHAIN_RING   = 16, /**< Sensor Location - Chain Ring */
} e_ble_cscs_sensor_location_t;

/*******************************************************************************************************************//**
 * @brief Op Code enumeration.
***********************************************************************************************************************/
typedef enum 
{
    BLE_CSCS_SC_CONTROL_POINT_OP_CODE_RESERVED_FOR_FUTURE_USE            = 0, /**< Reserved for Future Use */
    BLE_CSCS_SC_CONTROL_POINT_OP_CODE_SET_CUMULATIVE_VALUE               = 1, /**< Set Cumulative Value */
    BLE_CSCS_SC_CONTROL_POINT_OP_CODE_START_SENSOR_CALIBRATION           = 2, /**< Start Sensor Calibration */
    BLE_CSCS_SC_CONTROL_POINT_OP_CODE_UPDATE_SENSOR_LOCATION             = 3, /**< Update the Sensor Location */
    BLE_CSCS_SC_CONTROL_POINT_OP_CODE_REQUEST_SUPPORTED_SENSOR_LOCATIONS = 4, /**< Send list of supported sensor location values */
    BLE_CSCS_SC_CONTROL_POINT_OP_CODE_RESPONSE_CODE                      = 16, /**< Response Code */
} e_ble_cscs_sc_control_point_op_code_t;

/*******************************************************************************************************************//**
 * @brief Response Value enumeration.
***********************************************************************************************************************/
typedef enum 
{
    BLE_CSCS_SC_CONTROL_POINT_RESPONSE_VALUE_RESERVED_FOR_FUTURE_USE = 0, /**< Reserved For Future Use */
    BLE_CSCS_SC_CONTROL_POINT_RESPONSE_VALUE_SUCCESS                 = 1, /**< Success */
    BLE_CSCS_SC_CONTROL_POINT_RESPONSE_VALUE_OP_CODE_NOT_SUPPORTED   = 2, /**< Opcode not supported */
    BLE_CSCS_SC_CONTROL_POINT_RESPONSE_VALUE_INVALID_PARAMETER       = 3, /**< Invalid parameter */
    BLE_CSCS_SC_CONTROL_POINT_RESPONSE_VALUE_OPERATION_FAILED        = 4, /**< Operation Failed */
} e_ble_cscs_sc_control_point_response_value_t;

/*******************************************************************************************************************//**
 * @brief Cycling Speed and Cadence Service initialization parameters.
***********************************************************************************************************************/
typedef struct 
{
    ble_cscs_app_cb_t cb; /**< Cycling Speed and Cadence Service event callback */
} st_ble_cscs_init_param_t;

/*******************************************************************************************************************//**
 * @brief Cycling Speed and Cadence Service connection parameters.
***********************************************************************************************************************/
typedef struct 
{
    uint16_t csc_measurement_cli_cnfg; /**< CSC Measurement characteristic cli cnfg */
    uint16_t sc_control_point_cli_cnfg; /**< SC Control Point characteristic cli cnfg */
} st_ble_cscs_connect_param_t;

/*******************************************************************************************************************//**
 * @brief Cycling Speed and Cadence Service disconnection parameters.
***********************************************************************************************************************/
typedef struct 
{
    uint16_t csc_measurement_cli_cnfg; /**< CSC Measurement characteristic cli cnfg */
    uint16_t sc_control_point_cli_cnfg; /**< SC Control Point characteristic cli cnfg */
} st_ble_cscs_disconnect_param_t;

/*******************************************************************************************************************//**
 * @brief CSC Measurement characteristic parameters.
***********************************************************************************************************************/
typedef struct 
{
    bool is_wheel_revolution_data_present; /**< Wheel Revolution data present or not */
    bool is_crank_revolution_data_present; /**< Crank Revolution data present or not */
    uint32_t cumulative_wheel_revolutions; /**< Cumulative Wheel Revolutions value */
    uint16_t last_wheel_event_time;        /**< Last Wheel Event Time value */
    uint16_t cumulative_crank_revolutions; /**< Cumulative Crank Revolutions value */
    uint16_t last_crank_event_time;        /**< Last Crank Event Time value */
} st_ble_cscs_csc_measurement_t;

/*******************************************************************************************************************//**
 * @brief CSC Feature characteristic parameters.
***********************************************************************************************************************/
typedef struct 
{
    bool is_wheel_revolution_data_supported;  /**< Wheel Revolution data supported or not */
    bool is_crank_revolution_data_supported;  /**< Crank Revolution data supported or not */
    bool is_multiple_sensor_locations_supported; /**< Multiple Sensor Locations supported or not */
} st_ble_cscs_csc_feature_t;

/*******************************************************************************************************************//**
 * @brief SC Control Point characteristic parameters.
***********************************************************************************************************************/
typedef struct 
{
    uint8_t  op_code; /**< Op Code value */
    uint32_t cumulative_value; /**< Cumulative Value value */
    uint8_t  sensor_location_value; /**< Sensor Location Value value */
    uint8_t  response_code;         /**< Response Code */
    uint8_t  request_op_code; /**< Request Op Code value */
    uint8_t  response_value; /**< Response Value value */
    uint8_t  response_parameter[BLE_CSCS_SC_CONTROL_POINT_RESPONSE_PARAMETER_LEN]; /**< Response Parameter value */
    uint8_t  no_of_supported_sensor_locations;                                   /**< No of sensor locations supported */
} st_ble_cscs_sc_control_point_t;


/***********************************************************************************************************************
Exported global functions (to be accessed by other files)
***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @brief     Initialize Cycling Speed and Cadence Service.
 * @details   This function shall be called once at startup.
 * @param[in] p_param Pointer to Cycling Speed and Cadence Service initialization parameters.
 * @return
***********************************************************************************************************************/
ble_status_t R_BLE_CSCS_Init(const st_ble_cscs_init_param_t *p_param);

/*******************************************************************************************************************//**
 * @brief     Perform Cycling Speed and Cadence Service connection settings.
 * @details   This function shall be called on each connection establishment.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_param  Pointer to Connection parameters.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_CSCS_Connect(uint16_t conn_hdl, const st_ble_cscs_connect_param_t *p_param);

/*******************************************************************************************************************//**
 * @brief     Retrieve Cycling Speed and Cadence Service connection specific settings before disconnection.
 * @details   This function shall be called on each disconnection.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_param  Pointer to Disconnection parameters.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_CSCS_Disconnect(uint16_t conn_hdl, st_ble_cscs_disconnect_param_t *p_param);

/*******************************************************************************************************************//**
 * @brief     Send CSC Measurement notification.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] p_app_value Pointer to CSC Measurement value to send.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_CSCS_NotifyCscMeasurement(uint16_t conn_hdl, const st_ble_cscs_csc_measurement_t *p_app_value);

/*******************************************************************************************************************//**
 * @brief      Get CSC Feature characteristic value from local GATT database.
 * @param[out] p_app_value Pointer to Retrieved CSC Feature characteristic value.
 * @return     @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_CSCS_GetCscFeature(st_ble_cscs_csc_feature_t *p_app_value);

/*******************************************************************************************************************//**
 * @brief     Set CSC Feature characteristic value to local GATT database.
 * @param[in] p_app_value Pointer to CSC Feature characteristic value to set.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_CSCS_SetCscFeature(const st_ble_cscs_csc_feature_t *p_app_value);

/*******************************************************************************************************************//**
 * @brief      Get Sensor Location characteristic value from local GATT database.
 * @param[out] p_app_value Pointer to Retrieved Sensor Location characteristic value.
 * @return     @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_CSCS_GetSensorLocation(uint8_t *p_app_value);

/*******************************************************************************************************************//**
 * @brief     Set Sensor Location characteristic value to local GATT database.
 * @param[in] app_value Sensor Location characteristic value to set.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_CSCS_SetSensorLocation(uint8_t app_value);

/*******************************************************************************************************************//**
 * @brief     Send SC Control Point indication.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] p_app_value Pointer to SC Control Point value to send.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_CSCS_IndicateScControlPoint(uint16_t conn_hdl, const st_ble_cscs_sc_control_point_t *p_app_value);


/*******************************************************************************************************************//**
 * @brief     Return version of the CSCC service server.
 * @return    version
***********************************************************************************************************************/
uint32_t R_BLE_CSCS_GetVersion(void);

#endif /* R_BLE_CSCS_H */

/** @} */
