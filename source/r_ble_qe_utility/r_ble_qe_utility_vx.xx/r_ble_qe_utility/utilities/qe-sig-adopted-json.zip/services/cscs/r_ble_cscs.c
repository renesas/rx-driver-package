/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_cscs.c
 * Version : 1.0
 * Description : The source file for Cycling Speed and Cadence Service service.
 **********************************************************************************************************************/
 /***********************************************************************************************************************
  * History : DD.MM.YYYY Version Description
  *         : 20.12.2019 1.00 First Release
 ***********************************************************************************************************************/

 /***********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 ***********************************************************************************************************************/
#include "r_ble_cscs.h"
#include "profile_cmn/r_ble_servs_if.h"
#include "gatt_db.h"
#include <string.h>

 /***********************************************************************************************************************
 Macro definitions
 ***********************************************************************************************************************/
#ifndef UNUSED_ARG
#define UNUSED_ARG(arg)         (void)(arg)
#endif /* UNUSED_ARG */

 /*******************************************************************************************************************//**
  * @brief Cumulative_value length .
 ***********************************************************************************************************************/
#define BLE_CSCS_PRV_SC_CONTROL_POINT_CUMULATIVE_VALUE_LEN                                  (17)

 /*******************************************************************************************************************//**
  * @brief Response Parameter length .
 ***********************************************************************************************************************/
#define BLE_CSCS_PRV_SC_CONTROL_POINT_RESPONSE_PARAMETER_LEN                                (17)

 /*******************************************************************************************************************//**
  * @brief Max No of Supported Sensor Locations
 ***********************************************************************************************************************/
#define BLE_CSCS_PRV_MAX_SENSOR_LOCATIONS_SUPPORTED                                         (17)

 /*******************************************************************************************************************//**
  * @brief Wheel Revolution Data Present bit.
 ***********************************************************************************************************************/
#define BLE_CSCS_PRV_CSC_MEASUREMENT_FLAGS_WHEEL_REVOLUTION_DATA_PRESENT                    (1 << 0)

 /*******************************************************************************************************************//**
  * @brief Crank Revolution Data Present bit.
 ***********************************************************************************************************************/
#define BLE_CSCS_PRV_CSC_MEASUREMENT_FLAGS_CRANK_REVOLUTION_DATA_PRESENT                    (1 << 1)

 /*******************************************************************************************************************//**
  * @brief Wheel Revolution Data Supported bit.
 ***********************************************************************************************************************/
#define BLE_CSCS_PRV_CSC_FEATURE_WHEEL_REVOLUTION_DATA_SUPPORTED                            (1 << 0)

 /*******************************************************************************************************************//**
  * @brief Crank Revolution Data Supported bit.
 ***********************************************************************************************************************/
#define BLE_CSCS_PRV_CSC_FEATURE_CRANK_REVOLUTION_DATA_SUPPORTED                            (1 << 1)

 /*******************************************************************************************************************//**
  * @brief Multiple Sensor Locations Supported bit.
 ***********************************************************************************************************************/
#define BLE_CSCS_PRV_CSC_FEATURE_MULTIPLE_SENSOR_LOCATIONS_SUPPORTED                        (1 << 2)

 /***********************************************************************************************************************
 Private global variables and functions
 ***********************************************************************************************************************/
static st_ble_servs_info_t                       gs_servs_info;
static bool                                      gs_is_sc_in_progress = false;
static uint16_t                                  gs_conn_hdl;
static uint8_t                                   gs_count             = 0;
static uint8_t                                   gs_counter           = 0;
static st_ble_cscs_sc_cp_t                       gs_csc_sc_control_point;


/*----------------------------------------------------------------------------------------------------------------------
    CSC Measurement Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

static const st_ble_servs_desc_info_t gs_csc_measurement_cli_cnfg =
{
    .attr_hdl = BLE_CSCS_CSC_MEASUREMENT_CLI_CNFG_DESC_HDL,
    .app_size = sizeof(uint16_t),
    .desc_idx = BLE_CSCS_CSC_MEASUREMENT_CLI_CNFG_IDX,
    .db_size  = BLE_CSCS_CSC_MEASUREMENT_CLI_CNFG_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_uint16_t,
    .encode   = (ble_servs_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_CSCS_Setcsc_Measclicnfg(uint16_t conn_hdl, const uint16_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_csc_measurement_cli_cnfg, conn_hdl, (const void *)p_value);
}

ble_status_t R_BLE_CSCS_Getcsc_Measclicnfg(uint16_t conn_hdl, uint16_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_csc_measurement_cli_cnfg, conn_hdl, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    CSC Measurement characteristic
----------------------------------------------------------------------------------------------------------------------*/

/***********************************************************************************************************************//**
* Function Name: decode_csc_measurement
* Description  : This function converts CSC Measurement characteristic value representation in
*                GATT (uint8_t[]) to representation in application layer (struct).
* Arguments    : p_app_value - pointer to the CGM Measurement value in the application layer
*                p_gatt_value - pointer to the characteristic value in the GATT database
* Return Value : ble_status_t
**********************************************************************************************************************/
static ble_status_t decode_st_ble_cscs_csc_meas(st_ble_cscs_csc_measurement_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    UNUSED_ARG(p_app_value);
    UNUSED_ARG(p_gatt_value);

    /* Do Nothing As Flow is not hitting here */
    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_csc_measurement
 * Description  : This function converts CSC Measurement characteristic value representation in
 *                application layer (structure) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the CSC Measurement  value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_cscs_csc_meas(const st_ble_cscs_csc_measurement_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 1;

    st_ble_cscs_csc_feature_t csc_feature = { 0 };

    R_BLE_CSCS_Getfeat(&csc_feature);

    /* Clear the byte array */
    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    if ((p_app_value->is_wheel_rev_data_present) && (csc_feature.is_wheel_rev_data_supported))
    {
        p_gatt_value->p_value[0] |= BLE_CSCS_PRV_CSC_MEASUREMENT_FLAGS_WHEEL_REVOLUTION_DATA_PRESENT;
        BT_PACK_LE_4_BYTE(&p_gatt_value->p_value[pos], &p_app_value->cumulative_wheel_revolutions);
        pos += 4;

        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->last_wheel_event_time);
        pos += 2;
    }

    if ((p_app_value->is_crank_rev_data_present) && (csc_feature.is_crank_rev_data_supported))
    {
        p_gatt_value->p_value[0] |= BLE_CSCS_PRV_CSC_MEASUREMENT_FLAGS_CRANK_REVOLUTION_DATA_PRESENT;
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->cumulative_crank_revolutions);
        pos += 2;

        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->last_crank_event_time);
        pos += 2;
    }

    p_gatt_value->value_len = (uint16_t)pos;

    return BLE_SUCCESS;
}

/* CSC Measurement characteristic descriptor definition */
static const st_ble_servs_desc_info_t *gspp_csc_measurement_descs[] =
{
    &gs_csc_measurement_cli_cnfg,
};

/* CSC Measurement characteristic definition */
static const st_ble_servs_char_info_t gs_csc_measurement_char =
{
    .start_hdl     = BLE_CSCS_CSC_MEASUREMENT_DECL_HDL,
    .end_hdl       = BLE_CSCS_CSC_MEASUREMENT_CLI_CNFG_DESC_HDL,
    .char_idx      = BLE_CSCS_CSC_MEASUREMENT_IDX,
    .app_size      = sizeof(st_ble_cscs_csc_measurement_t),
    .db_size       = BLE_CSCS_CSC_MEASUREMENT_LEN,
    .decode        = (ble_servs_attr_decode_t)decode_st_ble_cscs_csc_meas,
    .encode        = (ble_servs_attr_encode_t)encode_st_ble_cscs_csc_meas,
    .pp_descs      = gspp_csc_measurement_descs,
    .num_of_descs  = ARRAY_SIZE(gspp_csc_measurement_descs),
};

ble_status_t R_BLE_CSCS_Notifycscmeas(uint16_t conn_hdl, const st_ble_cscs_csc_measurement_t *p_value)
{
    return R_BLE_SERVS_SendHdlVal(&gs_csc_measurement_char, conn_hdl, (const void *)p_value, true);
}

/*----------------------------------------------------------------------------------------------------------------------
    CSC Feature characteristic
----------------------------------------------------------------------------------------------------------------------*/

/***********************************************************************************************************************
 * Function Name: decode_csc_feature
 * Description  : This function converts CSC Feature characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (structure).
 * Arguments    : p_app_value - pointer to the CSC Feature value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_cscs_csc_feat(st_ble_cscs_csc_feature_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint16_t csc_feature = 0;

    if (BLE_CSCS_CSC_FEATURE_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Clear the feature bit flags */
    memset(p_app_value, 0x00, sizeof(st_ble_cscs_csc_feature_t));

    BT_UNPACK_LE_2_BYTE(&csc_feature, p_gatt_value->p_value);

    /*is_wheel_rev_data_present*/
    if (csc_feature & BLE_CSCS_PRV_CSC_FEATURE_WHEEL_REVOLUTION_DATA_SUPPORTED)
    {
        p_app_value->is_wheel_rev_data_supported = true;
    }
    else
    {
        p_app_value->is_wheel_rev_data_supported = false;
    }

    /*is_crank_revolution_data_supported*/
    if (csc_feature & BLE_CSCS_PRV_CSC_FEATURE_CRANK_REVOLUTION_DATA_SUPPORTED)
    {
        p_app_value->is_crank_rev_data_supported = true;
    }
    else
    {
        p_app_value->is_crank_rev_data_supported = false;
    }

    /*is_multiple_sensor_locations_supported*/
    if (csc_feature & BLE_CSCS_PRV_CSC_FEATURE_MULTIPLE_SENSOR_LOCATIONS_SUPPORTED)
    {
        p_app_value->is_multiple_sen_loc_supported = true;
    }
    else
    {
        p_app_value->is_multiple_sen_loc_supported = false;
    }

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_csc_feature
 * Description  : This function converts CSC Feature characteristic value representation in
 *                application layer (structure) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the CSC Feature  value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_cscs_csc_feat(const st_ble_cscs_csc_feature_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint16_t csc_feature = 0;

    /* Clear the byte array */
    memset(p_gatt_value, 0x00, p_gatt_value->value_len);

    /* Wheel Revolution Data Bit */
    if (p_app_value->is_wheel_rev_data_supported)
    {
        csc_feature |= BLE_CSCS_PRV_CSC_FEATURE_WHEEL_REVOLUTION_DATA_SUPPORTED;
    }

    /* Crank Revolution Data Bit */
    if (p_app_value->is_crank_rev_data_supported)
    {
        csc_feature |= BLE_CSCS_PRV_CSC_FEATURE_CRANK_REVOLUTION_DATA_SUPPORTED;
    }

    /* Multiple Sensor Locations Bit */
    if (p_app_value->is_multiple_sen_loc_supported)
    {
        csc_feature |= BLE_CSCS_PRV_CSC_FEATURE_MULTIPLE_SENSOR_LOCATIONS_SUPPORTED;
    }

    BT_PACK_LE_2_BYTE(p_gatt_value->p_value, &csc_feature);

    p_gatt_value->value_len = BLE_CSCS_CSC_FEATURE_LEN;

    return BLE_SUCCESS;
}

/* CSC Feature characteristic definition */
static const st_ble_servs_char_info_t gs_csc_feature_char =
{
    .start_hdl  = BLE_CSCS_CSC_FEATURE_DECL_HDL,
    .end_hdl    = BLE_CSCS_CSC_FEATURE_VAL_HDL,
    .char_idx   = BLE_CSCS_CSC_FEATURE_IDX,
    .app_size   = sizeof(st_ble_cscs_csc_feature_t),
    .db_size    = BLE_CSCS_CSC_FEATURE_LEN,
    .decode     = (ble_servs_attr_decode_t)decode_st_ble_cscs_csc_feat,
    .encode     = (ble_servs_attr_encode_t)encode_st_ble_cscs_csc_feat,
};

ble_status_t R_BLE_CSCS_Setfeat(const st_ble_cscs_csc_feature_t *p_value)
{
    return R_BLE_SERVS_SetChar(&gs_csc_feature_char, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_CSCS_Getfeat(st_ble_cscs_csc_feature_t *p_value)
{
    return R_BLE_SERVS_GetChar(&gs_csc_feature_char, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Sensor Location characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Sensor Location characteristic definition */
static const st_ble_servs_char_info_t gs_sensor_location_char =
{
    .start_hdl  = BLE_CSCS_SENSOR_LOCATION_DECL_HDL,
    .end_hdl    = BLE_CSCS_SENSOR_LOCATION_VAL_HDL,
    .char_idx   = BLE_CSCS_SENSOR_LOCATION_IDX,
    .app_size   = sizeof(uint16_t),
    .db_size    = BLE_CSCS_SENSOR_LOCATION_LEN,
    .decode     = (ble_servs_attr_decode_t)decode_uint8_t,
    .encode     = (ble_servs_attr_encode_t)encode_uint8_t,
};

ble_status_t R_BLE_CSCS_Set_Sensor_loc(const uint8_t *p_value)
{
    return R_BLE_SERVS_SetChar(&gs_sensor_location_char, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_CSCS_Get_Sensor_loc(uint8_t *p_value)
{
    return R_BLE_SERVS_GetChar(&gs_sensor_location_char, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    SC Control Point Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

static const st_ble_servs_desc_info_t gs_sc_control_point_cli_cnfg =
{
    .attr_hdl = BLE_CSCS_SC_CONTROL_POINT_CLI_CNFG_DESC_HDL,
    .app_size = sizeof(uint16_t),
    .desc_idx = BLE_CSCS_SC_CONTROL_POINT_CLI_CNFG_IDX,
    .db_size  = BLE_CSCS_SC_CONTROL_POINT_CLI_CNFG_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_uint16_t,
    .encode   = (ble_servs_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_CSCS_SetSc_cp_CliCnfg(uint16_t conn_hdl, const uint16_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_sc_control_point_cli_cnfg, conn_hdl, (const void *)p_value);
}

ble_status_t R_BLE_CSCS_GetSc_cp_CliCnfg(uint16_t conn_hdl, uint16_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_sc_control_point_cli_cnfg, conn_hdl, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    SC Control Point characteristic
----------------------------------------------------------------------------------------------------------------------*/

/***********************************************************************************************************************
 * Function Name: decode_sc_control_point
 * Description  : This function converts SC Control Point characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the SC Control Point value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_cscs_sc_cp(st_ble_cscs_sc_cp_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos =                  0;

    ble_status_t                   ret;
    
    /* Opcode */
    BT_UNPACK_LE_1_BYTE(&gs_csc_sc_control_point.op_code, &p_gatt_value->p_value[pos]);
    pos += 1;

    /* copy cumulative value*/
    if (BLE_CSCS_SC_CONTROL_POINT_OP_CODE_SET_CUMULATIVE_VALUE == gs_csc_sc_control_point.op_code)
    {
        BT_UNPACK_LE_4_BYTE(&gs_csc_sc_control_point.cumulative_value, &p_gatt_value->p_value[pos]);
        pos += 4;
    }
    else if (BLE_CSCS_SC_CONTROL_POINT_OP_CODE_UPDATE_SENSOR_LOCATION == gs_csc_sc_control_point.op_code)
    {
        BT_UNPACK_LE_1_BYTE(&gs_csc_sc_control_point.sensor_location_value, &p_gatt_value->p_value[pos]);
        pos += 1;
    }
    else
    {
        /* BLE_RSCS_SC_CONTROL_POINT_OP_CODE_START_SENSOR_CALIBRATION or
        BLE_RSCS_SC_CONTROL_POINT_OP_CODE_REQUEST_SUPPORTED_SENSOR_LOCATIONS or
        Invalid opcode - Do nothing*/
    }

    if ((p_gatt_value->value_len <= BLE_CSCS_SC_CONTROL_POINT_LEN) && (p_gatt_value->value_len == pos))
    {
        memcpy(p_app_value, &gs_csc_sc_control_point, sizeof(st_ble_cscs_sc_cp_t));

        ret = BLE_SUCCESS;
    }
    else
    {
        ret = BLE_CSCS_PRV_WRITE_REQUEST_REJECTED;
    }

    return ret;
}

/***********************************************************************************************************************
 * Function Name: encode_sc_control_point
 * Description  : This function converts SC Control Point characteristic value representation in
 *                application layer (structure) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the SC Control Point  value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_cscs_sc_cp(const st_ble_cscs_sc_cp_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    /* Response code */
    p_gatt_value->p_value[pos++] = BLE_CSCS_SC_CONTROL_POINT_OP_CODE_RESPONSE_CODE;

    /* request opcode */
    BT_UNPACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->request_op_code);

    /* response value */
    BT_UNPACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->response_value);

    if (BLE_CSCS_SC_CONTROL_POINT_OP_CODE_REQUEST_SUPPORTED_SENSOR_LOCATIONS == p_app_value->request_op_code)
    {
        /* response parameter - list of supported sensor locations */
        for (uint32_t i = 0; i < p_app_value->no_of_supported_sensor_loc; i++)
        {
            BT_UNPACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->response_parameter[i]);
        }
    }

    p_gatt_value->value_len = (uint16_t)pos;

    return BLE_SUCCESS;
}

/***********************************************************************************************************************//**
 * Function Name: cscs_process_operation
 * Description  : This function handles the write request events and process the operation and sends the response .
 * Arguments    : conn_hdl    - connection handle
 *                p_app_value - pointer to the characteristic value in the application database
                  started     - process started indication
 * Return Value : none
 **********************************************************************************************************************/
static void cscs_process_operation(uint16_t conn_hdl, st_ble_cscs_sc_cp_t *p_app_value, bool started)
{
    UNUSED_ARG(conn_hdl);
    UNUSED_ARG(p_app_value);
    UNUSED_ARG(started);

    /* UN Supported OP CODE */
    if ((BLE_CSCS_SC_CONTROL_POINT_OP_CODE_RESERVED_FOR_FUTURE_USE == gs_csc_sc_control_point.op_code) || (0xff == gs_csc_sc_control_point.op_code))
    {
        if (0 == gs_count)
        {
            gs_csc_sc_control_point.op_code         = BLE_CSCS_SC_CONTROL_POINT_OP_CODE_RESPONSE_CODE;
            gs_csc_sc_control_point.request_op_code = BLE_CSCS_SC_CONTROL_POINT_RESPONSE_VALUE_RESERVED_FOR_FUTURE_USE__RESPONSE_PARAMETER__N_A_;
            gs_csc_sc_control_point.response_value  = BLE_CSCS_SC_CONTROL_POINT_RESPONSE_VALUE_OP_CODE_NOT_SUPPORTED__RESPONSE_PARAMETER__N_A_;
            R_BLE_CSCS_IndicateSc_cp(gs_conn_hdl, &gs_csc_sc_control_point);
            gs_count++;
        }
        else if (1 == gs_count)
        {
            gs_csc_sc_control_point.op_code         = BLE_CSCS_SC_CONTROL_POINT_OP_CODE_RESPONSE_CODE;
            gs_csc_sc_control_point.request_op_code = 0xff;
            gs_csc_sc_control_point.response_value  = BLE_CSCS_SC_CONTROL_POINT_RESPONSE_VALUE_OP_CODE_NOT_SUPPORTED__RESPONSE_PARAMETER__N_A_;
            R_BLE_CSCS_IndicateSc_cp(gs_conn_hdl, &gs_csc_sc_control_point);
        }
        else
        {
            /*DO Nothing*/
        }
    }
    else
    {
        /*Do Nothing*/
    }
}

/***********************************************************************************************************************//**
* Function Name: write_req_sc_ctrl_pt
* Description  : This function handles the Speed and Cadence Control Point characteristic write request event.
* Arguments    : p_attr      - pointer to the attribute handle
                 conn_hdl    - connection handle
                 result      - BLE_STATUS
                 p_app_value - pointer to the CGM Record Access Control Point  value in the application layer
* Return Value : None
**********************************************************************************************************************/
static void write_req_sc_ctrl_pt(const void *p_attr, uint16_t conn_hdl, ble_status_t result, st_ble_cscs_sc_cp_t *p_app_value)
{
    UNUSED_ARG(p_attr);
    UNUSED_ARG(result);

    if ((BLE_CSCS_SC_CONTROL_POINT_OP_CODE_REQUEST_SUPPORTED_SENSOR_LOCATIONS == p_app_value->op_code))
    {
        gs_counter++;
        if (2 == gs_counter)
        {
            gs_is_sc_in_progress = true;
        }
    }

    if (gs_is_sc_in_progress)
    {
        /* Previous Opcode in progress, send error response */
        R_BLE_GATTS_SendErrRsp(BLE_CSCS_PROCEDURE_ALREADY_IN_PROGRESS_ERROR);
        return;
    }

    uint16_t cli_cnfg;
    R_BLE_CSCS_GetSc_cp_CliCnfg(conn_hdl, &cli_cnfg);
    if (BLE_GATTS_CLI_CNFG_INDICATION != cli_cnfg)
    {
        /* SC Control Point Indication Disabled, Send Error Response */
        R_BLE_GATTS_SendErrRsp(BLE_CSCS_CLI_CNFG_IMPROPERLY_CONFIGURED_ERROR);
        return;
    }

    else
    {
        /* Do Nothing*/
    }
}

/***********************************************************************************************************************//**
* Function Name: write_comp_sc_ctrl_pt
* Description  : This function handles the Speed and Cadence Control Point characteristic write complete event.
* Arguments    : p_attr      - pointer to the attribute handle
                 conn_hdl    - connection handle
                 result      - BLE_STATUS
                 p_app_value - pointer to the Speed and Cadence Control Point  value in the application layer
* Return Value : None
**********************************************************************************************************************/
static void write_comp_sc_ctrl_pt(const void *p_attr, uint16_t conn_hdl, ble_status_t result, st_ble_cscs_sc_cp_t *p_app_value)
{
    UNUSED_ARG(result);

    gs_conn_hdl = conn_hdl;
    
    cscs_process_operation(conn_hdl, p_app_value, true);

    st_ble_servs_evt_data_t evt_data =
    {
        .conn_hdl  = conn_hdl,
        .param_len = sizeof(gs_csc_sc_control_point),
        .p_param   = &gs_csc_sc_control_point,
    };
    st_ble_servs_char_info_t p_char = *(st_ble_servs_char_info_t *)p_attr;

    gs_servs_info.cb(BLE_SERVS_MULTI_ATTR_EVENT(p_char.char_idx, p_char.inst_idx, BLE_SERVS_WRITE_REQ), BLE_SUCCESS, &evt_data);
}

/* SC Control Point characteristic descriptor definition */
static const st_ble_servs_desc_info_t *gspp_sc_control_point_descs[] =
{
    &gs_sc_control_point_cli_cnfg,
};


/* SC Control Point characteristic definition */
static const st_ble_servs_char_info_t gs_sc_control_point_char =
{
    .start_hdl     = BLE_CSCS_SC_CONTROL_POINT_DECL_HDL,
    .end_hdl       = BLE_CSCS_SC_CONTROL_POINT_CLI_CNFG_DESC_HDL,
    .char_idx      = BLE_CSCS_SC_CONTROL_POINT_IDX,
    .app_size      = sizeof(st_ble_cscs_sc_cp_t),
    .db_size       = BLE_CSCS_SC_CONTROL_POINT_LEN,
    .write_req_cb  = (ble_servs_attr_write_req_t)write_req_sc_ctrl_pt,
    .write_comp_cb = (ble_servs_attr_write_comp_t)write_comp_sc_ctrl_pt,
    .decode        = (ble_servs_attr_decode_t)decode_st_ble_cscs_sc_cp,
    .encode        = (ble_servs_attr_encode_t)encode_st_ble_cscs_sc_cp,
    .pp_descs      = gspp_sc_control_point_descs,
    .num_of_descs  = ARRAY_SIZE(gspp_sc_control_point_descs),
};

ble_status_t R_BLE_CSCS_IndicateSc_cp(uint16_t conn_hdl, const st_ble_cscs_sc_cp_t *p_value)
{
    return R_BLE_SERVS_SendHdlVal(&gs_sc_control_point_char, conn_hdl, (const void *)p_value, false);
}

/*----------------------------------------------------------------------------------------------------------------------
    Cycling Speed and Cadence Service server
----------------------------------------------------------------------------------------------------------------------*/

/* Cycling Speed and Cadence Service characteristics definition */
static const st_ble_servs_char_info_t *gspp_chars[] =
{
    &gs_csc_measurement_char,
    &gs_csc_feature_char,
    &gs_sensor_location_char,
    &gs_sc_control_point_char,
};

/* Cycling Speed and Cadence Service service definition */
static st_ble_servs_info_t gs_servs_info =
{
    .pp_chars     = gspp_chars,
    .num_of_chars = ARRAY_SIZE(gspp_chars),
};

ble_status_t R_BLE_CSCS_Init(ble_servs_app_cb_t cb)
{
    if (NULL == cb)
    {
        return BLE_ERR_INVALID_PTR;
    }

    gs_servs_info.cb = cb;

    return R_BLE_SERVS_RegisterServer(&gs_servs_info);
}
