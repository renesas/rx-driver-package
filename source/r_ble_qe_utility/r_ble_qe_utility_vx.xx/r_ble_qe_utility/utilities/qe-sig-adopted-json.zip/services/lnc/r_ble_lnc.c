/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_lnc.c
 * Version : 1.0
 * Description : The source file for Location and Navigation client.
 **********************************************************************************************************************/
#include "r_ble_lnc.h"
#include "profile_cmn/r_ble_servc_if.h"

static st_ble_servc_info_t gs_client_info;

/*----------------------------------------------------------------------------------------------------------------------
    LN Feature Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* LN Feature characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_feat_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

static ble_status_t decode_st_ble_lnc_feat_t(st_ble_lnc_feat_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    if(BLE_LNC_FEAT_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    p_app_value->is_instantaneous_speed_supported = (p_gatt_value->p_value[0]) & 0x01;
    p_app_value->is_total_distance_supported = (p_gatt_value->p_value[0] >> 1) & 0x01;
    p_app_value->is_location_supported = (p_gatt_value->p_value[0] >> 2) & 0x01;
    p_app_value->is_elevation_supported = (p_gatt_value->p_value[0] >> 3) & 0x01;
    p_app_value->is_heading_supported = (p_gatt_value->p_value[0] >> 4) & 0x01;
    p_app_value->is_rolling_time_supported = (p_gatt_value->p_value[0] >> 5) & 0x01;
    p_app_value->is_utc_time_supported = (p_gatt_value->p_value[0] >> 6) & 0x01;
    p_app_value->is_remaining_distance_supported = (p_gatt_value->p_value[0] >> 7) & 0x01;
    p_app_value->is_remaining_vertical_distance_supported = (p_gatt_value->p_value[1]) & 0x01;
    p_app_value->is_estimated_time_of_arrival_supported = (p_gatt_value->p_value[1] >> 1) & 0x01;
    p_app_value->is_number_of_beacons_in_solution_supported = (p_gatt_value->p_value[1] >> 2) & 0x01;
    p_app_value->is_number_of_beacons_in_view_supported = (p_gatt_value->p_value[1] >> 3) & 0x01;
    p_app_value->is_time_to_first_fix_supported = (p_gatt_value->p_value[1] >> 4) & 0x01;
    p_app_value->is_estimated_horizontal_position_error_supported = (p_gatt_value->p_value[1] >> 5) & 0x01;
    p_app_value->is_estimated_vertical_position_error_supported = (p_gatt_value->p_value[1] >> 6) & 0x01;
    p_app_value->is_horizontal_dilution_of_precision_supported = (p_gatt_value->p_value[1] >> 7) & 0x01;
    p_app_value->is_vertical_dilution_of_precision_supported = (p_gatt_value->p_value[2]) & 0x01;
    p_app_value->is_location_and_speed_characteristic_content_masking_supported = (p_gatt_value->p_value[2] >> 1) & 0x01;
    p_app_value->is_fix_rate_setting_supported = (p_gatt_value->p_value[2] >> 2) & 0x01;
    p_app_value->is_elevation_setting_supported = (p_gatt_value->p_value[2] >> 3) & 0x01;
    p_app_value->is_position_status_supported = (p_gatt_value->p_value[2] >> 4) & 0x01;
    return BLE_SUCCESS;
}

/* LN Feature characteristic definition */
static const st_ble_servc_char_info_t gs_feat_char = {
    .uuid_16      = BLE_LNC_FEAT_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_lnc_feat_t),
    .db_size      = BLE_LNC_FEAT_LEN,
    .char_idx     = BLE_LNC_FEAT_IDX,
    .p_attr_hdls  = gs_feat_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_lnc_feat_t,
};

ble_status_t R_BLE_LNC_ReadFeat(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_feat_char, conn_hdl);
}

void R_BLE_LNC_GetFeatAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_lnc_feat_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_feat_char_ranges[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Location and Speed Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Location and Speed characteristic descriptors attribute handles */
static uint16_t gs_location_and_speed_cli_cnfg_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_location_and_speed_cli_cnfg ={
    .uuid_16     = BLE_LNC_LOCATION_AND_SPEED_CLI_CNFG_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint16_t),
    .db_size     = BLE_LNC_LOCATION_AND_SPEED_CLI_CNFG_LEN,
    .desc_idx    = BLE_LNC_LOCATION_AND_SPEED_CLI_CNFG_IDX,
    .p_attr_hdls = gs_location_and_speed_cli_cnfg_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_LNC_WriteLocationAndSpeedCliCnfg(uint16_t conn_hdl, const uint16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_location_and_speed_cli_cnfg, conn_hdl, p_value);
}

ble_status_t R_BLE_LNC_ReadLocationAndSpeedCliCnfg(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_location_and_speed_cli_cnfg, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Location and Speed Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Location and Speed characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_location_and_speed_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

static ble_status_t decode_st_ble_lnc_location_and_speed_t(st_ble_lnc_location_and_speed_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 2;

    p_app_value->flags.is_instantaneous_speed_present = p_gatt_value->p_value[0] & 0x01;
    p_app_value->flags.is_total_distance_present = (p_gatt_value->p_value[0] >> 1) & 0x01;
    p_app_value->flags.is_location_present = (p_gatt_value->p_value[0] >> 2) & 0x01;
    p_app_value->flags.is_elevation_present = (p_gatt_value->p_value[0] >> 3) & 0x01;
    p_app_value->flags.is_heading_present = (p_gatt_value->p_value[0] >> 4) & 0x01;
    p_app_value->flags.is_rolling_time_present = (p_gatt_value->p_value[0] >> 5) & 0x01;
    p_app_value->flags.is_utc_time_present = (p_gatt_value->p_value[0] >> 6) & 0x01;
    p_app_value->flags.position_status = (uint8_t)(((p_gatt_value->p_value[0] >> 7) & 0x01) | ((p_gatt_value->p_value[1] << 1) & 0x02));
    p_app_value->flags.is_speed_and_distance_format = (p_gatt_value->p_value[1] >> 1) & 0x01;
    p_app_value->flags.elevation_source = (uint8_t)((p_gatt_value->p_value[1] >> 2) & 0x03);
    p_app_value->flags.is_heading_source = (p_gatt_value->p_value[1] >> 4) & 0x01;

    if(p_app_value->flags.is_instantaneous_speed_present)
    {
        p_app_value->instantaneous_speed = (uint16_t)((p_gatt_value->p_value[pos] & 0xff) |
            ((p_gatt_value->p_value[pos + 1] & 0xff) << 8));
        pos += 2;
    }
    if(p_app_value->flags.is_total_distance_present)
    {
        p_app_value->total_distance = (uint32_t)((p_gatt_value->p_value[pos] & 0xff) |
            ((p_gatt_value->p_value[pos + 1] & 0xff) << 8) |
            ((p_gatt_value->p_value[pos+2] & 0xff) << 16));
        pos += 3;
    }
    if(p_app_value->flags.is_location_present)
    {
        p_app_value->latitude = (p_gatt_value->p_value[pos] & 0xff) |
            ((p_gatt_value->p_value[pos + 1] & 0xff) << 8) |
            ((p_gatt_value->p_value[pos + 2] & 0xff) << 16) |
            ((p_gatt_value->p_value[pos + 3] & 0xff) << 24);
        pos += 4;
        p_app_value->longitude = (p_gatt_value->p_value[pos] & 0xff) |
            ((p_gatt_value->p_value[pos + 1] & 0xff) << 8) |
            ((p_gatt_value->p_value[pos + 2] & 0xff) << 16) |
            ((p_gatt_value->p_value[pos + 3] & 0xff) << 24);
        pos += 4;
    }
    if(p_app_value->flags.is_elevation_present)
    {
        p_app_value->elevation = (p_gatt_value->p_value[pos] & 0xff) |
            ((p_gatt_value->p_value[pos + 1] & 0xff) << 8) |
            ((p_gatt_value->p_value[pos+2] & 0xff) << 16);
        pos += 3;
    }
    if(p_app_value->flags.is_heading_present)
    {
        p_app_value->heading = (uint16_t)((p_gatt_value->p_value[pos] & 0xff) |
            ((p_gatt_value->p_value[pos + 1] & 0xff) << 8));
        pos += 2;
    }
    if(p_app_value->flags.is_rolling_time_present)
    {
        p_app_value->rolling_time = p_gatt_value->p_value[pos++] & 0xff;
    }
    if(p_app_value->flags.is_utc_time_present)
    {
        p_app_value->utc_time.year = (uint16_t)((p_gatt_value->p_value[pos] & 0xff) |
            ((p_gatt_value->p_value[pos + 1] & 0xff) << 8));
        pos += 2;
        p_app_value->utc_time.month = p_gatt_value->p_value[pos++];
        p_app_value->utc_time.day = p_gatt_value->p_value[pos++];
        p_app_value->utc_time.hours = p_gatt_value->p_value[pos++];
        p_app_value->utc_time.minutes = p_gatt_value->p_value[pos++];
        p_app_value->utc_time.seconds = p_gatt_value->p_value[pos++];
    }

    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_lnc_location_and_speed_t(const st_ble_lnc_location_and_speed_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 2;
    p_gatt_value->p_value[0] = (uint8_t)((p_app_value->flags.is_instantaneous_speed_present & 0x01) |
        ((p_app_value->flags.is_total_distance_present & 0x01) << 1) |
        ((p_app_value->flags.is_location_present & 0x01) << 2) |
        ((p_app_value->flags.is_elevation_present & 0x01) << 3) |
        ((p_app_value->flags.is_heading_present & 0x01) << 4) |
        ((p_app_value->flags.is_rolling_time_present & 0x01) << 5) |
        ((p_app_value->flags.is_utc_time_present & 0x01) << 6) |
        ((p_app_value->flags.position_status & 0x01) << 7));
    p_gatt_value->p_value[1] = (uint8_t)(((p_app_value->flags.position_status & 0x02) >> 1) |
        ((p_app_value->flags.is_speed_and_distance_format & 0x01) << 1) |
        ((p_app_value->flags.elevation_source & 0x03) << 2) |
        ((p_app_value->flags.is_heading_source & 0x01) << 4));

    if (p_app_value->flags.is_instantaneous_speed_present)
    {
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->instantaneous_speed) & 0xFF);
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->instantaneous_speed >> 8) & 0xFF);
    }
    if (p_app_value->flags.is_total_distance_present)
    {
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->total_distance) & 0xFF);
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->total_distance >> 8) & 0xFF);
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->total_distance >> 16) & 0xFF);
    }
    if (p_app_value->flags.is_location_present)
    {
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->latitude) & 0xFF);
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->latitude >> 8) & 0xFF);
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->latitude >> 16) & 0xFF);
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->latitude >> 24) & 0xFF);
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->longitude) & 0xFF);
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->longitude >> 8) & 0xFF);
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->longitude >> 16) & 0xFF);
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->longitude >> 24) & 0xFF);
    }
    if (p_app_value->flags.is_elevation_present)
    {
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->elevation) & 0xFF);
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->elevation >> 8) & 0xFF);
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->elevation >> 16) & 0xFF);
    }
    if (p_app_value->flags.is_heading_present)
    {
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->heading) & 0xFF);
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->heading >> 8) & 0xFF);
    }
    if (p_app_value->flags.is_rolling_time_present)
    {
        p_gatt_value->p_value[pos++] = p_app_value->rolling_time;
    }
    if (p_app_value->flags.is_utc_time_present)
    {
        p_gatt_value->p_value[pos++] = (uint8_t)(p_app_value->utc_time.year & 0xFF);
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->utc_time.year >> 8) & 0xFF);
        p_gatt_value->p_value[pos++] = p_app_value->utc_time.month;
        p_gatt_value->p_value[pos++] = p_app_value->utc_time.day;
        p_gatt_value->p_value[pos++] = p_app_value->utc_time.hours;
        p_gatt_value->p_value[pos++] = p_app_value->utc_time.minutes;
        p_gatt_value->p_value[pos++] = p_app_value->utc_time.seconds;
    }
    return BLE_SUCCESS;
}

/* Location and Speed characteristic descriptor definition */
static const st_ble_servc_desc_info_t *gspp_location_and_speed_descs[] = {
    &gs_location_and_speed_cli_cnfg,
};

/* Location and Speed characteristic definition */
const st_ble_servc_char_info_t gs_location_and_speed_char = {
    .uuid_16      = BLE_LNC_LOCATION_AND_SPEED_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_lnc_location_and_speed_t),
    .db_size      = BLE_LNC_LOCATION_AND_SPEED_LEN,
    .char_idx     = BLE_LNC_LOCATION_AND_SPEED_IDX,
    .p_attr_hdls  = gs_location_and_speed_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_lnc_location_and_speed_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_lnc_location_and_speed_t,
    .num_of_descs = ARRAY_SIZE(gspp_location_and_speed_descs),
    .pp_descs     = gspp_location_and_speed_descs,
};

void R_BLE_LNC_GetLocationAndSpeedAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_lnc_location_and_speed_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_location_and_speed_char_ranges[conn_idx];
    p_hdl->cli_cnfg_desc_hdl = gs_location_and_speed_cli_cnfg_desc_hdls[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Position Quality Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Position Quality characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_position_quality_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

static ble_status_t decode_st_ble_lnc_position_quality_t(st_ble_lnc_position_quality_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 2;
    if(BLE_LNC_POSITION_QUALITY_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    p_app_value->flags.is_number_of_beacons_in_solution_present = (p_gatt_value->p_value[0]) & 0x01;
    p_app_value->flags.is_number_of_beacons_in_view_present = (p_gatt_value->p_value[0] >> 1) & 0x01;
    p_app_value->flags.is_time_to_first_fix_present = (p_gatt_value->p_value[0] >> 2) & 0x01;
    p_app_value->flags.is_ehpe_present = (p_gatt_value->p_value[0] >> 3) & 0x01;
    p_app_value->flags.is_evpe_present = (p_gatt_value->p_value[0] >> 4) & 0x01;
    p_app_value->flags.is_hdop_present= (p_gatt_value->p_value[0] >> 5) & 0x01;
    p_app_value->flags.is_vdop_present = (p_gatt_value->p_value[0] >> 6) & 0x01;
    p_app_value->flags.position_status = (uint8_t)(((p_gatt_value->p_value[0] >> 7) & 0x01) |
        ((p_gatt_value->p_value[1] & 0x01) << 1));

    if (p_app_value->flags.is_number_of_beacons_in_solution_present)
    {
        p_app_value->number_of_beacons_in_solution = p_gatt_value->p_value[pos++];
    }
    if (p_app_value->flags.is_number_of_beacons_in_view_present)
    {
        p_app_value->number_of_beacons_in_view = p_gatt_value->p_value[pos++];
    }
    if (p_app_value->flags.is_time_to_first_fix_present)
    {
        p_app_value->time_to_first_fix = (uint16_t)(p_gatt_value->p_value[pos] |
            (p_gatt_value->p_value[pos + 1] << 8));
        pos += 2;
    }
    if (p_app_value->flags.is_ehpe_present)
    {
        p_app_value->ehpe = (uint32_t)(p_gatt_value->p_value[pos] |
            (p_gatt_value->p_value[pos + 1] << 8) |
            (p_gatt_value->p_value[pos + 2] << 16) |
            (p_gatt_value->p_value[pos + 3] << 24));
        pos += 4;
    }
    if(p_app_value->flags.is_evpe_present)
    {
        p_app_value->evpe = (uint32_t)(p_gatt_value->p_value[pos] |
            (p_gatt_value->p_value[pos + 1] << 8) |
            (p_gatt_value->p_value[pos + 2] << 16) |
            (p_gatt_value->p_value[pos + 3] << 24));
        pos += 4;
    }
    if (p_app_value->flags.is_hdop_present)
    {
        p_app_value->hdop = p_gatt_value->p_value[pos++];
    }
    if (p_app_value->flags.is_vdop_present)
    {
        p_app_value->vdop = p_gatt_value->p_value[pos++];
    }
    return BLE_SUCCESS;
}

/* Position Quality characteristic definition */
const st_ble_servc_char_info_t gs_position_quality_char = {
    .uuid_16      = BLE_LNC_POSITION_QUALITY_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_lnc_position_quality_t),
    .db_size      = BLE_LNC_POSITION_QUALITY_LEN,
    .char_idx     = BLE_LNC_POSITION_QUALITY_IDX,
    .p_attr_hdls  = gs_position_quality_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_lnc_position_quality_t,
};

ble_status_t R_BLE_LNC_ReadPositionQuality(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_position_quality_char, conn_hdl);
}

void R_BLE_LNC_GetPositionQualityAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_lnc_position_quality_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_position_quality_char_ranges[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    LN Control Point Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* LN Control Point characteristic descriptors attribute handles */
static uint16_t gs_cp_cli_cnfg_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_cp_cli_cnfg ={
    .uuid_16     = BLE_LNC_CP_CLI_CNFG_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint16_t),
    .db_size     = BLE_LNC_CP_CLI_CNFG_LEN,
    .desc_idx    = BLE_LNC_CP_CLI_CNFG_IDX,
    .p_attr_hdls = gs_cp_cli_cnfg_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_LNC_WriteCpCliCnfg(uint16_t conn_hdl, const uint16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_cp_cli_cnfg, conn_hdl, p_value);
}

ble_status_t R_BLE_LNC_ReadCpCliCnfg(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_cp_cli_cnfg, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    LN Control Point Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* LN Control Point characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_cp_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

static ble_status_t decode_st_ble_lnc_cp_t(st_ble_lnc_cp_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint16_t pv_len = 0;

    p_app_value->op_codes = p_gatt_value->p_value[0];

    switch(p_app_value->op_codes)
    {
        case BLE_LNC_CP_OP_CODES_SET_CUMULATIVE_VALUE:
        case BLE_LNC_CP_OP_CODES_SET_ELEVATION:
        {
            pv_len = 3;
        } break;

        case BLE_LNC_CP_OP_CODES_MASK_LOCATION_AND_SPEED_CHARACTERISTIC_CONTENT:
        case BLE_LNC_CP_OP_CODES_SELECT_ROUTE:
        case BLE_LNC_CP_OP_CODES_REQUEST_NAME_OF_ROUTE:
        {
            pv_len = 2;
        } break;

        case BLE_LNC_CP_OP_CODES_NAVIGATION_CONTROL:
        case BLE_LNC_CP_OP_CODES_SET_FIX_RATE:
        {
            pv_len = 1;
        } break;

        case BLE_LNC_CP_OP_CODES_REQUEST_NUMBER_OF_ROUTES:
        case BLE_LNC_CP_OP_CODES_RESPONSE_CODE:
        {
            pv_len = 0;
        } break;

        default:
        {
            pv_len = 0;
        } break;
    }

    st_ble_gatt_value_t pv_val = {
            .value_len = pv_len,
            .p_value = &p_gatt_value->p_value[1],
    };
    decode_st_ble_seq_data_t(&p_app_value->parameter_value, &pv_val);

    if(BLE_LNC_CP_OP_CODES_RESPONSE_CODE == p_app_value->op_codes)
    {
        p_app_value->request_op_code = p_gatt_value->p_value[1];
        p_app_value->response_value = p_gatt_value->p_value[2];

        if(BLE_LNC_CP_RESPONSE_VALUE_SUCCESS == p_app_value->response_value)
        {
            p_app_value->response_parameter.len = (uint16_t)(p_gatt_value->value_len - 3);
            p_app_value->response_parameter.data = &p_gatt_value->p_value[3];
        }
    }
    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_lnc_cp_t(const st_ble_lnc_cp_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;
    p_gatt_value->p_value[pos++] = p_app_value->op_codes;

    if (0 != p_app_value->parameter_value.len)
    {
        st_ble_gatt_value_t pv_val = {
            .value_len = p_app_value->parameter_value.len,
            .p_value = &p_gatt_value->p_value[pos]
        };
        encode_st_ble_seq_data_t(&p_app_value->parameter_value, &pv_val);
        pos += p_app_value->parameter_value.len;
    }

    if (BLE_LNC_CP_OP_CODES_RESPONSE_CODE == p_app_value->op_codes)
    {
        p_gatt_value->p_value[pos++] = p_app_value->request_op_code;
        p_gatt_value->p_value[pos++] = p_app_value->response_value;
    }

    if (0 != p_app_value->response_parameter.len)
    {
        st_ble_gatt_value_t rp_val = {
            .value_len = p_app_value->response_parameter.len,
            .p_value = &p_gatt_value->p_value[pos]
        };
        encode_st_ble_seq_data_t(&p_app_value->response_parameter, &rp_val);
        pos += p_app_value->response_parameter.len;
    }

    p_gatt_value->value_len = (uint16_t)pos;
    return BLE_SUCCESS;
}

/* LN Control Point characteristic descriptor definition */
static const st_ble_servc_desc_info_t *gspp_cp_descs[] = {
    &gs_cp_cli_cnfg,
};

/* LN Control Point characteristic definition */
static const st_ble_servc_char_info_t gs_cp_char = {
    .uuid_16      = BLE_LNC_CP_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_lnc_cp_t),
    .db_size      = BLE_LNC_CP_LEN,
    .char_idx     = BLE_LNC_CP_IDX,
    .p_attr_hdls  = gs_cp_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_lnc_cp_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_lnc_cp_t,
    .num_of_descs = ARRAY_SIZE(gspp_cp_descs),
    .pp_descs     = gspp_cp_descs,
};

ble_status_t R_BLE_LNC_WriteCp(uint16_t conn_hdl, const st_ble_lnc_cp_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteChar(&gs_cp_char, conn_hdl, p_value);
}

void R_BLE_LNC_GetCpAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_lnc_cp_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_cp_char_ranges[conn_idx];
    p_hdl->cli_cnfg_desc_hdl = gs_cp_cli_cnfg_desc_hdls[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Navigation Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Navigation characteristic descriptors attribute handles */
static uint16_t gs_navigation_cli_cnfg_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_navigation_cli_cnfg ={
    .uuid_16     = BLE_LNC_NAVIGATION_CLI_CNFG_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint16_t),
    .db_size     = BLE_LNC_NAVIGATION_CLI_CNFG_LEN,
    .desc_idx    = BLE_LNC_NAVIGATION_CLI_CNFG_IDX,
    .p_attr_hdls = gs_navigation_cli_cnfg_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_LNC_WriteNavigationCliCnfg(uint16_t conn_hdl, const uint16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_navigation_cli_cnfg, conn_hdl, p_value);
}

ble_status_t R_BLE_LNC_ReadNavigationCliCnfg(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_navigation_cli_cnfg, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Navigation Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Navigation characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_navigation_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

static ble_status_t decode_st_ble_lnc_navigation_t(st_ble_lnc_navigation_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 6;
    p_app_value->flags.is_remaining_distance_present = p_gatt_value->p_value[0] & 0x01;
    p_app_value->flags.is_remaining_vertical_distance_present = (p_gatt_value->p_value[0] >> 1) & 0x01;
    p_app_value->flags.is_estimated_time_of_arrival_present = (p_gatt_value->p_value[0] >> 2) & 0x01;
    p_app_value->flags.position_status = (p_gatt_value->p_value[0] >> 3) & 0x03;
    p_app_value->flags.is_heading_source = (p_gatt_value->p_value[0] >> 5) & 0x01;
    p_app_value->flags.is_navigation_indicator_type = (p_gatt_value->p_value[0] >> 6) & 0x01;
    p_app_value->flags.is_waypoint_reached = (p_gatt_value->p_value[0] >> 7) & 0x01;
    p_app_value->flags.is_destination_reached = p_gatt_value->p_value[1] & 0x01;
    p_app_value->bearing = (uint16_t)((p_gatt_value->p_value[2] & 0xff) |
        ((p_gatt_value->p_value[3] & 0xff) << 8));
    p_app_value->heading = (uint16_t)((p_gatt_value->p_value[4] & 0xff) |
        ((p_gatt_value->p_value[5] & 0xff) << 8));

    if(p_app_value->flags.is_remaining_distance_present)
    {
        p_app_value->remaining_distance = (uint32_t)((p_gatt_value->p_value[pos] & 0xff) |
            ((p_gatt_value->p_value[pos + 1] & 0xff) << 8) |
            ((p_gatt_value->p_value[pos + 2] & 0xff) << 16));
        pos += 3;
    }
    if(p_app_value->flags.is_remaining_vertical_distance_present)
    {
        p_app_value->remaining_vertical_distance = (int32_t)((p_gatt_value->p_value[pos] & 0xff) |
            ((p_gatt_value->p_value[pos + 1] & 0xff) << 8) |
            ((p_gatt_value->p_value[pos + 2] & 0xff) << 16));
        pos += 3;
    }
    if (p_app_value->flags.is_estimated_time_of_arrival_present)
    {
        p_app_value->estimated_time_of_arrival.year = (uint16_t)((p_gatt_value->p_value[pos] & 0xff) |
            ((p_gatt_value->p_value[pos + 1] & 0xff) << 8));
        pos += 2;
        p_app_value->estimated_time_of_arrival.month = p_gatt_value->p_value[pos++];
        p_app_value->estimated_time_of_arrival.day = p_gatt_value->p_value[pos++];
        p_app_value->estimated_time_of_arrival.hours = p_gatt_value->p_value[pos++];
        p_app_value->estimated_time_of_arrival.minutes = p_gatt_value->p_value[pos++];
        p_app_value->estimated_time_of_arrival.seconds = p_gatt_value->p_value[pos++];
    }

    return BLE_SUCCESS;
}

/* Navigation characteristic descriptor definition */
static const st_ble_servc_desc_info_t *gspp_navigation_descs[] = {
    &gs_navigation_cli_cnfg,
};

/* Navigation characteristic definition */
const st_ble_servc_char_info_t gs_navigation_char = {
    .uuid_16      = BLE_LNC_NAVIGATION_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_lnc_navigation_t),
    .db_size      = BLE_LNC_NAVIGATION_LEN,
    .char_idx     = BLE_LNC_NAVIGATION_IDX,
    .p_attr_hdls  = gs_navigation_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_lnc_navigation_t,
    .num_of_descs = ARRAY_SIZE(gspp_navigation_descs),
    .pp_descs     = gspp_navigation_descs,
};

void R_BLE_LNC_GetNavigationAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_lnc_navigation_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_navigation_char_ranges[conn_idx];
    p_hdl->cli_cnfg_desc_hdl = gs_navigation_cli_cnfg_desc_hdls[conn_idx];
}


/*----------------------------------------------------------------------------------------------------------------------
    Location and Navigation client
----------------------------------------------------------------------------------------------------------------------*/

/* Location and Navigation client attribute handles */
static st_ble_gatt_hdl_range_t gs_lnc_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

const st_ble_servc_char_info_t *gspp_lnc_chars[] = {
    &gs_feat_char,
    &gs_location_and_speed_char,
    &gs_position_quality_char,
    &gs_cp_char,
    &gs_navigation_char,
};

static st_ble_servc_info_t gs_client_info = {
    .pp_chars     = gspp_lnc_chars,
    .num_of_chars = ARRAY_SIZE(gspp_lnc_chars),
    .p_attr_hdls  = gs_lnc_ranges,
};

ble_status_t R_BLE_LNC_Init(ble_servc_app_cb_t cb) // @suppress("API function naming")
{
    if (NULL == cb)
    {
        return BLE_ERR_INVALID_PTR;
    }

    gs_client_info.cb = cb;

    return R_BLE_SERVC_RegisterClient(&gs_client_info);
}

void R_BLE_LNC_ServDiscCb(uint16_t conn_hdl, uint8_t serv_idx, uint16_t type, void *p_param) // @suppress("API function naming")
{
    R_BLE_SERVC_ServDiscCb(&gs_client_info, conn_hdl, serv_idx, type, p_param);
}

void R_BLE_LNC_GetServAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_gatt_hdl_range_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    *p_hdl = gs_lnc_ranges[conn_idx];
}
