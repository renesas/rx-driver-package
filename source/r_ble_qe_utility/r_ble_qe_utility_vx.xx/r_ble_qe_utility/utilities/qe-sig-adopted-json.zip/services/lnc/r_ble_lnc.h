/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_lnc.h
 * Version : 1.0
 * Description : The header file for Location and Navigation client.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 31.12.2999 1.00 First Release
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @file
 * @defgroup lnc Location and Navigation Client
 * @{
 * @ingroup profile
 * @brief   This is the client for the Location and Navigation Service.
 **********************************************************************************************************************/
#include "r_ble_rx23w_if.h"
#include "profile_cmn/r_ble_servc_if.h"

#ifndef R_BLE_LNC_H
#define R_BLE_LNC_H

/*----------------------------------------------------------------------------------------------------------------------
    LN Feature Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_LNC_FEAT_UUID (0x2A6A)
#define BLE_LNC_FEAT_LEN (4)

/***************************************************************************//**
 * @brief LN Feature value structure.
*******************************************************************************/
typedef struct {
    bool is_instantaneous_speed_supported; /**< Instantaneous Speed Supported */
    bool is_total_distance_supported; /**< Total Distance Supported */
    bool is_location_supported; /**< Location Supported */
    bool is_elevation_supported; /**< Elevation Supported */
    bool is_heading_supported; /**< Heading Supported */
    bool is_rolling_time_supported; /**< Rolling Time Supported */
    bool is_utc_time_supported; /**< UTC Time Supported */
    bool is_remaining_distance_supported; /**< Remaining Distance Supported */
    bool is_remaining_vertical_distance_supported; /**< Remaining Vertical Distance Supported */
    bool is_estimated_time_of_arrival_supported; /**< Estimated Time of Arrival Supported */
    bool is_number_of_beacons_in_solution_supported; /**< Number of Beacons in Solution Supported */
    bool is_number_of_beacons_in_view_supported; /**< Number of Beacons in View Supported */
    bool is_time_to_first_fix_supported; /**< Time to First Fix Supported */
    bool is_estimated_horizontal_position_error_supported; /**< Estimated Horizontal Position Error Supported */
    bool is_estimated_vertical_position_error_supported; /**< Estimated Vertical Position Error Supported */
    bool is_horizontal_dilution_of_precision_supported; /**< Horizontal Dilution of Precision Supported */
    bool is_vertical_dilution_of_precision_supported; /**< Vertical Dilution of Precision Supported */
    bool is_location_and_speed_characteristic_content_masking_supported; /**< Location and Speed Characteristic Content Masking Supported */
    bool is_fix_rate_setting_supported; /**< Fix Rate Setting Supported */
    bool is_elevation_setting_supported; /**< Elevation Setting Supported */
    bool is_position_status_supported; /**< Position Status Supported */
} st_ble_lnc_feat_t;

/***************************************************************************//**
 * @brief LN Feature attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
} st_ble_lnc_feat_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read LN Feature characteristic value from the remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_LNC_ReadFeat(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief      Get LN Feature attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_LNC_GetFeatAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_lnc_feat_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Location and Speed Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_LNC_LOCATION_AND_SPEED_UUID (0x2A67)
#define BLE_LNC_LOCATION_AND_SPEED_LEN (30)
#define BLE_LNC_LOCATION_AND_SPEED_CLI_CNFG_UUID (0x2902)
#define BLE_LNC_LOCATION_AND_SPEED_CLI_CNFG_LEN (2)
      
/***************************************************************************//**
 * @brief Location and Speed Flags value structure.
*******************************************************************************/
typedef struct {
    bool is_instantaneous_speed_present; /**< Instantaneous Speed Present */
    bool is_total_distance_present; /**< Total Distance Present */
    bool is_location_present; /**< Location Present */
    bool is_elevation_present; /**< Elevation Present */
    bool is_heading_present; /**< Heading Present */
    bool is_rolling_time_present; /**< Rolling Time Present */
    bool is_utc_time_present; /**< UTC Time Present */
    uint8_t position_status; /**< Position Status */
    bool is_speed_and_distance_format; /**< Speed and Distance format */
    uint8_t elevation_source; /**< Elevation Source */
    bool is_heading_source; /**< Heading Source */
} st_ble_location_and_speed_flags_t;

/***************************************************************************//**
 * @brief Location and Speed value structure.
*******************************************************************************/
typedef struct {
    st_ble_location_and_speed_flags_t flags; /**< Flags */
    uint16_t instantaneous_speed; /**< Instantaneous Speed */
    uint32_t total_distance; /**< Total Distance */
    int32_t latitude; /**< Location - Latitude */
    int32_t longitude; /**< Location - Longitude */
    int32_t elevation; /**< Elevation */
    uint16_t heading; /**< Heading */
    uint8_t rolling_time; /**< Rolling Time */
    st_ble_date_time_t utc_time; /**< UTC Time */
} st_ble_lnc_location_and_speed_t;

/***************************************************************************//**
 * @brief Location and Speed attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
    uint16_t cli_cnfg_desc_hdl;
} st_ble_lnc_location_and_speed_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Location and Speed characteristic Client Characteristic Configuration descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_LNC_ReadLocationAndSpeedCliCnfg(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Location and Speed characteristic Client Characteristic Configuration descriptor value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value Location and Speed characteristic Client Characteristic Configuration descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_LNC_WriteLocationAndSpeedCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief      Get Location and Speed attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_LNC_GetLocationAndSpeedAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_lnc_location_and_speed_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Position Quality Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_LNC_POSITION_QUALITY_UUID (0x2A69)
#define BLE_LNC_POSITION_QUALITY_LEN (16)
      
/***************************************************************************//**
 * @brief Position Quality Flags value structure.
*******************************************************************************/
typedef struct {
    bool is_number_of_beacons_in_solution_present; /**< Number of Beacons in Solution Present */
    bool is_number_of_beacons_in_view_present; /**< Number of Beacons in View Present */
    bool is_time_to_first_fix_present; /**< Time to First Fix Present */
    bool is_ehpe_present; /**< EHPE Present */
    bool is_evpe_present; /**< EVPE Present */
    bool is_hdop_present; /**< HDOP Present */
    bool is_vdop_present; /**< VDOP Present */
    uint8_t position_status; /**< Position Status */
} st_ble_position_quality_flags_t;

/***************************************************************************//**
 * @brief Position Quality value structure.
*******************************************************************************/
typedef struct {
    st_ble_position_quality_flags_t flags; /**< Flags */
    uint8_t number_of_beacons_in_solution; /**< Number of Beacons in Solution */
    uint8_t number_of_beacons_in_view; /**< Number of Beacons in View */
    uint16_t time_to_first_fix; /**< Time to First Fix */
    uint32_t ehpe; /**< EHPE */
    uint32_t evpe; /**< EVPE */
    uint8_t hdop; /**< HDOP */
    uint8_t vdop; /**< VDOP */
} st_ble_lnc_position_quality_t;

/***************************************************************************//**
 * @brief Position Quality attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
} st_ble_lnc_position_quality_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Position Quality characteristic value from the remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_LNC_ReadPositionQuality(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief      Get Position Quality attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_LNC_GetPositionQualityAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_lnc_position_quality_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    LN Control Point Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_LNC_CP_UUID (0x2A6B)
#define BLE_LNC_CP_LEN (23)
#define BLE_LNC_CP_CLI_CNFG_UUID (0x2902)
#define BLE_LNC_CP_CLI_CNFG_LEN (2)

/***************************************************************************//**
 * @brief LN Control Point Op Codes enumeration.
*******************************************************************************/
typedef enum {
    BLE_LNC_CP_OP_CODES_SET_CUMULATIVE_VALUE = 1, /**< Set Cumulative Value */
    BLE_LNC_CP_OP_CODES_MASK_LOCATION_AND_SPEED_CHARACTERISTIC_CONTENT = 2, /**< Mask Location and Speed Characteristic Content */
    BLE_LNC_CP_OP_CODES_NAVIGATION_CONTROL = 3, /**< Navigation Control */
    BLE_LNC_CP_OP_CODES_REQUEST_NUMBER_OF_ROUTES = 4, /**< Request Number of Routes */
    BLE_LNC_CP_OP_CODES_REQUEST_NAME_OF_ROUTE = 5, /**< Request Name of Route */
    BLE_LNC_CP_OP_CODES_SELECT_ROUTE = 6, /**< Select Route */
    BLE_LNC_CP_OP_CODES_SET_FIX_RATE = 7, /**< Set Fix Rate */
    BLE_LNC_CP_OP_CODES_SET_ELEVATION = 8, /**< Set Elevation */
    BLE_LNC_CP_OP_CODES_RESPONSE_CODE = 32, /**< Response Code */
} e_ble_lnc_cp_op_codes_t;

/***************************************************************************//**
 * @brief LN Control Point Response Value enumeration.
*******************************************************************************/
typedef enum {
    BLE_LNC_CP_RESPONSE_VALUE_SUCCESS = 1, /**< Success */
    BLE_LNC_CP_RESPONSE_VALUE_OP_CODE_NOT_SUPPORTED = 2, /**< Op Code not Supported */
    BLE_LNC_CP_RESPONSE_VALUE_INVALID_PARAMETER = 3, /**< Invalid Parameter */
    BLE_LNC_CP_RESPONSE_VALUE_OPERATION_FAILED = 4, /**< Operation Failed */
} e_ble_lnc_cp_response_value_t;

/***************************************************************************//**
 * @brief LN Control Point Navigation Control Value enumeration.
*******************************************************************************/
typedef enum {
    BLE_LNS_CP_NAVIGATION_CONTROL_VALUE_STOP_NAVIGATION = 0,
    BLE_LNS_CP_NAVIGATION_CONTROL_VALUE_START_NAVIGATION = 1,
    BLE_LNS_CP_NAVIGATION_CONTROL_VALUE_PAUSE_NAVIGATION = 2,
    BLE_LNS_CP_NAVIGATION_CONTROL_VALUE_CONTINUE_NAVIGATION = 3,
    BLE_LNS_CP_NAVIGATION_CONTROL_VALUE_SKIP_WAYPOINT = 4,
    BLE_LNS_CP_NAVIGATION_CONTROL_VALUE_SELECT_NEAREST_WAYPOINT_ON_A_ROUTE = 5
} e_ble_lnc_cp_navigation_control_value_t;


/***************************************************************************//**
 * @brief LN Control Point value structure.
*******************************************************************************/
typedef struct {
    uint8_t op_codes; /**< Op Codes */
    st_ble_seq_data_t parameter_value; /**< Parameter Value */
    uint8_t request_op_code; /**< Request Op Code */
    uint8_t response_value; /**< Response Value */
    st_ble_seq_data_t response_parameter; /**< Response Parameter */
} st_ble_lnc_cp_t;

/***************************************************************************//**
 * @brief LN Control Point attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
    uint16_t cli_cnfg_desc_hdl;
} st_ble_lnc_cp_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read LN Control Point characteristic Client Characteristic Configuration descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_LNC_ReadCpCliCnfg(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write LN Control Point characteristic Client Characteristic Configuration descriptor value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value LN Control Point characteristic Client Characteristic Configuration descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_LNC_WriteCpCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Write LN Control Point characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] p_value LN Control Point characteristic value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_LNC_WriteCp(uint16_t conn_hdl, const st_ble_lnc_cp_t *p_value);

/***************************************************************************//**
 * @brief      Get LN Control Point attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_LNC_GetCpAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_lnc_cp_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Navigation Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_LNC_NAVIGATION_UUID (0x2A68)
#define BLE_LNC_NAVIGATION_LEN (21)
#define BLE_LNC_NAVIGATION_CLI_CNFG_UUID (0x2902)
#define BLE_LNC_NAVIGATION_CLI_CNFG_LEN (2)
      
/***************************************************************************//**
 * @brief Navigation Flags value structure.
*******************************************************************************/
typedef struct {
    bool is_remaining_distance_present; /**< Remaining Distance Present */
    bool is_remaining_vertical_distance_present; /**< Remaining Vertical Distance Present */
    bool is_estimated_time_of_arrival_present; /**< Estimated Time of Arrival Present */
    uint8_t position_status; /**< Position Status */
    bool is_heading_source; /**< Heading Source */
    bool is_navigation_indicator_type; /**< Navigation Indicator Type */
    bool is_waypoint_reached; /**< Waypoint Reached */
    bool is_destination_reached; /**< Destination Reached */
} st_ble_navigation_flags_t;

/***************************************************************************//**
 * @brief Navigation value structure.
*******************************************************************************/
typedef struct {
    st_ble_navigation_flags_t flags; /**< Flags */
    uint16_t bearing; /**< Bearing */
    uint16_t heading; /**< Heading */
    uint32_t remaining_distance; /**< Remaining Distance */
    int32_t remaining_vertical_distance; /**< Remaining Vertical Distance */
    st_ble_date_time_t estimated_time_of_arrival; /**< Estimated Time of Arrival */
} st_ble_lnc_navigation_t;

/***************************************************************************//**
 * @brief Navigation attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
    uint16_t cli_cnfg_desc_hdl;
} st_ble_lnc_navigation_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Navigation characteristic Client Characteristic Configuration descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_LNC_ReadNavigationCliCnfg(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Navigation characteristic Client Characteristic Configuration descriptor value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value Navigation characteristic Client Characteristic Configuration descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_LNC_WriteNavigationCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief      Get Navigation attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_LNC_GetNavigationAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_lnc_navigation_attr_hdl_t *p_hdl);


/*----------------------------------------------------------------------------------------------------------------------
    Location and Navigation Client
----------------------------------------------------------------------------------------------------------------------*/

/***************************************************************************//**
 * @brief Location and Navigation client event data.
*******************************************************************************/
typedef struct {
    uint16_t    conn_hdl;  /**< Connection handle */
    uint16_t    param_len; /**< Event parameter length */
    const void *p_param;   /**< Event parameter */
} st_ble_lnc_evt_data_t;

/***************************************************************************//**
 * @brief Location and Navigation characteristic ID.
*******************************************************************************/
typedef enum {
    BLE_LNC_FEAT_IDX,
    BLE_LNC_LOCATION_AND_SPEED_IDX,
    BLE_LNC_LOCATION_AND_SPEED_CLI_CNFG_IDX,
    BLE_LNC_POSITION_QUALITY_IDX,
    BLE_LNC_CP_IDX,
    BLE_LNC_CP_CLI_CNFG_IDX,
    BLE_LNC_NAVIGATION_IDX,
    BLE_LNC_NAVIGATION_CLI_CNFG_IDX,
} e_ble_lnc_char_idx_t;

/***************************************************************************//**
 * @brief Location and Navigation client event type.
*******************************************************************************/
typedef enum {
    /* LN Feature */
    BLE_LNC_EVENT_FEAT_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_LNC_FEAT_IDX, BLE_SERVC_READ_RSP),

    /* Location and Speed */
    BLE_LNC_EVENT_LOCATION_AND_SPEED_HDL_VAL_NTF = BLE_SERVC_ATTR_EVENT(BLE_LNC_LOCATION_AND_SPEED_IDX, BLE_SERVC_HDL_VAL_NTF),
    BLE_LNC_EVENT_LOCATION_AND_SPEED_CLI_CNFG_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_LNC_LOCATION_AND_SPEED_CLI_CNFG_IDX, BLE_SERVC_READ_RSP),
    BLE_LNC_EVENT_LOCATION_AND_SPEED_CLI_CNFG_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_LNC_LOCATION_AND_SPEED_CLI_CNFG_IDX, BLE_SERVC_WRITE_RSP),

    /* Position Quality */
    BLE_LNC_EVENT_POSITION_QUALITY_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_LNC_POSITION_QUALITY_IDX, BLE_SERVC_READ_RSP),

    /* LN Control Point */
    BLE_LNC_EVENT_CP_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_LNC_CP_IDX, BLE_SERVC_WRITE_RSP),
    BLE_LNC_EVENT_CP_HDL_VAL_IND = BLE_SERVC_ATTR_EVENT(BLE_LNC_CP_IDX, BLE_SERVC_HDL_VAL_IND),
    BLE_LNC_EVENT_CP_CLI_CNFG_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_LNC_CP_CLI_CNFG_IDX, BLE_SERVC_READ_RSP),
    BLE_LNC_EVENT_CP_CLI_CNFG_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_LNC_CP_CLI_CNFG_IDX, BLE_SERVC_WRITE_RSP),

    /* Navigation */
    BLE_LNC_EVENT_NAVIGATION_HDL_VAL_NTF = BLE_SERVC_ATTR_EVENT(BLE_LNC_NAVIGATION_IDX, BLE_SERVC_HDL_VAL_NTF),
    BLE_LNC_EVENT_NAVIGATION_CLI_CNFG_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_LNC_NAVIGATION_CLI_CNFG_IDX, BLE_SERVC_READ_RSP),
    BLE_LNC_EVENT_NAVIGATION_CLI_CNFG_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_LNC_NAVIGATION_CLI_CNFG_IDX, BLE_SERVC_WRITE_RSP),
} e_ble_lnc_event_t;

/***************************************************************************//**
 * @brief     Initialize Location and Navigation client.
 * @param[in] cb Client callback.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_LNC_Init(ble_servc_app_cb_t cb);

/***************************************************************************//**
 * @brief     Location and Navigation client discovery callback.
 * @param[in] conn_hdl Connection handle
 * @param[in] serv_idx Service instance index.
 * @param[in] type     Service discovery event type.
 * @param[in] p_param  Service discovery event parameter.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_LNC_ServDiscCb(uint16_t conn_hdl, uint8_t serv_idx, uint16_t type, void *p_param);

/***************************************************************************//**
 * @brief     Get Location and Navigation client attribute handle.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
*******************************************************************************/
void R_BLE_LNC_GetServAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_gatt_hdl_range_t *p_hdl);

#endif /* R_BLE_LNC_H */

/** @} */
