/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_llc.c
 * Version : 1.0
 * Description : The source file for Link Loss client.
 **********************************************************************************************************************/
#include "r_ble_llc.h"
#include "profile_cmn/r_ble_servc_if.h"

#ifndef UNUSED_ARG
#define UNUSED_ARG(arg)         (void)(arg)
#endif /* UNUSED_ARG */

static st_ble_servc_info_t gs_client_info;

/*----------------------------------------------------------------------------------------------------------------------
    Alert Level Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Alert Level characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_alert_level_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

/* Alert Level characteristic value*/
typedef struct {
    uint16_t conn_hdl;
    uint8_t value;
} st_ble_llc_alert_level_value_t;

static st_ble_llc_alert_level_value_t gs_alert_level_val[BLE_SERVC_MAX_NUM_OF_SAVED];

static void ble_lls_read_rsp_cb(const void *p_attr, uint16_t conn_hdl, ble_status_t result, const void *p_app_value);

/* Alert Level characteristic definition */
const st_ble_servc_char_info_t gs_llc_alert_level_char = {
    .uuid_16      = BLE_LLC_ALERT_LEVEL_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(uint8_t),
    .db_size      = BLE_LLC_ALERT_LEVEL_LEN,
    .char_idx     = BLE_LLC_ALERT_LEVEL_IDX,
    .p_attr_hdls  = gs_alert_level_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_uint8_t,
    .encode       = (ble_servc_attr_encode_t)encode_uint8_t,
    .read_rsp_cb  = (ble_servc_attr_read_rsp_t)ble_lls_read_rsp_cb,
};

ble_status_t R_BLE_LLC_WriteAlertLevel(uint16_t conn_hdl, const uint8_t *p_value) // @suppress("API function naming")
{
    for (uint8_t i = 0; i < BLE_SERVC_MAX_NUM_OF_SAVED; i++)
    {
        if (conn_hdl == gs_alert_level_val[i].conn_hdl)
        {
            gs_alert_level_val[i].value = *p_value;
            break;
        }
    }

    return R_BLE_SERVC_WriteChar(&gs_llc_alert_level_char, conn_hdl, p_value);
}

ble_status_t R_BLE_LLC_ReadAlertLevel(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_llc_alert_level_char, conn_hdl);
}

void R_BLE_LLC_GetAlertLevelAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_llc_alert_level_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_alert_level_char_ranges[conn_idx];
}

static void ble_lls_read_rsp_cb(const void *p_attr, uint16_t conn_hdl, ble_status_t result, const void *p_app_value)
{
    UNUSED_ARG(result);

    uint8_t rd_value = *((uint8_t *)p_app_value);
    st_ble_servc_char_info_t * p_rd_attr = (st_ble_servc_char_info_t *)p_attr;

    for (uint8_t i = 0; i < BLE_SERVC_MAX_NUM_OF_SAVED; i++)
    {
        if (conn_hdl == gs_alert_level_val[i].conn_hdl)
        {
            gs_alert_level_val[i].value = rd_value;
            break;
        }
    }

    st_ble_servc_evt_data_t evt_data = {
        .conn_hdl  = conn_hdl,
        .param_len = gs_llc_alert_level_char.app_size,
        .p_param   = p_app_value,
    };
    gs_client_info.cb(BLE_SERVC_MULTI_ATTR_EVENT(p_rd_attr->char_idx, p_rd_attr->inst_idx, BLE_SERVC_READ_RSP), BLE_SUCCESS, &evt_data);
}


/*----------------------------------------------------------------------------------------------------------------------
    Link Loss client
----------------------------------------------------------------------------------------------------------------------*/

/* Link Loss client attribute handles */
static st_ble_gatt_hdl_range_t gs_llc_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

const st_ble_servc_char_info_t *gspp_llc_chars[] = {
    &gs_llc_alert_level_char,
};

static st_ble_servc_info_t gs_client_info = {
    .pp_chars     = gspp_llc_chars,
    .num_of_chars = ARRAY_SIZE(gspp_llc_chars),
    .p_attr_hdls  = gs_llc_ranges,
};

static void llc_gattc_cb(uint16_t type, ble_status_t result, st_ble_gattc_evt_data_t * p_data)
{
    UNUSED_ARG(result);

    switch (type)
    {
        case BLE_GATTC_EVENT_CONN_IND:
        {
            for (uint8_t i = 0; i < BLE_SERVC_MAX_NUM_OF_SAVED; i++)
            {
                if (BLE_GAP_INVALID_CONN_HDL == gs_alert_level_val[i].conn_hdl)
                {
                    gs_alert_level_val[i].conn_hdl = p_data->conn_hdl;
                    break;
                }
            }
        } break;
            
        case BLE_GATTC_EVENT_DISCONN_IND:
        {
            for (uint8_t i = 0; i < BLE_SERVC_MAX_NUM_OF_SAVED; i++)
            {
                if (p_data->conn_hdl == gs_alert_level_val[i].conn_hdl)
                {
                    gs_alert_level_val[i].conn_hdl = BLE_GAP_INVALID_CONN_HDL;
                }
            }
        } break;

        default:
        {
            /* Do nothing. */
        } break;
    }
}

ble_status_t R_BLE_LLC_Init(ble_servc_app_cb_t cb) // @suppress("API function naming")
{
    if (NULL == cb)
    {
        return BLE_ERR_INVALID_PTR;
    }
    
    gs_client_info.cb = cb;

    R_BLE_GATTC_RegisterCb(llc_gattc_cb, 5);

    for (uint8_t i = 0; i < BLE_SERVC_MAX_NUM_OF_SAVED; i++)
    {
        gs_alert_level_val[i].conn_hdl = BLE_GAP_INVALID_CONN_HDL;
    }

    return R_BLE_SERVC_RegisterClient(&gs_client_info);
}

void R_BLE_LLC_ServDiscCb(uint16_t conn_hdl, uint8_t serv_idx, uint16_t type, void *p_param) // @suppress("API function naming")
{
    R_BLE_SERVC_ServDiscCb(&gs_client_info, conn_hdl, serv_idx, type, p_param);
}

void R_BLE_LLC_GetServAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_gatt_hdl_range_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    *p_hdl = gs_llc_ranges[conn_idx];
}

ble_status_t R_BLE_LLC_Disconnect(uint16_t conn_hdl, uint8_t reason, uint8_t *p_alert_level)
{
    if (NULL == p_alert_level)
    {
    	return BLE_ERR_INVALID_PTR;
    }

    /* 0x13 = remote user terminated connection
     * 0x16 = connection terminated by local host
     * */
    if ((0x13 != reason) && (0x16 != reason))
    {
        for (uint8_t i = 0; i < BLE_SERVC_MAX_NUM_OF_SAVED; i++)
        {
            if (gs_alert_level_val[i].conn_hdl == conn_hdl)
            {
                *p_alert_level = gs_alert_level_val[i].value;
                break;
            }
        }
    }

    return BLE_SUCCESS;
}

