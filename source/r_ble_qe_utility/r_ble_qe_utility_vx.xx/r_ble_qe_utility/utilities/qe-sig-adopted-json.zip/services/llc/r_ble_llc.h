/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_llc.h
 * Version : 1.0
 * Description : The header file for Link Loss client.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 31.12.2999 1.00 First Release
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @file
 * @defgroup llc Link Loss Client
 * @{
 * @ingroup profile
 * @brief   This is the client for the Link Loss Service.
 **********************************************************************************************************************/
#include "r_ble_rx23w_if.h"
#include "profile_cmn/r_ble_servc_if.h"

#ifndef R_BLE_LLC_H
#define R_BLE_LLC_H

/*----------------------------------------------------------------------------------------------------------------------
    Alert Level Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_LLC_ALERT_LEVEL_UUID (0x2A06)
#define BLE_LLC_ALERT_LEVEL_LEN (1)

/***************************************************************************//**
 * @brief Alert Level Level enumeration.
*******************************************************************************/
typedef enum {
    BLE_LLC_ALERT_LEVEL_LEVEL_NO_ALERT = 0, /**< No Alert */
    BLE_LLC_ALERT_LEVEL_LEVEL_MILD_ALERT = 1, /**< Mild Alert */
    BLE_LLC_ALERT_LEVEL_LEVEL_HIGH_ALERT = 2, /**< High Alert */
} e_ble_llc_alert_level_level_t;

/***************************************************************************//**
 * @brief Alert Level attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
} st_ble_llc_alert_level_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Alert Level characteristic value from the remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_LLC_ReadAlertLevel(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Alert Level characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] p_value Alert Level characteristic value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_LLC_WriteAlertLevel(uint16_t conn_hdl, const uint8_t *p_value);

/***************************************************************************//**
 * @brief      Get Alert Level attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_LLC_GetAlertLevelAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_llc_alert_level_attr_hdl_t *p_hdl);


/*----------------------------------------------------------------------------------------------------------------------
    Link Loss Client
----------------------------------------------------------------------------------------------------------------------*/

/***************************************************************************//**
 * @brief Link Loss client event data.
*******************************************************************************/
typedef struct {
    uint16_t    conn_hdl;  /**< Connection handle */
    uint16_t    param_len; /**< Event parameter length */
    const void *p_param;   /**< Event parameter */
} st_ble_llc_evt_data_t;

/***************************************************************************//**
 * @brief Link Loss characteristic ID.
*******************************************************************************/
typedef enum {
    BLE_LLC_ALERT_LEVEL_IDX,
} e_ble_llc_char_idx_t;

/***************************************************************************//**
 * @brief Link Loss client event type.
*******************************************************************************/
typedef enum {
    /* Alert Level */
    BLE_LLC_EVENT_ALERT_LEVEL_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_LLC_ALERT_LEVEL_IDX, BLE_SERVC_READ_RSP),
    BLE_LLC_EVENT_ALERT_LEVEL_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_LLC_ALERT_LEVEL_IDX, BLE_SERVC_WRITE_RSP),
} e_ble_llc_event_t;

/***************************************************************************//**
 * @brief     Initialize Link Loss client.
 * @param[in] cb Client callback.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_LLC_Init(ble_servc_app_cb_t cb);

/***************************************************************************//**
 * @brief     Link Loss client discovery callback.
 * @param[in] conn_hdl Connection handle
 * @param[in] serv_idx Service instance index.
 * @param[in] type     Service discovery event type.
 * @param[in] p_param  Service discovery event parameter.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_LLC_ServDiscCb(uint16_t conn_hdl, uint8_t serv_idx, uint16_t type, void *p_param);

/***************************************************************************//**
 * @brief     Get Link Loss client attribute handle.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
*******************************************************************************/
void R_BLE_LLC_GetServAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_gatt_hdl_range_t *p_hdl);

/***************************************************************************//**
 * @brief     Alert when Disconnected.
 * @param[in] conn_hdl Connection handle.
 * @param[in] reason Disconnected reason.
 * @param[out] alertlevel Output location of Alert Level characteristic value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_LLC_Disconnect(uint16_t conn_hdl, uint8_t reason, uint8_t * alertlevel);

#endif /* R_BLE_LLC_H */

/** @} */
