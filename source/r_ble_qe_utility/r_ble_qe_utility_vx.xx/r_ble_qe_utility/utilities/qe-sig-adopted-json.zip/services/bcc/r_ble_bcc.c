/***********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
 * SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
 ***********************************************************************************************************************/

/***********************************************************************************************************************
 * File Name: r_ble_bcc.c
 * Version : 1.0
 * Description : This module implements Body Composition Service Client.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 22.03.2019 1.00 First Release
 ***********************************************************************************************************************/

/***********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 ***********************************************************************************************************************/
#include <string.h>
#include "profile_cmn/r_ble_serv_common.h"
#include "r_ble_bcc.h"
#include "discovery/r_ble_disc.h"

/***********************************************************************************************************************
 Macro definitions
 ***********************************************************************************************************************/
#ifndef UNUSED_ARG
#define UNUSED_ARG(arg)         (void)(arg)
#endif /* UNUSED_ARG */

/* Version number */
#define BLE_BCC_PRV_VERSION_MAJOR           (1)
#define BLE_BCC_PRV_VERSION_MINOR           (0)

#define BLE_BCC_PRV_CONNECTION_COUNT        (4)

/***********************************************************************************************************************
 Typedef definitions
 ***********************************************************************************************************************/
typedef struct
{
    uint16_t          conn_hdl;
    st_ble_bcc_hdls_t hdls;
} st_bcc_peer_param_t;

/***********************************************************************************************************************
 Exported global variables (to be accessed by other files)
 ***********************************************************************************************************************/
const uint8_t BLE_BCC_UUID[BLE_GATT_16_BIT_UUID_SIZE]                              = { 0x1B, 0x18 };
const uint8_t BLE_BCC_BODY_COMPOSITION_FEATURE_UUID[BLE_GATT_16_BIT_UUID_SIZE]     = { 0x9B, 0x2A };
const uint8_t BLE_BCC_BODY_COMPOSITION_MEASUREMENT_UUID[BLE_GATT_16_BIT_UUID_SIZE] = { 0x9C, 0x2A };
const uint8_t BLE_BCC_BODY_COMPOSITION_MEASUREMENT_CLIENT_CHARACTERISTIC_CONFIGURATION_UUID[BLE_GATT_16_BIT_UUID_SIZE] =
                                                                                     { 0x02, 0x29 };

/***********************************************************************************************************************
 Private global variables and functions
 ***********************************************************************************************************************/
static st_bcc_peer_param_t gs_peer_params[BLE_BCC_PRV_CONNECTION_COUNT];
static ble_bcc_app_cb_t    gs_bcc_cb;


/***********************************************************************************************************************
 * Function Name: find_peer_param
 * Description  : This function finds the attribute handles for the given connection handle.
 * Arguments    : conn_hdl - handle to connection
 * Return Value : pointer to the attribute handles structure
 **********************************************************************************************************************/
static st_bcc_peer_param_t *find_peer_param (uint16_t conn_hdl)
{
    for (uint8_t i = 0; i < BLE_BCC_PRV_CONNECTION_COUNT; i++)
    {
        if ((BLE_GAP_INVALID_CONN_HDL != gs_peer_params[i].conn_hdl) && (gs_peer_params[i].conn_hdl == conn_hdl))
        {
            return &gs_peer_params[i];
        }
    }
    return NULL;
}

/***********************************************************************************************************************
 * Function Name: get_new_peer_param
 * Description  : This function finds the free attribute handle.
 * Arguments    : conn_hdl - handle to connection.
 * Return Value : pointer to the free attribute handles structure
 **********************************************************************************************************************/
static st_bcc_peer_param_t *get_new_peer_param (uint16_t conn_hdl)
{
    for (uint8_t i = 0; i < BLE_BCC_PRV_CONNECTION_COUNT; i++)
    {
        if (BLE_GAP_INVALID_CONN_HDL == gs_peer_params[i].conn_hdl)
        {
            gs_peer_params[i].conn_hdl = conn_hdl;
            return &gs_peer_params[i];
        }
    }
    return NULL;
}

/***********************************************************************************************************************
 * Function Name: clear_peer_param
 * Description  : This function frees all the attribute handles.
 * Arguments    : p_peer - pointer to the attribute handle structure to be freed
 * Return Value : none
 ***********************************************************************************************************************/
static void clear_peer_param (st_bcc_peer_param_t *p_peer)
{
    if (NULL != p_peer)
    {
        p_peer->conn_hdl = BLE_GAP_INVALID_CONN_HDL;
        memset( &p_peer->hdls, 0x00, sizeof(p_peer->hdls));
    }
}

/***********************************************************************************************************************
 * Function Name: decode_body_composition_feature
 * Description  : This function converts Body Composition Feature characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the Body Composition Feature value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_body_composition_feature (st_ble_bcc_body_composition_feature_t *p_app_value,
        const st_ble_gatt_value_t *p_gatt_value)
{
    /* Convert byte sequence to application data. */
    uint32_t bcs_feature = 0;

    /* Value length not checked since the PTS expects the extra octets received shoudl be 
    ignored and the execution should continue */
    memset(p_app_value, 0x0, sizeof(st_ble_bcc_body_composition_feature_t));

    BT_UNPACK_LE_4_BYTE(&bcs_feature, &p_gatt_value->p_value[0]);

    /* Time Stamp Supported bit */
    if (bcs_feature & BLE_BCC_BODY_COMPOSITION_FEATURE_TIME_STAMP_SUPPORTED)
    {
        p_app_value->is_timestamp_supported = true;
    }
    else
    {
        p_app_value->is_timestamp_supported = false;
    }

    /* Multiple Users Supported bit */
    if (bcs_feature & BLE_BCC_BODY_COMPOSITION_FEATURE_MULTIPLE_USERS_SUPPORTED)
    {
        p_app_value->is_multiple_users_supported = true;
    }
    else
    {
        p_app_value->is_multiple_users_supported = false;
    }

    /* Basal Metabolism Supported bit */
    if (bcs_feature & BLE_BCC_BODY_COMPOSITION_FEATURE_BASAL_METABOLISM_SUPPORTED)
    {
        p_app_value->is_basal_metabolism_supported = true;
    }
    else
    {
        p_app_value->is_basal_metabolism_supported = false;
    }

    /* Muscle Percentage Supported bit */
    if (bcs_feature & BLE_BCC_BODY_COMPOSITION_FEATURE_MUSCLE_PERCENTAGE_SUPPORTED)
    {
        p_app_value->is_muscle_percentage_supported = true;
    }
    else
    {
        p_app_value->is_muscle_percentage_supported = false;
    }

    /* Muscle Mass Supported bit */
    if (bcs_feature & BLE_BCC_BODY_COMPOSITION_FEATURE_MUSCLE_MASS_SUPPORTED)
    {
        p_app_value->is_muscle_mass_supported = true;
    }
    else
    {
        p_app_value->is_muscle_mass_supported = false;
    }

    /* Fat Free Mass Supported bit */
    if (bcs_feature & BLE_BCC_BODY_COMPOSITION_FEATURE_FAT_FREE_MASS_SUPPORTED)
    {
        p_app_value->is_fat_free_mass_supported = true;
    }
    else
    {
        p_app_value->is_fat_free_mass_supported = false;
    }

    /* Soft Lean Mass Supported bit */
    if (bcs_feature & BLE_BCC_BODY_COMPOSITION_FEATURE_SOFT_LEAN_MASS_SUPPORTED)
    {
        p_app_value->is_soft_lean_mass_supported = true;
    }
    else
    {
        p_app_value->is_soft_lean_mass_supported = false;
    }

    /* Body Water Mass Supported */
    if (bcs_feature & BLE_BCC_BODY_COMPOSITION_FEATURE_BODY_WATER_MASS_SUPPORTED)
    {
        p_app_value->is_body_water_mass_supported = true;
    }
    else
    {
        p_app_value->is_body_water_mass_supported = false;
    }

    /* Impedance Supported bit */
    if (bcs_feature & BLE_BCC_BODY_COMPOSITION_FEATURE_IMPEDANCE_SUPPORTED)
    {
        p_app_value->is_impedance_supported = true;
    }
    else
    {
        p_app_value->is_impedance_supported = false;
    }

    /* Weight Supported bit and Weight Resolution */
    if (bcs_feature & BLE_BCC_BODY_COMPOSITION_FEATURE_WEIGHT_SUPPORTED)
    {
        p_app_value->is_weight_supported = true;
        p_app_value->mass_measurement_resolution = (p_gatt_value->p_value[1] >> 3) & 0xF;
    }
    else
    {
        p_app_value->is_weight_supported = false;
        p_app_value->mass_measurement_resolution = 0;
    }

    /* Height Supported bit and Height Resolution */
    if (bcs_feature & BLE_BCC_BODY_COMPOSITION_FEATURE_HEIGHT_SUPPORTED)
    {
        p_app_value->is_height_supported = true;
        p_app_value->height_measurement_resolution = (uint8_t)(((p_gatt_value->p_value[1] >> 7) & 0x1)
                                                   | ((p_gatt_value->p_value[2] & 0x3) << 1));
    }
    else
    {
        p_app_value->is_height_supported = false;
        p_app_value->height_measurement_resolution = 0;
    }

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: decode_body_composition_measurement
 * Description  : This function converts Body Composition Measurement characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the Body Composition Measurement value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_body_composition_measurement (st_ble_bcc_body_composition_measurement_t *p_app_value,
        const st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t     pos  = 2;
    uint16_t     flag = 0;
    ble_status_t ret  = BLE_SUCCESS;
    
    memset(p_app_value, 0x00, sizeof(st_ble_bcc_body_composition_measurement_t));

    /* Copy the flag bytes */
    BT_UNPACK_LE_2_BYTE(&flag, &p_gatt_value->p_value[0]);

    p_app_value->is_multiple_packet_measurement_present =
        (flag & BLE_BCC_BODY_COMPOSITION_MEASUREMENT_FLAGS_MULTIPLE_PACKET_MEASUREMENT);

    /* Measurement Units Bit */
    if ((flag & BLE_BCC_BODY_COMPOSITION_MEASUREMENT_FLAGS_MEASUREMENT_UNITS))
    {
        p_app_value->is_measurement_in_imperial_units = true;
    }
    else
    {
        p_app_value->is_measurement_in_imperial_units = false;
    }
    
    /* Copy Body Fat Percentage */
    BT_UNPACK_LE_2_BYTE(&(p_app_value->body_fat_percentage), &(p_gatt_value->p_value[pos]));
    pos += (sizeof(p_app_value->body_fat_percentage));

    /* Time stamp Present Bit */
    if (flag & BLE_BCC_BODY_COMPOSITION_MEASUREMENT_FLAGS_TIME_STAMP_PRESENT)
    {
        p_app_value->is_timestamp_present                        = true;

        /* Copy the timestamp */
        BT_UNPACK_LE_2_BYTE(&(p_app_value->time_stamp.year), &(p_gatt_value->p_value[pos]));
        pos += (sizeof(p_app_value->time_stamp.year));

        BT_UNPACK_LE_1_BYTE(&(p_app_value->time_stamp.month), &(p_gatt_value->p_value[pos++]));
        BT_UNPACK_LE_1_BYTE(&(p_app_value->time_stamp.day), &(p_gatt_value->p_value[pos++]));
        BT_UNPACK_LE_1_BYTE(&(p_app_value->time_stamp.hours), &(p_gatt_value->p_value[pos++]));
        BT_UNPACK_LE_1_BYTE(&(p_app_value->time_stamp.minutes), &(p_gatt_value->p_value[pos++]));
        BT_UNPACK_LE_1_BYTE(&(p_app_value->time_stamp.seconds), &(p_gatt_value->p_value[pos++]));
    }
    else
    {
        p_app_value->is_timestamp_present                        = false;
    }

    /* User ID Present Bit */
    if (flag & BLE_BCC_BODY_COMPOSITION_MEASUREMENT_FLAGS_USER_ID_PRESENT)
    {
        /* Set the flag and Copy the User ID*/
        p_app_value->is_user_id_present = true;
        BT_UNPACK_LE_1_BYTE(&(p_app_value->user_id), &(p_gatt_value->p_value[pos++]));
    }
    else
    {
        p_app_value->is_user_id_present = false;
    }

    /* Basal Metabolism Present Bit */
    if (flag & BLE_BCC_BODY_COMPOSITION_MEASUREMENT_FLAGS_BASAL_METABOLISM_PRESENT)
    {
        /* Copy the Basal Metabolism Value */
        p_app_value->is_basal_metabolism_present = true;
        BT_UNPACK_LE_2_BYTE(&(p_app_value->basal_metabolism), &(p_gatt_value->p_value[pos]));
        pos += (sizeof(p_app_value->basal_metabolism));
    }
    else
    {
        p_app_value->is_basal_metabolism_present = false;
    }

    /* Muscle Percentage present or not */
    if (flag & BLE_BCC_BODY_COMPOSITION_MEASUREMENT_FLAGS_MUSCLE_PERCENTAGE_PRESENT)
    {
        /* Copy Muscle Percentage */
        p_app_value->is_muscle_percentage_present = true;
        BT_UNPACK_LE_2_BYTE(&(p_app_value->muscle_percentage), &(p_gatt_value->p_value[pos]));
        pos += (sizeof(p_app_value->muscle_percentage));
    }
    else
    {
        p_app_value->is_muscle_percentage_present = false;
    }

    /*  Muscle Mass present or not */
    if (flag & BLE_BCC_BODY_COMPOSITION_MEASUREMENT_FLAGS_MUSCLE_MASS_PRESENT)
    {
        /* Copy the Muscle Mass */
        p_app_value->is_muscle_mass_present = true;
        BT_UNPACK_LE_2_BYTE(&(p_app_value->muscle_mass), &(p_gatt_value->p_value[pos]));
        pos += (sizeof(p_app_value->muscle_mass));
    }
    else
    {
        p_app_value->is_muscle_mass_present = false;
    }

    /* Fat Free Mass present or not */
    if (flag & BLE_BCC_BODY_COMPOSITION_MEASUREMENT_FLAGS_FAT_FREE_MASS_PRESENT)
    {
        /* Copy the Fat Free Mass */
        p_app_value->is_fat_free_mass_present = true;
        BT_UNPACK_LE_2_BYTE(&(p_app_value->fat_free_mass), &(p_gatt_value->p_value[pos]));
        pos += (sizeof(p_app_value->fat_free_mass));
    }
    else
    {
        p_app_value->is_fat_free_mass_present = false;
    }

    /* Soft Lean Mass present or not */
    if(flag & BLE_BCC_BODY_COMPOSITION_MEASUREMENT_FLAGS_SOFT_LEAN_MASS_PRESENT)
    {
        /* Copy the Soft Lean Mass */
        p_app_value->is_soft_lean_mass_present = true;
        BT_UNPACK_LE_2_BYTE(&(p_app_value->soft_lean_mass), &(p_gatt_value->p_value[pos]));
        pos += (sizeof(p_app_value->soft_lean_mass));
    }
    else
    {
        p_app_value->is_soft_lean_mass_present = false;
    }

    /*  Body Water Mass present or not */
    if (flag & BLE_BCC_BODY_COMPOSITION_MEASUREMENT_FLAGS_BODY_WATER_MASS_PRESENT)
    {
        /* Copy the Body Water Mass */
        p_app_value->is_body_water_mass_present = true;
        BT_UNPACK_LE_2_BYTE(&(p_app_value->body_water_mass), &(p_gatt_value->p_value[pos]));
        pos += (sizeof(p_app_value->body_water_mass));
    }
    else
    {
        p_app_value->is_body_water_mass_present = false;
    }

    /*  Impedance present or not */
    if (flag & BLE_BCC_BODY_COMPOSITION_MEASUREMENT_FLAGS_IMPEDANCE_PRESENT)
    {
        /* Copy the Impedance */
        p_app_value->is_impedance_present = true;
        BT_UNPACK_LE_2_BYTE(&(p_app_value->impedance), &(p_gatt_value->p_value[pos]));
        pos += (sizeof(p_app_value->impedance));
    }
    else
    {
        p_app_value->is_impedance_present = false;
    }

    /* Weight present or not */
    if (flag & BLE_BCC_BODY_COMPOSITION_MEASUREMENT_FLAGS_WEIGHT_PRESENT)
    {
        /* Copy the Weight */
        p_app_value->is_weight_present = true;
        BT_UNPACK_LE_2_BYTE(&(p_app_value->weight), &(p_gatt_value->p_value[pos]));
        pos += (sizeof(p_app_value->weight));
    }
    else
    {
        p_app_value->is_weight_present = false;
    }

    /* Height Supported or not */
    if (flag & BLE_BCC_BODY_COMPOSITION_MEASUREMENT_FLAGS_HEIGHT_PRESENT)
    {
        /* Copy the Weight */
        p_app_value->is_height_present = true;
        BT_UNPACK_LE_2_BYTE(&(p_app_value->height), &(p_gatt_value->p_value[pos]));
        pos += (sizeof(p_app_value->height));
    }
    else
    {
        p_app_value->is_height_present = false;
    }

    /* Multiple Packet Measurement */
    if (flag & BLE_BCC_BODY_COMPOSITION_MEASUREMENT_FLAGS_MULTIPLE_PACKET_MEASUREMENT)
    {
        p_app_value->is_multiple_packet_measurement_present = true;
    }
    else
    {
        p_app_value->is_multiple_packet_measurement_present = false;
    }

    /* Check the length */
    if (p_gatt_value->value_len != pos)
    {
        ret = BLE_ERR_INVALID_DATA;
    }

    return ret;
}

/***********************************************************************************************************************
 * Function Name: bcc_gattc_cb
 * Description  : Callback function for the Body Composition GATTC events.
 * Arguments    : conn_hdl - handle to the connection
 *                result - ble status
 *              : p_data - pointer to GATTC event data
 * Return Value : none
 ***********************************************************************************************************************/
static void bcc_gattc_cb (uint16_t type, ble_status_t result, st_ble_gattc_evt_data_t *p_data) // @suppress("Function length")
{
    st_bcc_peer_param_t *p_peer = find_peer_param(p_data->conn_hdl);

    switch (type)
    {
        case BLE_GATTC_EVENT_CHAR_READ_RSP:
        {
            /* Type cast void pointer to st_ble_gattc_rd_char_evt_t* */
            st_ble_gattc_rd_char_evt_t *p_rd_char_evt_param = (st_ble_gattc_rd_char_evt_t *) p_data->p_param;

            if (p_rd_char_evt_param->read_data.attr_hdl == p_peer->hdls.body_composition_feature_char_val_hdl)
            {
                ble_status_t ret;
                st_ble_bcc_body_composition_feature_t app_value;

                ret = decode_body_composition_feature( &app_value, &p_rd_char_evt_param->read_data.value);

                st_ble_bcc_evt_data_t evt_data =
                { 
                    .conn_hdl  = p_data->conn_hdl, 
                    .param_len = sizeof(app_value), 
                    .p_param   = &app_value, 
                };
                
                gs_bcc_cb(BLE_BCC_EVENT_BODY_COMPOSITION_FEATURE_READ_RSP, ret, &evt_data);
            }
        }
        break;

        case BLE_GATTC_EVENT_HDL_VAL_IND:
        {
            /* Type cast void pointer to st_ble_gattc_ind_evt_t* */
            st_ble_gattc_ind_evt_t *p_ind_evt_param = (st_ble_gattc_ind_evt_t *) p_data->p_param;

            if (p_ind_evt_param->data.attr_hdl == p_peer->hdls.body_composition_measurement_char_val_hdl)
            {
                ble_status_t ret;
                st_ble_bcc_body_composition_measurement_t app_value;

                ret = decode_body_composition_measurement( &app_value, &p_ind_evt_param->data.value);

                st_ble_bcc_evt_data_t evt_data =
                { 
                    .conn_hdl  = p_data->conn_hdl, 
                    .param_len = sizeof(app_value), 
                    .p_param   = &app_value, 
                };

                gs_bcc_cb(BLE_BCC_EVENT_BODY_COMPOSITION_MEASUREMENT_HDL_VAL_IND, ret, &evt_data);
            }
        }
        break;

        case BLE_GATTC_EVENT_ERROR_RSP:
        {
            /* Type cast void pointer to st_ble_gattc_err_rsp_evt_t* */
            st_ble_gattc_err_rsp_evt_t *p_err_rsp_evt_param = (st_ble_gattc_err_rsp_evt_t *) p_data->p_param;

            st_ble_bcc_evt_data_t evt_data =
            { 
                .conn_hdl  = p_data->conn_hdl, 
                .param_len = sizeof(st_ble_gattc_err_rsp_evt_t), 
                .p_param   = p_err_rsp_evt_param, 
            };
            
            if (p_err_rsp_evt_param->attr_hdl == p_peer->hdls.body_composition_feature_char_val_hdl)
            {
                gs_bcc_cb(BLE_BCC_EVENT_ERROR_RSP, result, &evt_data);
            }
        }
        break;

        default:
        {
            /* Do nothing. */
        }
        break;
    }
}

ble_status_t R_BLE_BCC_Init (const st_ble_bcc_init_param_t *p_param) // @suppress("API function naming")
{
    if (NULL == p_param)
    {
        return BLE_ERR_INVALID_PTR;
    }

    if (NULL == p_param->cb)
    {
        return BLE_ERR_INVALID_ARG;
    }

    for (uint8_t i = 0; i < BLE_BCC_PRV_CONNECTION_COUNT; i++)
    {
        clear_peer_param( &gs_peer_params[i]);
    }

    R_BLE_GATTC_RegisterCb(bcc_gattc_cb, 5);

    gs_bcc_cb = p_param->cb;

    return BLE_SUCCESS;
}

ble_status_t R_BLE_BCC_Connect (uint16_t conn_hdl, const st_ble_bcc_connect_param_t *p_param) // @suppress("API function naming")
{
    st_bcc_peer_param_t *p_peer = get_new_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if ((NULL != p_param) && (NULL != p_param->p_hdls))
    {
        memcpy( &p_peer->hdls, p_param->p_hdls, sizeof(p_peer->hdls));
    }

    return BLE_SUCCESS;
}

ble_status_t R_BLE_BCC_Disconnect (uint16_t conn_hdl, st_ble_bcc_disconnect_param_t *p_param) // @suppress("API function naming")
{
    st_bcc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if ((NULL != p_param) && (NULL != p_param->p_hdls))
    {
        memcpy(p_param->p_hdls, &p_peer->hdls, sizeof( *p_param->p_hdls));
    }

    clear_peer_param(p_peer);

    return BLE_SUCCESS;
}

ble_status_t R_BLE_BCC_ReadBodyCompositionFeature (uint16_t conn_hdl) // @suppress("API function naming")
{
    st_bcc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.body_composition_feature_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    return R_BLE_GATTC_ReadChar(conn_hdl, p_peer->hdls.body_composition_feature_char_val_hdl);
}

ble_status_t R_BLE_BCC_SetBodyCompositionMeasurementCliCnfg (uint16_t conn_hdl, uint16_t cli_cnfg) // @suppress("API function naming")
{
    st_bcc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.body_composition_measurement_cli_cnfg_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    if (0 != (cli_cnfg & 0xFFFC))
    {
        return BLE_ERR_INVALID_ARG;
    }

    uint8_t byte_value[2] = { 0 };
    
    BT_PACK_LE_2_BYTE(byte_value, &cli_cnfg);

    st_ble_gatt_hdl_value_pair_t gatt_value =
    { 
        .attr_hdl = p_peer->hdls.body_composition_measurement_cli_cnfg_hdl, 
        .value    = 
        { 
            .p_value   = byte_value, 
            .value_len = 2, 
        } 
    };

    return R_BLE_GATTC_WriteChar(conn_hdl, &gatt_value);
}

void R_BLE_BCC_ServDiscCb (uint16_t conn_hdl, uint8_t idx, uint16_t type, void *p_param) // @suppress("API function naming")
{
    UNUSED_ARG(idx);

    st_bcc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    switch (type)
    {
        case BLE_DISC_PRIM_SERV_FOUND:
        {
            /* Type cast void pointer to st_disc_serv_param_t* */
            st_disc_serv_param_t *p_serv_param = (st_disc_serv_param_t *) p_param;

            memcpy( &p_peer->hdls.service_range, &p_serv_param->value.serv_16.range,
                    sizeof(p_peer->hdls.service_range));
        }
        break;

        case BLE_DISC_CHAR_FOUND:
        {
            /* Type cast void pointer to st_disc_char_param_t* */
            st_disc_char_param_t *p_char_param = (st_disc_char_param_t *) p_param;

            if (BLE_GATT_16_BIT_UUID_FORMAT == p_char_param->uuid_type)
            {
                uint8_t uuid_16[BLE_GATT_16_BIT_UUID_SIZE];

                BT_PACK_LE_2_BYTE(uuid_16, &p_char_param->value.char_16.uuid_16);

                if (0 == memcmp(uuid_16, BLE_BCC_BODY_COMPOSITION_FEATURE_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.body_composition_feature_char_val_hdl = p_char_param->value.char_16.value_hdl;

                }
                else if (0 == memcmp(uuid_16, BLE_BCC_BODY_COMPOSITION_MEASUREMENT_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.body_composition_measurement_char_val_hdl = p_char_param->value.char_16.value_hdl;

                    for (uint8_t i = 0; i < p_char_param->num_of_descs; i++)
                    {
                        BT_PACK_LE_2_BYTE(uuid_16, &p_char_param->descs[i].value.desc_16.uuid_16);

                        if (0
                                == memcmp(uuid_16,
                                        BLE_BCC_BODY_COMPOSITION_MEASUREMENT_CLIENT_CHARACTERISTIC_CONFIGURATION_UUID,
                                        BLE_GATT_16_BIT_UUID_SIZE))
                        {
                            p_peer->hdls.body_composition_measurement_cli_cnfg_hdl =
                                    p_char_param->descs[i].value.desc_16.desc_hdl;
                        }
                    }
                }
                else
                {
                    /* Do Nothing */
                }
            }
        }
        break;

        default:
        {
            /* Do nothing. */
        }
        break;
    }
}

uint32_t R_BLE_BCC_GetVersion (void) // @suppress("API function naming")
{
    uint32_t version;

    version = ((BLE_BCC_PRV_VERSION_MAJOR << 16) | (BLE_BCC_PRV_VERSION_MINOR << 8));

    return version;
}

