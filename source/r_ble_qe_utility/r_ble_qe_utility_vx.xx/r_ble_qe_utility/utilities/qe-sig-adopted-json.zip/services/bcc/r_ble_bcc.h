/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_bcc.h
 * Version : 1.0
 * Description : This module implements Body Composition Service Client.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 22.03.2019 1.00 First Release
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @file
 * @defgroup bcc Body Composition Service Client
 * @{
 * @ingroup profile
 * @brief This file provides APIs to interface Body Composition Service Client.
 **********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_ble_rx23w_if.h"
#include "profile_cmn/r_ble_profile_cmn.h"

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
#ifndef R_BLE_BCC_H
#define R_BLE_BCC_H

/*******************************************************************************************************************//**
 * @brief Body Composition Feature characteristic value length.
***********************************************************************************************************************/
#define BLE_BCC_BODY_COMPOSITION_FEATURE_LEN                                        (4)
/*******************************************************************************************************************//**
 * @brief Body Composition Measurement characteristic value length.
***********************************************************************************************************************/
#define BLE_BCC_BODY_COMPOSITION_MEASUREMENT_LEN                                    (30)

/*******************************************************************************************************************//**
 * @brief Time Stamp Supported bit.
***********************************************************************************************************************/
#define BLE_BCC_BODY_COMPOSITION_FEATURE_TIME_STAMP_SUPPORTED                       (1 << 0)

/*******************************************************************************************************************//**
 * @brief Multiple Users Supported bit.
***********************************************************************************************************************/
#define BLE_BCC_BODY_COMPOSITION_FEATURE_MULTIPLE_USERS_SUPPORTED                   (1 << 1)

/*******************************************************************************************************************//**
 * @brief Basal Metabolism Supported bit.
***********************************************************************************************************************/
#define BLE_BCC_BODY_COMPOSITION_FEATURE_BASAL_METABOLISM_SUPPORTED                 (1 << 2)

/*******************************************************************************************************************//**
 * @brief Muscle Percentage Supported bit.
***********************************************************************************************************************/
#define BLE_BCC_BODY_COMPOSITION_FEATURE_MUSCLE_PERCENTAGE_SUPPORTED                (1 << 3)

/*******************************************************************************************************************//**
 * @brief Muscle Mass Supported bit.
***********************************************************************************************************************/
#define BLE_BCC_BODY_COMPOSITION_FEATURE_MUSCLE_MASS_SUPPORTED                      (1 << 4)

/*******************************************************************************************************************//**
 * @brief Fat Free Mass Supported bit.
***********************************************************************************************************************/
#define BLE_BCC_BODY_COMPOSITION_FEATURE_FAT_FREE_MASS_SUPPORTED                    (1 << 5)

/*******************************************************************************************************************//**
 * @brief Soft Lean Mass Supported bit.
***********************************************************************************************************************/
#define BLE_BCC_BODY_COMPOSITION_FEATURE_SOFT_LEAN_MASS_SUPPORTED                   (1 << 6)

/*******************************************************************************************************************//**
 * @brief Body Water Mass Supported bit.
***********************************************************************************************************************/
#define BLE_BCC_BODY_COMPOSITION_FEATURE_BODY_WATER_MASS_SUPPORTED                  (1 << 7)

/*******************************************************************************************************************//**
 * @brief Impedance Supported bit.
***********************************************************************************************************************/
#define BLE_BCC_BODY_COMPOSITION_FEATURE_IMPEDANCE_SUPPORTED                        (1 << 8)

/*******************************************************************************************************************//**
 * @brief Weight Supported bit.
***********************************************************************************************************************/
#define BLE_BCC_BODY_COMPOSITION_FEATURE_WEIGHT_SUPPORTED                           (1 << 9)

/*******************************************************************************************************************//**
 * @brief Height Supported bit.
***********************************************************************************************************************/
#define BLE_BCC_BODY_COMPOSITION_FEATURE_HEIGHT_SUPPORTED                           (1 << 10)

/*******************************************************************************************************************//**
 * @brief Mass Measurement Resolution bits.
***********************************************************************************************************************/
#define BLE_BCC_BODY_COMPOSITION_FEATURE_MASS_MEASUREMENT_RESOLUTION                (((1 << 4) - 1) << 11)

/*******************************************************************************************************************//**
 * @brief Height Measurement Resolution bits.
***********************************************************************************************************************/
#define BLE_BCC_BODY_COMPOSITION_FEATURE_HEIGHT_MEASUREMENT_RESOLUTION              (((1 << 3) - 1) << 15)

/*******************************************************************************************************************//**
 * @brief Measurement Units bit.
***********************************************************************************************************************/
#define BLE_BCC_BODY_COMPOSITION_MEASUREMENT_FLAGS_MEASUREMENT_UNITS                (1 << 0)

/*******************************************************************************************************************//**
 * @brief Time Stamp Present bit.
***********************************************************************************************************************/
#define BLE_BCC_BODY_COMPOSITION_MEASUREMENT_FLAGS_TIME_STAMP_PRESENT               (1 << 1)

/*******************************************************************************************************************//**
 * @brief User ID present bit.
***********************************************************************************************************************/
#define BLE_BCC_BODY_COMPOSITION_MEASUREMENT_FLAGS_USER_ID_PRESENT                  (1 << 2)

/*******************************************************************************************************************//**
 * @brief Basal Metabolism present bit.
***********************************************************************************************************************/
#define BLE_BCC_BODY_COMPOSITION_MEASUREMENT_FLAGS_BASAL_METABOLISM_PRESENT         (1 << 3)

/*******************************************************************************************************************//**
 * @brief Muscle Percentage present bit.
***********************************************************************************************************************/
#define BLE_BCC_BODY_COMPOSITION_MEASUREMENT_FLAGS_MUSCLE_PERCENTAGE_PRESENT        (1 << 4)

/*******************************************************************************************************************//**
 * @brief Muscle Mass present bit.
***********************************************************************************************************************/
#define BLE_BCC_BODY_COMPOSITION_MEASUREMENT_FLAGS_MUSCLE_MASS_PRESENT              (1 << 5)

/*******************************************************************************************************************//**
 * @brief Fat Free Mass present bit.
***********************************************************************************************************************/
#define BLE_BCC_BODY_COMPOSITION_MEASUREMENT_FLAGS_FAT_FREE_MASS_PRESENT            (1 << 6)

/*******************************************************************************************************************//**
 * @brief Soft Lean Mass present bit.
***********************************************************************************************************************/
#define BLE_BCC_BODY_COMPOSITION_MEASUREMENT_FLAGS_SOFT_LEAN_MASS_PRESENT           (1 << 7)

/*******************************************************************************************************************//**
 * @brief Body Water Mass present bit.
***********************************************************************************************************************/
#define BLE_BCC_BODY_COMPOSITION_MEASUREMENT_FLAGS_BODY_WATER_MASS_PRESENT          (1 << 8)

/*******************************************************************************************************************//**
 * @brief Impedance present bit.
***********************************************************************************************************************/
#define BLE_BCC_BODY_COMPOSITION_MEASUREMENT_FLAGS_IMPEDANCE_PRESENT                (1 << 9)

/*******************************************************************************************************************//**
 * @brief Weight present bit.
***********************************************************************************************************************/
#define BLE_BCC_BODY_COMPOSITION_MEASUREMENT_FLAGS_WEIGHT_PRESENT                   (1 << 10)

/*******************************************************************************************************************//**
 * @brief Height present bit.
***********************************************************************************************************************/
#define BLE_BCC_BODY_COMPOSITION_MEASUREMENT_FLAGS_HEIGHT_PRESENT                   (1 << 11)

/*******************************************************************************************************************//**
 * @brief Multiple Packet Measurement bit.
***********************************************************************************************************************/
#define BLE_BCC_BODY_COMPOSITION_MEASUREMENT_FLAGS_MULTIPLE_PACKET_MEASUREMENT      (1 << 12)

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @brief Body Composition Service Client event data.
***********************************************************************************************************************/
typedef struct
{
    uint16_t  conn_hdl;  /**< Connection handle */
    uint16_t  param_len; /**< Event parameter length */
    void     *p_param;   /**< Event parameter */
} st_ble_bcc_evt_data_t;

/*******************************************************************************************************************//**
 * @brief Body Composition Service Client event callback.
***********************************************************************************************************************/
typedef void (*ble_bcc_app_cb_t)(uint16_t type, ble_status_t result, st_ble_bcc_evt_data_t *p_data);

/*******************************************************************************************************************//**
 * @brief Body Composition Service Client event type.
***********************************************************************************************************************/
typedef enum
{
    BLE_BCC_EVENT_BODY_COMPOSITION_FEATURE_READ_RSP, /**< Body Composition Feature characteristic read response event */
    BLE_BCC_EVENT_BODY_COMPOSITION_MEASUREMENT_HDL_VAL_IND, /**< Body Composition Measurement characteristic handle 
                                                            value indication event */
    BLE_BCC_EVENT_CLI_CNFG_WRITE_RSP,                      /**< Cli Cnfig write response */
    BLE_BCC_EVENT_ERROR_RSP,                              /**< error response */
} e_ble_bcc_event_t;

/*******************************************************************************************************************//**
 * @brief User ID enumeration.
***********************************************************************************************************************/
typedef enum
{
    BLE_BCC_BODY_COMPOSITION_MEASUREMENT_USER_ID_UNKNOWN_USER = 255, /**< Unknown User */
} e_ble_bcc_body_composition_measurement_t;

/*******************************************************************************************************************//**
 * @brief Body Composition Service attribute handles.
***********************************************************************************************************************/
typedef struct
{
    st_ble_gatt_hdl_range_t service_range; /**< Body Composition Service range */
    uint16_t body_composition_feature_char_val_hdl; /**< Body Composition Feature characteristic value handle */
    uint16_t body_composition_measurement_char_val_hdl; /**< Body Composition Measurement characteristic value handle */
    uint16_t body_composition_measurement_cli_cnfg_hdl; /**< Body Composition Measurement characteristic Client
                                                        Characteristic Configuration descriptor handle */
} st_ble_bcc_hdls_t;

/*******************************************************************************************************************//**
 * @brief Body Composition Service initialization parameters.
***********************************************************************************************************************/
typedef struct
{
    ble_bcc_app_cb_t cb; /**< Body Composition Service Client event handler */
} st_ble_bcc_init_param_t;

/*******************************************************************************************************************//**
 * @brief Body Composition Service Client connection parameters.
***********************************************************************************************************************/
typedef struct
{
    st_ble_bcc_hdls_t *p_hdls; /**< Body Composition Service handles */
} st_ble_bcc_connect_param_t;

/*******************************************************************************************************************//**
 * @brief Body Composition Service disconnection parameters.
***********************************************************************************************************************/
typedef struct
{
    st_ble_bcc_hdls_t *p_hdls; /**< Body Composition Service handles */
} st_ble_bcc_disconnect_param_t;

/*******************************************************************************************************************//**
 * @brief Body Composition Feature characteristic parameters.
***********************************************************************************************************************/
typedef struct
{
    bool    is_timestamp_supported;         /**< Time Stamp feature supported for Weight Scale or not */
    bool    is_multiple_users_supported;    /**< Multiple Users feature supported for Weight Scale or not */
    bool    is_basal_metabolism_supported;  /**< Basal Metabolism Supported or not */
    bool    is_muscle_percentage_supported; /**< Muscle Percentage Supported or not */
    bool    is_muscle_mass_supported;       /**< Muscle Mass Supported or not */
    bool    is_fat_free_mass_supported;     /**< Fat Free Mass Supported or not */
    bool    is_soft_lean_mass_supported;    /**< Soft Lean Mass Supported or not */
    bool    is_body_water_mass_supported;   /**< Body Water Mass Supported or not */
    bool    is_impedance_supported;         /**< Impedance Supported or not */
    bool    is_weight_supported;            /**< Weight Supported or not */
    bool    is_height_supported;            /**< Height Supported or not */
    uint8_t mass_measurement_resolution;    /**< Mass Measurement Resolution */
    uint8_t height_measurement_resolution;  /**< Height Measurement Resolution */
} st_ble_bcc_body_composition_feature_t;

/*******************************************************************************************************************//**
 * @brief Body Composition Measurement characteristic parameters.
***********************************************************************************************************************/
typedef struct
{
    bool               is_measurement_in_imperial_units;       /**< Weight and Mass in SI Units or Imperial Units */
    bool               is_timestamp_present;                   /**< Time stamp present or not */
    bool               is_user_id_present;                     /**< User ID present or not */
    bool               is_basal_metabolism_present;            /**< Basal Metabolism present or not */
    bool               is_muscle_percentage_present;           /**< Muscle Percentage present or not */
    bool               is_muscle_mass_present;                 /**< Muscle Mass present or not */
    bool               is_fat_free_mass_present;               /**< Fat Free Mass present or not */
    bool               is_soft_lean_mass_present;              /**< Soft Lean Mass present or not */
    bool               is_body_water_mass_present;             /**< Body Water Mass present or not */
    bool               is_impedance_present;                   /**< Impedance present or not */
    bool               is_weight_present;                      /**< Weight present or not */
    bool               is_height_present;                      /**< Height Supported or not */
    bool               is_multiple_packet_measurement_present; /**< Multiple Packet Measurement */
    uint16_t           body_fat_percentage;                    /**< Body Fat Percentage with a resolution of 0.1 */
    st_ble_date_time_t time_stamp;                             /**< Time Stamp */
    uint8_t            user_id;                                /**< User ID */
    uint16_t           basal_metabolism;                       /**< Basal Metabolism in Joules with a resolution of 1 */
    uint16_t           muscle_percentage;                      /**< Muscle Percentage with a resolutin of 0.1 */
    uint16_t           muscle_mass;                            /**< Muscle Mass in Kilograms or Ponds */
    uint16_t           fat_free_mass;                          /**< Fat Free Mass - Kilograms or Ponds */
    uint16_t           soft_lean_mass;                         /**< Soft Lean Mass - Kilograms or Ponds */
    uint16_t           body_water_mass;                        /**< Body Water Mass - Kilograms or Ponts */
    uint16_t           impedance;                              /**< Impedance in Ohms with a resolution of 0.1 */
    uint16_t           weight;                                 /**< Weight - Kilograms or Ponts */
    uint16_t           height;                                 /**< Height - Meters or Inches */
} st_ble_bcc_body_composition_measurement_t;

/***********************************************************************************************************************
Exported global variables (to be accessed by other files)
***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @brief Body Composition Service UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_BCC_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Body Composition Feature characteristic UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_BCC_BODY_COMPOSITION_FEATURE_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Body Composition Measurement characteristic UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_BCC_BODY_COMPOSITION_MEASUREMENT_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/***********************************************************************************************************************
Exported global functions (to be accessed by other files)
***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @brief     Initialize Body Composition Service  Client.
 * @details   This function shall be called once at startup.
 * @param[in] p_param Pointer to Body Composition Service Client initialization parameters.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_BCC_Init(const st_ble_bcc_init_param_t *p_param);

/*******************************************************************************************************************//**
 * @brief     Perform Body Composition Service Client connection settings.
 * @details   This function shall be called on each connection establishment.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_param    Pointer to Connection parameters.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_BCC_Connect(uint16_t conn_hdl, const st_ble_bcc_connect_param_t *p_param);

/*******************************************************************************************************************//**
 * @brief     Retrieve Body Composition Service Client connection specific settings before disconnection.
 * @details   This function shall be called on each disconnection.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] p_param   Pointer to Disconnection parameters.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_BCC_Disconnect(uint16_t conn_hdl, st_ble_bcc_disconnect_param_t *p_param);

/*******************************************************************************************************************//**
 * @brief      Read Body Composition Feature characteristic value from remote GATT database.
 * @param[in]  conn_hdl Connection handle
 * @return     @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_BCC_ReadBodyCompositionFeature(uint16_t conn_hdl);

/*******************************************************************************************************************//**
 * @brief     Set Body Composition Measurement characteristic cli cnfg.
 * @param[in] conn_hdl Connection handle.
 * @param[in] cli_cnfg Body Composition Measurement characteristic cli cnfg to set.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_BCC_SetBodyCompositionMeasurementCliCnfg(uint16_t conn_hdl, uint16_t cli_cnfg);

/***********************************************************************************************************************
 * @brief      Callback function for the Body Composition Discovery events.
 * @param[out] conn_hdl Connection handle.
 * @param[out] idx      Service index used to distiguish the multiple same UUID service.
 * @param[out] type     Discovery event type
 * @param[out] p_param  Pointer to GATTC event data.
***********************************************************************************************************************/
void R_BLE_BCC_ServDiscCb(uint16_t conn_hdl, uint8_t idx, uint16_t type, void *p_param);

/*******************************************************************************************************************//**
 * @brief     Return version of the BCC service client.
 * @return    version
***********************************************************************************************************************/
uint32_t R_BLE_BCC_GetVersion(void);

#endif /* R_BLE_BCC_H */

/** @} */
