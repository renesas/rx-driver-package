/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_cts.c
 * Version : 1.0
 * Description : The source file for Current Time Service service.
 **********************************************************************************************************************/
 /***********************************************************************************************************************
   * History : DD.MM.YYYY Version Description
   *         : 24.05.2019 1.00 First Release
  ***********************************************************************************************************************/
#include <string.h>
#include "r_ble_cts.h"
#include "profile_cmn/r_ble_servs_if.h"
#include "gatt_db.h"

/***********************************************************************************************************************
 Private global variables and functions
 ***********************************************************************************************************************/
static ble_status_t validate_st_ble_cts_cur_time_t(const st_ble_cts_cur_time_t *p_date_time);
static ble_status_t validate_st_ble_cts_local_time_info_t(const st_ble_cts_local_time_info_t *p_app_value);

static st_ble_servs_info_t gs_servs_info;

/*----------------------------------------------------------------------------------------------------------------------
    Current Time Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

static const st_ble_servs_desc_info_t gs_cur_time_cli_cnfg =
{
    .attr_hdl = BLE_CTS_CUR_TIME_CLI_CNFG_DESC_HDL,
    .app_size = sizeof(uint16_t),
    .desc_idx = BLE_CTS_CUR_TIME_CLI_CNFG_IDX,
    .db_size  = BLE_CTS_CUR_TIME_CLI_CNFG_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_uint16_t,
    .encode   = (ble_servs_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_CTS_SetCurTimeCliCnfg(const uint16_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_cur_time_cli_cnfg, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_CTS_GetCurTimeCliCnfg(uint16_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_cur_time_cli_cnfg, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Current Time characteristic
----------------------------------------------------------------------------------------------------------------------*/

static ble_status_t decode_st_ble_cts_cur_time_t(st_ble_cts_cur_time_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    if (BLE_CTS_CUR_TIME_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    memset((uint8_t*)p_app_value, 0x00, sizeof(*p_app_value));

    BT_UNPACK_LE_2_BYTE(&p_app_value->exact_time_256.date_time.year, &p_gatt_value->p_value[pos]);
    pos += 2;

    p_app_value->exact_time_256.date_time.month   = p_gatt_value->p_value[pos++];
    p_app_value->exact_time_256.date_time.day     = p_gatt_value->p_value[pos++];
    p_app_value->exact_time_256.date_time.hours   = p_gatt_value->p_value[pos++];
    p_app_value->exact_time_256.date_time.minutes = p_gatt_value->p_value[pos++];
    p_app_value->exact_time_256.date_time.seconds = p_gatt_value->p_value[pos++];
    p_app_value->exact_time_256.day_of_week       = p_gatt_value->p_value[pos++];
    p_app_value->exact_time_256.fractions256      = p_gatt_value->p_value[pos++];
    
    p_app_value->adjust_reason.is_manual_time_update             = !!(p_gatt_value->p_value[pos] & 0x01);
    p_app_value->adjust_reason.is_external_reference_time_update = !!(p_gatt_value->p_value[pos] & 0x02);
    p_app_value->adjust_reason.is_change_of_time_zone            = !!(p_gatt_value->p_value[pos] & 0x04);
    p_app_value->adjust_reason.is_change_of_dst                  = !!(p_gatt_value->p_value[pos] & 0x08);

    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_cts_cur_time_t(const st_ble_cts_cur_time_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos] ,&p_app_value->exact_time_256.date_time.year);
    pos += 2;

    p_gatt_value->p_value[pos++] = p_app_value->exact_time_256.date_time.month;
    p_gatt_value->p_value[pos++] = p_app_value->exact_time_256.date_time.day;
    p_gatt_value->p_value[pos++] = p_app_value->exact_time_256.date_time.hours;
    p_gatt_value->p_value[pos++] = p_app_value->exact_time_256.date_time.minutes;
    p_gatt_value->p_value[pos++] = p_app_value->exact_time_256.date_time.seconds;
    p_gatt_value->p_value[pos++] = p_app_value->exact_time_256.day_of_week;
    p_gatt_value->p_value[pos++] = p_app_value->exact_time_256.fractions256;

    p_gatt_value->p_value[pos] |= p_app_value->adjust_reason.is_manual_time_update ? 0x01 : 0x00;
    p_gatt_value->p_value[pos] |= p_app_value->adjust_reason.is_external_reference_time_update ? 0x02 : 0x00;
    p_gatt_value->p_value[pos] |= p_app_value->adjust_reason.is_change_of_time_zone ? 0x04 : 0x00;
    p_gatt_value->p_value[pos] |= p_app_value->adjust_reason.is_change_of_dst ? 0x08 : 0x00;
    pos += 1;

    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

static void write_req_cur_time(const void *p_attr, uint16_t conn_hdl, ble_status_t result, const st_ble_cts_cur_time_t *p_app_value)
{
    ble_status_t ret;

    ret = validate_st_ble_cts_cur_time_t(p_app_value);

    if (BLE_SUCCESS != ret)
    {
        R_BLE_GATTS_SendErrRsp(BLE_CTS_DATA_FIELD_IGNORED_ERROR);
    }
}

/* Current Time characteristic descriptor definition */
static const st_ble_servs_desc_info_t *gspp_cur_time_descs[] =
{
    &gs_cur_time_cli_cnfg,
};

/* Current Time characteristic definition */
static const st_ble_servs_char_info_t gs_cur_time_char =
{
    .start_hdl    = BLE_CTS_CUR_TIME_DECL_HDL,
    .end_hdl      = BLE_CTS_CUR_TIME_CLI_CNFG_DESC_HDL,
    .char_idx     = BLE_CTS_CUR_TIME_IDX,
    .app_size     = sizeof(st_ble_cts_cur_time_t),
    .db_size      = BLE_CTS_CUR_TIME_LEN,
    .write_req_cb = (ble_servs_attr_write_req_t)write_req_cur_time,
    .decode       = (ble_servs_attr_decode_t)decode_st_ble_cts_cur_time_t,
    .encode       = (ble_servs_attr_encode_t)encode_st_ble_cts_cur_time_t,
    .pp_descs     = gspp_cur_time_descs,
    .num_of_descs = ARRAY_SIZE(gspp_cur_time_descs),
};

ble_status_t R_BLE_CTS_SetCurTime(const st_ble_cts_cur_time_t *p_value)
{
    return R_BLE_SERVS_SetChar(&gs_cur_time_char, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_CTS_GetCurTime(st_ble_cts_cur_time_t *p_value)
{
    return R_BLE_SERVS_GetChar(&gs_cur_time_char, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

ble_status_t R_BLE_CTS_NotifyCurTime(uint16_t conn_hdl, const st_ble_cts_cur_time_t *p_value)
{
    return R_BLE_SERVS_SendHdlVal(&gs_cur_time_char, conn_hdl, (const void *)p_value, true);
}

/*----------------------------------------------------------------------------------------------------------------------
    Local Time Information characteristic
----------------------------------------------------------------------------------------------------------------------*/

static ble_status_t decode_st_ble_cts_local_time_info_t(st_ble_cts_local_time_info_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    if (BLE_CTS_LOCAL_TIME_INFO_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    memset((uint8_t*)p_app_value, 0x00, sizeof(*p_app_value));

    p_app_value->time_zone                   = p_gatt_value->p_value[pos++];
    p_app_value->daylight_saving_time_offset = p_gatt_value->p_value[pos++];

    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_cts_local_time_info_t(const st_ble_cts_local_time_info_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;
    
    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);
    
    p_gatt_value->p_value[pos++] = p_app_value->time_zone;
    p_gatt_value->p_value[pos++] = p_app_value->daylight_saving_time_offset;

    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

static void write_req_local_time_info(const void *p_attr, uint16_t conn_hdl, ble_status_t result, const st_ble_cts_local_time_info_t *p_app_value)
{
    ble_status_t ret;

    ret = validate_st_ble_cts_local_time_info_t(p_app_value);

    if (BLE_SUCCESS != ret)
    {
        R_BLE_GATTS_SendErrRsp(BLE_CTS_DATA_FIELD_IGNORED_ERROR);
    }
}

/* Local Time Information characteristic definition */
static const st_ble_servs_char_info_t gs_local_time_info_char =
{
    .start_hdl    = BLE_CTS_LOCAL_TIME_INFO_DECL_HDL,
    .end_hdl      = BLE_CTS_LOCAL_TIME_INFO_VAL_HDL,
    .char_idx     = BLE_CTS_LOCAL_TIME_INFO_IDX,
    .app_size     = sizeof(st_ble_cts_local_time_info_t),
    .db_size      = BLE_CTS_LOCAL_TIME_INFO_LEN,
    .write_req_cb = (ble_servs_attr_write_req_t)write_req_local_time_info,
    .decode       = (ble_servs_attr_decode_t)decode_st_ble_cts_local_time_info_t,
    .encode       = (ble_servs_attr_encode_t)encode_st_ble_cts_local_time_info_t,
};

ble_status_t R_BLE_CTS_SetLocalTimeInfo(const st_ble_cts_local_time_info_t *p_value)
{
    return R_BLE_SERVS_SetChar(&gs_local_time_info_char, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_CTS_GetLocalTimeInfo(st_ble_cts_local_time_info_t *p_value)
{
    return R_BLE_SERVS_GetChar(&gs_local_time_info_char, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Reference Time Information characteristic
----------------------------------------------------------------------------------------------------------------------*/

static ble_status_t decode_st_ble_cts_ref_time_info_t(st_ble_cts_ref_time_info_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    if (BLE_CTS_REF_TIME_INFO_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    memset((uint8_t*)p_app_value, 0x00, sizeof(*p_app_value));

    p_app_value->source                 = p_gatt_value->p_value[pos++];
    p_app_value->accuracy               = p_gatt_value->p_value[pos++];
    p_app_value->days_since_update      = p_gatt_value->p_value[pos++];
    p_app_value->hours_since_update     = p_gatt_value->p_value[pos++];
    
    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_cts_ref_time_info_t(const st_ble_cts_ref_time_info_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    p_gatt_value->p_value[pos++] = p_app_value->source;
    p_gatt_value->p_value[pos++] = p_app_value->accuracy;
    p_gatt_value->p_value[pos++] = p_app_value->days_since_update;
    p_gatt_value->p_value[pos++] = p_app_value->hours_since_update;
    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

/* Reference Time Information characteristic definition */
static const st_ble_servs_char_info_t gs_ref_time_info_char = 
{
    .start_hdl    = BLE_CTS_REF_TIME_INFO_DECL_HDL,
    .end_hdl      = BLE_CTS_REF_TIME_INFO_VAL_HDL,
    .char_idx     = BLE_CTS_REF_TIME_INFO_IDX,
    .app_size     = sizeof(st_ble_cts_ref_time_info_t),
    .db_size      = BLE_CTS_REF_TIME_INFO_LEN,
    .decode       = (ble_servs_attr_decode_t)decode_st_ble_cts_ref_time_info_t,
    .encode       = (ble_servs_attr_encode_t)encode_st_ble_cts_ref_time_info_t,
};

ble_status_t R_BLE_CTS_SetRefTimeInfo(const st_ble_cts_ref_time_info_t *p_value)
{
    return R_BLE_SERVS_SetChar(&gs_ref_time_info_char, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_CTS_GetRefTimeInfo(st_ble_cts_ref_time_info_t *p_value)
{
    return R_BLE_SERVS_GetChar(&gs_ref_time_info_char, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Current Time Service server
----------------------------------------------------------------------------------------------------------------------*/

/* Current Time Service characteristics definition */
static const st_ble_servs_char_info_t *gspp_chars[] = 
{
    &gs_cur_time_char,
    &gs_local_time_info_char,
    &gs_ref_time_info_char,
};

/* Current Time Service service definition */
static st_ble_servs_info_t gs_servs_info = 
{
    .pp_chars     = gspp_chars,
    .num_of_chars = ARRAY_SIZE(gspp_chars),
};

static ble_status_t validate_st_ble_cts_cur_time_t(const st_ble_cts_cur_time_t *p_app_value)
{
    if ((9999 < p_app_value->exact_time_256.date_time.year) || (1582 > p_app_value->exact_time_256.date_time.year))
    {
        return BLE_ERR_INVALID_DATA;
    }

    if ((1 > p_app_value->exact_time_256.date_time.month) || (12 < p_app_value->exact_time_256.date_time.month))
    {
        return BLE_ERR_INVALID_DATA;
    }

    if ((1 > p_app_value->exact_time_256.date_time.day) || (31 < p_app_value->exact_time_256.date_time.day))
    {
        return BLE_ERR_INVALID_DATA;
    }

    if ((4 == p_app_value->exact_time_256.date_time.month) || (6 == p_app_value->exact_time_256.date_time.month) ||
        (9 == p_app_value->exact_time_256.date_time.month) || (11 == p_app_value->exact_time_256.date_time.month))
    {
        if (31 == p_app_value->exact_time_256.date_time.day)
        {
            return BLE_ERR_INVALID_DATA;
        }
    }

    if (2 == p_app_value->exact_time_256.date_time.month)
    {
        if (((p_app_value->exact_time_256.date_time.year % 4 == 0) && (p_app_value->exact_time_256.date_time.year % 100 != 0)) ||
            (p_app_value->exact_time_256.date_time.year % 400 == 0))
        {
            if (29 < p_app_value->exact_time_256.date_time.day)
            {
                return BLE_ERR_INVALID_DATA;
            }
        }
        else
        {
            if (28 < p_app_value->exact_time_256.date_time.day)
            {
                return BLE_ERR_INVALID_DATA;
            }
        }
    }

    if ((0 > p_app_value->exact_time_256.date_time.hours) || (23 < p_app_value->exact_time_256.date_time.hours))
    {
        return BLE_ERR_INVALID_DATA;
    }

    if ((0 > p_app_value->exact_time_256.date_time.minutes) || (59 < p_app_value->exact_time_256.date_time.minutes))
    {
        return BLE_ERR_INVALID_DATA;
    }

    if ((0 > p_app_value->exact_time_256.date_time.seconds) || (59 < p_app_value->exact_time_256.date_time.seconds))
    {
        return BLE_ERR_INVALID_DATA;
    }

    return BLE_SUCCESS;
}

static ble_status_t validate_st_ble_cts_local_time_info_t(const st_ble_cts_local_time_info_t *p_app_value)
{
    if ((56 <= p_app_value->time_zone) || (-48 > p_app_value->time_zone))
    {
        return BLE_ERR_INVALID_DATA;
    }

    if ((BLE_CTS_LOCAL_TIME_INFO_DAYLIGHT_SAVING_TIME_OFFSET_STANDARD_TIME != p_app_value->daylight_saving_time_offset) &&
        (BLE_CTS_LOCAL_TIME_INFO_DAYLIGHT_SAVING_TIME_OFFSET_HALF_AN_HOUR_DAYLIGHT_TIME != p_app_value->daylight_saving_time_offset) &&
        (BLE_CTS_LOCAL_TIME_INFO_DAYLIGHT_SAVING_TIME_OFFSET_DAYLIGHT_TIME != p_app_value->daylight_saving_time_offset) &&
        (BLE_CTS_LOCAL_TIME_INFO_DAYLIGHT_SAVING_TIME_OFFSET_DOUBLE_DAYLIGHT_TIME != p_app_value->daylight_saving_time_offset))
    {
        return BLE_ERR_INVALID_DATA;
    }

    return BLE_SUCCESS;
}

ble_status_t R_BLE_CTS_Init(ble_servs_app_cb_t cb)
{
    if (NULL == cb)
    {
        return BLE_ERR_INVALID_PTR;
    }

    gs_servs_info.cb = cb;

    return R_BLE_SERVS_RegisterServer(&gs_servs_info);
}
