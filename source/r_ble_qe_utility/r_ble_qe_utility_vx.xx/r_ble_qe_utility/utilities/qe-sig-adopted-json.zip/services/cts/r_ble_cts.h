/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_cts.h
 * Version : 1.0
 * Description : The header file for Current Time Service service.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 24.05.2019 1.00 First Release
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @file
 * @defgroup cts Current Time Service Service
 * @{
 * @ingroup profile
 * @brief   This service defines how the current time can be exposed using the Generic Attribute Profile (GATT).
 **********************************************************************************************************************/
#include "r_ble_rx23w_if.h"
#include "profile_cmn/r_ble_servs_if.h"
#include "gatt_db.h"

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
#ifndef R_BLE_CTS_H
#define R_BLE_CTS_H

/*----------------------------------------------------------------------------------------------------------------------
    Current Time Characteristic
----------------------------------------------------------------------------------------------------------------------*/
      
/***************************************************************************//**
 * @brief Current Time Exact Time 256 value structure.
*******************************************************************************/
typedef struct 
{
    st_ble_date_time_t date_time;      /**< Date Time */
    uint8_t day_of_week;               /**< Day of Week */
    uint8_t fractions256;              /**< Fractions256 */
} st_ble_cts_cur_time_exact_time_256_t;

/***************************************************************************//**
 * @brief Current Time Adjust Reason value structure.
*******************************************************************************/
typedef struct 
{
    bool is_manual_time_update;               /**< Manual time update */
    bool is_external_reference_time_update;   /**< External Reference Time Update */
    bool is_change_of_time_zone;              /**< Change of Time Zone */
    bool is_change_of_dst;                    /**< Change of Day Saving Time */
} st_ble_cts_cur_time_adjust_reason_t;

/***************************************************************************//**
 * @brief Current Time value structure.
*******************************************************************************/
typedef struct 
{
    st_ble_cts_cur_time_exact_time_256_t exact_time_256;   /**< Exact Time 256 */
    st_ble_cts_cur_time_adjust_reason_t adjust_reason;     /**< Adjust Reason */
} st_ble_cts_cur_time_t;

/***************************************************************************//**
 * @brief     Set Current Time characteristic value to the local GATT database.
 * @param[in] p_value  Characteristic value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_CTS_SetCurTime(const st_ble_cts_cur_time_t *p_value);

/***************************************************************************//**
 * @brief     Get Current Time characteristic value from the local GATT database.
 * @param[in] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_CTS_GetCurTime(st_ble_cts_cur_time_t *p_value);

/***************************************************************************//**
 * @brief     Send notification of  Current Time characteristic value to the remote device.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value  Characteristic value to send.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_CTS_NotifyCurTime(uint16_t conn_hdl, const st_ble_cts_cur_time_t *p_value);

/***************************************************************************//**
 * @brief     Set Current Time cli cnfg descriptor value to the local GATT database.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_CTS_SetCurTimeCliCnfg(const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Get Current Time cli cnfg descriptor value from the local GATT database.
 * @param[in] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_CTS_GetCurTimeCliCnfg(uint16_t *p_value);

/*----------------------------------------------------------------------------------------------------------------------
    Local Time Information Characteristic
----------------------------------------------------------------------------------------------------------------------*/
/***************************************************************************//**
 * @brief Local Time Information Daylight Saving Time Offset enumeration.
*******************************************************************************/
typedef enum 
{
    BLE_CTS_LOCAL_TIME_INFO_DAYLIGHT_SAVING_TIME_OFFSET_STANDARD_TIME              = 0, /**< Standard Time */
    BLE_CTS_LOCAL_TIME_INFO_DAYLIGHT_SAVING_TIME_OFFSET_HALF_AN_HOUR_DAYLIGHT_TIME = 2, /**< Half An Hour Daylight Time (+0.5h) */
    BLE_CTS_LOCAL_TIME_INFO_DAYLIGHT_SAVING_TIME_OFFSET_DAYLIGHT_TIME              = 4, /**< Daylight Time (+1h) */
    BLE_CTS_LOCAL_TIME_INFO_DAYLIGHT_SAVING_TIME_OFFSET_DOUBLE_DAYLIGHT_TIME       = 8, /**< Double Daylight Time (+2h) */
} e_ble_cts_local_time_info_daylight_saving_time_offset_t;

/***************************************************************************//**
 * @brief Local Time Information value structure.
*******************************************************************************/
typedef struct 
{
    int8_t time_zone;                    /**< Time Zone */
    uint8_t daylight_saving_time_offset; /**< Daylight Saving Time */
} st_ble_cts_local_time_info_t;

/***************************************************************************//**
 * @brief     Set Local Time Information characteristic value to the local GATT database.
 * @param[in] p_value  Characteristic value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_CTS_SetLocalTimeInfo(const st_ble_cts_local_time_info_t *p_value);

/***************************************************************************//**
 * @brief     Get Local Time Information characteristic value from the local GATT database.
 * @param[in] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_CTS_GetLocalTimeInfo(st_ble_cts_local_time_info_t *p_value);

/*----------------------------------------------------------------------------------------------------------------------
    Reference Time Information Characteristic
----------------------------------------------------------------------------------------------------------------------*/
/***************************************************************************//**
 * @brief Reference Time Information Source enumeration.
*******************************************************************************/
typedef enum 
{
    BLE_CTS_REF_TIME_INFO_SOURCE_UNKNOWN               = 0,  /**< Unknown */
    BLE_CTS_REF_TIME_INFO_SOURCE_NETWORK_TIME_PROTOCOL = 1,  /**< Network Time Protocol */
    BLE_CTS_REF_TIME_INFO_SOURCE_GPS                   = 2,  /**< GPS */
    BLE_CTS_REF_TIME_INFO_SOURCE_RADIO_TIME_SIGNAL     = 3,  /**< Radio Time Signal */
    BLE_CTS_REF_TIME_INFO_SOURCE_MANUAL                = 4,  /**< Manual */
    BLE_CTS_REF_TIME_INFO_SOURCE_ATOMIC_CLOCK          = 5,  /**< Atomic Clock */
    BLE_CTS_REF_TIME_INFO_SOURCE_CELLULAR_NETWORK      = 6,  /**< Cellular Network */
} e_ble_cts_ref_time_info_source_t;

/***************************************************************************//**
 * @brief Reference Time Information value structure.
*******************************************************************************/
typedef struct 
{
    uint8_t source;                                       /**< Source */
    uint8_t accuracy;                                     /**< Accuracy */
    uint8_t days_since_update;                           /**< Days Since Update */
    uint8_t hours_since_update;                          /**< Hours Since Update */
} st_ble_cts_ref_time_info_t;

/***************************************************************************//**
 * @brief     Set Reference Time Information characteristic value to the local GATT database.
 * @param[in] p_value  Characteristic value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_CTS_SetRefTimeInfo(const st_ble_cts_ref_time_info_t *p_value);

/***************************************************************************//**
 * @brief     Get Reference Time Information characteristic value from the local GATT database.
 * @param[in] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_CTS_GetRefTimeInfo(st_ble_cts_ref_time_info_t *p_value);

/*----------------------------------------------------------------------------------------------------------------------
    Current Time Service Service
----------------------------------------------------------------------------------------------------------------------*/

/***************************************************************************//**
 * @brief The server ignored one or more fields.
*******************************************************************************/
#define BLE_CTS_DATA_FIELD_IGNORED_ERROR (BLE_ERR_GROUP_GATT | 0x80)

/***************************************************************************//**
 * @brief Current Time Service characteristic Index.
*******************************************************************************/
typedef enum
{
    BLE_CTS_CUR_TIME_IDX,
    BLE_CTS_CUR_TIME_CLI_CNFG_IDX,
    BLE_CTS_LOCAL_TIME_INFO_IDX,
    BLE_CTS_REF_TIME_INFO_IDX,
} e_ble_cts_char_idx_t;

/***************************************************************************//**
 * @brief Current Time Service event type.
*******************************************************************************/
typedef enum 
{
    /* Current Time */
    BLE_CTS_EVENT_CUR_TIME_WRITE_REQ           = BLE_SERVS_ATTR_EVENT(BLE_CTS_CUR_TIME_IDX, BLE_SERVS_WRITE_REQ),
    BLE_CTS_EVENT_CUR_TIME_WRITE_COMP          = BLE_SERVS_ATTR_EVENT(BLE_CTS_CUR_TIME_IDX, BLE_SERVS_WRITE_COMP),
    BLE_CTS_EVENT_CUR_TIME_READ_REQ            = BLE_SERVS_ATTR_EVENT(BLE_CTS_CUR_TIME_IDX, BLE_SERVS_READ_REQ),
    BLE_CTS_EVENT_CUR_TIME_CLI_CNFG_WRITE_REQ  = BLE_SERVS_ATTR_EVENT(BLE_CTS_CUR_TIME_CLI_CNFG_IDX, BLE_SERVS_WRITE_REQ),
    BLE_CTS_EVENT_CUR_TIME_CLI_CNFG_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_CTS_CUR_TIME_CLI_CNFG_IDX, BLE_SERVS_WRITE_COMP),
    BLE_CTS_EVENT_CUR_TIME_CLI_CNFG_READ_REQ   = BLE_SERVS_ATTR_EVENT(BLE_CTS_CUR_TIME_CLI_CNFG_IDX, BLE_SERVS_READ_REQ),
    /* Local Time Information */
    BLE_CTS_EVENT_LOCAL_TIME_INFO_WRITE_REQ    = BLE_SERVS_ATTR_EVENT(BLE_CTS_LOCAL_TIME_INFO_IDX, BLE_SERVS_WRITE_REQ),
    BLE_CTS_EVENT_LOCAL_TIME_INFO_WRITE_COMP   = BLE_SERVS_ATTR_EVENT(BLE_CTS_LOCAL_TIME_INFO_IDX, BLE_SERVS_WRITE_COMP),
    BLE_CTS_EVENT_LOCAL_TIME_INFO_READ_REQ     = BLE_SERVS_ATTR_EVENT(BLE_CTS_LOCAL_TIME_INFO_IDX, BLE_SERVS_READ_REQ),
    /* Reference Time Information */
    BLE_CTS_EVENT_REF_TIME_INFO_READ_REQ       = BLE_SERVS_ATTR_EVENT(BLE_CTS_REF_TIME_INFO_IDX, BLE_SERVS_READ_REQ),
} e_ble_cts_event_t;

/***************************************************************************//**
 * @brief     Initialize Current Time Service service.
 * @param[in] cb Service callback.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_CTS_Init(ble_servs_app_cb_t cb);

#endif /* R_BLE_CTS_H */

/** @} */
