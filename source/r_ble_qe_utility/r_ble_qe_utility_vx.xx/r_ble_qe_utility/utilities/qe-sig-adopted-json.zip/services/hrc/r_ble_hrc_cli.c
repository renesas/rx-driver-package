/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
#include <stdlib.h>
#include "services/hrc/r_ble_hrc.h"
#include "cli/r_ble_cli.h"

#define pf R_BLE_CLI_Printf

extern uint16_t g_conn_hdl;

static void cmd_hrc_set_meas(int argc, char *argv[])
{
    if (argc != 2)
    {
        pf("hrc %s: unrecognized operands\n", argv[0]);
    }

    long value = strtol(argv[1], NULL, 0);

    ble_status_t ret;
    ret = R_BLE_HRC_SetHeartRateMeasurementCliCnfg(g_conn_hdl, (uint16_t)value);
    if (ret != BLE_SUCCESS)
    {
        pf("hrc %s: failed with 0x%04X\n", argv[0], ret);
    }
}

static void cmd_hrc_reset_energy(int argc, char *argv[])
{
    if (argc != 1)
    {
        pf("hrc %s: unrecognized operands\n", argv[0]);
    }

    ble_status_t ret;
    ret = R_BLE_HRC_ResetEnergyExpended(g_conn_hdl);
    if (ret != BLE_SUCCESS)
    {
        pf("hrc %s: failed with 0x%04X\n", argv[0], ret);
    }
}

static const st_ble_cli_cmd_t hrc_sub_cmds[] =
{
    {
        .cmd = "set_meas",
        .exec = cmd_hrc_set_meas,
        .help = "Usage: hrc set_meas value",
    },
    {
        .cmd  = "reset_energy",
        .exec = cmd_hrc_reset_energy,
        .help = "Usage: hrc reset_energy",
    },
    {   .cmd = NULL },
};

static const st_ble_cli_cmd_t hrc_cmds[] =
{
    {
        .cmd      = "hrc",
        .sub_cmds = hrc_sub_cmds,
        .help     = "Sub Command: set_meas, reset_energy\n"
                    "Try 'hrc sub-cmd help' for more information",
    },
    {
        .cmd = NULL
    },
};
