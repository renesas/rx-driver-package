/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_hrc.c
 * Version : 1.0
 * Description : The source file for Heart Rate client.
 **********************************************************************************************************************/
#include <string.h>
#include "r_ble_hrc.h"
#include "profile_cmn/r_ble_servc_if.h"

static st_ble_servc_info_t gs_client_info;

/*----------------------------------------------------------------------------------------------------------------------
    Heart Rate Measurement Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Heart Rate Measurement characteristic descriptors attribute handles */
static uint16_t gs_meas_cli_cnfg_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_meas_cli_cnfg ={
    .uuid_16     = BLE_HRC_MEAS_CLI_CNFG_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint16_t),
    .db_size     = BLE_HRC_MEAS_CLI_CNFG_LEN,
    .desc_idx    = BLE_HRC_MEAS_CLI_CNFG_IDX,
    .p_attr_hdls = gs_meas_cli_cnfg_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_HRC_WriteMeasCliCnfg(uint16_t conn_hdl, const uint16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_meas_cli_cnfg, conn_hdl, p_value);
}

ble_status_t R_BLE_HRC_ReadMeasCliCnfg(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_meas_cli_cnfg, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Heart Rate Measurement Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Heart Rate Measurement characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_meas_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

static ble_status_t decode_st_ble_hrc_meas_t(st_ble_hrc_meas_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_app_value, 0x00, sizeof(*p_app_value));

    p_app_value->flags.is_heart_rate_value_16_bit          = !!(p_gatt_value->p_value[pos] & 0x01);
    p_app_value->flags.is_sensor_contact_detected          = !!(p_gatt_value->p_value[pos] & 0x02);
    p_app_value->flags.is_sensor_contact_feature_supported = !!(p_gatt_value->p_value[pos] & 0x04);
    p_app_value->flags.is_energy_expended_included         = !!(p_gatt_value->p_value[pos] & 0x08);
    p_app_value->flags.is_rr_interval_included             = !!(p_gatt_value->p_value[pos] & 0x10);
    pos++;

    if (p_app_value->flags.is_heart_rate_value_16_bit)
    {
        BT_UNPACK_LE_2_BYTE(&p_app_value->heart_rate_measurement_value, &p_gatt_value->p_value[pos]);
        pos += 2;
    }
    else
    {
        p_app_value->heart_rate_measurement_value = (uint16_t)p_gatt_value->p_value[pos];
        pos++;
    }

    if (p_app_value->flags.is_energy_expended_included)
    {
        BT_UNPACK_LE_2_BYTE(&p_app_value->energy_expended, &p_gatt_value->p_value[pos]);
        pos += 2;
    }

    if (p_app_value->flags.is_rr_interval_included)
    {
        p_app_value->number_of_rr_interval = (p_gatt_value->value_len - pos) / 2;

        for (uint8_t i = 0; i < p_app_value->number_of_rr_interval; i++)
        {
            BT_UNPACK_LE_2_BYTE(&p_app_value->rr_interval[i], &p_gatt_value->p_value[pos]);
            pos += 2;
        }
    }

    return BLE_SUCCESS;
}

/* Heart Rate Measurement characteristic descriptor definition */
static const st_ble_servc_desc_info_t *gspp_meas_descs[] = {
    &gs_meas_cli_cnfg,
};

/* Heart Rate Measurement characteristic definition */
static const st_ble_servc_char_info_t gs_meas_char = {
    .uuid_16      = BLE_HRC_MEAS_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_hrc_meas_t),
    .db_size      = BLE_HRC_MEAS_LEN,
    .char_idx     = BLE_HRC_MEAS_IDX,
    .p_attr_hdls  = gs_meas_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_hrc_meas_t,
    .num_of_descs = ARRAY_SIZE(gspp_meas_descs),
    .pp_descs     = gspp_meas_descs,
};

void R_BLE_HRC_GetMeasAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_hrc_meas_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_meas_char_ranges[conn_idx];
    p_hdl->cli_cnfg_desc_hdl = gs_meas_cli_cnfg_desc_hdls[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Body Sensor Location Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Body Sensor Location characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_body_sensor_location_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

/* Body Sensor Location characteristic definition */
const st_ble_servc_char_info_t gs_body_sensor_location_char = {
    .uuid_16      = BLE_HRC_BODY_SENSOR_LOCATION_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(uint8_t),
    .db_size      = BLE_HRC_BODY_SENSOR_LOCATION_LEN,
    .char_idx     = BLE_HRC_BODY_SENSOR_LOCATION_IDX,
    .p_attr_hdls  = gs_body_sensor_location_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_uint8_t,
    .encode       = (ble_servc_attr_encode_t)encode_uint8_t,
};

ble_status_t R_BLE_HRC_ReadBodySensorLocation(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_body_sensor_location_char, conn_hdl);
}

void R_BLE_HRC_GetBodySensorLocationAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_hrc_body_sensor_location_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_body_sensor_location_char_ranges[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Heart Rate Control Point Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Heart Rate Control Point characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_heart_rate_cp_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

/* Heart Rate Control Point characteristic definition */
const st_ble_servc_char_info_t gs_heart_rate_cp_char = {
    .uuid_16      = BLE_HRC_HEART_RATE_CP_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(uint8_t),
    .db_size      = BLE_HRC_HEART_RATE_CP_LEN,
    .char_idx     = BLE_HRC_HEART_RATE_CP_IDX,
    .p_attr_hdls  = gs_heart_rate_cp_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_uint8_t,
    .encode       = (ble_servc_attr_encode_t)encode_uint8_t,
};

ble_status_t R_BLE_HRC_WriteHeartRateCp(uint16_t conn_hdl, const uint8_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteChar(&gs_heart_rate_cp_char, conn_hdl, p_value);
}

void R_BLE_HRC_GetHeartRateCpAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_hrc_heart_rate_cp_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_heart_rate_cp_char_ranges[conn_idx];
}


/*----------------------------------------------------------------------------------------------------------------------
    Heart Rate client
----------------------------------------------------------------------------------------------------------------------*/

/* Heart Rate client attribute handles */
static st_ble_gatt_hdl_range_t gs_hrc_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

const st_ble_servc_char_info_t *gspp_hrc_chars[] = {
    &gs_meas_char,
    &gs_body_sensor_location_char,
    &gs_heart_rate_cp_char,
};

static st_ble_servc_info_t gs_client_info = {
    .pp_chars     = gspp_hrc_chars,
    .num_of_chars = ARRAY_SIZE(gspp_hrc_chars),
    .p_attr_hdls  = gs_hrc_ranges,
};

ble_status_t R_BLE_HRC_Init(ble_servc_app_cb_t cb) // @suppress("API function naming")
{
    if (NULL == cb)
    {
        return BLE_ERR_INVALID_PTR;
    }

    gs_client_info.cb = cb;

    return R_BLE_SERVC_RegisterClient(&gs_client_info);
}

void R_BLE_HRC_ServDiscCb(uint16_t conn_hdl, uint8_t serv_idx, uint16_t type, void *p_param) // @suppress("API function naming")
{
    R_BLE_SERVC_ServDiscCb(&gs_client_info, conn_hdl, serv_idx, type, p_param);
}

void R_BLE_HRC_GetServAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_gatt_hdl_range_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    *p_hdl = gs_hrc_ranges[conn_idx];
}
