/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_hrc.h
 * Version : 1.0
 * Description : The header file for Heart Rate client.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 31.12.2999 1.00 First Release
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @file
 * @defgroup hrc Heart Rate Service Client
 * @{
 * @ingroup profile
 * @brief   This is the client for the Heart Rate Service.
 **********************************************************************************************************************/

#include "profile_cmn/r_ble_servc_if.h"

#ifndef R_BLE_HRC_H
#define R_BLE_HRC_H

/*----------------------------------------------------------------------------------------------------------------------
    Heart Rate Measurement Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_HRC_MEAS_UUID (0x2A37)
#define BLE_HRC_MEAS_LEN (20)
#define BLE_HRC_MEAS_CLI_CNFG_UUID (0x2902)
#define BLE_HRC_MEAS_CLI_CNFG_LEN (2)
      
/***************************************************************************//**
 * @brief Heart Rate Measurement Flags value structure.
*******************************************************************************/
typedef struct {
    bool is_heart_rate_value_16_bit; /**< Heart Rate Value Format bit */
    bool is_sensor_contact_feature_supported; /**< Sensor Contact Feature Supported */
    bool is_sensor_contact_detected; /**< Sensor Contact Detected */
    bool is_energy_expended_included; /**< Energy Expended Status bit */
    bool is_rr_interval_included; /**< RR-Interval bit */
} st_ble_hrc_meas_flags_t;

/***************************************************************************//**
 * @brief Heart Rate Measurement value structure.
*******************************************************************************/
typedef struct {
    st_ble_hrc_meas_flags_t flags; /**< Flags */
    uint16_t heart_rate_measurement_value; /**< Heart Rate Measurement Value */
    uint16_t energy_expended;
    uint16_t rr_interval[9]; /**< RR-Interval */
    uint8_t number_of_rr_interval; /**< Number of RR-Interval */
} st_ble_hrc_meas_t;

/***************************************************************************//**
 * @brief Heart Rate Measurement attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
    uint16_t cli_cnfg_desc_hdl;
} st_ble_hrc_meas_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Heart Rate Measurement characteristic Client Characteristic Configuration descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_HRC_ReadMeasCliCnfg(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Heart Rate Measurement characteristic Client Characteristic Configuration descriptor value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value Heart Rate Measurement characteristic Client Characteristic Configuration descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_HRC_WriteMeasCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief      Get Heart Rate Measurement attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_HRC_GetMeasAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_hrc_meas_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Body Sensor Location Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_HRC_BODY_SENSOR_LOCATION_UUID (0x2A38)
#define BLE_HRC_BODY_SENSOR_LOCATION_LEN (1)
/***************************************************************************//**
 * @brief Body Sensor Location Body Sensor Location enumeration.
*******************************************************************************/
typedef enum {
    BLE_HRC_BODY_SENSOR_LOCATION_BODY_SENSOR_LOCATION_OTHER = 0, /**< Other */
    BLE_HRC_BODY_SENSOR_LOCATION_BODY_SENSOR_LOCATION_CHEST = 1, /**< Chest */
    BLE_HRC_BODY_SENSOR_LOCATION_BODY_SENSOR_LOCATION_WRIST = 2, /**< Wrist */
    BLE_HRC_BODY_SENSOR_LOCATION_BODY_SENSOR_LOCATION_FINGER = 3, /**< Finger */
    BLE_HRC_BODY_SENSOR_LOCATION_BODY_SENSOR_LOCATION_HAND = 4, /**< Hand */
    BLE_HRC_BODY_SENSOR_LOCATION_BODY_SENSOR_LOCATION_EAR_LOBE = 5, /**< Ear Lobe */
    BLE_HRC_BODY_SENSOR_LOCATION_BODY_SENSOR_LOCATION_FOOT = 6, /**< Foot */
} e_ble_hrc_body_sensor_location_body_sensor_location_t;

/***************************************************************************//**
 * @brief Body Sensor Location attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
} st_ble_hrc_body_sensor_location_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Body Sensor Location characteristic value from the remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_HRC_ReadBodySensorLocation(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief      Get Body Sensor Location attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_HRC_GetBodySensorLocationAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_hrc_body_sensor_location_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Heart Rate Control Point Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_HRC_HEART_RATE_CP_UUID (0x2A39)
#define BLE_HRC_HEART_RATE_CP_LEN (1)
/***************************************************************************//**
 * @brief Heart Rate Control Point Heart Rate Control Point enumeration.
*******************************************************************************/
typedef enum {
    BLE_HRC_HEART_RATE_CP_HEART_RATE_CONTROL_POINT_RESET_ENERGY_EXPENDED = 1, /**< Reset Energy Expended: resets the value of the Energy Expended field in the Heart Rate Measurement characteristic to 0 */
} e_ble_hrc_heart_rate_cp_heart_rate_control_point_t;

/***************************************************************************//**
 * @brief Heart Rate Control Point attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
} st_ble_hrc_heart_rate_cp_attr_hdl_t;

/***************************************************************************//**
 * @brief     Write Heart Rate Control Point characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] p_value Heart Rate Control Point characteristic value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_HRC_WriteHeartRateCp(uint16_t conn_hdl, const uint8_t *p_value);
;
/***************************************************************************//**
 * @brief      Get Heart Rate Control Point attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_HRC_GetHeartRateCpAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_hrc_heart_rate_cp_attr_hdl_t *p_hdl);


/*----------------------------------------------------------------------------------------------------------------------
    Heart Rate Client
----------------------------------------------------------------------------------------------------------------------*/

/***************************************************************************//**
 * @brief Heart Rate Control Point Not Supported
*******************************************************************************/
#define BLE_HRC_HEART_RATE_CONTROL_POINT_NOT_SUPPORTED_ERROR (BLE_ERR_GROUP_GATT | 0x80)

/***************************************************************************//**
 * @brief Heart Rate client event data.
*******************************************************************************/
typedef struct {
    uint16_t    conn_hdl;  /**< Connection handle */
    uint16_t    param_len; /**< Event parameter length */
    const void *p_param;   /**< Event parameter */
} st_ble_hrc_evt_data_t;

/***************************************************************************//**
 * @brief Heart Rate characteristic ID.
*******************************************************************************/
typedef enum {
    BLE_HRC_MEAS_IDX,
    BLE_HRC_MEAS_CLI_CNFG_IDX,
    BLE_HRC_BODY_SENSOR_LOCATION_IDX,
    BLE_HRC_HEART_RATE_CP_IDX,
} e_ble_hrc_char_idx_t;

/***************************************************************************//**
 * @brief Heart Rate client event type.
*******************************************************************************/
typedef enum {
    /* Heart Rate Measurement */
    BLE_HRC_EVENT_MEAS_HDL_VAL_NTF = BLE_SERVC_ATTR_EVENT(BLE_HRC_MEAS_IDX, BLE_SERVC_HDL_VAL_NTF),
    BLE_HRC_EVENT_MEAS_CLI_CNFG_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_HRC_MEAS_CLI_CNFG_IDX, BLE_SERVC_READ_RSP),
    BLE_HRC_EVENT_MEAS_CLI_CNFG_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_HRC_MEAS_CLI_CNFG_IDX, BLE_SERVC_WRITE_RSP),
    /* Body Sensor Location */
    BLE_HRC_EVENT_BODY_SENSOR_LOCATION_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_HRC_BODY_SENSOR_LOCATION_IDX, BLE_SERVC_READ_RSP),
    /* Heart Rate Control Point */
    BLE_HRC_EVENT_HEART_RATE_CP_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_HRC_HEART_RATE_CP_IDX, BLE_SERVC_WRITE_RSP),
} e_ble_hrc_event_t;

/***************************************************************************//**
 * @brief     Initialize Heart Rate client.
 * @param[in] cb Client callback.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_HRC_Init(ble_servc_app_cb_t cb);

/***************************************************************************//**
 * @brief     Heart Rate client discovery callback.
 * @param[in] conn_hdl Connection handle
 * @param[in] serv_idx Service instance index.
 * @param[in] type     Service discovery event type.
 * @param[in] p_param  Service discovery event parameter.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_HRC_ServDiscCb(uint16_t conn_hdl, uint8_t serv_idx, uint16_t type, void *p_param);

/***************************************************************************//**
 * @brief     Get Heart Rate client attribute handle.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
*******************************************************************************/
void R_BLE_HRC_GetServAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_gatt_hdl_range_t *p_hdl);

#endif /* R_BLE_HRC_H */

/** @} */
