/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_aios.h
 * Version : 1.0
 * Description : The header file for Automation IO service.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 05.06.2019 1.00 First Release
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @file
 * @defgroup aios Automation IO Service Server
 * @{
 * @ingroup profile
 * @brief   The Automation IO service is used to expose the analog inputs/outputs and digital input/outputs of a generic IO module (IOM).
 **********************************************************************************************************************/
#include "profile_cmn/r_ble_servs_if.h"
#include "gatt_db.h"

#ifndef R_BLE_AIOS_H
#define R_BLE_AIOS_H

/*----------------------------------------------------------------------------------------------------------------------
    Digital 0 Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/***************************************************************************//**
 * @brief Characteristic Presentation Format Format enumeration.
*******************************************************************************/
typedef enum {
    BLE_AIOS_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_BOOLEAN = 1, /**< Boolean */
    BLE_AIOS_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_2_BIT_INTEGER = 2, /**< unsigned 2-bit integer */
    BLE_AIOS_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_4_BIT_INTEGER = 3, /**< unsigned 4-bit integer */
    BLE_AIOS_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_8_BIT_INTEGER = 4, /**< unsigned 8-bit integer */
    BLE_AIOS_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_12_BIT_INTEGER = 5, /**< unsigned 12-bit integer */
    BLE_AIOS_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_16_BIT_INTEGER = 6, /**< unsigned 16-bit integer */
    BLE_AIOS_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_24_BIT_INTEGER = 7, /**< unsigned 24-bit integer */
    BLE_AIOS_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_32_BIT_INTEGER = 8, /**< unsigned 32-bit integer */
    BLE_AIOS_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_48_BIT_INTEGER = 9, /**< unsigned 48-bit integer */
    BLE_AIOS_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_64_BIT_INTEGER = 10, /**< unsigned 64-bit integer */
    BLE_AIOS_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_128_BIT_INTEGER = 11, /**< unsigned 128-bit integer */
    BLE_AIOS_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_8_BIT_INTEGER = 12, /**< signed 8-bit integer */
    BLE_AIOS_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_12_BIT_INTEGER = 13, /**< signed 12-bit integer */
    BLE_AIOS_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_16_BIT_INTEGER = 14, /**< signed 16-bit integer */
    BLE_AIOS_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_24_BIT_INTEGER = 15, /**< signed 24-bit integer */
    BLE_AIOS_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_32_BIT_INTEGER = 16, /**< signed 32-bit integer */
    BLE_AIOS_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_48_BIT_INTEGER = 17, /**< signed 48-bit integer */
    BLE_AIOS_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_64_BIT_INTEGER = 18, /**< signed 64-bit integer */
    BLE_AIOS_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_128_BIT_INTEGER = 19, /**< signed 128-bit integer */
    BLE_AIOS_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_IEEE_754_32_BIT_FLOATING_POINT = 20, /**< IEEE-754 32-bit floating point */
    BLE_AIOS_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_IEEE_754_64_BIT_FLOATING_POINT = 21, /**< IEEE-754 64-bit floating point */
    BLE_AIOS_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_IEEE_11073_16_BIT_SFLOAT = 22, /**< IEEE-11073 16-bit SFLOAT */
    BLE_AIOS_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_IEEE_11073_32_BIT_FLOAT = 23, /**< IEEE-11073 32-bit FLOAT */
    BLE_AIOS_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_IEEE_20601_FORMAT = 24, /**< IEEE-20601 format */
    BLE_AIOS_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_UTF_8_STRING = 25, /**< UTF-8 string */
    BLE_AIOS_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_UTF_16_STRING = 26, /**< UTF-16 string */
    BLE_AIOS_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_OPAQUE_STRUCTURE = 27, /**< Opaque Structure */
} e_ble_aios_digital_0_char_presentation_format_format_t;

/*******************************************************************************************************************//**
* @brief Value Trigger Setting value condition structure.
***********************************************************************************************************************/
typedef enum
{
    BLE_AIOS_VALUE_TRIGGER_SETTING_CONDITION_CHARACTERISTIC_VALUE_CHANGED = 0X00,/* Characteristic value is changed */
    BLE_AIOS_VALUE_TRIGGER_SETTING_CONDITION_CROSSED_A_BOUNDRY,/* Crossed a boundary */
    BLE_AIOS_VALUE_TRIGGER_SETTING_CONDITION_ON_THE_BOUNDRY,/* On the boundary. */
    BLE_AIOS_VALUE_TRIGGER_SETTING_CONDITION_VALUE_CHANGED_MORE_THAN_SETTABLE,/* Value changed more than settable */
    BLE_AIOS_VALUE_TRIGGER_SETTING_CONDITION_MASK_THEN_COMPARE,/* Mask then compare */
    BLE_AIOS_VALUE_TRIGGER_SETTING_CONDITION_INSIDE_AND_OUTSIDE_THE_BOUNDRIES,/* Inside or outside the boundries */
    BLE_AIOS_VALUE_TRIGGER_SETTING_CONDITION_ON_THE_BOUNDRIES,/* On the Boundries */
    BLE_AIOS_VALUE_TRIGGER_SETTING_CONDITION_NO_VALUE_TRIGGER,/* No value trigger */
} e_ble_aios_value_trigger_setting_condition_t;

/*******************************************************************************************************************//**
* @brief Time Trigger Setting value condition structure.
***********************************************************************************************************************/
typedef enum
{
    BLE_AIOS_TIME_TRIGGER_NO_TIME_BASED_TRIGGERING = 0X00,/* No time-based triggering used. */
    BLE_AIOS_TIME_TRIGGER_INDICATES_OR_NOTIFIES_UNCONDITIONALLY,/* Indicates or notifies unconditionally after a settable time */
    BLE_AIOS_TIME_TRIGGER_NOT_INDICATES_OR_NOTIFIES_OFTEN,/* Not indicated or notified more often than a settable time */
    BLE_AIOS_TIME_TRIGGER_CHANGED_MORE_OFTEN,/* Changed more often */
} e_ble_aios_time_trigger_setting_condition_t;

/***************************************************************************//**
 * @brief Characteristic Presentation Format Namespace enumeration.
*******************************************************************************/
typedef enum {
    BLE_AIOS_DIGITAL_0_CHAR_PRESENTATION_FORMAT_NAMESPACE_BLUETOOTH_SIG_ASSIGNED_NUMBERS = 1, /**< Bluetooth SIG Assigned Numbers */
} e_ble_aios_char_presentation_format_namespace_t;

/***************************************************************************//**
 * @brief Characteristic Presentation Format value structure.
*******************************************************************************/
typedef struct {
    uint8_t format; /**< Format */
    int8_t exponent; /**< Exponent */
    uint16_t unit; /**< Unit */
    uint8_t name_space; /**< Namespace */
    uint16_t description; /**< Description */
} st_ble_aios_digital_0_char_presentation_format_t;

/***************************************************************************//**
 * @brief Value Trigger Setting value structure.
*******************************************************************************/
typedef struct {
    uint8_t condition; /**< Condition */
    uint16_t bit_mask_value; /**< Value (Bit Mask) */
} st_ble_aios_digital_0_val_trigger_setting_t;

/***************************************************************************//**
 * @brief Time Trigger Setting value structure.
*******************************************************************************/
typedef struct {
    uint8_t condition; /**< Condition */
    uint8_t value__none_; /**< Value (None) */
    uint32_t time_interval_value; /**< Value Time Interval */
    uint16_t count_value; /**< Value Count */
} st_ble_aios_digital_0_time_trigger_setting_t;


/***************************************************************************//**
 * @brief Digital 0 Digital 0 enumeration.
*******************************************************************************/
typedef enum {
    BLE_AIOS_DIGITAL_0_DIGITAL_0_INACTIVE = 0, /**< Inactive */
    BLE_AIOS_DIGITAL_0_DIGITAL_0_ACTIVE = 1, /**< Active */
    BLE_AIOS_DIGITAL_0_DIGITAL_0_TRI_STATE = 2, /**< Tri-state */
    BLE_AIOS_DIGITAL_0_DIGITAL_0_OUTPUT_STATE = 3, /**< Output-state */
} e_ble_aios_digital_0_digital_0_t;

/***************************************************************************//**
 * @brief     Set Digital 0 characteristic value to the local GATT database.
 * @param[in] p_value - Pointer to Characteristic value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_SetDigital0(const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Get Digital 0 characteristic value from the local GATT database.
 * @param[out] p_value  Pointer to Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_GetDigital0(uint16_t *p_value);

/***************************************************************************//**
 * @brief     Send notification of  Digital 0 characteristic value to the remote device.
 * @param[in] conn_hdl - Connection handle.
 * @param[in] p_value  - Pointer to Characteristic value to send.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_NotifyDigital0(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Set Digital 0 cli cnfg descriptor value to the local GATT database.
 * @param[in] p_value - Pointer to Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_SetDigital0CliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Get Digital 0 cli cnfg descriptor value from the local GATT database.
 * @param[out] p_value  Pointer to Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_GetDigital0CliCnfg(uint16_t conn_hdl, uint16_t *p_value);

/***************************************************************************//**
 * @brief     Set Digital 0 char presentation format descriptor value to the local GATT database.
 * @param[in] p_value - Pointer to Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_SetDigital0CharPresentationFormat(const st_ble_aios_digital_0_char_presentation_format_t *p_value);

/***************************************************************************//**
 * @brief     Get Digital 0 char presentation format descriptor value from the local GATT database.
 * @param[out] p_value  Pointer to Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_GetDigital0CharPresentationFormat(st_ble_aios_digital_0_char_presentation_format_t *p_value);

/***************************************************************************//**
 * @brief     Set Digital 0 char user description descriptor value to the local GATT database.
 * @param[in] p_value - Pointer to Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_SetDigital0CharUserDescription(const uint8_t *p_value);

/***************************************************************************//**
 * @brief     Get Digital 0 char user description descriptor value from the local GATT database.
 * @param[out] p_value  Pointer to Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_GetDigital0CharUserDescription(uint8_t *p_value);

/***************************************************************************//**
 * @brief     Set Digital 0 char extended properties descriptor value to the local GATT database.
 * @param[in] p_value - Pointer to Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_SetDigital0CharExtendedProperties(const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Get Digital 0 char extended properties descriptor value from the local GATT database.
 * @param[out] p_value  Pointer to Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_GetDigital0CharExtendedProperties(uint16_t *p_value);

/***************************************************************************//**
 * @brief     Set Digital 0 val trigger setting descriptor value to the local GATT database.
 * @param[in] p_value - Pointer to Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_SetDigital0ValTriggerSetting(const st_ble_aios_digital_0_val_trigger_setting_t *p_value);

/***************************************************************************//**
 * @brief     Get Digital 0 val trigger setting descriptor value from the local GATT database.
 * @param[out] p_value  Pointer to Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_GetDigital0ValTriggerSetting(st_ble_aios_digital_0_val_trigger_setting_t *p_value);

/***************************************************************************//**
 * @brief     Set Digital 0 time trigger setting descriptor value to the local GATT database.
 * @param[in] p_value - Pointer to Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_SetDigital0TimeTriggerSetting(const st_ble_aios_digital_0_time_trigger_setting_t *p_value);

/***************************************************************************//**
 * @brief     Get Digital 0 time trigger setting descriptor value from the local GATT database.
 * @param[out] p_value  Pointer to Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_GetDigital0TimeTriggerSetting(st_ble_aios_digital_0_time_trigger_setting_t *p_value);

/***************************************************************************//**
 * @brief     Set Digital 0 num of digitals descriptor value to the local GATT database.
 * @param[in] p_value - Pointer to Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_SetDigital0NumOfDigitals(const uint8_t *p_value);

/***************************************************************************//**
 * @brief     Get Digital 0 num of digitals descriptor value from the local GATT database.
 * @param[out] p_value  Pointer to Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_GetDigital0NumOfDigitals(uint8_t *p_value);

/*----------------------------------------------------------------------------------------------------------------------
    Digital 1 Characteristic
----------------------------------------------------------------------------------------------------------------------*/


/***************************************************************************//**
 * @brief Characteristic Presentation Format Format enumeration.
*******************************************************************************/
typedef enum {
    BLE_AIOS_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_BOOLEAN = 1, /**< Boolean */
    BLE_AIOS_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_2_BIT_INTEGER = 2, /**< unsigned 2-bit integer */
    BLE_AIOS_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_4_BIT_INTEGER = 3, /**< unsigned 4-bit integer */
    BLE_AIOS_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_8_BIT_INTEGER = 4, /**< unsigned 8-bit integer */
    BLE_AIOS_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_12_BIT_INTEGER = 5, /**< unsigned 12-bit integer */
    BLE_AIOS_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_16_BIT_INTEGER = 6, /**< unsigned 16-bit integer */
    BLE_AIOS_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_24_BIT_INTEGER = 7, /**< unsigned 24-bit integer */
    BLE_AIOS_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_32_BIT_INTEGER = 8, /**< unsigned 32-bit integer */
    BLE_AIOS_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_48_BIT_INTEGER = 9, /**< unsigned 48-bit integer */
    BLE_AIOS_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_64_BIT_INTEGER = 10, /**< unsigned 64-bit integer */
    BLE_AIOS_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_128_BIT_INTEGER = 11, /**< unsigned 128-bit integer */
    BLE_AIOS_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_8_BIT_INTEGER = 12, /**< signed 8-bit integer */
    BLE_AIOS_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_12_BIT_INTEGER = 13, /**< signed 12-bit integer */
    BLE_AIOS_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_16_BIT_INTEGER = 14, /**< signed 16-bit integer */
    BLE_AIOS_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_24_BIT_INTEGER = 15, /**< signed 24-bit integer */
    BLE_AIOS_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_32_BIT_INTEGER = 16, /**< signed 32-bit integer */
    BLE_AIOS_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_48_BIT_INTEGER = 17, /**< signed 48-bit integer */
    BLE_AIOS_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_64_BIT_INTEGER = 18, /**< signed 64-bit integer */
    BLE_AIOS_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_128_BIT_INTEGER = 19, /**< signed 128-bit integer */
    BLE_AIOS_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_IEEE_754_32_BIT_FLOATING_POINT = 20, /**< IEEE-754 32-bit floating point */
    BLE_AIOS_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_IEEE_754_64_BIT_FLOATING_POINT = 21, /**< IEEE-754 64-bit floating point */
    BLE_AIOS_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_IEEE_11073_16_BIT_SFLOAT = 22, /**< IEEE-11073 16-bit SFLOAT */
    BLE_AIOS_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_IEEE_11073_32_BIT_FLOAT = 23, /**< IEEE-11073 32-bit FLOAT */
    BLE_AIOS_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_IEEE_20601_FORMAT = 24, /**< IEEE-20601 format */
    BLE_AIOS_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_UTF_8_STRING = 25, /**< UTF-8 string */
    BLE_AIOS_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_UTF_16_STRING = 26, /**< UTF-16 string */
    BLE_AIOS_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_OPAQUE_STRUCTURE = 27, /**< Opaque Structure */
} e_ble_aios_digital_1_char_presentation_format_format_t;

/***************************************************************************//**
 * @brief Characteristic Presentation Format Namespace enumeration.
*******************************************************************************/
typedef enum {
    BLE_AIOS_DIGITAL_1_CHAR_PRESENTATION_FORMAT_NAMESPACE_BLUETOOTH_SIG_ASSIGNED_NUMBERS = 1, /**< Bluetooth SIG Assigned Numbers */
} e_ble_aios_digital_1_char_presentation_format_namespace_t;

/***************************************************************************//**
 * @brief Characteristic Presentation Format value structure.
*******************************************************************************/
typedef struct {
    uint8_t format; /**< Format */
    int8_t exponent; /**< Exponent */
    uint16_t unit; /**< Unit */
    uint8_t name_space; /**< Namespace */
    uint16_t description; /**< Description */
} st_ble_aios_digital_1_char_presentation_format_t;


/***************************************************************************//**
 * @brief Value Trigger Setting value structure.
*******************************************************************************/
typedef struct {
    uint8_t condition; /**< Condition */
    uint16_t bit_mask_value; /**< Value (Bit Mask) */
} st_ble_aios_digital_1_val_trigger_setting_t;


/***************************************************************************//**
 * @brief Time Trigger Setting value structure.
*******************************************************************************/
typedef struct {
    uint8_t condition; /**< Condition */
    uint8_t value__none_; /**< Value (None) */
    uint32_t time_interval_value; /**< Value Time Interval */
    uint16_t count_value; /**< Value Count */
} st_ble_aios_digital_1_time_trigger_setting_t;


/***************************************************************************//**
 * @brief Digital 1 Digital 1 enumeration.
*******************************************************************************/
typedef enum {
    BLE_AIOS_DIGITAL_1_DIGITAL_1_INACTIVE = 0, /**< Inactive */
    BLE_AIOS_DIGITAL_1_DIGITAL_1_ACTIVE = 1, /**< Active */
    BLE_AIOS_DIGITAL_1_DIGITAL_1_TRI_STATE = 2, /**< Tri-state */
    BLE_AIOS_DIGITAL_1_DIGITAL_1_OUTPUT_STATE = 3, /**< Output-state */
} e_ble_aios_digital_1_digital_1_t;

/***************************************************************************//**
 * @brief     Set Digital 1 characteristic value to the local GATT database.
 * @param[in] p_value - Pointer to Characteristic value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_SetDigital1(const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Get Digital 1 characteristic value from the local GATT database.
 * @param[out] p_value  Pointer to Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_GetDigital1(uint16_t *p_value);

/***************************************************************************//**
 * @brief     Send notification of  Digital 1 characteristic value to the remote device.
 * @param[in] conn_hdl - Connection handle.
 * @param[in] p_value  - Pointer to Characteristic value to send.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_NotifyDigital1(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Set Digital 1 cli cnfg descriptor value to the local GATT database.
 * @param[in] p_value - Pointer to Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_SetDigital1CliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Get Digital 1 cli cnfg descriptor value from the local GATT database.
 * @param[out] p_value  Pointer to Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_GetDigital1CliCnfg(uint16_t conn_hdl, uint16_t *p_value);

/***************************************************************************//**
 * @brief     Set Digital 1 char presentation format descriptor value to the local GATT database.
 * @param[in] p_value - Pointer to Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_SetDigital1CharPresentationFormat(const st_ble_aios_digital_1_char_presentation_format_t *p_value);

/***************************************************************************//**
 * @brief     Get Digital 1 char presentation format descriptor value from the local GATT database.
 * @param[out] p_value  Pointer to Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_GetDigital1CharPresentationFormat(st_ble_aios_digital_1_char_presentation_format_t *p_value);

/***************************************************************************//**
 * @brief     Set Digital 1 char user description descriptor value to the local GATT database.
 * @param[in] p_value - Pointer to Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_SetDigital1CharUserDescription(const uint8_t *p_value);

/***************************************************************************//**
 * @brief     Get Digital 1 char user description descriptor value from the local GATT database.
 * @param[out] p_value  Pointer to Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_GetDigital1CharUserDescription(uint8_t *p_value);

/***************************************************************************//**
 * @brief     Set Digital 1 char extended properties descriptor value to the local GATT database.
 * @param[in] p_value - Pointer to Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_SetDigital1CharExtendedProperties(const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Get Digital 1 char extended properties descriptor value from the local GATT database.
 * @param[out] p_value  Pointer to Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_GetDigital1CharExtendedProperties(uint16_t *p_value);

/***************************************************************************//**
 * @brief     Set Digital 1 val trigger setting descriptor value to the local GATT database.
 * @param[in] p_value - Pointer to Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_SetDigital1ValTriggerSetting(const st_ble_aios_digital_1_val_trigger_setting_t *p_value);

/***************************************************************************//**
 * @brief     Get Digital 1 val trigger setting descriptor value from the local GATT database.
 * @param[out] p_value  Pointer to Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_GetDigital1ValTriggerSetting(st_ble_aios_digital_1_val_trigger_setting_t *p_value);

/***************************************************************************//**
 * @brief     Set Digital 1 time trigger setting descriptor value to the local GATT database.
 * @param[in] p_value - Pointer to Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_SetDigital1TimeTriggerSetting(const st_ble_aios_digital_1_time_trigger_setting_t *p_value);

/***************************************************************************//**
 * @brief     Get Digital 1 time trigger setting descriptor value from the local GATT database.
 * @param[out] p_value  Pointer to Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_GetDigital1TimeTriggerSetting(st_ble_aios_digital_1_time_trigger_setting_t *p_value);

/***************************************************************************//**
 * @brief     Set Digital 1 num of digitals descriptor value to the local GATT database.
 * @param[in] p_value - Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_SetDigital1NumOfDigitals(const uint8_t *p_value);

/***************************************************************************//**
 * @brief     Get Digital 1 num of digitals descriptor value from the local GATT database.
 * @param[out] p_value  Pointer to Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_GetDigital1NumOfDigitals(uint8_t *p_value);

/*----------------------------------------------------------------------------------------------------------------------
    Analog 0 Characteristic
----------------------------------------------------------------------------------------------------------------------*/


/***************************************************************************//**
 * @brief Characteristic Presentation Format Format enumeration.
*******************************************************************************/
typedef enum {
    BLE_AIOS_ANALOG_0_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_8_BIT_INTEGER = 1, /**< unsigned 8-bit integer */
    BLE_AIOS_ANALOG_0_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_12_BIT_INTEGER = 2, /**< unsigned 12-bit integer */
    BLE_AIOS_ANALOG_0_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_16_BIT_INTEGER = 3, /**< unsigned 16-bit integer */
    BLE_AIOS_ANALOG_0_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_8_BIT_INTEGER = 4, /**< signed 8-bit integer */
    BLE_AIOS_ANALOG_0_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_12_BIT_INTEGER = 5, /**< signed 12-bit integer */
    BLE_AIOS_ANALOG_0_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_16_BIT_INTEGER = 6, /**< signed 16-bit integer */
    BLE_AIOS_ANALOG_0_CHAR_PRESENTATION_FORMAT_FORMAT_IEEE_11073_16_BIT_SFLOAT = 7, /**< IEEE-11073 16-bit SFLOAT */
    BLE_AIOS_ANALOG_0_CHAR_PRESENTATION_FORMAT_FORMAT_UTF_16_STRING = 8, /**< UTF-16 string */
} e_ble_aios_analog_0_char_presentation_format_format_t;

/***************************************************************************//**
 * @brief Characteristic Presentation Format Namespace enumeration.
*******************************************************************************/
typedef enum {
    BLE_AIOS_ANALOG_0_CHAR_PRESENTATION_FORMAT_NAMESPACE_BLUETOOTH_SIG_ASSIGNED_NUMBERS = 1, /**< Bluetooth SIG Assigned Numbers */
} e_ble_aios_analog_0_char_presentation_format_namespace_t;

/***************************************************************************//**
 * @brief Characteristic Presentation Format value structure.
*******************************************************************************/
typedef struct {
    uint8_t format; /**< Format */
    int8_t exponent; /**< Exponent */
    uint16_t unit; /**< Unit */
    uint8_t name_space; /**< Namespace */
    uint16_t description; /**< Description */
} st_ble_aios_analog_0_char_presentation_format_t;

/***************************************************************************//**
 * @brief Value Trigger Setting value structure.
*******************************************************************************/
typedef struct {
    uint8_t condition; /**< Condition */
    int16_t analog_value; /**< Value Analog */
    int16_t analog_interval_value1; /**< Value Analog Interval */
    int16_t analog_interval_value2; /**< Value Analog Interval */
} st_ble_aios_analog_0_val_trigger_setting_t;

/***************************************************************************//**
 * @brief Time Trigger Setting value structure.
*******************************************************************************/
typedef struct {
    uint8_t condition; /**< Condition */
    uint8_t none; /**< Value (None) */
    uint32_t time_interval_value; /**< Value (Time Interval) */
    uint16_t count_value; /**< Value (Count) */
} st_ble_aios_analog_0_time_trigger_setting_t;

/***************************************************************************//**
 * @brief Valid Range value structure.
*******************************************************************************/
typedef struct {
    int16_t lower_inclusive_value; /**< Lower inclusive value */
    int16_t upper_inclusive_value; /**< Upper inclusive value */
} st_ble_aios_analog_0_valid_range_t;

/***************************************************************************//**
 * @brief     Set Analog 0 characteristic value to the local GATT database.
 * @param[in] p_value - Pointer to Characteristic value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_SetAnalog0(const int16_t *p_value);

/***************************************************************************//**
 * @brief     Get Analog 0 characteristic value from the local GATT database.
 * @param[out] p_value  Pointer to Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_GetAnalog0(int16_t *p_value);

/***************************************************************************//**
 * @brief     Send notification of  Analog 0 characteristic value to the remote device.
 * @param[in] conn_hdl - Connection handle.
 * @param[in] p_value  - Pointer to Characteristic value to send.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_NotifyAnalog0(uint16_t conn_hdl, const int16_t *p_value);

/***************************************************************************//**
 * @brief     Set Analog 0 cli cnfg descriptor value to the local GATT database.
 * @param[in] p_value - Pointer to Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_SetAnalog0CliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Get Analog 0 cli cnfg descriptor value from the local GATT database.
 * @param[out] p_value  Pointer to Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_GetAnalog0CliCnfg(uint16_t conn_hdl, uint16_t *p_value);

/***************************************************************************//**
 * @brief     Set Analog 0 char presentation format descriptor value to the local GATT database.
 * @param[in] p_value - Pointer to Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_SetAnalog0CharPresentationFormat(const st_ble_aios_analog_0_char_presentation_format_t *p_value);

/***************************************************************************//**
 * @brief     Get Analog 0 char presentation format descriptor value from the local GATT database.
 * @param[out] p_value  Pointer to Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_GetAnalog0CharPresentationFormat(st_ble_aios_analog_0_char_presentation_format_t *p_value);

/***************************************************************************//**
 * @brief     Set Analog 0 char user description descriptor value to the local GATT database.
 * @param[in] p_value - Pointer to Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_SetAnalog0CharUserDescription(const uint8_t *p_value);

/***************************************************************************//**
 * @brief     Get Analog 0 char user description descriptor value from the local GATT database.
 * @param[out] p_value  Pointer to Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_GetAnalog0CharUserDescription(uint8_t *p_value);

/***************************************************************************//**
 * @brief     Set Analog 0 char extended properties descriptor value to the local GATT database.
 * @param[in] p_value - Pointer to Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_SetAnalog0CharExtendedProperties(const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Get Analog 0 char extended properties descriptor value from the local GATT database.
 * @param[out] p_value  Pointer to Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_GetAnalog0CharExtendedProperties(uint16_t *p_value);

/***************************************************************************//**
 * @brief     Set Analog 0 val trigger setting descriptor value to the local GATT database.
 * @param[in] p_value - Pointer to Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_SetAnalog0ValTriggerSetting(const st_ble_aios_analog_0_val_trigger_setting_t *p_value);

/***************************************************************************//**
 * @brief     Get Analog 0 val trigger setting descriptor value from the local GATT database.
 * @param[out] p_value  Pointer to Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_GetAnalog0ValTriggerSetting(st_ble_aios_analog_0_val_trigger_setting_t *p_value);

/***************************************************************************//**
 * @brief     Set Analog 0 time trigger setting descriptor value to the local GATT database.
 * @param[in] p_value - Pointer to Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_SetAnalog0TimeTriggerSetting(const st_ble_aios_analog_0_time_trigger_setting_t *p_value);

/***************************************************************************//**
 * @brief     Get Analog 0 time trigger setting descriptor value from the local GATT database.
 * @param[out] p_value  Pointer to Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_GetAnalog0TimeTriggerSetting(st_ble_aios_analog_0_time_trigger_setting_t *p_value);

/***************************************************************************//**
 * @brief     Set Analog 0 valid range descriptor value to the local GATT database.
 * @param[in] p_value - Pointer to Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_SetAnalog0ValidRange(const st_ble_aios_analog_0_valid_range_t *p_value);

/***************************************************************************//**
 * @brief     Get Analog 0 valid range descriptor value from the local GATT database.
 * @param[out] p_value  Pointer to Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_GetAnalog0ValidRange(st_ble_aios_analog_0_valid_range_t *p_value);

/*----------------------------------------------------------------------------------------------------------------------
    Analog 1 Characteristic
----------------------------------------------------------------------------------------------------------------------*/
/***************************************************************************//**
 * @brief Characteristic Presentation Format Format enumeration.
*******************************************************************************/
typedef enum {
    BLE_AIOS_ANALOG_1_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_8_BIT_INTEGER = 1, /**< unsigned 8-bit integer */
    BLE_AIOS_ANALOG_1_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_12_BIT_INTEGER = 2, /**< unsigned 12-bit integer */
    BLE_AIOS_ANALOG_1_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_16_BIT_INTEGER = 3, /**< unsigned 16-bit integer */
    BLE_AIOS_ANALOG_1_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_8_BIT_INTEGER = 4, /**< signed 8-bit integer */
    BLE_AIOS_ANALOG_1_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_12_BIT_INTEGER = 5, /**< signed 12-bit integer */
    BLE_AIOS_ANALOG_1_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_16_BIT_INTEGER = 6, /**< signed 16-bit integer */
    BLE_AIOS_ANALOG_1_CHAR_PRESENTATION_FORMAT_FORMAT_IEEE_11073_16_BIT_SFLOAT = 7, /**< IEEE-11073 16-bit SFLOAT */
    BLE_AIOS_ANALOG_1_CHAR_PRESENTATION_FORMAT_FORMAT_UTF_16_STRING = 8, /**< UTF-16 string */
} e_ble_aios_analog_1_char_presentation_format_format_t;

/***************************************************************************//**
 * @brief Characteristic Presentation Format Namespace enumeration.
*******************************************************************************/
typedef enum {
    BLE_AIOS_ANALOG_1_CHAR_PRESENTATION_FORMAT_NAMESPACE_BLUETOOTH_SIG_ASSIGNED_NUMBERS = 1, /**< Bluetooth SIG Assigned Numbers */
} e_ble_aios_analog_1_char_presentation_format_namespace_t;

/***************************************************************************//**
 * @brief Characteristic Presentation Format value structure.
*******************************************************************************/
typedef struct {
    uint8_t format; /**< Format */
    int8_t exponent; /**< Exponent */
    uint16_t unit; /**< Unit */
    uint8_t name_space; /**< Namespace */
    uint16_t description; /**< Description */
} st_ble_aios_analog_1_char_presentation_format_t;

/***************************************************************************//**
 * @brief Value Trigger Setting value structure.
*******************************************************************************/
typedef struct {
    uint8_t condition; /**< Condition */
    int16_t analog_value; /**< Value Analog */
    int16_t analog_interval_value1; /**< Value Analog Interval */
    int16_t analog_interval_value2; /**< Value Analog Interval */
} st_ble_aios_analog_1_val_trigger_setting_t;

/***************************************************************************//**
 * @brief Time Trigger Setting value structure.
*******************************************************************************/
typedef struct {
    uint8_t condition; /**< Condition */
    uint8_t none; /**< Value (None) */
    uint32_t time_interval_value; /**< Value (Time Interval) */
    uint16_t count_value; /**< Value (Count) */
} st_ble_aios_analog_1_time_trigger_setting_t;

/***************************************************************************//**
 * @brief Valid Range value structure.
*******************************************************************************/
typedef struct {
    int16_t lower_inclusive_value; /**< Lower inclusive value */
    int16_t upper_inclusive_value; /**< Upper inclusive value */
} st_ble_aios_analog_1_valid_range_t;

/***************************************************************************//**
 * @brief     Set Analog 1 characteristic value to the local GATT database.
 * @param[in] p_value - Pointer to Characteristic value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_SetAnalog1(const int16_t *p_value);

/***************************************************************************//**
 * @brief     Get Analog 1 characteristic value from the local GATT database.
 * @param[out] p_value  Pointer to Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_GetAnalog1(int16_t *p_value);

/***************************************************************************//**
 * @brief     Send notification of  Analog 1 characteristic value to the remote device.
 * @param[in] conn_hdl - Connection handle.
 * @param[in] p_value  - Pointer to Characteristic value to send.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_NotifyAnalog1(uint16_t conn_hdl, const int16_t *p_value);

/***************************************************************************//**
 * @brief     Set Analog 1 cli cnfg descriptor value to the local GATT database.
 * @param[in] p_value - Pointer to Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_SetAnalog1CliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Get Analog 1 cli cnfg descriptor value from the local GATT database.
 * @param[out] p_value  Pointer to Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_GetAnalog1CliCnfg(uint16_t conn_hdl, uint16_t *p_value);

/***************************************************************************//**
 * @brief     Set Analog 1 char presentation format descriptor value to the local GATT database.
 * @param[in] p_value - Pointer to Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_SetAnalog1CharPresentationFormat(const st_ble_aios_analog_1_char_presentation_format_t *p_value);

/***************************************************************************//**
 * @brief     Get Analog 1 char presentation format descriptor value from the local GATT database.
 * @param[out] p_value  Pointer to Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_GetAnalog1CharPresentationFormat(st_ble_aios_analog_1_char_presentation_format_t *p_value);

/***************************************************************************//**
 * @brief     Set Analog 1 char user description descriptor value to the local GATT database.
 * @param[in] p_value - Pointer to Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_SetAnalog1CharUserDescription(const uint8_t *p_value);

/***************************************************************************//**
 * @brief     Get Analog 1 char user description descriptor value from the local GATT database.
 * @param[out] p_value  Pointer to Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_GetAnalog1CharUserDescription(uint8_t *p_value);

/***************************************************************************//**
 * @brief     Set Analog 1 char extended properties descriptor value to the local GATT database.
 * @param[in] p_value - Pointer to Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_SetAnalog1CharExtendedProperties(const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Get Analog 1 char extended properties descriptor value from the local GATT database.
 * @param[out] p_value  Pointer to Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_GetAnalog1CharExtendedProperties(uint16_t *p_value);

/***************************************************************************//**
 * @brief     Set Analog 1 val trigger setting descriptor value to the local GATT database.
 * @param[in] p_value - Pointer to Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_SetAnalog1ValTriggerSetting(const st_ble_aios_analog_1_val_trigger_setting_t *p_value);

/***************************************************************************//**
 * @brief     Get Analog 1 val trigger setting descriptor value from the local GATT database.
 * @param[out] p_value  Pointer to Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_GetAnalog1ValTriggerSetting(st_ble_aios_analog_1_val_trigger_setting_t *p_value);

/***************************************************************************//**
 * @brief     Set Analog 1 time trigger setting descriptor value to the local GATT database.
 * @param[in] p_value - Pointer to Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_SetAnalog1TimeTriggerSetting(const st_ble_aios_analog_1_time_trigger_setting_t *p_value);

/***************************************************************************//**
 * @brief     Get Analog 1 time trigger setting descriptor value from the local GATT database.
 * @param[out] p_value  Pointer to Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_GetAnalog1TimeTriggerSetting(st_ble_aios_analog_1_time_trigger_setting_t *p_value);

/***************************************************************************//**
 * @brief     Set Analog 1 valid range descriptor value to the local GATT database.
 * @param[in] p_value - Pointer to Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_SetAnalog1ValidRange(const st_ble_aios_analog_1_valid_range_t *p_value);

/***************************************************************************//**
 * @brief     Get Analog 1 valid range descriptor value from the local GATT database.
 * @param[out] p_value  Pointer to Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_GetAnalog1ValidRange(st_ble_aios_analog_1_valid_range_t *p_value);

/*----------------------------------------------------------------------------------------------------------------------
    Aggregate Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/***************************************************************************//**
 * @brief Aggregate value structure.
*******************************************************************************/
typedef struct {
    uint16_t input_bits0; /**< Input Bits */
    uint16_t input_bits1; /**< Input Bits */
    int16_t analog_input0; /**< Analog Input */
    int16_t analog_input1; /**< Analog Input */
} st_ble_aios_aggregate_t;

/***************************************************************************//**
 * @brief     Set Aggregate characteristic value to the local GATT database.
 * @param[in] p_value - Pointer to Characteristic value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_SetAggregate(const st_ble_aios_aggregate_t *p_value);

/***************************************************************************//**
 * @brief     Get Aggregate characteristic value from the local GATT database.
 * @param[out] p_value  Pointer to Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_GetAggregate(st_ble_aios_aggregate_t *p_value);

/***************************************************************************//**
 * @brief     Send notification of  Aggregate characteristic value to the remote device.
 * @param[in] conn_hdl - Connection handle.
 * @param[in] p_value  - Pointer to Characteristic value to send.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_NotifyAggregate(uint16_t conn_hdl, const st_ble_aios_aggregate_t *p_value);

/***************************************************************************//**
 * @brief     Set Aggregate cli cnfg descriptor value to the local GATT database.
 * @param[in] p_value - Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_SetAggregateCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Get Aggregate cli cnfg descriptor value from the local GATT database.
 * @param[out] p_value  Pointer to Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_GetAggregateCliCnfg(uint16_t conn_hdl, uint16_t *p_value);

/*----------------------------------------------------------------------------------------------------------------------
    Automation IO Service
----------------------------------------------------------------------------------------------------------------------*/
/***************************************************************************//**
 * @brief An attempt was made to configure a condition value not supported by this Automation IO Server
*******************************************************************************/
#define BLE_AIOS_TRIGGER_CONDITION_VALUE_NOT_SUPPORTED_ERROR (BLE_ERR_GROUP_GATT | 0x80)

/***************************************************************************//**
 * @brief Automation IO characteristic Index.
*******************************************************************************/
typedef enum {
    BLE_AIOS_DIGITAL_0_IDX,
    BLE_AIOS_DIGITAL_0_CLI_CNFG_IDX,
    BLE_AIOS_DIGITAL_0_CHAR_PRESENTATION_FORMAT_IDX,
    BLE_AIOS_DIGITAL_0_CHAR_USER_DESCRIPTION_IDX,
    BLE_AIOS_DIGITAL_0_CHAR_EXTENDED_PROPERTIES_IDX,
    BLE_AIOS_DIGITAL_0_VAL_TRIGGER_SETTING_IDX,
    BLE_AIOS_DIGITAL_0_TIME_TRIGGER_SETTING_IDX,
    BLE_AIOS_DIGITAL_0_NUM_OF_DIGITALS_IDX,
    BLE_AIOS_DIGITAL_1_IDX,
    BLE_AIOS_DIGITAL_1_CLI_CNFG_IDX,
    BLE_AIOS_DIGITAL_1_CHAR_PRESENTATION_FORMAT_IDX,
    BLE_AIOS_DIGITAL_1_CHAR_USER_DESCRIPTION_IDX,
    BLE_AIOS_DIGITAL_1_CHAR_EXTENDED_PROPERTIES_IDX,
    BLE_AIOS_DIGITAL_1_VAL_TRIGGER_SETTING_IDX,
    BLE_AIOS_DIGITAL_1_TIME_TRIGGER_SETTING_IDX,
    BLE_AIOS_DIGITAL_1_NUM_OF_DIGITALS_IDX,
    BLE_AIOS_ANALOG_0_IDX,
    BLE_AIOS_ANALOG_0_CLI_CNFG_IDX,
    BLE_AIOS_ANALOG_0_CHAR_PRESENTATION_FORMAT_IDX,
    BLE_AIOS_ANALOG_0_CHAR_USER_DESCRIPTION_IDX,
    BLE_AIOS_ANALOG_0_CHAR_EXTENDED_PROPERTIES_IDX,
    BLE_AIOS_ANALOG_0_VAL_TRIGGER_SETTING_IDX,
    BLE_AIOS_ANALOG_0_TIME_TRIGGER_SETTING_IDX,
    BLE_AIOS_ANALOG_0_VALID_RANGE_IDX,
    BLE_AIOS_ANALOG_1_IDX,
    BLE_AIOS_ANALOG_1_CLI_CNFG_IDX,
    BLE_AIOS_ANALOG_1_CHAR_PRESENTATION_FORMAT_IDX,
    BLE_AIOS_ANALOG_1_CHAR_USER_DESCRIPTION_IDX,
    BLE_AIOS_ANALOG_1_CHAR_EXTENDED_PROPERTIES_IDX,
    BLE_AIOS_ANALOG_1_VAL_TRIGGER_SETTING_IDX,
    BLE_AIOS_ANALOG_1_TIME_TRIGGER_SETTING_IDX,
    BLE_AIOS_ANALOG_1_VALID_RANGE_IDX,
    BLE_AIOS_AGGREGATE_IDX,
    BLE_AIOS_AGGREGATE_CLI_CNFG_IDX,
} e_ble_aios_char_idx_t;

/***************************************************************************//**
 * @brief Automation IO event type.
*******************************************************************************/
typedef enum {
    /* Digital 0 */
    BLE_AIOS_EVENT_DIGITAL_0_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_DIGITAL_0_IDX, BLE_SERVS_WRITE_REQ),
    BLE_AIOS_EVENT_DIGITAL_0_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_AIOS_DIGITAL_0_IDX, BLE_SERVS_WRITE_COMP),
    BLE_AIOS_EVENT_DIGITAL_0_WRITE_CMD = BLE_SERVS_ATTR_EVENT(BLE_AIOS_DIGITAL_0_IDX, BLE_SERVS_WRITE_CMD),
    BLE_AIOS_EVENT_DIGITAL_0_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_DIGITAL_0_IDX, BLE_SERVS_READ_REQ),
    BLE_AIOS_EVENT_DIGITAL_0_CLI_CNFG_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_DIGITAL_0_CLI_CNFG_IDX, BLE_SERVS_WRITE_REQ),
    BLE_AIOS_EVENT_DIGITAL_0_CLI_CNFG_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_AIOS_DIGITAL_0_CLI_CNFG_IDX, BLE_SERVS_WRITE_COMP),
    BLE_AIOS_EVENT_DIGITAL_0_CLI_CNFG_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_DIGITAL_0_CLI_CNFG_IDX, BLE_SERVS_READ_REQ),
    BLE_AIOS_EVENT_DIGITAL_0_CHAR_PRESENTATION_FORMAT_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_DIGITAL_0_CHAR_PRESENTATION_FORMAT_IDX, BLE_SERVS_READ_REQ),
    BLE_AIOS_EVENT_DIGITAL_0_CHAR_USER_DESCRIPTION_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_DIGITAL_0_CHAR_USER_DESCRIPTION_IDX, BLE_SERVS_WRITE_REQ),
    BLE_AIOS_EVENT_DIGITAL_0_CHAR_USER_DESCRIPTION_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_AIOS_DIGITAL_0_CHAR_USER_DESCRIPTION_IDX, BLE_SERVS_WRITE_COMP),
    BLE_AIOS_EVENT_DIGITAL_0_CHAR_USER_DESCRIPTION_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_DIGITAL_0_CHAR_USER_DESCRIPTION_IDX, BLE_SERVS_READ_REQ),
    BLE_AIOS_EVENT_DIGITAL_0_CHAR_EXTENDED_PROPERTIES_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_DIGITAL_0_CHAR_EXTENDED_PROPERTIES_IDX, BLE_SERVS_READ_REQ),
    BLE_AIOS_EVENT_DIGITAL_0_VAL_TRIGGER_SETTING_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_DIGITAL_0_VAL_TRIGGER_SETTING_IDX, BLE_SERVS_WRITE_REQ),
    BLE_AIOS_EVENT_DIGITAL_0_VAL_TRIGGER_SETTING_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_AIOS_DIGITAL_0_VAL_TRIGGER_SETTING_IDX, BLE_SERVS_WRITE_COMP),
    BLE_AIOS_EVENT_DIGITAL_0_VAL_TRIGGER_SETTING_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_DIGITAL_0_VAL_TRIGGER_SETTING_IDX, BLE_SERVS_READ_REQ),
    BLE_AIOS_EVENT_DIGITAL_0_TIME_TRIGGER_SETTING_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_DIGITAL_0_TIME_TRIGGER_SETTING_IDX, BLE_SERVS_WRITE_REQ),
    BLE_AIOS_EVENT_DIGITAL_0_TIME_TRIGGER_SETTING_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_AIOS_DIGITAL_0_TIME_TRIGGER_SETTING_IDX, BLE_SERVS_WRITE_COMP),
    BLE_AIOS_EVENT_DIGITAL_0_TIME_TRIGGER_SETTING_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_DIGITAL_0_TIME_TRIGGER_SETTING_IDX, BLE_SERVS_READ_REQ),
    BLE_AIOS_EVENT_DIGITAL_0_NUM_OF_DIGITALS_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_DIGITAL_0_NUM_OF_DIGITALS_IDX, BLE_SERVS_READ_REQ),
    /* Digital 1 */
    BLE_AIOS_EVENT_DIGITAL_1_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_DIGITAL_1_IDX, BLE_SERVS_WRITE_REQ),
    BLE_AIOS_EVENT_DIGITAL_1_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_AIOS_DIGITAL_1_IDX, BLE_SERVS_WRITE_COMP),
    BLE_AIOS_EVENT_DIGITAL_1_WRITE_CMD = BLE_SERVS_ATTR_EVENT(BLE_AIOS_DIGITAL_1_IDX, BLE_SERVS_WRITE_CMD),
    BLE_AIOS_EVENT_DIGITAL_1_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_DIGITAL_1_IDX, BLE_SERVS_READ_REQ),
    BLE_AIOS_EVENT_DIGITAL_1_CLI_CNFG_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_DIGITAL_1_CLI_CNFG_IDX, BLE_SERVS_WRITE_REQ),
    BLE_AIOS_EVENT_DIGITAL_1_CLI_CNFG_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_AIOS_DIGITAL_1_CLI_CNFG_IDX, BLE_SERVS_WRITE_COMP),
    BLE_AIOS_EVENT_DIGITAL_1_CLI_CNFG_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_DIGITAL_1_CLI_CNFG_IDX, BLE_SERVS_READ_REQ),
    BLE_AIOS_EVENT_DIGITAL_1_CHAR_PRESENTATION_FORMAT_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_DIGITAL_1_CHAR_PRESENTATION_FORMAT_IDX, BLE_SERVS_READ_REQ),
    BLE_AIOS_EVENT_DIGITAL_1_CHAR_USER_DESCRIPTION_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_DIGITAL_1_CHAR_USER_DESCRIPTION_IDX, BLE_SERVS_WRITE_REQ),
    BLE_AIOS_EVENT_DIGITAL_1_CHAR_USER_DESCRIPTION_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_AIOS_DIGITAL_1_CHAR_USER_DESCRIPTION_IDX, BLE_SERVS_WRITE_COMP),
    BLE_AIOS_EVENT_DIGITAL_1_CHAR_USER_DESCRIPTION_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_DIGITAL_1_CHAR_USER_DESCRIPTION_IDX, BLE_SERVS_READ_REQ),
    BLE_AIOS_EVENT_DIGITAL_1_CHAR_EXTENDED_PROPERTIES_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_DIGITAL_1_CHAR_EXTENDED_PROPERTIES_IDX, BLE_SERVS_READ_REQ),
    BLE_AIOS_EVENT_DIGITAL_1_VAL_TRIGGER_SETTING_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_DIGITAL_1_VAL_TRIGGER_SETTING_IDX, BLE_SERVS_WRITE_REQ),
    BLE_AIOS_EVENT_DIGITAL_1_VAL_TRIGGER_SETTING_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_AIOS_DIGITAL_1_VAL_TRIGGER_SETTING_IDX, BLE_SERVS_WRITE_COMP),
    BLE_AIOS_EVENT_DIGITAL_1_VAL_TRIGGER_SETTING_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_DIGITAL_1_VAL_TRIGGER_SETTING_IDX, BLE_SERVS_READ_REQ),
    BLE_AIOS_EVENT_DIGITAL_1_TIME_TRIGGER_SETTING_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_DIGITAL_1_TIME_TRIGGER_SETTING_IDX, BLE_SERVS_WRITE_REQ),
    BLE_AIOS_EVENT_DIGITAL_1_TIME_TRIGGER_SETTING_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_AIOS_DIGITAL_1_TIME_TRIGGER_SETTING_IDX, BLE_SERVS_WRITE_COMP),
    BLE_AIOS_EVENT_DIGITAL_1_TIME_TRIGGER_SETTING_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_DIGITAL_1_TIME_TRIGGER_SETTING_IDX, BLE_SERVS_READ_REQ),
    BLE_AIOS_EVENT_DIGITAL_1_NUM_OF_DIGITALS_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_DIGITAL_1_NUM_OF_DIGITALS_IDX, BLE_SERVS_READ_REQ),
    /* Analog 0 */
    BLE_AIOS_EVENT_ANALOG_0_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_ANALOG_0_IDX, BLE_SERVS_WRITE_REQ),
    BLE_AIOS_EVENT_ANALOG_0_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_AIOS_ANALOG_0_IDX, BLE_SERVS_WRITE_COMP),
    BLE_AIOS_EVENT_ANALOG_0_WRITE_CMD = BLE_SERVS_ATTR_EVENT(BLE_AIOS_ANALOG_0_IDX, BLE_SERVS_WRITE_CMD),
    BLE_AIOS_EVENT_ANALOG_0_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_ANALOG_0_IDX, BLE_SERVS_READ_REQ),
    BLE_AIOS_EVENT_ANALOG_0_CLI_CNFG_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_ANALOG_0_CLI_CNFG_IDX, BLE_SERVS_WRITE_REQ),
    BLE_AIOS_EVENT_ANALOG_0_CLI_CNFG_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_AIOS_ANALOG_0_CLI_CNFG_IDX, BLE_SERVS_WRITE_COMP),
    BLE_AIOS_EVENT_ANALOG_0_CLI_CNFG_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_ANALOG_0_CLI_CNFG_IDX, BLE_SERVS_READ_REQ),
    BLE_AIOS_EVENT_ANALOG_0_CHAR_PRESENTATION_FORMAT_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_ANALOG_0_CHAR_PRESENTATION_FORMAT_IDX, BLE_SERVS_READ_REQ),
    BLE_AIOS_EVENT_ANALOG_0_CHAR_USER_DESCRIPTION_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_ANALOG_0_CHAR_USER_DESCRIPTION_IDX, BLE_SERVS_WRITE_REQ),
    BLE_AIOS_EVENT_ANALOG_0_CHAR_USER_DESCRIPTION_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_AIOS_ANALOG_0_CHAR_USER_DESCRIPTION_IDX, BLE_SERVS_WRITE_COMP),
    BLE_AIOS_EVENT_ANALOG_0_CHAR_USER_DESCRIPTION_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_ANALOG_0_CHAR_USER_DESCRIPTION_IDX, BLE_SERVS_READ_REQ),
    BLE_AIOS_EVENT_ANALOG_0_CHAR_EXTENDED_PROPERTIES_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_ANALOG_0_CHAR_EXTENDED_PROPERTIES_IDX, BLE_SERVS_READ_REQ),
    BLE_AIOS_EVENT_ANALOG_0_VAL_TRIGGER_SETTING_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_ANALOG_0_VAL_TRIGGER_SETTING_IDX, BLE_SERVS_WRITE_REQ),
    BLE_AIOS_EVENT_ANALOG_0_VAL_TRIGGER_SETTING_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_AIOS_ANALOG_0_VAL_TRIGGER_SETTING_IDX, BLE_SERVS_WRITE_COMP),
    BLE_AIOS_EVENT_ANALOG_0_VAL_TRIGGER_SETTING_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_ANALOG_0_VAL_TRIGGER_SETTING_IDX, BLE_SERVS_READ_REQ),
    BLE_AIOS_EVENT_ANALOG_0_TIME_TRIGGER_SETTING_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_ANALOG_0_TIME_TRIGGER_SETTING_IDX, BLE_SERVS_WRITE_REQ),
    BLE_AIOS_EVENT_ANALOG_0_TIME_TRIGGER_SETTING_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_AIOS_ANALOG_0_TIME_TRIGGER_SETTING_IDX, BLE_SERVS_WRITE_COMP),
    BLE_AIOS_EVENT_ANALOG_0_TIME_TRIGGER_SETTING_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_ANALOG_0_TIME_TRIGGER_SETTING_IDX, BLE_SERVS_READ_REQ),
    BLE_AIOS_EVENT_ANALOG_0_VALID_RANGE_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_ANALOG_0_VALID_RANGE_IDX, BLE_SERVS_READ_REQ),
    /* Analog 1 */
    BLE_AIOS_EVENT_ANALOG_1_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_ANALOG_1_IDX, BLE_SERVS_WRITE_REQ),
    BLE_AIOS_EVENT_ANALOG_1_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_AIOS_ANALOG_1_IDX, BLE_SERVS_WRITE_COMP),
    BLE_AIOS_EVENT_ANALOG_1_WRITE_CMD = BLE_SERVS_ATTR_EVENT(BLE_AIOS_ANALOG_1_IDX, BLE_SERVS_WRITE_CMD),
    BLE_AIOS_EVENT_ANALOG_1_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_ANALOG_1_IDX, BLE_SERVS_READ_REQ),
    BLE_AIOS_EVENT_ANALOG_1_CLI_CNFG_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_ANALOG_1_CLI_CNFG_IDX, BLE_SERVS_WRITE_REQ),
    BLE_AIOS_EVENT_ANALOG_1_CLI_CNFG_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_AIOS_ANALOG_1_CLI_CNFG_IDX, BLE_SERVS_WRITE_COMP),
    BLE_AIOS_EVENT_ANALOG_1_CLI_CNFG_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_ANALOG_1_CLI_CNFG_IDX, BLE_SERVS_READ_REQ),
    BLE_AIOS_EVENT_ANALOG_1_CHAR_PRESENTATION_FORMAT_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_ANALOG_1_CHAR_PRESENTATION_FORMAT_IDX, BLE_SERVS_READ_REQ),
    BLE_AIOS_EVENT_ANALOG_1_CHAR_USER_DESCRIPTION_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_ANALOG_1_CHAR_USER_DESCRIPTION_IDX, BLE_SERVS_WRITE_REQ),
    BLE_AIOS_EVENT_ANALOG_1_CHAR_USER_DESCRIPTION_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_AIOS_ANALOG_1_CHAR_USER_DESCRIPTION_IDX, BLE_SERVS_WRITE_COMP),
    BLE_AIOS_EVENT_ANALOG_1_CHAR_USER_DESCRIPTION_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_ANALOG_1_CHAR_USER_DESCRIPTION_IDX, BLE_SERVS_READ_REQ),
    BLE_AIOS_EVENT_ANALOG_1_CHAR_EXTENDED_PROPERTIES_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_ANALOG_1_CHAR_EXTENDED_PROPERTIES_IDX, BLE_SERVS_READ_REQ),
    BLE_AIOS_EVENT_ANALOG_1_VAL_TRIGGER_SETTING_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_ANALOG_1_VAL_TRIGGER_SETTING_IDX, BLE_SERVS_WRITE_REQ),
    BLE_AIOS_EVENT_ANALOG_1_VAL_TRIGGER_SETTING_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_AIOS_ANALOG_1_VAL_TRIGGER_SETTING_IDX, BLE_SERVS_WRITE_COMP),
    BLE_AIOS_EVENT_ANALOG_1_VAL_TRIGGER_SETTING_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_ANALOG_1_VAL_TRIGGER_SETTING_IDX, BLE_SERVS_READ_REQ),
    BLE_AIOS_EVENT_ANALOG_1_TIME_TRIGGER_SETTING_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_ANALOG_1_TIME_TRIGGER_SETTING_IDX, BLE_SERVS_WRITE_REQ),
    BLE_AIOS_EVENT_ANALOG_1_TIME_TRIGGER_SETTING_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_AIOS_ANALOG_1_TIME_TRIGGER_SETTING_IDX, BLE_SERVS_WRITE_COMP),
    BLE_AIOS_EVENT_ANALOG_1_TIME_TRIGGER_SETTING_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_ANALOG_1_TIME_TRIGGER_SETTING_IDX, BLE_SERVS_READ_REQ),
    BLE_AIOS_EVENT_ANALOG_1_VALID_RANGE_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_ANALOG_1_VALID_RANGE_IDX, BLE_SERVS_READ_REQ),
    /* Aggregate */
    BLE_AIOS_EVENT_AGGREGATE_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_AGGREGATE_IDX, BLE_SERVS_READ_REQ),
    BLE_AIOS_EVENT_AGGREGATE_CLI_CNFG_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_AGGREGATE_CLI_CNFG_IDX, BLE_SERVS_WRITE_REQ),
    BLE_AIOS_EVENT_AGGREGATE_CLI_CNFG_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_AIOS_AGGREGATE_CLI_CNFG_IDX, BLE_SERVS_WRITE_COMP),
    BLE_AIOS_EVENT_AGGREGATE_CLI_CNFG_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_AIOS_AGGREGATE_CLI_CNFG_IDX, BLE_SERVS_READ_REQ),
} e_ble_aios_event_t;

/***************************************************************************//**
 * @brief     Initialize Automation IO service.
 * @param[in] cb Service callback.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOS_Init(ble_servs_app_cb_t cb);

#endif /* R_BLE_AIOS_H */

/** @} */
