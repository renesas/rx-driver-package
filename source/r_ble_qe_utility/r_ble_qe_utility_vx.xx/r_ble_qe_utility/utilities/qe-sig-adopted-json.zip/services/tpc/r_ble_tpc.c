/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_tpc.c
 * Version : 1.0
 * Description : The source file for Tx Power client.
 **********************************************************************************************************************/
#include "r_ble_tpc.h"
#include "profile_cmn/r_ble_servc_if.h"

static st_ble_servc_info_t gs_client_info;

/*----------------------------------------------------------------------------------------------------------------------
    Tx Power Level Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Tx Power Level characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_tx_power_level_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

/* Tx Power Level characteristic definition */
const st_ble_servc_char_info_t gs_tx_power_level_char = {
    .uuid_16      = BLE_TPC_TX_POWER_LEVEL_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(int8_t),
    .db_size      = BLE_TPC_TX_POWER_LEVEL_LEN,
    .char_idx     = BLE_TPC_TX_POWER_LEVEL_IDX,
    .p_attr_hdls  = gs_tx_power_level_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_int8_t,
    .encode       = (ble_servc_attr_encode_t)encode_int8_t,
};

ble_status_t R_BLE_TPC_ReadTxPowerLevel(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_tx_power_level_char, conn_hdl);
}

void R_BLE_TPC_GetTxPowerLevelAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_tpc_tx_power_level_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_tx_power_level_char_ranges[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Tx Power client
----------------------------------------------------------------------------------------------------------------------*/

/* Tx Power client attribute handles */
static st_ble_gatt_hdl_range_t gs_tpc_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

const st_ble_servc_char_info_t *gspp_tpc_chars[] = {
    &gs_tx_power_level_char,
};

static st_ble_servc_info_t gs_client_info = {
    .pp_chars     = gspp_tpc_chars,
    .num_of_chars = ARRAY_SIZE(gspp_tpc_chars),
    .p_attr_hdls  = gs_tpc_ranges,
};

ble_status_t R_BLE_TPC_Init(ble_servc_app_cb_t cb) // @suppress("API function naming")
{
    if (NULL == cb)
    {
        return BLE_ERR_INVALID_PTR;
    }

    gs_client_info.cb = cb;

    return R_BLE_SERVC_RegisterClient(&gs_client_info);
}

void R_BLE_TPC_ServDiscCb(uint16_t conn_hdl, uint8_t serv_idx, uint16_t type, void *p_param) // @suppress("API function naming")
{
    R_BLE_SERVC_ServDiscCb(&gs_client_info, conn_hdl, serv_idx, type, p_param);
}

void R_BLE_TPC_GetServAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_gatt_hdl_range_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    *p_hdl = gs_tpc_ranges[conn_idx];
}
