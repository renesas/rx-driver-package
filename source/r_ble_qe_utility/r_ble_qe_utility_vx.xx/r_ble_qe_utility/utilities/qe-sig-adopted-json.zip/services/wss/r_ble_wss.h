/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_wss.h
 * Version : 1.0
 * Description : This module implements Weight Scale Service Server.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 22.03.2019 1.00 First Release
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @file
 * @defgroup wss Weight Scale Service Server 
 * @{
 * @ingroup profile
 * @brief   This service exposes weight and related data from a weight scale intended for consumer healthcare and sports/fitness applications. 
 **********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "profile_cmn/r_ble_serv_common.h"

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
#ifndef R_BLE_WSS_H
#define R_BLE_WSS_H

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @brief Weight Scale Service event data.
***********************************************************************************************************************/
typedef struct
{
    uint16_t  conn_hdl;  /**< Connection handle */
    uint16_t  param_len; /**< Event parameter length */
    void     *p_param;   /**< Event parameter */
} st_ble_wss_evt_data_t;

/*******************************************************************************************************************//**
 * @brief Weight Scale Service event callback.
***********************************************************************************************************************/
typedef void (*ble_wss_app_cb_t)(uint16_t type, ble_status_t result, st_ble_wss_evt_data_t *p_data);

/*******************************************************************************************************************//**
 * @brief Weight Scale Service event type.
***********************************************************************************************************************/
typedef enum
{
    BLE_WSS_EVENT_WEIGHT_MEASUREMENT_CLI_CNFG_ENABLED, /**< Weight Measurement characteristic cli cnfg enabled event */
    BLE_WSS_EVENT_WEIGHT_MEASUREMENT_CLI_CNFG_DISABLED, /**< Weight Measurement characteristic cli cnfg disabled event */
    BLE_WSS_EVENT_WEIGHT_MEASUREMENT_HDL_VAL_CNF, /**< Weight Measurement characteristic handle value confiration event */
    BLE_WSS_EVENT_WEIGHT_SCALE_FEATURE_READ_REQ, /**< Weight Scale Feature characteristic read request event */
} e_ble_wss_event_t;

/*******************************************************************************************************************//**
 * @brief User ID enumeration.
***********************************************************************************************************************/
typedef enum
{
    BLE_WSS_WEIGHT_MEASUREMENT_USER_ID_UNKNOWN_USER = 255, /**< Unknown user */
} e_ble_wss_weight_measurement_t;

/*******************************************************************************************************************//**
 * @brief Mass Measurement Resolution enumeration.
 ***********************************************************************************************************************/
typedef enum
{
    BLE_WSS_WEIGHT_SCALE_FEATURE_MASS_MEASUREMENT_RESOLUTION_UNSPECIFIED, /**< Not Specified */
    BLE_WSS_WEIGHT_SCALE_FEATURE_MASS_MEASUREMENT_RESOLUTION_1_LB, /**< Resolution of 0.5 kg or 1 lb */
    BLE_WSS_WEIGHT_SCALE_FEATURE_MASS_MEASUREMENT_RESOLUTION_0_5_LB, /**< Resolution of 0.2 kg or 0.5 lb */
    BLE_WSS_WEIGHT_SCALE_FEATURE_FEATURE_MASS_MEASUREMENT_RESOLUTION_0_2_LB, /**< Resolution of 0.1 kg or 0.2 lb */
    BLE_WSS_WEIGHT_SCALE_FEATURE_MASS_MEASUREMENT_RESOLUTION_0_1_LB, /**< Resolution of 0.05 kg or 0.1 lb */
    BLE_WSS_WEIGHT_SCALE_FEATURE_MASS_MEASUREMENT_RESOLUTION_0_05_LB, /**< Resolution of 0.02 kg or 0.05 lb */
    BLE_WSS_WEIGHT_SCALE_FEATURE_MASS_MEASUREMENT_RESOLUTION_0_02_LB, /**< Resolution of 0.01 kg or 0.02 lb */
    BLE_WSS_WEIGHT_SCALE_FEATURE_MASS_MEASUREMENT_RESOLUTION_0_01_LB, /**< Resolution of 0.005 kg or 0.01 lb */
} e_ble_wss_weight_scale_feature_mass_measurement_resolution_t;

/*******************************************************************************************************************//**
 * @brief Height Measurement Resolution enumeration.
 ***********************************************************************************************************************/
typedef enum
{
    BLE_WSS_WEIGHT_SCALE_FEATURE_HEIGHT_MEASUREMENT_RESOLUTION_UNSPECIFIED, /**< Resolution Not Specified */
    BLE_WSS_WEIGHT_SCALE_FEATURE_HEIGHT_MEASUREMENT_RESOLUTION_1_INCH, /**< Resolution of 0.01 meter or 1 inch */
    BLE_WSS_WEIGHT_SCALE_FEATURE_HEIGHT_MEASUREMENT_RESOLUTION_0_5_INCH, /**< Resolution of 0.005 meter or 0.5 inch */
    BLE_WSS_WEIGHT_SCALE_FEATURE_HEIGHT_MEASUREMENT_RESOLUTION_0_1_INCH, /**< Resolution of 0.001 meter or 0.1 inch */
} e_ble_wss_weight_scale_feature_height_measurement_resolution_t;

/*******************************************************************************************************************//**
 * @brief Weight Scale Service initialization parameters.
***********************************************************************************************************************/
typedef struct
{
    ble_wss_app_cb_t cb; /**< Weight Scale Service event callback */
} st_ble_wss_init_param_t;

/*******************************************************************************************************************//**
 * @brief Weight Scale Service connection parameters.
***********************************************************************************************************************/
typedef struct
{
    uint16_t weight_measurement_cli_cnfg; /**< Weight Measurement characteristic cli cnfg */
} st_ble_wss_connect_param_t;

/*******************************************************************************************************************//**
 * @brief Weight Scale Service disconnection parameters.
***********************************************************************************************************************/
typedef struct
{
    uint16_t weight_measurement_cli_cnfg; /**< Weight Measurement characteristic cli cnfg */
} st_ble_wss_disconnect_param_t;

/*******************************************************************************************************************//**
 * @brief Weight Scale Feature characteristic parameters.
***********************************************************************************************************************/
typedef struct
{
    bool    is_timestamp_supported;        /**< Time Stamp feature supported for Weight Scale or not */
    bool    is_multiple_users_supported;   /**< Multiple Users feature supported for Weight Scale or not */
    bool    is_bmi_supported;              /**< BMI feature supported in Weight Scale or not */
    uint8_t weight_measurement_resolution; /**< Weight Measurement Resolution */
    uint8_t height_measurement_resolution; /**< Height Measurement Resolution */
} st_ble_wss_weight_scale_feature_t;

/*******************************************************************************************************************//**
 * @brief Weight Measurement characteristic parameters.
***********************************************************************************************************************/
typedef struct
{
    bool               is_measurement_in_imperial_units; /**< Weight and Mass in SI Units or Imperial Units */
    bool               is_timestamp_present; /**< Timestamp present or not */
    bool               is_user_id_present;   /**< User ID present or not */
    bool               is_bmi_height_present; /**< BMI and Height present or not */
    uint16_t           weight; /**< Weight value */
    st_ble_date_time_t time_stamp; /**< Time Stamp value */
    uint8_t            user_id; /**< User ID value */
    uint16_t           bmi; /**< BMI value */
    uint16_t           height; /**< Height value */
} st_ble_wss_weight_measurement_t;

/***********************************************************************************************************************
Exported global functions (to be accessed by other files)
***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @brief     Initialize Weight Scale Service.
 * @details   This function shall be called once at startup.
 * @param[in] p_param Pointer to Weight Scale Service initialization parameters.
 * @return
***********************************************************************************************************************/
ble_status_t R_BLE_WSS_Init(const st_ble_wss_init_param_t *p_param);

/*******************************************************************************************************************//**
 * @brief     Perform Weight Scale Service connection settings.
 * @details   This function shall be called on each connection establishment.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_param    Pointer to Connection parameters.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_WSS_Connect(uint16_t conn_hdl, const st_ble_wss_connect_param_t *p_param);

/*******************************************************************************************************************//**
 * @brief     Retrieve Weight Scale Service connection specific settings before disconnection.
 * @details   This function shall be called on each disconnection.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_param  Pointer to Disconnection parameters.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_WSS_Disconnect(uint16_t conn_hdl, st_ble_wss_disconnect_param_t *p_param);

/*******************************************************************************************************************//**
 * @brief      Get Weight Scale Feature characteristic value from local GATT database.
 * @param[out] p_app_value Pointer to retrieved Weight Scale Feature characteristic value.
 * @return     @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_WSS_GetWeightScaleFeature(st_ble_wss_weight_scale_feature_t *p_app_value);

/*******************************************************************************************************************//**
 * @brief     Set Weight Scale Feature characteristic value to local GATT database.
 * @param[in] p_app_value Pointer to Weight Scale Feature characteristic value to set.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_WSS_SetWeightScaleFeature(const st_ble_wss_weight_scale_feature_t *p_app_value);

/*******************************************************************************************************************//**
 * @brief     Send Weight Measurement indication.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] p_app_value Pointer to Weight Measurement value to send.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_WSS_IndicateWeightMeasurement(uint16_t conn_hdl, const st_ble_wss_weight_measurement_t *p_app_value);


/*******************************************************************************************************************//**
 * @brief     Return version of the WSC service server.
 * @return    version
***********************************************************************************************************************/
uint32_t R_BLE_WSS_GetVersion(void);

#endif /* R_BLE_WSS_H */

/** @} */
