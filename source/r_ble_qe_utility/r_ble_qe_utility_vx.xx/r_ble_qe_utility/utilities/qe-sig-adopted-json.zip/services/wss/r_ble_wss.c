/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_wss.c
 * Version : 1.0
 * Description : This module implements Weight Scale Service Server.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 20.03.2019 1.00 First Release
 ***********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <string.h>
#include "r_ble_rx23w_if.h"
#include "r_ble_wss.h"
#include "gatt_db.h"

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/

/* Version number */
#define BLE_WSS_PRV_VERSION_MAJOR                                      (1)
#define BLE_WSS_PRV_VERSION_MINOR                                      (0)

/*******************************************************************************************************************//**
 * Weight Scale Feature Bit definitions
 ***********************************************************************************************************************/
#define BLE_WSS_PRV_WEIGHT_SCALE_FEATURE_TIME_STAMP_SUPPORTED          (1 << 0)
#define BLE_WSS_PRV_WEIGHT_SCALE_FEATURE_MULTIPLE_USERS_SUPPORTED      (1 << 1)
#define BLE_WSS_PRV_WEIGHT_SCALE_FEATURE_BMI_SUPPORTED                 (1 << 2)
#define BLE_WSS_PRV_WEIGHT_SCALE_FEATURE_WEIGHT_MEASUREMENT_RESOLUTION (((1 << 4) - 1) << 3)
#define BLE_WSS_PRV_WEIGHT_SCALE_FEATURE_HEIGHT_MEASUREMENT_RESOLUTION (((1 << 3) - 1) << 7)
#define BLE_WSS_PRV_WEIGHT_SCALE_FEATURE_RESERVED_FOR_FUTURE_USE       (((1 << 22) - 1) << 10)

/*******************************************************************************************************************//**
 Weight Scale Measurement Flags Bit.definitions
***********************************************************************************************************************/
#define BLE_WSS_PRV_WEIGHT_MEASUREMENT_FLAGS_MEASUREMENT_UNITS         (1 << 0)
#define BLE_WSS_PRV_WEIGHT_MEASUREMENT_FLAGS_TIME_STAMP_PRESENT        (1 << 1)
#define BLE_WSS_PRV_WEIGHT_MEASUREMENT_FLAGS_USER_ID_PRESENT           (1 << 2)
#define BLE_WSS_PRV_WEIGHT_MEASUREMENT_FLAGS_BMI_AND_HEIGHT_PRESENT    (1 << 3)

/***********************************************************************************************************************
Private global variables and functions
***********************************************************************************************************************/

static ble_wss_app_cb_t gs_wss_cb;

/***********************************************************************************************************************
 * Function Name: set_cli_cnfg
 * Description  : Set Characteristic value notification configuration in local GATT database.
 * Arguments    : conn_hdl - handle to connection.
 *                attr_hadl - handle to the attribute
 *                cli_cnfg - configuration value
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t set_cli_cnfg(uint16_t conn_hdl, uint16_t attr_hdl, uint16_t cli_cnfg)
{
    uint8_t data[2];

    BT_PACK_LE_2_BYTE(data, &cli_cnfg);

    st_ble_gatt_value_t gatt_value = 
    {
        .p_value   = data,
        .value_len = 2,
    };

    return R_BLE_GATTS_SetAttr(conn_hdl, attr_hdl, &gatt_value);
}

/***********************************************************************************************************************
 * Function Name: get_cli_cnfg
 * Description  : Get Characteristic value notification configuration from local GATT database.
 * Arguments    : conn_hdl - handle to connection.
 *                attr_hadl - handle to the attribute
 *                p_cli_cnfg - pointer to variable to store configuration value
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t get_cli_cnfg(uint16_t conn_hdl, uint16_t attr_hdl, uint16_t *p_cli_cnfg)
{
    ble_status_t ret;
    st_ble_gatt_value_t gatt_value;

    ret = R_BLE_GATTS_GetAttr(conn_hdl, attr_hdl, &gatt_value);

    if (BLE_SUCCESS == ret)
    {
        BT_UNPACK_LE_2_BYTE(p_cli_cnfg, gatt_value.p_value);
    }

    return ret;
}

/***********************************************************************************************************************
 * Function Name: encode_weight_scale_feature
 * Description  : This function converts Weight Scale Feature characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the Weight Scale Feature  value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_weight_scale_feature (const st_ble_wss_weight_scale_feature_t *p_app_value,
        st_ble_gatt_value_t *p_gatt_value)
{
    /* Convert application data to byte sequence. */

    /* Clear the bytes array */
    memset(p_gatt_value->p_value, 0x0, p_gatt_value->value_len);

    /* Time Stamp Supported bit */
    if (p_app_value->is_timestamp_supported)
    {
        p_gatt_value->p_value[0] |= BLE_WSS_PRV_WEIGHT_SCALE_FEATURE_TIME_STAMP_SUPPORTED;
    }

    /* Multiple Users Supported bit */
    if (p_app_value->is_multiple_users_supported)
    {
        p_gatt_value->p_value[0] |= BLE_WSS_PRV_WEIGHT_SCALE_FEATURE_MULTIPLE_USERS_SUPPORTED;
    }

    /* BMI Supported bit */
    if (p_app_value->is_bmi_supported)
    {
        /* Set the bit */
        p_gatt_value->p_value[0] |= BLE_WSS_PRV_WEIGHT_SCALE_FEATURE_BMI_SUPPORTED;

        /* Weight Measurement Resolution */
        p_gatt_value->p_value[0] |= ((p_app_value->weight_measurement_resolution & 0x0F) << 4);

        /* Height Measurement Resolution */
        p_gatt_value->p_value[0] |= ((p_app_value->height_measurement_resolution & 0x1) << 7);
        p_gatt_value->p_value[1] = ((p_app_value->height_measurement_resolution >> 1) && 0x3);
    }

    /* Update gatt value length */
    p_gatt_value->value_len = BLE_WSS_WEIGHT_SCALE_FEATURE_LEN;

    return BLE_SUCCESS;
}


/***********************************************************************************************************************
 * Function Name: decode_weight_scale_feature
 * Description  : This function converts Weight Scale Feature characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the Weight Scale Feature value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_weight_scale_feature (st_ble_wss_weight_scale_feature_t *p_app_value,
        const st_ble_gatt_value_t *p_gatt_value)
{
    /* Convert byte sequence to application data. */
    uint8_t feature_byte0 = 0;
    uint8_t feature_byte1 = 0;

    /* Check the length */
    if(BLE_WSS_WEIGHT_SCALE_FEATURE_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Clear the app_value */
    memset(p_app_value, 0x00, sizeof(st_ble_wss_weight_scale_feature_t));

    feature_byte0 = p_gatt_value->p_value[0];
    feature_byte1 = p_gatt_value->p_value[1];

    /* Time Stamp Supported bit */
    if (feature_byte0 & BLE_WSS_PRV_WEIGHT_SCALE_FEATURE_TIME_STAMP_SUPPORTED)
    {
        p_app_value->is_timestamp_supported = true;
    }
    else
    {
        p_app_value->is_timestamp_supported = false;
    }
    
    /* Multiple Users Supported bit */
    if (feature_byte0 & BLE_WSS_PRV_WEIGHT_SCALE_FEATURE_MULTIPLE_USERS_SUPPORTED)
    {
        p_app_value->is_multiple_users_supported = true;
    }
    else
    {
        p_app_value->is_multiple_users_supported = false;
    }
    
    /* BMI Supported bit */
    if (feature_byte0 & BLE_WSS_PRV_WEIGHT_SCALE_FEATURE_BMI_SUPPORTED)
    {
        p_app_value->is_bmi_supported = true;
    }
    else
    {
        p_app_value->is_bmi_supported = false;
    }
    
    /* Height Measurement Resolution */
    p_app_value->height_measurement_resolution = ((feature_byte0 >> 3) & 0xF);
    
    /* Weight Measurement Resolution */
    p_app_value->weight_measurement_resolution = ((feature_byte0 >> 7) & 0x1);
    p_app_value->weight_measurement_resolution |= ((feature_byte1 & 0x3) << 1);

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_weight_measurement
 * Description  : This function converts Weight Measurement characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the Weight Measurement  value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_weight_measurement (const st_ble_wss_weight_measurement_t *p_app_value,
        st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 1;
    
    /* Convert application data to byte sequence. */
    memset(p_gatt_value->p_value,0x00,p_gatt_value->value_len);
    
    /* Measurement value units and value */
    if(p_app_value->is_measurement_in_imperial_units)
    {
        p_gatt_value->p_value[0] |= BLE_WSS_PRV_WEIGHT_MEASUREMENT_FLAGS_MEASUREMENT_UNITS;
    }

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->weight);
    pos += (sizeof(p_app_value->weight));
    
    /* Time stamp */
    if(p_app_value->is_timestamp_present)
    {
        p_gatt_value->p_value[0] |= BLE_WSS_PRV_WEIGHT_MEASUREMENT_FLAGS_TIME_STAMP_PRESENT;
        
        /* Copy Time stamp */
        BT_PACK_LE_2_BYTE( &p_gatt_value->p_value[pos], &(p_app_value->time_stamp.year));
        pos += (sizeof(p_app_value->time_stamp.year));

        BT_PACK_LE_1_BYTE( &p_gatt_value->p_value[pos++], &(p_app_value->time_stamp.month));
        BT_PACK_LE_1_BYTE( &p_gatt_value->p_value[pos++], &(p_app_value->time_stamp.day));
        BT_PACK_LE_1_BYTE( &p_gatt_value->p_value[pos++], &(p_app_value->time_stamp.hours));
        BT_PACK_LE_1_BYTE( &p_gatt_value->p_value[pos++], &(p_app_value->time_stamp.minutes));
        BT_PACK_LE_1_BYTE( &p_gatt_value->p_value[pos++], &(p_app_value->time_stamp.seconds));
    }

    /* User ID */
    if(p_app_value->is_user_id_present)
    {
        p_gatt_value->p_value[0] |= BLE_WSS_PRV_WEIGHT_MEASUREMENT_FLAGS_USER_ID_PRESENT;
        
        BT_PACK_LE_1_BYTE( &p_gatt_value->p_value[pos], &(p_app_value->user_id));
        pos += (sizeof(p_app_value->user_id));
    }
    
    /* BMI and Height */
    if(p_app_value->is_bmi_height_present)
    {
        p_gatt_value->p_value[0] |= BLE_WSS_PRV_WEIGHT_MEASUREMENT_FLAGS_BMI_AND_HEIGHT_PRESENT;
        
        BT_PACK_LE_2_BYTE( &p_gatt_value->p_value[pos], &(p_app_value->bmi));
        pos += (sizeof(p_app_value->bmi));
        
        BT_PACK_LE_2_BYTE( &p_gatt_value->p_value[pos], &(p_app_value->height));
        pos += (sizeof(p_app_value->height));
    }
    
    /* Update gatt value length */
    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}


/***********************************************************************************************************************
 * Function Name: wss_gatt_db_cb
 * Description  : Callback function for Weight Scale GATT Server events.
 * Arguments    : conn_hdl - handle to the connection
 *                p_params - pointer to GATTS db parameter
 * Return Value : none
 **********************************************************************************************************************/
static void wss_gatts_db_cb(uint16_t conn_hdl, st_ble_gatts_db_params_t *p_params) // @suppress("Function length")
{
    switch (p_params->db_op)
    {
        case BLE_GATTS_OP_CHAR_PEER_CLI_CNFG_WRITE_REQ:
        {
            uint16_t cli_cnfg;

            st_ble_wss_evt_data_t evt_data = 
            {
                .conn_hdl  = conn_hdl,
                .param_len = 0,
                .p_param   = NULL,
            };

            BT_UNPACK_LE_2_BYTE(&cli_cnfg, p_params->value.p_value);

            if (BLE_WSS_WEIGHT_MEASUREMENT_CLI_CNFG_DESC_HDL == p_params->attr_hdl)
            {
                if (BLE_GATTS_CLI_CNFG_INDICATION == cli_cnfg)
                {
                    gs_wss_cb(BLE_WSS_EVENT_WEIGHT_MEASUREMENT_CLI_CNFG_ENABLED, BLE_SUCCESS, &evt_data);
                }
                else
                {
                    gs_wss_cb(BLE_WSS_EVENT_WEIGHT_MEASUREMENT_CLI_CNFG_DISABLED, BLE_SUCCESS, &evt_data);
                }
            }
        } 
        break;

        default:
        {
            /* Do nothing. */
        } 
        break;
    }
}

/***********************************************************************************************************************
 * Function Name: ws_gatts_cb
 * Description  : Callback function for the GATT Server events.
 * Arguments    : type - event id
 *                result - ble status
 *                p_data - pointer to the event data
 * Return Value : none
 **********************************************************************************************************************/
static void wss_gatts_cb(uint16_t type, ble_status_t result, st_ble_gatts_evt_data_t *p_data)
{
    switch (type)
    {
        case BLE_GATTS_EVENT_DB_ACCESS_IND:
        {
            /* Type cast void pointer to st_ble_gatts_db_access_evt_t pointer */
            st_ble_gatts_db_access_evt_t *p_db_access_evt_param =
                (st_ble_gatts_db_access_evt_t *)p_data->p_param;

            wss_gatts_db_cb(p_data->conn_hdl, p_db_access_evt_param->p_params);
        }
        
        break;

        case BLE_GATTS_EVENT_HDL_VAL_CNF:
        {
            /* Type cast void pointer to st_ble_gatts_cfm_evt_t pointer */
            st_ble_gatts_cfm_evt_t *p_cfm_evt_param =
                (st_ble_gatts_cfm_evt_t *)p_data->p_param;

            if (BLE_WSS_WEIGHT_MEASUREMENT_VAL_HDL == p_cfm_evt_param->attr_hdl)
            {
                st_ble_wss_evt_data_t evt_data = 
                {
                    .conn_hdl  = p_data->conn_hdl,
                    .param_len = 0,
                    .p_param   = NULL,
                };
                gs_wss_cb(BLE_WSS_EVENT_WEIGHT_MEASUREMENT_HDL_VAL_CNF, result, &evt_data);
            }
        }
        
        break;

        default:
        {
            /* Do nothing. */
        } 
        
        break;
    }
}

ble_status_t R_BLE_WSS_Init(const st_ble_wss_init_param_t *p_param) // @suppress("API function naming")
{
    if (NULL == p_param)
    {
        return BLE_ERR_INVALID_PTR;
    }

    if (NULL == p_param->cb)
    {
        return BLE_ERR_INVALID_ARG;
    }

    R_BLE_GATTS_RegisterCb(wss_gatts_cb, 1);

    gs_wss_cb = p_param->cb;

    return BLE_SUCCESS;
}

ble_status_t R_BLE_WSS_Connect(uint16_t conn_hdl, const st_ble_wss_connect_param_t *p_param) // @suppress("API function naming")
{
    if (BLE_GAP_INVALID_CONN_HDL == conn_hdl)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (NULL != p_param)
    {
        set_cli_cnfg(conn_hdl, BLE_WSS_WEIGHT_MEASUREMENT_CLI_CNFG_DESC_HDL, p_param->weight_measurement_cli_cnfg);
    }

    return BLE_SUCCESS;
}

ble_status_t R_BLE_WSS_Disconnect(uint16_t conn_hdl, st_ble_wss_disconnect_param_t *p_param) // @suppress("API function naming")
{
    if (BLE_GAP_INVALID_CONN_HDL == conn_hdl)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (NULL != p_param)
    {
        get_cli_cnfg(conn_hdl, BLE_WSS_WEIGHT_MEASUREMENT_CLI_CNFG_DESC_HDL, &p_param->weight_measurement_cli_cnfg);
    }

    return BLE_SUCCESS;
}

ble_status_t R_BLE_WSS_GetWeightScaleFeature(st_ble_wss_weight_scale_feature_t *p_app_value) // @suppress("API function naming")
{
    st_ble_gatt_value_t gatt_value;
    ble_status_t ret;

    ret = R_BLE_GATTS_GetAttr(BLE_GAP_INVALID_CONN_HDL, BLE_WSS_WEIGHT_SCALE_FEATURE_VAL_HDL, &gatt_value);

    if (BLE_SUCCESS == ret)
    {
        ret = decode_weight_scale_feature(p_app_value, &gatt_value);
    }

    return ret;
}

ble_status_t R_BLE_WSS_SetWeightScaleFeature(const st_ble_wss_weight_scale_feature_t *p_app_value) // @suppress("API function naming")
{
    uint8_t byte_value[BLE_WSS_WEIGHT_SCALE_FEATURE_LEN] = { 0 };
    ble_status_t ret;

    st_ble_gatt_value_t gatt_value = 
    {
        .p_value   = byte_value,
        .value_len = BLE_WSS_WEIGHT_SCALE_FEATURE_LEN,
    };

    ret = encode_weight_scale_feature(p_app_value, &gatt_value);

    if (BLE_SUCCESS == ret)
    {
        ret = R_BLE_GATTS_SetAttr(BLE_GAP_INVALID_CONN_HDL, BLE_WSS_WEIGHT_SCALE_FEATURE_VAL_HDL, &gatt_value);
    }
    else
    {
        ret = BLE_ERR_INVALID_DATA;
    }

    return ret;
}

ble_status_t R_BLE_WSS_IndicateWeightMeasurement(uint16_t conn_hdl, const st_ble_wss_weight_measurement_t *p_app_value) // @suppress("API function naming")
{
    ble_status_t ret;
    uint16_t cli_cnfg;

    if (NULL == p_app_value)
    {
        return BLE_ERR_INVALID_PTR;
    }

    ret = get_cli_cnfg(conn_hdl, BLE_WSS_WEIGHT_MEASUREMENT_CLI_CNFG_DESC_HDL, &cli_cnfg);
    if (BLE_SUCCESS != ret)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if ((cli_cnfg & BLE_GATTS_CLI_CNFG_INDICATION) == 0x0000)
    {
        return BLE_ERR_INVALID_STATE;
    }

    uint8_t byte_value[BLE_WSS_WEIGHT_MEASUREMENT_LEN] = { 0 };

    st_ble_gatt_hdl_value_pair_t ind_data = 
    {
        .attr_hdl        = BLE_WSS_WEIGHT_MEASUREMENT_VAL_HDL,
        .value.p_value   = byte_value,
        .value.value_len = BLE_WSS_WEIGHT_MEASUREMENT_LEN,
    };
    
    ret = encode_weight_measurement(p_app_value, &ind_data.value);

    if (BLE_SUCCESS == ret)
    {
        ret = R_BLE_GATTS_Indication(conn_hdl, &ind_data);
    }
    else
    {
        ret = BLE_ERR_INVALID_DATA;
    }

    return ret;
}

uint32_t R_BLE_WSS_GetVersion(void) // @suppress("API function naming")
{
    uint32_t version;

    version = ((BLE_WSS_PRV_VERSION_MAJOR << 16) | (BLE_WSS_PRV_VERSION_MINOR << 8));

    return version;
}
