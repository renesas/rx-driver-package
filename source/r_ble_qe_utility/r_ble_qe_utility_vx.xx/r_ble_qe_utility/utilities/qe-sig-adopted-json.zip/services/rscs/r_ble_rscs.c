/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_rscs.c
 * Version : 1.0
 * Description : The source file for Running Speed and Cadence Service service.
 **********************************************************************************************************************/

 /***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 20.12.2019 1.00 First Release
 ***********************************************************************************************************************/

 /***********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 ***********************************************************************************************************************/
#include "r_ble_rscs.h"
#include "profile_cmn/r_ble_servs_if.h"
#include "gatt_db.h"
#include <string.h>

/***********************************************************************************************************************
@brief Version number
***********************************************************************************************************************/
#ifndef UNUSED_ARG
#define UNUSED_ARG(arg)         (void)(arg)
#endif /* UNUSED_ARG */

#define BLE_RSCS_PRV_VERSION_MAJOR                                                                     (1)
#define BLE_RSCS_PRV_VERSION_MINOR                                                                     (0)

/*******************************************************************************************************************//**
 * @brief Instantaneous Stride Length Present bit.
***********************************************************************************************************************/
#define BLE_RSCS_PRV_RSC_MEASUREMENT_FLAGS_INSTANTANEOUS_STRIDE_LENGTH_PRESENT                         (1 << 0)

/*******************************************************************************************************************//**
 * @brief Total Distance Present bit.
***********************************************************************************************************************/
#define BLE_RSCS_PRV_RSC_MEASUREMENT_FLAGS_TOTAL_DISTANCE_PRESENT                                      (1 << 1)

/*********************************************************************************************************************
 * @brief Walking or Running Status bits.
***********************************************************************************************************************/
#define BLE_RSCS_PRV_RSC_MEASUREMENT_FLAGS_WALKING_OR_RUNNING_STATUS_BITS                              (1 << 2)

/***********************************************************************************************************************
 * @brief Instantaneous Stride Length Measurement Supported bit.
***********************************************************************************************************************/
#define BLE_RSCS_PRV_RSC_FEATURE_INSTANTANEOUS_STRIDE_LENGTH_MEASUREMENT_SUPPORTED                     (1 << 0)

/***********************************************************************************************************************
 * @brief Total Distance Measurement Supported bit.
***********************************************************************************************************************/
#define BLE_RSCS_PRV_RSC_FEATURE_TOTAL_DISTANCE_MEASUREMENT_SUPPORTED                                  (1 << 1)

/*****************************************************************************************************************//****
 * @brief Walking or Running Status Supported bit.
***********************************************************************************************************************/
#define BLE_RSCS_PRV_RSC_FEATURE_WALKING_OR_RUNNING_STATUS_SUPPORTED                                   (1 << 2)

/***********************************************************************************************************************
 * @brief Calibration Procedure Supported bit.
***********************************************************************************************************************/
#define BLE_RSCS_PRV_RSC_FEATURE_CALIBRATION_PROCEDURE_SUPPORTED                                       (1 << 3)

/***********************************************************************************************************************
 * @brief Multiple Sensor Locations Supported bit.
***********************************************************************************************************************/
#define BLE_RSCS_PRV_RSC_FEATURE_MULTIPLE_SENSOR_LOCATIONS_SUPPORTED                                   (1 << 4)

/***********************************************************************************************************************
Private global variables and functions
***********************************************************************************************************************/
static uint16_t                            gs_conn_hdl;
static st_ble_rscs_sc_control_point_t      gs_rsc_sc_control_point;
static st_ble_servs_info_t                 gs_servs_info;
static bool                                gs_is_sc_in_progress = false;
static uint8_t                             gs_count   = 0;
static uint8_t                             gs_counter = 0;
 
/*----------------------------------------------------------------------------------------------------------------------
   RSC Measurement Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

static const st_ble_servs_desc_info_t gs_rsc_measurement_cli_cnfg =
{
    .attr_hdl = BLE_RSCS_RSC_MEASUREMENT_CLI_CNFG_DESC_HDL,
    .app_size = sizeof(uint16_t),
    .desc_idx = BLE_RSCS_RSC_MEASUREMENT_CLI_CNFG_IDX,
    .db_size  = BLE_RSCS_RSC_MEASUREMENT_CLI_CNFG_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_uint16_t,
    .encode   = (ble_servs_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_RSCS_SetRscMeasCliCnfg(uint16_t conn_hdl, const uint16_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_rsc_measurement_cli_cnfg, conn_hdl, (const void *)p_value);
}

/* End of function R_BLE_RSCS_SetRscMeasCliCnfg */

ble_status_t R_BLE_RSCS_GetRscMeasCliCfg(uint16_t conn_hdl, uint16_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_rsc_measurement_cli_cnfg, conn_hdl, (void *)p_value);
}

/* End of function R_BLE_RSCS_GetRscMeasurementCliCnfg */

/***********************************************************************************************************************
 * Function Name: decode_st_ble_rscs_rsc_meas_t
 * Description  : This function converts RSC Measurement characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the RSC Measurement value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_rscs_rsc_meas_t(st_ble_rscs_rsc_measurement_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    UNUSED_ARG(p_app_value);
    UNUSED_ARG(p_gatt_value);

     /*Do Nothing as flow is not hitting here*/
    return BLE_SUCCESS;
}

/* End of function decode_st_ble_rscs_rsc_meas_t */

/***********************************************************************************************************************
 * Function Name: encode_st_ble_rscs_rsc_meas_t
 * Description  : This function converts RSC Measurement characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the RSC Measurement  value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_rscs_rsc_meas_t(const st_ble_rscs_rsc_measurement_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 1;
    st_ble_rscs_rsc_feature_t rsc_feature = { 0 };

    R_BLE_RSCS_GetRscFeat(&rsc_feature);

    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    /* copy the byte sequence to application data */
    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->instantaneous_speed);
    pos += 2;

    BT_UNPACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->instantaneous_cadence);

    if ((p_app_value->is_instantaneous_stride_length_present) &&
        (rsc_feature.is_instantaneous_stride_length_measurement_supported))
    {
        p_gatt_value->p_value[0] |= BLE_RSCS_PRV_RSC_MEASUREMENT_FLAGS_INSTANTANEOUS_STRIDE_LENGTH_PRESENT;

        /* stride length */
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->instantaneous_stride_length);
        pos += 2;
    }

    if ((p_app_value->is_total_distance_present) && (rsc_feature.is_total_distance_measurement_supported))
    {
        p_gatt_value->p_value[0] |= BLE_RSCS_PRV_RSC_MEASUREMENT_FLAGS_TOTAL_DISTANCE_PRESENT;

        /* total distance */
        BT_PACK_LE_4_BYTE(&p_gatt_value->p_value[pos], &p_app_value->total_distance);
        pos += 4;
    }

    if ((p_app_value->is_walking_or_running_status_bits) && (rsc_feature.is_walking_or_running_status_supported))
    {
        p_gatt_value->p_value[0] |= BLE_RSCS_PRV_RSC_MEASUREMENT_FLAGS_WALKING_OR_RUNNING_STATUS_BITS;
    }

    p_gatt_value->value_len = (uint16_t)pos;
    return BLE_SUCCESS;
}

/* End of function encode_st_ble_rscs_rsc_meas_t */

/*  RSC Measurement characteristic descriptor definition */
static const st_ble_servs_desc_info_t *gspp_rsc_measurement_descs[] =
{
    &gs_rsc_measurement_cli_cnfg,
};

/* RSC Measurement characteristic definition */
static const st_ble_servs_char_info_t gs_rsc_measurement_char =
{
    .start_hdl    = BLE_RSCS_RSC_MEASUREMENT_DECL_HDL,
    .end_hdl      = BLE_RSCS_RSC_MEASUREMENT_CLI_CNFG_DESC_HDL,
    .char_idx     = BLE_RSCS_RSC_MEASUREMENT_IDX,
    .app_size     = sizeof(st_ble_rscs_rsc_measurement_t),
    .db_size      = BLE_RSCS_RSC_MEASUREMENT_LEN,
    .decode       = (ble_servs_attr_decode_t)decode_st_ble_rscs_rsc_meas_t,
    .encode       = (ble_servs_attr_encode_t)encode_st_ble_rscs_rsc_meas_t,
    .pp_descs     = gspp_rsc_measurement_descs,
    .num_of_descs = ARRAY_SIZE(gspp_rsc_measurement_descs),
};

ble_status_t R_BLE_RSCS_NotifyRscMeasurement(uint16_t conn_hdl, const st_ble_rscs_rsc_measurement_t *p_value)
{
    return R_BLE_SERVS_SendHdlVal(&gs_rsc_measurement_char, conn_hdl, (const void *)p_value, true);
}

/* End of function R_BLE_RSCS_NotifyRscMeasurement */

/*----------------------------------------------------------------------------------------------------------------------
    CSC Feature characteristic
----------------------------------------------------------------------------------------------------------------------*/

/***********************************************************************************************************************
 * Function Name: decode_st_ble_rscs_rsc_feat_t
 * Description  : This function converts RSC Feature characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the RSC Feature value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_rscs_rsc_feat_t(st_ble_rscs_rsc_feature_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint16_t rsc_feature = 0;

    if (BLE_RSCS_RSC_FEATURE_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Clear the feature bit flags */
    memset(p_app_value, 0x00, sizeof(st_ble_rscs_rsc_feature_t));

    /* copy the feature supported bits */
    BT_UNPACK_LE_2_BYTE(&rsc_feature, p_gatt_value->p_value);

    /* Instantaneous Stride Length Measurement Supported bit */
    if (rsc_feature & BLE_RSCS_PRV_RSC_FEATURE_INSTANTANEOUS_STRIDE_LENGTH_MEASUREMENT_SUPPORTED)
    {
        p_app_value->is_instantaneous_stride_length_measurement_supported = true;
    }
    else
    {
        p_app_value->is_instantaneous_stride_length_measurement_supported = false;
    }

    /* Total Distance Measurement Supported bit */
    if (rsc_feature & BLE_RSCS_PRV_RSC_FEATURE_TOTAL_DISTANCE_MEASUREMENT_SUPPORTED)
    {
        p_app_value->is_total_distance_measurement_supported = true;
    }
    else
    {
        p_app_value->is_total_distance_measurement_supported = false;
    }

    /* Walking or Running Status Supported bit */
    if (rsc_feature & BLE_RSCS_PRV_RSC_FEATURE_WALKING_OR_RUNNING_STATUS_SUPPORTED)
    {
        p_app_value->is_walking_or_running_status_supported = true;
    }
    else
    {
        p_app_value->is_walking_or_running_status_supported = false;
    }

    /* Sensor Calibration Procedure Supported bit */
    if (rsc_feature & BLE_RSCS_PRV_RSC_FEATURE_CALIBRATION_PROCEDURE_SUPPORTED)
    {
        p_app_value->is_calibration_procedure_supported = true;
    }
    else
    {
        p_app_value->is_calibration_procedure_supported = false;
    }

    /* Multiple Sensor Location Supported bit */
    if (rsc_feature & BLE_RSCS_PRV_RSC_FEATURE_MULTIPLE_SENSOR_LOCATIONS_SUPPORTED)
    {
        p_app_value->is_multiple_sensor_locations_supported = true;
    }
    else
    {
        p_app_value->is_multiple_sensor_locations_supported = false;
    }
    return BLE_SUCCESS;
}

/* End of function decode_st_ble_rscs_rsc_feat_t */

/***********************************************************************************************************************
 * Function Name: encode_st_ble_rscs_rsc_feat_t
 * Description  : This function converts RSC Feature characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the RSC Feature  value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_rscs_rsc_feat_t(const st_ble_rscs_rsc_feature_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint16_t rsc_feature = 0;

    /* Clear the byte array */
    memset(p_gatt_value, 0x00, p_gatt_value->value_len);

    /* Instantaneous Stride Length Measurement Supported bit */
    if (p_app_value->is_instantaneous_stride_length_measurement_supported)
    {
        rsc_feature |= BLE_RSCS_PRV_RSC_FEATURE_INSTANTANEOUS_STRIDE_LENGTH_MEASUREMENT_SUPPORTED;
    }

    /* Total Distance Measurement Supported bit */
    if (p_app_value->is_total_distance_measurement_supported)
    {
        rsc_feature |= BLE_RSCS_PRV_RSC_FEATURE_TOTAL_DISTANCE_MEASUREMENT_SUPPORTED;
    }

    /* Walking or Running Status Supported bit */
    if (p_app_value->is_walking_or_running_status_supported)
    {
        rsc_feature |= BLE_RSCS_PRV_RSC_FEATURE_WALKING_OR_RUNNING_STATUS_SUPPORTED;
    }

    /* Sensor Calibration Procedure Supported bit */
    if (p_app_value->is_calibration_procedure_supported)
    {
        rsc_feature |= BLE_RSCS_PRV_RSC_FEATURE_CALIBRATION_PROCEDURE_SUPPORTED;
    }

    /* Multiple Sensor Location Supported bit */
    if (p_app_value->is_multiple_sensor_locations_supported)
    {
        rsc_feature |= BLE_RSCS_PRV_RSC_FEATURE_MULTIPLE_SENSOR_LOCATIONS_SUPPORTED;
    }

    BT_PACK_LE_2_BYTE(p_gatt_value->p_value, &rsc_feature);

    p_gatt_value->value_len = BLE_RSCS_RSC_FEATURE_LEN;
    return BLE_SUCCESS;
}

/* End of function encode_st_ble_rscs_rsc_feat_t */

/* RSC Feature characteristic definition */

static const st_ble_servs_char_info_t gs_rsc_feature_char =
{
    .start_hdl    = BLE_RSCS_RSC_FEATURE_DECL_HDL,
    .end_hdl      = BLE_RSCS_RSC_FEATURE_VAL_HDL,
    .char_idx     = BLE_RSCS_RSC_FEATURE_IDX,
    .app_size     = sizeof(st_ble_rscs_rsc_feature_t),
    .db_size      = BLE_RSCS_RSC_FEATURE_LEN,
    .decode       = (ble_servs_attr_decode_t)decode_st_ble_rscs_rsc_feat_t,
    .encode       = (ble_servs_attr_encode_t)encode_st_ble_rscs_rsc_feat_t,
};

ble_status_t R_BLE_RSCS_SetRscFeat(const st_ble_rscs_rsc_feature_t *p_value)
{
    return R_BLE_SERVS_SetChar(&gs_rsc_feature_char, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

/* End of function R_BLE_RSCS_SetRscFeat */

ble_status_t R_BLE_RSCS_GetRscFeat(st_ble_rscs_rsc_feature_t *p_value)
{
    return R_BLE_SERVS_GetChar(&gs_rsc_feature_char, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/* End of function R_BLE_RSCS_GetRscFeat */

/*----------------------------------------------------------------------------------------------------------------------
Sensor Location characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Sensor Location characteristic definition */

static const st_ble_servs_char_info_t gs_sensor_location_char =
{
    .start_hdl    = BLE_RSCS_SENSOR_LOCATION_DECL_HDL,
    .end_hdl      = BLE_RSCS_SENSOR_LOCATION_VAL_HDL,
    .char_idx     = BLE_RSCS_SENSOR_LOCATION_IDX,
    .app_size     = sizeof(uint8_t),
    .db_size      = BLE_RSCS_SENSOR_LOCATION_LEN,
    .decode       = (ble_servs_attr_decode_t)decode_uint8_t,
    .encode       = (ble_servs_attr_encode_t)encode_uint8_t,
};

ble_status_t R_BLE_RSCS_SetSenLoc(const uint8_t *p_value)
{
    return R_BLE_SERVS_SetChar(&gs_sensor_location_char, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

/* End of function R_BLE_RSCS_SetSenLoc */

ble_status_t R_BLE_RSCS_GetSenLoc(uint8_t *p_value)
{
    return R_BLE_SERVS_GetChar(&gs_sensor_location_char, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/* End of function R_BLE_RSCS_GetSenLoc */

/*----------------------------------------------------------------------------------------------------------------------
    SC Control Point Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

static const st_ble_servs_desc_info_t gs_sc_control_point_cli_cnfg =
{
    .attr_hdl = BLE_RSCS_SC_CONTROL_POINT_CLI_CNFG_DESC_HDL,
    .app_size = sizeof(uint16_t),
    .desc_idx = BLE_RSCS_SC_CONTROL_POINT_CLI_CNFG_IDX,
    .db_size  = BLE_RSCS_SC_CONTROL_POINT_CLI_CNFG_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_uint16_t,
    .encode   = (ble_servs_attr_encode_t)encode_uint16_t,
};


ble_status_t R_BLE_RSCS_SetScCPCliCfg(uint16_t conn_hdl, const uint16_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_sc_control_point_cli_cnfg, conn_hdl, (const void *)p_value);
}

/* End of function R_BLE_RSCS_SetScCPCliCfg */

ble_status_t R_BLE_RSCS_GetScCPCliCfg(uint16_t conn_hdl, uint16_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_sc_control_point_cli_cnfg, conn_hdl, (void *)p_value);
}

/* End of function R_BLE_RSCS_GetScCPCliCfg */

/***********************************************************************************************************************
 * Function Name: decode_st_ble_rscs_sc_cp_t
 * Description  : This function converts SC Control Point characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the SC Control Point value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : none
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_rscs_sc_cp_t(st_ble_rscs_sc_control_point_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t  pos = 0;
    ble_status_t  ret;

    BT_UNPACK_LE_1_BYTE(&gs_rsc_sc_control_point.op_code,&p_gatt_value->p_value[pos]);
    pos += 1;

    if (BLE_RSCS_SC_CONTROL_POINT_OP_CODE_SET_CUMULATIVE_VALUE == gs_rsc_sc_control_point.op_code)
    {
        BT_UNPACK_LE_4_BYTE(&gs_rsc_sc_control_point.cumulative_value, &p_gatt_value->p_value[pos]);
        pos += 4;
    }
    else if (BLE_RSCS_SC_CONTROL_POINT_OP_CODE_UPDATE_SENSOR_LOCATION == gs_rsc_sc_control_point.op_code)
    {
        BT_UNPACK_LE_1_BYTE(&gs_rsc_sc_control_point.sensor_location_value, &p_gatt_value->p_value[pos]);
        pos += 1;
    }
    else
    {
        /* BLE_RSCS_SC_CONTROL_POINT_OP_CODE_START_SENSOR_CALIBRATION or
        BLE_RSCS_SC_CONTROL_POINT_OP_CODE_REQUEST_SUPPORTED_SENSOR_LOCATIONS or
        Invalid opcode - Do nothing*/
    }

    if ((p_gatt_value->value_len <= BLE_RSCS_SC_CONTROL_POINT_LEN) && (p_gatt_value->value_len == pos))
    {
        memcpy(p_app_value, &gs_rsc_sc_control_point, sizeof(st_ble_rscs_sc_control_point_t));

        ret = BLE_SUCCESS;
    }
    else
    {
        ret = BLE_RSCS_PRV_WRITE_REQUEST_REJECTED;
    }

    return ret;
}

/*   End of function decode_st_ble_rscs_sc_cp_t */

/******************************************************************************************************************
 * Function Name: encode_st_ble_rscs_sc_control_point_t
 * Description  : This function converts SC Control Point characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the SC Control Point  value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_rscs_sc_cp_t(const st_ble_rscs_sc_control_point_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;
    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

     /* Response code */
     p_gatt_value->p_value[pos++] = BLE_RSCS_SC_CONTROL_POINT_OP_CODE_RESPONSE_CODE;

    /* request opcode */
    BT_UNPACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->request_op_code);

    /* response value */
    BT_UNPACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->response_value);

    if (BLE_RSCS_SC_CONTROL_POINT_OP_CODE_REQUEST_SUPPORTED_SENSOR_LOCATIONS == p_app_value->request_op_code)
    {
        /* response parameter - list of supported sensor locations */
        for (uint32_t i = 0; i < p_app_value->no_of_supported_sensor_locations; i++)
        {
            BT_UNPACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->response_parameter[i]);
        }
    }

    p_gatt_value->value_len = (uint16_t)pos;
    return BLE_SUCCESS;
}

/*  End of function encode_st_ble_rscs_sc_control_point_t  */

/***********************************************************************************************************************//**
 * Function Name: rscs_process_operation
 * Description  : This function handles the write request events and process the operation and sends the response .
 * Arguments    : conn_hdl    - connection handle
 *                p_app_value - pointer to the characteristic value in the application database
                  started     - process started indication
 * Return Value : none
 **********************************************************************************************************************/
static void rscs_process_operation(uint16_t conn_hdl, st_ble_rscs_sc_control_point_t *p_app_value, bool started)
{
    UNUSED_ARG(conn_hdl);
    UNUSED_ARG(p_app_value);
    UNUSED_ARG(started);

    /* UN Supported OP CODE */
    if ((BLE_RSCS_SC_CONTROL_POINT_OP_CODE_RESERVED_FOR_FUTURE_USE == gs_rsc_sc_control_point.op_code) || (0xff == gs_rsc_sc_control_point.op_code))
    {
        if (0 == gs_count)
        {
            gs_rsc_sc_control_point.op_code         = BLE_RSCS_SC_CONTROL_POINT_OP_CODE_RESPONSE_CODE;
            gs_rsc_sc_control_point.request_op_code = BLE_RSCS_SC_CONTROL_POINT_RESPONSE_VALUE_RESERVED_FOR_FUTURE_USE__RESPONSE_PARAMETER__N_A_;
            gs_rsc_sc_control_point.response_value  = BLE_RSCS_SC_CONTROL_POINT_RESPONSE_VALUE_OP_CODE_NOT_SUPPORTED__RESPONSE_PARAMETER__N_A_;
            R_BLE_RSCS_IndicateScCP(gs_conn_hdl, &gs_rsc_sc_control_point);
            gs_count++;
        }
        else if(1 == gs_count)
        {
            gs_rsc_sc_control_point.op_code         = BLE_RSCS_SC_CONTROL_POINT_OP_CODE_RESPONSE_CODE;
            gs_rsc_sc_control_point.request_op_code = 0xff;
            gs_rsc_sc_control_point.response_value  = BLE_RSCS_SC_CONTROL_POINT_RESPONSE_VALUE_OP_CODE_NOT_SUPPORTED__RESPONSE_PARAMETER__N_A_;
            R_BLE_RSCS_IndicateScCP(gs_conn_hdl, &gs_rsc_sc_control_point);
        }
        else
        {
            /*DO Nothing*/
        }
    }
}

/* End of function rscs_process_operation */

/***********************************************************************************************************************//**
* Function Name: write_req_sc_ctrl_pt
* Description  : This function handles the Speed and Cadence Control Point characteristic write request event.
* Arguments    : p_attr      - pointer to the attribute handle
                 conn_hdl    - connection handle
                 result      - BLE_STATUS
                 p_app_value - pointer to the CGM Record Access Control Point  value in the application layer
* Return Value : None
**********************************************************************************************************************/
static void write_req_sc_ctrl_pt(const void *p_attr, uint16_t conn_hdl, ble_status_t result, st_ble_rscs_sc_control_point_t *p_app_value)
{
    UNUSED_ARG(p_attr);
    UNUSED_ARG(result);
    UNUSED_ARG(p_app_value);

    if ((0x4 == gs_rsc_sc_control_point.op_code))// && (0x01 == p_app_value->response_code))
    {
        gs_counter++;
        if (2 == gs_counter)
        {
            gs_is_sc_in_progress = true;
        }
    }

    if (gs_is_sc_in_progress)
    {
        R_BLE_GATTS_SendErrRsp(BLE_RSCS_PROCEDURE_ALREADY_IN_PROGRESS_ERROR);
        return;
    }

    uint16_t cli_cnfg;
    R_BLE_RSCS_GetScCPCliCfg(conn_hdl, &cli_cnfg);
    if (BLE_GATTS_CLI_CNFG_INDICATION != cli_cnfg)
    {
        R_BLE_GATTS_SendErrRsp(BLE_RSCS_CLIENT_CHARACTERISTIC_CONFIGURATION_DESCRIPTOR_IMPROPERLY_CONFIGURED_ERROR);
        return;
    }
}

/* End of function write_req_sc_ctrl_pt */

/***********************************************************************************************************************//**
* Function Name: write_comp_sc_ctrl_pt
* Description  : This function handles the Speed and Cadence Control Point characteristic write complete event.
* Arguments    : p_attr      - pointer to the attribute handle
                 conn_hdl    - connection handle
                 result      - BLE_STATUS
                 p_app_value - pointer to the Speed and Cadence Control Point  value in the application layer
* Return Value : None
**********************************************************************************************************************/
static void write_comp_sc_ctrl_pt(const void *p_attr, uint16_t conn_hdl, ble_status_t result, st_ble_rscs_sc_control_point_t *p_app_value)
{
    UNUSED_ARG(result);

    gs_conn_hdl = conn_hdl;

    rscs_process_operation(conn_hdl, p_app_value, true);

    st_ble_servs_evt_data_t evt_data =
    {
        .conn_hdl  = conn_hdl,
        .param_len = sizeof(gs_rsc_sc_control_point),
        .p_param   = &gs_rsc_sc_control_point,
    };
    st_ble_servs_char_info_t p_char = *(st_ble_servs_char_info_t *)p_attr;

    gs_servs_info.cb(BLE_SERVS_MULTI_ATTR_EVENT(p_char.char_idx, p_char.inst_idx, BLE_SERVS_WRITE_REQ), BLE_SUCCESS, &evt_data);
}

/*  End of function write_comp_sc_ctrl_pt */

/* SC Control Point characteristic descriptor definition */
static const st_ble_servs_desc_info_t *gspp_sc_control_point_descs[] =
{
    &gs_sc_control_point_cli_cnfg,
};

/* SC Control Point characteristic definition */
static const st_ble_servs_char_info_t gs_sc_control_point_char =
{
    .start_hdl     = BLE_RSCS_SC_CONTROL_POINT_DECL_HDL,
    .end_hdl       = BLE_RSCS_SC_CONTROL_POINT_CLI_CNFG_DESC_HDL,
    .char_idx      = BLE_RSCS_SC_CONTROL_POINT_IDX,
    .app_size      = sizeof(st_ble_rscs_sc_control_point_t),
    .db_size       = BLE_RSCS_SC_CONTROL_POINT_LEN,
    .write_req_cb  = (ble_servs_attr_write_req_t)write_req_sc_ctrl_pt,
    .write_comp_cb = (ble_servs_attr_write_comp_t)write_comp_sc_ctrl_pt,
    .decode        = (ble_servs_attr_decode_t)decode_st_ble_rscs_sc_cp_t,
    .encode        = (ble_servs_attr_encode_t)encode_st_ble_rscs_sc_cp_t,
    .pp_descs      = gspp_sc_control_point_descs,
    .num_of_descs  = ARRAY_SIZE(gspp_sc_control_point_descs),
};

ble_status_t R_BLE_RSCS_IndicateScCP(uint16_t conn_hdl, const st_ble_rscs_sc_control_point_t *p_value)
{
    return R_BLE_SERVS_SendHdlVal(&gs_sc_control_point_char, conn_hdl, (const void *)p_value, false);
}

/* End of function R_BLE_RSCS_IndicateScCP */

/*----------------------------------------------------------------------------------------------------------------------
    Running Speed and Cadence Service server
----------------------------------------------------------------------------------------------------------------------*/

/* Running Speed and Cadence Service characteristics definition */
static const st_ble_servs_char_info_t *gspp_chars[] =
{
    &gs_rsc_measurement_char,
    &gs_rsc_feature_char,
    &gs_sensor_location_char,
    &gs_sc_control_point_char,
};

/*-------------------------------------------------------------------------------------------------------------------------
     Running Speed and Cadence Service service definition
---------------------------------------------------------------------------------------------------------------------------*/
static st_ble_servs_info_t gs_servs_info =
{
    .pp_chars     = gspp_chars,
    .num_of_chars = ARRAY_SIZE(gspp_chars),
};


/***********************************************************************************************************************//**
* Function Name: R_BLE_RSCS_Init
* Description  : This function initializes the GATTS Server and RSC Service, registers the callback function for
*                GATTS.
* Arguments    : cb - cal back to the initialization parameters data
* Return Value : BLE_SUCCESS               - Success
*                BLE_ERR_INVALID_PTR       - The p_ntf_data parameter or the value field in the value field in
*                                            the p_ntf_data parameter is NULL.
*                BLE_ERR_INVALID_ARG       - The value_len field in the value field in the p_ntf_data parameter is 0
*                                            or the attr_hdl field in the p_ntf_data parameters is 0.
**********************************************************************************************************************/
ble_status_t R_BLE_RSCS_Init(ble_servs_app_cb_t cb)
{
    if (NULL == cb)
    {
        return BLE_ERR_INVALID_PTR;
    }

    gs_servs_info.cb = cb;

    return R_BLE_SERVS_RegisterServer(&gs_servs_info);
}

/* End of R_BLE_RSCS_Init */
