/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
 * File Name: r_ble_rscs.c
 * Version : 1.0
 * Description : This module implements Running Speed and Cadence Service Server.
 **********************************************************************************************************************/
 
 /***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 22.03.2019 1.00 First Release
 ***********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <string.h>
#include "r_ble_rx23w_if.h"
#include "r_ble_rscs.h"
#include "gatt_db.h"

/***********************************************************************************************************************
Version number
***********************************************************************************************************************/
#define BLE_RSCS_PRV_VERSION_MAJOR                                                          (1)
#define BLE_RSCS_PRV_VERSION_MINOR                                                          (0)

/*******************************************************************************************************************//**
 * @brief Procedure Already in Progress error code.
***********************************************************************************************************************/
#define BLE_RSCS_PRV_PROCEDURE_ALREADY_IN_PROGRESS                                          (BLE_ERR_GROUP_GATT | 0x80)

/*******************************************************************************************************************//**
 * @brief Client Characteristic Configuration descriptor improperly configured error code.
***********************************************************************************************************************/
#define BLE_RSCS_PRV_CLIENT_CHARACTERISTIC_CONFIGURATION_DESCRIPTOR_IMPROPERLY_CONFIGURED   (BLE_ERR_GROUP_GATT | 0x81)

/*******************************************************************************************************************//**
 * @brief Write Request Rejected error code.
***********************************************************************************************************************/
#define BLE_RSCS_PRV_WRITE_REQUEST_REJECTED                                                 (BLE_ERR_GROUP_GATT | 0x82)

/*******************************************************************************************************************//**
 * @brief Instantaneous Stride Length Present bit.
***********************************************************************************************************************/
#define BLE_RSCS_PRV_RSC_MEASUREMENT_FLAGS_INSTANTANEOUS_STRIDE_LENGTH_PRESENT                         (1 << 0)

/*******************************************************************************************************************//**
 * @brief Total Distance Present bit.
***********************************************************************************************************************/
#define BLE_RSCS_PRV_RSC_MEASUREMENT_FLAGS_TOTAL_DISTANCE_PRESENT                                      (1 << 1)

/*********************************************************************************************************************
 * @brief Walking or Running Status bits.
***********************************************************************************************************************/
#define BLE_RSCS_PRV_RSC_MEASUREMENT_FLAGS_WALKING_OR_RUNNING_STATUS_BITS                              (1 << 2)

/***********************************************************************************************************************
 * @brief Instantaneous Stride Length Measurement Supported bit.
***********************************************************************************************************************/
#define BLE_RSCS_PRV_RSC_FEATURE_INSTANTANEOUS_STRIDE_LENGTH_MEASUREMENT_SUPPORTED                     (1 << 0)

/***********************************************************************************************************************
 * @brief Total Distance Measurement Supported bit.
***********************************************************************************************************************/
#define BLE_RSCS_PRV_RSC_FEATURE_TOTAL_DISTANCE_MEASUREMENT_SUPPORTED                                  (1 << 1)

/*****************************************************************************************************************//****
 * @brief Walking or Running Status Supported bit.
***********************************************************************************************************************/
#define BLE_RSCS_PRV_RSC_FEATURE_WALKING_OR_RUNNING_STATUS_SUPPORTED                                   (1 << 2)

/***********************************************************************************************************************
 * @brief Calibration Procedure Supported bit.
***********************************************************************************************************************/
#define BLE_RSCS_PRV_RSC_FEATURE_CALIBRATION_PROCEDURE_SUPPORTED                                       (1 << 3)

/***********************************************************************************************************************
 * @brief Multiple Sensor Locations Supported bit.
***********************************************************************************************************************/
#define BLE_RSCS_PRV_RSC_FEATURE_MULTIPLE_SENSOR_LOCATIONS_SUPPORTED                                   (1 << 4)

/*******************************************************************************************************************//**
 * @brief Control Point Event ID
***********************************************************************************************************************/
#define BLE_RSCS_PRV_SCCP_EVENT_ID                                                                     (11)

/***********************************************************************************************************************
Private global variables and functions
***********************************************************************************************************************/
static ble_rscs_app_cb_t                   gs_rscs_cb;

static uint16_t                            gs_conn_hdl;
static st_ble_rscs_sc_control_point_t      gs_sc_control_point;
static bool                                gs_rscs_sc_cp_in_progress = false;

static void rscs_gatts_cb(uint16_t type, ble_status_t result, st_ble_gatts_evt_data_t *p_data);

/************************************************************************************************************************
 * Function Name: set_cli_cnfg
 * Description  : Set Characteristic value notification configuration in local GATT database.
 * Arguments    : conn_hdl - handle to connection.
 *                attr_hadl - handle to the attribute
 *                cli_cnfg - configuration value
 * Return Value : ble_status_t
 ***********************************************************************************************************************/
static ble_status_t set_cli_cnfg (uint16_t conn_hdl, uint16_t attr_hdl, uint16_t cli_cnfg)
{
    uint8_t data[2];

    BT_PACK_LE_2_BYTE(data, &cli_cnfg);

    st_ble_gatt_value_t gatt_value =
    {
        .p_value   = data,
        .value_len = 2,
    };

    return R_BLE_GATTS_SetAttr(conn_hdl, attr_hdl, &gatt_value);
}

/***********************************************************************************************************************
 * Function Name: get_cli_cnfg
 * Description  : Get Characteristic value notification configuration from local GATT database.
 * Arguments    : conn_hdl - handle to connection.
 *                attr_hadl - handle to the attribute
 *                p_cli_cnfg - pointer to variable to store configuration value
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t get_cli_cnfg (uint16_t conn_hdl, uint16_t attr_hdl, uint16_t *p_cli_cnfg)
{
    ble_status_t ret;
    st_ble_gatt_value_t gatt_value;

    ret = R_BLE_GATTS_GetAttr(conn_hdl, attr_hdl, &gatt_value);

    if (BLE_SUCCESS == ret)
    {
        BT_UNPACK_LE_2_BYTE(p_cli_cnfg, gatt_value.p_value);
    }

    return ret;
}

/***********************************************************************************************************************
 * Function Name: encode_rsc_measurement
 * Description  : This function converts RSC Measurement characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the RSC Measurement  value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_rsc_measurement (const st_ble_rscs_rsc_measurement_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 1;
    st_ble_rscs_rsc_feature_t rsc_feature = { 0 };

    R_BLE_RSCS_GetRscFeature(&rsc_feature);

    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    /* copy the byte sequence to application data */
    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->instantaneous_speed);
    pos += 2;

    BT_UNPACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->instantaneous_cadence);

    if ((p_app_value->is_instantaneous_stride_length_present) && 
        (rsc_feature.is_instantaneous_stride_length_measurement_supported))
    {
        p_gatt_value->p_value[0] |= BLE_RSCS_PRV_RSC_MEASUREMENT_FLAGS_INSTANTANEOUS_STRIDE_LENGTH_PRESENT;

        /* stride length */
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->instantaneous_stride_length);
        pos += 2;
    }

    if ((p_app_value->is_total_distance_present) && (rsc_feature.is_total_distance_measurement_supported))
    {
        p_gatt_value->p_value[0] |= BLE_RSCS_PRV_RSC_MEASUREMENT_FLAGS_TOTAL_DISTANCE_PRESENT;

        /* total distance */
        BT_PACK_LE_4_BYTE(&p_gatt_value->p_value[pos], &p_app_value->total_distance);
        pos += 4;
    }
       
    if ((p_app_value->is_running) && (rsc_feature.is_walking_or_running_status_supported))
    {
        p_gatt_value->p_value[0] |= BLE_RSCS_PRV_RSC_MEASUREMENT_FLAGS_WALKING_OR_RUNNING_STATUS_BITS;
    }

    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_rsc_feature
 * Description  : This function converts RSC Feature characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the RSC Feature  value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_rsc_feature(const st_ble_rscs_rsc_feature_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint16_t rsc_feature = 0;
    
    /* Clear the byte array */
    memset(p_gatt_value, 0x00, p_gatt_value->value_len);

    /* Instantaneous Stride Length Measurement Supported bit */
    if (p_app_value->is_instantaneous_stride_length_measurement_supported)
    {
        rsc_feature |= BLE_RSCS_PRV_RSC_FEATURE_INSTANTANEOUS_STRIDE_LENGTH_MEASUREMENT_SUPPORTED;
    }

    /* Total Distance Measurement Supported bit */
    if (p_app_value->is_total_distance_measurement_supported)
    {
        rsc_feature |= BLE_RSCS_PRV_RSC_FEATURE_TOTAL_DISTANCE_MEASUREMENT_SUPPORTED;
    }

    /* Walking or Running Status Supported bit */
    if (p_app_value->is_walking_or_running_status_supported)
    {
        rsc_feature |= BLE_RSCS_PRV_RSC_FEATURE_WALKING_OR_RUNNING_STATUS_SUPPORTED;
    }

    /* Sensor Calibration Procedure Supported bit */
    if (p_app_value->is_sensor_calibration_procedure_supported)
    {
        rsc_feature |= BLE_RSCS_PRV_RSC_FEATURE_CALIBRATION_PROCEDURE_SUPPORTED;
    }

    /* Multiple Sensor Location Supported bit */
    if (p_app_value->is_multiple_sensor_location_supported)
    {
        rsc_feature |= BLE_RSCS_PRV_RSC_FEATURE_MULTIPLE_SENSOR_LOCATIONS_SUPPORTED;
    }

    BT_PACK_LE_2_BYTE(p_gatt_value->p_value, &rsc_feature);

    p_gatt_value->value_len = BLE_RSCS_RSC_FEATURE_LEN;

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: decode_rsc_feature
 * Description  : This function converts RSC Feature characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the RSC Feature value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_rsc_feature(st_ble_rscs_rsc_feature_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint16_t rsc_feature = 0;

    if (BLE_RSCS_RSC_FEATURE_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Clear the feature bit flags */
    memset(p_app_value, 0x00, sizeof(st_ble_rscs_rsc_feature_t));

    /* copy the feature supported bits */
    BT_UNPACK_LE_2_BYTE(&rsc_feature, p_gatt_value->p_value);

    /* Instantaneous Stride Length Measurement Supported bit */
    if (rsc_feature & BLE_RSCS_PRV_RSC_FEATURE_INSTANTANEOUS_STRIDE_LENGTH_MEASUREMENT_SUPPORTED)
    {
        p_app_value->is_instantaneous_stride_length_measurement_supported = true;
    }
    else
    {
        p_app_value->is_instantaneous_stride_length_measurement_supported = false;
    }

    /* Total Distance Measurement Supported bit */
    if(rsc_feature & BLE_RSCS_PRV_RSC_FEATURE_TOTAL_DISTANCE_MEASUREMENT_SUPPORTED)
    {
        p_app_value->is_total_distance_measurement_supported = true;
    }
    else
    {
        p_app_value->is_total_distance_measurement_supported = false;
    }

    /* Walking or Running Status Supported bit */
    if (rsc_feature & BLE_RSCS_PRV_RSC_FEATURE_WALKING_OR_RUNNING_STATUS_SUPPORTED)
    {
        p_app_value->is_walking_or_running_status_supported = true;
    }
    else
    {
        p_app_value->is_walking_or_running_status_supported = false;
    }

    /* Sensor Calibration Procedure Supported bit */
    if (rsc_feature & BLE_RSCS_PRV_RSC_FEATURE_CALIBRATION_PROCEDURE_SUPPORTED)
    {
        p_app_value->is_sensor_calibration_procedure_supported = true;
    }
    else
    {
        p_app_value->is_sensor_calibration_procedure_supported = false;
    }

    /* Multiple Sensor Location Supported bit */
    if (rsc_feature & BLE_RSCS_PRV_RSC_FEATURE_MULTIPLE_SENSOR_LOCATIONS_SUPPORTED)
    {
        p_app_value->is_multiple_sensor_location_supported = true;
    }
    else
    {
        p_app_value->is_multiple_sensor_location_supported = false;
    }

    return BLE_SUCCESS;
}

/******************************************************************************************************************
 * Function Name: encode_sc_control_point
 * Description  : This function converts SC Control Point characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the SC Control Point  value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_sc_control_point (const st_ble_rscs_sc_control_point_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);
 
    /* response code */
    BT_UNPACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->response_code);

    /* request opcode */
    BT_UNPACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->request_op_code);
    
    /* response value */
    BT_UNPACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->response_value);
    
    if (BLE_RSCS_SC_CONTROL_POINT_OP_CODE_REQUEST_SUPPORTED_SENSOR_LOCATIONS == p_app_value->request_op_code)
    {
        /* response parameter - list of supported sensor locations */
        for (uint32_t i = 0; i < p_app_value->no_of_supported_sensor_locations; i++)
        {
            BT_UNPACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->response_parameter[i]);
        }
    }

    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: decode_sc_control_point
 * Description  : This function converts SC Control Point characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the SC Control Point value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : none
 **********************************************************************************************************************/
static ble_status_t decode_sc_control_point(st_ble_rscs_sc_control_point_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t                        pos            = 0;
    ble_status_t                   ret            = BLE_SUCCESS;
    st_ble_rscs_sc_control_point_t temp_app_value = { 0 };

    BT_UNPACK_LE_1_BYTE(&temp_app_value.op_code,&p_gatt_value->p_value[pos]);
    pos += 1;
    
    if (BLE_RSCS_SC_CONTROL_POINT_OP_CODE_SET_CUMULATIVE_VALUE == temp_app_value.op_code)
    {
        BT_UNPACK_LE_4_BYTE(&temp_app_value.cumulative_value, &p_gatt_value->p_value[pos]);
        pos += 4;
    }
    else if (BLE_RSCS_SC_CONTROL_POINT_OP_CODE_UPDATE_SENSOR_LOCATION == temp_app_value.op_code)
    {
        BT_UNPACK_LE_1_BYTE(&temp_app_value.sensor_location_value, &p_gatt_value->p_value[pos]);
        pos += 1;
    }
    else
    {
        /* BLE_RSCS_SC_CONTROL_POINT_OP_CODE_START_SENSOR_CALIBRATION or 
        BLE_RSCS_SC_CONTROL_POINT_OP_CODE_REQUEST_SUPPORTED_SENSOR_LOCATIONS or 
        Invalid opcode - Do nothing*/
    }
    
    if ((p_gatt_value->value_len <= BLE_RSCS_SC_CONTROL_POINT_LEN) && (p_gatt_value->value_len == pos))
    {
        memcpy(p_app_value, &temp_app_value, sizeof(st_ble_rscs_sc_control_point_t));

        ret = BLE_SUCCESS;
    }
    else
    {
        ret = BLE_RSCS_PRV_WRITE_REQUEST_REJECTED;
    }

    return ret;
}

/***********************************************************************************************************************
 * Function Name: rscs_cp_event_cb
 * Description  : This function is callback to the SC Control Point events.
 * Arguments    : event  control point event
 * Return Value : none
 **********************************************************************************************************************/
static void rscs_cp_event_cb(uint8_t event)
{
    st_ble_rscs_rsc_feature_t rsc_feature = { 0 };
    st_ble_rscs_sc_control_point_t rscs_sc_control_point_response;

    R_BLE_RSCS_GetRscFeature(&rsc_feature);

    st_ble_rscs_evt_data_t evt_data =
    {
        .conn_hdl  = gs_conn_hdl,
        .param_len = sizeof(gs_sc_control_point),
        .p_param   = &gs_sc_control_point,
    };

    rscs_sc_control_point_response.request_op_code = gs_sc_control_point.op_code;
    rscs_sc_control_point_response.response_code   = BLE_RSCS_SC_CONTROL_POINT_OP_CODE_RESPONSE_CODE;

    switch (gs_sc_control_point.op_code)
    {
        case BLE_RSCS_SC_CONTROL_POINT_OP_CODE_SET_CUMULATIVE_VALUE:
        {
            if (rsc_feature.is_total_distance_measurement_supported)
            {
                gs_rscs_cb(BLE_RSCS_EVENT_SC_CONTROL_POINT_WRITE_REQ, BLE_SUCCESS, &evt_data);
            }
            else
            {
                rscs_sc_control_point_response.response_value  = 
                    BLE_RSCS_SC_CONTROL_POINT_RESPONSE_VALUE_OPERATION_FAILED;

                R_BLE_RSCS_IndicateScControlPoint(gs_conn_hdl, &rscs_sc_control_point_response);
             }
        }
        break;

        case BLE_RSCS_SC_CONTROL_POINT_OP_CODE_START_SENSOR_CALIBRATION:
        {
            if (rsc_feature.is_sensor_calibration_procedure_supported)
            {
                gs_rscs_cb(BLE_RSCS_EVENT_SC_CONTROL_POINT_WRITE_REQ, BLE_SUCCESS, &evt_data);
            }
            else
            {
                rscs_sc_control_point_response.response_value  = 
                    BLE_RSCS_SC_CONTROL_POINT_RESPONSE_VALUE_OPERATION_FAILED;

                R_BLE_RSCS_IndicateScControlPoint(gs_conn_hdl, &rscs_sc_control_point_response);
            }
        }
        break;

        case BLE_RSCS_SC_CONTROL_POINT_OP_CODE_UPDATE_SENSOR_LOCATION:
        {
            if (rsc_feature.is_multiple_sensor_location_supported)
            {
                gs_rscs_cb(BLE_RSCS_EVENT_SC_CONTROL_POINT_WRITE_REQ, BLE_SUCCESS, &evt_data);
            }
            else
            {
                rscs_sc_control_point_response.response_value =
                    BLE_RSCS_SC_CONTROL_POINT_RESPONSE_VALUE_OPERATION_FAILED,

                R_BLE_RSCS_IndicateScControlPoint(gs_conn_hdl, &rscs_sc_control_point_response);
            }
        }
        break;

        case BLE_RSCS_SC_CONTROL_POINT_OP_CODE_REQUEST_SUPPORTED_SENSOR_LOCATIONS:
        {
            if (rsc_feature.is_multiple_sensor_location_supported)
            {
                gs_rscs_cb(BLE_RSCS_EVENT_SC_CONTROL_POINT_WRITE_REQ, BLE_SUCCESS, &evt_data);
            }
            else
            {
                rscs_sc_control_point_response.response_value  = 
                    BLE_RSCS_SC_CONTROL_POINT_RESPONSE_VALUE_OPERATION_FAILED;

                R_BLE_RSCS_IndicateScControlPoint(gs_conn_hdl, &rscs_sc_control_point_response);
            }
        }
        break;

        default:
        {
            /* Op code not supported */
            rscs_sc_control_point_response.response_value  = 
                BLE_RSCS_SC_CONTROL_POINT_RESPONSE_VALUE_OP_CODE_NOT_SUPPORTED;

            R_BLE_RSCS_IndicateScControlPoint(gs_conn_hdl, &rscs_sc_control_point_response);
        }
        break;
    }
}

/***********************************************************************************************************************
 * Function Name: evt_write_req_sc_control_point
 * Description  : This function handles the SC Control Point characteristic write request event.
 * Arguments    : conn_hdl - connection handle
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : none
 **********************************************************************************************************************/
static void evt_write_req_sc_control_point (uint16_t conn_hdl, st_ble_gatt_value_t *p_gatt_value)
{
    ble_status_t ret;
    uint16_t cli_cfg;

    if (gs_rscs_sc_cp_in_progress)
    {
        /* Previous Opcode in progress, send error response */
        R_BLE_GATTS_SendErrRsp(BLE_RSCS_PRV_PROCEDURE_ALREADY_IN_PROGRESS);
        return;
    }

    /* Check if Indication Enabled for the Control Point */
    get_cli_cnfg(conn_hdl, BLE_RSCS_SC_CONTROL_POINT_CLI_CNFG_DESC_HDL, &cli_cfg);

    if (cli_cfg & BLE_GATTS_CLI_CNFG_INDICATION)
    {
        /* SC Control Point Indication Enabled */
        ret = decode_sc_control_point(&gs_sc_control_point, p_gatt_value);

        if(BLE_SUCCESS == ret)
        {
            gs_conn_hdl = conn_hdl;

            /* Set an event to execute the control point opcode on next schedule  */
            R_BLE_SetEvent(BLE_RSCS_PRV_SCCP_EVENT_ID, rscs_cp_event_cb);

            gs_rscs_sc_cp_in_progress = true;
        }
        else
        {
            R_BLE_GATTS_SendErrRsp(ret);
        }
    }
    else
    {
        /* SC Control Point Indication Disabled, Send Error Response */
        R_BLE_GATTS_SendErrRsp(BLE_RSCS_PRV_CLIENT_CHARACTERISTIC_CONFIGURATION_DESCRIPTOR_IMPROPERLY_CONFIGURED);
    }
}

/***********************************************************************************************************************
 * Function Name: rscs_gatt_db_cb
 * Description  : Callback function for Running Speed and Cadence GATT Server events.
 * Arguments    : conn_hdl - handle to the connection
 *                p_params - pointer to GATTS db parameter
 * Return Value : none
 **********************************************************************************************************************/
static void rscs_gatts_db_cb (uint16_t conn_hdl, st_ble_gatts_db_params_t *p_params) // @suppress("Function length")
{
    switch (p_params->db_op)
    {
        case BLE_GATTS_OP_CHAR_PEER_WRITE_REQ:
        {
            if (BLE_RSCS_SC_CONTROL_POINT_VAL_HDL == p_params->attr_hdl)
            {
                evt_write_req_sc_control_point(conn_hdl, &p_params->value);
            }
        } 
        break;

        case BLE_GATTS_OP_CHAR_PEER_CLI_CNFG_WRITE_REQ:
        {
            uint16_t cli_cnfg;

            st_ble_rscs_evt_data_t evt_data = 
            {
                .conn_hdl  = conn_hdl,
                .param_len = 0,
                .p_param   = NULL,
            };

            BT_UNPACK_LE_2_BYTE(&cli_cnfg, p_params->value.p_value);

            if (BLE_RSCS_RSC_MEASUREMENT_CLI_CNFG_DESC_HDL == p_params->attr_hdl)
            {
                if (BLE_GATTS_CLI_CNFG_NOTIFICATION == cli_cnfg)
                {
                    gs_rscs_cb(BLE_RSCS_EVENT_RSC_MEASUREMENT_CLI_CNFG_ENABLED, BLE_SUCCESS, &evt_data);
                }
                else
                {
                    gs_rscs_cb(BLE_RSCS_EVENT_RSC_MEASUREMENT_CLI_CNFG_DISABLED, BLE_SUCCESS, &evt_data);
                }
            }
            else if (BLE_RSCS_SC_CONTROL_POINT_CLI_CNFG_DESC_HDL == p_params->attr_hdl)
            {
                if (BLE_GATTS_CLI_CNFG_INDICATION == cli_cnfg)
                {
                    gs_rscs_cb(BLE_RSCS_EVENT_SC_CONTROL_POINT_CLI_CNFG_ENABLED, BLE_SUCCESS, &evt_data);
                }
                else
                {
                    gs_rscs_cb(BLE_RSCS_EVENT_SC_CONTROL_POINT_CLI_CNFG_DISABLED, BLE_SUCCESS, &evt_data);
                }
            }
            else
            {
                /* Do nothing. */
            }
        } 
        break;

        default:
        {
            /* Do nothing. */
        } 
        break;
    }
}

/***********************************************************************************************************************
 * Function Name: rscs_gatts_cb
 * Description  : Callback function for the GATT Server events.
 * Arguments    : type - event id
 *                result - ble status
 *                p_data - pointer to the event data
 * Return Value : none
 **********************************************************************************************************************/
static void rscs_gatts_cb(uint16_t type, ble_status_t result, st_ble_gatts_evt_data_t *p_data)
{
    switch (type)
    {
        case BLE_GATTS_EVENT_DB_ACCESS_IND:
        {
            /* Type cast void * to st_ble_gatts_db_access_evt_t * */
            st_ble_gatts_db_access_evt_t *p_db_access_evt_param = (st_ble_gatts_db_access_evt_t *) p_data->p_param;

            rscs_gatts_db_cb(p_data->conn_hdl, p_db_access_evt_param->p_params);
        } 
        break;

        case BLE_GATTS_EVENT_HDL_VAL_CNF:
        {
            /* Type cast void * to st_ble_gatts_cfm_evt_t * */
            st_ble_gatts_cfm_evt_t *p_cfm_evt_param = (st_ble_gatts_cfm_evt_t *) p_data->p_param;

            if (BLE_RSCS_SC_CONTROL_POINT_VAL_HDL == p_cfm_evt_param->attr_hdl)
            {
                st_ble_rscs_evt_data_t evt_data =
                {
                    .conn_hdl  = p_data->conn_hdl,
                    .param_len = 0,
                    .p_param   = NULL,
                };
                gs_rscs_cb(BLE_RSCS_EVENT_SC_CONTROL_POINT_HDL_VAL_CNF, result, &evt_data);

                /* Reset the flag */
                gs_rscs_sc_cp_in_progress = false;
            }
        } 
        break;

        default:
        {
            /* Do nothing. */
        } 
        break;
    }
}

ble_status_t R_BLE_RSCS_Init (const st_ble_rscs_init_param_t *p_param) // @suppress("API function naming")
{
    if (NULL == p_param)
    {
        return BLE_ERR_INVALID_PTR;
    }

    if (NULL == p_param->cb)
    {
        return BLE_ERR_INVALID_ARG;
    }

    R_BLE_GATTS_RegisterCb(rscs_gatts_cb, 1);

    gs_rscs_cb = p_param->cb;

    return BLE_SUCCESS;
}

ble_status_t R_BLE_RSCS_Connect (uint16_t conn_hdl, const st_ble_rscs_connect_param_t *p_param) // @suppress("API function naming")
{
    if (BLE_GAP_INVALID_CONN_HDL == conn_hdl)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (NULL != p_param)
    {
        set_cli_cnfg(conn_hdl, BLE_RSCS_RSC_MEASUREMENT_CLI_CNFG_DESC_HDL, p_param->rsc_measurement_cli_cnfg);
        set_cli_cnfg(conn_hdl, BLE_RSCS_SC_CONTROL_POINT_CLI_CNFG_DESC_HDL, p_param->sc_control_point_cli_cnfg);
    }

    return BLE_SUCCESS;
}

ble_status_t R_BLE_RSCS_Disconnect (uint16_t conn_hdl, st_ble_rscs_disconnect_param_t *p_param) // @suppress("API function naming")
{
    if (BLE_GAP_INVALID_CONN_HDL == conn_hdl)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (NULL != p_param)
    {
        get_cli_cnfg(conn_hdl, BLE_RSCS_RSC_MEASUREMENT_CLI_CNFG_DESC_HDL, &p_param->rsc_measurement_cli_cnfg);
        get_cli_cnfg(conn_hdl, BLE_RSCS_SC_CONTROL_POINT_CLI_CNFG_DESC_HDL, &p_param->sc_control_point_cli_cnfg);
    }

    return BLE_SUCCESS;
}

ble_status_t R_BLE_RSCS_NotifyRscMeasurement (uint16_t conn_hdl, const st_ble_rscs_rsc_measurement_t *p_app_value) // @suppress("API function naming")
{
    ble_status_t ret;
    uint16_t cli_cnfg;

    if (NULL == p_app_value)
    {
        return BLE_ERR_INVALID_PTR;
    }

    ret = get_cli_cnfg(conn_hdl, BLE_RSCS_RSC_MEASUREMENT_CLI_CNFG_DESC_HDL, &cli_cnfg);

    if (BLE_SUCCESS != ret)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if ((cli_cnfg & BLE_GATTS_CLI_CNFG_NOTIFICATION) == 0x0000)
    {
        return BLE_ERR_INVALID_STATE;
    }

    uint8_t byte_value[BLE_RSCS_RSC_MEASUREMENT_LEN] = { 0 };
    
    st_ble_gatt_hdl_value_pair_t ntf_data =
    {
        .attr_hdl        = BLE_RSCS_RSC_MEASUREMENT_VAL_HDL,
        .value.p_value   = byte_value,
        .value.value_len = BLE_RSCS_RSC_MEASUREMENT_LEN,
    };

    ret = encode_rsc_measurement(p_app_value, &ntf_data.value);
    if (BLE_SUCCESS != ret)
    {
        ret = BLE_ERR_INVALID_DATA;
    }
    else
    {
        ret = R_BLE_GATTS_Notification(conn_hdl, &ntf_data);
    }

    return ret;
}

ble_status_t R_BLE_RSCS_GetRscFeature(st_ble_rscs_rsc_feature_t *p_app_value) // @suppress("API function naming")
{
    st_ble_gatt_value_t gatt_value;
    ble_status_t ret;
    
    if (NULL == p_app_value)
    {
        return BLE_ERR_INVALID_PTR;
    }
    
    ret = R_BLE_GATTS_GetAttr(BLE_GAP_INVALID_CONN_HDL, BLE_RSCS_RSC_FEATURE_VAL_HDL, &gatt_value);

    if (BLE_SUCCESS == ret)
    {
        ret = decode_rsc_feature(p_app_value, &gatt_value);
    }

    return ret;
}

ble_status_t R_BLE_RSCS_SetRscFeature(const st_ble_rscs_rsc_feature_t *p_app_value) // @suppress("API function naming")
{
    ble_status_t ret;
    uint8_t byte_value[BLE_RSCS_RSC_FEATURE_LEN] = { 0 };

    st_ble_gatt_value_t gatt_value = 
    {
        .p_value   = byte_value,
        .value_len = BLE_RSCS_RSC_FEATURE_LEN,
    };

    ret = encode_rsc_feature(p_app_value, &gatt_value);
    if (BLE_SUCCESS != ret)
    {
        ret = BLE_ERR_INVALID_DATA;
    }
    else
    {
        ret = R_BLE_GATTS_SetAttr(BLE_GAP_INVALID_CONN_HDL, BLE_RSCS_RSC_FEATURE_VAL_HDL, &gatt_value);;
    }

    return ret;
}

ble_status_t R_BLE_RSCS_GetSensorLocation (uint8_t *p_app_value) // @suppress("API function naming")
{
    st_ble_gatt_value_t gatt_value;
    ble_status_t ret;
    
    if (NULL == p_app_value)
    {
        return BLE_ERR_INVALID_PTR;
    }

    ret = R_BLE_GATTS_GetAttr(BLE_GAP_INVALID_CONN_HDL, BLE_RSCS_SENSOR_LOCATION_VAL_HDL, &gatt_value);

    if (BLE_SUCCESS == ret)
    {
        BT_UNPACK_LE_1_BYTE(p_app_value, gatt_value.p_value);
    }

    return ret;
}

ble_status_t R_BLE_RSCS_SetSensorLocation (uint8_t app_value) // @suppress("API function naming")
{
    uint8_t byte_value[BLE_RSCS_SENSOR_LOCATION_LEN] = { 0 };

    BT_PACK_LE_1_BYTE(byte_value, &app_value);

    st_ble_gatt_value_t gatt_value =
    {
        .p_value   = byte_value,
        .value_len = sizeof(app_value),
    };

    return R_BLE_GATTS_SetAttr(BLE_GAP_INVALID_CONN_HDL, BLE_RSCS_SENSOR_LOCATION_VAL_HDL, &gatt_value);
}

ble_status_t R_BLE_RSCS_IndicateScControlPoint (uint16_t conn_hdl, const st_ble_rscs_sc_control_point_t *p_app_value) // @suppress("API function naming")
{
    ble_status_t ret;
    uint16_t cli_cnfg;

    if (NULL == p_app_value)
    {
        return BLE_ERR_INVALID_PTR;
    }

    ret = get_cli_cnfg(conn_hdl, BLE_RSCS_SC_CONTROL_POINT_CLI_CNFG_DESC_HDL, &cli_cnfg);
    if (BLE_SUCCESS != ret)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if ((cli_cnfg & BLE_GATTS_CLI_CNFG_INDICATION) == 0x0000)
    {
        return BLE_ERR_INVALID_STATE;
    }
    
    uint8_t byte_value[BLE_RSCS_SC_CONTROL_POINT_LEN] = { 0 };

    st_ble_gatt_hdl_value_pair_t ind_data =
    {
        .attr_hdl        = BLE_RSCS_SC_CONTROL_POINT_VAL_HDL,
        .value.p_value   = byte_value,
        .value.value_len = BLE_RSCS_SC_CONTROL_POINT_LEN,
    };

    ret = encode_sc_control_point(p_app_value, &ind_data.value);
    if (BLE_SUCCESS != ret)
    {
        ret = BLE_ERR_INVALID_DATA;
    }
    else
    {
        ret = R_BLE_GATTS_Indication(conn_hdl, &ind_data);
    }

    return ret;
}

uint32_t R_BLE_RSCS_GetVersion(void) // @suppress("API function naming")
{
    uint32_t version;

    version = ((BLE_RSCS_PRV_VERSION_MAJOR << 16) | (BLE_RSCS_PRV_VERSION_MINOR << 8));

    return version;
}
