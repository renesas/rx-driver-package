/***********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
 * SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
 ***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_ids_record.c
 * Version : 1.0
 * Description : This module implements Insulin Delivery Service Records
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 22.03.2019 1.00 First Release
 ***********************************************************************************************************************/

/***********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 ***********************************************************************************************************************/
#include <string.h>
#include "r_ble_ids_record.h"
#include "gatt_db.h"

/* When transmitting stored data, the oldest data shall be sent first followed by
 the next oldest data until all stored data has been transferred.
 */
/***********************************************************************************************************************
 Private global variables and functions
 ***********************************************************************************************************************/
static uint16_t             gs_seq_num;
static uint16_t             gs_oldest_index;
static uint16_t             gs_newest_index;
static uint16_t             gs_num_of_records;
static st_ble_ids_record_t  gs_records[BLE_IDS_DB_MAX_NUM_OF_RECORDS];

/***********************************************************************************************************************
 * Function Name: ids_db_init
 * Description  : This function initializes the IDS record database.
 * Arguments    : none
 * Return Value : none
 **********************************************************************************************************************/
void ids_db_init(void)
{
    gs_oldest_index     = 0;
    gs_newest_index     = BLE_IDS_DB_INVALID_INDEX;
    gs_num_of_records   = 0;

    for (uint8_t i = 0; i < BLE_IDS_DB_MAX_NUM_OF_RECORDS; i++)
    {
        gs_records[i].valid         = false;
        gs_records[i].next_index    = BLE_IDS_DB_INVALID_INDEX;
        gs_records[i].prev_index    = BLE_IDS_DB_INVALID_INDEX;

        memset( &gs_records[i].history_data, 0x00, sizeof(gs_records[i].history_data));
    }

    gs_seq_num = 0;
}

/***********************************************************************************************************************
 * Function Name: ids_db_get_oldest_index
 * Description  : This function returns the oldest record index.
 * Arguments    : none
 * Return Value : gs_oldest_index - oldest record index
 **********************************************************************************************************************/
uint16_t ids_db_get_oldest_index (void)
{
    return gs_oldest_index;
}

/***********************************************************************************************************************
 * Function Name: ids_db_get_newest_index
 * Description  : This function returns the newest record index.
 * Arguments    : none
 * Return Value : gs_newest_index - newest record index
 **********************************************************************************************************************/
uint16_t ids_db_get_newest_index (void)
{
    return gs_newest_index;
}

/***********************************************************************************************************************
 * Function Name: ids_db_get_record
 * Description  : This function returns the record at the given index.
 * Arguments    : index - record index in the database
 * Return Value : record
 **********************************************************************************************************************/
st_ble_ids_record_t *ids_db_get_record (uint16_t index)
{
    if (BLE_IDS_DB_MAX_NUM_OF_RECORDS <= index)
    {
        return NULL;
    }

    if (false == gs_records[index].valid)
    {
        return NULL;
    }
    
    return &gs_records[index];
}

/***********************************************************************************************************************
 * Function Name: ids_db_store_record
 * Description  : This function adds the given record to the database.
 * Arguments    : p_history_data - Pointer to history data
 * Return Value : none
 **********************************************************************************************************************/
void ids_db_store_record(st_ble_ids_idd_history_data_t *p_history_data)
{
    /* No space to save new record, hence remove oldest one. */
    if (BLE_IDS_DB_MAX_NUM_OF_RECORDS <= gs_num_of_records)
    {
        if (NULL != p_history_data)
        {
            gs_records[gs_oldest_index].history_data.seq_num = gs_seq_num++;
            memcpy(&gs_records[gs_oldest_index].history_data, p_history_data,sizeof(gs_records[gs_oldest_index].history_data));
        }
        else
        {
            return;
        }

        gs_oldest_index = gs_records[gs_oldest_index].next_index;
        gs_records[gs_oldest_index].prev_index = gs_newest_index;
        gs_records[gs_oldest_index].next_index = BLE_IDS_DB_INVALID_INDEX;
    }
    /* Vacant space exist, save the new record to it. */
    else
    {
        for (uint8_t i = 0; i < BLE_IDS_DB_MAX_NUM_OF_RECORDS; i++)
        {
            if (false == gs_records[i].valid)
            {

                if (NULL != p_history_data)
                {
                    gs_records[i].history_data.seq_num = gs_seq_num++;
                    memcpy(&gs_records[i].history_data, p_history_data, sizeof(gs_records[i].history_data));
                }
                else
                {
                    return;
                }
                if (0 < i)
                {
                    gs_records[i].prev_index            = (uint16_t)(i-1);
                }
                gs_newest_index                         = i;
                gs_records[i].next_index                = (uint16_t)(i+1);
                gs_records[i].valid                     = true;
                gs_num_of_records++;
                break;
            }
        }
    }
}

/***********************************************************************************************************************
 * Function Name: gls_db_delete_record
 * Description  : This function deletes the record at the given index from the database.
 * Arguments    : p_measurement - glucose measurement
 *                p_context     - glucose measurement context
 * Return Value : none
 **********************************************************************************************************************/
void ids_db_delete_record (uint16_t index)
{
    st_ble_ids_record_t *p_record;

    p_record = ids_db_get_record(index);

    if (NULL != p_record)
    {
        p_record->valid = false;
        gs_num_of_records--;
    }
}
