/***********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
 * SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
 ***********************************************************************************************************************/

/**********************************************************************************************************************
 * File Name: r_ble_ids_record.h
 * Version : 1.0
 * Description: This file provides APIs to interface Glucose Service Record
 **********************************************************************************************************************/
/***********************************************************************************************************************
* History : DD.MM.YYYY Version Description
*         : 22.03.2019 1.00 First Release
**********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @file
 * @defgroup ids Insulin Delivery Service Server
 * @{
 * @ingroup profile
 * @brief   This file provides APIs to interface Insulin Delivery Service Records.
 **********************************************************************************************************************/

/***********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 ***********************************************************************************************************************/
#include "r_ble_ids.h"

/***********************************************************************************************************************
 Macro definitions
 ***********************************************************************************************************************/
#ifndef R_BLE_IDS_RECORD_H
#define R_BLE_IDS_RECORD_H

#define BLE_IDS_DB_MAX_NUM_OF_RECORDS (10)
#define BLE_IDS_DB_INVALID_INDEX      (0xFFFF)

typedef struct
{
    bool                                     valid;
    uint16_t                                 next_index;
    uint16_t                                 prev_index;
    st_ble_ids_idd_history_data_t            history_data;
} st_ble_ids_record_t;

void ids_db_init (void);

uint16_t ids_db_get_oldest_index (void);

uint16_t ids_db_get_newest_index (void);

st_ble_ids_record_t *ids_db_get_record (uint16_t index);

void ids_db_store_record (st_ble_ids_idd_history_data_t *p_history_data);

void ids_db_delete_record (uint16_t index);

#endif /* R_BLE_IDS_RECORD_H */

/** @} */
