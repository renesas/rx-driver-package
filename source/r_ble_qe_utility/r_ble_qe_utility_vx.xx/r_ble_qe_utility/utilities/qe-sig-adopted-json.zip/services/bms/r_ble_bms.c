/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_bms.c
 * Version : 1.0
 * Description : The source file for Bond Management Service service.
 **********************************************************************************************************************/

#include <string.h>
#include "r_ble_bms.h"
#include "profile_cmn/r_ble_servs_if.h"
#include "gatt_db.h"

#ifndef UNUSED_ARG
#define UNUSED_ARG(arg)         (void)(arg)
#endif /* UNUSED_ARG */

static st_ble_servs_info_t gs_servs_info;

/*----------------------------------------------------------------------------------------------------------------------
    Bond Management Control Point characteristic
----------------------------------------------------------------------------------------------------------------------*/

static ble_status_t decode_st_ble_bms_cp_t(st_ble_bms_cp_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    p_app_value->op_code      = p_gatt_value->p_value[0];
    p_app_value->operand.data = &p_gatt_value->p_value[1];
    p_app_value->operand.len  = (uint16_t)(p_gatt_value->value_len - 1);
    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_bms_cp_t(const st_ble_bms_cp_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;

    p_gatt_value->p_value[pos++] = p_app_value->op_code;
    memcpy(&p_gatt_value->p_value[pos], p_app_value->operand.data, p_app_value->operand.len);
    pos += p_app_value->operand.len;

    p_gatt_value->value_len = (uint16_t)pos;

    return BLE_SUCCESS;
}

static void write_req_cp(const void *p_attr, uint16_t conn_hdl, ble_status_t result, const st_ble_bms_cp_t *p_app_value)
{
    UNUSED_ARG(p_attr);
    UNUSED_ARG(conn_hdl);
    UNUSED_ARG(result);

    if ((BLE_BMS_CP_OP_CODE_DELETE_BOND_OF_REQUESTING_DEVICE_LE_TRANSPORT_ONLY != p_app_value->op_code) &&
        (BLE_BMS_CP_OP_CODE_DELETE_ALL_BONDS_ON_SERVER_LE_TRANSPORT_ONLY != p_app_value->op_code) &&
        (BLE_BMS_CP_OP_CODE_DELETE_ALL_BUT_THE_ACTIVE_BOND_ON_SERVER_LE_TRANSPORT_ONLY != p_app_value->op_code))
    {
        R_BLE_GATTS_SendErrRsp(BLE_BMS_OP_CODE_NOT_SUPPORTED_ERROR);
    }
}

/* Bond Management Control Point characteristic definition */
static const st_ble_servs_char_info_t gs_cp_char = {
    .start_hdl    = BLE_BMS_CP_DECL_HDL,
    .end_hdl      = BLE_BMS_CP_VAL_HDL,
    .char_idx     = BLE_BMS_CP_IDX,
    .app_size     = sizeof(st_ble_bms_cp_t),
    .db_size      = BLE_BMS_CP_LEN,
    .write_req_cb = (ble_servs_attr_write_cmd_t)write_req_cp,
    .decode       = (ble_servs_attr_decode_t)decode_st_ble_bms_cp_t,
    .encode       = (ble_servs_attr_encode_t)encode_st_ble_bms_cp_t,
};

/*----------------------------------------------------------------------------------------------------------------------
    Bond Management Features characteristic
----------------------------------------------------------------------------------------------------------------------*/

static ble_status_t decode_st_ble_bms_feat_t(st_ble_bms_feat_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    p_app_value->is_delete_bond_of_current_connection_le_transport_only_supported    = !!(p_gatt_value->p_value[0] & 0x10);
    p_app_value->is_authorization_code_required_to_delete_bond_of_current_connection = !!(p_gatt_value->p_value[0] & 0x20);

    p_app_value->is_remove_all_bonds_on_server_le_transport_only_supported    = !!(p_gatt_value->p_value[1] & 0x04);
    p_app_value->is_authorization_code_required_to_remove_all_bonds_on_server = !!(p_gatt_value->p_value[1] & 0x08);

    p_app_value->is_remove_all_but_the_active_bond_on_server_le_transport_only_supported    = !!(p_gatt_value->p_value[2] & 0x01);
    p_app_value->is_authorization_code_required_to_remove_all_but_the_active_bond_on_server = !!(p_gatt_value->p_value[2] & 0x02);
    p_app_value->is_identify_yourself_supported                                             = !!(p_gatt_value->p_value[2] & 0x04);
    p_app_value->is_feature_extension                                                       = !!(p_gatt_value->p_value[2] & 0x80);

    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_bms_feat_t(const st_ble_bms_feat_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    memset(p_gatt_value->p_value, 0x00, BLE_BMS_FEAT_LEN);

    p_gatt_value->p_value[0] = (uint8_t)((p_app_value->is_delete_bond_of_current_connection_le_transport_only_supported ? 0x10 : 0x00)
                             | (p_app_value->is_authorization_code_required_to_delete_bond_of_current_connection ? 0x20 : 0x00));

    p_gatt_value->p_value[1] = (uint8_t)((p_app_value->is_remove_all_bonds_on_server_le_transport_only_supported ? 0x04 : 0x00)
                             | (p_app_value->is_authorization_code_required_to_remove_all_bonds_on_server ? 0x08 : 0x00));

    p_gatt_value->p_value[2] = (uint8_t)((p_app_value->is_remove_all_but_the_active_bond_on_server_le_transport_only_supported ? 0x01 : 0x00)
                             | (p_app_value->is_authorization_code_required_to_remove_all_but_the_active_bond_on_server ? 0x02 : 0x00)
                             | (p_app_value->is_identify_yourself_supported ? 0x04 : 0x00)
                             | (p_app_value->is_feature_extension ? 0x80 : 0x00));
    
    p_gatt_value->value_len = BLE_BMS_FEAT_LEN;

    return BLE_SUCCESS;
}

/* Bond Management Features characteristic definition */
static const st_ble_servs_char_info_t gs_feat_char = {
    .start_hdl    = BLE_BMS_FEAT_DECL_HDL,
    .end_hdl      = BLE_BMS_FEAT_VAL_HDL,
    .char_idx     = BLE_BMS_FEAT_IDX,
    .app_size     = sizeof(st_ble_bms_feat_t),
    .db_size      = BLE_BMS_FEAT_LEN,
    .decode       = (ble_servs_attr_decode_t)decode_st_ble_bms_feat_t,
    .encode       = (ble_servs_attr_encode_t)encode_st_ble_bms_feat_t,
};

ble_status_t R_BLE_BMS_SetFeat(const st_ble_bms_feat_t *p_value)
{
    return R_BLE_SERVS_SetChar(&gs_feat_char, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_BMS_GetFeat(st_ble_bms_feat_t *p_value)
{
    return R_BLE_SERVS_GetChar(&gs_feat_char, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Bond Management Service server
----------------------------------------------------------------------------------------------------------------------*/

/* Bond Management Service characteristics definition */
static const st_ble_servs_char_info_t *gspp_chars[] = {
    &gs_cp_char,
    &gs_feat_char,
};

/* Bond Management Service service definition */
static st_ble_servs_info_t gs_servs_info = {
    .pp_chars     = gspp_chars,
    .num_of_chars = ARRAY_SIZE(gspp_chars),
};

ble_status_t R_BLE_BMS_Init(ble_servs_app_cb_t cb)
{
    if (NULL == cb)
    {
        return BLE_ERR_INVALID_PTR;
    }

    gs_servs_info.cb = cb;

    return R_BLE_SERVS_RegisterServer(&gs_servs_info);
}
