/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_bms.h
 * Version : 1.0
 * Description : The header file for Bond Management Service service.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 31.12.2999 1.00 First Release
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @file
 * @defgroup bms Bond Management Service Service
 * @{
 * @ingroup profile
 * @brief   This Specification proposes that this service will enable users to manage their bonds on devices with a limited user interface.
 **********************************************************************************************************************/
#include "r_ble_rx23w_if.h"
#include "profile_cmn/r_ble_servs_if.h"
#include "gatt_db.h"

#ifndef R_BLE_BMS_H
#define R_BLE_BMS_H

/*----------------------------------------------------------------------------------------------------------------------
    Bond Management Control Point Characteristic
----------------------------------------------------------------------------------------------------------------------*/
/***************************************************************************//**
 * @brief Bond Management Control Point Op Code enumeration.
*******************************************************************************/
typedef enum {
    BLE_BMS_CP_OP_CODE_DELETE_BOND_OF_REQUESTING_DEVICE_LE_TRANSPORT_ONLY = 3, /**< Delete bond of requesting device (LE transport only) */
    BLE_BMS_CP_OP_CODE_DELETE_ALL_BONDS_ON_SERVER_LE_TRANSPORT_ONLY = 6, /**< Delete all bonds on server (LE transport only) */
    BLE_BMS_CP_OP_CODE_DELETE_ALL_BUT_THE_ACTIVE_BOND_ON_SERVER_LE_TRANSPORT_ONLY = 9, /**< Delete all but the active bond on server (LE transport only) */
} e_ble_bms_cp_op_code_t;

/***************************************************************************//**
 * @brief Bond Management Control Point value structure.
*******************************************************************************/
typedef struct {
    uint8_t op_code; /**< Op Code */
    st_ble_seq_data_t operand; /**< Operand */
} st_ble_bms_cp_t;

/*----------------------------------------------------------------------------------------------------------------------
    Bond Management Features Characteristic
----------------------------------------------------------------------------------------------------------------------*/
/***************************************************************************//**
 * @brief Bond Management Features value structure.
*******************************************************************************/
typedef struct {
    bool is_delete_bond_of_current_connection_le_transport_only_supported; /**< Delete bond of current connection (LE transport only) supported */
    bool is_authorization_code_required_to_delete_bond_of_current_connection; /**< Authorization Code required to delete bond of current connection */
    bool is_remove_all_bonds_on_server_le_transport_only_supported; /**< Remove all bonds on server (LE transport only) supported */
    bool is_authorization_code_required_to_remove_all_bonds_on_server; /**< Authorization Code required to remove all bonds on server */
    bool is_remove_all_but_the_active_bond_on_server_le_transport_only_supported; /**< Remove all but the active bond on server (LE transport only) supported */
    bool is_authorization_code_required_to_remove_all_but_the_active_bond_on_server; /**< Authorization Code required to remove all but the active bond on server */
    bool is_identify_yourself_supported; /**< Identify yourself supported */
    bool is_feature_extension; /**< Feature Extension */
} st_ble_bms_feat_t;

/***************************************************************************//**
 * @brief     Set Bond Management Features characteristic value to the local GATT database.
 * @param[in] p_value  Characteristic value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_BMS_SetFeat(const st_ble_bms_feat_t *p_value);

/***************************************************************************//**
 * @brief     Get Bond Management Features characteristic value from the local GATT database.
 * @param[in] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_BMS_GetFeat(st_ble_bms_feat_t *p_value);

/*----------------------------------------------------------------------------------------------------------------------
    Bond Management Service Service
----------------------------------------------------------------------------------------------------------------------*/

/***************************************************************************//**
 * @brief Response if unsupported Op Code is received
*******************************************************************************/
#define BLE_BMS_OP_CODE_NOT_SUPPORTED_ERROR (BLE_ERR_GROUP_GATT | 0x80)

/***************************************************************************//**
 * @brief Response if unable to complete a procedure for any reason
*******************************************************************************/
#define BLE_BMS_OPERATION_FAILED_ERROR (BLE_ERR_GROUP_GATT | 0x81)

/***************************************************************************//**
 * @brief Bond Management Service characteristic Index.
*******************************************************************************/
typedef enum {
    BLE_BMS_CP_IDX,
    BLE_BMS_FEAT_IDX,
} e_ble_bms_char_idx_t;

/***************************************************************************//**
 * @brief Bond Management Service event type.
*******************************************************************************/
typedef enum {
    /* Bond Management Control Point */
    BLE_BMS_EVENT_CP_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_BMS_CP_IDX, BLE_SERVS_WRITE_REQ),
    BLE_BMS_EVENT_CP_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_BMS_CP_IDX, BLE_SERVS_WRITE_COMP),
    /* Bond Management Features */
    BLE_BMS_EVENT_FEAT_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_BMS_FEAT_IDX, BLE_SERVS_READ_REQ),
} e_ble_bms_event_t;

/***************************************************************************//**
 * @brief     Initialize Bond Management Service service.
 * @param[in] cb Service callback.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_BMS_Init(ble_servs_app_cb_t cb);

#endif /* R_BLE_BMS_H */

/** @} */
