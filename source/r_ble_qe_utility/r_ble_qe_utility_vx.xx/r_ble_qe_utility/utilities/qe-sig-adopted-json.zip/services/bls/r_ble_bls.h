/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_bls.h
 * Version : 1.0
 * Description : The header file for Blood Pressure service.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 31.12.2999 1.00 First Release
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @file
 * @defgroup bls Blood Pressure Service Server
 * @{
 * @ingroup profile
 * @brief   This service exposes blood pressure and other data from a blood pressure monitor intended for healthcare applications.
 **********************************************************************************************************************/
#include "profile_cmn/r_ble_servs_if.h"
#include "gatt_db.h"

#ifndef R_BLE_BLS_H
#define R_BLE_BLS_H

/*----------------------------------------------------------------------------------------------------------------------
    Blood Pressure Measurement Characteristic
----------------------------------------------------------------------------------------------------------------------*/

      
      
      
      
      
/***************************************************************************//**
 * @brief Blood Pressure Measurement User ID enumeration.
*******************************************************************************/
typedef enum {
    BLE_BLS_MEAS_USER_ID_UNKNOWN_USER = 255, /**< Unknown User */
} e_ble_bls_meas_user_id_t;

      
/***************************************************************************//**
 * @brief Blood Pressure Measurement Pulse Rate Range enumeration.
*******************************************************************************/
typedef enum {
    BLE_BLS_MEAS_PULSE_RATE_RANGE_PULSE_RATE_IS_WITHIN_THE_RANGE = 0, /**< Pulse rate is within the range */
    BLE_BLS_MEAS_PULSE_RATE_RANGE_PULSE_RATE_EXCEEDS_UPPER_LIMIT = 1, /**< Pulse rate exceeds upper limit */
    BLE_BLS_MEAS_PULSE_RATE_RANGE_PULSE_RATE_IS_LESS_THAN_LOWER_LIMIT = 2, /**< Pulse rate is less than lower limit */
} e_ble_bls_meas_pulse_rate_range_t;

      
/***************************************************************************//**
 * @brief Blood Pressure Measurement Flags value structure.
*******************************************************************************/
typedef struct {
    bool is_blood_pressure_units_kpa; /**< Blood Pressure Units Flag is mmHg(false) or kPa(true) */
    bool is_time_stamp_present; /**< Time Stamp Flag */
    bool is_pulse_rate_present; /**< Pulse Rate Flag */
    bool is_user_id_present; /**< User ID Flag */
    bool is_measurement_status_present; /**< Measurement Status Flag */
} st_ble_bls_meas_flags_t;

      
/***************************************************************************//**
 * @brief Blood Pressure Measurement Measurement Status value structure.
*******************************************************************************/
typedef struct {
    bool is_body_movement_detected; /**< Body Movement Detected */
    bool is_cuff_fit_loose; /**< Cuff Fit is Loose */
    bool is_irregular_pulse_detected; /**< Irregular Pulse Detected */
    uint8_t pulse_rate_range; /**< Pulse Rate Range */
    bool is_measurement_position_improper; /**< Measurement Position Improper */
} st_ble_bls_meas_measurement_status_t;

/***************************************************************************//**
 * @brief Blood Pressure Measurement value structure.
*******************************************************************************/
typedef struct {
    st_ble_bls_meas_flags_t flags; /**< Flags */
    st_ble_ieee11073_sfloat_t systolic; /**< Blood Pressure Measurement Compound Value - Systolic (mmHg or kPa) */
    st_ble_ieee11073_sfloat_t diastolic; /**< Blood Pressure Measurement Compound Value - Diastolic (mmHg) */
    st_ble_ieee11073_sfloat_t mean_arterial_pressure; /**< Blood Pressure Measurement Compound Value - Mean Arterial Pressure (mmHg or kPa) */
    st_ble_date_time_t time_stamp; /**< Time Stamp */
    st_ble_ieee11073_sfloat_t pulse_rate; /**< Pulse Rate */
    uint8_t user_id; /**< User ID */
    st_ble_bls_meas_measurement_status_t measurement_status; /**< Measurement Status */
} st_ble_bls_meas_t;

/***************************************************************************//**
 * @brief     Send indication of  Blood Pressure Measurement characteristic value to the remote device.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value  Characteristic value to send.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_BLS_IndicateMeas(uint16_t conn_hdl, const st_ble_bls_meas_t *p_value);

/***************************************************************************//**
 * @brief     Set Blood Pressure Measurement cli cnfg descriptor value to the local GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_BLS_SetMeasCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Get Blood Pressure Measurement cli cnfg descriptor value from the local GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_BLS_GetMeasCliCnfg(uint16_t conn_hdl, uint16_t *p_value);

/*----------------------------------------------------------------------------------------------------------------------
    Intermediate Cuff Pressure Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/***************************************************************************//**
 * @brief     Send notification of  Intermediate Cuff Pressure characteristic value to the remote device.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value  Characteristic value to send.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_BLS_NotifyIntermediateCuffPressure(uint16_t conn_hdl, const st_ble_bls_meas_t *p_value);

/***************************************************************************//**
 * @brief     Set Intermediate Cuff Pressure cli cnfg descriptor value to the local GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_BLS_SetIntermediateCuffPressureCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Get Intermediate Cuff Pressure cli cnfg descriptor value from the local GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_BLS_GetIntermediateCuffPressureCliCnfg(uint16_t conn_hdl, uint16_t *p_value);

/*----------------------------------------------------------------------------------------------------------------------
    Blood Pressure Feature Characteristic
----------------------------------------------------------------------------------------------------------------------*/
/***************************************************************************//**
 * @brief Blood Pressure Feature value structure.
*******************************************************************************/
typedef struct {
    bool is_body_movement_detection_support_bit; /**< Body Movement Detection Support bit */
    bool is_cuff_fit_detection_support_bit; /**< Cuff Fit Detection Support bit */
    bool is_irregular_pulse_detection_support_bit; /**< Irregular Pulse Detection Support bit */
    bool is_pulse_rate_range_detection_support_bit; /**< Pulse Rate Range Detection Support bit */
    bool is_measurement_position_detection_support_bit; /**< Measurement Position Detection Support bit */
    bool is_multiple_bond_support_bit; /**< Multiple Bond Support bit */
} st_ble_bls_feat_t;

/***************************************************************************//**
 * @brief     Set Blood Pressure Feature characteristic value to the local GATT database.
 * @param[in] p_value  Characteristic value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_BLS_SetFeat(const st_ble_bls_feat_t *p_value);

/***************************************************************************//**
 * @brief     Get Blood Pressure Feature characteristic value from the local GATT database.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_BLS_GetFeat(st_ble_bls_feat_t *p_value);

/*----------------------------------------------------------------------------------------------------------------------
    Blood Pressure Service
----------------------------------------------------------------------------------------------------------------------*/

/***************************************************************************//**
 * @brief Blood Pressure characteristic Index.
*******************************************************************************/
typedef enum {
    BLE_BLS_MEAS_IDX,
    BLE_BLS_MEAS_CLI_CNFG_IDX,
    BLE_BLS_INTERMEDIATE_CUFF_PRESSURE_IDX,
    BLE_BLS_INTERMEDIATE_CUFF_PRESSURE_CLI_CNFG_IDX,
    BLE_BLS_FEAT_IDX,
} e_ble_bls_char_idx_t;

/***************************************************************************//**
 * @brief Blood Pressure event type.
*******************************************************************************/
typedef enum {
    /* Blood Pressure Measurement */
    BLE_BLS_EVENT_MEAS_HDL_VAL_CNF = BLE_SERVS_ATTR_EVENT(BLE_BLS_MEAS_IDX, BLE_SERVS_HDL_VAL_CNF),
    BLE_BLS_EVENT_MEAS_CLI_CNFG_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_BLS_MEAS_CLI_CNFG_IDX, BLE_SERVS_WRITE_REQ),
    BLE_BLS_EVENT_MEAS_CLI_CNFG_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_BLS_MEAS_CLI_CNFG_IDX, BLE_SERVS_WRITE_COMP),
    BLE_BLS_EVENT_MEAS_CLI_CNFG_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_BLS_MEAS_CLI_CNFG_IDX, BLE_SERVS_READ_REQ),
    /* Intermediate Cuff Pressure */
    BLE_BLS_EVENT_INTERMEDIATE_CUFF_PRESSURE_CLI_CNFG_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_BLS_INTERMEDIATE_CUFF_PRESSURE_CLI_CNFG_IDX, BLE_SERVS_WRITE_REQ),
    BLE_BLS_EVENT_INTERMEDIATE_CUFF_PRESSURE_CLI_CNFG_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_BLS_INTERMEDIATE_CUFF_PRESSURE_CLI_CNFG_IDX, BLE_SERVS_WRITE_COMP),
    BLE_BLS_EVENT_INTERMEDIATE_CUFF_PRESSURE_CLI_CNFG_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_BLS_INTERMEDIATE_CUFF_PRESSURE_CLI_CNFG_IDX, BLE_SERVS_READ_REQ),
    /* Blood Pressure Feature */
    BLE_BLS_EVENT_FEAT_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_BLS_FEAT_IDX, BLE_SERVS_READ_REQ),
} e_ble_bls_event_t;

/***************************************************************************//**
 * @brief     Initialize Blood Pressure service.
 * @param[in] cb Service callback.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_BLS_Init(ble_servs_app_cb_t cb);

#endif /* R_BLE_BLS_H */

/** @} */
