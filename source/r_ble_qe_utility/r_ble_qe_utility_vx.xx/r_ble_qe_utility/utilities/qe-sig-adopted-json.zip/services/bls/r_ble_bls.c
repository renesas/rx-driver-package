/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_bls.c
 * Version : 1.0
 * Description : The source file for Blood Pressure service.
 **********************************************************************************************************************/

#include <string.h>
#include "r_ble_bls.h"
#include "profile_cmn/r_ble_servs_if.h"
#include "gatt_db.h"

static st_ble_servs_info_t gs_servs_info;

/*----------------------------------------------------------------------------------------------------------------------
    Blood Pressure Measurement Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

static const st_ble_servs_desc_info_t gs_meas_cli_cnfg = {
    .attr_hdl = BLE_BLS_MEAS_CLI_CNFG_DESC_HDL,
    .app_size = sizeof(uint16_t),
    .desc_idx = BLE_BLS_MEAS_CLI_CNFG_IDX,
    .db_size  = BLE_BLS_MEAS_CLI_CNFG_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_uint16_t,
    .encode   = (ble_servs_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_BLS_SetMeasCliCnfg(uint16_t conn_hdl, const uint16_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_meas_cli_cnfg, conn_hdl, (const void *)p_value);
}

ble_status_t R_BLE_BLS_GetMeasCliCnfg(uint16_t conn_hdl, uint16_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_meas_cli_cnfg, conn_hdl, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Blood Pressure Measurement characteristic
----------------------------------------------------------------------------------------------------------------------*/

static ble_status_t encode_st_ble_bls_meas_t(const st_ble_bls_meas_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    p_gatt_value->p_value[pos] |= p_app_value->flags.is_blood_pressure_units_kpa ? 0x01 : 0x00;
    p_gatt_value->p_value[pos] |= p_app_value->flags.is_time_stamp_present ? 0x02 : 0x00;
    p_gatt_value->p_value[pos] |= p_app_value->flags.is_pulse_rate_present ? 0x04 : 0x00;
    p_gatt_value->p_value[pos] |= p_app_value->flags.is_user_id_present ? 0x08 : 0x00;
    p_gatt_value->p_value[pos] |= p_app_value->flags.is_measurement_status_present ? 0x10 : 0x00;
    pos++;

    pos += pack_st_ble_ieee11073_sfloat_t(&p_gatt_value->p_value[pos], &p_app_value->systolic);
    pos += pack_st_ble_ieee11073_sfloat_t(&p_gatt_value->p_value[pos], &p_app_value->diastolic);
    pos += pack_st_ble_ieee11073_sfloat_t(&p_gatt_value->p_value[pos], &p_app_value->mean_arterial_pressure);

    if (p_app_value->flags.is_time_stamp_present)
    {
        pos += pack_st_ble_date_time_t(&p_gatt_value->p_value[pos], &p_app_value->time_stamp);
    }

    if (p_app_value->flags.is_pulse_rate_present)
    {
        pos += pack_st_ble_ieee11073_sfloat_t(&p_gatt_value->p_value[pos], &p_app_value->time_stamp);
    }

    if (p_app_value->flags.is_user_id_present)
    {
        p_gatt_value->p_value[pos++] = p_app_value->user_id;
    }

    if (p_app_value->flags.is_measurement_status_present)
    {
        p_gatt_value->p_value[pos] |= p_app_value->measurement_status.is_body_movement_detected ? 0x01 : 0x00;
        p_gatt_value->p_value[pos] |= p_app_value->measurement_status.is_cuff_fit_loose ? 0x02 : 0x00;
        p_gatt_value->p_value[pos] |= p_app_value->measurement_status.is_irregular_pulse_detected ? 0x04 : 0x00;
        p_gatt_value->p_value[pos] |= p_app_value->measurement_status.pulse_rate_range << 3;
        p_gatt_value->p_value[pos] |= p_app_value->measurement_status.is_measurement_position_improper ? 0x20 : 0x00;
        pos += 2;
    }

    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

/* Blood Pressure Measurement characteristic descriptor definition */
static const st_ble_servs_desc_info_t *gspp_meas_descs[] = {
    &gs_meas_cli_cnfg,
};

/* Blood Pressure Measurement characteristic definition */
static const st_ble_servs_char_info_t gs_meas_char = {
    .start_hdl    = BLE_BLS_MEAS_DECL_HDL,
    .end_hdl      = BLE_BLS_MEAS_CLI_CNFG_DESC_HDL,
    .char_idx     = BLE_BLS_MEAS_IDX,
    .app_size     = sizeof(st_ble_bls_meas_t),
    .db_size      = BLE_BLS_MEAS_LEN,
    .encode       = (ble_servs_attr_encode_t)encode_st_ble_bls_meas_t,
    .pp_descs     = gspp_meas_descs,
    .num_of_descs = ARRAY_SIZE(gspp_meas_descs),
};

ble_status_t R_BLE_BLS_IndicateMeas(uint16_t conn_hdl, const st_ble_bls_meas_t *p_value)
{
    return R_BLE_SERVS_SendHdlVal(&gs_meas_char, conn_hdl, (const void *)p_value, false);
}

/*----------------------------------------------------------------------------------------------------------------------
    Intermediate Cuff Pressure Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

static const st_ble_servs_desc_info_t gs_intermediate_cuff_pressure_cli_cnfg = {
    .attr_hdl = BLE_BLS_INTERMEDIATE_CUFF_PRESSURE_CLI_CNFG_DESC_HDL,
    .app_size = sizeof(uint16_t),
    .desc_idx = BLE_BLS_INTERMEDIATE_CUFF_PRESSURE_CLI_CNFG_IDX,
    .db_size  = BLE_BLS_INTERMEDIATE_CUFF_PRESSURE_CLI_CNFG_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_uint16_t,
    .encode   = (ble_servs_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_BLS_SetIntermediateCuffPressureCliCnfg(uint16_t conn_hdl, const uint16_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_intermediate_cuff_pressure_cli_cnfg, conn_hdl, (const void *)p_value);
}

ble_status_t R_BLE_BLS_GetIntermediateCuffPressureCliCnfg(uint16_t conn_hdl, uint16_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_intermediate_cuff_pressure_cli_cnfg, conn_hdl, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Intermediate Cuff Pressure characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Intermediate Cuff Pressure characteristic descriptor definition */
static const st_ble_servs_desc_info_t *gspp_intermediate_cuff_pressure_descs[] = {
    &gs_intermediate_cuff_pressure_cli_cnfg,
};

/* Intermediate Cuff Pressure characteristic definition */
static const st_ble_servs_char_info_t gs_intermediate_cuff_pressure_char = {
    .start_hdl    = BLE_BLS_INTERMEDIATE_CUFF_PRESSURE_DECL_HDL,
    .end_hdl      = BLE_BLS_INTERMEDIATE_CUFF_PRESSURE_CLI_CNFG_DESC_HDL,
    .char_idx     = BLE_BLS_INTERMEDIATE_CUFF_PRESSURE_IDX,
    .app_size     = sizeof(st_ble_bls_meas_t),
    .db_size      = BLE_BLS_INTERMEDIATE_CUFF_PRESSURE_LEN,
    .encode       = (ble_servs_attr_encode_t)encode_st_ble_bls_meas_t,
    .pp_descs     = gspp_intermediate_cuff_pressure_descs,
    .num_of_descs = ARRAY_SIZE(gspp_intermediate_cuff_pressure_descs),
};

ble_status_t R_BLE_BLS_NotifyIntermediateCuffPressure(uint16_t conn_hdl, const st_ble_bls_meas_t *p_value)
{
    return R_BLE_SERVS_SendHdlVal(&gs_intermediate_cuff_pressure_char, conn_hdl, (const void *)p_value, true);
}

/*----------------------------------------------------------------------------------------------------------------------
    Blood Pressure Feature characteristic
----------------------------------------------------------------------------------------------------------------------*/

static ble_status_t decode_st_ble_bls_feat_t(st_ble_bls_feat_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    p_app_value->is_body_movement_detection_support_bit        = !!(p_gatt_value->p_value[0] & 0x01);
    p_app_value->is_cuff_fit_detection_support_bit             = !!(p_gatt_value->p_value[0] & 0x02);
    p_app_value->is_irregular_pulse_detection_support_bit      = !!(p_gatt_value->p_value[0] & 0x04);
    p_app_value->is_pulse_rate_range_detection_support_bit     = !!(p_gatt_value->p_value[0] & 0x08);
    p_app_value->is_measurement_position_detection_support_bit = !!(p_gatt_value->p_value[0] & 0x10);
    p_app_value->is_multiple_bond_support_bit                  = !!(p_gatt_value->p_value[0] & 0x20);

    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_bls_feat_t(const st_ble_bls_feat_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    p_gatt_value->p_value[0] |= p_app_value->is_body_movement_detection_support_bit ? 0x01 : 0x00;
    p_gatt_value->p_value[0] |= p_app_value->is_cuff_fit_detection_support_bit ? 0x02 : 0x00;
    p_gatt_value->p_value[0] |= p_app_value->is_irregular_pulse_detection_support_bit ? 0x04 : 0x00;
    p_gatt_value->p_value[0] |= p_app_value->is_pulse_rate_range_detection_support_bit ? 0x08 : 0x00;
    p_gatt_value->p_value[0] |= p_app_value->is_measurement_position_detection_support_bit ? 0x10 : 0x00;
    p_gatt_value->p_value[0] |= p_app_value->is_multiple_bond_support_bit ? 0x20 : 0x00;

    return BLE_SUCCESS;
}

/* Blood Pressure Feature characteristic definition */
static const st_ble_servs_char_info_t gs_feat_char = {
    .start_hdl    = BLE_BLS_FEAT_DECL_HDL,
    .end_hdl      = BLE_BLS_FEAT_VAL_HDL,
    .char_idx     = BLE_BLS_FEAT_IDX,
    .app_size     = sizeof(st_ble_bls_feat_t),
    .db_size      = BLE_BLS_FEAT_LEN,
    .decode       = (ble_servs_attr_decode_t)decode_st_ble_bls_feat_t,
    .encode       = (ble_servs_attr_encode_t)encode_st_ble_bls_feat_t,
};

ble_status_t R_BLE_BLS_SetFeat(const st_ble_bls_feat_t *p_value)
{
    return R_BLE_SERVS_SetChar(&gs_feat_char, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_BLS_GetFeat(st_ble_bls_feat_t *p_value)
{
    return R_BLE_SERVS_GetChar(&gs_feat_char, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Blood Pressure server
----------------------------------------------------------------------------------------------------------------------*/

/* Blood Pressure characteristics definition */
static const st_ble_servs_char_info_t *gspp_chars[] = {
    &gs_meas_char,
    &gs_intermediate_cuff_pressure_char,
    &gs_feat_char,
};

/* Blood Pressure service definition */
static st_ble_servs_info_t gs_servs_info = {
    .pp_chars     = gspp_chars,
    .num_of_chars = ARRAY_SIZE(gspp_chars),
};

ble_status_t R_BLE_BLS_Init(ble_servs_app_cb_t cb)
{
    if (NULL == cb)
    {
        return BLE_ERR_INVALID_PTR;
    }

    gs_servs_info.cb = cb;

    return R_BLE_SERVS_RegisterServer(&gs_servs_info);
}
