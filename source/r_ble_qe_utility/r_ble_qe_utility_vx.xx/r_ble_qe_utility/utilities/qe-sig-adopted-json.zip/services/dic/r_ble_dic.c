/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_dic.c
 * Version : 1.0
 * Description : The source file for Device Information client.
 **********************************************************************************************************************/
#include <string.h>
#include "r_ble_dic.h"
#include "profile_cmn/r_ble_servc_if.h"

static st_ble_servc_info_t gs_client_info;

/*----------------------------------------------------------------------------------------------------------------------
    Manufacturer Name Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Manufacturer Name characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_mfr_name_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

/* Manufacturer Name characteristic definition */
const st_ble_servc_char_info_t gs_mfr_name_char = {
    .uuid_16      = BLE_DIC_MFR_NAME_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_seq_data_t),
    .db_size      = BLE_DIC_MFR_NAME_LEN,
    .char_idx     = BLE_DIC_MFR_NAME_IDX,
    .p_attr_hdls  = gs_mfr_name_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_seq_data_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_seq_data_t,
};

ble_status_t R_BLE_DIC_ReadMfrName(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_mfr_name_char, conn_hdl);
}

void R_BLE_DIC_GetMfrNameAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_dic_mfr_name_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_mfr_name_char_ranges[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Model Number Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Model Number characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_model_num_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

/* Model Number characteristic definition */
const st_ble_servc_char_info_t gs_model_num_char = {
    .uuid_16      = BLE_DIC_MODEL_NUM_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_seq_data_t),
    .db_size      = BLE_DIC_MODEL_NUM_LEN,
    .char_idx     = BLE_DIC_MODEL_NUM_IDX,
    .p_attr_hdls  = gs_model_num_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_seq_data_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_seq_data_t,
};

ble_status_t R_BLE_DIC_ReadModelNum(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_model_num_char, conn_hdl);
}

void R_BLE_DIC_GetModelNumAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_dic_model_num_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_model_num_char_ranges[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Serial Number Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Serial Number characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_ser_num_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

/* Serial Number characteristic definition */
const st_ble_servc_char_info_t gs_ser_num_char = {
    .uuid_16      = BLE_DIC_SER_NUM_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_seq_data_t),
    .db_size      = BLE_DIC_SER_NUM_LEN,
    .char_idx     = BLE_DIC_SER_NUM_IDX,
    .p_attr_hdls  = gs_ser_num_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_seq_data_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_seq_data_t,
};

ble_status_t R_BLE_DIC_ReadSerNum(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_ser_num_char, conn_hdl);
}

void R_BLE_DIC_GetSerNumAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_dic_ser_num_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_ser_num_char_ranges[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Hardware Revision Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Hardware Revision characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_hw_rev_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

/* Hardware Revision characteristic definition */
const st_ble_servc_char_info_t gs_hw_rev_char = {
    .uuid_16      = BLE_DIC_HW_REV_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_seq_data_t),
    .db_size      = BLE_DIC_HW_REV_LEN,
    .char_idx     = BLE_DIC_HW_REV_IDX,
    .p_attr_hdls  = gs_hw_rev_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_seq_data_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_seq_data_t,
};

ble_status_t R_BLE_DIC_ReadHwRev(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_hw_rev_char, conn_hdl);
}

void R_BLE_DIC_GetHwRevAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_dic_hw_rev_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_hw_rev_char_ranges[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Firmware Revision Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Firmware Revision characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_firm_rev_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

/* Firmware Revision characteristic definition */
const st_ble_servc_char_info_t gs_firm_rev_char = {
    .uuid_16      = BLE_DIC_FIRM_REV_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_seq_data_t),
    .db_size      = BLE_DIC_FIRM_REV_LEN,
    .char_idx     = BLE_DIC_FIRM_REV_IDX,
    .p_attr_hdls  = gs_firm_rev_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_seq_data_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_seq_data_t,
};

ble_status_t R_BLE_DIC_ReadFirmRev(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_firm_rev_char, conn_hdl);
}

void R_BLE_DIC_GetFirmRevAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_dic_firm_rev_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_firm_rev_char_ranges[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Software Revision Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Software Revision characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_sw_rev_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

/* Software Revision characteristic definition */
const st_ble_servc_char_info_t gs_sw_rev_char = {
    .uuid_16      = BLE_DIC_SW_REV_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_seq_data_t),
    .db_size      = BLE_DIC_SW_REV_LEN,
    .char_idx     = BLE_DIC_SW_REV_IDX,
    .p_attr_hdls  = gs_sw_rev_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_seq_data_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_seq_data_t,
};

ble_status_t R_BLE_DIC_ReadSwRev(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_sw_rev_char, conn_hdl);
}

void R_BLE_DIC_GetSwRevAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_dic_sw_rev_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_sw_rev_char_ranges[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    System ID Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* System ID characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_sys_id_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

static ble_status_t decode_st_ble_dic_sys_id_t(st_ble_dic_sys_id_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memcpy(p_app_value->manufacturer_identifier, &p_gatt_value->p_value[pos], 5);
    pos += 5;

    memcpy(p_app_value->organizationally_unique_identifier, &p_gatt_value->p_value[pos], 3);
    pos += 3;

    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_dic_sys_id_t(const st_ble_dic_sys_id_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memcpy(&p_gatt_value->p_value[pos], p_app_value->manufacturer_identifier, 5);
    pos += 5;

    memcpy(&p_gatt_value->p_value[pos], p_app_value->organizationally_unique_identifier, 3);
    pos += 3;

    return BLE_SUCCESS;
}

/* System ID characteristic definition */
const st_ble_servc_char_info_t gs_sys_id_char = {
    .uuid_16      = BLE_DIC_SYS_ID_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_dic_sys_id_t),
    .db_size      = BLE_DIC_SYS_ID_LEN,
    .char_idx     = BLE_DIC_SYS_ID_IDX,
    .p_attr_hdls  = gs_sys_id_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_dic_sys_id_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_dic_sys_id_t,
};

ble_status_t R_BLE_DIC_ReadSysId(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_sys_id_char, conn_hdl);
}

void R_BLE_DIC_GetSysIdAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_dic_sys_id_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_sys_id_char_ranges[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    IEEE 11073-20601 Regulatory Certification Data List Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* IEEE 11073-20601 Regulatory Certification Data List characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_reg_cer_data_list_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

/* IEEE 11073-20601 Regulatory Certification Data List characteristic definition */
const st_ble_servc_char_info_t gs_reg_cer_data_list_char = {
    .uuid_16      = BLE_DIC_REG_CER_DATA_LIST_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_seq_data_t),
    .db_size      = BLE_DIC_REG_CER_DATA_LIST_LEN,
    .char_idx     = BLE_DIC_REG_CER_DATA_LIST_IDX,
    .p_attr_hdls  = gs_reg_cer_data_list_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_seq_data_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_seq_data_t,
};

ble_status_t R_BLE_DIC_ReadRegCerDataList(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_reg_cer_data_list_char, conn_hdl);
}

void R_BLE_DIC_GetRegCerDataListAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_dic_reg_cer_data_list_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_reg_cer_data_list_char_ranges[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    PnP ID Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* PnP ID characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_pnp_id_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

static ble_status_t decode_st_ble_dic_pnp_id_t(st_ble_dic_pnp_id_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    p_app_value->vendor_id_source = p_gatt_value->p_value[pos++];

    BT_UNPACK_LE_2_BYTE(&p_app_value->vendor_id, &p_gatt_value->p_value[pos]);
    pos += sizeof(uint16_t);

    BT_UNPACK_LE_2_BYTE(&p_app_value->product_id, &p_gatt_value->p_value[pos]);
    pos += sizeof(uint16_t);

    BT_UNPACK_LE_2_BYTE(&p_app_value->product_version, &p_gatt_value->p_value[pos]);
    pos += sizeof(uint16_t);

    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_dic_pnp_id_t(const st_ble_dic_pnp_id_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    p_gatt_value->p_value[pos++] = p_app_value->vendor_id_source;

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->vendor_id);
    pos += sizeof(uint16_t);

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->product_id);
    pos += sizeof(uint16_t);

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->product_version);
    pos += sizeof(uint16_t);

    return BLE_SUCCESS;
}

/* PnP ID characteristic definition */
const st_ble_servc_char_info_t gs_pnp_id_char = {
    .uuid_16      = BLE_DIC_PNP_ID_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_dic_pnp_id_t),
    .db_size      = BLE_DIC_PNP_ID_LEN,
    .char_idx     = BLE_DIC_PNP_ID_IDX,
    .p_attr_hdls  = gs_pnp_id_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_dic_pnp_id_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_dic_pnp_id_t,
};

ble_status_t R_BLE_DIC_ReadPnpId(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_pnp_id_char, conn_hdl);
}

void R_BLE_DIC_GetPnpIdAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_dic_pnp_id_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_pnp_id_char_ranges[conn_idx];
}


/*----------------------------------------------------------------------------------------------------------------------
    Device Information client
----------------------------------------------------------------------------------------------------------------------*/

/* Device Information client attribute handles */
static st_ble_gatt_hdl_range_t gs_dic_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

const st_ble_servc_char_info_t *gspp_dic_chars[] = {
    &gs_mfr_name_char,
    &gs_model_num_char,
    &gs_ser_num_char,
    &gs_hw_rev_char,
    &gs_firm_rev_char,
    &gs_sw_rev_char,
    &gs_sys_id_char,
    &gs_reg_cer_data_list_char,
    &gs_pnp_id_char,
};

static st_ble_servc_info_t gs_client_info = {
    .pp_chars     = gspp_dic_chars,
    .num_of_chars = ARRAY_SIZE(gspp_dic_chars),
    .p_attr_hdls  = gs_dic_ranges,
};

ble_status_t R_BLE_DIC_Init(ble_servc_app_cb_t cb) // @suppress("API function naming")
{
    if (NULL == cb)
    {
        return BLE_ERR_INVALID_PTR;
    }

    gs_client_info.cb = cb;

    return R_BLE_SERVC_RegisterClient(&gs_client_info);
}

void R_BLE_DIC_ServDiscCb(uint16_t conn_hdl, uint8_t serv_idx, uint16_t type, void *p_param) // @suppress("API function naming")
{
    R_BLE_SERVC_ServDiscCb(&gs_client_info, conn_hdl, serv_idx, type, p_param);
}

void R_BLE_DIC_GetServAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_gatt_hdl_range_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    *p_hdl = gs_dic_ranges[conn_idx];
}
