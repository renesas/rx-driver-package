/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_dic.h
 * Version : 1.0
 * Description : The header file for Device Information client.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 31.12.2999 1.00 First Release
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @file
 * @defgroup dic Device Information Service Client
 * @{
 * @ingroup profile
 * @brief   This is the client for the Device Information Service.
 **********************************************************************************************************************/
#include "profile_cmn/r_ble_servc_if.h"

#ifndef R_BLE_DIC_H
#define R_BLE_DIC_H

/*----------------------------------------------------------------------------------------------------------------------
    Manufacturer Name Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_DIC_MFR_NAME_UUID (0x2A29)
#define BLE_DIC_MFR_NAME_LEN (100)
/***************************************************************************//**
 * @brief Manufacturer Name attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
} st_ble_dic_mfr_name_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Manufacturer Name characteristic value from the remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_DIC_ReadMfrName(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief      Get Manufacturer Name attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_DIC_GetMfrNameAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_dic_mfr_name_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Model Number Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_DIC_MODEL_NUM_UUID (0x2A24)
#define BLE_DIC_MODEL_NUM_LEN (100)
/***************************************************************************//**
 * @brief Model Number attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
} st_ble_dic_model_num_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Model Number characteristic value from the remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_DIC_ReadModelNum(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief      Get Model Number attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_DIC_GetModelNumAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_dic_model_num_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Serial Number Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_DIC_SER_NUM_UUID (0x2A25)
#define BLE_DIC_SER_NUM_LEN (100)
/***************************************************************************//**
 * @brief Serial Number attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
} st_ble_dic_ser_num_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Serial Number characteristic value from the remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_DIC_ReadSerNum(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief      Get Serial Number attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_DIC_GetSerNumAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_dic_ser_num_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Hardware Revision Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_DIC_HW_REV_UUID (0x2A27)
#define BLE_DIC_HW_REV_LEN (100)
/***************************************************************************//**
 * @brief Hardware Revision attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
} st_ble_dic_hw_rev_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Hardware Revision characteristic value from the remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_DIC_ReadHwRev(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief      Get Hardware Revision attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_DIC_GetHwRevAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_dic_hw_rev_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Firmware Revision Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_DIC_FIRM_REV_UUID (0x2A26)
#define BLE_DIC_FIRM_REV_LEN (100)
/***************************************************************************//**
 * @brief Firmware Revision attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
} st_ble_dic_firm_rev_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Firmware Revision characteristic value from the remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_DIC_ReadFirmRev(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief      Get Firmware Revision attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_DIC_GetFirmRevAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_dic_firm_rev_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Software Revision Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_DIC_SW_REV_UUID (0x2A28)
#define BLE_DIC_SW_REV_LEN (100)
/***************************************************************************//**
 * @brief Software Revision attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
} st_ble_dic_sw_rev_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Software Revision characteristic value from the remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_DIC_ReadSwRev(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief      Get Software Revision attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_DIC_GetSwRevAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_dic_sw_rev_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    System ID Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_DIC_SYS_ID_UUID (0x2A23)
#define BLE_DIC_SYS_ID_LEN (8)
/***************************************************************************//**
 * @brief System ID value structure.
*******************************************************************************/
typedef struct {
    uint8_t manufacturer_identifier[5]; /**< Manufacturer Identifier */
    uint8_t organizationally_unique_identifier[3]; /**< Organizationally Unique Identifier */
} st_ble_dic_sys_id_t;

/***************************************************************************//**
 * @brief System ID attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
} st_ble_dic_sys_id_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read System ID characteristic value from the remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_DIC_ReadSysId(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief      Get System ID attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_DIC_GetSysIdAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_dic_sys_id_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    IEEE 11073-20601 Regulatory Certification Data List Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_DIC_REG_CER_DATA_LIST_UUID (0x2A2A)
#define BLE_DIC_REG_CER_DATA_LIST_LEN (100)
/***************************************************************************//**
 * @brief IEEE 11073-20601 Regulatory Certification Data List attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
} st_ble_dic_reg_cer_data_list_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read IEEE 11073-20601 Regulatory Certification Data List characteristic value from the remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_DIC_ReadRegCerDataList(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief      Get IEEE 11073-20601 Regulatory Certification Data List attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_DIC_GetRegCerDataListAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_dic_reg_cer_data_list_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    PnP ID Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_DIC_PNP_ID_UUID (0x2A50)
#define BLE_DIC_PNP_ID_LEN (7)
/***************************************************************************//**
 * @brief PnP ID Vendor ID Source enumeration.
*******************************************************************************/
typedef enum {
    BLE_DIC_PNP_ID_VENDOR_ID_SOURCE_BLUETOOTH_SIG_ASSIGNED_COMPANY_IDENTIFIER_VALUE_FROM_THE_ASSIGNED_NUMBERS_DOCUMENT = 1, /**< Bluetooth SIG assigned Company Identifier value from the Assigned Numbers document */
    BLE_DIC_PNP_ID_VENDOR_ID_SOURCE_USB_IMPLEMENTER_S_FORUM_ASSIGNED_VENDOR_ID_VALUE = 2, /**< USB Implementer's Forum assigned Vendor ID value */
} e_ble_dic_pnp_id_vendor_id_source_t;

/***************************************************************************//**
 * @brief PnP ID value structure.
*******************************************************************************/
typedef struct {
    uint8_t vendor_id_source; /**< Vendor ID Source */
    uint16_t vendor_id; /**< Vendor ID */
    uint16_t product_id; /**< Product ID */
    uint16_t product_version; /**< Product Version */
} st_ble_dic_pnp_id_t;

/***************************************************************************//**
 * @brief PnP ID attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
} st_ble_dic_pnp_id_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read PnP ID characteristic value from the remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_DIC_ReadPnpId(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief      Get PnP ID attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_DIC_GetPnpIdAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_dic_pnp_id_attr_hdl_t *p_hdl);


/*----------------------------------------------------------------------------------------------------------------------
    Device Information Client
----------------------------------------------------------------------------------------------------------------------*/

/***************************************************************************//**
 * @brief Device Information client event data.
*******************************************************************************/
typedef struct {
    uint16_t    conn_hdl;  /**< Connection handle */
    uint16_t    param_len; /**< Event parameter length */
    const void *p_param;   /**< Event parameter */
} st_ble_dic_evt_data_t;

/***************************************************************************//**
 * @brief Device Information characteristic ID.
*******************************************************************************/
typedef enum {
    BLE_DIC_MFR_NAME_IDX,
    BLE_DIC_MODEL_NUM_IDX,
    BLE_DIC_SER_NUM_IDX,
    BLE_DIC_HW_REV_IDX,
    BLE_DIC_FIRM_REV_IDX,
    BLE_DIC_SW_REV_IDX,
    BLE_DIC_SYS_ID_IDX,
    BLE_DIC_REG_CER_DATA_LIST_IDX,
    BLE_DIC_PNP_ID_IDX,
} st_ble_dic_char_idx_t;

/***************************************************************************//**
 * @brief Device Information client event type.
*******************************************************************************/
typedef enum {
    /* Manufacturer Name */
    BLE_DIC_EVENT_MFR_NAME_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_DIC_MFR_NAME_IDX, BLE_SERVC_READ_RSP),
    /* Model Number */
    BLE_DIC_EVENT_MODEL_NUM_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_DIC_MODEL_NUM_IDX, BLE_SERVC_READ_RSP),
    /* Serial Number */
    BLE_DIC_EVENT_SER_NUM_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_DIC_SER_NUM_IDX, BLE_SERVC_READ_RSP),
    /* Hardware Revision */
    BLE_DIC_EVENT_HW_REV_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_DIC_HW_REV_IDX, BLE_SERVC_READ_RSP),
    /* Firmware Revision */
    BLE_DIC_EVENT_FIRM_REV_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_DIC_FIRM_REV_IDX, BLE_SERVC_READ_RSP),
    /* Software Revision */
    BLE_DIC_EVENT_SW_REV_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_DIC_SW_REV_IDX, BLE_SERVC_READ_RSP),
    /* System ID */
    BLE_DIC_EVENT_SYS_ID_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_DIC_SYS_ID_IDX, BLE_SERVC_READ_RSP),
    /* IEEE 11073-20601 Regulatory Certification Data List */
    BLE_DIC_EVENT_REG_CER_DATA_LIST_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_DIC_REG_CER_DATA_LIST_IDX, BLE_SERVC_READ_RSP),
    /* PnP ID */
    BLE_DIC_EVENT_PNP_ID_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_DIC_PNP_ID_IDX, BLE_SERVC_READ_RSP),
} e_ble_dic_event_t;

/***************************************************************************//**
 * @brief     Initialize Device Information client.
 * @param[in] cb Client callback.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_DIC_Init(ble_servc_app_cb_t cb);

/***************************************************************************//**
 * @brief     Device Information client discovery callback.
 * @param[in] conn_hdl Connection handle
 * @param[in] serv_idx Service instance index.
 * @param[in] type     Service discovery event type.
 * @param[in] p_param  Service discovery event parameter.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_DIC_ServDiscCb(uint16_t conn_hdl, uint8_t serv_idx, uint16_t type, void *p_param);

/***************************************************************************//**
 * @brief     Get Device Information client attribute handle.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
*******************************************************************************/
void R_BLE_DIC_GetServAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_gatt_hdl_range_t *p_hdl);

#endif /* R_BLE_DIC_H */

/** @} */
