/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_bac.h
 * Version : 1.0
 * Description : The header file for Battery Service client.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 31.12.2999 1.00 First Release
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @file
 * @defgroup bac Battery Service Client
 * @{
 * @ingroup profile
 * @brief   This is the client for the Battery Service Service.
 **********************************************************************************************************************/
#include "profile_cmn/r_ble_servc_if.h"

#ifndef R_BLE_BAC_H
#define R_BLE_BAC_H

/*----------------------------------------------------------------------------------------------------------------------
    Battery Level Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_BAC_BATTERY_LEVEL_UUID (0x2A19)
#define BLE_BAC_BATTERY_LEVEL_LEN (1)
#define BLE_BAC_BATTERY_LEVEL_CLI_CNFG_UUID (0x2902)
#define BLE_BAC_BATTERY_LEVEL_CLI_CNFG_LEN (2)
#define BLE_BAC_BATTERY_LEVEL_PRESN_FORMAT_UUID (0x2904)
#define BLE_BAC_BATTERY_LEVEL_PRESN_FORMAT_LEN (7)

/***************************************************************************//**
 * @brief Characteristic Presentation Format value structure.
*******************************************************************************/
typedef struct {
    uint8_t format; /**< Format */
    int8_t exponent; /**< Exponent */
    uint16_t unit; /**< Unit */
    uint8_t namespace; /**< Namespace */
    uint16_t description; /**< Description */
} st_ble_bac_battery_level_presn_format_t;


/***************************************************************************//**
 * @brief Battery Level attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
    uint16_t cli_cnfg_desc_hdl;
    uint16_t presn_format_desc_hdl;
} st_ble_bac_battery_level_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Battery Level characteristic Characteristic Presentation Format descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_BAC_ReadBatteryLevelPresnFormat(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Read Battery Level characteristic Client Characteristic Configuration descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_BAC_ReadBatteryLevelCliCnfg(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Battery Level characteristic Client Characteristic Configuration descriptor value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value Battery Level characteristic Client Characteristic Configuration descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_BAC_WriteBatteryLevelCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Read Battery Level characteristic value from the remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_BAC_ReadBatteryLevel(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief      Get Battery Level attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_BAC_GetBatteryLevelAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_bac_battery_level_attr_hdl_t *p_hdl);


/*----------------------------------------------------------------------------------------------------------------------
    Battery Service Client
----------------------------------------------------------------------------------------------------------------------*/

/***************************************************************************//**
 * @brief Battery Service client event data.
*******************************************************************************/
typedef struct {
    uint16_t    conn_hdl;  /**< Connection handle */
    uint16_t    param_len; /**< Event parameter length */
    const void *p_param;   /**< Event parameter */
} st_ble_bac_evt_data_t;

/***************************************************************************//**
 * @brief Battery Service characteristic ID.
*******************************************************************************/
typedef enum {
    BLE_BAC_BATTERY_LEVEL_IDX,
    BLE_BAC_BATTERY_LEVEL_CLI_CNFG_IDX,
    BLE_BAC_BATTERY_LEVEL_PRESN_FORMAT_IDX,
} e_ble_bac_char_idx_t;

/***************************************************************************//**
 * @brief Battery Service client event type.
*******************************************************************************/
typedef enum {
    /* Battery Level */
    BLE_BAC_EVENT_BATTERY_LEVEL_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_BAC_BATTERY_LEVEL_IDX, BLE_SERVC_READ_RSP),
    BLE_BAC_EVENT_BATTERY_LEVEL_HDL_VAL_NTF = BLE_SERVC_ATTR_EVENT(BLE_BAC_BATTERY_LEVEL_IDX, BLE_SERVC_HDL_VAL_NTF),
    BLE_BAC_EVENT_BATTERY_LEVEL_CLI_CNFG_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_BAC_BATTERY_LEVEL_CLI_CNFG_IDX, BLE_SERVC_READ_RSP),
    BLE_BAC_EVENT_BATTERY_LEVEL_CLI_CNFG_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_BAC_BATTERY_LEVEL_CLI_CNFG_IDX, BLE_SERVC_WRITE_RSP),
    BLE_BAC_EVENT_BATTERY_LEVEL_PRESN_FORMAT_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_BAC_BATTERY_LEVEL_PRESN_FORMAT_IDX, BLE_SERVC_READ_RSP),
} e_ble_bac_event_t;

/***************************************************************************//**
 * @brief     Initialize Battery Service client.
 * @param[in] cb Client callback.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_BAC_Init(ble_servc_app_cb_t cb);

/***************************************************************************//**
 * @brief     Battery Service client discovery callback.
 * @param[in] conn_hdl Connection handle
 * @param[in] serv_idx Service instance index.
 * @param[in] type     Service discovery event type.
 * @param[in] p_param  Service discovery event parameter.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_BAC_ServDiscCb(uint16_t conn_hdl, uint8_t serv_idx, uint16_t type, void *p_param);

/***************************************************************************//**
 * @brief     Get Battery Service client attribute handle.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
*******************************************************************************/
void R_BLE_BAC_GetServAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_gatt_hdl_range_t *p_hdl);

#endif /* R_BLE_BAC_H */

/** @} */
