/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_cpc.h
 * Version : 1.0
 * Description : The header file for Cycling Power client.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 31.12.2999 1.00 First Release
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @file
 * @defgroup cpc Cycling Power Service Client
 * @{
 * @ingroup profile
 * @brief   This is the client for the Cycling Power Service.
 **********************************************************************************************************************/
#include "profile_cmn/r_ble_servc_if.h"

#ifndef R_BLE_CPC_H
#define R_BLE_CPC_H

/*******************************************************************************************************************//**
 * @brief Number of sensor locations.
***********************************************************************************************************************/
#define NUM_OF_SUPPORTED_SENSOR_LOCATIONS (17)


/*----------------------------------------------------------------------------------------------------------------------
    Cycling Power Measurement Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_CPC_MEAS_UUID (0x2A63)
#define BLE_CPC_MEAS_LEN (34)
#define BLE_CPC_MEAS_CLI_CNFG_UUID (0x2902)
#define BLE_CPC_MEAS_CLI_CNFG_LEN (2)
#define BLE_CPC_MEAS_SER_CNFG_UUID (0x2903)
#define BLE_CPC_MEAS_SER_CNFG_LEN (2)


/*******************************************************************************************************************//**
 * @brief Pedal Power Balance Present bit.
***********************************************************************************************************************/
#define BLE_PRV_CPC_CP_MESURMNT_FLAGS_PEDAL_POWER_BALANCE_PRSNT (1 << 0)

/*******************************************************************************************************************//**
 * @brief Pedal Power Balance Reference bit.
***********************************************************************************************************************/
#define BLE_PRV_CPC_CP_MESURMNT_FLAGS_PEDAL_POWER_BALANCE_REFERENCE (1 << 1)

/*******************************************************************************************************************//**
 * @brief Accumulated Torque Present bit.
***********************************************************************************************************************/
#define BLE_PRV_CPC_CP_MESURMNT_FLAGS_ACCUMULATED_TORQUE_PRSNT (1 << 2)

/*******************************************************************************************************************//**
 * @brief Accumulated Torque Source bit.
***********************************************************************************************************************/
#define BLE_PRV_CPC_CP_MESURMNT_FLAGS_ACCUMULATED_TORQUE_SOURCE (1 << 3)

/*******************************************************************************************************************//**
 * @brief Wheel Revolution Data Present bit.
***********************************************************************************************************************/
#define BLE_PRV_CPC_CP_MESURMNT_FLAGS_WHEEL_REVOLUTION_DATA_PRSNT (1 << 4)

/*******************************************************************************************************************//**
 * @brief Crank Revolution Data Present bit.
***********************************************************************************************************************/
#define BLE_PRV_CPC_CP_MESURMNT_FLAGS_CRANK_REVOLUTION_DATA_PRSNT (1 << 5)

/*******************************************************************************************************************//**
 * @brief Extreme Force Magnitudes Present bit.
***********************************************************************************************************************/
#define BLE_PRV_CPC_CP_MESURMNT_FLAGS_EXTREME_FORCE_MAGNITUDES_PRSNT (1 << 6)

/*******************************************************************************************************************//**
 * @brief Extreme Torque Magnitudes Present bit.
***********************************************************************************************************************/
#define BLE_PRV_CPC_CP_MESURMNT_FLAGS_EXTREME_TORQUE_MAGNITUDES_PRSNT (1 << 7)

/*******************************************************************************************************************//**
 * @brief Extreme Angles Present bit.
***********************************************************************************************************************/
#define BLE_PRV_CPC_CP_MESURMNT_FLAGS_EXTREME_ANGLES_PRSNT (1 << 8)

/*******************************************************************************************************************//**
 * @brief Top Dead Spot Angle Present bit.
***********************************************************************************************************************/
#define BLE_PRV_CPC_CP_MESURMNT_FLAGS_TOP_DEAD_SPOT_ANGLE_PRSNT (1 << 9)

/*******************************************************************************************************************//**
 * @brief Bottom Dead Spot Angle Present bit.
***********************************************************************************************************************/
#define BLE_PRV_CPC_CP_MESURMNT_FLAGS_BOTTOM_DEAD_SPOT_ANGLE_PRSNT (1 << 10)

/*******************************************************************************************************************//**
 * @brief Accumulated Energy Present bit.
***********************************************************************************************************************/
#define BLE_PRV_CPC_CP_MESURMNT_FLAGS_ACCUMULATED_ENERGY_PRSNT (1 << 11)

/*******************************************************************************************************************//**
 * @brief Offset Compensation Indicator  bit.
***********************************************************************************************************************/
#define BLE_PRV_CPC_CP_MESURMNT_FLAGS_OFFSET_COMPENSATION_INDICATOR (1 << 12)


/***************************************************************************//**
 * @brief Cycling Power Measurement Flags value structure.
*******************************************************************************/
typedef struct {
    bool is_pedal_power_balance_present; /**< Pedal Power Balance Present */
    bool is_pedal_power_balance_reference; /**< Pedal Power Balance Reference */
    bool is_accumulated_torque_present; /**< Accumulated Torque Present */
    bool is_accumulated_torque_source; /**< Accumulated Torque Source */
    bool is_wheel_revolution_data_present; /**< Wheel Revolution Data Present */
    bool is_crank_revolution_data_present; /**< Crank Revolution Data Present */
    bool is_extreme_force_magnitudes_present; /**< Extreme Force Magnitudes Present */
    bool is_extreme_torque_magnitudes_present; /**< Extreme Torque Magnitudes Present */
    bool is_extreme_angles_present; /**< Extreme Angles Present */
    bool is_top_dead_spot_angle_present; /**< Top Dead Spot Angle Present */
    bool is_bottom_dead_spot_angle_present; /**< Bottom Dead Spot Angle Present */
    bool is_accumulated_energy_present; /**< Accumulated Energy Present */
    bool is_offset_compensation_indicator; /**< Offset Compensation Indicator  */
} st_ble_cpc_meas_flags_t;

/***************************************************************************//**
 * @brief Cycling Power Measurement value structure.
*******************************************************************************/
typedef struct {
    st_ble_cpc_meas_flags_t flags; /**< Flags */
    int16_t instantaneous_power; /**< Instantaneous Power */
    uint8_t pedal_power_balance; /**< Pedal Power Balance */
    uint16_t accumulated_torque; /**< Accumulated Torque */
    uint32_t wheel_revolution_data___cumulative_wheel_revolutions; /**< Wheel Revolution Data - Cumulative Wheel Revolutions */
    uint16_t wheel_revolution_data___last_wheel_event_time; /**< Wheel Revolution Data - Last Wheel Event Time */
    uint16_t crank_revolution_data__cumulative_crank_revolutions; /**< Crank Revolution Data- Cumulative Crank Revolutions */
    uint16_t crank_revolution_data__last_crank_event_time; /**< Crank Revolution Data- Last Crank Event Time */
    int16_t extreme_force_magnitudes___maximum_force_magnitude; /**< Extreme Force Magnitudes - Maximum Force Magnitude */
    int16_t extreme_force_magnitudes___minimum_force_magnitude; /**< Extreme Force Magnitudes - Minimum Force Magnitude */
    int16_t extreme_torque_magnitudes__maximum_torque_magnitude; /**< Extreme Torque Magnitudes- Maximum Torque Magnitude */
    int16_t extreme_torque_magnitudes__minimum_torque_magnitude; /**< Extreme Torque Magnitudes- Minimum Torque Magnitude */
    uint16_t extreme_angles___maximum_angle; /**< Extreme Angles - Maximum Angle */
    uint16_t extreme_angles___minimum_angle; /**< Extreme Angles - Minimum Angle */
    uint16_t top_dead_spot_angle; /**< Top Dead Spot Angle */
    uint16_t bottom_dead_spot_angle; /**< Bottom Dead Spot Angle */
    uint16_t accumulated_energy; /**< Accumulated Energy */
} st_ble_cpc_meas_t;

/***************************************************************************//**
 * @brief Cycling Power Measurement attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
    uint16_t cli_cnfg_desc_hdl;
    uint16_t ser_cnfg_desc_hdl;
} st_ble_cpc_meas_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Cycling Power Measurement characteristic Client Characteristic Configuration descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_CPC_ReadMeasCliCnfg(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Cycling Power Measurement characteristic Client Characteristic Configuration descriptor value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value Cycling Power Measurement characteristic Client Characteristic Configuration descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_CPC_WriteMeasCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Read Cycling Power Measurement characteristic Server Characteristic Configuration descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_CPC_ReadMeasSerCnfg(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Cycling Power Measurement characteristic Server Characteristic Configuration descriptor value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value Cycling Power Measurement characteristic Server Characteristic Configuration descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_CPC_WriteMeasSerCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief      Get Cycling Power Measurement attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_CPC_GetMeasAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_cpc_meas_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Cycling Power Feature Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_CPC_FEAT_UUID (0x2A65)
#define BLE_CPC_FEAT_LEN (4)
/***************************************************************************//**
 * @brief Cycling Power Feature value structure.
*******************************************************************************/
typedef struct {
    bool is_pedal_power_balance_supported; /**< Pedal Power Balance Supported */
    bool is_accumulated_torque_supported; /**< Accumulated Torque Supported */
    bool is_wheel_revolution_data_supported; /**< Wheel Revolution Data Supported */
    bool is_crank_revolution_data_supported; /**< Crank Revolution Data Supported */
    bool is_extreme_magnitudes_supported; /**< Extreme Magnitudes Supported */
    bool is_extreme_angles_supported; /**< Extreme Angles Supported */
    bool is_top_and_bottom_dead_spot_angles_supported; /**< Top and Bottom Dead Spot Angles Supported */
    bool is_accumulated_energy_supported; /**< Accumulated Energy Supported */
    bool is_offset_compensation_indicator_supported; /**< Offset Compensation Indicator Supported */
    bool is_offset_compensation_supported; /**< Offset Compensation Supported */
    bool is_cycling_power_measurement_characteristic_content_masking_supported; /**< Cycling Power Measurement Characteristic Content Masking Supported */
    bool is_multiple_sensor_locations_supported; /**< Multiple Sensor Locations Supported */
    bool is_crank_length_adjustment_supported; /**< Crank Length Adjustment Supported  */
    bool is_chain_length_adjustment_supported; /**< Chain Length Adjustment Supported */
    bool is_chain_weight_adjustment_supported; /**< Chain Weight Adjustment Supported */
    bool is_span_length_adjustment_supported; /**< Span Length Adjustment Supported */
    bool is_sensor_measurement_context; /**< Sensor Measurement Context */
    bool is_instantaneous_measurement_direction_supported; /**< Instantaneous Measurement Direction Supported */
    bool is_factory_calibration_date_supported; /**< Factory Calibration Date Supported */
    bool is_enhanced_offset_compensation_supported; /**< Enhanced Offset Compensation Supported */
    uint8_t distribute_system_support; /**< Distribute System Support */
} st_ble_cpc_feat_t;

/***************************************************************************//**
 * @brief Cycling Power Feature attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
} st_ble_cpc_feat_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Cycling Power Feature characteristic value from the remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_CPC_ReadFeat(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief      Get Cycling Power Feature attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_CPC_GetFeatAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_cpc_feat_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Sensor Location Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_CPC_SENSOR_LOC_UUID (0x2A5D)
#define BLE_CPC_SENSOR_LOC_LEN (1)
/***************************************************************************//**
 * @brief Sensor Location Sensor Location enumeration.
*******************************************************************************/
typedef enum {
    BLE_CPC_SENSOR_LOC_SENSOR_LOCATION_OTHER = 0, /**< Other */
    BLE_CPC_SENSOR_LOC_SENSOR_LOCATION_TOP_OF_SHOE = 1, /**< Top of shoe */
    BLE_CPC_SENSOR_LOC_SENSOR_LOCATION_IN_SHOE = 2, /**< In shoe */
    BLE_CPC_SENSOR_LOC_SENSOR_LOCATION_HIP = 3, /**< Hip */
    BLE_CPC_SENSOR_LOC_SENSOR_LOCATION__FRONT_WHEEL = 4, /**<  Front Wheel */
    BLE_CPC_SENSOR_LOC_SENSOR_LOCATION_LEFT_CRANK = 5, /**< Left Crank */
    BLE_CPC_SENSOR_LOC_SENSOR_LOCATION_RIGHT_CRANK = 6, /**< Right Crank */
    BLE_CPC_SENSOR_LOC_SENSOR_LOCATION_LEFT_PEDAL = 7, /**< Left Pedal */
    BLE_CPC_SENSOR_LOC_SENSOR_LOCATION_RIGHT_PEDAL = 8, /**< Right Pedal */
    BLE_CPC_SENSOR_LOC_SENSOR_LOCATION__FRONT_HUB = 9, /**<  Front Hub */
    BLE_CPC_SENSOR_LOC_SENSOR_LOCATION_REAR_DROPOUT = 10, /**< Rear Dropout */
    BLE_CPC_SENSOR_LOC_SENSOR_LOCATION_CHAINSTAY = 11, /**< Chainstay */
    BLE_CPC_SENSOR_LOC_SENSOR_LOCATION_REAR_WHEEL = 12, /**< Rear Wheel */
    BLE_CPC_SENSOR_LOC_SENSOR_LOCATION_REAR_HUB = 13, /**< Rear Hub */
    BLE_CPC_SENSOR_LOC_SENSOR_LOCATION_CHEST = 14, /**< Chest */
    BLE_CPC_SENSOR_LOC_SENSOR_LOCATION_SPIDER = 15, /**< Spider */
    BLE_CPC_SENSOR_LOC_SENSOR_LOCATION_CHAIN_RING = 16, /**< Chain Ring */
} e_ble_sensor_loc_sensor_location_t;

/***************************************************************************//**
 * @brief Sensor Location attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
} st_ble_cpc_sensor_loc_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Sensor Location characteristic value from the remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_CPC_ReadSensorLoc(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief      Get Sensor Location attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_CPC_GetSensorLocAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_cpc_sensor_loc_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Cycling Power Vector Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_CPC_VECTOR_UUID (0x2A64)
#define BLE_CPC_VECTOR_LEN (11)
#define BLE_CPC_VECTOR_CLI_CNFG_UUID (0x2902)
#define BLE_CPC_VECTOR_CLI_CNFG_LEN (2)


/*******************************************************************************************************************//**
 * @brief Crank Revolution Data Present bit.
***********************************************************************************************************************/
#define BLE_PRV_CPC_CPV_FLAGS_CRANK_REVLUTN_DATA_PRSNT (1 << 0)

/*******************************************************************************************************************//**
 * @brief First Crank Measurement Angle Present bit.
***********************************************************************************************************************/
#define BLE_PRV_CPC_CPV_FLAGS_FIRST_CRANK_MESURMNT_ANGLE_PRSNT (1 << 1)

/*******************************************************************************************************************//**
 * @brief Instantaneous Force Magnitude Array Present bit.
***********************************************************************************************************************/
#define BLE_PRV_CPC_CPV_FLAGS_INSTANT_FORCE_MAGNITUDE_ARR_PRSNT (1 << 2)

/*******************************************************************************************************************//**
 * @brief Instantaneous Torque Magnitude Array Present bit.
***********************************************************************************************************************/
#define BLE_PRV_CPC_CPV_FLAGS_INSTANT_TORQUE_MAGNITUDE_ARR_PRSNT (1 << 3)

/*******************************************************************************************************************//**
 * @brief Instantaneous Measurement Direction bits.
***********************************************************************************************************************/
#define BLE_PRV_CPC_CPV_FLAGS_INSTANT_MESURENT_DIRECTN (((1 << 2) - 1) << 4)

/*******************************************************************************************************************//**
 * @brief Response code to be sent to every response for control point request.
***********************************************************************************************************************/
#define BLE_CPC_CYCLING_POWER_CONTROL_POINT_OP_CODES_RESPONSE_CODE (32)


/***************************************************************************//**
 * @brief Cycling Power Vector Flags value structure.
*******************************************************************************/
typedef struct {
    bool is_crank_revolution_data_present; /**< Crank Revolution Data Present */
    bool is_first_crank_measurement_angle_present; /**< First Crank Measurement Angle Present */
    bool is_instantaneous_force_magnitude_array_present; /**< Instantaneous Force Magnitude Array Present */
    bool is_instantaneous_torque_magnitude_array_present; /**< Instantaneous Torque Magnitude Array Present */
    uint8_t instantaneous_measurement_direction; /**< Instantaneous Measurement Direction */
} st_ble_vector_flags_t;

/***************************************************************************//**
 * @brief Cycling Power Vector value structure.
*******************************************************************************/
typedef struct {
    st_ble_vector_flags_t flags; /**< Flags */
    uint16_t crank_revolution_data___cumulative_crank_revolutions; /**< Crank Revolution Data - Cumulative Crank Revolutions */
    uint16_t crank_revolution_data___last_crank_event_time; /**< Crank Revolution Data - Last Crank Event Time */
    uint16_t first_crank_measurement_angle_; /**< First Crank Measurement Angle  */
    int16_t instantaneous_force_magnitude_array; /**< Instantaneous Force Magnitude Array */
    int16_t instantaneous_torque_magnitude_array; /**< Instantaneous Torque Magnitude Array */
} st_ble_cpc_vector_t;

/***************************************************************************//**
 * @brief Cycling Power Vector attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
    uint16_t cli_cnfg_desc_hdl;
} st_ble_cpc_vector_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Cycling Power Vector characteristic Client Characteristic Configuration descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_CPC_ReadVectorCliCnfg(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Cycling Power Vector characteristic Client Characteristic Configuration descriptor value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value Cycling Power Vector characteristic Client Characteristic Configuration descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_CPC_WriteVectorCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief      Get Cycling Power Vector attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_CPC_GetVectorAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_cpc_vector_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Cycling Power Control Point Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_CPC_CP_UUID (0x2A66)
#define BLE_CPC_CP_LEN (20)
#define BLE_CPC_CP_CLI_CNFG_UUID (0x2902)
#define BLE_CPC_CP_CLI_CNFG_LEN (2)

/***************************************************************************//**
 * @brief Cycling Power Control Point Op Codes enumeration.
*******************************************************************************/
typedef enum {
    BLE_CPC_CP_OP_CODES_SET_CUMULATIVE_VALUE = 1, /**< Set Cumulative Value */
    BLE_CPC_CP_OP_CODES_UPDATE_SENSOR_LOCATION = 2, /**< Update Sensor Location */
    BLE_CPC_CP_OP_CODES_REQUEST_SUPPORTED_SENSOR_LOCATIONS = 3, /**< Request Supported Sensor Locations */
    BLE_CPC_CP_OP_CODES_SET_CRANK_LENGTH = 4, /**< Set Crank Length */
    BLE_CPC_CP_OP_CODES_REQUEST_CRANK_LENGTH = 5, /**< Request Crank Length */
    BLE_CPC_CP_OP_CODES_SET_CHAIN_LENGTH = 6, /**< Set Chain Length */
    BLE_CPC_CP_OP_CODES_REQUEST_CHAIN_LENGTH = 7, /**< Request Chain Length */
    BLE_CPC_CP_OP_CODES_SET_CHAIN_WEIGHT = 8, /**< Set Chain Weight */
    BLE_CPC_CP_OP_CODES_REQUEST_CHAIN_WEIGHT = 9, /**< Request Chain Weight */
    BLE_CPC_CP_OP_CODES_SET_SPAN_LENGTH = 10, /**< Set Span Length */
    BLE_CPC_CP_OP_CODES_REQUEST_SPAN_LENGTH = 11, /**< Request Span Length */
    BLE_CPC_CP_OP_CODES_START_OFFSET_COMPENSATION = 12, /**< Start Offset Compensation */
    BLE_CPC_CP_OP_CODES_MASK_CYCLING_POWER_MEASUREMENT_CHARACTERISTIC_CONTENT = 13, /**< Mask Cycling Power Measurement Characteristic Content */
    BLE_CPC_CP_OP_CODES_REQUEST_SAMPLING_RATE = 14, /**< Request Sampling Rate */
    BLE_CPC_CP_OP_CODES_REQUEST_FACTORY_CALIBRATION_DATE = 15, /**< Request Factory Calibration Date */
    BLE_CPC_CP_OP_CODES_START_ENHANCED_OFFSET_COMPENSATION = 16, /**< Start Enhanced Offset Compensation */
    BLE_CPC_CP_OP_CODES_RESPONSE_CODE = 32, /**< Response Code */
} e_ble_cp_op_codes_t;

/***************************************************************************//**
 * @brief Cycling Power Control Point Response Value enumeration.
*******************************************************************************/
typedef enum {
    BLE_CPC_CP_RESPONSE_VALUE_SUCCESS = 1, /**< Success */
    BLE_CPC_CP_RESPONSE_VALUE_OP_CODE_NOT_SUPPORTED = 2, /**< Op Code not Supported */
    BLE_CPC_CP_RESPONSE_VALUE_INVALID_PARAMETER = 3, /**< Invalid Parameter */
    BLE_CPC_CP_RESPONSE_VALUE_OPERATION_FAILED = 4, /**< Operation Failed */
} e_ble_cp_response_value_t;

/*******************************************************************************************************************//**
 * @brief Cycling Power Control Point Response parameters.
***********************************************************************************************************************/
typedef struct {
    int16_t cntxt_bit_cyclic_power_feature; /**< Context bit of the Cycling Power Feature */
    uint16_t company_id; /**< manufacturer Company ID */
    uint8_t num_of_octets; /**< number of octets of manufacturer specific data */
    uint8_t *manufacturer_data; /**< manufacturer specific data */
} st_start_enhanced_offset_compensation_respnse_t;

typedef union {
    uint8_t list_of_supported_locations[NUM_OF_SUPPORTED_SENSOR_LOCATIONS]; /**< List of supported locations */
    uint16_t crank_length; /**< crank length in millimeters with a resolution of 1/2 millimeter */
    uint16_t chain_length; /**< chain length in millimeters with a resolution of 1 millimeter */
    uint16_t chain_weight; /**< chain weight in grams with a resolution of 1 gram */
    uint16_t span_length;  /**< span length in millimeters with a resolution of 1 millimeter */
    uint8_t sampling_rate; /**< sampling rate in Hertz with a resolution of 1 Hertz */
    st_ble_date_time_t factory_calibration_date; /**< factory calibration date */
    uint16_t offset_comp; /**< start offset compensation */
    st_start_enhanced_offset_compensation_respnse_t eocr_response; /**< Enhanced offset compensation response */
} u_cpc_cp_control_point_response_parameter_t;

/*******************************************************************************************************************//**
 * @brief Cycling Power Control Point Request .
***********************************************************************************************************************/
typedef union {
    uint32_t cumultive_value;
    uint8_t sensor_location; /**< Supported Location */
    uint16_t crank_length; /**<  crank length in millimeters with a resolution of 1/2 millimeter */
    uint16_t chain_length; /**<  chain length in millimeters with a resolution of 1 millimeter */
    uint16_t chain_weight; /**<  chain weight in grams with a resolution of 1 gram */
    uint16_t span_length; /**<   span length in millimeters with a resolution of 1 millimeter */
    uint16_t content_settings_cp_mesurmnt; /**< content settings of the Cycling Power Measurement characteristic  */
} u_cpc_cp_control_point_request_parameter_t;

/***************************************************************************//**
 * @brief Cycling Power Control Point value structure.
*******************************************************************************/
typedef struct {
    uint8_t op_codes; /**< Op Codes */
    u_cpc_cp_control_point_response_parameter_t resp_param; /**< Response param */
    u_cpc_cp_control_point_request_parameter_t req_param; /**< Request param */
    /*uint8_t parameter_value;*/ /**< Parameter Value */
    /*uint8_t request_op_code;*/ /**< Request Op Code */
    /*uint8_t response_value;*/ /**< Response Value */
    /*uint8_t response_parameter;*/ /**< Response Parameter */
} st_ble_cpc_cp_t;

/***************************************************************************//**
 * @brief Cycling Power Control Point attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
    uint16_t cli_cnfg_desc_hdl;
} st_ble_cpc_cp_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Cycling Power Control Point characteristic Client Characteristic Configuration descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_CPC_ReadCpCliCnfg(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Cycling Power Control Point characteristic Client Characteristic Configuration descriptor value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value Cycling Power Control Point characteristic Client Characteristic Configuration descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_CPC_WriteCpCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Write Cycling Power Control Point characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] p_value Cycling Power Control Point characteristic value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_CPC_WriteCp(uint16_t conn_hdl, const st_ble_cpc_cp_t *p_value);
;
/***************************************************************************//**
 * @brief      Get Cycling Power Control Point attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_CPC_GetCpAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_cpc_cp_attr_hdl_t *p_hdl);


/*----------------------------------------------------------------------------------------------------------------------
    Cycling Power Client
----------------------------------------------------------------------------------------------------------------------*/

/***************************************************************************//**
 * @brief Inappopropriate Connection Parameters
*******************************************************************************/
#define BLE_CPC_INAPPOPROPRIATE_CONNECTION_PARAMETERS_ERROR (BLE_ERR_GROUP_GATT | 0x80)

/***************************************************************************//**
 * @brief Cycling Power client event data.
*******************************************************************************/
typedef struct {
    uint16_t    conn_hdl;  /**< Connection handle */
    uint16_t    param_len; /**< Event parameter length */
    const void *p_param;   /**< Event parameter */
} st_ble_cpc_evt_data_t;

/***************************************************************************//**
 * @brief Cycling Power characteristic ID.
*******************************************************************************/
typedef enum {
    BLE_CPC_MEAS_IDX,
    BLE_CPC_MEAS_CLI_CNFG_IDX,
    BLE_CPC_MEAS_SER_CNFG_IDX,
    BLE_CPC_FEAT_IDX,
    BLE_CPC_SENSOR_LOC_IDX,
    BLE_CPC_VECTOR_IDX,
    BLE_CPC_VECTOR_CLI_CNFG_IDX,
    BLE_CPC_CP_IDX,
    BLE_CPC_CP_CLI_CNFG_IDX,
} e_ble_cpc_char_idx_t;

/***************************************************************************//**
 * @brief Cycling Power client event type.
*******************************************************************************/
typedef enum {
    /* Cycling Power Measurement */
    BLE_CPC_EVENT_MEAS_HDL_VAL_NTF = BLE_SERVC_ATTR_EVENT(BLE_CPC_MEAS_IDX, BLE_SERVC_HDL_VAL_NTF),
    BLE_CPC_EVENT_MEAS_CLI_CNFG_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_CPC_MEAS_CLI_CNFG_IDX, BLE_SERVC_READ_RSP),
    BLE_CPC_EVENT_MEAS_CLI_CNFG_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_CPC_MEAS_CLI_CNFG_IDX, BLE_SERVC_WRITE_RSP),
    BLE_CPC_EVENT_MEAS_SER_CNFG_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_CPC_MEAS_SER_CNFG_IDX, BLE_SERVC_READ_RSP),
    BLE_CPC_EVENT_MEAS_SER_CNFG_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_CPC_MEAS_SER_CNFG_IDX, BLE_SERVC_WRITE_RSP),
    /* Cycling Power Feature */
    BLE_CPC_EVENT_FEAT_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_CPC_FEAT_IDX, BLE_SERVC_READ_RSP),
    /* Sensor Location */
    BLE_CPC_EVENT_SENSOR_LOC_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_CPC_SENSOR_LOC_IDX, BLE_SERVC_READ_RSP),
    /* Cycling Power Vector */
    BLE_CPC_EVENT_VECTOR_HDL_VAL_NTF = BLE_SERVC_ATTR_EVENT(BLE_CPC_VECTOR_IDX, BLE_SERVC_HDL_VAL_NTF),
    BLE_CPC_EVENT_VECTOR_CLI_CNFG_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_CPC_VECTOR_CLI_CNFG_IDX, BLE_SERVC_READ_RSP),
    BLE_CPC_EVENT_VECTOR_CLI_CNFG_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_CPC_VECTOR_CLI_CNFG_IDX, BLE_SERVC_WRITE_RSP),
    /* Cycling Power Control Point */
    BLE_CPC_EVENT_CP_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_CPC_CP_IDX, BLE_SERVC_WRITE_RSP),
    BLE_CPC_EVENT_CP_HDL_VAL_IND = BLE_SERVC_ATTR_EVENT(BLE_CPC_CP_IDX, BLE_SERVC_HDL_VAL_IND),
    BLE_CPC_EVENT_CP_CLI_CNFG_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_CPC_CP_CLI_CNFG_IDX, BLE_SERVC_READ_RSP),
    BLE_CPC_EVENT_CP_CLI_CNFG_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_CPC_CP_CLI_CNFG_IDX, BLE_SERVC_WRITE_RSP),
} e_ble_cpc_event_t;

/***************************************************************************//**
 * @brief     Initialize Cycling Power client.
 * @param[in] cb Client callback.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_CPC_Init(ble_servc_app_cb_t cb);

/***************************************************************************//**
 * @brief     Cycling Power client discovery callback.
 * @param[in] conn_hdl Connection handle
 * @param[in] serv_idx Service instance index.
 * @param[in] type     Service discovery event type.
 * @param[in] p_param  Service discovery event parameter.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_CPC_ServDiscCb(uint16_t conn_hdl, uint8_t serv_idx, uint16_t type, void *p_param);

/***************************************************************************//**
 * @brief     Get Cycling Power client attribute handle.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
*******************************************************************************/
void R_BLE_CPC_GetServAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_gatt_hdl_range_t *p_hdl);

#endif /* R_BLE_CPC_H */

/** @} */
