/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_cpc.c
 * Version : 1.0
 * Description : The source file for Cycling Power client.
 **********************************************************************************************************************/
#include <stdlib.h>
#include <string.h>
#include "r_ble_cpc.h"
#include "profile_cmn/r_ble_servc_if.h"

#ifndef UNUSED_ARG
#define UNUSED_ARG(arg)         (void)(arg)
#endif /* UNUSED_ARG */

static st_ble_servc_info_t gs_client_info;

/*----------------------------------------------------------------------------------------------------------------------
    Cycling Power Measurement Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Cycling Power Measurement characteristic descriptors attribute handles */
static uint16_t gs_meas_cli_cnfg_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_meas_cli_cnfg ={
    .uuid_16     = BLE_CPC_MEAS_CLI_CNFG_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint16_t),
    .db_size     = BLE_CPC_MEAS_CLI_CNFG_LEN,
    .desc_idx    = BLE_CPC_MEAS_CLI_CNFG_IDX,
    .p_attr_hdls = gs_meas_cli_cnfg_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_CPC_WriteMeasCliCnfg(uint16_t conn_hdl, const uint16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_meas_cli_cnfg, conn_hdl, p_value);
}

ble_status_t R_BLE_CPC_ReadMeasCliCnfg(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_meas_cli_cnfg, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Cycling Power Measurement Server Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Cycling Power Measurement characteristic descriptors attribute handles */
static uint16_t gs_meas_ser_cnfg_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_meas_ser_cnfg ={
    .uuid_16     = BLE_CPC_MEAS_SER_CNFG_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint16_t),
    .db_size     = BLE_CPC_MEAS_SER_CNFG_LEN,
    .desc_idx    = BLE_CPC_MEAS_SER_CNFG_IDX,
    .p_attr_hdls = gs_meas_ser_cnfg_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_CPC_WriteMeasSerCnfg(uint16_t conn_hdl, const uint16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_meas_ser_cnfg, conn_hdl, p_value);
}

ble_status_t R_BLE_CPC_ReadMeasSerCnfg(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_meas_ser_cnfg, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Cycling Power Measurement Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Cycling Power Measurement characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_meas_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

static ble_status_t decode_st_ble_cpc_meas_t(st_ble_cpc_meas_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;
    uint16_t flag = 0;
    
    if ((NULL == p_gatt_value) || (0 == p_gatt_value->value_len))
    {
        return BLE_ERR_INVALID_PTR;
    }
    
    memset(p_app_value, 0x00, sizeof(st_ble_cpc_meas_t));
    
    /* cast unpack */
    BT_UNPACK_LE_2_BYTE(&flag, &p_gatt_value->p_value[pos])
    pos += 2;

    /* Unpacking  instantaneous power */
    BT_UNPACK_LE_2_BYTE(&p_app_value->instantaneous_power, &p_gatt_value->p_value[pos])
    pos += 2;

    /* Unpacking instantaneous speed measurement */
    if (flag & BLE_PRV_CPC_CP_MESURMNT_FLAGS_PEDAL_POWER_BALANCE_PRSNT)
    {
        p_app_value->flags.is_pedal_power_balance_present = true;

        /* cast unpack */
        BT_UNPACK_LE_1_BYTE(&p_app_value->pedal_power_balance, &p_gatt_value->p_value[pos++])
    }
    
    if( flag & BLE_PRV_CPC_CP_MESURMNT_FLAGS_PEDAL_POWER_BALANCE_REFERENCE )
    {
        p_app_value->flags.is_pedal_power_balance_reference = true;
    }
    
    /* Unpacking Accumulated Torque */
    if (flag & BLE_PRV_CPC_CP_MESURMNT_FLAGS_ACCUMULATED_TORQUE_PRSNT)
    {
        p_app_value->flags.is_accumulated_torque_present = true;

        /* cast unpack */
        BT_UNPACK_LE_2_BYTE(&p_app_value->accumulated_torque, &p_gatt_value->p_value[pos])
        pos += 2;
    }
    
    if( flag & BLE_PRV_CPC_CP_MESURMNT_FLAGS_ACCUMULATED_TORQUE_SOURCE )
    {
        p_app_value->flags.is_accumulated_torque_source = true;
    }
    
    /* Unpacking Wheel Revolution Data */
    if (flag & BLE_PRV_CPC_CP_MESURMNT_FLAGS_WHEEL_REVOLUTION_DATA_PRSNT)
    {
        p_app_value->flags.is_wheel_revolution_data_present = true;
        
        /* cast unpack */
        BT_UNPACK_LE_4_BYTE(&p_app_value->wheel_revolution_data___cumulative_wheel_revolutions, &p_gatt_value->p_value[pos])
        pos += 4;

        /* cast unpack */
        BT_UNPACK_LE_2_BYTE(&p_app_value->wheel_revolution_data___last_wheel_event_time, &p_gatt_value->p_value[pos])
        pos += 2;
    }
    
    /* Unpacking Crank Revolution Data */
    if (flag & BLE_PRV_CPC_CP_MESURMNT_FLAGS_CRANK_REVOLUTION_DATA_PRSNT)
    {
        p_app_value->flags.is_crank_revolution_data_present = true;
        
        /* cast unpack */
        BT_UNPACK_LE_2_BYTE(&p_app_value->crank_revolution_data__cumulative_crank_revolutions, &p_gatt_value->p_value[pos])
        pos += 2;
        /* cast unpack */
        BT_UNPACK_LE_2_BYTE(&p_app_value->crank_revolution_data__last_crank_event_time, &p_gatt_value->p_value[pos])
        pos += 2;
    }
    
    /* Unpacking Extreme Force Magnitudes */
    if (flag & BLE_PRV_CPC_CP_MESURMNT_FLAGS_EXTREME_FORCE_MAGNITUDES_PRSNT)
    {
        p_app_value->flags.is_extreme_force_magnitudes_present = true;
        
        /* cast unpack */
        BT_UNPACK_LE_2_BYTE(&p_app_value->extreme_force_magnitudes___maximum_force_magnitude, &p_gatt_value->p_value[pos])
        pos += 2;
        
        /* cast unpack */
        BT_UNPACK_LE_2_BYTE(&p_app_value->extreme_force_magnitudes___minimum_force_magnitude, &p_gatt_value->p_value[pos])
        pos += 2;
    }
    
    /* Unpacking Extreme Torque Magnitudes */
    if (flag & BLE_PRV_CPC_CP_MESURMNT_FLAGS_EXTREME_TORQUE_MAGNITUDES_PRSNT)
    {
        p_app_value->flags.is_extreme_torque_magnitudes_present = true;
        
        /* cast unpack */
        BT_UNPACK_LE_2_BYTE(&p_app_value->extreme_torque_magnitudes__maximum_torque_magnitude, &p_gatt_value->p_value[pos])
        pos += 2;
        
        /* cast unpack */
        BT_UNPACK_LE_2_BYTE(&p_app_value->extreme_torque_magnitudes__minimum_torque_magnitude, &p_gatt_value->p_value[pos])
        pos += 2;
    }
    
    /* Unpacking Extreme Angles */
    if (flag & BLE_PRV_CPC_CP_MESURMNT_FLAGS_EXTREME_ANGLES_PRSNT)
    {
        p_app_value->flags.is_extreme_angles_present = true;

        /* Unpack 12 bits into 16 bits */
        BT_UNPACK_LE_2_BYTE(&p_app_value->extreme_angles___maximum_angle, &p_gatt_value->p_value[pos]);
        p_app_value->extreme_angles___maximum_angle &= 0x0fff;
        p_app_value->extreme_angles___minimum_angle = (uint16_t)(((p_gatt_value->p_value[pos + 1] >> 4) & 0x0f) | ((uint16_t)p_gatt_value->p_value[pos + 2] << 4));
        pos += 3;
    }
    
    /* Unpacking Top Dead Spot Angle */
    if (flag & BLE_PRV_CPC_CP_MESURMNT_FLAGS_TOP_DEAD_SPOT_ANGLE_PRSNT)
    {
        p_app_value->flags.is_top_dead_spot_angle_present = true;
        
        /* cast unpack */
        BT_UNPACK_LE_2_BYTE(&p_app_value->top_dead_spot_angle, &p_gatt_value->p_value[pos])
        pos += 2;
    }
    
    /* Unpacking Bottom Dead Spot Angle */
    if (flag & BLE_PRV_CPC_CP_MESURMNT_FLAGS_BOTTOM_DEAD_SPOT_ANGLE_PRSNT)
    {
        p_app_value->flags.is_bottom_dead_spot_angle_present = true;
        
        /* cast unpackng */
        BT_UNPACK_LE_2_BYTE(&p_app_value->bottom_dead_spot_angle, &p_gatt_value->p_value[pos])
        pos += 2;
    }
    
    /* Unpacking Accumulated Energy */
    if (flag & BLE_PRV_CPC_CP_MESURMNT_FLAGS_ACCUMULATED_ENERGY_PRSNT)
    {
        p_app_value->flags.is_accumulated_energy_present = true;
        
        /* cast unpackng */
        BT_UNPACK_LE_2_BYTE(&p_app_value->accumulated_energy, &p_gatt_value->p_value[pos])
        pos += 2;
    }
    
    if( flag & BLE_PRV_CPC_CP_MESURMNT_FLAGS_OFFSET_COMPENSATION_INDICATOR )
    {
        p_app_value->flags.is_offset_compensation_indicator = true;
    }
    
    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_cpc_meas_t(const st_ble_cpc_meas_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    UNUSED_ARG(p_app_value);
    UNUSED_ARG(p_gatt_value);

    return BLE_SUCCESS;
}

/* Cycling Power Measurement characteristic descriptor definition */
static const st_ble_servc_desc_info_t *gspp_meas_descs[] = {
    &gs_meas_cli_cnfg,
    &gs_meas_ser_cnfg,
};

/* Cycling Power Measurement characteristic definition */
static const st_ble_servc_char_info_t gs_meas_char = {
    .uuid_16      = BLE_CPC_MEAS_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_cpc_meas_t),
    .db_size      = BLE_CPC_MEAS_LEN,
    .char_idx     = BLE_CPC_MEAS_IDX,
    .p_attr_hdls  = gs_meas_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_cpc_meas_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_cpc_meas_t,
    .num_of_descs = ARRAY_SIZE(gspp_meas_descs),
    .pp_descs     = gspp_meas_descs,
};

void R_BLE_CPC_GetMeasAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_cpc_meas_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_meas_char_ranges[conn_idx];
    p_hdl->cli_cnfg_desc_hdl = gs_meas_cli_cnfg_desc_hdls[conn_idx];
    p_hdl->ser_cnfg_desc_hdl = gs_meas_ser_cnfg_desc_hdls[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Cycling Power Feature Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Cycling Power Feature characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_feat_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

static ble_status_t decode_st_ble_cpc_feat_t(st_ble_cpc_feat_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    if ((NULL == p_gatt_value) || (0 == p_gatt_value->value_len))
    {
        return BLE_ERR_INVALID_PTR;
    }
    
    p_app_value->is_pedal_power_balance_supported             = (p_gatt_value->p_value[0] >> 0) & 0x01;
    p_app_value->is_accumulated_torque_supported              = (p_gatt_value->p_value[0] >> 1) & 0x01;
    p_app_value->is_wheel_revolution_data_supported           = (p_gatt_value->p_value[0] >> 2) & 0x01;
    p_app_value->is_crank_revolution_data_supported           = (p_gatt_value->p_value[0] >> 3) & 0x01;
    p_app_value->is_extreme_magnitudes_supported              = (p_gatt_value->p_value[0] >> 4) & 0x01;
    p_app_value->is_extreme_angles_supported                  = (p_gatt_value->p_value[0] >> 5) & 0x01;
    p_app_value->is_top_and_bottom_dead_spot_angles_supported = (p_gatt_value->p_value[0] >> 6) & 0x01;
    p_app_value->is_accumulated_energy_supported              = (p_gatt_value->p_value[0] >> 7) & 0x01;

    p_app_value->is_offset_compensation_indicator_supported   = (p_gatt_value->p_value[1] >> 0) & 0x01;
    p_app_value->is_offset_compensation_supported             = (p_gatt_value->p_value[1] >> 1) & 0x01;
    p_app_value->is_cycling_power_measurement_characteristic_content_masking_supported = (p_gatt_value->p_value[1] >> 2) & 0x01;
    p_app_value->is_multiple_sensor_locations_supported       = (p_gatt_value->p_value[1] >> 3) & 0x01;
    p_app_value->is_crank_length_adjustment_supported         = (p_gatt_value->p_value[1] >> 4) & 0x01;
    p_app_value->is_chain_length_adjustment_supported         = (p_gatt_value->p_value[1] >> 5) & 0x01;
    p_app_value->is_chain_weight_adjustment_supported         = (p_gatt_value->p_value[1] >> 6) & 0x01;
    p_app_value->is_span_length_adjustment_supported          = (p_gatt_value->p_value[1] >> 7) & 0x01;

    p_app_value->is_sensor_measurement_context                    = (p_gatt_value->p_value[2] >> 0) & 0x01;
    p_app_value->is_instantaneous_measurement_direction_supported = (p_gatt_value->p_value[2] >> 1) & 0x01;
    p_app_value->is_factory_calibration_date_supported            = (p_gatt_value->p_value[2] >> 2) & 0x01;
    p_app_value->is_enhanced_offset_compensation_supported        = (p_gatt_value->p_value[2] >> 3) & 0x01;

    p_app_value->distribute_system_support                        = (p_gatt_value->p_value[2] >> 4) & 0x03;

    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_cpc_feat_t(const st_ble_cpc_feat_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    UNUSED_ARG(p_app_value);
    UNUSED_ARG(p_gatt_value);

    return BLE_SUCCESS;
}

/* Cycling Power Feature characteristic definition */
static const st_ble_servc_char_info_t gs_feat_char = {
    .uuid_16      = BLE_CPC_FEAT_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_cpc_feat_t),
    .db_size      = BLE_CPC_FEAT_LEN,
    .char_idx     = BLE_CPC_FEAT_IDX,
    .p_attr_hdls  = gs_feat_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_cpc_feat_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_cpc_feat_t,
};

ble_status_t R_BLE_CPC_ReadFeat(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_feat_char, conn_hdl);
}

void R_BLE_CPC_GetFeatAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_cpc_feat_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_feat_char_ranges[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Sensor Location Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Sensor Location characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_sensor_loc_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

/* Sensor Location characteristic definition */
const st_ble_servc_char_info_t gs_sensor_loc_char = {
    .uuid_16      = BLE_CPC_SENSOR_LOC_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(uint8_t),
    .db_size      = BLE_CPC_SENSOR_LOC_LEN,
    .char_idx     = BLE_CPC_SENSOR_LOC_IDX,
    .p_attr_hdls  = gs_sensor_loc_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_uint8_t,
    .encode       = (ble_servc_attr_encode_t)encode_uint8_t,
};

ble_status_t R_BLE_CPC_ReadSensorLoc(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_sensor_loc_char, conn_hdl);
}

void R_BLE_CPC_GetSensorLocAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_cpc_sensor_loc_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_sensor_loc_char_ranges[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Cycling Power Vector Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Cycling Power Vector characteristic descriptors attribute handles */
static uint16_t gs_vector_cli_cnfg_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_vector_cli_cnfg ={
    .uuid_16     = BLE_CPC_VECTOR_CLI_CNFG_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint16_t),
    .db_size     = BLE_CPC_VECTOR_CLI_CNFG_LEN,
    .desc_idx    = BLE_CPC_VECTOR_CLI_CNFG_IDX,
    .p_attr_hdls = gs_vector_cli_cnfg_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_CPC_WriteVectorCliCnfg(uint16_t conn_hdl, const uint16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_vector_cli_cnfg, conn_hdl, p_value);
}

ble_status_t R_BLE_CPC_ReadVectorCliCnfg(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_vector_cli_cnfg, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Cycling Power Vector Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Cycling Power Vector characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_vector_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

static ble_status_t decode_st_ble_cpc_vector_t(st_ble_cpc_vector_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;
    uint8_t flag = 0;

    if ((NULL == p_gatt_value) || (0 == p_gatt_value->value_len))
    {
        return BLE_ERR_INVALID_PTR;
    }

    memset(p_app_value, 0x00, sizeof(st_ble_cpc_vector_t));
    
    /*cast unpackng*/
    BT_UNPACK_LE_1_BYTE(&flag, &p_gatt_value->p_value[pos++])

    /* Unpacking pedal power balance measurement  */
    if (flag & BLE_PRV_CPC_CPV_FLAGS_CRANK_REVLUTN_DATA_PRSNT)
    {
        p_app_value->flags.is_crank_revolution_data_present = true;

        /*cast unpacking*/
        BT_UNPACK_LE_2_BYTE(&p_app_value->crank_revolution_data___cumulative_crank_revolutions, &p_gatt_value->p_value[pos])
        pos += 2;

        /*cast unpacking*/
        BT_UNPACK_LE_2_BYTE(&p_app_value->crank_revolution_data___last_crank_event_time, &p_gatt_value->p_value[pos])
        pos += 2;
    }

    /* Unpacking First Crank Measurement  */
    if (flag & BLE_PRV_CPC_CPV_FLAGS_FIRST_CRANK_MESURMNT_ANGLE_PRSNT)
    {
        p_app_value->flags.is_first_crank_measurement_angle_present = true;
        
        /*cast unpacking*/
        BT_UNPACK_LE_2_BYTE(&p_app_value->first_crank_measurement_angle_, &p_gatt_value->p_value[pos])
        pos += 2;
    }

    /* Unpacking Instantaneous Force Magnitude */
    if (flag & BLE_PRV_CPC_CPV_FLAGS_INSTANT_FORCE_MAGNITUDE_ARR_PRSNT)
    {
        p_app_value->flags.is_instantaneous_force_magnitude_array_present = true;
        
        /*cast unpacking*/
        BT_UNPACK_LE_2_BYTE(&p_app_value->instantaneous_force_magnitude_array, &p_gatt_value->p_value[pos])
        pos += 2;
    }
    
    /* Unpacking Instantaneous Torque Magnitude */
    if (flag & BLE_PRV_CPC_CPV_FLAGS_INSTANT_TORQUE_MAGNITUDE_ARR_PRSNT)
    {
        p_app_value->flags.is_instantaneous_torque_magnitude_array_present = true;
        
        /*cast unpacking*/
        BT_UNPACK_LE_2_BYTE(&p_app_value->instantaneous_torque_magnitude_array, &p_gatt_value->p_value[pos])
        pos += 2;
    }

    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_cpc_vector_t(const st_ble_cpc_vector_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    UNUSED_ARG(p_app_value);
    UNUSED_ARG(p_gatt_value);

    return BLE_SUCCESS;
}

/* Cycling Power Vector characteristic descriptor definition */
static const st_ble_servc_desc_info_t *gspp_vector_descs[] = {
    &gs_vector_cli_cnfg,
};

/* Cycling Power Vector characteristic definition */
const st_ble_servc_char_info_t gs_vector_char = {
    .uuid_16      = BLE_CPC_VECTOR_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_cpc_vector_t),
    .db_size      = BLE_CPC_VECTOR_LEN,
    .char_idx     = BLE_CPC_VECTOR_IDX,
    .p_attr_hdls  = gs_vector_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_cpc_vector_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_cpc_vector_t,
    .num_of_descs = ARRAY_SIZE(gspp_vector_descs),
    .pp_descs     = gspp_vector_descs,
};

void R_BLE_CPC_GetVectorAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_cpc_vector_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_vector_char_ranges[conn_idx];
    p_hdl->cli_cnfg_desc_hdl = gs_vector_cli_cnfg_desc_hdls[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Cycling Power Control Point Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Cycling Power Control Point characteristic descriptors attribute handles */
static uint16_t gs_cp_cli_cnfg_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_cp_cli_cnfg ={
    .uuid_16     = BLE_CPC_CP_CLI_CNFG_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint16_t),
    .db_size     = BLE_CPC_CP_CLI_CNFG_LEN,
    .desc_idx    = BLE_CPC_CP_CLI_CNFG_IDX,
    .p_attr_hdls = gs_cp_cli_cnfg_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_CPC_WriteCpCliCnfg(uint16_t conn_hdl, const uint16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_cp_cli_cnfg, conn_hdl, p_value);
}

ble_status_t R_BLE_CPC_ReadCpCliCnfg(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_cp_cli_cnfg, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Cycling Power Control Point Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Cycling Power Control Point characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_cp_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

static ble_status_t decode_st_ble_cpc_cp_t(st_ble_cpc_cp_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 3;
    uint8_t opcode = 0;

    if ((NULL == p_gatt_value) || (0 == p_gatt_value->value_len))
    {
        return BLE_ERR_INVALID_PTR;
    }

    memset(p_app_value, 0x00, sizeof(st_ble_cpc_cp_t));

    opcode = p_gatt_value->p_value[1];

    switch (opcode)
    {
        case BLE_CPC_CP_OP_CODES_SET_CUMULATIVE_VALUE:
        case BLE_CPC_CP_OP_CODES_SET_CRANK_LENGTH:
        case BLE_CPC_CP_OP_CODES_SET_CHAIN_LENGTH:
        case BLE_CPC_CP_OP_CODES_SET_CHAIN_WEIGHT:
        case BLE_CPC_CP_OP_CODES_SET_SPAN_LENGTH:
        case BLE_CPC_CP_OP_CODES_UPDATE_SENSOR_LOCATION:
        case BLE_CPC_CP_OP_CODES_MASK_CYCLING_POWER_MEASUREMENT_CHARACTERISTIC_CONTENT:
        {
            ;/* Do Nothing */
        } break;
        
        case BLE_CPC_CP_OP_CODES_START_OFFSET_COMPENSATION:
        {
            BT_UNPACK_LE_2_BYTE(&p_app_value->resp_param.offset_comp, &p_gatt_value->p_value[pos]);
        } break; /* ??? */

        case BLE_CPC_CP_OP_CODES_REQUEST_SUPPORTED_SENSOR_LOCATIONS:
        {
            uint8_t num_of_supported_loc = (uint8_t)strlen((const char*)p_app_value->resp_param.list_of_supported_locations);
            memcpy(p_app_value->resp_param.list_of_supported_locations, &p_gatt_value->p_value[pos], num_of_supported_loc);
        } break;

        case BLE_CPC_CP_OP_CODES_REQUEST_CRANK_LENGTH:
        {
            /* Unpacking crank_length with p_gatt_value */
            BT_UNPACK_LE_2_BYTE(&p_app_value->resp_param.crank_length, &p_gatt_value->p_value[pos]);
        } break;

        case BLE_CPC_CP_OP_CODES_REQUEST_CHAIN_LENGTH:
        {
            /* Unpacking chain_length with p_gatt_value */
            BT_UNPACK_LE_2_BYTE(&p_app_value->resp_param.chain_length, &p_gatt_value->p_value[pos]);
        } break;

        case BLE_CPC_CP_OP_CODES_REQUEST_CHAIN_WEIGHT:
        {
            /* Unpacking chain_weight with p_gatt_value */
            BT_UNPACK_LE_2_BYTE(&p_app_value->resp_param.chain_weight, &p_gatt_value->p_value[pos]);
        } break;
        
        case BLE_CPC_CP_OP_CODES_REQUEST_SPAN_LENGTH:
        {
            /* Unpacking span_length with p_gatt_value */
            BT_UNPACK_LE_2_BYTE(&p_app_value->resp_param.span_length, &p_gatt_value->p_value[pos]);
        } break;

        case BLE_CPC_CP_OP_CODES_REQUEST_SAMPLING_RATE:
        {
            /* Unpacking span_length with p_gatt_value */
            BT_UNPACK_LE_1_BYTE(&p_app_value->resp_param.span_length, &p_gatt_value->p_value[pos]);
        } break;

        case BLE_CPC_CP_OP_CODES_REQUEST_FACTORY_CALIBRATION_DATE:
        {
            p_app_value->resp_param.factory_calibration_date.year = (uint16_t)((p_gatt_value->p_value[pos] << 0) | (p_gatt_value->p_value[pos] << 8));
            pos++;
            p_app_value->resp_param.factory_calibration_date.month = p_gatt_value->p_value[pos++];
            p_app_value->resp_param.factory_calibration_date.day = p_gatt_value->p_value[pos++];
            p_app_value->resp_param.factory_calibration_date.hours = p_gatt_value->p_value[pos++];
            p_app_value->resp_param.factory_calibration_date.minutes = p_gatt_value->p_value[pos++];
            p_app_value->resp_param.factory_calibration_date.seconds = p_gatt_value->p_value[pos++];
        } break;

        case BLE_CPC_CP_OP_CODES_START_ENHANCED_OFFSET_COMPENSATION:
        {
            /* operation failed check */
            if( 0x04 != p_gatt_value->p_value[2] )
            {
                /* Unpacking cntxt_bit_cyclic_power_feature with p_gatt_value */
                BT_UNPACK_LE_2_BYTE(&p_app_value->resp_param.eocr_response.cntxt_bit_cyclic_power_feature, &p_gatt_value->p_value[pos]);
                pos += 2;

                /* Unpacking company_id with p_gatt_value */
                BT_UNPACK_LE_2_BYTE(&p_app_value->resp_param.eocr_response.company_id, &p_gatt_value->p_value[pos]);
                pos += 2;

                /* Unpacking num_of_octets with p_gatt_value */
                BT_UNPACK_LE_1_BYTE(&p_app_value->resp_param.eocr_response.num_of_octets, &p_gatt_value->p_value[pos++]);

                if (p_app_value->resp_param.eocr_response.num_of_octets > 0)
                {
                    /* Casting manufacturer_data with uint8 type data */
                    p_app_value->resp_param.eocr_response.manufacturer_data = (uint8_t*)malloc(p_app_value->resp_param.eocr_response.num_of_octets);
                    memcpy(&p_app_value->resp_param.eocr_response.manufacturer_data, &p_gatt_value->p_value[pos], p_app_value->resp_param.eocr_response.num_of_octets);
                }
            }
            else
            {
                /* operation failed */
                if( 0xff != p_gatt_value->p_value[pos] )
                {
                    BT_UNPACK_LE_1_BYTE(&p_app_value->resp_param.eocr_response.cntxt_bit_cyclic_power_feature, &p_gatt_value->p_value[pos]);
                }
                else
                {
                    pos++;
                    
                    /* Unpacking company_id with p_gatt_value */
                    BT_UNPACK_LE_2_BYTE(&p_app_value->resp_param.eocr_response.company_id, &p_gatt_value->p_value[pos]);
                    pos += 2;
                    
                    /* Unpacking num_of_octets with p_gatt_value */
                    BT_UNPACK_LE_1_BYTE(&p_app_value->resp_param.eocr_response.num_of_octets, &p_gatt_value->p_value[pos++]);
                    
                    if (p_app_value->resp_param.eocr_response.num_of_octets > 0)
                    {
                        /* Casting manufacturer_data with uint8 type data */
                        p_app_value->resp_param.eocr_response.manufacturer_data = (uint8_t*)malloc((size_t)(p_app_value->resp_param.eocr_response.num_of_octets - 1));
                        memcpy(&p_app_value->resp_param.eocr_response.manufacturer_data, &p_gatt_value->p_value[pos], (size_t)(p_app_value->resp_param.eocr_response.num_of_octets - 1));
                    }
                }
            }
        } break;

        default:
        {
            return BLE_ERR_UNSUPPORTED;
        } break;
    }

    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_cpc_cp_t(const st_ble_cpc_cp_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t opcode = p_app_value->op_codes;

    if ((NULL == p_gatt_value) || (0 == p_gatt_value->value_len))
    {
        return BLE_ERR_INVALID_PTR;
    }

    memset(&p_gatt_value->p_value[0], 0x00, p_gatt_value->value_len);

    if (0x00 != opcode)
    {
        p_gatt_value->p_value[0] = opcode;
    }

    switch(opcode)
    {

        case BLE_CPC_CP_OP_CODES_SET_CUMULATIVE_VALUE:
        {
            /* cast packing */
            BT_PACK_LE_4_BYTE(&p_gatt_value->p_value[1], &p_app_value->req_param.cumultive_value);
            p_gatt_value->value_len = sizeof(p_app_value->req_param.cumultive_value) + 1;
          
        } break;
        
        case BLE_CPC_CP_OP_CODES_UPDATE_SENSOR_LOCATION:
        {
            /* cast packing */
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[1], &p_app_value->req_param.sensor_location);
            p_gatt_value->value_len = sizeof(p_app_value->req_param.sensor_location) + 1;
            
        } break;
        
        case BLE_CPC_CP_OP_CODES_SET_CRANK_LENGTH:
        {
            /*cast packing*/
            BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[1], &p_app_value->req_param.crank_length);

           
        } break;
        
        case BLE_CPC_CP_OP_CODES_SET_CHAIN_LENGTH:
        {
            /*cast packing*/
            BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[1], &p_app_value->req_param.chain_length);

            
        } break;
        
        case BLE_CPC_CP_OP_CODES_SET_CHAIN_WEIGHT:
        {
            /*cast packing*/
            BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[1], &p_app_value->req_param.chain_weight);

            
        } break;
        
        case BLE_CPC_CP_OP_CODES_SET_SPAN_LENGTH:
        {
            /*cast packing*/
            BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[1], &p_app_value->req_param.span_length);

           
        } break;
        
        case BLE_CPC_CP_OP_CODES_MASK_CYCLING_POWER_MEASUREMENT_CHARACTERISTIC_CONTENT:
        {
            /*cast packing*/
            BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[1], &p_app_value->req_param.content_settings_cp_mesurmnt);

            
        } break;

        case BLE_CPC_CP_OP_CODES_START_OFFSET_COMPENSATION:
        case BLE_CPC_CP_OP_CODES_REQUEST_SUPPORTED_SENSOR_LOCATIONS:
        case BLE_CPC_CP_OP_CODES_REQUEST_CRANK_LENGTH:
        case BLE_CPC_CP_OP_CODES_REQUEST_CHAIN_LENGTH:
        case BLE_CPC_CP_OP_CODES_REQUEST_CHAIN_WEIGHT:
        case BLE_CPC_CP_OP_CODES_REQUEST_SPAN_LENGTH:
        case BLE_CPC_CP_OP_CODES_REQUEST_SAMPLING_RATE:
        case BLE_CPC_CP_OP_CODES_REQUEST_FACTORY_CALIBRATION_DATE:
        case BLE_CPC_CP_OP_CODES_START_ENHANCED_OFFSET_COMPENSATION:
        case BLE_CPC_CP_OP_CODES_RESPONSE_CODE:
        {
            ;  /* Do nothing. */
        } break;
        
        default:
        {
            ;  /* Do nothing. */
        }
    }

    return BLE_SUCCESS;
}

/* Cycling Power Control Point characteristic descriptor definition */
static const st_ble_servc_desc_info_t *gspp_cp_descs[] = {
    &gs_cp_cli_cnfg,
};

/* Cycling Power Control Point characteristic definition */
static const st_ble_servc_char_info_t gs_cp_char = {
    .uuid_16      = BLE_CPC_CP_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_cpc_cp_t),
    .db_size      = BLE_CPC_CP_LEN,
    .char_idx     = BLE_CPC_CP_IDX,
    .p_attr_hdls  = gs_cp_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_cpc_cp_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_cpc_cp_t,
    .num_of_descs = ARRAY_SIZE(gspp_cp_descs),
    .pp_descs     = gspp_cp_descs,
};

ble_status_t R_BLE_CPC_WriteCp(uint16_t conn_hdl, const st_ble_cpc_cp_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteChar(&gs_cp_char, conn_hdl, p_value);
}

void R_BLE_CPC_GetCpAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_cpc_cp_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_cp_char_ranges[conn_idx];
    p_hdl->cli_cnfg_desc_hdl = gs_cp_cli_cnfg_desc_hdls[conn_idx];
}


/*----------------------------------------------------------------------------------------------------------------------
    Cycling Power client
----------------------------------------------------------------------------------------------------------------------*/

/* Cycling Power client attribute handles */
static st_ble_gatt_hdl_range_t gs_cpc_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

const st_ble_servc_char_info_t *gspp_cpc_chars[] = {
    &gs_meas_char,
    &gs_feat_char,
    &gs_sensor_loc_char,
    &gs_vector_char,
    &gs_cp_char,
};

static st_ble_servc_info_t gs_client_info = {
    .pp_chars     = gspp_cpc_chars,
    .num_of_chars = ARRAY_SIZE(gspp_cpc_chars),
    .p_attr_hdls  = gs_cpc_ranges,
};

ble_status_t R_BLE_CPC_Init(ble_servc_app_cb_t cb) // @suppress("API function naming")
{
    if (NULL == cb)
    {
        return BLE_ERR_INVALID_PTR;
    }

    gs_client_info.cb = cb;

    return R_BLE_SERVC_RegisterClient(&gs_client_info);
}

void R_BLE_CPC_ServDiscCb(uint16_t conn_hdl, uint8_t serv_idx, uint16_t type, void *p_param) // @suppress("API function naming")
{
    R_BLE_SERVC_ServDiscCb(&gs_client_info, conn_hdl, serv_idx, type, p_param);
}

void R_BLE_CPC_GetServAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_gatt_hdl_range_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    *p_hdl = gs_cpc_ranges[conn_idx];
}
