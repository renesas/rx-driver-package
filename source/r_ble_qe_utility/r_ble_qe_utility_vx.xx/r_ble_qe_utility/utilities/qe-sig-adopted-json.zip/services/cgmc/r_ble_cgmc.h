/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
* File Name: r_ble_cgmc.h
* Version : 1.0
* Description : The header file for Continuous Glucose Monitoring client.
**********************************************************************************************************************/
/***********************************************************************************************************************
* History : DD.MM.YYYY Version Description
*         : 24.05.2019 1.00 First Release
***********************************************************************************************************************/

/*******************************************************************************************************************//**
* @file
* @defgroup cgmc Continuous Glucose Monitoring Client
* @{
* @ingroup profile
* @brief   This is the client for the Continuous Glucose Monitoring Service.
**********************************************************************************************************************/
#include "r_ble_rx23w_if.h"
#include "profile_cmn/r_ble_servc_if.h"

#ifndef R_BLE_CGMC_H
#define R_BLE_CGMC_H

/*----------------------------------------------------------------------------------------------------------------------
    CGM Measurement Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_CGMC_MEAS_UUID                    (0x2AA7)
#define BLE_CGMC_MEAS_LEN                     (15)
#define BLE_CGMC_MEAS_CLI_CNFG_UUID           (0x2902)
#define BLE_CGMC_MEAS_CLI_CNFG_LEN            (2)

/***************************************************************************//**
* @brief CGM Measurement Flags value structure.
*******************************************************************************/
typedef struct
{
    bool is_cgm_trend_information_present;

    /**< CGM Trend Information Present */

    bool is_cgm_quality_present;/**< CGM Quality Present */

    bool is_sensor_status_annunciation_field__warning_octet_present;

    /**< Sensor Status Annunciation Field, Warning-Octet present */

    bool is_sensor_status_annunciation_field__cal_temp_octet_present;

    /**< Sensor Status Annunciation Field, Cal/Temp-Octet present */

    bool is_sensor_status_annunciation_field__status_octet_present;

    /**< Sensor Status Annunciation Field, Status-Octet present */
} st_ble_cgmc_meas_flags_t;

/***************************************************************************//**
* @brief CGM Measurement Sensor Status Annunciation value structure.
*******************************************************************************/
typedef struct 
{
    bool is_session_stopped;
    
    /**< Session Stopped */
    
    bool is_device_battery_low;
    
    /**< Device Battery Low */
    
    bool is_sensor_type_incorrect_for_device;

    /**< Sensor type incorrect for device */

    bool is_sensor_malfunction;
    
    /**< Sensor malfunction */
    
    bool is_device_specific_alert;
    
    /**< Device Specific Alert */
    
    bool is_general_device_fault_has_occurred_in_the_sensor;

    /**< General device fault has occurred in the sensor */

    bool is_time_synchronization_between_sensor_and_collector_required;

    /**< Time synchronization between sensor and collector required */

    bool is_calibration_not_allowed;
    
    /**< Calibration not allowed */
    
    bool is_calibration_recommended;
    
    /**< Calibration recommended */
    
    bool is_calibration_required;
    
    /**< Calibration required */
    
    bool is_sensor_temperature_too_high_for_valid_test_result_at_time_of_measurement;

    /**< Sensor Temperature too high for valid test/result at time of measurement */

    bool is_sensor_temperature_too_low_for_valid_test_result_at_time_of_measurement;

    /**< Sensor temperature too low for valid test/result at time of measurement */

    bool is_sensor_result_lower_than_the_patient_low_level;

    /**< Sensor result lower than the Patient Low level */

    bool is_sensor_result_higher_than_the_patient_high_level;

    /**< Sensor result higher than the Patient High level */

    bool is_sensor_result_lower_than_the_hypo_level;

    /**< Sensor result lower than the Hypo level */

    bool is_sensor_result_higher_than_the_hyper_level;

    /**< Sensor result higher than the Hyper level */

    bool is_sensor_rate_of_decrease_exceeded;

    /**< Sensor Rate of Decrease exceeded */

    bool is_sensor_rate_of_increase_exceeded;

    /**< Sensor Rate of Increase exceeded */

    bool is_sensor_result_lower_than_the_device_can_process;

    /**< Sensor result lower than the device can process */

    bool is_sensor_result_higher_than_the_device_can_process;

    /**< Sensor result higher than the device can process */

} st_ble_cgmc_meas_sensor_status_annunciation_t;

/***************************************************************************//**
* @brief CGM Measurement value structure.
*******************************************************************************/
typedef struct 
{
    uint8_t size; 
    
    /**< Size */
    
    st_ble_cgmc_meas_flags_t flags; 
    
    /**< Flags */
    
    st_ble_ieee11073_sfloat_t cgm_glucose_concentration; 

    /**< CGM Glucose Concentration */

    uint16_t time_offset; 
    
    /**< Time Offset */
    
    st_ble_cgmc_meas_sensor_status_annunciation_t sensor_status_annunciation; 

    /**< Sensor Status Annunciation */

    st_ble_ieee11073_sfloat_t cgm_trend_information;

    /**< CGM Trend Information */

    st_ble_ieee11073_sfloat_t cgm_quality; 
    
    /**< CGM Quality */
    
    uint16_t e2e_crc; 
    
    /**< E2E-CRC */

} st_ble_cgmc_meas_t;

/***************************************************************************//**
* @brief CGM Measurement attribute handle value.
*******************************************************************************/
typedef struct 
{
    st_ble_gatt_hdl_range_t range;
    uint16_t cli_cnfg_desc_hdl;
} st_ble_cgmc_meas_attr_hdl_t;

/***************************************************************************//**
* @brief     Read CGM Measurement characteristic Client Characteristic Configuration 
                  descriptor value from the remote GATT database.
* @param[in] conn_hdl Connection handle.
* @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_CGMC_ReadMeasCliCnfg(uint16_t conn_hdl);

/***************************************************************************//**
* @brief     Write CGM Measurement characteristic Client Characteristic Configuration 
                   descriptor value to remote GATT database.
* @param[in] conn_hdl Connection handle.
* @param[in] p_value CGM Measurement characteristic Client Characteristic Configuration 
                    descriptor value to write.
* @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_CGMC_WriteMeasCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
* @brief      Get CGM Measurement attribute handles.
* @param[in]  p_addr Bluetooth device address for the attribute handles.
* @param[out] p_hdl  The pointer to store the retrieved attribute handles.
* @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_CGMC_GetMeasAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_cgmc_meas_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    CGM Feature Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_CGMC_FEAT_UUID           (0x2AA8)
#define BLE_CGMC_FEAT_LEN            (6)
/***************************************************************************//**
* @brief CGM Feature CGM Type enumeration.
*******************************************************************************/
typedef enum 
{
    BLE_CGMC_FEAT_CGM_TYPE_CAPILLARY_WHOLE_BLOOD_1 = 1,

    /**< Capillary Whole blood */

    BLE_CGMC_FEAT_CGM_TYPE_CAPILLARY_PLASMA = 2, 

    /**< Capillary Plasma */

    BLE_CGMC_FEAT_CGM_TYPE_CAPILLARY_WHOLE_BLOOD_2 = 3, 

    /**< Capillary Whole blood */

    BLE_CGMC_FEAT_CGM_TYPE_VENOUS_PLASMA = 4, 

    /**< Venous Plasma */

    BLE_CGMC_FEAT_CGM_TYPE_ARTERIAL_WHOLE_BLOOD = 5, 

    /**< Arterial Whole blood */

    BLE_CGMC_FEAT_CGM_TYPE_ARTERIAL_PLASMA = 6,

    /**< Arterial Plasma */

    BLE_CGMC_FEAT_CGM_TYPE_UNDETERMINED_WHOLE_BLOOD = 7,

    /**< Undetermined Whole blood */

    BLE_CGMC_FEAT_CGM_TYPE_UNDETERMINED_PLASMA = 8,

    /**< Undetermined Plasma */

    BLE_CGMC_FEAT_CGM_TYPE_INTERSTITIAL_FLUID = 9,

    /**< Interstitial Fluid (ISF) */

    BLE_CGMC_FEAT_CGM_TYPE_CONTROL_SOLUTION = 10, 

    /**< Control Solution */

} e_ble_cgmc_feat_cgm_type_t;

/***************************************************************************//**
 * @brief CGM Feature CGM Sample Location enumeration.
*******************************************************************************/
typedef enum 
{
    BLE_CGMC_FEAT_CGM_SAMPLE_LOCATION_FINGER = 1, 

    /**< Finger */

    BLE_CGMC_FEAT_CGM_SAMPLE_LOCATION_ALTERNATE_SITE_TEST = 2, 

    /**< Alternate Site Test (AST) */

    BLE_CGMC_FEAT_CGM_SAMPLE_LOCATION_EARLOBE = 3, 

    /**< Earlobe */

    BLE_CGMC_FEAT_CGM_SAMPLE_LOCATION_CONTROL_SOLUTION = 4, 

    /**< Control solution */

    BLE_CGMC_FEAT_CGM_SAMPLE_LOCATION_SUBCUTANEOUS_TISSUE = 5,

    /**< Subcutaneous tissue */

    BLE_CGMC_FEAT_CGM_SAMPLE_LOCATION_SAMPLE_LOCATION_VALUE_NOT_AVAILABLE = 15,

    /**< Sample Location value not available */

} e_ble_cgmc_feat_cgm_sample_location_t;

/***************************************************************************//**
 * @brief CGM Feature CGM Feature value structure.
*******************************************************************************/
typedef struct 
{
    bool is_calibration_supported; 

    /**< Calibration Supported */

    bool is_patient_high_low_alerts_supported; 

    /**< Patient High/Low Alerts supported */

    bool is_hypo_alerts_supported; 

    /**< Hypo Alerts supported */

    bool is_hyper_alerts_supported;

    /**< Hyper Alerts supported */

    bool is_rate_of_increase_decrease_alerts_supported; 

    /**< Rate of Increase/Decrease Alerts supported */

    bool is_device_specific_alert_supported; 

    /**< Device Specific Alert supported */

    bool is_sensor_malfunction_detection_supported; 

    /**< Sensor Malfunction Detection supported */

    bool is_sensor_temperature_high_low_detection_supported; 

    /**< Sensor Temperature High-Low Detection supported */

    bool is_sensor_result_high_low_detection_supported; 

    /**< Sensor Result High-Low Detection supported */

    bool is_low_battery_detection_supported;

    /**< Low Battery Detection supported */

    bool is_sensor_type_error_detection_supported; 

    /**< Sensor Type Error Detection supported */

    bool is_general_device_fault_supported;

    /**< General Device Fault supported */

    bool is_e2e_crc_supported;

    /**< E2E-CRC supported */

    bool is_multiple_bond_supported; 

    /**< Multiple Bond supported */

    bool is_multiple_sessions_supported; 

    /**< Multiple Sessions supported */

    bool is_cgm_trend_information_supported; 

    /**< CGM Trend Information supported */

    bool is_cgm_quality_supported;

    /**< CGM Quality supported */

} st_ble_cgmc_feat_cgm_feature_t;

/***************************************************************************//**
 * @brief CGM Feature value structure.
*******************************************************************************/
typedef struct 
{
    st_ble_cgmc_feat_cgm_feature_t cgm_feature; /**< CGM Feature */
    uint8_t cgm_type; /**< CGM Type */
    uint8_t cgm_sample_location; /**< CGM Sample Location */
    uint16_t e2e_crc; /**< E2E-CRC */
} st_ble_cgmc_feat_t;

/***************************************************************************//**
 * @brief CGM Feature attribute handle value.
*******************************************************************************/
typedef struct
{
    st_ble_gatt_hdl_range_t range;
} st_ble_cgmc_feat_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read CGM Feature characteristic value from the remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_CGMC_ReadFeat(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief      Get CGM Feature attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_CGMC_GetFeatAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_cgmc_feat_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    CGM Status Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_CGMC_STATUS_UUID           (0x2AA9)
#define BLE_CGMC_STATUS_LEN            (7)
/***************************************************************************//**
 * @brief CGM Status value structure.
*******************************************************************************/
typedef struct 
{
    uint16_t time_offset; /**< Time Offset */
    uint32_t cgm_status; /**< CGM Status */
    uint16_t e2e_crc; /**< E2E-CRC */
} st_ble_cgmc_status_t;

/***************************************************************************//**
 * @brief CGM Status attribute handle value.
*******************************************************************************/
typedef struct
{
    st_ble_gatt_hdl_range_t range;
} st_ble_cgmc_status_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read CGM Status characteristic value from the remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_CGMC_ReadStatus(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief      Get CGM Status attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_CGMC_GetStatusAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_cgmc_status_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    CGM Session Start Time Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_CGMC_SESSION_START_TIME_UUID            (0x2AAA)
#define BLE_CGMC_SESSION_START_TIME_LEN             (11)
/***************************************************************************//**
 * @brief CGM Session Start Time DST-Offset enumeration.
*******************************************************************************/
typedef enum 
{
    BLE_CGMC_SESSION_START_TIME_DST_OFFSET_STANDARD_TIME = 0, 

    /**< Standard Time */

    BLE_CGMC_SESSION_START_TIME_DST_OFFSET_HALF_AN_HOUR_DAYLIGHT_TIME = 2,

    /**< Half An Hour Daylight Time (+0.5h) */

    BLE_CGMC_SESSION_START_TIME_DST_OFFSET_DAYLIGHT_TIME = 4,

    /**< Daylight Time (+1h) */

    BLE_CGMC_SESSION_START_TIME_DST_OFFSET_DOUBLE_DAYLIGHT_TIME = 8,

    /**< Double Daylight Time (+2h) */

} e_ble_cgmc_session_start_time_dst_offset_t;

/***************************************************************************//**
 * @brief CGM Session Start Time value structure.
*******************************************************************************/
typedef struct 
{
    st_ble_date_time_t session_start_time;

    /**< Session Start Time */

    int8_t time_zone; /**< Time Zone */
    uint8_t dst_offset; /**< DST-Offset */
    uint16_t e2e_crc; /**< E2E-CRC */

} st_ble_cgmc_session_start_time_t;

/***************************************************************************//**
 * @brief CGM Session Start Time attribute handle value.
*******************************************************************************/
typedef struct
{
    st_ble_gatt_hdl_range_t range;
} st_ble_cgmc_session_start_time_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read CGM Session Start Time characteristic value from the remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_CGMC_ReadSessionStartTime(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write CGM Session Start Time characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] p_value CGM Session Start Time characteristic value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_CGMC_WriteSessionStartTime(uint16_t conn_hdl, const st_ble_cgmc_session_start_time_t *p_value);
;
/***************************************************************************//**
 * @brief      Get CGM Session Start Time attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_CGMC_GetSessionStartTimeAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_cgmc_session_start_time_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    CGM Session Run Time Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_CGMC_SESSION_RUN_TIME_UUID             (0x2AAB)
#define BLE_CGMC_SESSION_RUN_TIME_LEN              (4)
/***************************************************************************//**
 * @brief CGM Session Run Time value structure.
*******************************************************************************/
typedef struct 
{
    uint16_t cgm_session_run_time; /**< CGM Session Run Time */
    uint16_t e2e_crc; /**< E2E-CRC */
} st_ble_cgmc_session_run_time_t;

/***************************************************************************//**
 * @brief CGM Session Run Time attribute handle value.
*******************************************************************************/
typedef struct 
{
    st_ble_gatt_hdl_range_t range;
} st_ble_cgmc_session_run_time_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read CGM Session Run Time characteristic value from the remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_CGMC_ReadSessionRunTime(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief      Get CGM Session Run Time attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_CGMC_GetSessionRunTimeAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_cgmc_session_run_time_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Record Access Control Point Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_CGMC_RECORD_ACCESS_CP_UUID               (0x2A52)
#define BLE_CGMC_RECORD_ACCESS_CP_LEN                (10)
#define BLE_CGMC_RECORD_ACCESS_CP_CLI_CNFG_UUID      (0x2902)
#define BLE_CGMC_RECORD_ACCESS_CP_CLI_CNFG_LEN       (2)

/***************************************************************************//**
 * @brief Record Access Control Point Op Code enumeration.
*******************************************************************************/
typedef enum 
{
    BLE_CGMC_RECORD_ACCESS_CP_OP_CODE_REPORT_STORED_RECORDS = 1, 

    /**< Report stored records (Operator: Value from Operator Table) */

    BLE_CGMC_RECORD_ACCESS_CP_OP_CODE_DELETE_STORED_RECORDS = 2, 

    /**< Delete stored records (Operator: Value from Operator Table) */

    BLE_CGMC_RECORD_ACCESS_CP_OP_CODE_ABORT_OPERATION = 3, 

    /**< Abort operation (Operator: Null 'value of 0x00 from Operator Table') */

    BLE_CGMC_RECORD_ACCESS_CP_OP_CODE_REPORT_NUMBER_OF_STORED_RECORDS = 4,

    /**< Report number of stored records (Operator: Value from Operator Table) */

    BLE_CGMC_RECORD_ACCESS_CP_OP_CODE_NUMBER_OF_STORED_RECORDS_RESPONSE = 5, 

    /**< Number of stored records response (Operator: Null 'value of 0x00 from Operator Table') */

    BLE_CGMC_RECORD_ACCESS_CP_OP_CODE_RESPONSE_CODE = 6, 

    /**< Response Code (Operator: Null 'value of 0x00 from Operator Table') */

} e_ble_cgmc_record_access_cp_op_code_t;

/***************************************************************************//**
 * @brief Record Access Control Point Operator enumeration.
*******************************************************************************/
typedef enum 
{
    BLE_CGMC_RECORD_ACCESS_CP_OPERATOR_NULL = 0, 

    /**< Null */

    BLE_CGMC_RECORD_ACCESS_CP_OPERATOR_ALL_RECORDS = 1, 

    /**< All records */

    BLE_CGMC_RECORD_ACCESS_CP_OPERATOR_LESS_THAN_OR_EQUAL_TO = 2,

    /**< Less than or equal to */

    BLE_CGMC_RECORD_ACCESS_CP_OPERATOR_GREATER_THAN_OR_EQUAL_TO = 3, 

    /**< Greater than or equal to */

    BLE_CGMC_RECORD_ACCESS_CP_OPERATOR_WITHIN_RANGE_OF = 4, 

    /**< Within range of (inclusive) */

    BLE_CGMC_RECORD_ACCESS_CP_OPERATOR_FIRST_RECORD = 5, 

    /**< First record(i.e. oldest record) */

    BLE_CGMC_RECORD_ACCESS_CP_OPERATOR_LAST_RECORD = 6, 

    /**< Last record (i.e. most recent record) */

} e_ble_cgmc_record_access_cp_operator_t;

/***************************************************************************//**
 * @brief Record Access Control Point Operand enumeration.
*******************************************************************************/
typedef enum 
{
    BLE_CGMC_RECORD_ACCESS_CP_OPERAND_FILTER_PARAMETERS_1 = 1, 

    /**< Filter parameters (as appropriate to Operator and Service) */

    BLE_CGMC_RECORD_ACCESS_CP_OPERAND_FILTER_PARAMETERS_2 = 2, 

    /**< Filter parameters (as appropriate to Operator and Service) */

    BLE_CGMC_RECORD_ACCESS_CP_OPERAND_NOT_INCLUDED = 3,

    /**< Not included */

    BLE_CGMC_RECORD_ACCESS_CP_OPERAND_FILTER_PARAMETERS_4 = 4, 

    /**< Filter parameters (as appropriate to Operator and Service) */

    BLE_CGMC_RECORD_ACCESS_CP_OPERAND_NUMBER_OF_RECORDS = 5,

    /**< Number of Records (Field size defined per service) */

    BLE_CGMC_RECORD_ACCESS_CP_OPERAND_REQUEST_OP_CODE__RESPONSE_CODE_VALUE = 6, 

    /**< Request Op Code, Response Code Value */

} e_ble_cgmc_record_access_cp_operand_t;

/***************************************************************************//**
 * @brief Record Access Control Point Response Code enumeration.
*******************************************************************************/
typedef enum 
{
    BLE_CGMC_RECORD_ACCESS_CP_RESPONSE_CODE_SUCCESS = 1, 

    /**< Normal response for successful operation */

    BLE_CGMC_RECORD_ACCESS_CP_RESPONSE_CODE_OP_CODE_NOT_SUPPORTED = 2, 

    /**< Normal response if unsupported Op Code is received */

    BLE_CGMC_RECORD_ACCESS_CP_RESPONSE_CODE_INVALID_OPERATOR = 3, 

    /**< Normal response if Operator received does not meet the requirements of the service 
    (e.g. Null was expected) */

    BLE_CGMC_RECORD_ACCESS_CP_RESPONSE_CODE_OPERATOR_NOT_SUPPORTED = 4, 

    /**< Normal response if unsupported Operator is received */

    BLE_CGMC_RECORD_ACCESS_CP_RESPONSE_CODE_INVALID_OPERAND = 5, 

    /**< Normal response if Operand received does not meet the requirements of the service */

    BLE_CGMC_RECORD_ACCESS_CP_RESPONSE_CODE_NO_RECORDS_FOUND = 6, 

    /**< Normal response if request to report stored records or request to delete stored 

    records resulted in no records meeting criteria. */

    BLE_CGMC_RECORD_ACCESS_CP_RESPONSE_CODE_ABORT_UNSUCCESSFUL = 7, 

    /**< Normal response if request for Abort cannot be completed */

    BLE_CGMC_RECORD_ACCESS_CP_RESPONSE_CODE_PROCEDURE_NOT_COMPLETED = 8,

    /**< Normal response if unable to complete a procedure for any reason */

    BLE_CGMC_RECORD_ACCESS_CP_RESPONSE_CODE_OPERAND_NOT_SUPPORTED = 9, 

    /**< Normal response if unsupported Operand is received */

} e_ble_cgmc_record_access_cp_response_code_t;

/***************************************************************************//**
 * @brief Record Access Control Point value structure.
*******************************************************************************/
typedef struct
{
    uint8_t op_code;            /**< Op Code */
    uint8_t racp_operator;      /**< Operator */
    uint8_t operand[18];        /**< Operand */
    uint8_t operand_len;        /**< operand Length */
} st_ble_cgmc_record_access_cp_t;

/***************************************************************************//**
 * @brief Record Access Control Point attribute handle value.
*******************************************************************************/
typedef struct 
{
    st_ble_gatt_hdl_range_t range;
    uint16_t cli_cnfg_desc_hdl;
} st_ble_cgmc_record_access_cp_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Record Access Control Point characteristic Client Characteristic 
 Configuration descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_CGMC_ReadRecordAccessCpCliCnfg(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Record Access Control Point characteristic Client Characteristic 
 Configuration descriptor value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value Record Access Control Point characteristic Client Characteristic
 Configuration descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_CGMC_WriteRecordAccessCpCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Write Record Access Control Point characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] p_value Record Access Control Point characteristic value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_CGMC_WriteRecordAccessCp(uint16_t conn_hdl, const st_ble_cgmc_record_access_cp_t *p_value);
;
/***************************************************************************//**
 * @brief      Get Record Access Control Point attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_CGMC_GetRecordAccessCpAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_cgmc_record_access_cp_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    CGM Specific Ops Control Point Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_CGMC_SPECIFIC_OPS_CP_UUID                  (0x2AAC)
#define BLE_CGMC_SPECIFIC_OPS_CP_LEN                   (16)
#define BLE_CGMC_SPECIFIC_OPS_CP_CLI_CNFG_UUID         (0x2902)
#define BLE_CGMC_SPECIFIC_OPS_CP_CLI_CNFG_LEN          (2)

/***************************************************************************//**
 * @brief CGM Specific Ops Control Point Op Code enumeration.
*******************************************************************************/
typedef enum 
{
    BLE_CGMC_SPECIFIC_OPS_CP_OP_CODE_SET_CGM_COMMUNICATION_INTERVAL = 1,

    /**< Set CGM Communication Interval */

    BLE_CGMC_SPECIFIC_OPS_CP_OP_CODE_GET_CGM_COMMUNICATION_INTERVAL = 2, 

    /**< Get CGM Communication Interval */

    BLE_CGMC_SPECIFIC_OPS_CP_OP_CODE_CGM_COMMUNICATION_INTERVAL_RESPONSE = 3, 

    /**< CGM Communication Interval response */

    BLE_CGMC_SPECIFIC_OPS_CP_OP_CODE_SET_GLUCOSE_CALIBRATION_VALUE = 4, 

    /**< Set Glucose Calibration Value */

    BLE_CGMC_SPECIFIC_OPS_CP_OP_CODE_GET_GLUCOSE_CALIBRATION_VALUE = 5, 

    /**< Get Glucose Calibration Value */

    BLE_CGMC_SPECIFIC_OPS_CP_OP_CODE_GLUCOSE_CALIBRATION_VALUE_RESPONSE = 6, 

    /**< Glucose Calibration Value response */

    BLE_CGMC_SPECIFIC_OPS_CP_OP_CODE_SET_PATIENT_HIGH_ALERT_LEVEL = 7,

    /**< Set Patient High Alert Level */

    BLE_CGMC_SPECIFIC_OPS_CP_OP_CODE_GET_PATIENT_HIGH_ALERT_LEVEL = 8, 

    /**< Get Patient High Alert Level */

    BLE_CGMC_SPECIFIC_OPS_CP_OP_CODE_PATIENT_HIGH_ALERT_LEVEL_RESPONSE = 9,

    /**< Patient High Alert Level Response */

    BLE_CGMC_SPECIFIC_OPS_CP_OP_CODE_SET_PATIENT_LOW_ALERT_LEVEL = 10,

    /**< Set Patient Low Alert Level */

    BLE_CGMC_SPECIFIC_OPS_CP_OP_CODE_GET_PATIENT_LOW_ALERT_LEVEL = 11, 

    /**< Get Patient Low Alert Level */

    BLE_CGMC_SPECIFIC_OPS_CP_OP_CODE_PATIENT_LOW_ALERT_LEVEL_RESPONSE = 12, 

    /**< Patient Low Alert Level Response */

    BLE_CGMC_SPECIFIC_OPS_CP_OP_CODE_SET_HYPO_ALERT_LEVEL = 13,

    /**< Set Hypo Alert Level */

    BLE_CGMC_SPECIFIC_OPS_CP_OP_CODE_GET_HYPO_ALERT_LEVEL = 14,

    /**< Get Hypo Alert Level */

    BLE_CGMC_SPECIFIC_OPS_CP_OP_CODE_HYPO_ALERT_LEVEL_RESPONSE = 15, 

    /**< Hypo Alert Level Response */

    BLE_CGMC_SPECIFIC_OPS_CP_OP_CODE_SET_HYPER_ALERT_LEVEL = 16, 

    /**< Set Hyper Alert Level */

    BLE_CGMC_SPECIFIC_OPS_CP_OP_CODE_GET_HYPER_ALERT_LEVEL = 17, 

    /**< Get Hyper Alert Level */

    BLE_CGMC_SPECIFIC_OPS_CP_OP_CODE_HYPER_ALERT_LEVEL_RESPONSE = 18,

    /**< Hyper Alert Level Response */

    BLE_CGMC_SPECIFIC_OPS_CP_OP_CODE_SET_RATE_OF_DECREASE_ALERT_LEVEL = 19, 

    /**< Set Rate of Decrease Alert Level */

    BLE_CGMC_SPECIFIC_OPS_CP_OP_CODE_GET_RATE_OF_DECREASE_ALERT_LEVEL = 20,

    /**< Get Rate of Decrease Alert Level */

    BLE_CGMC_SPECIFIC_OPS_CP_OP_CODE_RATE_OF_DECREASE_ALERT_LEVEL_RESPONSE = 21, 

    /**< Rate of Decrease Alert Level Response */

    BLE_CGMC_SPECIFIC_OPS_CP_OP_CODE_SET_RATE_OF_INCREASE_ALERT_LEVEL = 22,

    /**< Set Rate of Increase Alert Level */

    BLE_CGMC_SPECIFIC_OPS_CP_OP_CODE_GET_RATE_OF_INCREASE_ALERT_LEVEL = 23, 

    /**< Get Rate of Increase Alert Level */

    BLE_CGMC_SPECIFIC_OPS_CP_OP_CODE_RATE_OF_INCREASE_ALERT_LEVEL_RESPONSE = 24, 

    /**< Rate of Increase Alert Level Response */

    BLE_CGMC_SPECIFIC_OPS_CP_OP_CODE_RESET_DEVICE_SPECIFIC_ALERT = 25,

    /**< Reset Device Specific Alert */

    BLE_CGMC_SPECIFIC_OPS_CP_OP_CODE_START_THE_SESSION = 26, 

    /**< Start the Session */

    BLE_CGMC_SPECIFIC_OPS_CP_OP_CODE_STOP_THE_SESSION = 27, 

    /**< Stop the Session */

    BLE_CGMC_SPECIFIC_OPS_CP_OP_CODE_RESPONSE_CODE = 28,

    /**< Response Code */

} e_ble_cgmc_specific_ops_cp_op_code_t;

/***************************************************************************//**
 * @brief CGM Specific Ops Control Point Op Code - Response Codes enumeration.
*******************************************************************************/
typedef enum 
{
    BLE_CGMC_SPECIFIC_OPS_CP_OP_CODE_RESPONSE_CODES_SUCCESS = 1,

    /**< Success */

    BLE_CGMC_SPECIFIC_OPS_CP_OP_CODE_RESPONSE_CODES_OP_CODE_NOT_SUPPORTED = 2,

    /**< Op Code not supported */

    BLE_CGMC_SPECIFIC_OPS_CP_OP_CODE_RESPONSE_CODES_INVALID_OPERAND = 3,

    /**< Invalid Operand */

    BLE_CGMC_SPECIFIC_OPS_CP_OP_CODE_RESPONSE_CODES_PROCEDURE_NOT_COMPLETED = 4,

    /**< Procedure not completed */

    BLE_CGMC_SPECIFIC_OPS_CP_OP_CODE_RESPONSE_CODES_PARAMETER_OUT_OF_RANGE = 5,

    /**< Parameter out of range */

} e_ble_cgmc_specific_ops_cp_op_code_response_codes_t;

/***************************************************************************//**
 * @brief CGM Specific Ops Control Point Operand enumeration.
*******************************************************************************/
typedef enum 
{
    BLE_CGMC_SPECIFIC_OPS_CP_OPERAND_COMMUNICATION_INTERVAL_IN_MINUTES_1 = 1, 

    /**< Communication interval in minutes */

    BLE_CGMC_SPECIFIC_OPS_CP_OPERAND_COMMUNICATION_INTERVAL_IN_MINUTES_2 = 3, 

    /**< Communication Interval in minutes */

    BLE_CGMC_SPECIFIC_OPS_CP_OPERAND_OPERAND_VALUE_AS_DEFINED_IN_THE_CALIBRATION_VALUE_FIELDS_ = 4, 

    /**< Operand value as defined in the Calibration Value Fields. */

    BLE_CGMC_SPECIFIC_OPS_CP_OPERAND_CALIBRATION_DATA_RECORD_NUMBER = 5, 

    /**< Calibration Data Record Number */

    BLE_CGMC_SPECIFIC_OPS_CP_OPERAND_CALIBRATION_DATA = 6, 

    /**< Calibration Data */

    BLE_CGMC_SPECIFIC_OPS_CP_OPERAND_PATIENT_HIGH_BG_VALUE_IN_MG_DL_1 = 7,

    /**< Patient High bG value in mg/dL */

    BLE_CGMC_SPECIFIC_OPS_CP_OPERAND_PATIENT_HIGH_BG_VALUE_IN_MG_DL_2 = 9,

    /**< Patient High bG value in mg/dL */

    BLE_CGMC_SPECIFIC_OPS_CP_OPERAND_PATIENT_LOW_BG_VALUE_IN_MG_DL_1 = 10,

    /**< Patient Low bG value in mg/dL */

    BLE_CGMC_SPECIFIC_OPS_CP_OPERAND_PATIENT_LOW_BG_VALUE_IN_MG_DL_2 = 12,

    /**< Patient Low bG value in mg/dL */

    BLE_CGMC_SPECIFIC_OPS_CP_OPERAND_HYPO_ALERT_LEVEL_VALUE_IN_MG_DL_1 = 13, 

    /**< Hypo Alert Level value in mg/dL */

    BLE_CGMC_SPECIFIC_OPS_CP_OPERAND_HYPO_ALERT_LEVEL_VALUE_IN_MG_DL_2 = 15,

    /**< Hypo Alert Level value in mg/dL */

    BLE_CGMC_SPECIFIC_OPS_CP_OPERAND_HYPER_ALERT_LEVEL_VALUE_IN_MG_DL_1 = 16, 

    /**< Hyper Alert Level value in mg/dL */

    BLE_CGMC_SPECIFIC_OPS_CP_OPERAND_HYPER_ALERT_LEVEL_VALUE_IN_MG_DL_2 = 18, 

    /**< Hyper Alert Level value in mg/dL */

    BLE_CGMC_SPECIFIC_OPS_CP_OPERAND_RATE_OF_DECREASE_ALERT_LEVEL_VALUE_IN_MG_DL_MIN_1 = 19,

    /**< Rate of Decrease Alert Level value in mg/dL/min */

    BLE_CGMC_SPECIFIC_OPS_CP_OPERAND_RATE_OF_DECREASE_ALERT_LEVEL_VALUE_IN_MG_DL_MIN_2 = 21, 

    /**< Rate of Decrease Alert Level value in mg/dL/min */

    BLE_CGMC_SPECIFIC_OPS_CP_OPERAND_RATE_OF_INCREASE_ALERT_LEVEL_VALUE_IN_MG_DL_MIN_1 = 22, 

    /**< Rate of Increase Alert Level value in mg/dL/min */

    BLE_CGMC_SPECIFIC_OPS_CP_OPERAND_RATE_OF_INCREASE_ALERT_LEVEL_VALUE_IN_MG_DL_MIN_2 = 24,

    /**< Rate of Increase Alert Level value in mg/dL/min */

    BLE_CGMC_SPECIFIC_OPS_CP_OPERAND_REQUEST_OP_CODE__RESPONSE_CODE_VALUE = 28,

    /**< Request Op Code, Response Code Value */

} e_ble_cgmc_specific_ops_cp_operand_t;

/***************************************************************************//**
 * @brief CGM Specific Ops Control Point Calibration Value - Calibration Status value structure.
*******************************************************************************/
typedef struct 
{
    bool is_calibration_data_rejected;

    /**< Calibration Data rejected (Calibration failed) */

    bool is_calibration_data_out_of_range;

    /**< Calibration Data out of range */

    bool is_calibration_process_pending;

    /**< Calibration Process Pending */

} st_ble_cgmc_specific_ops_cp_calibration_value_calibration_status_t;

/***************************************************************************//**
 * @brief CGM Specific Ops Control Point value structure.
*******************************************************************************/
typedef struct 
{
    uint8_t op_code;

    /**< Op Code */

    uint8_t op_code_response_codes;

    /**< Op Code - Response Codes */

    uint8_t operand;

    /**< Operand */

    uint16_t e2e_crc;

    /**< E2E-CRC */

    st_ble_ieee11073_sfloat_t calibration_value_glucose_concentration_of_calibration; 

    /**< Calibration Value - Glucose Concentration of Calibration */

    uint16_t calibration_value_calibration_time; 

    /**< Calibration Value - Calibration Time */

    uint8_t calibration_value_calibration_type; 

    /**< Calibration Value - Calibration Type */

    uint8_t calibration_value_calibration_sample_location; 

    /**< Calibration Value - Calibration Sample Location */

    uint16_t calibration_value_next_calibration_time; 

    /**< Calibration Value - Next Calibration Time */

    uint16_t calibration_value_calibration_data_record_number; 

    /**< Calibration Value - Calibration Data Record Number */

    st_ble_cgmc_specific_ops_cp_calibration_value_calibration_status_t calibration_value_calibration_status; 

    /**< Calibration Value - Calibration Status */
} st_ble_cgmc_specific_ops_cp_t;

/***************************************************************************//**
 * @brief CGM Specific Ops Control Point attribute handle value.
*******************************************************************************/
typedef struct
{
    st_ble_gatt_hdl_range_t range;
    uint16_t cli_cnfg_desc_hdl;
} st_ble_cgmc_specific_ops_cp_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read CGM Specific Ops Control Point characteristic Client Characteristic Configuration 
 descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_CGMC_ReadSpecificOpsCpCliCnfg(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write CGM Specific Ops Control Point characteristic Client Characteristic Configuration 
 descriptor value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value CGM Specific Ops Control Point characteristic Client Characteristic Configuration 
 descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_CGMC_WriteSpecificOpsCpCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Write CGM Specific Ops Control Point characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] p_value CGM Specific Ops Control Point characteristic value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_CGMC_WriteSpecificOpsCp(uint16_t conn_hdl, const st_ble_cgmc_specific_ops_cp_t *p_value);
;
/***************************************************************************//**
 * @brief      Get CGM Specific Ops Control Point attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_CGMC_GetSpecificOpsCpAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_cgmc_specific_ops_cp_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Continuous Glucose Monitoring Client
----------------------------------------------------------------------------------------------------------------------*/

/***************************************************************************//**
 * @brief If E2E-CRC is supported and a Write procedure is processed without CRC attached 
*******************************************************************************/
#define BLE_CGMC_MISSING_CRC_ERROR (BLE_ERR_GROUP_GATT | 0x80)

/***************************************************************************//**
 * @brief If E2E-CRC is supported and a Write procedure is processed with incorrect or invalid CRC value attached
*******************************************************************************/
#define BLE_CGMC_INVALID_CRC_ERROR (BLE_ERR_GROUP_GATT | 0x81)

/***************************************************************************//**
 * @brief Continuous Glucose Monitoring client event data.
*******************************************************************************/
typedef struct 
{
    uint16_t    conn_hdl;  /**< Connection handle */
    uint16_t    param_len; /**< Event parameter length */
    const void *p_param;   /**< Event parameter */
} st_ble_cgmc_evt_data_t;

/***************************************************************************//**
 * @brief Continuous Glucose Monitoring characteristic ID.
*******************************************************************************/
typedef enum 
{
    BLE_CGMC_MEAS_IDX,
    BLE_CGMC_MEAS_CLI_CNFG_IDX,
    BLE_CGMC_FEAT_IDX,
    BLE_CGMC_STATUS_IDX,
    BLE_CGMC_SESSION_START_TIME_IDX,
    BLE_CGMC_SESSION_RUN_TIME_IDX,
    BLE_CGMC_RECORD_ACCESS_CP_IDX,
    BLE_CGMC_RECORD_ACCESS_CP_CLI_CNFG_IDX,
    BLE_CGMC_SPECIFIC_OPS_CP_IDX,
    BLE_CGMC_SPECIFIC_OPS_CP_CLI_CNFG_IDX,
} e_ble_cgmc_char_idx_t;

/***************************************************************************//**
 * @brief Continuous Glucose Monitoring client event type.
*******************************************************************************/
typedef enum 
{
    /* CGM Measurement */
    BLE_CGMC_EVENT_MEAS_HDL_VAL_NTF = BLE_SERVC_ATTR_EVENT(BLE_CGMC_MEAS_IDX, BLE_SERVC_HDL_VAL_NTF),
    BLE_CGMC_EVENT_MEAS_CLI_CNFG_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_CGMC_MEAS_CLI_CNFG_IDX, BLE_SERVC_READ_RSP),
    BLE_CGMC_EVENT_MEAS_CLI_CNFG_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_CGMC_MEAS_CLI_CNFG_IDX, BLE_SERVC_WRITE_RSP),
    /* CGM Feature */
    BLE_CGMC_EVENT_FEAT_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_CGMC_FEAT_IDX, BLE_SERVC_READ_RSP),
    /* CGM Status */
    BLE_CGMC_EVENT_STATUS_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_CGMC_STATUS_IDX, BLE_SERVC_READ_RSP),
    /* CGM Session Start Time */
    BLE_CGMC_EVENT_SESSION_START_TIME_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_CGMC_SESSION_START_TIME_IDX, BLE_SERVC_READ_RSP),
    BLE_CGMC_EVENT_SESSION_START_TIME_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_CGMC_SESSION_START_TIME_IDX, BLE_SERVC_WRITE_RSP),
    /* CGM Session Run Time */
    BLE_CGMC_EVENT_SESSION_RUN_TIME_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_CGMC_SESSION_RUN_TIME_IDX, BLE_SERVC_READ_RSP),
    /* Record Access Control Point */
    BLE_CGMC_EVENT_RECORD_ACCESS_CP_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_CGMC_RECORD_ACCESS_CP_IDX, BLE_SERVC_WRITE_RSP),
    BLE_CGMC_EVENT_RECORD_ACCESS_CP_HDL_VAL_IND = BLE_SERVC_ATTR_EVENT(BLE_CGMC_RECORD_ACCESS_CP_IDX, BLE_SERVC_HDL_VAL_IND),
    BLE_CGMC_EVENT_RECORD_ACCESS_CP_CLI_CNFG_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_CGMC_RECORD_ACCESS_CP_CLI_CNFG_IDX, BLE_SERVC_READ_RSP),
    BLE_CGMC_EVENT_RECORD_ACCESS_CP_CLI_CNFG_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_CGMC_RECORD_ACCESS_CP_CLI_CNFG_IDX, BLE_SERVC_WRITE_RSP),
    /* CGM Specific Ops Control Point */
    BLE_CGMC_EVENT_SPECIFIC_OPS_CP_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_CGMC_SPECIFIC_OPS_CP_IDX, BLE_SERVC_WRITE_RSP),
    BLE_CGMC_EVENT_SPECIFIC_OPS_CP_HDL_VAL_IND = BLE_SERVC_ATTR_EVENT(BLE_CGMC_SPECIFIC_OPS_CP_IDX, BLE_SERVC_HDL_VAL_IND),
    BLE_CGMC_EVENT_SPECIFIC_OPS_CP_CLI_CNFG_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_CGMC_SPECIFIC_OPS_CP_CLI_CNFG_IDX, BLE_SERVC_READ_RSP),
    BLE_CGMC_EVENT_SPECIFIC_OPS_CP_CLI_CNFG_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_CGMC_SPECIFIC_OPS_CP_CLI_CNFG_IDX, BLE_SERVC_WRITE_RSP),
} e_ble_cgmc_event_t;

/***************************************************************************//**
 * @brief     Initialize Continuous Glucose Monitoring client.
 * @param[in] cb Client callback.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_CGMC_Init(ble_servc_app_cb_t cb);

/***************************************************************************//**
 * @brief     Continuous Glucose Monitoring client discovery callback.
 * @param[in] conn_hdl Connection handle
 * @param[in] serv_idx Service instance index.
 * @param[in] type     Service discovery event type.
 * @param[in] p_param  Service discovery event parameter.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_CGMC_ServDiscCb(uint16_t conn_hdl, uint8_t serv_idx, uint16_t type, void *p_param);

/***************************************************************************//**
 * @brief     Get Continuous Glucose Monitoring client attribute handle.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
*******************************************************************************/
void R_BLE_CGMC_GetServAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_gatt_hdl_range_t *p_hdl);

#endif /* R_BLE_CGMC_H */

/** @} */
