/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_cgmc.c
 * Version : 1.0
 * Description : The source file for Continuous Glucose Monitoring client.
 **********************************************************************************************************************/
 /************************************************************************************************************************//**
 * History : DD.MM.YYYY Version Description
 *         : 24.05.2019 1.00 First Release
 ***********************************************************************************************************************/
#include <string.h>
#include "r_ble_cgmc.h"
#include "profile_cmn/r_ble_servc_if.h"

static st_ble_servc_info_t gs_client_info;
static st_ble_cgmc_feat_t g_cgm_feature = { 0 };

/*----------------------------------------------------------------------------------------------------------------------
     CGM Measurement FLAGS
 ----------------------------------------------------------------------------------------------------------------------*/
#define BLE_CGMC_PRV_CGM_MEASUREMENT_FLAG_CGM_TREND_INFORMATION_PRESENT                                   (1 << 0)
#define BLE_CGMC_PRV_CGM_MEASUREMENT_FLAG_CGM_QUALITY_PRESENT                                             (1 << 1)
#define BLE_CGMC_PRV_CGM_MEASUREMENT_FLAG_CGM_SENSOR_STATUS_ANNUNCIATION_FIELD_WARNING_OCTECT_PRESENT     (1 << 5)
#define BLE_CGMC_PRV_CGM_MEASUREMENT_FLAG_CGM_SENSOR_STATUS_ANNUNCIATION_FIELD_CAL_TEMP_OCTECT_PRESENT    (1 << 6)
#define BLE_CGMC_PRV_CGM_MEASUREMENT_FLAG_CGM_SENSOR_STATUS_ANNUCIATION_FIELD_STATUS_OCTECT_PRESENT       (1 << 7)

 /*----------------------------------------------------------------------------------------------------------------------
     CGM Measurement Sensor Status Annunciation
 ----------------------------------------------------------------------------------------------------------------------*/
#define BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SESSION_STOPPED                                             (1 << 0)
#define BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_DEVICE_BATTERY_LOW                                          (1 << 1)
#define BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_TYPE_INCORRECT_FOR_DEVICE                            (1 << 2)
#define BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_MALFUNCTION                                          (1 << 3)
#define BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_DEVICE_SPECIFIC_ALERT                                       (1 << 4)
#define BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_GENERAL_DEVICE_FAULT_HAS_OCCURED_IN_THE_SENSOR              (1 << 5)
#define BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_TIME_SYNCHRONIZATION_BETWEEN_SENSOR_AND_COLLECTOR_REQUIRED  (1 << 8)
#define BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_CALIBRATION_NOT_ALLOWED                                     (1 << 9)
#define BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_CALIBRATION_RECOMMENDED                                     (1 << 10)
#define BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_CALIBRATION_REQUIRED                                        (1 << 11)
#define BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_TEMP_TOO_HIGH_FOR_VALID_TEST_RESULT_AT_MEASUREMENT   (1 << 12)
#define BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_TEMP_TOO_LOW_FOR_VALID_TEST_RESULT_AT_MEASUREMENT    (1 << 13)
#define BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_LOWER_THAN_THE_PATIENT_LOW_LEVEL              (1 << 16)
#define BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_HIGHER_THAN_THE_PATIENT_HIGH_LEVEL            (1 << 17)
#define BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_LOWER_THAN_HYPO_LEVEL                         (1 << 18)
#define BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_HIGHER_THAN_HYPER_LEVEL                       (1 << 19)
#define BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RATE_OF_DECREASE_EXCEEDED                            (1 << 20)
#define BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RATE_OF_INCREASE_EXCEEDED                            (1 << 21)
#define BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_LOWER_THAN_DEVICE_CAN_PROCESS                 (1 << 22)
#define BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_HIGHER_THAN_DEVICE_CAN_PROCESS                (1 << 23)

#define BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_TIME_SYNCHRONIZATION_BETWEEN_SENSOR_AND_COLLECTOR_REQUIRED_2  (1 << 0)
#define BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_CALIBRATION_NOT_ALLOWED_2                                     (1 << 1)
#define BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_CALIBRATION_RECOMMENDED_2                                     (1 << 2)
#define BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_CALIBRATION_REQUIRED_2                                        (1 << 3)
#define BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_TEMP_TOO_HIGH_FOR_VALID_TEST_RESULT_AT_MEASUREMENT_2   (1 << 4)
#define BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_TEMP_TOO_LOW_FOR_VALID_TEST_RESULT_AT_MEASUREMENT_2    (1 << 5)
#define BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_LOWER_THAN_THE_PATIENT_LOW_LEVEL_2              (1 << 0)
#define BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_HIGHER_THAN_THE_PATIENT_HIGH_LEVEL_2            (1 << 1)
#define BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_LOWER_THAN_HYPO_LEVEL_2                         (1 << 2)
#define BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_HIGHER_THAN_HYPER_LEVEL_2                       (1 << 3)
#define BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RATE_OF_DECREASE_EXCEEDED_2                            (1 << 4)
#define BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RATE_OF_INCREASE_EXCEEDED_2                            (1 << 5)
#define BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_LOWER_THAN_DEVICE_CAN_PROCESS_2                 (1 << 6)
#define BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_HIGHER_THAN_DEVICE_CAN_PROCESS_2                (1 << 7)

 /*----------------------------------------------------------------------------------------------------------------------
     CGM Measurement Features
 ----------------------------------------------------------------------------------------------------------------------*/
#define BLE_CGMC_PRV_CGM_FEATURES_CALIBRATION_SUPPORTED                                      (1 << 0)
#define BLE_CGMC_PRV_CGM_FEATURES_PATIENT_HIGH_LOW_ALERTS_SUPPORTED                          (1 << 1)
#define BLE_CGMC_PRV_CGM_FEATURES_HYPO_ALERTS_SUPPORTED                                      (1 << 2)
#define BLE_CGMC_PRV_CGM_FEATURES_HYPER_ALERTS_SUPPORTED                                     (1 << 3)
#define BLE_CGMC_PRV_CGM_FEATURES_RATE_OF_INCREASE_DECREASE_ALERTS_SUPPORTED                 (1 << 4)
#define BLE_CGMC_PRV_CGM_FEATURES_DEVICE_SPECIFIC_ALERTS_SUPPORTED                           (1 << 5)
#define BLE_CGMC_PRV_CGM_FEATURES_SENSOR_MALFUNCTION_DETECTION_SUPPORTED                     (1 << 6)
#define BLE_CGMC_PRV_CGM_FEATURES_SENSOR_TEMPERATURE_HIGH_LOW_DETECTION_SUPPORTED            (1 << 7)
#define BLE_CGMC_PRV_CGM_FEATURES_SENSOR_RESULT_HIGH_LOW_DETECTION_SUPPORTED                 (1 << 8)
#define BLE_CGMC_PRV_CGM_FEATURES_LOW_BATTERY_DETECTION_SUPPORTED                            (1 << 9)
#define BLE_CGMC_PRV_CGM_FEATURES_SENSOR_TYPE_ERROR_DETECTION_SUPPORTED                      (1 << 10)
#define BLE_CGMC_PRV_CGM_FEATURES_GENERAL_DEVICE_FAULT_SUPPORTED                             (1 << 11)
#define BLE_CGMC_PRV_CGM_FEATURES_E2E_CRC_SUPPORTED                                          (1 << 12)
#define BLE_CGMC_PRV_CGM_FEATURES_MULTIPLE_BOND_SUPPORTED                                    (1 << 13)
#define BLE_CGMC_PRV_CGM_FEATURES_MULTIPLE_SESSIONS_SUPPORTED                                (1 << 14)
#define BLE_CGMC_PRV_CGM_FEATURES_CGM_TREND_INFORMATION_SUPPORTED                            (1 << 15)
#define BLE_CGMC_PRV_CGM_FEATURES_CGM_QUALITY_SUPPORTED                                      (1 << 16)

/***************************************************************************//**
 CGM Specific Ops Control Point Calibration Value - Calibration Status value structure.
 *******************************************************************************/
#define BLE_CGMC_PRV_CGM_SPECIFIC_CP_CAL_VALUE_CAL_STATUS_CAL_DATA_REJECTED_OR_CAL_FAILED       (1 << 0)
#define BLE_CGMC_PRV_CGM_SPECIFIC_CP_CAL_VALUE_CAL_STATUS_CAL_DATA_OUT_OFF_RANGE                (1 << 1)
#define BLE_CGMC_PRV_CGM_SPECIFIC_CP_CAL_VALUE_CAL_STATUS_CAL_DATA_PROCESS_PENDING              (1 << 2)

 /***************************************************************************//**
 CGM Characteristics Lengths
 *******************************************************************************/
#define BLE_CGMC_PRV_CGM_RACP_LEN             (04)
#define BLE_CGMC_PRV_CGM_SPECIFIC_CP_LEN      (16)

/*----------------------------------------------------------------------------------------------------------------------
    CGM Measurement Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* CGM Measurement characteristic descriptors attribute handles */
static uint16_t gs_meas_cli_cnfg_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_meas_cli_cnfg =
{
    .uuid_16     = BLE_CGMC_MEAS_CLI_CNFG_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint16_t),
    .db_size     = BLE_CGMC_MEAS_CLI_CNFG_LEN,
    .desc_idx    = BLE_CGMC_MEAS_CLI_CNFG_IDX,
    .p_attr_hdls = gs_meas_cli_cnfg_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_CGMC_WriteMeasCliCnfg(uint16_t conn_hdl, const uint16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_meas_cli_cnfg, conn_hdl, p_value);
}

ble_status_t R_BLE_CGMC_ReadMeasCliCnfg(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_meas_cli_cnfg, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    CGM Measurement Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* CGM Measurement characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_meas_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************//**
* Function Name: decode_st_ble_cgmc_meas_t
* Description  : This function converts CGM Measurement characteristic value representation in
*                GATT (uint8_t[]) to representation in application layer (struct).
* Arguments    : p_app_value - pointer to the CGM Measurement value in the application layer
*                p_gatt_value - pointer to the characteristic value in the GATT database
* Return Value : ble_status_t
**********************************************************************************************************************/
static ble_status_t decode_st_ble_cgmc_meas_t(st_ble_cgmc_meas_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos;
    uint32_t total_pos = 0;
    uint8_t temp_flag = 0;
    uint8_t record_num = 0;

    while(p_gatt_value->value_len > total_pos)
    {
        pos = 0;
        p_app_value[record_num].size = p_gatt_value->p_value[total_pos++];
        pos++;

        temp_flag = p_gatt_value->p_value[total_pos++];
        pos++;
        if(temp_flag & BLE_CGMC_PRV_CGM_MEASUREMENT_FLAG_CGM_TREND_INFORMATION_PRESENT)
        {
            p_app_value[record_num].flags.is_cgm_trend_information_present = 1;
        }
        else
        {
            p_app_value[record_num].flags.is_cgm_trend_information_present = 0;
        }
        
        if(temp_flag & BLE_CGMC_PRV_CGM_MEASUREMENT_FLAG_CGM_QUALITY_PRESENT)
        {
            p_app_value[record_num].flags.is_cgm_quality_present = 1;
        }
        else
        {
            p_app_value[record_num].flags.is_cgm_quality_present = 0;
        }
            
        if(temp_flag & BLE_CGMC_PRV_CGM_MEASUREMENT_FLAG_CGM_SENSOR_STATUS_ANNUNCIATION_FIELD_WARNING_OCTECT_PRESENT)
        {
        
            p_app_value[record_num].flags.is_sensor_status_annunciation_field__warning_octet_present = 1;        
        }
        else
        {
            p_app_value[record_num].flags.is_sensor_status_annunciation_field__warning_octet_present = 0;
        }
        
        if(temp_flag & BLE_CGMC_PRV_CGM_MEASUREMENT_FLAG_CGM_SENSOR_STATUS_ANNUNCIATION_FIELD_CAL_TEMP_OCTECT_PRESENT)
        {
            p_app_value[record_num].flags.is_sensor_status_annunciation_field__cal_temp_octet_present = 1;        
        }
        else
        {
            p_app_value[record_num].flags.is_sensor_status_annunciation_field__cal_temp_octet_present = 0;
        }
        
        if(temp_flag & BLE_CGMC_PRV_CGM_MEASUREMENT_FLAG_CGM_SENSOR_STATUS_ANNUCIATION_FIELD_STATUS_OCTECT_PRESENT)
        {
            p_app_value[record_num].flags.is_sensor_status_annunciation_field__status_octet_present = 1;        
        }
        else
        {
            p_app_value[record_num].flags.is_sensor_status_annunciation_field__status_octet_present = 0;
        }

        p_app_value[record_num].cgm_glucose_concentration.exponent = (int8_t)(p_gatt_value->p_value[total_pos + 1] & 0x0f);
        p_app_value[record_num].cgm_glucose_concentration.mantissa = (int16_t)(((p_gatt_value->p_value[total_pos] & 0xff << 4)) | ((p_gatt_value->p_value[total_pos + 1] & 0xf0) >> 4));
        total_pos += 2;
        pos += 2;

        BT_UNPACK_LE_2_BYTE(&p_app_value[record_num].time_offset, &p_gatt_value->p_value[total_pos]);
        total_pos += 2;
        pos += 2;

        if(p_app_value[record_num].flags.is_sensor_status_annunciation_field__status_octet_present)
        {
            temp_flag = p_gatt_value->p_value[total_pos++];
            pos++;
            if(temp_flag & BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SESSION_STOPPED)
            {
                p_app_value[record_num].sensor_status_annunciation.is_session_stopped = 1;
            }
            else
            {
                p_app_value[record_num].sensor_status_annunciation.is_session_stopped = 0;
            }
            
            if(temp_flag & BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_DEVICE_BATTERY_LOW)
            {
                p_app_value[record_num].sensor_status_annunciation.is_device_battery_low = 1;
            }
            else
            {
                p_app_value[record_num].sensor_status_annunciation.is_device_battery_low = 0;
            }
            
            if(temp_flag & BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_TYPE_INCORRECT_FOR_DEVICE)
            {
                p_app_value[record_num].sensor_status_annunciation.is_sensor_type_incorrect_for_device = 1;
            }
            else
            {
                p_app_value[record_num].sensor_status_annunciation.is_sensor_type_incorrect_for_device = 0;
            }
            
            if(temp_flag & BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_MALFUNCTION)
            {
                p_app_value[record_num].sensor_status_annunciation.is_sensor_malfunction = 1;
            }
            else
            {
                p_app_value[record_num].sensor_status_annunciation.is_sensor_malfunction = 0;
            }
            
            if(temp_flag & BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_DEVICE_SPECIFIC_ALERT)
            {
                p_app_value[record_num].sensor_status_annunciation.is_device_specific_alert = 1;
            }
            else
            {
                p_app_value[record_num].sensor_status_annunciation.is_device_specific_alert = 0;
            }
            
            if(temp_flag & BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_GENERAL_DEVICE_FAULT_HAS_OCCURED_IN_THE_SENSOR)
            {
                p_app_value[record_num].sensor_status_annunciation.is_general_device_fault_has_occurred_in_the_sensor = 1;
            }
            else
            {
                p_app_value[record_num].sensor_status_annunciation.is_general_device_fault_has_occurred_in_the_sensor = 0;
            }
        }		
        
        if(p_app_value[record_num].flags.is_sensor_status_annunciation_field__cal_temp_octet_present)
        {
            temp_flag = p_gatt_value->p_value[total_pos++];
            pos++;
            if(temp_flag & BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_TIME_SYNCHRONIZATION_BETWEEN_SENSOR_AND_COLLECTOR_REQUIRED_2)
            {
                p_app_value[record_num].sensor_status_annunciation.is_time_synchronization_between_sensor_and_collector_required = 1;
            }
            else
            {
                p_app_value[record_num].sensor_status_annunciation.is_time_synchronization_between_sensor_and_collector_required = 0;
            }
            
            if(temp_flag & BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_CALIBRATION_NOT_ALLOWED_2)
            {
                p_app_value[record_num].sensor_status_annunciation.is_calibration_not_allowed = 1;
            }
            else
            {
                p_app_value[record_num].sensor_status_annunciation.is_calibration_not_allowed = 0;
            }
            
            if(temp_flag & BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_CALIBRATION_RECOMMENDED_2)
            {
                p_app_value[record_num].sensor_status_annunciation.is_calibration_recommended = 1;
            }
            else
            {
                p_app_value[record_num].sensor_status_annunciation.is_calibration_recommended = 0;
            }
            
            if(temp_flag & BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_CALIBRATION_REQUIRED_2)
            {
                p_app_value[record_num].sensor_status_annunciation.is_calibration_required = 1;
            }
            else
            {
                p_app_value[record_num].sensor_status_annunciation.is_calibration_required = 0;
            }
            
            if(temp_flag & BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_TEMP_TOO_HIGH_FOR_VALID_TEST_RESULT_AT_MEASUREMENT_2)
            {
                p_app_value[record_num].sensor_status_annunciation.is_sensor_temperature_too_high_for_valid_test_result_at_time_of_measurement = 1;
            }
            else
            {
                p_app_value[record_num].sensor_status_annunciation.is_sensor_temperature_too_high_for_valid_test_result_at_time_of_measurement = 0;
            }
            
            if(temp_flag & BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_TEMP_TOO_LOW_FOR_VALID_TEST_RESULT_AT_MEASUREMENT_2)
            {
                p_app_value[record_num].sensor_status_annunciation.is_sensor_temperature_too_low_for_valid_test_result_at_time_of_measurement = 1;
            }
            else
            {
                p_app_value[record_num].sensor_status_annunciation.is_sensor_temperature_too_low_for_valid_test_result_at_time_of_measurement = 0;
            }
        }
        
        if(p_app_value[record_num].flags.is_sensor_status_annunciation_field__warning_octet_present)
        {
            temp_flag = p_gatt_value->p_value[total_pos++];
            pos++;
            if(temp_flag & BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_LOWER_THAN_THE_PATIENT_LOW_LEVEL_2)
            {
                p_app_value[record_num].sensor_status_annunciation.is_sensor_result_lower_than_the_patient_low_level = 1;
            }
            else
            {
                p_app_value[record_num].sensor_status_annunciation.is_sensor_result_lower_than_the_patient_low_level = 0;
            }
            
            if(temp_flag & BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_HIGHER_THAN_THE_PATIENT_HIGH_LEVEL_2)
            {
                p_app_value[record_num].sensor_status_annunciation.is_sensor_result_higher_than_the_patient_high_level = 1;
            }
            else
            {
                p_app_value[record_num].sensor_status_annunciation.is_sensor_result_higher_than_the_patient_high_level = 0;
            }
            
            if(temp_flag & BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_LOWER_THAN_HYPO_LEVEL_2)
            {
                p_app_value[record_num].sensor_status_annunciation.is_sensor_result_lower_than_the_hypo_level = 1;
            }
            else
            {
                p_app_value[record_num].sensor_status_annunciation.is_sensor_result_lower_than_the_hypo_level = 0;
            }
            
            if(temp_flag & BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_HIGHER_THAN_HYPER_LEVEL_2)
            {
                p_app_value[record_num].sensor_status_annunciation.is_sensor_result_higher_than_the_hyper_level = 1;
            }
            else
            {
                p_app_value[record_num].sensor_status_annunciation.is_sensor_result_higher_than_the_hyper_level = 0;
            }
            
            if(temp_flag & BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RATE_OF_DECREASE_EXCEEDED_2)
            {
                p_app_value[record_num].sensor_status_annunciation.is_sensor_rate_of_decrease_exceeded = 1;
            }
            else
            {
                p_app_value[record_num].sensor_status_annunciation.is_sensor_rate_of_decrease_exceeded = 0;
            }
            
            if(temp_flag & BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RATE_OF_INCREASE_EXCEEDED_2)
            {
                p_app_value[record_num].sensor_status_annunciation.is_sensor_rate_of_increase_exceeded = 1;
            }
            else
            {
                p_app_value[record_num].sensor_status_annunciation.is_sensor_rate_of_increase_exceeded = 0;
            }
            
            if(temp_flag & BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_LOWER_THAN_DEVICE_CAN_PROCESS_2)
            {
                p_app_value[record_num].sensor_status_annunciation.is_sensor_result_lower_than_the_device_can_process = 1;
            }
            else
            {
                p_app_value[record_num].sensor_status_annunciation.is_sensor_result_lower_than_the_device_can_process = 0;
            }
            
            if(temp_flag & BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_HIGHER_THAN_DEVICE_CAN_PROCESS_2)
            {
                p_app_value[record_num].sensor_status_annunciation.is_sensor_result_higher_than_the_device_can_process = 1;
            }
            else
            {
                p_app_value[record_num].sensor_status_annunciation.is_sensor_result_higher_than_the_device_can_process = 0;
            }
        }

        if (p_app_value[record_num].flags.is_cgm_trend_information_present)
        {
            p_app_value[record_num].cgm_trend_information.exponent = (int8_t)(p_gatt_value->p_value[total_pos + 1] & 0x0f);
            p_app_value[record_num].cgm_trend_information.mantissa = (int16_t)((((p_gatt_value->p_value[total_pos] & 0xff) << 4) | ((p_gatt_value->p_value[total_pos + 1] & 0xf0) >> 4)));
            total_pos += 2;
            pos += 2;			
        }
        
        if(p_app_value[record_num].flags.is_cgm_quality_present)
        {
            p_app_value[record_num].cgm_quality.exponent = (int8_t)(p_gatt_value->p_value[total_pos + 1] & 0x0f);
            p_app_value[record_num].cgm_quality.mantissa = (int16_t)((((p_gatt_value->p_value[total_pos] & 0xff) << 4) | ((p_gatt_value->p_value[total_pos + 1] & 0xf0) >> 4)));
            total_pos += 2;
            pos += 2;		
        }
        
        if(pos < p_app_value[record_num].size)
        {
            BT_UNPACK_LE_2_BYTE(&p_app_value[record_num].e2e_crc, &p_gatt_value->p_value[total_pos]);
            total_pos += 2;
            pos += 2;
        }       
      
        if(pos != p_app_value[record_num].size)
        {
            return BLE_ERR_INVALID_DATA ;
        }
        
        record_num++;
    }

    return BLE_SUCCESS;
}

/***********************************************************************************************************************//**
* Function Name: encode_st_ble_cgmc_meas_t
* Description  : This function converts CGM Measurement characteristic value representation in
*                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
* Arguments    : p_app_value - pointer to the CGM Measurement  value in the application layer
*                p_gatt_value - pointer to the characteristic value in the GATT database
* Return Value : ble_status_t
**********************************************************************************************************************/
static ble_status_t encode_st_ble_cgmc_meas_t(const st_ble_cgmc_meas_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 1;
    uint32_t flag_1 = 0;

    /* Clear the bytes array */
    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);
    
    /*Copy the Size Value*/
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->size);

    /*Copy the cgm_glucose_concentration Value*/
    /*variable to copy the exponent and mantissa values of cgm_glucose_concentration VALUE*/
    uint16_t value_to_copy_cgm_glucose_concentration = 0;

    value_to_copy_cgm_glucose_concentration = (uint16_t)((((((int16_t)(p_app_value->cgm_glucose_concentration.exponent)) << 12) & 0xF000)
        | (p_app_value->cgm_glucose_concentration.mantissa & 0x0FFF)));

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], (uint8_t*)&value_to_copy_cgm_glucose_concentration);
    pos += 2;

    /*Copy the time_offset Value*/
    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->time_offset);
    pos += 2;

    p_gatt_value->p_value[0] |= BLE_CGMC_PRV_CGM_MEASUREMENT_FLAG_CGM_SENSOR_STATUS_ANNUNCIATION_FIELD_WARNING_OCTECT_PRESENT;
    p_gatt_value->p_value[0] |= BLE_CGMC_PRV_CGM_MEASUREMENT_FLAG_CGM_SENSOR_STATUS_ANNUNCIATION_FIELD_CAL_TEMP_OCTECT_PRESENT;
    p_gatt_value->p_value[0] |= BLE_CGMC_PRV_CGM_MEASUREMENT_FLAG_CGM_SENSOR_STATUS_ANNUCIATION_FIELD_STATUS_OCTECT_PRESENT;
    
    if (p_app_value->sensor_status_annunciation.is_session_stopped)
    {
        flag_1 |= BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SESSION_STOPPED;
    }

    if (p_app_value->sensor_status_annunciation.is_device_battery_low)
    {
        flag_1 |= BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_DEVICE_BATTERY_LOW;
    }

    if (p_app_value->sensor_status_annunciation.is_sensor_type_incorrect_for_device)
    {
        flag_1 |= BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_TYPE_INCORRECT_FOR_DEVICE;
    }

    if (p_app_value->sensor_status_annunciation.is_sensor_malfunction)
    {
        flag_1 |= BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_MALFUNCTION;
    }

    if (p_app_value->sensor_status_annunciation.is_device_specific_alert)
    {
        flag_1 |= BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_DEVICE_SPECIFIC_ALERT;
    }

    if (p_app_value->sensor_status_annunciation.is_general_device_fault_has_occurred_in_the_sensor)
    {
        flag_1 |= BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_GENERAL_DEVICE_FAULT_HAS_OCCURED_IN_THE_SENSOR;
    }

    if (p_app_value->sensor_status_annunciation.is_time_synchronization_between_sensor_and_collector_required)
    {
        flag_1 |= BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_TIME_SYNCHRONIZATION_BETWEEN_SENSOR_AND_COLLECTOR_REQUIRED;
    }

    if (p_app_value->sensor_status_annunciation.is_calibration_not_allowed)
    {
        flag_1 |= BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_CALIBRATION_NOT_ALLOWED;
    }

    if (p_app_value->sensor_status_annunciation.is_calibration_recommended)
    {
        flag_1 |= BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_CALIBRATION_RECOMMENDED;
    }

    if (p_app_value->sensor_status_annunciation.is_calibration_required)
    {
        flag_1 |= BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_CALIBRATION_REQUIRED;
    }

    if (p_app_value->sensor_status_annunciation.is_sensor_temperature_too_high_for_valid_test_result_at_time_of_measurement)
    {
        flag_1 |= BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_TEMP_TOO_HIGH_FOR_VALID_TEST_RESULT_AT_MEASUREMENT;
    }

    if (p_app_value->sensor_status_annunciation.is_sensor_temperature_too_low_for_valid_test_result_at_time_of_measurement)
    {
        flag_1 |= BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_TEMP_TOO_LOW_FOR_VALID_TEST_RESULT_AT_MEASUREMENT;
    }

    if (p_app_value->sensor_status_annunciation.is_sensor_result_lower_than_the_patient_low_level)
    {
        flag_1 |= BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_LOWER_THAN_THE_PATIENT_LOW_LEVEL;
    }

    if (p_app_value->sensor_status_annunciation.is_sensor_result_higher_than_the_patient_high_level)
    {
        flag_1 |= BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_HIGHER_THAN_THE_PATIENT_HIGH_LEVEL;
    }

    if (p_app_value->sensor_status_annunciation.is_sensor_result_lower_than_the_hypo_level)
    {
        flag_1 |= BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_LOWER_THAN_HYPO_LEVEL;
    }

    if (p_app_value->sensor_status_annunciation.is_sensor_result_higher_than_the_hyper_level)
    {
        flag_1 |= BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_HIGHER_THAN_HYPER_LEVEL;
    }

    if (p_app_value->sensor_status_annunciation.is_sensor_rate_of_decrease_exceeded)
    {
        flag_1 |= BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RATE_OF_DECREASE_EXCEEDED;
    }
    if (p_app_value->sensor_status_annunciation.is_sensor_rate_of_increase_exceeded)
    {
        flag_1 |= BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RATE_OF_INCREASE_EXCEEDED;
    }

    if (p_app_value->sensor_status_annunciation.is_sensor_result_lower_than_the_device_can_process)
    {
        flag_1 |= BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_LOWER_THAN_DEVICE_CAN_PROCESS;
    }

    if (p_app_value->sensor_status_annunciation.is_sensor_result_higher_than_the_device_can_process)
    {
        flag_1 |= BLE_CGMC_PRV_CGM_MEASUREMENT_SENSOR_STATUS_ANNUCIATION_SENSOR_RESULT_HIGHER_THAN_DEVICE_CAN_PROCESS;
    }

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &flag_1);
    pos += 2;    
   
    /*Copy the cgm_trend_information Value*/
    /*variable to copy the exponent and mantisa values of cgm_trend_information VALUE*/	 
    if (p_app_value->flags.is_cgm_trend_information_present )
    {
        p_gatt_value->p_value[0] |= BLE_CGMC_PRV_CGM_MEASUREMENT_FLAG_CGM_TREND_INFORMATION_PRESENT;
        uint16_t value_to_copy_cgm_trend_information = 0;

        value_to_copy_cgm_trend_information = (uint16_t)((((((int16_t)(p_app_value->cgm_trend_information.exponent)) << 12) & 0xF000)
            | (p_app_value->cgm_trend_information.mantissa & 0x0FFF)));

        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], (uint8_t*)&value_to_copy_cgm_trend_information);
        pos += 2;
    }

    /*Copy the cgm_quality Value*/
    /*variable to copy the exponent and mantisa values of cgm_quality VALUE*/
    if (p_app_value->flags.is_cgm_quality_present )
    {
        p_gatt_value->p_value[0] |= BLE_CGMC_PRV_CGM_MEASUREMENT_FLAG_CGM_QUALITY_PRESENT;
        uint16_t value_to_copy_cgm_quality = 0;

        value_to_copy_cgm_quality = (uint16_t)((((((int16_t)(p_app_value->cgm_quality.exponent)) << 12) & 0xF000)
            | (p_app_value->cgm_quality.mantissa & 0x0FFF)));

        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], (uint8_t*)&value_to_copy_cgm_quality);
        pos += 2;
    }

    /*Copy the e2e_crc Value*/
    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->e2e_crc);
    pos += 2;

    p_gatt_value->value_len = (uint16_t)pos;

    return BLE_SUCCESS;
}

/* CGM Measurement characteristic descriptor definition */
static const st_ble_servc_desc_info_t *gspp_meas_descs[] = 
{
    &gs_meas_cli_cnfg,
};

/* CGM Measurement characteristic definition */
static const st_ble_servc_char_info_t gs_meas_char = 
{
    .uuid_16      = BLE_CGMC_MEAS_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_cgmc_meas_t) * 3,
    .db_size      = BLE_CGMC_MEAS_LEN,
    .char_idx     = BLE_CGMC_MEAS_IDX,
    .p_attr_hdls  = gs_meas_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_cgmc_meas_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_cgmc_meas_t,
    .num_of_descs = ARRAY_SIZE(gspp_meas_descs),
    .pp_descs     = gspp_meas_descs,
};

void R_BLE_CGMC_GetMeasAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_cgmc_meas_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_meas_char_ranges[conn_idx];
    p_hdl->cli_cnfg_desc_hdl = gs_meas_cli_cnfg_desc_hdls[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    CGM Feature Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* CGM Feature characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_feat_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************//**
* Function Name: decode_st_ble_cgmc_feat_t
* Description  : This function converts CGM Feature value representation in
*                GATT (uint8_t[]) to representation in application layer (struct).
* Arguments    : p_app_value - pointer to the CGM Feature value in the application layer
*                p_gatt_value - pointer to the characteristic value in the GATT database
* Return Value : ble_status_t
**********************************************************************************************************************/
static ble_status_t decode_st_ble_cgmc_feat_t(st_ble_cgmc_feat_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;

    if (BLE_CGMC_FEAT_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    memset((uint8_t*)p_app_value, 0x00, sizeof(*p_app_value));
    
    uint32_t feature_byte0 = 0;
    BT_UNPACK_LE_3_BYTE(&feature_byte0, &p_gatt_value->p_value[0]);
    pos += 3;

    /* CGMS SUPPORTED FEATURES SUPPORTED BITS */
    /* is_calibration_supported bit */
    if (feature_byte0 & BLE_CGMC_PRV_CGM_FEATURES_CALIBRATION_SUPPORTED )
    {
        p_app_value->cgm_feature.is_calibration_supported = true;
    }
    else
    {
        p_app_value->cgm_feature.is_calibration_supported = false;
    }

    /* is_patient_high_low_alerts_supported bit */
    if (feature_byte0 & BLE_CGMC_PRV_CGM_FEATURES_PATIENT_HIGH_LOW_ALERTS_SUPPORTED)
    {
        p_app_value->cgm_feature.is_patient_high_low_alerts_supported = true;
    }
    else
    {
        p_app_value->cgm_feature.is_patient_high_low_alerts_supported = false;
    }

    /* is_hypo_alerts_supported bit */
    if (feature_byte0 & BLE_CGMC_PRV_CGM_FEATURES_HYPO_ALERTS_SUPPORTED)
    {
        p_app_value->cgm_feature.is_hypo_alerts_supported = true;
    }
    else
    {
        p_app_value->cgm_feature.is_hypo_alerts_supported = false;
    }

    /* is_hyper_alerts_supported bit */
    if (feature_byte0 & BLE_CGMC_PRV_CGM_FEATURES_HYPER_ALERTS_SUPPORTED)
    {
        p_app_value->cgm_feature.is_hyper_alerts_supported = true;
    }
    else
    {
        p_app_value->cgm_feature.is_hyper_alerts_supported = false;
    }

    /* is_rate_of_increase_decrease_alerts_supported bit */
    if (feature_byte0 & BLE_CGMC_PRV_CGM_FEATURES_RATE_OF_INCREASE_DECREASE_ALERTS_SUPPORTED)
    {
        p_app_value->cgm_feature.is_rate_of_increase_decrease_alerts_supported = true;
    }
    else
    {
        p_app_value->cgm_feature.is_rate_of_increase_decrease_alerts_supported = false;
    }

    /* is_device_specific_alert_supported bit */
    if (feature_byte0 & BLE_CGMC_PRV_CGM_FEATURES_DEVICE_SPECIFIC_ALERTS_SUPPORTED)
    {
        p_app_value->cgm_feature.is_device_specific_alert_supported = true;
    }
    else
    {
        p_app_value->cgm_feature.is_device_specific_alert_supported = false;
    }

    /* is_sensor_malfunction_detection_supported bit */
    if (feature_byte0 & BLE_CGMC_PRV_CGM_FEATURES_SENSOR_MALFUNCTION_DETECTION_SUPPORTED)
    {
        p_app_value->cgm_feature.is_sensor_malfunction_detection_supported = true;
    }
    else
    {
        p_app_value->cgm_feature.is_sensor_malfunction_detection_supported = false;
    }

    /* is_sensor_temperature_high_low_detection_supported bit */
    if (feature_byte0 & BLE_CGMC_PRV_CGM_FEATURES_SENSOR_TEMPERATURE_HIGH_LOW_DETECTION_SUPPORTED)
    {
        p_app_value->cgm_feature.is_sensor_temperature_high_low_detection_supported = true;
    }
    else
    {
        p_app_value->cgm_feature.is_sensor_temperature_high_low_detection_supported = false;
    }

    /* is_sensor_result_high_low_detection_supported bit */
    if (feature_byte0 & BLE_CGMC_PRV_CGM_FEATURES_SENSOR_RESULT_HIGH_LOW_DETECTION_SUPPORTED)
    {
        p_app_value->cgm_feature.is_sensor_result_high_low_detection_supported = true;
    }
    else
    {
        p_app_value->cgm_feature.is_sensor_result_high_low_detection_supported = false;
    }

    /* is_low_battery_detection_supported bit */
    if (feature_byte0 & BLE_CGMC_PRV_CGM_FEATURES_LOW_BATTERY_DETECTION_SUPPORTED)
    {
        p_app_value->cgm_feature.is_low_battery_detection_supported = true;
    }
    else
    {
        p_app_value->cgm_feature.is_low_battery_detection_supported = false;
    }

    /* is_sensor_type_error_detection_supported bit */
    if (feature_byte0 & BLE_CGMC_PRV_CGM_FEATURES_SENSOR_TYPE_ERROR_DETECTION_SUPPORTED)
    {
        p_app_value->cgm_feature.is_sensor_type_error_detection_supported = true;
    }
    else
    {
        p_app_value->cgm_feature.is_sensor_type_error_detection_supported = false;
    }

    /* is_general_device_fault_supported bit */
    if (feature_byte0 & BLE_CGMC_PRV_CGM_FEATURES_GENERAL_DEVICE_FAULT_SUPPORTED)
    {
        p_app_value->cgm_feature.is_general_device_fault_supported = true;
    }
    else
    {
        p_app_value->cgm_feature.is_general_device_fault_supported = false;
    }

    /* is_e2e_crc_supported bit */
    if (feature_byte0 & BLE_CGMC_PRV_CGM_FEATURES_E2E_CRC_SUPPORTED)
    {
        p_app_value->cgm_feature.is_e2e_crc_supported = true;
    }
    else
    {
        p_app_value->cgm_feature.is_e2e_crc_supported = false;
    }

    /* is_multiple_bond_supported bit */
    if (feature_byte0 & BLE_CGMC_PRV_CGM_FEATURES_MULTIPLE_BOND_SUPPORTED)
    {
        p_app_value->cgm_feature.is_multiple_bond_supported = true;
    }
    else
    {
        p_app_value->cgm_feature.is_multiple_bond_supported = false;
    }

    /* is_multiple_sessions_supported bit */
    if (feature_byte0 & BLE_CGMC_PRV_CGM_FEATURES_MULTIPLE_SESSIONS_SUPPORTED)
    {
        p_app_value->cgm_feature.is_multiple_sessions_supported = true;
    }
    else
    {
        p_app_value->cgm_feature.is_multiple_sessions_supported = false;
    }

    /* is_cgm_trend_information_supported bit */
    if (feature_byte0 & BLE_CGMC_PRV_CGM_FEATURES_CGM_TREND_INFORMATION_SUPPORTED)
    {
        p_app_value->cgm_feature.is_cgm_trend_information_supported = true;
    }
    else
    {
        p_app_value->cgm_feature.is_cgm_trend_information_supported = false;
    }

    /* is_cgm_quality_supported bit */
    if (feature_byte0 & BLE_CGMC_PRV_CGM_FEATURES_CGM_QUALITY_SUPPORTED)
    {
        p_app_value->cgm_feature.is_cgm_quality_supported = true;
    }
    else
    {
        p_app_value->cgm_feature.is_cgm_quality_supported = false;
    }

    /* cgm_type value */
    BT_UNPACK_LE_1_BYTE(&p_app_value->cgm_type, &p_gatt_value->p_value[pos]);

    p_app_value->cgm_sample_location = ((p_app_value->cgm_type & 0xF0) >> 4);
    p_app_value->cgm_type = (p_app_value->cgm_type & 0x0F);
    
    pos += 1;

    BT_UNPACK_LE_2_BYTE(&p_app_value->e2e_crc, &p_gatt_value->p_value[pos]);
    pos += 2;

    return BLE_SUCCESS;
}

/***********************************************************************************************************************//**
 * Function Name: encode_st_ble_cgmc_feat_t
 * Description  : This function converts CGM Features characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the CGM Features  value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_cgmc_feat_t(const st_ble_cgmc_feat_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;
    uint32_t flag_1 = 0;

    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    /* Copy the supported_features Value of CGM Features  */
    if (p_app_value->cgm_feature.is_calibration_supported)
    {
        flag_1 |= BLE_CGMC_PRV_CGM_FEATURES_CALIBRATION_SUPPORTED;
    }

    if (p_app_value->cgm_feature.is_patient_high_low_alerts_supported)
    {
        flag_1 |= BLE_CGMC_PRV_CGM_FEATURES_PATIENT_HIGH_LOW_ALERTS_SUPPORTED;
    }

    if (p_app_value->cgm_feature.is_hypo_alerts_supported)
    {
        flag_1 |= BLE_CGMC_PRV_CGM_FEATURES_HYPO_ALERTS_SUPPORTED;
    }

    if (p_app_value->cgm_feature.is_hyper_alerts_supported)
    {
        flag_1 |= BLE_CGMC_PRV_CGM_FEATURES_HYPER_ALERTS_SUPPORTED;
    }

    if (p_app_value->cgm_feature.is_rate_of_increase_decrease_alerts_supported)
    {
        flag_1 |= BLE_CGMC_PRV_CGM_FEATURES_RATE_OF_INCREASE_DECREASE_ALERTS_SUPPORTED;
    }

    if (p_app_value->cgm_feature.is_device_specific_alert_supported)
    {
        flag_1 |= BLE_CGMC_PRV_CGM_FEATURES_DEVICE_SPECIFIC_ALERTS_SUPPORTED;
    }

    if (p_app_value->cgm_feature.is_sensor_malfunction_detection_supported)
    {
        flag_1 |= BLE_CGMC_PRV_CGM_FEATURES_SENSOR_MALFUNCTION_DETECTION_SUPPORTED;
    }

    if (p_app_value->cgm_feature.is_sensor_temperature_high_low_detection_supported)
    {
        flag_1 |= BLE_CGMC_PRV_CGM_FEATURES_SENSOR_TEMPERATURE_HIGH_LOW_DETECTION_SUPPORTED;
    }

    if (p_app_value->cgm_feature.is_sensor_result_high_low_detection_supported)
    {
        flag_1 |= BLE_CGMC_PRV_CGM_FEATURES_SENSOR_RESULT_HIGH_LOW_DETECTION_SUPPORTED;
    }

    if (p_app_value->cgm_feature.is_low_battery_detection_supported)
    {
        flag_1 |= BLE_CGMC_PRV_CGM_FEATURES_LOW_BATTERY_DETECTION_SUPPORTED;
    }

    if (p_app_value->cgm_feature.is_sensor_type_error_detection_supported)
    {
        flag_1 |= BLE_CGMC_PRV_CGM_FEATURES_SENSOR_TYPE_ERROR_DETECTION_SUPPORTED;
    }

    if (p_app_value->cgm_feature.is_general_device_fault_supported)
    {
        flag_1 |= BLE_CGMC_PRV_CGM_FEATURES_GENERAL_DEVICE_FAULT_SUPPORTED;
    }

    if (p_app_value->cgm_feature.is_e2e_crc_supported)
    {
        flag_1 |= BLE_CGMC_PRV_CGM_FEATURES_E2E_CRC_SUPPORTED;
    }

    if (p_app_value->cgm_feature.is_multiple_bond_supported)
    {
        flag_1 |= BLE_CGMC_PRV_CGM_FEATURES_MULTIPLE_BOND_SUPPORTED;
    }

    if (p_app_value->cgm_feature.is_multiple_sessions_supported)
    {
        flag_1 |= BLE_CGMC_PRV_CGM_FEATURES_MULTIPLE_SESSIONS_SUPPORTED;
    }

    if (p_app_value->cgm_feature.is_cgm_trend_information_supported)
    {
        flag_1 |= BLE_CGMC_PRV_CGM_FEATURES_CGM_TREND_INFORMATION_SUPPORTED;
    }

    if (p_app_value->cgm_feature.is_cgm_quality_supported)
    {
        flag_1 |= BLE_CGMC_PRV_CGM_FEATURES_CGM_QUALITY_SUPPORTED;
    }

    BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], &flag_1);
    pos += 3;

    /* copy the value of cgm_type*/
    uint8_t value_to_copy_cgm_type = 0;

    value_to_copy_cgm_type = (uint8_t)((((((uint8_t)(p_app_value->cgm_type))) & 0xF0)
        | (p_app_value->cgm_sample_location & 0x0F)));

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &value_to_copy_cgm_type);
    
    /* copy the value of e2e_crc*/
    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->e2e_crc);
    pos += 2;

    p_gatt_value->value_len = (uint16_t)pos;

    return BLE_SUCCESS;
}

/* CGM Feature characteristic definition */
static const st_ble_servc_char_info_t gs_feat_char =
{
    .uuid_16      = BLE_CGMC_FEAT_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_cgmc_feat_t),
    .db_size      = BLE_CGMC_FEAT_LEN,
    .char_idx     = BLE_CGMC_FEAT_IDX,
    .p_attr_hdls  = gs_feat_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_cgmc_feat_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_cgmc_feat_t,
};

ble_status_t R_BLE_CGMC_ReadFeat(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_feat_char, conn_hdl);
}

void R_BLE_CGMC_GetFeatAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_cgmc_feat_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_feat_char_ranges[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    CGM Status Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* CGM Status characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_status_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************//**
* Function Name: decode_st_ble_cgmc_status_t
* Description  : This function converts CGM Status characteristic value representation in
*                GATT (uint8_t[]) to representation in application layer (struct).
* Arguments    : p_app_value - pointer to the CGM Status value in the application layer
*                p_gatt_value - pointer to the characteristic value in the GATT database
* Return Value : ble_status_t
**********************************************************************************************************************/
static ble_status_t decode_st_ble_cgmc_status_t(st_ble_cgmc_status_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;

    if (BLE_CGMC_STATUS_LEN < p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    memset((uint8_t*)p_app_value, 0x00, sizeof(st_ble_cgmc_status_t));

    /*Copy the CGM_STATUS time_offset value*/
    BT_UNPACK_LE_2_BYTE(&p_app_value->time_offset, &p_gatt_value->p_value[pos]);
    pos += 2;

    /*Copy the CGM_STATUS cgm_status value - 24 bits */
    BT_UNPACK_LE_3_BYTE(&p_app_value->cgm_status, &p_gatt_value->p_value[pos]);
    pos += 3;

    /*Copy the CGM_STATUS e2e_crc value*/
    BT_UNPACK_LE_2_BYTE(&p_app_value->e2e_crc, &p_gatt_value->p_value[pos]);
    pos += 2;

    return BLE_SUCCESS;
}

/***********************************************************************************************************************//**
 * Function Name: encode_st_ble_cgmc_status_t
 * Description  : This function converts CGM Status characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the CGM Status value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_cgmc_status_t(const st_ble_cgmc_status_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    /* copy the value of time_offset*/
    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->time_offset);
    pos += 2;

    /* copy the value of cgm_status*/
    BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], &p_app_value->cgm_status);
    pos += 3;

    /* copy the value of time_offset*/
    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->e2e_crc);
    pos += 2;

    p_gatt_value->value_len = (uint16_t)pos;

    return BLE_SUCCESS;
}

/* CGM Status characteristic definition */
const st_ble_servc_char_info_t gs_status_char = 
{
    .uuid_16      = BLE_CGMC_STATUS_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_cgmc_status_t),
    .db_size      = BLE_CGMC_STATUS_LEN,
    .char_idx     = BLE_CGMC_STATUS_IDX,
    .p_attr_hdls  = gs_status_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_cgmc_status_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_cgmc_status_t,
};

ble_status_t R_BLE_CGMC_ReadStatus(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_status_char, conn_hdl);
}

void R_BLE_CGMC_GetStatusAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_cgmc_status_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_status_char_ranges[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    CGM Session Start Time Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* CGM Session Start Time characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_session_start_time_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************//**
* Function Name: decode_st_ble_cgmc_session_start_time_t
* Description  : This function converts CGM Session Start Time characteristic value representation in
*                GATT (uint8_t[]) to representation in application layer (struct).
* Arguments    : p_app_value - pointer to the CGM Session Start Time value in the application layer
*                p_gatt_value - pointer to the characteristic value in the GATT database
* Return Value : ble_status_t
**********************************************************************************************************************/
static ble_status_t decode_st_ble_cgmc_session_start_time_t(st_ble_cgmc_session_start_time_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;

    if ((BLE_CGMC_SESSION_START_TIME_LEN < p_gatt_value->value_len))
    {
            return BLE_ERR_INVALID_DATA;
    }

    memset((uint8_t*)p_app_value, 0x00, sizeof(st_ble_cgmc_session_start_time_t));

    /*Copy the CGM_SESSION_START_TIME_Value*/
    BT_UNPACK_LE_2_BYTE(&p_app_value->session_start_time.year, &p_gatt_value->p_value[pos]);
    pos += (sizeof(p_app_value->session_start_time.year));

    p_app_value->session_start_time.month = p_gatt_value->p_value[pos++];
    p_app_value->session_start_time.day = p_gatt_value->p_value[pos++];
    p_app_value->session_start_time.hours = p_gatt_value->p_value[pos++];
    p_app_value->session_start_time.minutes = p_gatt_value->p_value[pos++];
    p_app_value->session_start_time.seconds = p_gatt_value->p_value[pos++];

    /*Copy the CGM_SESSION_START time_zone value*/
    BT_UNPACK_LE_1_BYTE(&p_app_value->time_zone, &p_gatt_value->p_value[pos++]);

    /*Copy the CGM_SESSION_START dst_offset value*/
    BT_UNPACK_LE_1_BYTE(&p_app_value->dst_offset, &p_gatt_value->p_value[pos++]);

    if(BLE_CGMC_SESSION_START_TIME_LEN == p_gatt_value->value_len)
    {
        /*Copy the CGM_SESSION_START e2e_crc value*/
        BT_UNPACK_LE_2_BYTE(&p_app_value->e2e_crc, &p_gatt_value->p_value[pos]);
        pos += 2;
    }
    
    return BLE_SUCCESS;
}

/***********************************************************************************************************************//**
 * Function Name: encode_st_ble_cgmc_session_start_time_t
 * Description  : This function converts CGM Session Start Time characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the CGM Session Start Time value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_cgmc_session_start_time_t(const st_ble_cgmc_session_start_time_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    /* copy the value of session_start_time value*/
    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->session_start_time.year);
    pos += (sizeof(p_app_value->session_start_time.year));

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->session_start_time.month);
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->session_start_time.day);
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->session_start_time.hours);
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->session_start_time.minutes);
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->session_start_time.seconds);

    /* copy the value of time_zone value*/
    p_gatt_value->p_value[pos++] = (uint8_t)p_app_value->time_zone;

    /* copy the value of dst_offset value*/
    p_gatt_value->p_value[pos++] = p_app_value->dst_offset;

    if ((BLE_CGMC_SESSION_START_TIME_LEN == p_gatt_value->value_len))
    {
        /* copy the value of e2e_crc value*/
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->e2e_crc);
        pos += 2;
    }
    p_gatt_value->value_len = (uint16_t)pos;

    return BLE_SUCCESS;
}

/* CGM Session Start Time characteristic definition */
const st_ble_servc_char_info_t gs_session_start_time_char = 
{
    .uuid_16      = BLE_CGMC_SESSION_START_TIME_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_cgmc_session_start_time_t),
    .db_size      = BLE_CGMC_SESSION_START_TIME_LEN,
    .char_idx     = BLE_CGMC_SESSION_START_TIME_IDX,
    .p_attr_hdls  = gs_session_start_time_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_cgmc_session_start_time_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_cgmc_session_start_time_t,
};

ble_status_t R_BLE_CGMC_WriteSessionStartTime(uint16_t conn_hdl, const st_ble_cgmc_session_start_time_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteChar(&gs_session_start_time_char, conn_hdl, p_value);
}

ble_status_t R_BLE_CGMC_ReadSessionStartTime(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_session_start_time_char, conn_hdl);
}

void R_BLE_CGMC_GetSessionStartTimeAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_cgmc_session_start_time_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_session_start_time_char_ranges[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    CGM Session Run Time Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* CGM Session Run Time characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_session_run_time_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************//**
* Function Name: decode_st_ble_cgmc_session_run_time_t
* Description  : This function converts CGM Session Run Time characteristic value representation in
*                GATT (uint8_t[]) to representation in application layer (struct).
* Arguments    : p_app_value - pointer to the CGM Session Run Time value in the application layer
*                p_gatt_value - pointer to the characteristic value in the GATT database
* Return Value : ble_status_t
**********************************************************************************************************************/
static ble_status_t decode_st_ble_cgmc_session_run_time_t(st_ble_cgmc_session_run_time_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;

    if (BLE_CGMC_SESSION_RUN_TIME_LEN < p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    memset((uint8_t*)p_app_value, 0x00, sizeof(*p_app_value));

    /*Copy the CGM_SESSION_RUN cgm_session_run_time value*/
    BT_UNPACK_LE_2_BYTE(&p_app_value->cgm_session_run_time, &p_gatt_value->p_value[pos]);
    pos += 2;

    /*Copy the CGM_SESSION_RUN e2e_crc value*/
    BT_UNPACK_LE_2_BYTE(&p_app_value->e2e_crc, &p_gatt_value->p_value[pos]);
    pos += 2;

    return BLE_SUCCESS;
}

/***********************************************************************************************************************//**
 * Function Name: encode_st_ble_cgmc_session_run_time_t
 * Description  : This function converts CGM Session Run Time  characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the CGM Session Run Time value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_cgmc_session_run_time_t(const st_ble_cgmc_session_run_time_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    /* copy the value of cgm_session_run_time value*/
    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->cgm_session_run_time);
    pos += 2;

    /* copy the value of e2e_crc value*/
    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->e2e_crc);
    pos += 2;

    p_gatt_value->value_len = (uint16_t)pos;

    return BLE_SUCCESS;
}

/* CGM Session Run Time characteristic definition */
const st_ble_servc_char_info_t gs_session_run_time_char = 
{
    .uuid_16      = BLE_CGMC_SESSION_RUN_TIME_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_cgmc_session_run_time_t),
    .db_size      = BLE_CGMC_SESSION_RUN_TIME_LEN,
    .char_idx     = BLE_CGMC_SESSION_RUN_TIME_IDX,
    .p_attr_hdls  = gs_session_run_time_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_cgmc_session_run_time_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_cgmc_session_run_time_t,
};

ble_status_t R_BLE_CGMC_ReadSessionRunTime(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_session_run_time_char, conn_hdl);
}

void R_BLE_CGMC_GetSessionRunTimeAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_cgmc_session_run_time_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_session_run_time_char_ranges[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Record Access Control Point Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Record Access Control Point characteristic descriptors attribute handles */
static uint16_t gs_record_access_cp_cli_cnfg_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_record_access_cp_cli_cnfg =
{
    .uuid_16     = BLE_CGMC_RECORD_ACCESS_CP_CLI_CNFG_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint16_t),
    .db_size     = BLE_CGMC_RECORD_ACCESS_CP_CLI_CNFG_LEN,
    .desc_idx    = BLE_CGMC_RECORD_ACCESS_CP_CLI_CNFG_IDX,
    .p_attr_hdls = gs_record_access_cp_cli_cnfg_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_CGMC_WriteRecordAccessCpCliCnfg(uint16_t conn_hdl, const uint16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_record_access_cp_cli_cnfg, conn_hdl, p_value);
}

ble_status_t R_BLE_CGMC_ReadRecordAccessCpCliCnfg(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_record_access_cp_cli_cnfg, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Record Access Control Point Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Record Access Control Point characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_record_access_cp_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************//**
* Function Name: decode_st_ble_cgmc_record_access_cp_t
* Description  : This function converts CGM Record Access Control Point characteristic value representation in
*                GATT (uint8_t[]) to representation in application layer (struct).
* Arguments    : p_app_value - pointer to the CGM Record Access Control Point value in the application layer
*                p_gatt_value - pointer to the characteristic value in the GATT database
* Return Value : ble_status_t
**********************************************************************************************************************/
static ble_status_t decode_st_ble_cgmc_record_access_cp_t(st_ble_cgmc_record_access_cp_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{ 
    uint32_t pos = 0;
    if (BLE_CGMC_PRV_CGM_RACP_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    memset((uint8_t*)p_app_value, 0x00, sizeof(st_ble_cgmc_record_access_cp_t));

    p_app_value->op_code = p_gatt_value->p_value[pos++];
    p_app_value->racp_operator = p_gatt_value->p_value[pos++];
    memcpy(p_app_value->operand, &p_gatt_value->p_value[pos], (size_t)(p_gatt_value->value_len - pos));
    p_app_value->operand_len = (uint8_t)(p_gatt_value->value_len - pos);
    
    return BLE_SUCCESS;
}

/***********************************************************************************************************************//**
* Function Name: encode_st_ble_cgmc_record_access_cp_t
* Description  : This function converts CGM Record Access Control Point characteristic value representation in
*                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
* Arguments    : p_app_value - pointer to the CGM Record Access Control Point  value in the application layer
*                p_gatt_value - pointer to the characteristic value in the GATT database
* Return Value : ble_status_t
**********************************************************************************************************************/
static ble_status_t encode_st_ble_cgmc_record_access_cp_t(const st_ble_cgmc_record_access_cp_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    p_gatt_value->p_value[pos++] = p_app_value->op_code;
    p_gatt_value->p_value[pos++] = p_app_value->racp_operator;

    if (p_app_value->operand_len > 0)
    {
        int i = 0;
        for (i = 0; i < (p_app_value->operand_len); i++)
        {
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->operand[i]);
            pos += 1;
        }
    }

    p_gatt_value->value_len = (uint16_t)pos;

    return BLE_SUCCESS;
}

/* Record Access Control Point characteristic descriptor definition */
static const st_ble_servc_desc_info_t *gspp_record_access_cp_descs[] = 
{
    &gs_record_access_cp_cli_cnfg,
};

/* Record Access Control Point characteristic definition */
const st_ble_servc_char_info_t gs_record_access_cp_char = 
{
    .uuid_16      = BLE_CGMC_RECORD_ACCESS_CP_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_cgmc_record_access_cp_t),
    .db_size      = BLE_CGMC_RECORD_ACCESS_CP_LEN,
    .char_idx     = BLE_CGMC_RECORD_ACCESS_CP_IDX,
    .p_attr_hdls  = gs_record_access_cp_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_cgmc_record_access_cp_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_cgmc_record_access_cp_t,
    .num_of_descs = ARRAY_SIZE(gspp_record_access_cp_descs),
    .pp_descs     = gspp_record_access_cp_descs,
};

ble_status_t R_BLE_CGMC_WriteRecordAccessCp(uint16_t conn_hdl, const st_ble_cgmc_record_access_cp_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteChar(&gs_record_access_cp_char, conn_hdl, p_value);
}

void R_BLE_CGMC_GetRecordAccessCpAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_cgmc_record_access_cp_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_record_access_cp_char_ranges[conn_idx];
    p_hdl->cli_cnfg_desc_hdl = gs_record_access_cp_cli_cnfg_desc_hdls[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    CGM Specific Ops Control Point Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* CGM Specific Ops Control Point characteristic descriptors attribute handles */
static uint16_t gs_specific_ops_cp_cli_cnfg_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_specific_ops_cp_cli_cnfg =
{
    .uuid_16     = BLE_CGMC_SPECIFIC_OPS_CP_CLI_CNFG_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint16_t),
    .db_size     = BLE_CGMC_SPECIFIC_OPS_CP_CLI_CNFG_LEN,
    .desc_idx    = BLE_CGMC_SPECIFIC_OPS_CP_CLI_CNFG_IDX,
    .p_attr_hdls = gs_specific_ops_cp_cli_cnfg_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_CGMC_WriteSpecificOpsCpCliCnfg(uint16_t conn_hdl, const uint16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_specific_ops_cp_cli_cnfg, conn_hdl, p_value);
}

ble_status_t R_BLE_CGMC_ReadSpecificOpsCpCliCnfg(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_specific_ops_cp_cli_cnfg, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    CGM Specific Ops Control Point Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* CGM Specific Ops Control Point characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_specific_ops_cp_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************//**
* Function Name: decode_st_ble_cgmc_specific_ops_cp_t
* Description  : This function converts CGM Specific Opcodes Control Point characteristic value representation in
*                GATT (uint8_t[]) to representation in application layer (struct).
* Arguments    : p_app_value - pointer to the CGM Specific Opcodes Control Point value in the application layer
*                p_gatt_value - pointer to the characteristic value in the GATT database
* Return Value : ble_status_t
**********************************************************************************************************************/
static ble_status_t decode_st_ble_cgmc_specific_ops_cp_t(st_ble_cgmc_specific_ops_cp_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;

    if (BLE_CGMC_PRV_CGM_SPECIFIC_CP_LEN < p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    memset((uint8_t*)p_app_value, 0x00, sizeof(st_ble_cgmc_specific_ops_cp_t));

    /* Copy the CGM_SPECIFIC_CONTROL_POINT op_code___response_codes value */
    BT_UNPACK_LE_1_BYTE(&p_app_value->op_code, &p_gatt_value->p_value[pos++]);
    
    if ((BLE_CGMC_SPECIFIC_OPS_CP_OP_CODE_CGM_COMMUNICATION_INTERVAL_RESPONSE == p_app_value->op_code))
    {
        /* copy the value of spec_cp_operand value*/
        BT_PACK_LE_1_BYTE(&p_app_value->operand, &p_gatt_value->p_value[pos++]);        
    }
    else if ((BLE_CGMC_SPECIFIC_OPS_CP_OP_CODE_GLUCOSE_CALIBRATION_VALUE_RESPONSE == p_app_value->op_code))
    {
        if (g_cgm_feature.cgm_feature.is_calibration_supported)
        {
            /*Copy the CGM_SPECIFIC_CONTROL_POINT calibration_value___glucose_concentration_of_calibration value*/		
            BT_UNPACK_LE_2_BYTE(&p_app_value->calibration_value_glucose_concentration_of_calibration.mantissa,
                &p_gatt_value->p_value[pos]);
            p_app_value->calibration_value_glucose_concentration_of_calibration.exponent = (int8_t)((
                (int16_t)p_app_value->calibration_value_glucose_concentration_of_calibration.mantissa) >> 12);
            p_app_value->calibration_value_glucose_concentration_of_calibration.mantissa = (int16_t)(
                p_app_value->calibration_value_glucose_concentration_of_calibration.mantissa & 0x0FFF);
            pos += 2;

            /*Copy the CGM_SPECIFIC_CONTROL_POINT calibration_value___calibration_time value*/
            BT_UNPACK_LE_2_BYTE(&p_app_value->calibration_value_calibration_time, &p_gatt_value->p_value[pos]);
            pos += 2;

            uint8_t type_location = p_gatt_value->p_value[pos++];
            /*Copy the CGM_SPECIFIC_CONTROL_POINT calibration_value___calibration_type value*/
            p_app_value->calibration_value_calibration_type = (type_location & 0x0F);

            /*Copy the CGM_SPECIFIC_CONTROL_POINT calibration_value___calibration_sample_location value*/
            p_app_value->calibration_value_calibration_sample_location = ((type_location & 0xF0) >> 4);

            /*Copy the CGM_SPECIFIC_CONTROL_POINT calibration_value___next_calibration_time value*/
            BT_UNPACK_LE_2_BYTE(&p_app_value->calibration_value_next_calibration_time, &p_gatt_value->p_value[pos]);
            pos += 2;

            /*Copy the CGM_SPECIFIC_CONTROL_POINT calibration_value___calibration_data_record_number value*/
            BT_UNPACK_LE_2_BYTE(&p_app_value->calibration_value_calibration_data_record_number, &p_gatt_value->p_value[pos]);
            pos += 2;
            
            /* Calibration Status */
            uint8_t feature_byte1 = 0;
            BT_UNPACK_LE_1_BYTE(&feature_byte1, &p_gatt_value->p_value[pos++]);

            /* is_calibration_data_rejected__calibration_failed bit */
            if (feature_byte1 & BLE_CGMC_PRV_CGM_SPECIFIC_CP_CAL_VALUE_CAL_STATUS_CAL_DATA_REJECTED_OR_CAL_FAILED)
            {
                p_app_value->calibration_value_calibration_status.is_calibration_data_rejected = true;
            }
            else
            {
                p_app_value->calibration_value_calibration_status.is_calibration_data_rejected = false;
            }

            /* is_calibration_data_out_of_range bit */
            if (feature_byte1 & BLE_CGMC_PRV_CGM_SPECIFIC_CP_CAL_VALUE_CAL_STATUS_CAL_DATA_OUT_OFF_RANGE)
            {
                p_app_value->calibration_value_calibration_status.is_calibration_data_out_of_range = true;
            }
            else
            {
                p_app_value->calibration_value_calibration_status.is_calibration_data_out_of_range = false;
            }

            /* is_calibration_process_pending bit */
            if (feature_byte1 & BLE_CGMC_PRV_CGM_SPECIFIC_CP_CAL_VALUE_CAL_STATUS_CAL_DATA_PROCESS_PENDING)
            {
                p_app_value->calibration_value_calibration_status.is_calibration_process_pending = true;
            }
            else
            {
                p_app_value->calibration_value_calibration_status.is_calibration_process_pending = false;
            }
        }
    }
    else if ((BLE_CGMC_SPECIFIC_OPS_CP_OP_CODE_PATIENT_HIGH_ALERT_LEVEL_RESPONSE == p_app_value->op_code) ||
             (BLE_CGMC_SPECIFIC_OPS_CP_OP_CODE_PATIENT_LOW_ALERT_LEVEL_RESPONSE == p_app_value->op_code) ||
             (BLE_CGMC_SPECIFIC_OPS_CP_OP_CODE_HYPER_ALERT_LEVEL_RESPONSE == p_app_value->op_code) || 
             (BLE_CGMC_SPECIFIC_OPS_CP_OP_CODE_RATE_OF_DECREASE_ALERT_LEVEL_RESPONSE == p_app_value->op_code) ||
             (BLE_CGMC_SPECIFIC_OPS_CP_OP_CODE_RATE_OF_INCREASE_ALERT_LEVEL_RESPONSE == p_app_value->op_code) || 
             (BLE_CGMC_SPECIFIC_OPS_CP_OP_CODE_HYPO_ALERT_LEVEL_RESPONSE == p_app_value->op_code))
    {
        /* Copy the Alert Level */
        BT_UNPACK_LE_1_BYTE(&p_app_value->operand, &p_gatt_value->p_value[pos++]);
        BT_UNPACK_LE_1_BYTE(&p_app_value->op_code_response_codes, &p_gatt_value->p_value[pos++]);
    }
    else //BLE_CGMC_SPECIFIC_OPS_CP_OP_CODE_RESPONSE_CODE
    {
        /* Copy the Request opcode and Response Code Value */
        BT_UNPACK_LE_1_BYTE(&p_app_value->operand, &p_gatt_value->p_value[pos++]);
        BT_UNPACK_LE_1_BYTE(&p_app_value->op_code_response_codes, &p_gatt_value->p_value[pos++]);
    }
    
    /*Copy the CGM_SPECIFIC_CONTROL_POINT e2e_crc value*/
    if (g_cgm_feature.cgm_feature.is_e2e_crc_supported && p_gatt_value->value_len > pos)
    {
        BT_UNPACK_LE_2_BYTE(&p_app_value->e2e_crc, &p_gatt_value->p_value[pos]);
        pos += 2;
    }
    
    return BLE_SUCCESS;
}

/***********************************************************************************************************************//**
* Function Name: encode_st_ble_cgmc_specific_ops_cp_t
* Description  : This function converts CGM Specific Opcodes Control Point characteristic value representation in
*                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
* Arguments    : p_app_value - pointer to the CGM Specific Opcodes Control Point value in the application layer
*                p_gatt_value - pointer to the characteristic value in the GATT database
* Return Value : ble_status_t
**********************************************************************************************************************/
static ble_status_t encode_st_ble_cgmc_specific_ops_cp_t(const st_ble_cgmc_specific_ops_cp_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    /* copy the value of op_code value*/
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->op_code);
    
    if (BLE_CGMC_SPECIFIC_OPS_CP_OP_CODE_SET_CGM_COMMUNICATION_INTERVAL == p_app_value->op_code)
    {
        /* copy the value of spec_cp_operand value - communication interval in minutes */
        BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->operand);
    }

    if (BLE_CGMC_SPECIFIC_OPS_CP_OP_CODE_SET_PATIENT_LOW_ALERT_LEVEL == p_app_value->op_code)
    {
        /* copy the value of spec_cp_operand value*/
        BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->operand);

        /* copy the value of op_code_response_codes value*/
        BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->op_code_response_codes);
    }

    if (BLE_CGMC_SPECIFIC_OPS_CP_OP_CODE_SET_RATE_OF_DECREASE_ALERT_LEVEL == p_app_value->op_code)
    {
        /* copy the value of spec_cp_operand value*/
        BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->operand);

        /* copy the value of op_code_response_codes value*/
        BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->op_code_response_codes);
    }

    if (BLE_CGMC_SPECIFIC_OPS_CP_OP_CODE_SET_HYPER_ALERT_LEVEL == p_app_value->op_code)
    {
        /* copy the value of spec_cp_operand value*/
        BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->operand);

        /* copy the value of op_code_response_codes value*/
        BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->op_code_response_codes);
    }

    if (BLE_CGMC_SPECIFIC_OPS_CP_OP_CODE_SET_HYPO_ALERT_LEVEL == p_app_value->op_code)
    {
        /* copy the value of spec_cp_operand value*/
        BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->operand);

        /* copy the value of op_code_response_codes value*/
        BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->op_code_response_codes);
    }

    if (BLE_CGMC_SPECIFIC_OPS_CP_OP_CODE_SET_RATE_OF_INCREASE_ALERT_LEVEL == p_app_value->op_code)
    {
        /* copy the value of spec_cp_operand value*/
        BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->operand);

        /* copy the value of op_code_response_codes value*/
        BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->op_code_response_codes);
    }

    if (BLE_CGMC_SPECIFIC_OPS_CP_OP_CODE_SET_PATIENT_HIGH_ALERT_LEVEL == p_app_value->op_code)
    {
        /* copy the value of spec_cp_operand value*/
        BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->operand);

        /* copy the value of op_code_response_codes value*/
        BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->op_code_response_codes);
    }
       
    if (BLE_CGMC_SPECIFIC_OPS_CP_OP_CODE_GET_GLUCOSE_CALIBRATION_VALUE == p_app_value->op_code)
    {
        /* copy the value of spec_cp_operand value*/
        BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->operand);

        /* copy the value of spec_cp_operand value*/
        BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->op_code_response_codes);
    }

    if (BLE_CGMC_SPECIFIC_OPS_CP_OP_CODE_SET_GLUCOSE_CALIBRATION_VALUE == p_app_value->op_code)
    {
        /* copy the value of spec_cp_operand value*/
        BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->operand);

        /* copy the value of calibration_value___glucose_concentration_of_calibration value*/
        uint16_t value_to_copy_calibration_value_glucose_concentration_of_calibration = 0;

        value_to_copy_calibration_value_glucose_concentration_of_calibration = (uint16_t)((((
            ((int16_t)(p_app_value->calibration_value_glucose_concentration_of_calibration.exponent)) << 12) & 0xF000)
            | (p_app_value->calibration_value_glucose_concentration_of_calibration.mantissa & 0x0FFF)));

        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], (uint8_t*)&value_to_copy_calibration_value_glucose_concentration_of_calibration);
        pos += 2;

        /* copy the value of calibration_value___calibration_time value*/
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->calibration_value_calibration_time);
        pos += 2;

        /* copy the value of calibration_value___calibration_sample_location value*/
        BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->calibration_value_calibration_sample_location);

        /* copy the value of calibration_value___next_calibration_time value*/
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->calibration_value_next_calibration_time);
        pos += 2;

        /* copy the value of calibration_value___calibration_data_record_number value*/
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->calibration_value_calibration_data_record_number);
        pos += 2;
    }

    p_gatt_value->value_len = (uint16_t)pos;

    return BLE_SUCCESS;
}

/* CGM Specific Ops Control Point characteristic descriptor definition */
static const st_ble_servc_desc_info_t *gspp_specific_ops_cp_descs[] = 
{
    &gs_specific_ops_cp_cli_cnfg,
};

/* CGM Specific Ops Control Point characteristic definition */
const st_ble_servc_char_info_t gs_specific_ops_cp_char = 
{
    .uuid_16      = BLE_CGMC_SPECIFIC_OPS_CP_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_cgmc_specific_ops_cp_t),
    .db_size      = BLE_CGMC_SPECIFIC_OPS_CP_LEN,
    .char_idx     = BLE_CGMC_SPECIFIC_OPS_CP_IDX,
    .p_attr_hdls  = gs_specific_ops_cp_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_cgmc_specific_ops_cp_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_cgmc_specific_ops_cp_t,
    .num_of_descs = ARRAY_SIZE(gspp_specific_ops_cp_descs),
    .pp_descs     = gspp_specific_ops_cp_descs,
};

ble_status_t R_BLE_CGMC_WriteSpecificOpsCp(uint16_t conn_hdl, const st_ble_cgmc_specific_ops_cp_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteChar(&gs_specific_ops_cp_char, conn_hdl, p_value);
}

void R_BLE_CGMC_GetSpecificOpsCpAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_cgmc_specific_ops_cp_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_specific_ops_cp_char_ranges[conn_idx];
    p_hdl->cli_cnfg_desc_hdl = gs_specific_ops_cp_cli_cnfg_desc_hdls[conn_idx];
}


/*----------------------------------------------------------------------------------------------------------------------
    Continuous Glucose Monitoring client
----------------------------------------------------------------------------------------------------------------------*/

/* Continuous Glucose Monitoring client attribute handles */
static st_ble_gatt_hdl_range_t gs_cgmc_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

const st_ble_servc_char_info_t *gspp_cgmc_chars[] = 
{
    &gs_meas_char,
    &gs_feat_char,
    &gs_status_char,
    &gs_session_start_time_char,
    &gs_session_run_time_char,
    &gs_record_access_cp_char,
    &gs_specific_ops_cp_char,
};

static st_ble_servc_info_t gs_client_info = 
{
    .pp_chars     = gspp_cgmc_chars,
    .num_of_chars = ARRAY_SIZE(gspp_cgmc_chars),
    .p_attr_hdls  = gs_cgmc_ranges,
};

/***********************************************************************************************************************//**
* Function Name: R_BLE_CGMC_Init
* Description  : This function initializes the GATTS Server and CGM Service, registers the callback function for
*                GATTS.
* Arguments    : cb - cal back to the initialization parameters data
* Return Value : BLE_SUCCESS               - Success
*                BLE_ERR_INVALID_PTR       - The p_ntf_data parameter or the value field in the value field in
*                                            the p_ntf_data parameter is NULL.
*                BLE_ERR_INVALID_ARG       - The value_len field in the value field in the p_ntf_data parameter is 0
*                                            or the attr_hdl field in the p_ntf_data parameters is 0.
**********************************************************************************************************************/
ble_status_t R_BLE_CGMC_Init(ble_servc_app_cb_t cb) // @suppress("API function naming")
{
    if (NULL == cb)
    {
        return BLE_ERR_INVALID_PTR;
    }

    gs_client_info.cb = cb;

    return R_BLE_SERVC_RegisterClient(&gs_client_info);
}

/***********************************************************************************************************************//**
 * Function Name: R_BLE_CGMC_ServDiscCb
 * Description  : Callback function for the Continuous Glucose Monitoring Service Discovery events.
 * Arguments    : conn_hdl  - handle to the connection
 *                type      - discovery event id
 *              : p_param   - pointer to GATTC event data
 *              : serv_idx  - Service index used to distinguish the multiple same UUID service.
 * Return Value : none
***********************************************************************************************************************/
void R_BLE_CGMC_ServDiscCb(uint16_t conn_hdl, uint8_t serv_idx, uint16_t type, void *p_param) // @suppress("API function naming")
{
    R_BLE_SERVC_ServDiscCb(&gs_client_info, conn_hdl, serv_idx, type, p_param);
}

void R_BLE_CGMC_GetServAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_gatt_hdl_range_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    *p_hdl = gs_cgmc_ranges[conn_idx];
}
