/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_aioc.c
 * Version : 1.0
 * Description : The source file for Automation IO client.
 **********************************************************************************************************************/
#include <string.h>
#include "r_ble_aioc.h"
#include "profile_cmn/r_ble_servc_if.h"

static st_ble_servc_info_t gs_client_info;

/*----------------------------------------------------------------------------------------------------------------------
    Digital 0 Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Digital 0 characteristic descriptors attribute handles */
static uint16_t gs_digital_0_cli_cnfg_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_digital_0_cli_cnfg ={
    .uuid_16     = BLE_AIOC_DIGITAL_0_CLI_CNFG_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint16_t),
    .db_size     = BLE_AIOC_DIGITAL_0_CLI_CNFG_LEN,
    .desc_idx    = BLE_AIOC_DIGITAL_0_CLI_CNFG_IDX,
    .p_attr_hdls = gs_digital_0_cli_cnfg_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_AIOC_WriteDigital0CliCnfg(uint16_t conn_hdl, const uint16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_digital_0_cli_cnfg, conn_hdl, p_value);
}

ble_status_t R_BLE_AIOC_ReadDigital0CliCnfg(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_digital_0_cli_cnfg, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Digital 0 Characteristic Presentation Format descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Digital 0 characteristic descriptors attribute handles */
static uint16_t gs_digital_0_char_presentation_format_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************
 * Function Name: decode_st_ble_aioc_digital_0_char_presentation_format_t
 * Description  : This function converts descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - Pointer to the characteristic value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_aioc_digital_0_char_presentation_format_t(st_ble_aioc_digital_0_char_presentation_format_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    /* Check the length */
    if (BLE_AIOC_DIGITAL_0_CHAR_PRESENTATION_FORMAT_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Decode Presentation format fields */
    BT_UNPACK_LE_1_BYTE(&p_app_value->format, &p_gatt_value->p_value[pos]);
    pos += 1;

    BT_UNPACK_LE_1_BYTE(&p_app_value->exponent, &p_gatt_value->p_value[pos]);
    pos += 1;

    BT_UNPACK_LE_2_BYTE(&p_app_value->unit, &p_gatt_value->p_value[pos]);
    pos += 2;

    BT_UNPACK_LE_1_BYTE(&p_app_value->name_space, &p_gatt_value->p_value[pos]);
    pos += 1;

    BT_UNPACK_LE_2_BYTE(&p_app_value->description, &p_gatt_value->p_value[pos]);

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_st_ble_aioc_digital_0_char_presentation_format_t
 * Description  : This function converts characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value  - Pointer to the characteristic  value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_aioc_digital_0_char_presentation_format_t(const st_ble_aioc_digital_0_char_presentation_format_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_AIOC_DIGITAL_0_CHAR_PRESENTATION_FORMAT_LEN);

    /* Encode Presentation format fields */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->format);
    pos += 1;

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->exponent);
    pos += 1;

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->unit);
    pos += 2;

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->name_space);
    pos += 1;

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->description);

    /* Update length */
    p_gatt_value->value_len = BLE_AIOC_DIGITAL_0_CHAR_PRESENTATION_FORMAT_LEN;

    return BLE_SUCCESS;
}

static const st_ble_servc_desc_info_t gs_digital_0_char_presentation_format ={
    .uuid_16     = BLE_AIOC_DIGITAL_0_CHAR_PRESENTATION_FORMAT_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(st_ble_aioc_digital_0_char_presentation_format_t),
    .db_size     = BLE_AIOC_DIGITAL_0_CHAR_PRESENTATION_FORMAT_LEN,
    .desc_idx    = BLE_AIOC_DIGITAL_0_CHAR_PRESENTATION_FORMAT_IDX,
    .p_attr_hdls = gs_digital_0_char_presentation_format_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_st_ble_aioc_digital_0_char_presentation_format_t,
    .encode      = (ble_servc_attr_encode_t)encode_st_ble_aioc_digital_0_char_presentation_format_t,
};

ble_status_t R_BLE_AIOC_ReadDigital0CharPresentationFormat(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_digital_0_char_presentation_format, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Digital 0 Characteristic User Description descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Digital 0 characteristic descriptors attribute handles */
static uint16_t gs_digital_0_char_user_description_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_digital_0_char_user_description ={
    .uuid_16     = BLE_AIOC_DIGITAL_0_CHAR_USER_DESCRIPTION_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint8_t) * 100,
    .db_size     = BLE_AIOC_DIGITAL_0_CHAR_USER_DESCRIPTION_LEN,
    .desc_idx    = BLE_AIOC_DIGITAL_0_CHAR_USER_DESCRIPTION_IDX,
    .p_attr_hdls = gs_digital_0_char_user_description_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_allcopy,
    .encode      = (ble_servc_attr_encode_t)encode_allcopy,
};

ble_status_t R_BLE_AIOC_WriteDigital0CharUserDescription(uint16_t conn_hdl, const st_ble_seq_data_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc_with_Size(&gs_digital_0_char_user_description, conn_hdl, p_value);
}

ble_status_t R_BLE_AIOC_ReadDigital0CharUserDescription(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_digital_0_char_user_description, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Digital 0 Characteristic Extended Properties descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Digital 0 characteristic descriptors attribute handles */
static uint16_t gs_digital_0_char_extended_properties_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_digital_0_char_extended_properties ={
    .uuid_16     = BLE_AIOC_DIGITAL_0_CHAR_EXTENDED_PROPERTIES_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint16_t),
    .db_size     = BLE_AIOC_DIGITAL_0_CHAR_EXTENDED_PROPERTIES_LEN,
    .desc_idx    = BLE_AIOC_DIGITAL_0_CHAR_EXTENDED_PROPERTIES_IDX,
    .p_attr_hdls = gs_digital_0_char_extended_properties_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_AIOC_ReadDigital0CharExtendedProperties(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_digital_0_char_extended_properties, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Digital 0 Value Trigger Setting descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Digital 0 characteristic descriptors attribute handles */
static uint16_t gs_digital_0_val_trigger_setting_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************
 * Function Name: decode_st_ble_aioc_digital_0_val_trigger_setting_t
 * Description  : This function converts descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - Pointer to the characteristic value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_aioc_digital_0_val_trigger_setting_t(st_ble_aioc_digital_0_val_trigger_setting_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    /* Check the length */
    if (BLE_AIOC_DIGITAL_0_VAL_TRIGGER_SETTING_LEN < p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Copy the condition byte */
    uint8_t condition = p_gatt_value->p_value[pos];

    /* Check for Supported condition */
    if ((BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_NO_VALUE_TRIGGER < condition) || 
        ((BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_CHARACTERISTIC_VALUE_CHANGED != condition) &&  
        (BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_MASK_THEN_COMPARE != condition) && 
        (BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_NO_VALUE_TRIGGER != condition)))
    {
        return BLE_AIOC_TRIGGER_CONDITION_VALUE_NOT_SUPPORTED_ERROR;
    }

    BT_UNPACK_LE_1_BYTE(&p_app_value->condition, &p_gatt_value->p_value[pos]);
    pos += 1;

    if (BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_MASK_THEN_COMPARE == condition)
    {
        /* Decode value Trigger setting fields */
        BT_UNPACK_LE_2_BYTE(&p_app_value->bit_mask_value, &p_gatt_value->p_value[pos]);
        pos += 2;
    }
    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_st_ble_aioc_digital_0_val_trigger_setting_t
 * Description  : This function converts characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value  - Pointer to the characteristic  value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_aioc_digital_0_val_trigger_setting_t(const st_ble_aioc_digital_0_val_trigger_setting_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_AIOC_DIGITAL_0_VAL_TRIGGER_SETTING_LEN);

    /* Encode value trigger setting fields */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->condition);
    pos += 1;

    if ((BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_MASK_THEN_COMPARE == p_app_value->condition))
    {
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->bit_mask_value);
        pos += 2;
    }
    else
    {
        /* Do Nothing */
    }

    /* Update length */
    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}


static const st_ble_servc_desc_info_t gs_digital_0_val_trigger_setting ={
    .uuid_16     = BLE_AIOC_DIGITAL_0_VAL_TRIGGER_SETTING_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(st_ble_aioc_digital_0_val_trigger_setting_t),
    .db_size     = BLE_AIOC_DIGITAL_0_VAL_TRIGGER_SETTING_LEN,
    .desc_idx    = BLE_AIOC_DIGITAL_0_VAL_TRIGGER_SETTING_IDX,
    .p_attr_hdls = gs_digital_0_val_trigger_setting_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_st_ble_aioc_digital_0_val_trigger_setting_t,
    .encode      = (ble_servc_attr_encode_t)encode_st_ble_aioc_digital_0_val_trigger_setting_t,
};

ble_status_t R_BLE_AIOC_WriteDigital0ValTriggerSetting(uint16_t conn_hdl, const st_ble_aioc_digital_0_val_trigger_setting_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_digital_0_val_trigger_setting, conn_hdl, p_value);
}

ble_status_t R_BLE_AIOC_ReadDigital0ValTriggerSetting(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_digital_0_val_trigger_setting, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Digital 0 Time Trigger Setting descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Digital 0 characteristic descriptors attribute handles */
static uint16_t gs_digital_0_time_trigger_setting_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************
 * Function Name: decode_st_ble_aioc_digital_0_time_trigger_setting_t
 * Description  : This function converts descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - Pointer to the characteristic value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_aioc_digital_0_time_trigger_setting_t(st_ble_aioc_digital_0_time_trigger_setting_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    /* check the length */
    if (BLE_AIOC_DIGITAL_0_TIME_TRIGGER_SETTING_LEN < p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Copy the condition byte */
    uint8_t condition = p_gatt_value->p_value[pos];


    /* Check for Supported condition */
    if (BLE_AIOC_TIME_TRIGGER_CHANGED_MORE_OFTEN < condition)
    {
        return BLE_AIOC_TRIGGER_CONDITION_VALUE_NOT_SUPPORTED_ERROR;
    }

    memset(p_app_value, 0x00, sizeof(st_ble_aioc_digital_0_time_trigger_setting_t));

    BT_UNPACK_LE_1_BYTE(&p_app_value->condition, &p_gatt_value->p_value[pos]);
    pos += 1;

    if ((BLE_AIOC_TIME_TRIGGER_INDICATES_OR_NOTIFIES_UNCONDITIONALLY == condition) ||
        (BLE_AIOC_TIME_TRIGGER_NOT_INDICATES_OR_NOTIFIES_OFTEN == condition))
    {
        BT_UNPACK_LE_3_BYTE(&p_app_value->time_interval_value, &p_gatt_value->p_value[pos]);
        pos += 3;
    }

    if (BLE_AIOC_TIME_TRIGGER_CHANGED_MORE_OFTEN == condition)
    {
        BT_UNPACK_LE_2_BYTE(&p_app_value->count_value, &p_gatt_value->p_value[pos]);
    }

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_st_ble_aioc_digital_0_time_trigger_setting_t
 * Description  : This function converts characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value  - Pointer to the characteristic  value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_aioc_digital_0_time_trigger_setting_t(const st_ble_aioc_digital_0_time_trigger_setting_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    int8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_AIOC_DIGITAL_0_TIME_TRIGGER_SETTING_LEN);

    /* Encode Time trigger setting fields */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->condition);
    pos += 1;

    if ((BLE_AIOC_TIME_TRIGGER_INDICATES_OR_NOTIFIES_UNCONDITIONALLY == p_app_value->condition) ||
        (BLE_AIOC_TIME_TRIGGER_NOT_INDICATES_OR_NOTIFIES_OFTEN == p_app_value->condition))
    {
        BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], &p_app_value->time_interval_value);
        pos += 3;
    }

    if (BLE_AIOC_TIME_TRIGGER_CHANGED_MORE_OFTEN == p_app_value->condition)
    {
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->count_value);
        pos += 2;
    }

    /* Update length */
    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

static const st_ble_servc_desc_info_t gs_digital_0_time_trigger_setting ={
    .uuid_16     = BLE_AIOC_DIGITAL_0_TIME_TRIGGER_SETTING_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(st_ble_aioc_digital_0_time_trigger_setting_t),
    .db_size     = BLE_AIOC_DIGITAL_0_TIME_TRIGGER_SETTING_LEN,
    .desc_idx    = BLE_AIOC_DIGITAL_0_TIME_TRIGGER_SETTING_IDX,
    .p_attr_hdls = gs_digital_0_time_trigger_setting_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_st_ble_aioc_digital_0_time_trigger_setting_t,
    .encode      = (ble_servc_attr_encode_t)encode_st_ble_aioc_digital_0_time_trigger_setting_t,
};

ble_status_t R_BLE_AIOC_WriteDigital0TimeTriggerSetting(uint16_t conn_hdl, const st_ble_aioc_digital_0_time_trigger_setting_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_digital_0_time_trigger_setting, conn_hdl, p_value);
}

ble_status_t R_BLE_AIOC_ReadDigital0TimeTriggerSetting(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_digital_0_time_trigger_setting, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Digital 0 Number of Digitals descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Digital 0 characteristic descriptors attribute handles */
static uint16_t gs_digital_0_num_of_digitals_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_digital_0_num_of_digitals ={
    .uuid_16     = BLE_AIOC_DIGITAL_0_NUM_OF_DIGITALS_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint8_t),
    .db_size     = BLE_AIOC_DIGITAL_0_NUM_OF_DIGITALS_LEN,
    .desc_idx    = BLE_AIOC_DIGITAL_0_NUM_OF_DIGITALS_IDX,
    .p_attr_hdls = gs_digital_0_num_of_digitals_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint8_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint8_t,
};

ble_status_t R_BLE_AIOC_ReadDigital0NumOfDigitals(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_digital_0_num_of_digitals, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Digital 0 Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Digital 0 characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_digital_0_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

/* Digital 0 characteristic descriptor definition */
static const st_ble_servc_desc_info_t *gspp_digital_0_descs[] = {
    &gs_digital_0_cli_cnfg,
    &gs_digital_0_char_presentation_format,
    &gs_digital_0_char_user_description,
    &gs_digital_0_char_extended_properties,
    &gs_digital_0_val_trigger_setting,
    &gs_digital_0_time_trigger_setting,
    &gs_digital_0_num_of_digitals,
};

/* Digital 0 characteristic definition */
static const st_ble_servc_char_info_t gs_digital_0_char = {
    .uuid_16      = BLE_AIOC_DIGITAL_0_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(uint16_t),
    .db_size      = BLE_AIOC_DIGITAL_0_LEN,
    .char_idx     = BLE_AIOC_DIGITAL_0_IDX,
    .p_attr_hdls  = gs_digital_0_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode       = (ble_servc_attr_encode_t)encode_uint16_t,
    .num_of_descs = ARRAY_SIZE(gspp_digital_0_descs),
    .pp_descs     = gspp_digital_0_descs,
};

ble_status_t R_BLE_AIOC_WriteDigital0(uint16_t conn_hdl, const uint16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteChar(&gs_digital_0_char, conn_hdl, p_value);
}

ble_status_t R_BLE_AIOC_WriteDigital0WithoutRsp(uint16_t conn_hdl, const uint16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteCmdChar(&gs_digital_0_char, conn_hdl, p_value);
}

ble_status_t R_BLE_AIOC_ReadDigital0(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_digital_0_char, conn_hdl);
}

void R_BLE_AIOC_GetDigital0AttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_aioc_digital_0_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_digital_0_char_ranges[conn_idx];
    p_hdl->cli_cnfg_desc_hdl = gs_digital_0_cli_cnfg_desc_hdls[conn_idx];
    p_hdl->char_presentation_format_desc_hdl = gs_digital_0_char_presentation_format_desc_hdls[conn_idx];
    p_hdl->char_user_description_desc_hdl = gs_digital_0_char_user_description_desc_hdls[conn_idx];
    p_hdl->char_extended_properties_desc_hdl = gs_digital_0_char_extended_properties_desc_hdls[conn_idx];
    p_hdl->val_trigger_setting_desc_hdl = gs_digital_0_val_trigger_setting_desc_hdls[conn_idx];
    p_hdl->time_trigger_setting_desc_hdl = gs_digital_0_time_trigger_setting_desc_hdls[conn_idx];
    p_hdl->num_of_digitals_desc_hdl = gs_digital_0_num_of_digitals_desc_hdls[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Digital 1 Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Digital 1 characteristic descriptors attribute handles */
static uint16_t gs_digital_1_cli_cnfg_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_digital_1_cli_cnfg ={
    .uuid_16     = BLE_AIOC_DIGITAL_1_CLI_CNFG_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint16_t),
    .db_size     = BLE_AIOC_DIGITAL_1_CLI_CNFG_LEN,
    .desc_idx    = BLE_AIOC_DIGITAL_1_CLI_CNFG_IDX,
    .p_attr_hdls = gs_digital_1_cli_cnfg_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_AIOC_WriteDigital1CliCnfg(uint16_t conn_hdl, const uint16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_digital_1_cli_cnfg, conn_hdl, p_value);
}

ble_status_t R_BLE_AIOC_ReadDigital1CliCnfg(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_digital_1_cli_cnfg, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Digital 1 Characteristic Presentation Format descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Digital 1 characteristic descriptors attribute handles */
static uint16_t gs_digital_1_char_presentation_format_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************
 * Function Name: decode_st_ble_aioc_digital_1_char_presentation_format_t
 * Description  : This function converts descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - Pointer to the characteristic value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_aioc_digital_1_char_presentation_format_t(st_ble_aioc_digital_0_char_presentation_format_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    /* Check the length */
    if (BLE_AIOC_DIGITAL_1_CHAR_PRESENTATION_FORMAT_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Decode Presentation format fields */
    BT_UNPACK_LE_1_BYTE(&p_app_value->format, &p_gatt_value->p_value[pos]);
    pos += 1;

    BT_UNPACK_LE_1_BYTE(&p_app_value->exponent, &p_gatt_value->p_value[pos]);
    pos += 1;

    BT_UNPACK_LE_2_BYTE(&p_app_value->unit, &p_gatt_value->p_value[pos]);
    pos += 2;

    BT_UNPACK_LE_1_BYTE(&p_app_value->name_space, &p_gatt_value->p_value[pos]);
    pos += 1;

    BT_UNPACK_LE_2_BYTE(&p_app_value->description, &p_gatt_value->p_value[pos]);

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_st_ble_aioc_digital_1_char_presentation_format_t
 * Description  : This function converts characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value  - Pointer to the characteristic  value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_aioc_digital_1_char_presentation_format_t(const st_ble_aioc_digital_1_char_presentation_format_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_AIOC_DIGITAL_1_CHAR_PRESENTATION_FORMAT_LEN);

    /* Encode Presentation format fields */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->format);
    pos += 1;

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->exponent);
    pos += 1;

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->unit);
    pos += 2;

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->name_space);
    pos += 1;

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->description);

    /* Update length */
    p_gatt_value->value_len = BLE_AIOC_DIGITAL_1_CHAR_PRESENTATION_FORMAT_LEN;

    return BLE_SUCCESS;
}

static const st_ble_servc_desc_info_t gs_digital_1_char_presentation_format ={
    .uuid_16     = BLE_AIOC_DIGITAL_1_CHAR_PRESENTATION_FORMAT_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(st_ble_aioc_digital_1_char_presentation_format_t),
    .db_size     = BLE_AIOC_DIGITAL_1_CHAR_PRESENTATION_FORMAT_LEN,
    .desc_idx    = BLE_AIOC_DIGITAL_1_CHAR_PRESENTATION_FORMAT_IDX,
    .p_attr_hdls = gs_digital_1_char_presentation_format_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_st_ble_aioc_digital_1_char_presentation_format_t,
    .encode      = (ble_servc_attr_encode_t)encode_st_ble_aioc_digital_1_char_presentation_format_t,
};

ble_status_t R_BLE_AIOC_ReadDigital1CharPresentationFormat(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_digital_1_char_presentation_format, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Digital 1 Characteristic User Description descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Digital 1 characteristic descriptors attribute handles */
static uint16_t gs_digital_1_char_user_description_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_digital_1_char_user_description ={
    .uuid_16     = BLE_AIOC_DIGITAL_1_CHAR_USER_DESCRIPTION_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint8_t) * 100,
    .db_size     = BLE_AIOC_DIGITAL_1_CHAR_USER_DESCRIPTION_LEN,
    .desc_idx    = BLE_AIOC_DIGITAL_1_CHAR_USER_DESCRIPTION_IDX,
    .p_attr_hdls = gs_digital_1_char_user_description_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_allcopy,
    .encode      = (ble_servc_attr_encode_t)encode_allcopy,
};

ble_status_t R_BLE_AIOC_WriteDigital1CharUserDescription(uint16_t conn_hdl, const st_ble_seq_data_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc_with_Size(&gs_digital_1_char_user_description, conn_hdl, p_value);
}

ble_status_t R_BLE_AIOC_ReadDigital1CharUserDescription(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_digital_1_char_user_description, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Digital 1 Characteristic Extended Properties descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Digital 1 characteristic descriptors attribute handles */
static uint16_t gs_digital_1_char_extended_properties_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_digital_1_char_extended_properties ={
    .uuid_16     = BLE_AIOC_DIGITAL_1_CHAR_EXTENDED_PROPERTIES_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint16_t),
    .db_size     = BLE_AIOC_DIGITAL_1_CHAR_EXTENDED_PROPERTIES_LEN,
    .desc_idx    = BLE_AIOC_DIGITAL_1_CHAR_EXTENDED_PROPERTIES_IDX,
    .p_attr_hdls = gs_digital_1_char_extended_properties_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_AIOC_ReadDigital1CharExtendedProperties(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_digital_1_char_extended_properties, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Digital 1 Value Trigger Setting descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Digital 1 characteristic descriptors attribute handles */
static uint16_t gs_digital_1_val_trigger_setting_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************
 * Function Name: decode_st_ble_aioc_digital_1_val_trigger_setting_t
 * Description  : This function converts descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - Pointer to the characteristic value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_aioc_digital_1_val_trigger_setting_t(st_ble_aioc_digital_1_val_trigger_setting_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    /* Check the length */
    if (BLE_AIOC_DIGITAL_1_VAL_TRIGGER_SETTING_LEN < p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Copy the condition byte */
    uint8_t condition = p_gatt_value->p_value[pos];

    /* Check for Supported condition */
    if ((BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_NO_VALUE_TRIGGER < condition) ||
        ((BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_CHARACTERISTIC_VALUE_CHANGED != condition) &&
        (BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_MASK_THEN_COMPARE != condition) &&
        (BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_NO_VALUE_TRIGGER != condition)))
    {
        return BLE_AIOC_TRIGGER_CONDITION_VALUE_NOT_SUPPORTED_ERROR;
    }

    BT_UNPACK_LE_1_BYTE(&p_app_value->condition, &p_gatt_value->p_value[pos]);
    pos += 1;

    if (BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_MASK_THEN_COMPARE == condition)
    {
        /* Decode value Trigger setting fields */
        BT_UNPACK_LE_2_BYTE(&p_app_value->bit_mask_value, &p_gatt_value->p_value[pos]);
        pos += 2;
    }
    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_st_ble_aioc_digital_1_value_trigger_setting_t
 * Description  : This function converts characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value  - Pointer to the characteristic  value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_aioc_digital_1_val_trigger_setting_t(const st_ble_aioc_digital_1_val_trigger_setting_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_AIOC_DIGITAL_1_VAL_TRIGGER_SETTING_LEN);

    /* Encode value trigger setting fields */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->condition);
    pos += 1;

    if ((BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_MASK_THEN_COMPARE == p_app_value->condition))
    {
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->bit_mask_value);
        pos += 2;
    }
    else
    {
        /* Do Nothing */
    }

    /* Update length */
    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

static const st_ble_servc_desc_info_t gs_digital_1_val_trigger_setting ={
    .uuid_16     = BLE_AIOC_DIGITAL_1_VAL_TRIGGER_SETTING_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(st_ble_aioc_digital_1_val_trigger_setting_t),
    .db_size     = BLE_AIOC_DIGITAL_1_VAL_TRIGGER_SETTING_LEN,
    .desc_idx    = BLE_AIOC_DIGITAL_1_VAL_TRIGGER_SETTING_IDX,
    .p_attr_hdls = gs_digital_1_val_trigger_setting_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_st_ble_aioc_digital_1_val_trigger_setting_t,
    .encode      = (ble_servc_attr_encode_t)encode_st_ble_aioc_digital_1_val_trigger_setting_t,
};

ble_status_t R_BLE_AIOC_WriteDigital1ValTriggerSetting(uint16_t conn_hdl, const st_ble_aioc_digital_1_val_trigger_setting_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_digital_1_val_trigger_setting, conn_hdl, p_value);
}

ble_status_t R_BLE_AIOC_ReadDigital1ValTriggerSetting(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_digital_1_val_trigger_setting, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Digital 1 Time Trigger Setting descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Digital 1 characteristic descriptors attribute handles */
static uint16_t gs_digital_1_time_trigger_setting_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************
 * Function Name: decode_st_ble_aioc_digital_1_time_trigger_setting_t
 * Description  : This function converts descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - Pointer to the characteristic value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_aioc_digital_1_time_trigger_setting_t(st_ble_aioc_digital_1_time_trigger_setting_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    /* check the length */
    if (BLE_AIOC_DIGITAL_1_TIME_TRIGGER_SETTING_LEN < p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Copy the condition byte */
    uint8_t condition = p_gatt_value->p_value[pos];


    /* Check for Supported condition */
    if (BLE_AIOC_TIME_TRIGGER_CHANGED_MORE_OFTEN < condition)
    {
        return BLE_AIOC_TRIGGER_CONDITION_VALUE_NOT_SUPPORTED_ERROR;
    }

    memset(p_app_value, 0x00, sizeof(st_ble_aioc_digital_1_time_trigger_setting_t));

    BT_UNPACK_LE_1_BYTE(&p_app_value->condition, &p_gatt_value->p_value[pos]);
    pos += 1;

    if ((BLE_AIOC_TIME_TRIGGER_INDICATES_OR_NOTIFIES_UNCONDITIONALLY == condition) ||
        (BLE_AIOC_TIME_TRIGGER_NOT_INDICATES_OR_NOTIFIES_OFTEN == condition))
    {
        BT_UNPACK_LE_3_BYTE(&p_app_value->time_interval_value, &p_gatt_value->p_value[pos]);
        pos += 3;
    }

    if (BLE_AIOC_TIME_TRIGGER_CHANGED_MORE_OFTEN == condition)
    {
        BT_UNPACK_LE_2_BYTE(&p_app_value->count_value, &p_gatt_value->p_value[pos]);
    }

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_st_ble_aioc_digital_1_time_trigger_setting_t
 * Description  : This function converts characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value  - Pointer to the characteristic  value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_aioc_digital_1_time_trigger_setting_t(const st_ble_aioc_digital_1_time_trigger_setting_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    int8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_AIOC_DIGITAL_1_TIME_TRIGGER_SETTING_LEN);

    /* Encode Time trigger setting fields */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->condition);
    pos += 1;

    if ((BLE_AIOC_TIME_TRIGGER_INDICATES_OR_NOTIFIES_UNCONDITIONALLY == p_app_value->condition) ||
        (BLE_AIOC_TIME_TRIGGER_NOT_INDICATES_OR_NOTIFIES_OFTEN == p_app_value->condition))
    {
        BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], &p_app_value->time_interval_value);
        pos += 3;
    }

    if (BLE_AIOC_TIME_TRIGGER_CHANGED_MORE_OFTEN == p_app_value->condition)
    {
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->count_value);
        pos += 2;
    }

    /* Update length */
    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

static const st_ble_servc_desc_info_t gs_digital_1_time_trigger_setting ={
    .uuid_16     = BLE_AIOC_DIGITAL_1_TIME_TRIGGER_SETTING_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(st_ble_aioc_digital_1_time_trigger_setting_t),
    .db_size     = BLE_AIOC_DIGITAL_1_TIME_TRIGGER_SETTING_LEN,
    .desc_idx    = BLE_AIOC_DIGITAL_1_TIME_TRIGGER_SETTING_IDX,
    .p_attr_hdls = gs_digital_1_time_trigger_setting_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_st_ble_aioc_digital_1_time_trigger_setting_t,
    .encode      = (ble_servc_attr_encode_t)encode_st_ble_aioc_digital_1_time_trigger_setting_t,
};

ble_status_t R_BLE_AIOC_WriteDigital1TimeTriggerSetting(uint16_t conn_hdl, const st_ble_aioc_digital_1_time_trigger_setting_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_digital_1_time_trigger_setting, conn_hdl, p_value);
}

ble_status_t R_BLE_AIOC_ReadDigital1TimeTriggerSetting(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_digital_1_time_trigger_setting, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Digital 1 Number of Digitals descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Digital 1 characteristic descriptors attribute handles */
static uint16_t gs_digital_1_num_of_digitals_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_digital_1_num_of_digitals ={
    .uuid_16     = BLE_AIOC_DIGITAL_1_NUM_OF_DIGITALS_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint8_t),
    .db_size     = BLE_AIOC_DIGITAL_1_NUM_OF_DIGITALS_LEN,
    .desc_idx    = BLE_AIOC_DIGITAL_1_NUM_OF_DIGITALS_IDX,
    .p_attr_hdls = gs_digital_1_num_of_digitals_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint8_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint8_t,
};

ble_status_t R_BLE_AIOC_ReadDigital1NumOfDigitals(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_digital_1_num_of_digitals, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Digital 1 Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Digital 1 characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_digital_1_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

/* Digital 1 characteristic descriptor definition */
static const st_ble_servc_desc_info_t *gspp_digital_1_descs[] = {
    &gs_digital_1_cli_cnfg,
    &gs_digital_1_char_presentation_format,
    &gs_digital_1_char_user_description,
    &gs_digital_1_char_extended_properties,
    &gs_digital_1_val_trigger_setting,
    &gs_digital_1_time_trigger_setting,
    &gs_digital_1_num_of_digitals,
};

/* Digital 1 characteristic definition */
static const st_ble_servc_char_info_t gs_digital_1_char = {
    .uuid_16      = BLE_AIOC_DIGITAL_1_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(uint16_t),
    .db_size      = BLE_AIOC_DIGITAL_1_LEN,
    .char_idx     = BLE_AIOC_DIGITAL_1_IDX,
    .p_attr_hdls  = gs_digital_1_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode       = (ble_servc_attr_encode_t)encode_uint16_t,
    .num_of_descs = ARRAY_SIZE(gspp_digital_1_descs),
    .pp_descs     = gspp_digital_1_descs,
};

ble_status_t R_BLE_AIOC_WriteDigital1(uint16_t conn_hdl, const uint16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteChar(&gs_digital_1_char, conn_hdl, p_value);
}

ble_status_t R_BLE_AIOC_ReadDigital1(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_digital_1_char, conn_hdl);
}

ble_status_t R_BLE_AIOC_WriteDigital1WithoutRsp(uint16_t conn_hdl, const uint16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteCmdChar(&gs_digital_1_char, conn_hdl, p_value);
}

void R_BLE_AIOC_GetDigital1AttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_aioc_digital_1_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_digital_1_char_ranges[conn_idx];
    p_hdl->cli_cnfg_desc_hdl = gs_digital_1_cli_cnfg_desc_hdls[conn_idx];
    p_hdl->char_presentation_format_desc_hdl = gs_digital_1_char_presentation_format_desc_hdls[conn_idx];
    p_hdl->char_user_description_desc_hdl = gs_digital_1_char_user_description_desc_hdls[conn_idx];
    p_hdl->char_extended_properties_desc_hdl = gs_digital_1_char_extended_properties_desc_hdls[conn_idx];
    p_hdl->val_trigger_setting_desc_hdl = gs_digital_1_val_trigger_setting_desc_hdls[conn_idx];
    p_hdl->time_trigger_setting_desc_hdl = gs_digital_1_time_trigger_setting_desc_hdls[conn_idx];
    p_hdl->num_of_digitals_desc_hdl = gs_digital_1_num_of_digitals_desc_hdls[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Analog 0 Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Analog 0 characteristic descriptors attribute handles */
static uint16_t gs_analog_0_cli_cnfg_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_analog_0_cli_cnfg ={
    .uuid_16     = BLE_AIOC_ANALOG_0_CLI_CNFG_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint16_t),
    .db_size     = BLE_AIOC_ANALOG_0_CLI_CNFG_LEN,
    .desc_idx    = BLE_AIOC_ANALOG_0_CLI_CNFG_IDX,
    .p_attr_hdls = gs_analog_0_cli_cnfg_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_AIOC_WriteAnalog0CliCnfg(uint16_t conn_hdl, const uint16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_analog_0_cli_cnfg, conn_hdl, p_value);
}

ble_status_t R_BLE_AIOC_ReadAnalog0CliCnfg(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_analog_0_cli_cnfg, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Analog 0 Characteristic Presentation Format descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Analog 0 characteristic descriptors attribute handles */
static uint16_t gs_analog_0_char_presentation_format_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************
 * Function Name: decode_st_ble_aioc_analog_0_char_presentation_format_t
 * Description  : This function converts descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - Pointer to the characteristic value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_aioc_analog_0_char_presentation_format_t(st_ble_aioc_analog_0_char_presentation_format_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    /* Check the length */
    if (BLE_AIOC_ANALOG_0_CHAR_PRESENTATION_FORMAT_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Decode Presentation format fields */
    BT_UNPACK_LE_1_BYTE(&p_app_value->format, &p_gatt_value->p_value[pos]);
    pos += 1;

    BT_UNPACK_LE_1_BYTE(&p_app_value->exponent, &p_gatt_value->p_value[pos]);
    pos += 1;

    BT_UNPACK_LE_2_BYTE(&p_app_value->unit, &p_gatt_value->p_value[pos]);
    pos += 2;

    BT_UNPACK_LE_1_BYTE(&p_app_value->name_space, &p_gatt_value->p_value[pos]);
    pos += 1;

    BT_UNPACK_LE_2_BYTE(&p_app_value->description, &p_gatt_value->p_value[pos]);

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_st_ble_aioc_analog_0_char_presentation_format_t
 * Description  : This function converts characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value  - Pointer to the characteristic  value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_aioc_analog_0_char_presentation_format_t(const st_ble_aioc_analog_0_char_presentation_format_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_AIOC_ANALOG_0_CHAR_PRESENTATION_FORMAT_LEN);

    /* Encode Presentation format fields */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->format);
    pos += 1;

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->exponent);
    pos += 1;

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->unit);
    pos += 2;

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->name_space);
    pos += 1;

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->description);

    /* Update length */
    p_gatt_value->value_len = BLE_AIOC_ANALOG_0_CHAR_PRESENTATION_FORMAT_LEN;

    return BLE_SUCCESS;
}

static const st_ble_servc_desc_info_t gs_analog_0_char_presentation_format ={
    .uuid_16     = BLE_AIOC_ANALOG_0_CHAR_PRESENTATION_FORMAT_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(st_ble_aioc_analog_0_char_presentation_format_t),
    .db_size     = BLE_AIOC_ANALOG_0_CHAR_PRESENTATION_FORMAT_LEN,
    .desc_idx    = BLE_AIOC_ANALOG_0_CHAR_PRESENTATION_FORMAT_IDX,
    .p_attr_hdls = gs_analog_0_char_presentation_format_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_st_ble_aioc_analog_0_char_presentation_format_t,
    .encode      = (ble_servc_attr_encode_t)encode_st_ble_aioc_analog_0_char_presentation_format_t,
};

ble_status_t R_BLE_AIOC_ReadAnalog0CharPresentationFormat(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_analog_0_char_presentation_format, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Analog 0 Characteristic User Description descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Analog 0 characteristic descriptors attribute handles */
static uint16_t gs_analog_0_char_user_description_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_analog_0_char_user_description ={
    .uuid_16     = BLE_AIOC_ANALOG_0_CHAR_USER_DESCRIPTION_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint8_t),
    .db_size     = BLE_AIOC_ANALOG_0_CHAR_USER_DESCRIPTION_LEN,
    .desc_idx    = BLE_AIOC_ANALOG_0_CHAR_USER_DESCRIPTION_IDX,
    .p_attr_hdls = gs_analog_0_char_user_description_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_allcopy,
    .encode      = (ble_servc_attr_encode_t)encode_allcopy,
};

ble_status_t R_BLE_AIOC_WriteAnalog0CharUserDescription(uint16_t conn_hdl, const st_ble_seq_data_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc_with_Size(&gs_analog_0_char_user_description, conn_hdl, p_value);
}

ble_status_t R_BLE_AIOC_ReadAnalog0CharUserDescription(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_analog_0_char_user_description, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Analog 0 Characteristic Extended Properties descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Analog 0 characteristic descriptors attribute handles */
static uint16_t gs_analog_0_char_extended_properties_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_analog_0_char_extended_properties ={
    .uuid_16     = BLE_AIOC_ANALOG_0_CHAR_EXTENDED_PROPERTIES_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint16_t),
    .db_size     = BLE_AIOC_ANALOG_0_CHAR_EXTENDED_PROPERTIES_LEN,
    .desc_idx    = BLE_AIOC_ANALOG_0_CHAR_EXTENDED_PROPERTIES_IDX,
    .p_attr_hdls = gs_analog_0_char_extended_properties_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_AIOC_ReadAnalog0CharExtendedProperties(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_analog_0_char_extended_properties, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Analog 0 Value Trigger Setting descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Analog 0 characteristic descriptors attribute handles */
static uint16_t gs_analog_0_val_trigger_setting_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************
 * Function Name: decode_st_ble_aioc_analog_0_val_trigger_setting_t
 * Description  : This function converts descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - Pointer to the characteristic value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_aioc_analog_0_val_trigger_setting_t(st_ble_aioc_analog_0_val_trigger_setting_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    /* Check the length */
    if (BLE_AIOC_ANALOG_0_VAL_TRIGGER_SETTING_LEN < p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Copy the condition byte */
    uint8_t condition = p_gatt_value->p_value[pos];


    /* Check for Supported condition */
    if ((BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_NO_VALUE_TRIGGER < condition) ||
        (BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_MASK_THEN_COMPARE == condition))
    {
        return BLE_AIOC_TRIGGER_CONDITION_VALUE_NOT_SUPPORTED_ERROR;
    }

    BT_UNPACK_LE_1_BYTE(&p_app_value->condition, &p_gatt_value->p_value[pos]);
    pos += 1;

    if ((BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_CROSSED_A_BOUNDRY == condition) ||
        (BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_ON_THE_BOUNDRY == condition) ||
        (BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_VALUE_CHANGED_MORE_THAN_SETTABLE == condition))
    {
        /* Check for Supported condition */
        BT_UNPACK_LE_2_BYTE(&p_app_value->analog_value, &p_gatt_value->p_value[pos]);
        pos += 2;
    }
    else if ((BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_INSIDE_AND_OUTSIDE_THE_BOUNDRIES == condition) ||
        (BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_ON_THE_BOUNDRIES == condition))
    {
        BT_UNPACK_LE_2_BYTE(&p_app_value->analog_interval_value1, &p_gatt_value->p_value[pos]);
        pos += 2;
        BT_UNPACK_LE_2_BYTE(&p_app_value->analog_interval_value2, &p_gatt_value->p_value[pos]);
        pos += 2;
    }
    else
    {
        /* Do Nothing */
    }

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_st_ble_aioc_analog_0_val_trigger_setting_t
 * Description  : This function converts characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value  - Pointer to the characteristic  value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_aioc_analog_0_val_trigger_setting_t(const st_ble_aioc_analog_0_val_trigger_setting_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_AIOC_ANALOG_0_VAL_TRIGGER_SETTING_LEN);

    /* Encode value trigger setting fields */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->condition);
    pos += 1;

    if ((BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_CROSSED_A_BOUNDRY == p_app_value->condition) || 
        (BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_ON_THE_BOUNDRY == p_app_value->condition) ||
        (BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_VALUE_CHANGED_MORE_THAN_SETTABLE == p_app_value->condition))
    {
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->analog_value);
        pos += 2;
    }
    else if ((BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_INSIDE_AND_OUTSIDE_THE_BOUNDRIES == p_app_value->condition) ||
        (BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_ON_THE_BOUNDRIES == p_app_value->condition))
    {
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->analog_interval_value1);
        pos += 2;
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->analog_interval_value2);
        pos += 2;
    }
    else
    {
        /* Do Nothing */
    }

    /* Update length */
    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

static const st_ble_servc_desc_info_t gs_analog_0_val_trigger_setting ={
    .uuid_16     = BLE_AIOC_ANALOG_0_VAL_TRIGGER_SETTING_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(st_ble_aioc_analog_0_val_trigger_setting_t),
    .db_size     = BLE_AIOC_ANALOG_0_VAL_TRIGGER_SETTING_LEN,
    .desc_idx    = BLE_AIOC_ANALOG_0_VAL_TRIGGER_SETTING_IDX,
    .p_attr_hdls = gs_analog_0_val_trigger_setting_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_st_ble_aioc_analog_0_val_trigger_setting_t,
    .encode      = (ble_servc_attr_encode_t)encode_st_ble_aioc_analog_0_val_trigger_setting_t,
};

ble_status_t R_BLE_AIOC_WriteAnalog0ValTriggerSetting(uint16_t conn_hdl, const st_ble_aioc_analog_0_val_trigger_setting_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_analog_0_val_trigger_setting, conn_hdl, p_value);
}

ble_status_t R_BLE_AIOC_ReadAnalog0ValTriggerSetting(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_analog_0_val_trigger_setting, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Analog 0 Time Trigger Setting descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Analog 0 characteristic descriptors attribute handles */
static uint16_t gs_analog_0_time_trigger_setting_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************
 * Function Name: decode_st_ble_aioc_analog_0_time_trigger_setting_t
 * Description  : This function converts descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - Pointer to the characteristic value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_aioc_analog_0_time_trigger_setting_t(st_ble_aioc_analog_0_time_trigger_setting_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    /* check the length */
    if (BLE_AIOC_ANALOG_0_TIME_TRIGGER_SETTING_LEN < p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Copy the condition byte */
    uint8_t condition = p_gatt_value->p_value[pos];


    /* Check for Supported condition */
    if (BLE_AIOC_TIME_TRIGGER_CHANGED_MORE_OFTEN < condition)
    {
        return BLE_AIOC_TRIGGER_CONDITION_VALUE_NOT_SUPPORTED_ERROR;
    }

    memset(p_app_value, 0x00, sizeof(st_ble_aioc_analog_0_time_trigger_setting_t));

    BT_UNPACK_LE_1_BYTE(&p_app_value->condition, &p_gatt_value->p_value[pos]);
    pos += 1;

    if ((BLE_AIOC_TIME_TRIGGER_INDICATES_OR_NOTIFIES_UNCONDITIONALLY == condition) ||
        (BLE_AIOC_TIME_TRIGGER_NOT_INDICATES_OR_NOTIFIES_OFTEN == condition))
    {
        BT_UNPACK_LE_3_BYTE(&p_app_value->time_interval_value, &p_gatt_value->p_value[pos]);
        pos += 3;
    }

    if (BLE_AIOC_TIME_TRIGGER_CHANGED_MORE_OFTEN == condition)
    {
        BT_UNPACK_LE_2_BYTE(&p_app_value->count_value, &p_gatt_value->p_value[pos]);
    }

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_st_ble_aioc_analog_0_time_trigger_setting_t
 * Description  : This function converts characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value  - Pointer to the characteristic  value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_aioc_analog_0_time_trigger_setting_t(const st_ble_aioc_analog_0_time_trigger_setting_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    int8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_AIOC_ANALOG_0_TIME_TRIGGER_SETTING_LEN);

    /* Encode Time trigger setting fields */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->condition);
    pos += 1;

    if ((BLE_AIOC_TIME_TRIGGER_INDICATES_OR_NOTIFIES_UNCONDITIONALLY == p_app_value->condition) ||
        (BLE_AIOC_TIME_TRIGGER_NOT_INDICATES_OR_NOTIFIES_OFTEN == p_app_value->condition))
    {
        BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], &p_app_value->time_interval_value);
        pos += 3;
    }

    if (BLE_AIOC_TIME_TRIGGER_CHANGED_MORE_OFTEN == p_app_value->condition)
    {
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->count_value);
        pos += 2;
    }

    /* Update length */
    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}
static const st_ble_servc_desc_info_t gs_analog_0_time_trigger_setting ={
    .uuid_16     = BLE_AIOC_ANALOG_0_TIME_TRIGGER_SETTING_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(st_ble_aioc_analog_0_time_trigger_setting_t),
    .db_size     = BLE_AIOC_ANALOG_0_TIME_TRIGGER_SETTING_LEN,
    .desc_idx    = BLE_AIOC_ANALOG_0_TIME_TRIGGER_SETTING_IDX,
    .p_attr_hdls = gs_analog_0_time_trigger_setting_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_st_ble_aioc_analog_0_time_trigger_setting_t,
    .encode      = (ble_servc_attr_encode_t)encode_st_ble_aioc_analog_0_time_trigger_setting_t,
};

ble_status_t R_BLE_AIOC_WriteAnalog0TimeTriggerSetting(uint16_t conn_hdl, const st_ble_aioc_analog_0_time_trigger_setting_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_analog_0_time_trigger_setting, conn_hdl, p_value);
}

ble_status_t R_BLE_AIOC_ReadAnalog0TimeTriggerSetting(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_analog_0_time_trigger_setting, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Analog 0 Valid Range descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Analog 0 characteristic descriptors attribute handles */
static uint16_t gs_analog_0_valid_range_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************
 * Function Name: decode_st_ble_aioc_analog_0_valid_range_t
 * Description  : This function converts descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - Pointer to the characteristic value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_aioc_analog_0_valid_range_t(st_ble_aioc_analog_0_valid_range_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    /* Check the length */
    if (BLE_AIOC_ANALOG_0_VALID_RANGE_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Decode valid range fields */
    BT_UNPACK_LE_2_BYTE(&p_app_value->lower_inclusive_value, &p_gatt_value->p_value[pos]);
    pos += 2;

    BT_UNPACK_LE_2_BYTE(&p_app_value->upper_inclusive_value, &p_gatt_value->p_value[pos]);

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_st_ble_aioc_analog_0_valid_range_t
 * Description  : This function converts characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value  - Pointer to the characteristic  value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_aioc_analog_0_valid_range_t(const st_ble_aioc_analog_0_valid_range_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_AIOC_ANALOG_0_VALID_RANGE_LEN);

    /* Encode valid range fields */
    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->lower_inclusive_value);
    pos += 2;

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->upper_inclusive_value);

    /* Update length */
    p_gatt_value->value_len = BLE_AIOC_ANALOG_0_VALID_RANGE_LEN;

    return BLE_SUCCESS;
}

static const st_ble_servc_desc_info_t gs_analog_0_valid_range ={
    .uuid_16     = BLE_AIOC_ANALOG_0_VALID_RANGE_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(st_ble_aioc_analog_0_valid_range_t),
    .db_size     = BLE_AIOC_ANALOG_0_VALID_RANGE_LEN,
    .desc_idx    = BLE_AIOC_ANALOG_0_VALID_RANGE_IDX,
    .p_attr_hdls = gs_analog_0_valid_range_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_st_ble_aioc_analog_0_valid_range_t,
    .encode      = (ble_servc_attr_encode_t)encode_st_ble_aioc_analog_0_valid_range_t,
};

ble_status_t R_BLE_AIOC_ReadAnalog0ValidRange(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_analog_0_valid_range, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Analog 0 Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Analog 0 characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_analog_0_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

/* Analog 0 characteristic descriptor definition */
static const st_ble_servc_desc_info_t *gspp_analog_0_descs[] = {
    &gs_analog_0_cli_cnfg,
    &gs_analog_0_char_presentation_format,
    &gs_analog_0_char_user_description,
    &gs_analog_0_char_extended_properties,
    &gs_analog_0_val_trigger_setting,
    &gs_analog_0_time_trigger_setting,
    &gs_analog_0_valid_range,
};

/* Analog 0 characteristic definition */
static const st_ble_servc_char_info_t gs_analog_0_char = {
    .uuid_16      = BLE_AIOC_ANALOG_0_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(int16_t),
    .db_size      = BLE_AIOC_ANALOG_0_LEN,
    .char_idx     = BLE_AIOC_ANALOG_0_IDX,
    .p_attr_hdls  = gs_analog_0_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_int16_t,
    .encode       = (ble_servc_attr_encode_t)encode_int16_t,
    .num_of_descs = ARRAY_SIZE(gspp_analog_0_descs),
    .pp_descs     = gspp_analog_0_descs,
};

ble_status_t R_BLE_AIOC_WriteAnalog0(uint16_t conn_hdl, const int16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteChar(&gs_analog_0_char, conn_hdl, p_value);
}

ble_status_t R_BLE_AIOC_WriteAnalog0WithoutRsp(uint16_t conn_hdl, const int16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteCmdChar(&gs_analog_0_char, conn_hdl, p_value);
}

ble_status_t R_BLE_AIOC_ReadAnalog0(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_analog_0_char, conn_hdl);
}

void R_BLE_AIOC_GetAnalog0AttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_aioc_analog_0_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_analog_0_char_ranges[conn_idx];
    p_hdl->cli_cnfg_desc_hdl = gs_analog_0_cli_cnfg_desc_hdls[conn_idx];
    p_hdl->char_presentation_format_desc_hdl = gs_analog_0_char_presentation_format_desc_hdls[conn_idx];
    p_hdl->char_user_description_desc_hdl = gs_analog_0_char_user_description_desc_hdls[conn_idx];
    p_hdl->char_extended_properties_desc_hdl = gs_analog_0_char_extended_properties_desc_hdls[conn_idx];
    p_hdl->val_trigger_setting_desc_hdl = gs_analog_0_val_trigger_setting_desc_hdls[conn_idx];
    p_hdl->time_trigger_setting_desc_hdl = gs_analog_0_time_trigger_setting_desc_hdls[conn_idx];
    p_hdl->valid_range_desc_hdl = gs_analog_0_valid_range_desc_hdls[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Analog 1 Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Analog 1 characteristic descriptors attribute handles */
static uint16_t gs_analog_1_cli_cnfg_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_analog_1_cli_cnfg ={
    .uuid_16     = BLE_AIOC_ANALOG_1_CLI_CNFG_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint16_t),
    .db_size     = BLE_AIOC_ANALOG_1_CLI_CNFG_LEN,
    .desc_idx    = BLE_AIOC_ANALOG_1_CLI_CNFG_IDX,
    .p_attr_hdls = gs_analog_1_cli_cnfg_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_AIOC_WriteAnalog1CliCnfg(uint16_t conn_hdl, const uint16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_analog_1_cli_cnfg, conn_hdl, p_value);
}

ble_status_t R_BLE_AIOC_ReadAnalog1CliCnfg(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_analog_1_cli_cnfg, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Analog 1 Characteristic Presentation Format descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Analog 1 characteristic descriptors attribute handles */
static uint16_t gs_analog_1_char_presentation_format_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************
 * Function Name: decode_st_ble_aioc_analog_1_char_presentation_format_t
 * Description  : This function converts descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - Pointer to the characteristic value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_aioc_analog_1_char_presentation_format_t(st_ble_aioc_analog_1_char_presentation_format_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    int pos = 0;

    /* Check the length */
    if (BLE_AIOC_ANALOG_1_CHAR_PRESENTATION_FORMAT_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Decode Presentation format fields */
    BT_UNPACK_LE_1_BYTE(&p_app_value->format, &p_gatt_value->p_value[pos]);
    pos += 1;

    BT_UNPACK_LE_1_BYTE(&p_app_value->exponent, &p_gatt_value->p_value[pos]);
    pos += 1;

    BT_UNPACK_LE_2_BYTE(&p_app_value->unit, &p_gatt_value->p_value[pos]);
    pos += 2;

    BT_UNPACK_LE_1_BYTE(&p_app_value->name_space, &p_gatt_value->p_value[pos]);
    pos += 1;

    BT_UNPACK_LE_2_BYTE(&p_app_value->description, &p_gatt_value->p_value[pos]);

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_st_ble_aioc_analog_1_char_presentation_format_t
 * Description  : This function converts characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value  - Pointer to the characteristic  value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_aioc_analog_1_char_presentation_format_t(const st_ble_aioc_analog_1_char_presentation_format_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_AIOC_ANALOG_1_CHAR_PRESENTATION_FORMAT_LEN);

    /* Encode Presentation format fields */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->format);
    pos += 1;

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->exponent);
    pos += 1;

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->unit);
    pos += 2;

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->name_space);
    pos += 1;

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->description);

    /* Update length */
    p_gatt_value->value_len = BLE_AIOC_ANALOG_1_CHAR_PRESENTATION_FORMAT_LEN;

    return BLE_SUCCESS;
}

static const st_ble_servc_desc_info_t gs_analog_1_char_presentation_format ={
    .uuid_16     = BLE_AIOC_ANALOG_1_CHAR_PRESENTATION_FORMAT_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(st_ble_aioc_analog_1_char_presentation_format_t),
    .db_size     = BLE_AIOC_ANALOG_1_CHAR_PRESENTATION_FORMAT_LEN,
    .desc_idx    = BLE_AIOC_ANALOG_1_CHAR_PRESENTATION_FORMAT_IDX,
    .p_attr_hdls = gs_analog_1_char_presentation_format_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_st_ble_aioc_analog_1_char_presentation_format_t,
    .encode      = (ble_servc_attr_encode_t)encode_st_ble_aioc_analog_1_char_presentation_format_t,
};

ble_status_t R_BLE_AIOC_ReadAnalog1CharPresentationFormat(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_analog_1_char_presentation_format, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Analog 1 Characteristic User Description descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Analog 1 characteristic descriptors attribute handles */
static uint16_t gs_analog_1_char_user_description_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_analog_1_char_user_description ={
    .uuid_16     = BLE_AIOC_ANALOG_1_CHAR_USER_DESCRIPTION_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint8_t),
    .db_size     = BLE_AIOC_ANALOG_1_CHAR_USER_DESCRIPTION_LEN,
    .desc_idx    = BLE_AIOC_ANALOG_1_CHAR_USER_DESCRIPTION_IDX,
    .p_attr_hdls = gs_analog_1_char_user_description_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_allcopy,
    .encode      = (ble_servc_attr_encode_t)encode_allcopy,
};

ble_status_t R_BLE_AIOC_WriteAnalog1CharUserDescription(uint16_t conn_hdl, const st_ble_seq_data_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc_with_Size(&gs_analog_1_char_user_description, conn_hdl, p_value);
}

ble_status_t R_BLE_AIOC_ReadAnalog1CharUserDescription(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_analog_1_char_user_description, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Analog 1 Characteristic Extended Properties descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Analog 1 characteristic descriptors attribute handles */
static uint16_t gs_analog_1_char_extended_properties_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_analog_1_char_extended_properties ={
    .uuid_16     = BLE_AIOC_ANALOG_1_CHAR_EXTENDED_PROPERTIES_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint16_t),
    .db_size     = BLE_AIOC_ANALOG_1_CHAR_EXTENDED_PROPERTIES_LEN,
    .desc_idx    = BLE_AIOC_ANALOG_1_CHAR_EXTENDED_PROPERTIES_IDX,
    .p_attr_hdls = gs_analog_1_char_extended_properties_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_AIOC_ReadAnalog1CharExtendedProperties(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_analog_1_char_extended_properties, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Analog 1 Value Trigger Setting descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Analog 1 characteristic descriptors attribute handles */
static uint16_t gs_analog_1_val_trigger_setting_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************
 * Function Name: decode_st_ble_aioc_analog_1_val_trigger_setting_t
 * Description  : This function converts descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - Pointer to the characteristic value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_aioc_analog_1_val_trigger_setting_t(st_ble_aioc_analog_1_val_trigger_setting_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    /* Check the length */
    if (BLE_AIOC_ANALOG_1_VAL_TRIGGER_SETTING_LEN < p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Copy the condition byte */
    uint8_t condition = p_gatt_value->p_value[pos];


    /* Check for Supported condition */
    if ((BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_NO_VALUE_TRIGGER < condition) ||
        (BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_MASK_THEN_COMPARE == condition))
    {
        return BLE_AIOC_TRIGGER_CONDITION_VALUE_NOT_SUPPORTED_ERROR;
    }

    BT_UNPACK_LE_1_BYTE(&p_app_value->condition, &p_gatt_value->p_value[pos]);
    pos += 1;

    if ((BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_CROSSED_A_BOUNDRY == condition) ||
        (BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_ON_THE_BOUNDRY == condition) ||
        (BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_VALUE_CHANGED_MORE_THAN_SETTABLE == condition))
    {
        /* Check for Supported condition */
        BT_UNPACK_LE_2_BYTE(&p_app_value->analog_value, &p_gatt_value->p_value[pos]);
        pos += 2;
    }
    else if ((BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_INSIDE_AND_OUTSIDE_THE_BOUNDRIES == condition) ||
        (BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_ON_THE_BOUNDRIES == condition))
    {
        BT_UNPACK_LE_2_BYTE(&p_app_value->analog_interval_value1, &p_gatt_value->p_value[pos]);
        pos += 2;
        BT_UNPACK_LE_2_BYTE(&p_app_value->analog_interval_value2, &p_gatt_value->p_value[pos]);
        pos += 2;
    }
    else
    {
        /* Do Nothing */
    }

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_st_ble_aioc_analog_1_value_trigger_setting_t
 * Description  : This function converts characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value  - Pointer to the characteristic  value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_aioc_analog_1_val_trigger_setting_t(const st_ble_aioc_analog_1_val_trigger_setting_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_AIOC_ANALOG_1_VAL_TRIGGER_SETTING_LEN);

    /* Encode value trigger setting fields */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->condition);
    pos += 1;

    if ((BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_CROSSED_A_BOUNDRY == p_app_value->condition) ||
        (BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_ON_THE_BOUNDRY == p_app_value->condition) ||
        (BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_VALUE_CHANGED_MORE_THAN_SETTABLE == p_app_value->condition))
    {
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->analog_value);
        pos += 2;
    }
    else if ((BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_INSIDE_AND_OUTSIDE_THE_BOUNDRIES == p_app_value->condition) ||
        (BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_ON_THE_BOUNDRIES == p_app_value->condition))
    {
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->analog_interval_value1);
        pos += 2;
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->analog_interval_value2);
        pos += 2;
    }
    else
    {
        /* Do Nothing */
    }

    /* Update length */
    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

static const st_ble_servc_desc_info_t gs_analog_1_val_trigger_setting ={
    .uuid_16     = BLE_AIOC_ANALOG_1_VAL_TRIGGER_SETTING_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(st_ble_aioc_analog_1_val_trigger_setting_t),
    .db_size     = BLE_AIOC_ANALOG_1_VAL_TRIGGER_SETTING_LEN,
    .desc_idx    = BLE_AIOC_ANALOG_1_VAL_TRIGGER_SETTING_IDX,
    .p_attr_hdls = gs_analog_1_val_trigger_setting_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_st_ble_aioc_analog_1_val_trigger_setting_t,
    .encode      = (ble_servc_attr_encode_t)encode_st_ble_aioc_analog_1_val_trigger_setting_t,
};

ble_status_t R_BLE_AIOC_WriteAnalog1ValTriggerSetting(uint16_t conn_hdl, const st_ble_aioc_analog_1_val_trigger_setting_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_analog_1_val_trigger_setting, conn_hdl, p_value);
}

ble_status_t R_BLE_AIOC_ReadAnalog1ValTriggerSetting(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_analog_1_val_trigger_setting, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Analog 1 Time Trigger Setting descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Analog 1 characteristic descriptors attribute handles */
static uint16_t gs_analog_1_time_trigger_setting_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************
 * Function Name: decode_st_ble_aioc_analog_1_time_trigger_setting_t
 * Description  : This function converts descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - Pointer to the characteristic value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_aioc_analog_1_time_trigger_setting_t(st_ble_aioc_analog_1_time_trigger_setting_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    /* check the length */
    if (BLE_AIOC_ANALOG_1_TIME_TRIGGER_SETTING_LEN < p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Copy the condition byte */
    uint8_t condition = p_gatt_value->p_value[pos];


    /* Check for Supported condition */
    if (BLE_AIOC_TIME_TRIGGER_CHANGED_MORE_OFTEN < condition)
    {
        return BLE_AIOC_TRIGGER_CONDITION_VALUE_NOT_SUPPORTED_ERROR;
    }

    memset(p_app_value, 0x00, sizeof(st_ble_aioc_analog_1_time_trigger_setting_t));

    BT_UNPACK_LE_1_BYTE(&p_app_value->condition, &p_gatt_value->p_value[pos]);
    pos += 1;

    if ((BLE_AIOC_TIME_TRIGGER_INDICATES_OR_NOTIFIES_UNCONDITIONALLY == condition) ||
        (BLE_AIOC_TIME_TRIGGER_NOT_INDICATES_OR_NOTIFIES_OFTEN == condition))
    {
        BT_UNPACK_LE_3_BYTE(&p_app_value->time_interval_value, &p_gatt_value->p_value[pos]);
        pos += 3;
    }

    if (BLE_AIOC_TIME_TRIGGER_CHANGED_MORE_OFTEN == condition)
    {
        BT_UNPACK_LE_2_BYTE(&p_app_value->count_value, &p_gatt_value->p_value[pos]);
    }

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_st_ble_aioc_analog_1_time_trigger_setting_t
 * Description  : This function converts characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value  - Pointer to the characteristic  value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_aioc_analog_1_time_trigger_setting_t(const st_ble_aioc_analog_1_time_trigger_setting_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    int8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_AIOC_ANALOG_1_TIME_TRIGGER_SETTING_LEN);

    /* Encode Time trigger setting fields */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->condition);
    pos += 1;

    if ((BLE_AIOC_TIME_TRIGGER_INDICATES_OR_NOTIFIES_UNCONDITIONALLY == p_app_value->condition) ||
        (BLE_AIOC_TIME_TRIGGER_NOT_INDICATES_OR_NOTIFIES_OFTEN == p_app_value->condition))
    {
        BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], &p_app_value->time_interval_value);
        pos += 3;
    }

    if (BLE_AIOC_TIME_TRIGGER_CHANGED_MORE_OFTEN == p_app_value->condition)
    {
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->count_value);
        pos += 2;
    }

    /* Update length */
    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

static const st_ble_servc_desc_info_t gs_analog_1_time_trigger_setting ={
    .uuid_16     = BLE_AIOC_ANALOG_1_TIME_TRIGGER_SETTING_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(st_ble_aioc_analog_1_time_trigger_setting_t),
    .db_size     = BLE_AIOC_ANALOG_1_TIME_TRIGGER_SETTING_LEN,
    .desc_idx    = BLE_AIOC_ANALOG_1_TIME_TRIGGER_SETTING_IDX,
    .p_attr_hdls = gs_analog_1_time_trigger_setting_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_st_ble_aioc_analog_1_time_trigger_setting_t,
    .encode      = (ble_servc_attr_encode_t)encode_st_ble_aioc_analog_1_time_trigger_setting_t,
};

ble_status_t R_BLE_AIOC_WriteAnalog1TimeTriggerSetting(uint16_t conn_hdl, const st_ble_aioc_analog_1_time_trigger_setting_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_analog_1_time_trigger_setting, conn_hdl, p_value);
}

ble_status_t R_BLE_AIOC_ReadAnalog1TimeTriggerSetting(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_analog_1_time_trigger_setting, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Analog 1 Valid Range descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Analog 1 characteristic descriptors attribute handles */
static uint16_t gs_analog_1_valid_range_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************
 * Function Name: decode_st_ble_aioc_analog_1_valid_range_t
 * Description  : This function converts descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - Pointer to the characteristic value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_aioc_analog_1_valid_range_t(st_ble_aioc_analog_1_valid_range_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    /* Check the length */
    if (BLE_AIOC_ANALOG_1_VALID_RANGE_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Decode valid range fields */
    BT_UNPACK_LE_2_BYTE(&p_app_value->lower_inclusive_value, &p_gatt_value->p_value[pos]);
    pos += 2;

    BT_UNPACK_LE_2_BYTE(&p_app_value->upper_inclusive_value, &p_gatt_value->p_value[pos]);

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_st_ble_aioc_analog_1_valid_range_t
 * Description  : This function converts characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value  - Pointer to the characteristic  value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_aioc_analog_1_valid_range_t(const st_ble_aioc_analog_1_valid_range_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_AIOC_ANALOG_1_VALID_RANGE_LEN);

    /* Encode valid range fields */
    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->lower_inclusive_value);
    pos += 2;

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->upper_inclusive_value);

    /* Update length */
    p_gatt_value->value_len = BLE_AIOC_ANALOG_1_VALID_RANGE_LEN;

    return BLE_SUCCESS;
}

static const st_ble_servc_desc_info_t gs_analog_1_valid_range ={
    .uuid_16     = BLE_AIOC_ANALOG_1_VALID_RANGE_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(st_ble_aioc_analog_1_valid_range_t),
    .db_size     = BLE_AIOC_ANALOG_1_VALID_RANGE_LEN,
    .desc_idx    = BLE_AIOC_ANALOG_1_VALID_RANGE_IDX,
    .p_attr_hdls = gs_analog_1_valid_range_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_st_ble_aioc_analog_1_valid_range_t,
    .encode      = (ble_servc_attr_encode_t)encode_st_ble_aioc_analog_1_valid_range_t,
};

ble_status_t R_BLE_AIOC_ReadAnalog1ValidRange(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_analog_1_valid_range, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Analog 1 Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Analog 1 characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_analog_1_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

/* Analog 1 characteristic descriptor definition */
static const st_ble_servc_desc_info_t *gspp_analog_1_descs[] = {
    &gs_analog_1_cli_cnfg,
    &gs_analog_1_char_presentation_format,
    &gs_analog_1_char_user_description,
    &gs_analog_1_char_extended_properties,
    &gs_analog_1_val_trigger_setting,
    &gs_analog_1_time_trigger_setting,
    &gs_analog_1_valid_range,
};

/* Analog 1 characteristic definition */
static const st_ble_servc_char_info_t gs_analog_1_char = {
    .uuid_16      = BLE_AIOC_ANALOG_1_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(int16_t),
    .db_size      = BLE_AIOC_ANALOG_1_LEN,
    .char_idx     = BLE_AIOC_ANALOG_1_IDX,
    .p_attr_hdls  = gs_analog_1_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_int16_t,
    .encode       = (ble_servc_attr_encode_t)encode_int16_t,
    .num_of_descs = ARRAY_SIZE(gspp_analog_1_descs),
    .pp_descs     = gspp_analog_1_descs,
};

ble_status_t R_BLE_AIOC_WriteAnalog1(uint16_t conn_hdl, const int16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteChar(&gs_analog_1_char, conn_hdl, p_value);
}

ble_status_t R_BLE_AIOC_WriteAnalog1WithoutRsp(uint16_t conn_hdl, const int16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteCmdChar(&gs_analog_1_char, conn_hdl, p_value);
}

ble_status_t R_BLE_AIOC_ReadAnalog1(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_analog_1_char, conn_hdl);
}

void R_BLE_AIOC_GetAnalog1AttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_aioc_analog_1_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_analog_1_char_ranges[conn_idx];
    p_hdl->cli_cnfg_desc_hdl = gs_analog_1_cli_cnfg_desc_hdls[conn_idx];
    p_hdl->char_presentation_format_desc_hdl = gs_analog_1_char_presentation_format_desc_hdls[conn_idx];
    p_hdl->char_user_description_desc_hdl = gs_analog_1_char_user_description_desc_hdls[conn_idx];
    p_hdl->char_extended_properties_desc_hdl = gs_analog_1_char_extended_properties_desc_hdls[conn_idx];
    p_hdl->val_trigger_setting_desc_hdl = gs_analog_1_val_trigger_setting_desc_hdls[conn_idx];
    p_hdl->time_trigger_setting_desc_hdl = gs_analog_1_time_trigger_setting_desc_hdls[conn_idx];
    p_hdl->valid_range_desc_hdl = gs_analog_1_valid_range_desc_hdls[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Analog 2 Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Analog 2 characteristic descriptors attribute handles */
static uint16_t gs_analog_2_cli_cnfg_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_analog_2_cli_cnfg ={
    .uuid_16     = BLE_AIOC_ANALOG_2_CLI_CNFG_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint16_t),
    .db_size     = BLE_AIOC_ANALOG_2_CLI_CNFG_LEN,
    .desc_idx    = BLE_AIOC_ANALOG_2_CLI_CNFG_IDX,
    .p_attr_hdls = gs_analog_2_cli_cnfg_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_AIOC_WriteAnalog2CliCnfg(uint16_t conn_hdl, const uint16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_analog_2_cli_cnfg, conn_hdl, p_value);
}

ble_status_t R_BLE_AIOC_ReadAnalog2CliCnfg(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_analog_2_cli_cnfg, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Analog 2 Characteristic Presentation Format descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Analog 2 characteristic descriptors attribute handles */
static uint16_t gs_analog_2_char_presentation_format_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************
 * Function Name: decode_st_ble_aioc_analog_2_char_presentation_format_t
 * Description  : This function converts descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - Pointer to the characteristic value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_aioc_analog_2_char_presentation_format_t(st_ble_aioc_analog_2_char_presentation_format_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    /* Check the length */
    if (BLE_AIOC_ANALOG_2_CHAR_PRESENTATION_FORMAT_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Decode Presentation format fields */
    BT_UNPACK_LE_1_BYTE(&p_app_value->format, &p_gatt_value->p_value[pos]);
    pos += 1;

    BT_UNPACK_LE_1_BYTE(&p_app_value->exponent, &p_gatt_value->p_value[pos]);
    pos += 1;

    BT_UNPACK_LE_2_BYTE(&p_app_value->unit, &p_gatt_value->p_value[pos]);
    pos += 2;

    BT_UNPACK_LE_1_BYTE(&p_app_value->name_space, &p_gatt_value->p_value[pos]);
    pos += 1;

    BT_UNPACK_LE_2_BYTE(&p_app_value->description, &p_gatt_value->p_value[pos]);

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_st_ble_aioc_analog_2_char_presentation_format_t
 * Description  : This function converts characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value  - Pointer to the characteristic  value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_aioc_analog_2_char_presentation_format_t(const st_ble_aioc_analog_2_char_presentation_format_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_AIOC_ANALOG_2_CHAR_PRESENTATION_FORMAT_LEN);

    /* Encode Presentation format fields */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->format);
    pos += 1;

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->exponent);
    pos += 1;

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->unit);
    pos += 2;

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->name_space);
    pos += 1;

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->description);

    /* Update length */
    p_gatt_value->value_len = BLE_AIOC_ANALOG_2_CHAR_PRESENTATION_FORMAT_LEN;

    return BLE_SUCCESS;
}

static const st_ble_servc_desc_info_t gs_analog_2_char_presentation_format ={
    .uuid_16     = BLE_AIOC_ANALOG_2_CHAR_PRESENTATION_FORMAT_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(st_ble_aioc_analog_2_char_presentation_format_t),
    .db_size     = BLE_AIOC_ANALOG_2_CHAR_PRESENTATION_FORMAT_LEN,
    .desc_idx    = BLE_AIOC_ANALOG_2_CHAR_PRESENTATION_FORMAT_IDX,
    .p_attr_hdls = gs_analog_2_char_presentation_format_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_st_ble_aioc_analog_2_char_presentation_format_t,
    .encode      = (ble_servc_attr_encode_t)encode_st_ble_aioc_analog_2_char_presentation_format_t,
};

ble_status_t R_BLE_AIOC_ReadAnalog2CharPresentationFormat(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_analog_2_char_presentation_format, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Analog 2 Characteristic User Description descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Analog 2 characteristic descriptors attribute handles */
static uint16_t gs_analog_2_char_user_description_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_analog_2_char_user_description ={
    .uuid_16     = BLE_AIOC_ANALOG_2_CHAR_USER_DESCRIPTION_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint8_t),
    .db_size     = BLE_AIOC_ANALOG_2_CHAR_USER_DESCRIPTION_LEN,
    .desc_idx    = BLE_AIOC_ANALOG_2_CHAR_USER_DESCRIPTION_IDX,
    .p_attr_hdls = gs_analog_2_char_user_description_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_allcopy,
    .encode      = (ble_servc_attr_encode_t)encode_allcopy,
};

ble_status_t R_BLE_AIOC_WriteAnalog2CharUserDescription(uint16_t conn_hdl, const st_ble_seq_data_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc_with_Size(&gs_analog_2_char_user_description, conn_hdl, p_value);
}

ble_status_t R_BLE_AIOC_ReadAnalog2CharUserDescription(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_analog_2_char_user_description, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Analog 2 Characteristic Extended Properties descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Analog 2 characteristic descriptors attribute handles */
static uint16_t gs_analog_2_char_extended_properties_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_analog_2_char_extended_properties ={
    .uuid_16     = BLE_AIOC_ANALOG_2_CHAR_EXTENDED_PROPERTIES_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint16_t),
    .db_size     = BLE_AIOC_ANALOG_2_CHAR_EXTENDED_PROPERTIES_LEN,
    .desc_idx    = BLE_AIOC_ANALOG_2_CHAR_EXTENDED_PROPERTIES_IDX,
    .p_attr_hdls = gs_analog_2_char_extended_properties_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_AIOC_ReadAnalog2CharExtendedProperties(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_analog_2_char_extended_properties, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Analog 2 Value Trigger Setting descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Analog 2 characteristic descriptors attribute handles */
static uint16_t gs_analog_2_val_trigger_setting_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************
 * Function Name: decode_st_ble_aioc_analog_2_val_trigger_setting_t
 * Description  : This function converts descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - Pointer to the characteristic value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_aioc_analog_2_val_trigger_setting_t(st_ble_aioc_analog_2_val_trigger_setting_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    /* Check the length */
    if (BLE_AIOC_ANALOG_2_VAL_TRIGGER_SETTING_LEN < p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Copy the condition byte */
    uint8_t condition = p_gatt_value->p_value[pos];


    /* Check for Supported condition */
    if ((BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_NO_VALUE_TRIGGER < condition) ||
        (BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_MASK_THEN_COMPARE == condition))
    {
        return BLE_AIOC_TRIGGER_CONDITION_VALUE_NOT_SUPPORTED_ERROR;
    }

    BT_UNPACK_LE_1_BYTE(&p_app_value->condition, &p_gatt_value->p_value[pos]);
    pos += 1;

    if ((BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_CROSSED_A_BOUNDRY == condition) ||
        (BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_ON_THE_BOUNDRY == condition) ||
        (BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_VALUE_CHANGED_MORE_THAN_SETTABLE == condition))
    {
        /* Check for Supported condition */
        BT_UNPACK_LE_2_BYTE(&p_app_value->analog_value, &p_gatt_value->p_value[pos]);
        pos += 2;
    }
    else if ((BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_INSIDE_AND_OUTSIDE_THE_BOUNDRIES == condition) ||
        (BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_ON_THE_BOUNDRIES == condition))
    {
        BT_UNPACK_LE_2_BYTE(&p_app_value->analog_interval_value1, &p_gatt_value->p_value[pos]);
        pos += 2;
        BT_UNPACK_LE_2_BYTE(&p_app_value->analog_interval_value2, &p_gatt_value->p_value[pos]);
        pos += 2;
    }
    else
    {
        /* Do Nothing */
    }

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_st_ble_aioc_analog_2_val_trigger_setting_t
 * Description  : This function converts characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value  - Pointer to the characteristic  value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_aioc_analog_2_val_trigger_setting_t(const st_ble_aioc_analog_2_val_trigger_setting_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_AIOC_ANALOG_2_VAL_TRIGGER_SETTING_LEN);

    /* Encode value trigger setting fields */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->condition);
    pos += 1;

    if ((BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_CROSSED_A_BOUNDRY == p_app_value->condition) ||
        (BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_ON_THE_BOUNDRY == p_app_value->condition) ||
        (BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_VALUE_CHANGED_MORE_THAN_SETTABLE == p_app_value->condition))
    {
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->analog_value);
        pos += 2;
    }
    else if ((BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_INSIDE_AND_OUTSIDE_THE_BOUNDRIES == p_app_value->condition) ||
        (BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_ON_THE_BOUNDRIES == p_app_value->condition))
    {
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->analog_interval_value1);
        pos += 2;
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->analog_interval_value2);
        pos += 2;
    }
    else
    {
        /* Do Nothing */
    }

    /* Update length */
    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

static const st_ble_servc_desc_info_t gs_analog_2_val_trigger_setting ={
    .uuid_16     = BLE_AIOC_ANALOG_2_VAL_TRIGGER_SETTING_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(st_ble_aioc_analog_2_val_trigger_setting_t),
    .db_size     = BLE_AIOC_ANALOG_2_VAL_TRIGGER_SETTING_LEN,
    .desc_idx    = BLE_AIOC_ANALOG_2_VAL_TRIGGER_SETTING_IDX,
    .p_attr_hdls = gs_analog_2_val_trigger_setting_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_st_ble_aioc_analog_2_val_trigger_setting_t,
    .encode      = (ble_servc_attr_encode_t)encode_st_ble_aioc_analog_2_val_trigger_setting_t,
};

ble_status_t R_BLE_AIOC_WriteAnalog2ValTriggerSetting(uint16_t conn_hdl, const st_ble_aioc_analog_2_val_trigger_setting_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_analog_2_val_trigger_setting, conn_hdl, p_value);
}

ble_status_t R_BLE_AIOC_ReadAnalog2ValTriggerSetting(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_analog_2_val_trigger_setting, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Analog 2 Time Trigger Setting descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Analog 2 characteristic descriptors attribute handles */
static uint16_t gs_analog_2_time_trigger_setting_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************
 * Function Name: decode_st_ble_aioc_analog_2_time_trigger_setting_t
 * Description  : This function converts descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - Pointer to the characteristic value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_aioc_analog_2_time_trigger_setting_t(st_ble_aioc_analog_2_time_trigger_setting_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    /* check the length */
    if (BLE_AIOC_ANALOG_2_TIME_TRIGGER_SETTING_LEN < p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Copy the condition byte */
    uint8_t condition = p_gatt_value->p_value[pos];


    /* Check for Supported condition */
    if (BLE_AIOC_TIME_TRIGGER_CHANGED_MORE_OFTEN < condition)
    {
        return BLE_AIOC_TRIGGER_CONDITION_VALUE_NOT_SUPPORTED_ERROR;
    }

    memset(p_app_value, 0x00, sizeof(st_ble_aioc_analog_2_time_trigger_setting_t));

    BT_UNPACK_LE_1_BYTE(&p_app_value->condition, &p_gatt_value->p_value[pos]);
    pos += 1;

    if ((BLE_AIOC_TIME_TRIGGER_INDICATES_OR_NOTIFIES_UNCONDITIONALLY == condition) ||
        (BLE_AIOC_TIME_TRIGGER_NOT_INDICATES_OR_NOTIFIES_OFTEN == condition))
    {
        BT_UNPACK_LE_3_BYTE(&p_app_value->time_interval_value, &p_gatt_value->p_value[pos]);
        pos += 3;
    }

    if (BLE_AIOC_TIME_TRIGGER_CHANGED_MORE_OFTEN == condition)
    {
        BT_UNPACK_LE_2_BYTE(&p_app_value->count_value, &p_gatt_value->p_value[pos]);
    }

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_st_ble_aioc_analog_2_time_trigger_setting_t
 * Description  : This function converts characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value  - Pointer to the characteristic  value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_aioc_analog_2_time_trigger_setting_t(const st_ble_aioc_analog_2_time_trigger_setting_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    int8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_AIOC_ANALOG_2_TIME_TRIGGER_SETTING_LEN);

    /* Encode Time trigger setting fields */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->condition);
    pos += 1;

    if ((BLE_AIOC_TIME_TRIGGER_INDICATES_OR_NOTIFIES_UNCONDITIONALLY == p_app_value->condition) ||
        (BLE_AIOC_TIME_TRIGGER_NOT_INDICATES_OR_NOTIFIES_OFTEN == p_app_value->condition))
    {
        BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], &p_app_value->time_interval_value);
        pos += 3;
    }

    if (BLE_AIOC_TIME_TRIGGER_CHANGED_MORE_OFTEN == p_app_value->condition)
    {
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->count_value);
        pos += 2;
    }

    /* Update length */
    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

static const st_ble_servc_desc_info_t gs_analog_2_time_trigger_setting ={
    .uuid_16     = BLE_AIOC_ANALOG_2_TIME_TRIGGER_SETTING_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(st_ble_aioc_analog_2_time_trigger_setting_t),
    .db_size     = BLE_AIOC_ANALOG_2_TIME_TRIGGER_SETTING_LEN,
    .desc_idx    = BLE_AIOC_ANALOG_2_TIME_TRIGGER_SETTING_IDX,
    .p_attr_hdls = gs_analog_2_time_trigger_setting_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_st_ble_aioc_analog_2_time_trigger_setting_t,
    .encode      = (ble_servc_attr_encode_t)encode_st_ble_aioc_analog_2_time_trigger_setting_t,
};

ble_status_t R_BLE_AIOC_WriteAnalog2TimeTriggerSetting(uint16_t conn_hdl, const st_ble_aioc_analog_2_time_trigger_setting_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_analog_2_time_trigger_setting, conn_hdl, p_value);
}

ble_status_t R_BLE_AIOC_ReadAnalog2TimeTriggerSetting(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_analog_2_time_trigger_setting, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Analog 2 Valid Range descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Analog 2 characteristic descriptors attribute handles */
static uint16_t gs_analog_2_valid_range_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************
 * Function Name: decode_st_ble_aioc_analog_2_valid_range_t
 * Description  : This function converts descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - Pointer to the characteristic value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_aioc_analog_2_valid_range_t(st_ble_aioc_analog_2_valid_range_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    /* Check the length */
    if (BLE_AIOC_ANALOG_2_VALID_RANGE_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Decode valid range fields */
    BT_UNPACK_LE_2_BYTE(&p_app_value->lower_inclusive_value, &p_gatt_value->p_value[pos]);
    pos += 2;

    BT_UNPACK_LE_2_BYTE(&p_app_value->upper_inclusive_value, &p_gatt_value->p_value[pos]);

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_st_ble_aioc_analog_2_valid_range_t
 * Description  : This function converts characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value  - Pointer to the characteristic  value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_aioc_analog_2_valid_range_t(const st_ble_aioc_analog_2_valid_range_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_AIOC_ANALOG_2_VALID_RANGE_LEN);

    /* Encode valid range fields */
    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->lower_inclusive_value);
    pos += 2;

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->upper_inclusive_value);

    /* Update length */
    p_gatt_value->value_len = BLE_AIOC_ANALOG_2_VALID_RANGE_LEN;

    return BLE_SUCCESS;
}

static const st_ble_servc_desc_info_t gs_analog_2_valid_range ={
    .uuid_16     = BLE_AIOC_ANALOG_2_VALID_RANGE_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(st_ble_aioc_analog_2_valid_range_t),
    .db_size     = BLE_AIOC_ANALOG_2_VALID_RANGE_LEN,
    .desc_idx    = BLE_AIOC_ANALOG_2_VALID_RANGE_IDX,
    .p_attr_hdls = gs_analog_2_valid_range_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_st_ble_aioc_analog_2_valid_range_t,
    .encode      = (ble_servc_attr_encode_t)encode_st_ble_aioc_analog_2_valid_range_t,
};

ble_status_t R_BLE_AIOC_ReadAnalog2ValidRange(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_analog_2_valid_range, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Analog 2 Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Analog 2 characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_analog_2_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

/* Analog 2 characteristic descriptor definition */
static const st_ble_servc_desc_info_t *gspp_analog_2_descs[] = {
    &gs_analog_2_cli_cnfg,
    &gs_analog_2_char_presentation_format,
    &gs_analog_2_char_user_description,
    &gs_analog_2_char_extended_properties,
    &gs_analog_2_val_trigger_setting,
    &gs_analog_2_time_trigger_setting,
    &gs_analog_2_valid_range,
};

/* Analog 2 characteristic definition */
static const st_ble_servc_char_info_t gs_analog_2_char = {
    .uuid_16      = BLE_AIOC_ANALOG_2_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(int16_t),
    .db_size      = BLE_AIOC_ANALOG_2_LEN,
    .char_idx     = BLE_AIOC_ANALOG_2_IDX,
    .p_attr_hdls  = gs_analog_2_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_int16_t,
    .encode       = (ble_servc_attr_encode_t)encode_int16_t,
    .num_of_descs = ARRAY_SIZE(gspp_analog_2_descs),
    .pp_descs     = gspp_analog_2_descs,
};

ble_status_t R_BLE_AIOC_WriteAnalog2(uint16_t conn_hdl, const int16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteChar(&gs_analog_2_char, conn_hdl, p_value);
}

ble_status_t R_BLE_AIOC_WriteAnalog2WithoutRsp(uint16_t conn_hdl, const int16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteCmdChar(&gs_analog_2_char, conn_hdl, p_value);
}

ble_status_t R_BLE_AIOC_ReadAnalog2(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_analog_2_char, conn_hdl);
}

void R_BLE_AIOC_GetAnalog2AttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_aioc_analog_2_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_analog_2_char_ranges[conn_idx];
    p_hdl->cli_cnfg_desc_hdl = gs_analog_2_cli_cnfg_desc_hdls[conn_idx];
    p_hdl->char_presentation_format_desc_hdl = gs_analog_2_char_presentation_format_desc_hdls[conn_idx];
    p_hdl->char_user_description_desc_hdl = gs_analog_2_char_user_description_desc_hdls[conn_idx];
    p_hdl->char_extended_properties_desc_hdl = gs_analog_2_char_extended_properties_desc_hdls[conn_idx];
    p_hdl->val_trigger_setting_desc_hdl = gs_analog_2_val_trigger_setting_desc_hdls[conn_idx];
    p_hdl->time_trigger_setting_desc_hdl = gs_analog_2_time_trigger_setting_desc_hdls[conn_idx];
    p_hdl->valid_range_desc_hdl = gs_analog_2_valid_range_desc_hdls[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Analog 3 Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Analog 3 characteristic descriptors attribute handles */
static uint16_t gs_analog_3_cli_cnfg_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_analog_3_cli_cnfg ={
    .uuid_16     = BLE_AIOC_ANALOG_3_CLI_CNFG_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint16_t),
    .db_size     = BLE_AIOC_ANALOG_3_CLI_CNFG_LEN,
    .desc_idx    = BLE_AIOC_ANALOG_3_CLI_CNFG_IDX,
    .p_attr_hdls = gs_analog_3_cli_cnfg_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_AIOC_WriteAnalog3CliCnfg(uint16_t conn_hdl, const uint16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_analog_3_cli_cnfg, conn_hdl, p_value);
}

ble_status_t R_BLE_AIOC_ReadAnalog3CliCnfg(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_analog_3_cli_cnfg, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Analog 3 Characteristic Presentation Format descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Analog 3 characteristic descriptors attribute handles */
static uint16_t gs_analog_3_char_presentation_format_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************
 * Function Name: decode_st_ble_aioc_analog_3_char_presentation_format_t
 * Description  : This function converts descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - Pointer to the characteristic value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_aioc_analog_3_char_presentation_format_t(st_ble_aioc_analog_3_char_presentation_format_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    /* Check the length */
    if (BLE_AIOC_ANALOG_3_CHAR_PRESENTATION_FORMAT_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Decode Presentation format fields */
    BT_UNPACK_LE_1_BYTE(&p_app_value->format, &p_gatt_value->p_value[pos]);
    pos += 1;

    BT_UNPACK_LE_1_BYTE(&p_app_value->exponent, &p_gatt_value->p_value[pos]);
    pos += 1;

    BT_UNPACK_LE_2_BYTE(&p_app_value->unit, &p_gatt_value->p_value[pos]);
    pos += 2;

    BT_UNPACK_LE_1_BYTE(&p_app_value->name_space, &p_gatt_value->p_value[pos]);
    pos += 1;

    BT_UNPACK_LE_2_BYTE(&p_app_value->description, &p_gatt_value->p_value[pos]);

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_st_ble_aioc_analog_3_char_presentation_format_t
 * Description  : This function converts characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value  - Pointer to the characteristic  value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_aioc_analog_3_char_presentation_format_t(const st_ble_aioc_analog_3_char_presentation_format_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_AIOC_ANALOG_3_CHAR_PRESENTATION_FORMAT_LEN);

    /* Encode Presentation format fields */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->format);
    pos += 1;

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->exponent);
    pos += 1;

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->unit);
    pos += 2;

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->name_space);
    pos += 1;

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->description);

    /* Update length */
    p_gatt_value->value_len = BLE_AIOC_ANALOG_3_CHAR_PRESENTATION_FORMAT_LEN;

    return BLE_SUCCESS;
}

static const st_ble_servc_desc_info_t gs_analog_3_char_presentation_format ={
    .uuid_16     = BLE_AIOC_ANALOG_3_CHAR_PRESENTATION_FORMAT_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(st_ble_aioc_analog_3_char_presentation_format_t),
    .db_size     = BLE_AIOC_ANALOG_3_CHAR_PRESENTATION_FORMAT_LEN,
    .desc_idx    = BLE_AIOC_ANALOG_3_CHAR_PRESENTATION_FORMAT_IDX,
    .p_attr_hdls = gs_analog_3_char_presentation_format_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_st_ble_aioc_analog_3_char_presentation_format_t,
    .encode      = (ble_servc_attr_encode_t)encode_st_ble_aioc_analog_3_char_presentation_format_t,
};

ble_status_t R_BLE_AIOC_ReadAnalog3CharPresentationFormat(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_analog_3_char_presentation_format, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Analog 3 Characteristic User Description descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Analog 3 characteristic descriptors attribute handles */
static uint16_t gs_analog_3_char_user_description_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_analog_3_char_user_description ={
    .uuid_16     = BLE_AIOC_ANALOG_3_CHAR_USER_DESCRIPTION_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint8_t),
    .db_size     = BLE_AIOC_ANALOG_3_CHAR_USER_DESCRIPTION_LEN,
    .desc_idx    = BLE_AIOC_ANALOG_3_CHAR_USER_DESCRIPTION_IDX,
    .p_attr_hdls = gs_analog_3_char_user_description_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_allcopy,
    .encode      = (ble_servc_attr_encode_t)encode_allcopy,
};

ble_status_t R_BLE_AIOC_WriteAnalog3CharUserDescription(uint16_t conn_hdl, const st_ble_seq_data_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc_with_Size(&gs_analog_3_char_user_description, conn_hdl, p_value);
}

ble_status_t R_BLE_AIOC_ReadAnalog3CharUserDescription(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_analog_3_char_user_description, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Analog 3 Characteristic Extended Properties descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Analog 3 characteristic descriptors attribute handles */
static uint16_t gs_analog_3_char_extended_properties_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_analog_3_char_extended_properties ={
    .uuid_16     = BLE_AIOC_ANALOG_3_CHAR_EXTENDED_PROPERTIES_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint16_t),
    .db_size     = BLE_AIOC_ANALOG_3_CHAR_EXTENDED_PROPERTIES_LEN,
    .desc_idx    = BLE_AIOC_ANALOG_3_CHAR_EXTENDED_PROPERTIES_IDX,
    .p_attr_hdls = gs_analog_3_char_extended_properties_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_AIOC_ReadAnalog3CharExtendedProperties(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_analog_3_char_extended_properties, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Analog 3 Value Trigger Setting descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Analog 3 characteristic descriptors attribute handles */
static uint16_t gs_analog_3_val_trigger_setting_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************
 * Function Name: decode_st_ble_aioc_analog_3_val_trigger_setting_t
 * Description  : This function converts descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - Pointer to the characteristic value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_aioc_analog_3_val_trigger_setting_t(st_ble_aioc_analog_3_val_trigger_setting_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    /* Check the length */
    if (BLE_AIOC_ANALOG_3_VAL_TRIGGER_SETTING_LEN < p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Copy the condition byte */
    uint8_t condition = p_gatt_value->p_value[pos];


    /* Check for Supported condition */
    if ((BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_NO_VALUE_TRIGGER < condition) ||
        (BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_MASK_THEN_COMPARE == condition))
    {
        return BLE_AIOC_TRIGGER_CONDITION_VALUE_NOT_SUPPORTED_ERROR;
    }

    BT_UNPACK_LE_1_BYTE(&p_app_value->condition, &p_gatt_value->p_value[pos]);
    pos += 1;

    if ((BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_CROSSED_A_BOUNDRY == condition) ||
        (BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_ON_THE_BOUNDRY == condition) ||
        (BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_VALUE_CHANGED_MORE_THAN_SETTABLE == condition))
    {
        /* Check for Supported condition */
        BT_UNPACK_LE_2_BYTE(&p_app_value->analog_value, &p_gatt_value->p_value[pos]);
        pos += 2;
    }
    else if ((BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_INSIDE_AND_OUTSIDE_THE_BOUNDRIES == condition) ||
        (BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_ON_THE_BOUNDRIES == condition))
    {
        BT_UNPACK_LE_2_BYTE(&p_app_value->analog_interval_value1, &p_gatt_value->p_value[pos]);
        pos += 2;
        BT_UNPACK_LE_2_BYTE(&p_app_value->analog_interval_value2, &p_gatt_value->p_value[pos]);
        pos += 2;
    }
    else
    {
        /* Do Nothing */
    }

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_st_ble_aioc_analog_3_val_trigger_setting_t
 * Description  : This function converts characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value  - Pointer to the characteristic  value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_aioc_analog_3_val_trigger_setting_t(const st_ble_aioc_analog_3_val_trigger_setting_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_AIOC_ANALOG_3_VAL_TRIGGER_SETTING_LEN);

    /* Encode value trigger setting fields */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->condition);
    pos += 1;

    if ((BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_CROSSED_A_BOUNDRY == p_app_value->condition) ||
        (BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_ON_THE_BOUNDRY == p_app_value->condition) ||
        (BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_VALUE_CHANGED_MORE_THAN_SETTABLE == p_app_value->condition))
    {
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->analog_value);
        pos += 2;
    }
    else if ((BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_INSIDE_AND_OUTSIDE_THE_BOUNDRIES == p_app_value->condition) ||
        (BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_ON_THE_BOUNDRIES == p_app_value->condition))
    {
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->analog_interval_value1);
        pos += 2;
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->analog_interval_value2);
        pos += 2;
    }
    else
    {
        /* Do Nothing */
    }

    /* Update length */
    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

static const st_ble_servc_desc_info_t gs_analog_3_val_trigger_setting ={
    .uuid_16     = BLE_AIOC_ANALOG_3_VAL_TRIGGER_SETTING_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(st_ble_aioc_analog_3_val_trigger_setting_t),
    .db_size     = BLE_AIOC_ANALOG_3_VAL_TRIGGER_SETTING_LEN,
    .desc_idx    = BLE_AIOC_ANALOG_3_VAL_TRIGGER_SETTING_IDX,
    .p_attr_hdls = gs_analog_3_val_trigger_setting_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_st_ble_aioc_analog_3_val_trigger_setting_t,
    .encode      = (ble_servc_attr_encode_t)encode_st_ble_aioc_analog_3_val_trigger_setting_t,
};

ble_status_t R_BLE_AIOC_WriteAnalog3ValTriggerSetting(uint16_t conn_hdl, const st_ble_aioc_analog_3_val_trigger_setting_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_analog_3_val_trigger_setting, conn_hdl, p_value);
}

ble_status_t R_BLE_AIOC_ReadAnalog3ValTriggerSetting(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_analog_3_val_trigger_setting, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Analog 3 Time Trigger Setting descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Analog 3 characteristic descriptors attribute handles */
static uint16_t gs_analog_3_time_trigger_setting_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************
 * Function Name: decode_st_ble_aioc_analog_3_time_trigger_setting_t
 * Description  : This function converts descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - Pointer to the characteristic value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_aioc_analog_3_time_trigger_setting_t(st_ble_aioc_analog_3_time_trigger_setting_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    /* check the length */
    if (BLE_AIOC_ANALOG_3_TIME_TRIGGER_SETTING_LEN < p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Copy the condition byte */
    uint8_t condition = p_gatt_value->p_value[pos];


    /* Check for Supported condition */
    if (BLE_AIOC_TIME_TRIGGER_CHANGED_MORE_OFTEN < condition)
    {
        return BLE_AIOC_TRIGGER_CONDITION_VALUE_NOT_SUPPORTED_ERROR;
    }

    memset(p_app_value, 0x00, sizeof(st_ble_aioc_analog_3_time_trigger_setting_t));

    BT_UNPACK_LE_1_BYTE(&p_app_value->condition, &p_gatt_value->p_value[pos]);
    pos += 1;

    if ((BLE_AIOC_TIME_TRIGGER_INDICATES_OR_NOTIFIES_UNCONDITIONALLY == condition) ||
        (BLE_AIOC_TIME_TRIGGER_NOT_INDICATES_OR_NOTIFIES_OFTEN == condition))
    {
        BT_UNPACK_LE_3_BYTE(&p_app_value->time_interval_value, &p_gatt_value->p_value[pos]);
        pos += 3;
    }

    if (BLE_AIOC_TIME_TRIGGER_CHANGED_MORE_OFTEN == condition)
    {
        BT_UNPACK_LE_2_BYTE(&p_app_value->count_value, &p_gatt_value->p_value[pos]);
    }

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_st_ble_aioc_analog_3_time_trigger_setting_t
 * Description  : This function converts characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value  - Pointer to the characteristic  value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_aioc_analog_3_time_trigger_setting_t(const st_ble_aioc_analog_3_time_trigger_setting_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    int8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_AIOC_ANALOG_3_TIME_TRIGGER_SETTING_LEN);

    /* Encode Time trigger setting fields */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->condition);
    pos += 1;

    if ((BLE_AIOC_TIME_TRIGGER_INDICATES_OR_NOTIFIES_UNCONDITIONALLY == p_app_value->condition) ||
        (BLE_AIOC_TIME_TRIGGER_NOT_INDICATES_OR_NOTIFIES_OFTEN == p_app_value->condition))
    {
        BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], &p_app_value->time_interval_value);
        pos += 3;
    }

    if (BLE_AIOC_TIME_TRIGGER_CHANGED_MORE_OFTEN == p_app_value->condition)
    {
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->count_value);
        pos += 2;
    }

    /* Update length */
    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

static const st_ble_servc_desc_info_t gs_analog_3_time_trigger_setting ={
    .uuid_16     = BLE_AIOC_ANALOG_3_TIME_TRIGGER_SETTING_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(st_ble_aioc_analog_3_time_trigger_setting_t),
    .db_size     = BLE_AIOC_ANALOG_3_TIME_TRIGGER_SETTING_LEN,
    .desc_idx    = BLE_AIOC_ANALOG_3_TIME_TRIGGER_SETTING_IDX,
    .p_attr_hdls = gs_analog_3_time_trigger_setting_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_st_ble_aioc_analog_3_time_trigger_setting_t,
    .encode      = (ble_servc_attr_encode_t)encode_st_ble_aioc_analog_3_time_trigger_setting_t,
};

ble_status_t R_BLE_AIOC_WriteAnalog3TimeTriggerSetting(uint16_t conn_hdl, const st_ble_aioc_analog_3_time_trigger_setting_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_analog_3_time_trigger_setting, conn_hdl, p_value);
}

ble_status_t R_BLE_AIOC_ReadAnalog3TimeTriggerSetting(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_analog_3_time_trigger_setting, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Analog 3 Valid Range descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Analog 3 characteristic descriptors attribute handles */
static uint16_t gs_analog_3_valid_range_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************
 * Function Name: decode_st_ble_aioc_analog_3_valid_range_t
 * Description  : This function converts descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - Pointer to the characteristic value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_aioc_analog_3_valid_range_t(st_ble_aioc_analog_3_valid_range_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    /* Check the length */
    if (BLE_AIOC_ANALOG_3_VALID_RANGE_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Decode valid range fields */
    BT_UNPACK_LE_2_BYTE(&p_app_value->lower_inclusive_value, &p_gatt_value->p_value[pos]);
    pos += 2;

    BT_UNPACK_LE_2_BYTE(&p_app_value->upper_inclusive_value, &p_gatt_value->p_value[pos]);

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_st_ble_aioc_analog_3_valid_range_t
 * Description  : This function converts characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value  - Pointer to the characteristic  value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_aioc_analog_3_valid_range_t(const st_ble_aioc_analog_3_valid_range_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_AIOC_ANALOG_3_VALID_RANGE_LEN);

    /* Encode valid range fields */
    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->lower_inclusive_value);
    pos += 2;

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->upper_inclusive_value);

    /* Update length */
    p_gatt_value->value_len = BLE_AIOC_ANALOG_3_VALID_RANGE_LEN;

    return BLE_SUCCESS;
}

static const st_ble_servc_desc_info_t gs_analog_3_valid_range ={
    .uuid_16     = BLE_AIOC_ANALOG_3_VALID_RANGE_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(st_ble_aioc_analog_3_valid_range_t),
    .db_size     = BLE_AIOC_ANALOG_3_VALID_RANGE_LEN,
    .desc_idx    = BLE_AIOC_ANALOG_3_VALID_RANGE_IDX,
    .p_attr_hdls = gs_analog_3_valid_range_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_st_ble_aioc_analog_3_valid_range_t,
    .encode      = (ble_servc_attr_encode_t)encode_st_ble_aioc_analog_3_valid_range_t,
};

ble_status_t R_BLE_AIOC_ReadAnalog3ValidRange(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_analog_3_valid_range, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Analog 3 Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Analog 3 characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_analog_3_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

/* Analog 3 characteristic descriptor definition */
static const st_ble_servc_desc_info_t *gspp_analog_3_descs[] = {
    &gs_analog_3_cli_cnfg,
    &gs_analog_3_char_presentation_format,
    &gs_analog_3_char_user_description,
    &gs_analog_3_char_extended_properties,
    &gs_analog_3_val_trigger_setting,
    &gs_analog_3_time_trigger_setting,
    &gs_analog_3_valid_range,
};

/* Analog 3 characteristic definition */
static const st_ble_servc_char_info_t gs_analog_3_char = {
    .uuid_16      = BLE_AIOC_ANALOG_3_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(int16_t),
    .db_size      = BLE_AIOC_ANALOG_3_LEN,
    .char_idx     = BLE_AIOC_ANALOG_3_IDX,
    .p_attr_hdls  = gs_analog_3_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_int16_t,
    .encode       = (ble_servc_attr_encode_t)encode_int16_t,
    .num_of_descs = ARRAY_SIZE(gspp_analog_3_descs),
    .pp_descs     = gspp_analog_3_descs,
};

ble_status_t R_BLE_AIOC_WriteAnalog3(uint16_t conn_hdl, const int16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteChar(&gs_analog_3_char, conn_hdl, p_value);
}

ble_status_t R_BLE_AIOC_WriteAnalog3WithoutRsp(uint16_t conn_hdl, const int16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteCmdChar(&gs_analog_3_char, conn_hdl, p_value);
}

ble_status_t R_BLE_AIOC_ReadAnalog3(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_analog_3_char, conn_hdl);
}

void R_BLE_AIOC_GetAnalog3AttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_aioc_analog_3_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_analog_3_char_ranges[conn_idx];
    p_hdl->cli_cnfg_desc_hdl = gs_analog_3_cli_cnfg_desc_hdls[conn_idx];
    p_hdl->char_presentation_format_desc_hdl = gs_analog_3_char_presentation_format_desc_hdls[conn_idx];
    p_hdl->char_user_description_desc_hdl = gs_analog_3_char_user_description_desc_hdls[conn_idx];
    p_hdl->char_extended_properties_desc_hdl = gs_analog_3_char_extended_properties_desc_hdls[conn_idx];
    p_hdl->val_trigger_setting_desc_hdl = gs_analog_3_val_trigger_setting_desc_hdls[conn_idx];
    p_hdl->time_trigger_setting_desc_hdl = gs_analog_3_time_trigger_setting_desc_hdls[conn_idx];
    p_hdl->valid_range_desc_hdl = gs_analog_3_valid_range_desc_hdls[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Aggregate Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Aggregate characteristic descriptors attribute handles */
static uint16_t gs_aggregate_cli_cnfg_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_aggregate_cli_cnfg ={
    .uuid_16     = BLE_AIOC_AGGREGATE_CLI_CNFG_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint16_t),
    .db_size     = BLE_AIOC_AGGREGATE_CLI_CNFG_LEN,
    .desc_idx    = BLE_AIOC_AGGREGATE_CLI_CNFG_IDX,
    .p_attr_hdls = gs_aggregate_cli_cnfg_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_AIOC_WriteAggregateCliCnfg(uint16_t conn_hdl, const uint16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_aggregate_cli_cnfg, conn_hdl, p_value);
}

ble_status_t R_BLE_AIOC_ReadAggregateCliCnfg(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_aggregate_cli_cnfg, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Aggregate Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Aggregate characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_aggregate_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************
 * Function Name: decode_st_ble_aioc_aggregate_t
 * Description  : This function converts descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - Pointer to the characteristic value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_aioc_aggregate_t(st_ble_aioc_aggregate_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    /* Check the length */
    if (BLE_AIOC_AGGREGATE_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    BT_UNPACK_LE_2_BYTE(&p_app_value->input_bits0, &p_gatt_value->p_value[pos]);
    pos += 2;

    BT_UNPACK_LE_2_BYTE(&p_app_value->input_bits1, &p_gatt_value->p_value[pos]);
    pos += 2;

    BT_UNPACK_LE_2_BYTE(&p_app_value->analog_input0, &p_gatt_value->p_value[pos]);
    pos += 2;

    BT_UNPACK_LE_2_BYTE(&p_app_value->analog_input1, &p_gatt_value->p_value[pos]);
    pos += 2;

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_st_ble_aioc_aggregate_t
 * Description  : This function converts characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value  - Pointer to the characteristic  value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_aioc_aggregate_t(const st_ble_aioc_aggregate_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_AIOC_AGGREGATE_LEN);

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->input_bits0);
    pos += 2;

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->input_bits1);
    pos += 2;

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->analog_input0);
    pos += 2;

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->analog_input1);
    pos += 2;

    /* Update length */
    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

/* Aggregate characteristic descriptor definition */
static const st_ble_servc_desc_info_t *gspp_aggregate_descs[] = {
    &gs_aggregate_cli_cnfg,
};

/* Aggregate characteristic definition */
static const st_ble_servc_char_info_t gs_aggregate_char = {
    .uuid_16      = BLE_AIOC_AGGREGATE_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_aioc_aggregate_t),
    .db_size      = BLE_AIOC_AGGREGATE_LEN,
    .char_idx     = BLE_AIOC_AGGREGATE_IDX,
    .p_attr_hdls  = gs_aggregate_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_aioc_aggregate_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_aioc_aggregate_t,
    .num_of_descs = ARRAY_SIZE(gspp_aggregate_descs),
    .pp_descs     = gspp_aggregate_descs,
};

ble_status_t R_BLE_AIOC_ReadAggregate(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_aggregate_char, conn_hdl);
}

void R_BLE_AIOC_GetAggregateAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_aioc_aggregate_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_aggregate_char_ranges[conn_idx];
    p_hdl->cli_cnfg_desc_hdl = gs_aggregate_cli_cnfg_desc_hdls[conn_idx];
}


/*----------------------------------------------------------------------------------------------------------------------
    Automation IO client
----------------------------------------------------------------------------------------------------------------------*/

/* Automation IO client attribute handles */
static st_ble_gatt_hdl_range_t gs_aioc_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_char_info_t *gspp_aioc_chars[] = {
    &gs_digital_0_char,
    &gs_digital_1_char,
    &gs_analog_0_char,
    &gs_analog_1_char,
    &gs_analog_2_char,
    &gs_analog_3_char,
    &gs_aggregate_char,
};

static st_ble_servc_info_t gs_client_info = {
    .pp_chars     = gspp_aioc_chars,
    .num_of_chars = ARRAY_SIZE(gspp_aioc_chars),
    .p_attr_hdls  = gs_aioc_ranges,
};

ble_status_t R_BLE_AIOC_Init(ble_servc_app_cb_t cb) // @suppress("API function naming")
{
    if (NULL == cb)
    {
        return BLE_ERR_INVALID_PTR;
    }

    gs_client_info.cb = cb;

    return R_BLE_SERVC_RegisterClient(&gs_client_info);
}

void R_BLE_AIOC_ServDiscCb(uint16_t conn_hdl, uint8_t serv_idx, uint16_t type, void *p_param) // @suppress("API function naming")
{
    R_BLE_SERVC_ServDiscCb(&gs_client_info, conn_hdl, serv_idx, type, p_param);
}

void R_BLE_AIOC_GetServAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_gatt_hdl_range_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    *p_hdl = gs_aioc_ranges[conn_idx];
}
