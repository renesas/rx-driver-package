/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_aioc.h
 * Version : 1.0
 * Description : The header file for Automation IO client.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 31.12.2999 1.00 First Release
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @file
 * @defgroup aioc Automation IO Service Client
 * @{
 * @ingroup profile
 * @brief   This is the client for the Automation IO Service.
 **********************************************************************************************************************/
#include "profile_cmn/r_ble_servc_if.h"

#ifndef R_BLE_AIOC_H
#define R_BLE_AIOC_H

/*----------------------------------------------------------------------------------------------------------------------
    Digital 0 Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_AIOC_DIGITAL_0_UUID (0x2A56)
#define BLE_AIOC_DIGITAL_0_LEN (2)
#define BLE_AIOC_DIGITAL_0_CLI_CNFG_UUID (0x2902)
#define BLE_AIOC_DIGITAL_0_CLI_CNFG_LEN (2)
#define BLE_AIOC_DIGITAL_0_CHAR_PRESENTATION_FORMAT_UUID (0x2904)
#define BLE_AIOC_DIGITAL_0_CHAR_PRESENTATION_FORMAT_LEN (7)
#define BLE_AIOC_DIGITAL_0_CHAR_USER_DESCRIPTION_UUID (0x2901)
#define BLE_AIOC_DIGITAL_0_CHAR_USER_DESCRIPTION_LEN (100)
#define BLE_AIOC_DIGITAL_0_CHAR_EXTENDED_PROPERTIES_UUID (0x2900)
#define BLE_AIOC_DIGITAL_0_CHAR_EXTENDED_PROPERTIES_LEN (2)
#define BLE_AIOC_DIGITAL_0_VAL_TRIGGER_SETTING_UUID (0x290A)
#define BLE_AIOC_DIGITAL_0_VAL_TRIGGER_SETTING_LEN (3)
#define BLE_AIOC_DIGITAL_0_TIME_TRIGGER_SETTING_UUID (0x290E)
#define BLE_AIOC_DIGITAL_0_TIME_TRIGGER_SETTING_LEN (4)
#define BLE_AIOC_DIGITAL_0_NUM_OF_DIGITALS_UUID (0x2909)
#define BLE_AIOC_DIGITAL_0_NUM_OF_DIGITALS_LEN (1)


/***************************************************************************//**
 * @brief Characteristic Presentation Format Format enumeration.
*******************************************************************************/
typedef enum {
    BLE_AIOC_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_BOOLEAN = 1, /**< Boolean */
    BLE_AIOC_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_2_BIT_INTEGER = 2, /**< unsigned 2-bit integer */
    BLE_AIOC_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_4_BIT_INTEGER = 3, /**< unsigned 4-bit integer */
    BLE_AIOC_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_8_BIT_INTEGER = 4, /**< unsigned 8-bit integer */
    BLE_AIOC_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_12_BIT_INTEGER = 5, /**< unsigned 12-bit integer */
    BLE_AIOC_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_16_BIT_INTEGER = 6, /**< unsigned 16-bit integer */
    BLE_AIOC_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_24_BIT_INTEGER = 7, /**< unsigned 24-bit integer */
    BLE_AIOC_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_32_BIT_INTEGER = 8, /**< unsigned 32-bit integer */
    BLE_AIOC_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_48_BIT_INTEGER = 9, /**< unsigned 48-bit integer */
    BLE_AIOC_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_64_BIT_INTEGER = 10, /**< unsigned 64-bit integer */
    BLE_AIOC_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_128_BIT_INTEGER = 11, /**< unsigned 128-bit integer */
    BLE_AIOC_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_8_BIT_INTEGER = 12, /**< signed 8-bit integer */
    BLE_AIOC_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_12_BIT_INTEGER = 13, /**< signed 12-bit integer */
    BLE_AIOC_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_16_BIT_INTEGER = 14, /**< signed 16-bit integer */
    BLE_AIOC_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_24_BIT_INTEGER = 15, /**< signed 24-bit integer */
    BLE_AIOC_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_32_BIT_INTEGER = 16, /**< signed 32-bit integer */
    BLE_AIOC_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_48_BIT_INTEGER = 17, /**< signed 48-bit integer */
    BLE_AIOC_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_64_BIT_INTEGER = 18, /**< signed 64-bit integer */
    BLE_AIOC_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_128_BIT_INTEGER = 19, /**< signed 128-bit integer */
    BLE_AIOC_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_IEEE_754_32_BIT_FLOATING_POINT = 20, /**< IEEE-754 32-bit floating point */
    BLE_AIOC_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_IEEE_754_64_BIT_FLOATING_POINT = 21, /**< IEEE-754 64-bit floating point */
    BLE_AIOC_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_IEEE_11073_16_BIT_SFLOAT = 22, /**< IEEE-11073 16-bit SFLOAT */
    BLE_AIOC_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_IEEE_11073_32_BIT_FLOAT = 23, /**< IEEE-11073 32-bit FLOAT */
    BLE_AIOC_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_IEEE_20601_FORMAT = 24, /**< IEEE-20601 format */
    BLE_AIOC_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_UTF_8_STRING = 25, /**< UTF-8 string */
    BLE_AIOC_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_UTF_16_STRING = 26, /**< UTF-16 string */
    BLE_AIOC_DIGITAL_0_CHAR_PRESENTATION_FORMAT_FORMAT_OPAQUE_STRUCTURE = 27, /**< Opaque Structure */
} e_ble_aioc_digital_0_char_presentation_format_format_t;

/***************************************************************************//**
 * @brief Characteristic Presentation Format Namespace enumeration.
*******************************************************************************/
typedef enum {
    BLE_AIOC_DIGITAL_0_CHAR_PRESENTATION_FORMAT_NAMESPACE_BLUETOOTH_SIG_ASSIGNED_NUMBERS = 1, /**< Bluetooth SIG Assigned Numbers */
} e_ble_aioc_digital_0_char_presentation_format_namespace_t;

/***************************************************************************//**
 * @brief Characteristic Presentation Format value structure.
*******************************************************************************/
typedef struct {
    uint8_t format; /**< Format */
    int8_t  exponent; /**< Exponent */
    uint16_t unit; /**< Unit */
    uint8_t  name_space; /**< Namespace */
    uint16_t description; /**< Description */
} st_ble_aioc_digital_0_char_presentation_format_t;

/*******************************************************************************************************************//**
 * @brief Value Trigger Setting value condition structure.
***********************************************************************************************************************/
typedef enum
{
    BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_CHARACTERISTIC_VALUE_CHANGED = 0X00,/* Characteristic value is changed */
    BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_CROSSED_A_BOUNDRY,/* Crossed a boundary */
    BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_ON_THE_BOUNDRY,/* On the boundary. */
    BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_VALUE_CHANGED_MORE_THAN_SETTABLE,/* Value changed more than settable */
    BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_MASK_THEN_COMPARE,/* Mask then compare */
    BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_INSIDE_AND_OUTSIDE_THE_BOUNDRIES,/* Inside or outside the boundries */
    BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_ON_THE_BOUNDRIES,/* On the Boundaries */
    BLE_AIOC_VALUE_TRIGGER_SETTING_CONDITION_NO_VALUE_TRIGGER,/* No value trigger */
} e_ble_aioc_value_trigger_setting_condition_t;

/*******************************************************************************************************************//**
* @brief Time Trigger Setting value condition structure.
***********************************************************************************************************************/
typedef enum
{
    BLE_AIOC_TIME_TRIGGER_NO_TIME_BASED_TRIGGERING = 0X00,/* No time-based triggering used. */
    BLE_AIOC_TIME_TRIGGER_INDICATES_OR_NOTIFIES_UNCONDITIONALLY,/* Indicates or notifies unconditionally after a settable time */
    BLE_AIOC_TIME_TRIGGER_NOT_INDICATES_OR_NOTIFIES_OFTEN,/* Not indicated or notified more often than a settable time */
    BLE_AIOC_TIME_TRIGGER_CHANGED_MORE_OFTEN,/* Changed more often */
} e_ble_aioc_time_trigger_setting_condition_t;


/***************************************************************************//**
 * @brief Value Trigger Setting value structure.
*******************************************************************************/
typedef struct {
    uint8_t condition; /**< Condition */
    uint16_t bit_mask_value; /**< Value (Bit Mask) */
} st_ble_aioc_digital_0_val_trigger_setting_t;


/***************************************************************************//**
 * @brief Time Trigger Setting value structure.
*******************************************************************************/
typedef struct {
    uint8_t condition; /**< Condition */
    uint8_t value_none; /**< Value (None) */
    uint32_t time_interval_value; /**< Value Time Interval */
    uint16_t count_value; /**< Value Count */
} st_ble_aioc_digital_0_time_trigger_setting_t;


/***************************************************************************//**
 * @brief Digital 0 Digital 0 enumeration.
*******************************************************************************/
typedef enum {
    BLE_AIOC_DIGITAL_0_DIGITAL_0_INACTIVE = 0, /**< Inactive */
    BLE_AIOC_DIGITAL_0_DIGITAL_0_ACTIVE = 1, /**< Active */
    BLE_AIOC_DIGITAL_0_DIGITAL_0_TRI_STATE = 2, /**< Tri-state */
    BLE_AIOC_DIGITAL_0_DIGITAL_0_OUTPUT_STATE = 3, /**< Output-state */
} e_ble_aioc_digital_0_digital_0_t;

/***************************************************************************//**
 * @brief Digital 0 attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
    uint16_t cli_cnfg_desc_hdl;
    uint16_t char_presentation_format_desc_hdl;
    uint16_t char_user_description_desc_hdl;
    uint16_t char_extended_properties_desc_hdl;
    uint16_t val_trigger_setting_desc_hdl;
    uint16_t time_trigger_setting_desc_hdl;
    uint16_t num_of_digitals_desc_hdl;
} st_ble_aioc_digital_0_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Digital 0 characteristic Client Characteristic Configuration descriptor value from the remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_ReadDigital0CliCnfg(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Digital 0 characteristic Client Characteristic Configuration descriptor value to remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @param[in] p_value  - Pointer to Digital 0 characteristic Client Characteristic Configuration descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_WriteDigital0CliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Read Digital 0 characteristic Characteristic Presentation Format descriptor value from the remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_ReadDigital0CharPresentationFormat(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Read Digital 0 characteristic Characteristic User Description descriptor value from the remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_ReadDigital0CharUserDescription(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Digital 0 characteristic Characteristic User Description descriptor value to remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @param[in] p_value  - Pointer to Digital 0 characteristic Characteristic User Description descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_WriteDigital0CharUserDescription(uint16_t conn_hdl, const st_ble_seq_data_t *p_value);

/***************************************************************************//**
 * @brief     Read Digital 0 characteristic Characteristic Extended Properties descriptor value from the remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_ReadDigital0CharExtendedProperties(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Read Digital 0 characteristic Value Trigger Setting descriptor value from the remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_ReadDigital0ValTriggerSetting(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Digital 0 characteristic Value Trigger Setting descriptor value to remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @param[in] p_value  - Pointer to Digital 0 characteristic Value Trigger Setting descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_WriteDigital0ValTriggerSetting(uint16_t conn_hdl, const st_ble_aioc_digital_0_val_trigger_setting_t *p_value);

/***************************************************************************//**
 * @brief     Read Digital 0 characteristic Time Trigger Setting descriptor value from the remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_ReadDigital0TimeTriggerSetting(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Digital 0 characteristic Time Trigger Setting descriptor value to remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @param[in] p_value  - Pointer to Digital 0 characteristic Time Trigger Setting descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_WriteDigital0TimeTriggerSetting(uint16_t conn_hdl, const st_ble_aioc_digital_0_time_trigger_setting_t *p_value);

/***************************************************************************//**
 * @brief     Read Digital 0 characteristic Number of Digitals descriptor value from the remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_ReadDigital0NumOfDigitals(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Read Digital 0 characteristic value from the remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_ReadDigital0(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Digital 0 characteristic value to remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @param[in] p_value  - Pointer to Digital 0 characteristic value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_WriteDigital0(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Write Digital 0 without response characteristic value to remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @param[in] p_value  - Pointer to Digital 0 characteristic value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_WriteDigital0WithoutRsp(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief      Get Digital 0 attribute handles.
 * @param[in]  p_addr - Pointer to Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  - Pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_AIOC_GetDigital0AttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_aioc_digital_0_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Digital 1 Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_AIOC_DIGITAL_1_UUID (0x2A56)
#define BLE_AIOC_DIGITAL_1_LEN (2)
#define BLE_AIOC_DIGITAL_1_CLI_CNFG_UUID (0x2902)
#define BLE_AIOC_DIGITAL_1_CLI_CNFG_LEN (2)
#define BLE_AIOC_DIGITAL_1_CHAR_PRESENTATION_FORMAT_UUID (0x2904)
#define BLE_AIOC_DIGITAL_1_CHAR_PRESENTATION_FORMAT_LEN (7)
#define BLE_AIOC_DIGITAL_1_CHAR_USER_DESCRIPTION_UUID (0x2901)
#define BLE_AIOC_DIGITAL_1_CHAR_USER_DESCRIPTION_LEN (100)
#define BLE_AIOC_DIGITAL_1_CHAR_EXTENDED_PROPERTIES_UUID (0x2900)
#define BLE_AIOC_DIGITAL_1_CHAR_EXTENDED_PROPERTIES_LEN (2)
#define BLE_AIOC_DIGITAL_1_VAL_TRIGGER_SETTING_UUID (0x290A)
#define BLE_AIOC_DIGITAL_1_VAL_TRIGGER_SETTING_LEN (3)
#define BLE_AIOC_DIGITAL_1_TIME_TRIGGER_SETTING_UUID (0x290E)
#define BLE_AIOC_DIGITAL_1_TIME_TRIGGER_SETTING_LEN (4)
#define BLE_AIOC_DIGITAL_1_NUM_OF_DIGITALS_UUID (0x2909)
#define BLE_AIOC_DIGITAL_1_NUM_OF_DIGITALS_LEN (1)


/***************************************************************************//**
 * @brief Characteristic Presentation Format Format enumeration.
*******************************************************************************/
typedef enum {
    BLE_AIOC_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_BOOLEAN = 1, /**< Boolean */
    BLE_AIOC_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_2_BIT_INTEGER = 2, /**< unsigned 2-bit integer */
    BLE_AIOC_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_4_BIT_INTEGER = 3, /**< unsigned 4-bit integer */
    BLE_AIOC_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_8_BIT_INTEGER = 4, /**< unsigned 8-bit integer */
    BLE_AIOC_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_12_BIT_INTEGER = 5, /**< unsigned 12-bit integer */
    BLE_AIOC_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_16_BIT_INTEGER = 6, /**< unsigned 16-bit integer */
    BLE_AIOC_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_24_BIT_INTEGER = 7, /**< unsigned 24-bit integer */
    BLE_AIOC_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_32_BIT_INTEGER = 8, /**< unsigned 32-bit integer */
    BLE_AIOC_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_48_BIT_INTEGER = 9, /**< unsigned 48-bit integer */
    BLE_AIOC_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_64_BIT_INTEGER = 10, /**< unsigned 64-bit integer */
    BLE_AIOC_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_128_BIT_INTEGER = 11, /**< unsigned 128-bit integer */
    BLE_AIOC_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_8_BIT_INTEGER = 12, /**< signed 8-bit integer */
    BLE_AIOC_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_12_BIT_INTEGER = 13, /**< signed 12-bit integer */
    BLE_AIOC_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_16_BIT_INTEGER = 14, /**< signed 16-bit integer */
    BLE_AIOC_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_24_BIT_INTEGER = 15, /**< signed 24-bit integer */
    BLE_AIOC_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_32_BIT_INTEGER = 16, /**< signed 32-bit integer */
    BLE_AIOC_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_48_BIT_INTEGER = 17, /**< signed 48-bit integer */
    BLE_AIOC_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_64_BIT_INTEGER = 18, /**< signed 64-bit integer */
    BLE_AIOC_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_128_BIT_INTEGER = 19, /**< signed 128-bit integer */
    BLE_AIOC_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_IEEE_754_32_BIT_FLOATING_POINT = 20, /**< IEEE-754 32-bit floating point */
    BLE_AIOC_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_IEEE_754_64_BIT_FLOATING_POINT = 21, /**< IEEE-754 64-bit floating point */
    BLE_AIOC_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_IEEE_11073_16_BIT_SFLOAT = 22, /**< IEEE-11073 16-bit SFLOAT */
    BLE_AIOC_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_IEEE_11073_32_BIT_FLOAT = 23, /**< IEEE-11073 32-bit FLOAT */
    BLE_AIOC_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_IEEE_20601_FORMAT = 24, /**< IEEE-20601 format */
    BLE_AIOC_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_UTF_8_STRING = 25, /**< UTF-8 string */
    BLE_AIOC_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_UTF_16_STRING = 26, /**< UTF-16 string */
    BLE_AIOC_DIGITAL_1_CHAR_PRESENTATION_FORMAT_FORMAT_OPAQUE_STRUCTURE = 27, /**< Opaque Structure */
} e_ble_aioc_digital_1_char_presentation_format_format_t;

/***************************************************************************//**
 * @brief Characteristic Presentation Format Namespace enumeration.
*******************************************************************************/
typedef enum {
    BLE_AIOC_DIGITAL_1_CHAR_PRESENTATION_FORMAT_NAMESPACE_BLUETOOTH_SIG_ASSIGNED_NUMBERS = 1, /**< Bluetooth SIG Assigned Numbers */
} e_ble_aioc_digital_1_char_presentation_format_namespace_t;

/***************************************************************************//**
 * @brief Characteristic Presentation Format value structure.
*******************************************************************************/
typedef struct {
    uint8_t format; /**< Format */
    int8_t exponent; /**< Exponent */
    uint16_t unit; /**< Unit */
    uint8_t name_space; /**< Namespace */
    uint16_t description; /**< Description */
} st_ble_aioc_digital_1_char_presentation_format_t;


/***************************************************************************//**
 * @brief Value Trigger Setting value structure.
*******************************************************************************/
typedef struct {
    uint8_t condition; /**< Condition */
    uint16_t bit_mask_value; /**< Value (Bit Mask) */
} st_ble_aioc_digital_1_val_trigger_setting_t;


/***************************************************************************//**
 * @brief Time Trigger Setting value structure.
*******************************************************************************/
typedef struct {
    uint8_t condition; /**< Condition */
    uint8_t value_none; /**< Value (None) */
    uint32_t time_interval_value; /**< Value Time Interval */
    uint16_t count_value; /**< Value Count */
} st_ble_aioc_digital_1_time_trigger_setting_t;


/***************************************************************************//**
 * @brief Digital 1 Digital 1 enumeration.
*******************************************************************************/
typedef enum {
    BLE_AIOC_DIGITAL_1_DIGITAL_1_INACTIVE = 0, /**< Inactive */
    BLE_AIOC_DIGITAL_1_DIGITAL_1_ACTIVE = 1, /**< Active */
    BLE_AIOC_DIGITAL_1_DIGITAL_1_TRI_STATE = 2, /**< Tri-state */
    BLE_AIOC_DIGITAL_1_DIGITAL_1_OUTPUT_STATE = 3, /**< Output-state */
} e_ble_aioc_digital_1_digital_1_t;

/***************************************************************************//**
 * @brief Digital 1 attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
    uint16_t cli_cnfg_desc_hdl;
    uint16_t char_presentation_format_desc_hdl;
    uint16_t char_user_description_desc_hdl;
    uint16_t char_extended_properties_desc_hdl;
    uint16_t val_trigger_setting_desc_hdl;
    uint16_t time_trigger_setting_desc_hdl;
    uint16_t num_of_digitals_desc_hdl;
} st_ble_aioc_digital_1_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Digital 1 characteristic Client Characteristic Configuration descriptor value from the remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_ReadDigital1CliCnfg(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Digital 1 characteristic Client Characteristic Configuration descriptor value to remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @param[in] p_value  - Pointer to Digital 1 characteristic Client Characteristic Configuration descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_WriteDigital1CliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Read Digital 1 characteristic Characteristic Presentation Format descriptor value from the remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_ReadDigital1CharPresentationFormat(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Read Digital 1 characteristic Characteristic User Description descriptor value from the remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_ReadDigital1CharUserDescription(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Digital 1 characteristic Characteristic User Description descriptor value to remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @param[in] p_value  - Pointer to Digital 1 characteristic Characteristic User Description descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_WriteDigital1CharUserDescription(uint16_t conn_hdl, const st_ble_seq_data_t *p_value);

/***************************************************************************//**
 * @brief     Read Digital 1 characteristic Characteristic Extended Properties descriptor value from the remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_ReadDigital1CharExtendedProperties(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Read Digital 1 characteristic Value Trigger Setting descriptor value from the remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_ReadDigital1ValTriggerSetting(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Digital 1 characteristic Value Trigger Setting descriptor value to remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @param[in] p_value  - Pointer to Digital 1 characteristic Value Trigger Setting descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_WriteDigital1ValTriggerSetting(uint16_t conn_hdl, const st_ble_aioc_digital_1_val_trigger_setting_t *p_value);

/***************************************************************************//**
 * @brief     Read Digital 1 characteristic Time Trigger Setting descriptor value from the remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_ReadDigital1TimeTriggerSetting(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Digital 1 characteristic Time Trigger Setting descriptor value to remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @param[in] p_value  - Pointer to Digital 1 characteristic Time Trigger Setting descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_WriteDigital1TimeTriggerSetting(uint16_t conn_hdl, const st_ble_aioc_digital_1_time_trigger_setting_t *p_value);

/***************************************************************************//**
 * @brief     Read Digital 1 characteristic Number of Digitals descriptor value from the remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_ReadDigital1NumOfDigitals(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Read Digital 1 characteristic value from the remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_ReadDigital1(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Digital 1 characteristic value to remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @param[in] p_value  - Pointer to Digital 1 characteristic value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_WriteDigital1(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Write Digital 1 without response characteristic value to remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @param[in] p_value  - Pointer to Digital 0 characteristic value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_WriteDigital1WithoutRsp(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief      Get Digital 1 attribute handles.
 * @param[in]  p_addr - Pointer to Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  - Pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_AIOC_GetDigital1AttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_aioc_digital_1_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Analog 0 Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_AIOC_ANALOG_0_UUID (0x2A58)
#define BLE_AIOC_ANALOG_0_LEN (2)
#define BLE_AIOC_ANALOG_0_CLI_CNFG_UUID (0x2902)
#define BLE_AIOC_ANALOG_0_CLI_CNFG_LEN (2)
#define BLE_AIOC_ANALOG_0_CHAR_PRESENTATION_FORMAT_UUID (0x2904)
#define BLE_AIOC_ANALOG_0_CHAR_PRESENTATION_FORMAT_LEN (7)
#define BLE_AIOC_ANALOG_0_CHAR_USER_DESCRIPTION_UUID (0x2901)
#define BLE_AIOC_ANALOG_0_CHAR_USER_DESCRIPTION_LEN (20)
#define BLE_AIOC_ANALOG_0_CHAR_EXTENDED_PROPERTIES_UUID (0x2900)
#define BLE_AIOC_ANALOG_0_CHAR_EXTENDED_PROPERTIES_LEN (2)
#define BLE_AIOC_ANALOG_0_VAL_TRIGGER_SETTING_UUID (0x290A)
#define BLE_AIOC_ANALOG_0_VAL_TRIGGER_SETTING_LEN (5)
#define BLE_AIOC_ANALOG_0_TIME_TRIGGER_SETTING_UUID (0x290E)
#define BLE_AIOC_ANALOG_0_TIME_TRIGGER_SETTING_LEN (4)
#define BLE_AIOC_ANALOG_0_VALID_RANGE_UUID (0x2906)
#define BLE_AIOC_ANALOG_0_VALID_RANGE_LEN (4)


/***************************************************************************//**
 * @brief Characteristic Presentation Format Format enumeration.
*******************************************************************************/
typedef enum {
    BLE_AIOC_ANALOG_0_CHAR_PRESENTATION_FORMAT_FORMAT_BOOLEAN = 1, /**< Boolean */
    BLE_AIOC_ANALOG_0_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_2_BIT_INTEGER = 2, /**< unsigned 2-bit integer */
    BLE_AIOC_ANALOG_0_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_4_BIT_INTEGER = 3, /**< unsigned 4-bit integer */
    BLE_AIOC_ANALOG_0_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_8_BIT_INTEGER = 4, /**< unsigned 8-bit integer */
    BLE_AIOC_ANALOG_0_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_12_BIT_INTEGER = 5, /**< unsigned 12-bit integer */
    BLE_AIOC_ANALOG_0_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_16_BIT_INTEGER = 6, /**< unsigned 16-bit integer */
    BLE_AIOC_ANALOG_0_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_24_BIT_INTEGER = 7, /**< unsigned 24-bit integer */
    BLE_AIOC_ANALOG_0_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_32_BIT_INTEGER = 8, /**< unsigned 32-bit integer */
    BLE_AIOC_ANALOG_0_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_48_BIT_INTEGER = 9, /**< unsigned 48-bit integer */
    BLE_AIOC_ANALOG_0_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_64_BIT_INTEGER = 10, /**< unsigned 64-bit integer */
    BLE_AIOC_ANALOG_0_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_128_BIT_INTEGER = 11, /**< unsigned 128-bit integer */
    BLE_AIOC_ANALOG_0_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_8_BIT_INTEGER = 12, /**< signed 8-bit integer */
    BLE_AIOC_ANALOG_0_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_12_BIT_INTEGER = 13, /**< signed 12-bit integer */
    BLE_AIOC_ANALOG_0_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_16_BIT_INTEGER = 14, /**< signed 16-bit integer */
    BLE_AIOC_ANALOG_0_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_24_BIT_INTEGER = 15, /**< signed 24-bit integer */
    BLE_AIOC_ANALOG_0_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_32_BIT_INTEGER = 16, /**< signed 32-bit integer */
    BLE_AIOC_ANALOG_0_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_48_BIT_INTEGER = 17, /**< signed 48-bit integer */
    BLE_AIOC_ANALOG_0_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_64_BIT_INTEGER = 18, /**< signed 64-bit integer */
    BLE_AIOC_ANALOG_0_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_128_BIT_INTEGER = 19, /**< signed 128-bit integer */
    BLE_AIOC_ANALOG_0_CHAR_PRESENTATION_FORMAT_FORMAT_IEEE_754_32_BIT_FLOATING_POINT = 20, /**< IEEE-754 32-bit floating point */
    BLE_AIOC_ANALOG_0_CHAR_PRESENTATION_FORMAT_FORMAT_IEEE_754_64_BIT_FLOATING_POINT = 21, /**< IEEE-754 64-bit floating point */
    BLE_AIOC_ANALOG_0_CHAR_PRESENTATION_FORMAT_FORMAT_IEEE_11073_16_BIT_SFLOAT = 22, /**< IEEE-11073 16-bit SFLOAT */
    BLE_AIOC_ANALOG_0_CHAR_PRESENTATION_FORMAT_FORMAT_IEEE_11073_32_BIT_FLOAT = 23, /**< IEEE-11073 32-bit FLOAT */
    BLE_AIOC_ANALOG_0_CHAR_PRESENTATION_FORMAT_FORMAT_IEEE_20601_FORMAT = 24, /**< IEEE-20601 format */
    BLE_AIOC_ANALOG_0_CHAR_PRESENTATION_FORMAT_FORMAT_UTF_8_STRING = 25, /**< UTF-8 string */
    BLE_AIOC_ANALOG_0_CHAR_PRESENTATION_FORMAT_FORMAT_UTF_16_STRING = 26, /**< UTF-16 string */
    BLE_AIOC_ANALOG_0_CHAR_PRESENTATION_FORMAT_FORMAT_OPAQUE_STRUCTURE = 27, /**< Opaque Structure */
} e_ble_aioc_analog_0_char_presentation_format_format_t;

/***************************************************************************//**
 * @brief Characteristic Presentation Format Namespace enumeration.
*******************************************************************************/
typedef enum {
    BLE_AIOC_ANALOG_0_CHAR_PRESENTATION_FORMAT_NAMESPACE_BLUETOOTH_SIG_ASSIGNED_NUMBERS = 1, /**< Bluetooth SIG Assigned Numbers */
} e_ble_aioc_analog_0_char_presentation_format_namespace_t;

/***************************************************************************//**
 * @brief Characteristic Presentation Format value structure.
*******************************************************************************/
typedef struct {
    uint8_t format; /**< Format */
    int8_t exponent; /**< Exponent */
    uint16_t unit; /**< Unit */
    uint8_t name_space; /**< Namespace */
    uint16_t description; /**< Description */
} st_ble_aioc_analog_0_char_presentation_format_t;


/***************************************************************************//**
 * @brief Value Trigger Setting value structure.
*******************************************************************************/
typedef struct {
    uint8_t condition; /**< Condition */
    int16_t analog_value; /**< Value Analog */
    int16_t analog_interval_value1; /**< Value Analog Interval */
    int16_t analog_interval_value2; /**< Value Analog Interval */
} st_ble_aioc_analog_0_val_trigger_setting_t;


/***************************************************************************//**
 * @brief Time Trigger Setting value structure.
*******************************************************************************/
typedef struct {
    uint8_t condition; /**< Condition */
    uint8_t value_none; /**< Value (None) */
    uint32_t time_interval_value; /**< Value (Time Interval) */
    uint16_t count_value; /**< Value (Count) */
} st_ble_aioc_analog_0_time_trigger_setting_t;


/***************************************************************************//**
 * @brief Valid Range value structure.
*******************************************************************************/
typedef struct {
    int16_t lower_inclusive_value; /**< Lower inclusive value */
    int16_t upper_inclusive_value; /**< Upper inclusive value */
} st_ble_aioc_analog_0_valid_range_t;

/***************************************************************************//**
 * @brief Analog 0 attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
    uint16_t cli_cnfg_desc_hdl;
    uint16_t char_presentation_format_desc_hdl;
    uint16_t char_user_description_desc_hdl;
    uint16_t char_extended_properties_desc_hdl;
    uint16_t val_trigger_setting_desc_hdl;
    uint16_t time_trigger_setting_desc_hdl;
    uint16_t valid_range_desc_hdl;
} st_ble_aioc_analog_0_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Analog 0 characteristic Client Characteristic Configuration descriptor value from the remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_ReadAnalog0CliCnfg(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Analog 0 characteristic Client Characteristic Configuration descriptor value to remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @param[in] p_value  - Analog 0 characteristic Client Characteristic Configuration descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_WriteAnalog0CliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Read Analog 0 characteristic Characteristic Presentation Format descriptor value from the remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_ReadAnalog0CharPresentationFormat(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Read Analog 0 characteristic Characteristic User Description descriptor value from the remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_ReadAnalog0CharUserDescription(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Analog 0 characteristic Characteristic User Description descriptor value to remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @param[in] p_value  - Pointer to Analog 0 characteristic Characteristic User Description descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_WriteAnalog0CharUserDescription(uint16_t conn_hdl, const st_ble_seq_data_t *p_value);

/***************************************************************************//**
 * @brief     Read Analog 0 characteristic Characteristic Extended Properties descriptor value from the remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_ReadAnalog0CharExtendedProperties(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Read Analog 0 characteristic Value Trigger Setting descriptor value from the remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_ReadAnalog0ValTriggerSetting(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Analog 0 characteristic Value Trigger Setting descriptor value to remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @param[in] p_value  - Pointer to Analog 0 characteristic Value Trigger Setting descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_WriteAnalog0ValTriggerSetting(uint16_t conn_hdl, const st_ble_aioc_analog_0_val_trigger_setting_t *p_value);

/***************************************************************************//**
 * @brief     Read Analog 0 characteristic Time Trigger Setting descriptor value from the remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_ReadAnalog0TimeTriggerSetting(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Analog 0 characteristic Time Trigger Setting descriptor value to remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @param[in] p_value  - Pointer to Analog 0 characteristic Time Trigger Setting descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_WriteAnalog0TimeTriggerSetting(uint16_t conn_hdl, const st_ble_aioc_analog_0_time_trigger_setting_t *p_value);

/***************************************************************************//**
 * @brief     Read Analog 0 characteristic Valid Range descriptor value from the remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_ReadAnalog0ValidRange(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Read Analog 0 characteristic value from the remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_ReadAnalog0(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Analog 0 characteristic value to remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @param[in] p_value  - Pointer to Analog 0 characteristic value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_WriteAnalog0(uint16_t conn_hdl, const int16_t *p_value);

/***************************************************************************//**
 * @brief     Write Analog 0 without reaponse characteristic value to remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @param[in] p_value  - Pointer to Analog 0 characteristic value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_WriteAnalog0WithoutRsp(uint16_t conn_hdl, const int16_t *p_value);

/***************************************************************************//**
 * @brief      Get Analog 0 attribute handles.
 * @param[in]  p_addr - Pointer to Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  - Pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_AIOC_GetAnalog0AttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_aioc_analog_0_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Analog 1 Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_AIOC_ANALOG_1_UUID (0x2A58)
#define BLE_AIOC_ANALOG_1_LEN (2)
#define BLE_AIOC_ANALOG_1_CLI_CNFG_UUID (0x2902)
#define BLE_AIOC_ANALOG_1_CLI_CNFG_LEN (2)
#define BLE_AIOC_ANALOG_1_CHAR_PRESENTATION_FORMAT_UUID (0x2904)
#define BLE_AIOC_ANALOG_1_CHAR_PRESENTATION_FORMAT_LEN (7)
#define BLE_AIOC_ANALOG_1_CHAR_USER_DESCRIPTION_UUID (0x2901)
#define BLE_AIOC_ANALOG_1_CHAR_USER_DESCRIPTION_LEN (20)
#define BLE_AIOC_ANALOG_1_CHAR_EXTENDED_PROPERTIES_UUID (0x2900)
#define BLE_AIOC_ANALOG_1_CHAR_EXTENDED_PROPERTIES_LEN (2)
#define BLE_AIOC_ANALOG_1_VAL_TRIGGER_SETTING_UUID (0x290A)
#define BLE_AIOC_ANALOG_1_VAL_TRIGGER_SETTING_LEN (5)
#define BLE_AIOC_ANALOG_1_TIME_TRIGGER_SETTING_UUID (0x290E)
#define BLE_AIOC_ANALOG_1_TIME_TRIGGER_SETTING_LEN (4)
#define BLE_AIOC_ANALOG_1_VALID_RANGE_UUID (0x2906)
#define BLE_AIOC_ANALOG_1_VALID_RANGE_LEN (4)


/***************************************************************************//**
 * @brief Characteristic Presentation Format Format enumeration.
*******************************************************************************/
typedef enum {
    BLE_AIOC_ANALOG_1_CHAR_PRESENTATION_FORMAT_FORMAT_BOOLEAN = 1, /**< Boolean */
    BLE_AIOC_ANALOG_1_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_2_BIT_INTEGER = 2, /**< unsigned 2-bit integer */
    BLE_AIOC_ANALOG_1_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_4_BIT_INTEGER = 3, /**< unsigned 4-bit integer */
    BLE_AIOC_ANALOG_1_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_8_BIT_INTEGER = 4, /**< unsigned 8-bit integer */
    BLE_AIOC_ANALOG_1_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_12_BIT_INTEGER = 5, /**< unsigned 12-bit integer */
    BLE_AIOC_ANALOG_1_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_16_BIT_INTEGER = 6, /**< unsigned 16-bit integer */
    BLE_AIOC_ANALOG_1_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_24_BIT_INTEGER = 7, /**< unsigned 24-bit integer */
    BLE_AIOC_ANALOG_1_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_32_BIT_INTEGER = 8, /**< unsigned 32-bit integer */
    BLE_AIOC_ANALOG_1_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_48_BIT_INTEGER = 9, /**< unsigned 48-bit integer */
    BLE_AIOC_ANALOG_1_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_64_BIT_INTEGER = 10, /**< unsigned 64-bit integer */
    BLE_AIOC_ANALOG_1_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_128_BIT_INTEGER = 11, /**< unsigned 128-bit integer */
    BLE_AIOC_ANALOG_1_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_8_BIT_INTEGER = 12, /**< signed 8-bit integer */
    BLE_AIOC_ANALOG_1_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_12_BIT_INTEGER = 13, /**< signed 12-bit integer */
    BLE_AIOC_ANALOG_1_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_16_BIT_INTEGER = 14, /**< signed 16-bit integer */
    BLE_AIOC_ANALOG_1_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_24_BIT_INTEGER = 15, /**< signed 24-bit integer */
    BLE_AIOC_ANALOG_1_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_32_BIT_INTEGER = 16, /**< signed 32-bit integer */
    BLE_AIOC_ANALOG_1_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_48_BIT_INTEGER = 17, /**< signed 48-bit integer */
    BLE_AIOC_ANALOG_1_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_64_BIT_INTEGER = 18, /**< signed 64-bit integer */
    BLE_AIOC_ANALOG_1_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_128_BIT_INTEGER = 19, /**< signed 128-bit integer */
    BLE_AIOC_ANALOG_1_CHAR_PRESENTATION_FORMAT_FORMAT_IEEE_754_32_BIT_FLOATING_POINT = 20, /**< IEEE-754 32-bit floating point */
    BLE_AIOC_ANALOG_1_CHAR_PRESENTATION_FORMAT_FORMAT_IEEE_754_64_BIT_FLOATING_POINT = 21, /**< IEEE-754 64-bit floating point */
    BLE_AIOC_ANALOG_1_CHAR_PRESENTATION_FORMAT_FORMAT_IEEE_11073_16_BIT_SFLOAT = 22, /**< IEEE-11073 16-bit SFLOAT */
    BLE_AIOC_ANALOG_1_CHAR_PRESENTATION_FORMAT_FORMAT_IEEE_11073_32_BIT_FLOAT = 23, /**< IEEE-11073 32-bit FLOAT */
    BLE_AIOC_ANALOG_1_CHAR_PRESENTATION_FORMAT_FORMAT_IEEE_20601_FORMAT = 24, /**< IEEE-20601 format */
    BLE_AIOC_ANALOG_1_CHAR_PRESENTATION_FORMAT_FORMAT_UTF_8_STRING = 25, /**< UTF-8 string */
    BLE_AIOC_ANALOG_1_CHAR_PRESENTATION_FORMAT_FORMAT_UTF_16_STRING = 26, /**< UTF-16 string */
    BLE_AIOC_ANALOG_1_CHAR_PRESENTATION_FORMAT_FORMAT_OPAQUE_STRUCTURE = 27, /**< Opaque Structure */
} e_ble_aioc_analog_1_char_presentation_format_format_t;

/***************************************************************************//**
 * @brief Characteristic Presentation Format Namespace enumeration.
*******************************************************************************/
typedef enum {
    BLE_AIOC_ANALOG_1_CHAR_PRESENTATION_FORMAT_NAMESPACE_BLUETOOTH_SIG_ASSIGNED_NUMBERS = 1, /**< Bluetooth SIG Assigned Numbers */
} e_ble_aioc_analog_1_char_presentation_format_namespace_t;

/***************************************************************************//**
 * @brief Characteristic Presentation Format value structure.
*******************************************************************************/
typedef struct {
    uint8_t format; /**< Format */
    int8_t exponent; /**< Exponent */
    uint16_t unit; /**< Unit */
    uint8_t name_space; /**< Namespace */
    uint16_t description; /**< Description */
} st_ble_aioc_analog_1_char_presentation_format_t;


/***************************************************************************//**
 * @brief Value Trigger Setting value structure.
*******************************************************************************/
typedef struct {
    uint8_t condition; /**< Condition */
    int16_t analog_value; /**< Value Analog */
    int16_t analog_interval_value1; /**< Value Analog Interval */
    int16_t analog_interval_value2; /**< Value Analog Interval */
} st_ble_aioc_analog_1_val_trigger_setting_t;


/***************************************************************************//**
 * @brief Time Trigger Setting value structure.
*******************************************************************************/
typedef struct {
    uint8_t condition; /**< Condition */
    uint8_t value_none; /**< Value (None) */
    uint32_t time_interval_value; /**< Value (Time Interval) */
    uint16_t count_value; /**< Value (Count) */
} st_ble_aioc_analog_1_time_trigger_setting_t;


/***************************************************************************//**
 * @brief Valid Range value structure.
*******************************************************************************/
typedef struct {
    int16_t lower_inclusive_value; /**< Lower inclusive value */
    int16_t upper_inclusive_value; /**< Upper inclusive value */
} st_ble_aioc_analog_1_valid_range_t;

/***************************************************************************//**
 * @brief Analog 1 attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
    uint16_t cli_cnfg_desc_hdl;
    uint16_t char_presentation_format_desc_hdl;
    uint16_t char_user_description_desc_hdl;
    uint16_t char_extended_properties_desc_hdl;
    uint16_t val_trigger_setting_desc_hdl;
    uint16_t time_trigger_setting_desc_hdl;
    uint16_t valid_range_desc_hdl;
} st_ble_aioc_analog_1_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Analog 1 characteristic Client Characteristic Configuration descriptor value from the remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_ReadAnalog1CliCnfg(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Analog 1 characteristic Client Characteristic Configuration descriptor value to remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @param[in] p_value  - Pointer to Analog 1 characteristic Client Characteristic Configuration descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_WriteAnalog1CliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Read Analog 1 characteristic Characteristic Presentation Format descriptor value from the remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_ReadAnalog1CharPresentationFormat(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Read Analog 1 characteristic Characteristic User Description descriptor value from the remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_ReadAnalog1CharUserDescription(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Analog 1 characteristic Characteristic User Description descriptor value to remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @param[in] p_value  - Pointer to Analog 1 characteristic Characteristic User Description descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_WriteAnalog1CharUserDescription(uint16_t conn_hdl, const st_ble_seq_data_t *p_value);

/***************************************************************************//**
 * @brief     Read Analog 1 characteristic Characteristic Extended Properties descriptor value from the remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_ReadAnalog1CharExtendedProperties(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Read Analog 1 characteristic Value Trigger Setting descriptor value from the remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_ReadAnalog1ValTriggerSetting(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Analog 1 characteristic Value Trigger Setting descriptor value to remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @param[in] p_value  - Pointer to Analog 1 characteristic Value Trigger Setting descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_WriteAnalog1ValTriggerSetting(uint16_t conn_hdl, const st_ble_aioc_analog_1_val_trigger_setting_t *p_value);

/***************************************************************************//**
 * @brief     Read Analog 1 characteristic Time Trigger Setting descriptor value from the remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_ReadAnalog1TimeTriggerSetting(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Analog 1 characteristic Time Trigger Setting descriptor value to remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @param[in] p_value  - Pointer to Analog 1 characteristic Time Trigger Setting descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_WriteAnalog1TimeTriggerSetting(uint16_t conn_hdl, const st_ble_aioc_analog_1_time_trigger_setting_t *p_value);

/***************************************************************************//**
 * @brief     Read Analog 1 characteristic Valid Range descriptor value from the remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_ReadAnalog1ValidRange(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Read Analog 1 characteristic value from the remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_ReadAnalog1(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Analog 1 characteristic value to remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @param[in] p_value  - Pointer to Analog 1 characteristic value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_WriteAnalog1(uint16_t conn_hdl, const int16_t *p_value);

/***************************************************************************//**
 * @brief     Write Analog 1 without response characteristic value to remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @param[in] p_value  - Pointer to Analog 0 characteristic value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_WriteAnalog1WithoutRsp(uint16_t conn_hdl, const int16_t *p_value);

/***************************************************************************//**
 * @brief      Get Analog 1 attribute handles.
 * @param[in]  p_addr - Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  - Pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_AIOC_GetAnalog1AttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_aioc_analog_1_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Analog 2 Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_AIOC_ANALOG_2_UUID (0x2A58)
#define BLE_AIOC_ANALOG_2_LEN (2)
#define BLE_AIOC_ANALOG_2_CLI_CNFG_UUID (0x2902)
#define BLE_AIOC_ANALOG_2_CLI_CNFG_LEN (2)
#define BLE_AIOC_ANALOG_2_CHAR_PRESENTATION_FORMAT_UUID (0x2904)
#define BLE_AIOC_ANALOG_2_CHAR_PRESENTATION_FORMAT_LEN (7)
#define BLE_AIOC_ANALOG_2_CHAR_USER_DESCRIPTION_UUID (0x2901)
#define BLE_AIOC_ANALOG_2_CHAR_USER_DESCRIPTION_LEN (20)
#define BLE_AIOC_ANALOG_2_CHAR_EXTENDED_PROPERTIES_UUID (0x2900)
#define BLE_AIOC_ANALOG_2_CHAR_EXTENDED_PROPERTIES_LEN (2)
#define BLE_AIOC_ANALOG_2_VAL_TRIGGER_SETTING_UUID (0x290A)
#define BLE_AIOC_ANALOG_2_VAL_TRIGGER_SETTING_LEN (5)
#define BLE_AIOC_ANALOG_2_TIME_TRIGGER_SETTING_UUID (0x290E)
#define BLE_AIOC_ANALOG_2_TIME_TRIGGER_SETTING_LEN (4)
#define BLE_AIOC_ANALOG_2_VALID_RANGE_UUID (0x2906)
#define BLE_AIOC_ANALOG_2_VALID_RANGE_LEN (4)


/***************************************************************************//**
 * @brief Characteristic Presentation Format Format enumeration.
*******************************************************************************/
typedef enum {
    BLE_AIOC_ANALOG_2_CHAR_PRESENTATION_FORMAT_FORMAT_BOOLEAN = 1, /**< Boolean */
    BLE_AIOC_ANALOG_2_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_2_BIT_INTEGER = 2, /**< unsigned 2-bit integer */
    BLE_AIOC_ANALOG_2_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_4_BIT_INTEGER = 3, /**< unsigned 4-bit integer */
    BLE_AIOC_ANALOG_2_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_8_BIT_INTEGER = 4, /**< unsigned 8-bit integer */
    BLE_AIOC_ANALOG_2_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_12_BIT_INTEGER = 5, /**< unsigned 12-bit integer */
    BLE_AIOC_ANALOG_2_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_16_BIT_INTEGER = 6, /**< unsigned 16-bit integer */
    BLE_AIOC_ANALOG_2_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_24_BIT_INTEGER = 7, /**< unsigned 24-bit integer */
    BLE_AIOC_ANALOG_2_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_32_BIT_INTEGER = 8, /**< unsigned 32-bit integer */
    BLE_AIOC_ANALOG_2_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_48_BIT_INTEGER = 9, /**< unsigned 48-bit integer */
    BLE_AIOC_ANALOG_2_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_64_BIT_INTEGER = 10, /**< unsigned 64-bit integer */
    BLE_AIOC_ANALOG_2_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_128_BIT_INTEGER = 11, /**< unsigned 128-bit integer */
    BLE_AIOC_ANALOG_2_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_8_BIT_INTEGER = 12, /**< signed 8-bit integer */
    BLE_AIOC_ANALOG_2_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_12_BIT_INTEGER = 13, /**< signed 12-bit integer */
    BLE_AIOC_ANALOG_2_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_16_BIT_INTEGER = 14, /**< signed 16-bit integer */
    BLE_AIOC_ANALOG_2_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_24_BIT_INTEGER = 15, /**< signed 24-bit integer */
    BLE_AIOC_ANALOG_2_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_32_BIT_INTEGER = 16, /**< signed 32-bit integer */
    BLE_AIOC_ANALOG_2_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_48_BIT_INTEGER = 17, /**< signed 48-bit integer */
    BLE_AIOC_ANALOG_2_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_64_BIT_INTEGER = 18, /**< signed 64-bit integer */
    BLE_AIOC_ANALOG_2_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_128_BIT_INTEGER = 19, /**< signed 128-bit integer */
    BLE_AIOC_ANALOG_2_CHAR_PRESENTATION_FORMAT_FORMAT_IEEE_754_32_BIT_FLOATING_POINT = 20, /**< IEEE-754 32-bit floating point */
    BLE_AIOC_ANALOG_2_CHAR_PRESENTATION_FORMAT_FORMAT_IEEE_754_64_BIT_FLOATING_POINT = 21, /**< IEEE-754 64-bit floating point */
    BLE_AIOC_ANALOG_2_CHAR_PRESENTATION_FORMAT_FORMAT_IEEE_11073_16_BIT_SFLOAT = 22, /**< IEEE-11073 16-bit SFLOAT */
    BLE_AIOC_ANALOG_2_CHAR_PRESENTATION_FORMAT_FORMAT_IEEE_11073_32_BIT_FLOAT = 23, /**< IEEE-11073 32-bit FLOAT */
    BLE_AIOC_ANALOG_2_CHAR_PRESENTATION_FORMAT_FORMAT_IEEE_20601_FORMAT = 24, /**< IEEE-20601 format */
    BLE_AIOC_ANALOG_2_CHAR_PRESENTATION_FORMAT_FORMAT_UTF_8_STRING = 25, /**< UTF-8 string */
    BLE_AIOC_ANALOG_2_CHAR_PRESENTATION_FORMAT_FORMAT_UTF_16_STRING = 26, /**< UTF-16 string */
    BLE_AIOC_ANALOG_2_CHAR_PRESENTATION_FORMAT_FORMAT_OPAQUE_STRUCTURE = 27, /**< Opaque Structure */
} e_ble_aioc_analog_2_char_presentation_format_format_t;

/***************************************************************************//**
 * @brief Characteristic Presentation Format Namespace enumeration.
*******************************************************************************/
typedef enum {
    BLE_AIOC_ANALOG_2_CHAR_PRESENTATION_FORMAT_NAMESPACE_BLUETOOTH_SIG_ASSIGNED_NUMBERS = 1, /**< Bluetooth SIG Assigned Numbers */
} e_ble_aioc_analog_2_char_presentation_format_namespace_t;

/***************************************************************************//**
 * @brief Characteristic Presentation Format value structure.
*******************************************************************************/
typedef struct {
    uint8_t format; /**< Format */
    int8_t exponent; /**< Exponent */
    uint16_t unit; /**< Unit */
    uint8_t name_space; /**< Namespace */
    uint16_t description; /**< Description */
} st_ble_aioc_analog_2_char_presentation_format_t;


/***************************************************************************//**
 * @brief Value Trigger Setting value structure.
*******************************************************************************/
typedef struct {
    uint8_t condition; /**< Condition */
    int16_t analog_value; /**< Value Analog */
    int16_t analog_interval_value1; /**< Value Analog Interval */
    int16_t analog_interval_value2; /**< Value Analog Interval */
} st_ble_aioc_analog_2_val_trigger_setting_t;


/***************************************************************************//**
 * @brief Time Trigger Setting value structure.
*******************************************************************************/
typedef struct {
    uint8_t condition; /**< Condition */
    uint8_t value_none; /**< Value (None) */
    uint32_t time_interval_value; /**< Value (Time Interval) */
    uint16_t count_value; /**< Value (Count) */
} st_ble_aioc_analog_2_time_trigger_setting_t;


/***************************************************************************//**
 * @brief Valid Range value structure.
*******************************************************************************/
typedef struct {
    int16_t lower_inclusive_value; /**< Lower inclusive value */
    int16_t upper_inclusive_value; /**< Upper inclusive value */
} st_ble_aioc_analog_2_valid_range_t;

/***************************************************************************//**
 * @brief Analog 2 attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
    uint16_t cli_cnfg_desc_hdl;
    uint16_t char_presentation_format_desc_hdl;
    uint16_t char_user_description_desc_hdl;
    uint16_t char_extended_properties_desc_hdl;
    uint16_t val_trigger_setting_desc_hdl;
    uint16_t time_trigger_setting_desc_hdl;
    uint16_t valid_range_desc_hdl;
} st_ble_aioc_analog_2_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Analog 2 characteristic Client Characteristic Configuration descriptor value from the remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_ReadAnalog2CliCnfg(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Analog 2 characteristic Client Characteristic Configuration descriptor value to remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @param[in] p_value  - Pointer to Analog 2 characteristic Client Characteristic Configuration descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_WriteAnalog2CliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Read Analog 2 characteristic Characteristic Presentation Format descriptor value from the remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_ReadAnalog2CharPresentationFormat(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Read Analog 2 characteristic Characteristic User Description descriptor value from the remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_ReadAnalog2CharUserDescription(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Analog 2 characteristic Characteristic User Description descriptor value to remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @param[in] p_value  - Pointer to Analog 2 characteristic Characteristic User Description descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_WriteAnalog2CharUserDescription(uint16_t conn_hdl, const st_ble_seq_data_t *p_value);

/***************************************************************************//**
 * @brief     Read Analog 2 characteristic Characteristic Extended Properties descriptor value from the remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_ReadAnalog2CharExtendedProperties(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Read Analog 2 characteristic Value Trigger Setting descriptor value from the remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_ReadAnalog2ValTriggerSetting(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Analog 2 characteristic Value Trigger Setting descriptor value to remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @param[in] p_value  - Pointer to Analog 2 characteristic Value Trigger Setting descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_WriteAnalog2ValTriggerSetting(uint16_t conn_hdl, const st_ble_aioc_analog_2_val_trigger_setting_t *p_value);

/***************************************************************************//**
 * @brief     Read Analog 2 characteristic Time Trigger Setting descriptor value from the remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_ReadAnalog2TimeTriggerSetting(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Analog 2 characteristic Time Trigger Setting descriptor value to remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @param[in] p_value  - Pointer to Analog 2 characteristic Time Trigger Setting descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_WriteAnalog2TimeTriggerSetting(uint16_t conn_hdl, const st_ble_aioc_analog_2_time_trigger_setting_t *p_value);

/***************************************************************************//**
 * @brief     Read Analog 2 characteristic Valid Range descriptor value from the remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_ReadAnalog2ValidRange(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Read Analog 2 characteristic value from the remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_ReadAnalog2(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Analog 2 characteristic value to remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @param[in] p_value  - Pointer to Analog 2 characteristic value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_WriteAnalog2(uint16_t conn_hdl, const int16_t *p_value);

/***************************************************************************//**
 * @brief     Write Analog 2 without response characteristic value to remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @param[in] p_value  - Pointer to Analog 0 characteristic value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_WriteAnalog2WithoutRsp(uint16_t conn_hdl, const int16_t *p_value);

/***************************************************************************//**
 * @brief      Get Analog 2 attribute handles.
 * @param[in]  p_addr - Pointer to Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  - Pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_AIOC_GetAnalog2AttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_aioc_analog_2_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Analog 3 Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_AIOC_ANALOG_3_UUID (0x2A58)
#define BLE_AIOC_ANALOG_3_LEN (2)
#define BLE_AIOC_ANALOG_3_CLI_CNFG_UUID (0x2902)
#define BLE_AIOC_ANALOG_3_CLI_CNFG_LEN (2)
#define BLE_AIOC_ANALOG_3_CHAR_PRESENTATION_FORMAT_UUID (0x2904)
#define BLE_AIOC_ANALOG_3_CHAR_PRESENTATION_FORMAT_LEN (7)
#define BLE_AIOC_ANALOG_3_CHAR_USER_DESCRIPTION_UUID (0x2901)
#define BLE_AIOC_ANALOG_3_CHAR_USER_DESCRIPTION_LEN (20)
#define BLE_AIOC_ANALOG_3_CHAR_EXTENDED_PROPERTIES_UUID (0x2900)
#define BLE_AIOC_ANALOG_3_CHAR_EXTENDED_PROPERTIES_LEN (2)
#define BLE_AIOC_ANALOG_3_VAL_TRIGGER_SETTING_UUID (0x290A)
#define BLE_AIOC_ANALOG_3_VAL_TRIGGER_SETTING_LEN (5)
#define BLE_AIOC_ANALOG_3_TIME_TRIGGER_SETTING_UUID (0x290E)
#define BLE_AIOC_ANALOG_3_TIME_TRIGGER_SETTING_LEN (4)
#define BLE_AIOC_ANALOG_3_VALID_RANGE_UUID (0x2906)
#define BLE_AIOC_ANALOG_3_VALID_RANGE_LEN (4)


/***************************************************************************//**
 * @brief Characteristic Presentation Format Format enumeration.
*******************************************************************************/
typedef enum {
    BLE_AIOC_ANALOG_3_CHAR_PRESENTATION_FORMAT_FORMAT_BOOLEAN = 1, /**< Boolean */
    BLE_AIOC_ANALOG_3_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_2_BIT_INTEGER = 2, /**< unsigned 2-bit integer */
    BLE_AIOC_ANALOG_3_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_4_BIT_INTEGER = 3, /**< unsigned 4-bit integer */
    BLE_AIOC_ANALOG_3_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_8_BIT_INTEGER = 4, /**< unsigned 8-bit integer */
    BLE_AIOC_ANALOG_3_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_12_BIT_INTEGER = 5, /**< unsigned 12-bit integer */
    BLE_AIOC_ANALOG_3_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_16_BIT_INTEGER = 6, /**< unsigned 16-bit integer */
    BLE_AIOC_ANALOG_3_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_24_BIT_INTEGER = 7, /**< unsigned 24-bit integer */
    BLE_AIOC_ANALOG_3_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_32_BIT_INTEGER = 8, /**< unsigned 32-bit integer */
    BLE_AIOC_ANALOG_3_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_48_BIT_INTEGER = 9, /**< unsigned 48-bit integer */
    BLE_AIOC_ANALOG_3_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_64_BIT_INTEGER = 10, /**< unsigned 64-bit integer */
    BLE_AIOC_ANALOG_3_CHAR_PRESENTATION_FORMAT_FORMAT_UNSIGNED_128_BIT_INTEGER = 11, /**< unsigned 128-bit integer */
    BLE_AIOC_ANALOG_3_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_8_BIT_INTEGER = 12, /**< signed 8-bit integer */
    BLE_AIOC_ANALOG_3_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_12_BIT_INTEGER = 13, /**< signed 12-bit integer */
    BLE_AIOC_ANALOG_3_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_16_BIT_INTEGER = 14, /**< signed 16-bit integer */
    BLE_AIOC_ANALOG_3_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_24_BIT_INTEGER = 15, /**< signed 24-bit integer */
    BLE_AIOC_ANALOG_3_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_32_BIT_INTEGER = 16, /**< signed 32-bit integer */
    BLE_AIOC_ANALOG_3_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_48_BIT_INTEGER = 17, /**< signed 48-bit integer */
    BLE_AIOC_ANALOG_3_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_64_BIT_INTEGER = 18, /**< signed 64-bit integer */
    BLE_AIOC_ANALOG_3_CHAR_PRESENTATION_FORMAT_FORMAT_SIGNED_128_BIT_INTEGER = 19, /**< signed 128-bit integer */
    BLE_AIOC_ANALOG_3_CHAR_PRESENTATION_FORMAT_FORMAT_IEEE_754_32_BIT_FLOATING_POINT = 20, /**< IEEE-754 32-bit floating point */
    BLE_AIOC_ANALOG_3_CHAR_PRESENTATION_FORMAT_FORMAT_IEEE_754_64_BIT_FLOATING_POINT = 21, /**< IEEE-754 64-bit floating point */
    BLE_AIOC_ANALOG_3_CHAR_PRESENTATION_FORMAT_FORMAT_IEEE_11073_16_BIT_SFLOAT = 22, /**< IEEE-11073 16-bit SFLOAT */
    BLE_AIOC_ANALOG_3_CHAR_PRESENTATION_FORMAT_FORMAT_IEEE_11073_32_BIT_FLOAT = 23, /**< IEEE-11073 32-bit FLOAT */
    BLE_AIOC_ANALOG_3_CHAR_PRESENTATION_FORMAT_FORMAT_IEEE_20601_FORMAT = 24, /**< IEEE-20601 format */
    BLE_AIOC_ANALOG_3_CHAR_PRESENTATION_FORMAT_FORMAT_UTF_8_STRING = 25, /**< UTF-8 string */
    BLE_AIOC_ANALOG_3_CHAR_PRESENTATION_FORMAT_FORMAT_UTF_16_STRING = 26, /**< UTF-16 string */
    BLE_AIOC_ANALOG_3_CHAR_PRESENTATION_FORMAT_FORMAT_OPAQUE_STRUCTURE = 27, /**< Opaque Structure */
} e_ble_aioc_analog_3_char_presentation_format_format_t;

/***************************************************************************//**
 * @brief Characteristic Presentation Format Namespace enumeration.
*******************************************************************************/
typedef enum {
    BLE_AIOC_ANALOG_3_CHAR_PRESENTATION_FORMAT_NAMESPACE_BLUETOOTH_SIG_ASSIGNED_NUMBERS = 1, /**< Bluetooth SIG Assigned Numbers */
} e_ble_aioc_analog_3_char_presentation_format_namespace_t;

/***************************************************************************//**
 * @brief Characteristic Presentation Format value structure.
*******************************************************************************/
typedef struct {
    uint8_t format; /**< Format */
    int8_t exponent; /**< Exponent */
    uint16_t unit; /**< Unit */
    uint8_t name_space; /**< Namespace */
    uint16_t description; /**< Description */
} st_ble_aioc_analog_3_char_presentation_format_t;


/***************************************************************************//**
 * @brief Value Trigger Setting value structure.
*******************************************************************************/
typedef struct {
    uint8_t condition; /**< Condition */
    int16_t analog_value; /**< Value Analog */
    int16_t analog_interval_value1; /**< Value Analog Interval */
    int16_t analog_interval_value2; /**< Value Analog Interval */
} st_ble_aioc_analog_3_val_trigger_setting_t;


/***************************************************************************//**
 * @brief Time Trigger Setting value structure.
*******************************************************************************/
typedef struct {
    uint8_t condition; /**< Condition */
    uint8_t value_none; /**< Value (None) */
    uint32_t time_interval_value; /**< Value (Time Interval) */
    uint16_t count_value; /**< Value (Count) */
} st_ble_aioc_analog_3_time_trigger_setting_t;


/***************************************************************************//**
 * @brief Valid Range value structure.
*******************************************************************************/
typedef struct {
    int16_t lower_inclusive_value; /**< Lower inclusive value */
    int16_t upper_inclusive_value; /**< Upper inclusive value */
} st_ble_aioc_analog_3_valid_range_t;

/***************************************************************************//**
 * @brief Analog 3 attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
    uint16_t cli_cnfg_desc_hdl;
    uint16_t char_presentation_format_desc_hdl;
    uint16_t char_user_description_desc_hdl;
    uint16_t char_extended_properties_desc_hdl;
    uint16_t val_trigger_setting_desc_hdl;
    uint16_t time_trigger_setting_desc_hdl;
    uint16_t valid_range_desc_hdl;
} st_ble_aioc_analog_3_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Analog 3 characteristic Client Characteristic Configuration descriptor value from the remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_ReadAnalog3CliCnfg(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Analog 3 characteristic Client Characteristic Configuration descriptor value to remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @param[in] p_value  - Pointer to Analog 3 characteristic Client Characteristic Configuration descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_WriteAnalog3CliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Read Analog 3 characteristic Characteristic Presentation Format descriptor value from the remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_ReadAnalog3CharPresentationFormat(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Read Analog 3 characteristic Characteristic User Description descriptor value from the remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_ReadAnalog3CharUserDescription(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Analog 3 characteristic Characteristic User Description descriptor value to remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @param[in] p_value  - Pointer to Analog 3 characteristic Characteristic User Description descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_WriteAnalog3CharUserDescription(uint16_t conn_hdl, const st_ble_seq_data_t *p_value);

/***************************************************************************//**
 * @brief     Read Analog 3 characteristic Characteristic Extended Properties descriptor value from the remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_ReadAnalog3CharExtendedProperties(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Read Analog 3 characteristic Value Trigger Setting descriptor value from the remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_ReadAnalog3ValTriggerSetting(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Analog 3 characteristic Value Trigger Setting descriptor value to remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @param[in] p_value  - Pointer to Analog 3 characteristic Value Trigger Setting descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_WriteAnalog3ValTriggerSetting(uint16_t conn_hdl, const st_ble_aioc_analog_3_val_trigger_setting_t *p_value);

/***************************************************************************//**
 * @brief     Read Analog 3 characteristic Time Trigger Setting descriptor value from the remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_ReadAnalog3TimeTriggerSetting(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Analog 3 characteristic Time Trigger Setting descriptor value to remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @param[in] p_value  - Pointer to Analog 3 characteristic Time Trigger Setting descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_WriteAnalog3TimeTriggerSetting(uint16_t conn_hdl, const st_ble_aioc_analog_3_time_trigger_setting_t *p_value);

/***************************************************************************//**
 * @brief     Read Analog 3 characteristic Valid Range descriptor value from the remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_ReadAnalog3ValidRange(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Read Analog 3 characteristic value from the remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_ReadAnalog3(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Analog 3 characteristic value to remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @param[in] p_value Analog 3 characteristic value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_WriteAnalog3(uint16_t conn_hdl, const int16_t *p_value);

/***************************************************************************//**
 * @brief     Write Analog 3 without response characteristic value to remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @param[in] p_value  - Pointer to Analog 0 characteristic value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_WriteAnalog3WithoutRsp(uint16_t conn_hdl, const int16_t *p_value);

/***************************************************************************//**
 * @brief      Get Analog 3 attribute handles.
 * @param[in]  p_addr - Pointer to Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  - Pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_AIOC_GetAnalog3AttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_aioc_analog_3_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Aggregate Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_AIOC_AGGREGATE_UUID (0x2A5A)
#define BLE_AIOC_AGGREGATE_LEN (8)
#define BLE_AIOC_AGGREGATE_CLI_CNFG_UUID (0x2902)
#define BLE_AIOC_AGGREGATE_CLI_CNFG_LEN (2)

/***************************************************************************//**
 * @brief Aggregate value structure.
*******************************************************************************/
typedef struct {
    uint16_t input_bits0; /**< Input Bits */
    uint16_t input_bits1; /**< Input Bits */
    int16_t analog_input0; /**< Analog Input */
    int16_t analog_input1; /**< Analog Input */
} st_ble_aioc_aggregate_t;

/***************************************************************************//**
 * @brief Aggregate attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
    uint16_t cli_cnfg_desc_hdl;
} st_ble_aioc_aggregate_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Aggregate characteristic Client Characteristic Configuration descriptor value from the remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_ReadAggregateCliCnfg(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Aggregate characteristic Client Characteristic Configuration descriptor value to remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @param[in] p_value  - Pointer to Aggregate characteristic Client Characteristic Configuration descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_WriteAggregateCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Read Aggregate characteristic value from the remote GATT database.
 * @param[in] conn_hdl - Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_ReadAggregate(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief      Get Aggregate attribute handles.
 * @param[in]  p_addr - Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  - Pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_AIOC_GetAggregateAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_aioc_aggregate_attr_hdl_t *p_hdl);


/*----------------------------------------------------------------------------------------------------------------------
    Automation IO Client
----------------------------------------------------------------------------------------------------------------------*/

/***************************************************************************//**
 * @brief An attempt was made to configure a condition value not supported by this Automation IO Server
*******************************************************************************/
#define BLE_AIOC_TRIGGER_CONDITION_VALUE_NOT_SUPPORTED_ERROR (BLE_ERR_GROUP_GATT | 0x80)

/***************************************************************************//**
 * @brief Automation IO client event data.
*******************************************************************************/
typedef struct {
    uint16_t    conn_hdl;  /**< Connection handle */
    uint16_t    param_len; /**< Event parameter length */
    const void *p_param;   /**< Event parameter */
} st_ble_aioc_evt_data_t;

/***************************************************************************//**
 * @brief Automation IO characteristic ID.
*******************************************************************************/
typedef enum {
    BLE_AIOC_DIGITAL_0_IDX,
    BLE_AIOC_DIGITAL_0_CLI_CNFG_IDX,
    BLE_AIOC_DIGITAL_0_CHAR_PRESENTATION_FORMAT_IDX,
    BLE_AIOC_DIGITAL_0_CHAR_USER_DESCRIPTION_IDX,
    BLE_AIOC_DIGITAL_0_CHAR_EXTENDED_PROPERTIES_IDX,
    BLE_AIOC_DIGITAL_0_VAL_TRIGGER_SETTING_IDX,
    BLE_AIOC_DIGITAL_0_TIME_TRIGGER_SETTING_IDX,
    BLE_AIOC_DIGITAL_0_NUM_OF_DIGITALS_IDX,
    BLE_AIOC_DIGITAL_1_IDX,
    BLE_AIOC_DIGITAL_1_CLI_CNFG_IDX,
    BLE_AIOC_DIGITAL_1_CHAR_PRESENTATION_FORMAT_IDX,
    BLE_AIOC_DIGITAL_1_CHAR_USER_DESCRIPTION_IDX,
    BLE_AIOC_DIGITAL_1_CHAR_EXTENDED_PROPERTIES_IDX,
    BLE_AIOC_DIGITAL_1_VAL_TRIGGER_SETTING_IDX,
    BLE_AIOC_DIGITAL_1_TIME_TRIGGER_SETTING_IDX,
    BLE_AIOC_DIGITAL_1_NUM_OF_DIGITALS_IDX,
    BLE_AIOC_ANALOG_0_IDX,
    BLE_AIOC_ANALOG_0_CLI_CNFG_IDX,
    BLE_AIOC_ANALOG_0_CHAR_PRESENTATION_FORMAT_IDX,
    BLE_AIOC_ANALOG_0_CHAR_USER_DESCRIPTION_IDX,
    BLE_AIOC_ANALOG_0_CHAR_EXTENDED_PROPERTIES_IDX,
    BLE_AIOC_ANALOG_0_VAL_TRIGGER_SETTING_IDX,
    BLE_AIOC_ANALOG_0_TIME_TRIGGER_SETTING_IDX,
    BLE_AIOC_ANALOG_0_VALID_RANGE_IDX,
    BLE_AIOC_ANALOG_1_IDX,
    BLE_AIOC_ANALOG_1_CLI_CNFG_IDX,
    BLE_AIOC_ANALOG_1_CHAR_PRESENTATION_FORMAT_IDX,
    BLE_AIOC_ANALOG_1_CHAR_USER_DESCRIPTION_IDX,
    BLE_AIOC_ANALOG_1_CHAR_EXTENDED_PROPERTIES_IDX,
    BLE_AIOC_ANALOG_1_VAL_TRIGGER_SETTING_IDX,
    BLE_AIOC_ANALOG_1_TIME_TRIGGER_SETTING_IDX,
    BLE_AIOC_ANALOG_1_VALID_RANGE_IDX,
    BLE_AIOC_ANALOG_2_IDX,
    BLE_AIOC_ANALOG_2_CLI_CNFG_IDX,
    BLE_AIOC_ANALOG_2_CHAR_PRESENTATION_FORMAT_IDX,
    BLE_AIOC_ANALOG_2_CHAR_USER_DESCRIPTION_IDX,
    BLE_AIOC_ANALOG_2_CHAR_EXTENDED_PROPERTIES_IDX,
    BLE_AIOC_ANALOG_2_VAL_TRIGGER_SETTING_IDX,
    BLE_AIOC_ANALOG_2_TIME_TRIGGER_SETTING_IDX,
    BLE_AIOC_ANALOG_2_VALID_RANGE_IDX,
    BLE_AIOC_ANALOG_3_IDX,
    BLE_AIOC_ANALOG_3_CLI_CNFG_IDX,
    BLE_AIOC_ANALOG_3_CHAR_PRESENTATION_FORMAT_IDX,
    BLE_AIOC_ANALOG_3_CHAR_USER_DESCRIPTION_IDX,
    BLE_AIOC_ANALOG_3_CHAR_EXTENDED_PROPERTIES_IDX,
    BLE_AIOC_ANALOG_3_VAL_TRIGGER_SETTING_IDX,
    BLE_AIOC_ANALOG_3_TIME_TRIGGER_SETTING_IDX,
    BLE_AIOC_ANALOG_3_VALID_RANGE_IDX,
    BLE_AIOC_AGGREGATE_IDX,
    BLE_AIOC_AGGREGATE_CLI_CNFG_IDX,
} e_ble_aioc_char_idx_t;

/***************************************************************************//**
 * @brief Automation IO client event type.
*******************************************************************************/
typedef enum {
    /* Digital 0 */
    BLE_AIOC_EVENT_DIGITAL_00_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_DIGITAL_0_IDX, BLE_SERVC_READ_RSP),
    BLE_AIOC_EVENT_DIGITAL_00_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_DIGITAL_0_IDX, BLE_SERVC_WRITE_RSP),
    BLE_AIOC_EVENT_DIGITAL_0_HDL_VAL_NTF = BLE_SERVC_ATTR_EVENT(BLE_AIOC_DIGITAL_0_IDX, BLE_SERVC_HDL_VAL_NTF),
    BLE_AIOC_EVENT_DIGITAL_0_HDL_VAL_IND = BLE_SERVC_ATTR_EVENT(BLE_AIOC_DIGITAL_0_IDX, BLE_SERVC_HDL_VAL_IND),
    BLE_AIOC_EVENT_DIGITAL_0_CLI_CNFG_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_DIGITAL_0_CLI_CNFG_IDX, BLE_SERVC_READ_RSP),
    BLE_AIOC_EVENT_DIGITAL_0_CLI_CNFG_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_DIGITAL_0_CLI_CNFG_IDX, BLE_SERVC_WRITE_RSP),
    BLE_AIOC_EVENT_DIGITAL_0_CHAR_PRESENTATION_FORMAT_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_DIGITAL_0_CHAR_PRESENTATION_FORMAT_IDX, BLE_SERVC_READ_RSP),
    BLE_AIOC_EVENT_DIGITAL_0_CHAR_USER_DESCRIPTION_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_DIGITAL_0_CHAR_USER_DESCRIPTION_IDX, BLE_SERVC_READ_RSP),
    BLE_AIOC_EVENT_DIGITAL_0_CHAR_USER_DESCRIPTION_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_DIGITAL_0_CHAR_USER_DESCRIPTION_IDX, BLE_SERVC_WRITE_RSP),
    BLE_AIOC_EVENT_DIGITAL_0_CHAR_EXTENDED_PROPERTIES_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_DIGITAL_0_CHAR_EXTENDED_PROPERTIES_IDX, BLE_SERVC_READ_RSP),
    BLE_AIOC_EVENT_DIGITAL_0_VAL_TRIGGER_SETTING_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_DIGITAL_0_VAL_TRIGGER_SETTING_IDX, BLE_SERVC_READ_RSP),
    BLE_AIOC_EVENT_DIGITAL_0_VAL_TRIGGER_SETTING_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_DIGITAL_0_VAL_TRIGGER_SETTING_IDX, BLE_SERVC_WRITE_RSP),
    BLE_AIOC_EVENT_DIGITAL_0_TIME_TRIGGER_SETTING_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_DIGITAL_0_TIME_TRIGGER_SETTING_IDX, BLE_SERVC_READ_RSP),
    BLE_AIOC_EVENT_DIGITAL_0_TIME_TRIGGER_SETTING_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_DIGITAL_0_TIME_TRIGGER_SETTING_IDX, BLE_SERVC_WRITE_RSP),
    BLE_AIOC_EVENT_DIGITAL_0_NUM_OF_DIGITALS_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_DIGITAL_0_NUM_OF_DIGITALS_IDX, BLE_SERVC_READ_RSP),
    /* Digital 1 */
    BLE_AIOC_EVENT_DIGITAL_1_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_DIGITAL_1_IDX, BLE_SERVC_READ_RSP),
    BLE_AIOC_EVENT_DIGITAL_1_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_DIGITAL_1_IDX, BLE_SERVC_WRITE_RSP),
    BLE_AIOC_EVENT_DIGITAL_1_HDL_VAL_NTF = BLE_SERVC_ATTR_EVENT(BLE_AIOC_DIGITAL_1_IDX, BLE_SERVC_HDL_VAL_NTF),
    BLE_AIOC_EVENT_DIGITAL_1_HDL_VAL_IND = BLE_SERVC_ATTR_EVENT(BLE_AIOC_DIGITAL_1_IDX, BLE_SERVC_HDL_VAL_IND),
    BLE_AIOC_EVENT_DIGITAL_1_CLI_CNFG_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_DIGITAL_1_CLI_CNFG_IDX, BLE_SERVC_READ_RSP),
    BLE_AIOC_EVENT_DIGITAL_1_CLI_CNFG_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_DIGITAL_1_CLI_CNFG_IDX, BLE_SERVC_WRITE_RSP),
    BLE_AIOC_EVENT_DIGITAL_1_CHAR_PRESENTATION_FORMAT_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_DIGITAL_1_CHAR_PRESENTATION_FORMAT_IDX, BLE_SERVC_READ_RSP),
    BLE_AIOC_EVENT_DIGITAL_1_CHAR_USER_DESCRIPTION_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_DIGITAL_1_CHAR_USER_DESCRIPTION_IDX, BLE_SERVC_READ_RSP),
    BLE_AIOC_EVENT_DIGITAL_1_CHAR_USER_DESCRIPTION_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_DIGITAL_1_CHAR_USER_DESCRIPTION_IDX, BLE_SERVC_WRITE_RSP),
    BLE_AIOC_EVENT_DIGITAL_1_CHAR_EXTENDED_PROPERTIES_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_DIGITAL_1_CHAR_EXTENDED_PROPERTIES_IDX, BLE_SERVC_READ_RSP),
    BLE_AIOC_EVENT_DIGITAL_1_VAL_TRIGGER_SETTING_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_DIGITAL_1_VAL_TRIGGER_SETTING_IDX, BLE_SERVC_READ_RSP),
    BLE_AIOC_EVENT_DIGITAL_1_VAL_TRIGGER_SETTING_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_DIGITAL_1_VAL_TRIGGER_SETTING_IDX, BLE_SERVC_WRITE_RSP),
    BLE_AIOC_EVENT_DIGITAL_1_TIME_TRIGGER_SETTING_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_DIGITAL_1_TIME_TRIGGER_SETTING_IDX, BLE_SERVC_READ_RSP),
    BLE_AIOC_EVENT_DIGITAL_1_TIME_TRIGGER_SETTING_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_DIGITAL_1_TIME_TRIGGER_SETTING_IDX, BLE_SERVC_WRITE_RSP),
    BLE_AIOC_EVENT_DIGITAL_1_NUM_OF_DIGITALS_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_DIGITAL_1_NUM_OF_DIGITALS_IDX, BLE_SERVC_READ_RSP),
    /* Analog 0 */
    BLE_AIOC_EVENT_ANALOG_00_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_0_IDX, BLE_SERVC_READ_RSP),
    BLE_AIOC_EVENT_ANALOG_00_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_0_IDX, BLE_SERVC_WRITE_RSP),
    BLE_AIOC_EVENT_ANALOG_0_HDL_VAL_NTF = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_0_IDX, BLE_SERVC_HDL_VAL_NTF),
    BLE_AIOC_EVENT_ANALOG_0_HDL_VAL_IND = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_0_IDX, BLE_SERVC_HDL_VAL_IND),
    BLE_AIOC_EVENT_ANALOG_0_CLI_CNFG_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_0_CLI_CNFG_IDX, BLE_SERVC_READ_RSP),
    BLE_AIOC_EVENT_ANALOG_0_CLI_CNFG_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_0_CLI_CNFG_IDX, BLE_SERVC_WRITE_RSP),
    BLE_AIOC_EVENT_ANALOG_0_CHAR_PRESENTATION_FORMAT_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_0_CHAR_PRESENTATION_FORMAT_IDX, BLE_SERVC_READ_RSP),
    BLE_AIOC_EVENT_ANALOG_0_CHAR_USER_DESCRIPTION_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_0_CHAR_USER_DESCRIPTION_IDX, BLE_SERVC_READ_RSP),
    BLE_AIOC_EVENT_ANALOG_0_CHAR_USER_DESCRIPTION_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_0_CHAR_USER_DESCRIPTION_IDX, BLE_SERVC_WRITE_RSP),
    BLE_AIOC_EVENT_ANALOG_0_CHAR_EXTENDED_PROPERTIES_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_0_CHAR_EXTENDED_PROPERTIES_IDX, BLE_SERVC_READ_RSP),
    BLE_AIOC_EVENT_ANALOG_0_VAL_TRIGGER_SETTING_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_0_VAL_TRIGGER_SETTING_IDX, BLE_SERVC_READ_RSP),
    BLE_AIOC_EVENT_ANALOG_0_VAL_TRIGGER_SETTING_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_0_VAL_TRIGGER_SETTING_IDX, BLE_SERVC_WRITE_RSP),
    BLE_AIOC_EVENT_ANALOG_0_TIME_TRIGGER_SETTING_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_0_TIME_TRIGGER_SETTING_IDX, BLE_SERVC_READ_RSP),
    BLE_AIOC_EVENT_ANALOG_0_TIME_TRIGGER_SETTING_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_0_TIME_TRIGGER_SETTING_IDX, BLE_SERVC_WRITE_RSP),
    BLE_AIOC_EVENT_ANALOG_0_VALID_RANGE_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_0_VALID_RANGE_IDX, BLE_SERVC_READ_RSP),
    /* Analog 1 */
    BLE_AIOC_EVENT_ANALOG_1_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_1_IDX, BLE_SERVC_READ_RSP),
    BLE_AIOC_EVENT_ANALOG_1_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_1_IDX, BLE_SERVC_WRITE_RSP),
    BLE_AIOC_EVENT_ANALOG_1_HDL_VAL_NTF = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_1_IDX, BLE_SERVC_HDL_VAL_NTF),
    BLE_AIOC_EVENT_ANALOG_1_HDL_VAL_IND = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_1_IDX, BLE_SERVC_HDL_VAL_IND),
    BLE_AIOC_EVENT_ANALOG_1_CLI_CNFG_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_1_CLI_CNFG_IDX, BLE_SERVC_READ_RSP),
    BLE_AIOC_EVENT_ANALOG_1_CLI_CNFG_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_1_CLI_CNFG_IDX, BLE_SERVC_WRITE_RSP),
    BLE_AIOC_EVENT_ANALOG_1_CHAR_PRESENTATION_FORMAT_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_1_CHAR_PRESENTATION_FORMAT_IDX, BLE_SERVC_READ_RSP),
    BLE_AIOC_EVENT_ANALOG_1_CHAR_USER_DESCRIPTION_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_1_CHAR_USER_DESCRIPTION_IDX, BLE_SERVC_READ_RSP),
    BLE_AIOC_EVENT_ANALOG_1_CHAR_USER_DESCRIPTION_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_1_CHAR_USER_DESCRIPTION_IDX, BLE_SERVC_WRITE_RSP),
    BLE_AIOC_EVENT_ANALOG_1_CHAR_EXTENDED_PROPERTIES_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_1_CHAR_EXTENDED_PROPERTIES_IDX, BLE_SERVC_READ_RSP),
    BLE_AIOC_EVENT_ANALOG_1_VAL_TRIGGER_SETTING_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_1_VAL_TRIGGER_SETTING_IDX, BLE_SERVC_READ_RSP),
    BLE_AIOC_EVENT_ANALOG_1_VAL_TRIGGER_SETTING_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_1_VAL_TRIGGER_SETTING_IDX, BLE_SERVC_WRITE_RSP),
    BLE_AIOC_EVENT_ANALOG_1_TIME_TRIGGER_SETTING_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_1_TIME_TRIGGER_SETTING_IDX, BLE_SERVC_READ_RSP),
    BLE_AIOC_EVENT_ANALOG_1_TIME_TRIGGER_SETTING_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_1_TIME_TRIGGER_SETTING_IDX, BLE_SERVC_WRITE_RSP),
    BLE_AIOC_EVENT_ANALOG_1_VALID_RANGE_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_1_VALID_RANGE_IDX, BLE_SERVC_READ_RSP),
    /* Analog 2 */
    BLE_AIOC_EVENT_ANALOG_2_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_2_IDX, BLE_SERVC_READ_RSP),
    BLE_AIOC_EVENT_ANALOG_2_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_2_IDX, BLE_SERVC_WRITE_RSP),
    BLE_AIOC_EVENT_ANALOG_2_HDL_VAL_NTF = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_2_IDX, BLE_SERVC_HDL_VAL_NTF),
    BLE_AIOC_EVENT_ANALOG_2_HDL_VAL_IND = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_2_IDX, BLE_SERVC_HDL_VAL_IND),
    BLE_AIOC_EVENT_ANALOG_2_CLI_CNFG_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_2_CLI_CNFG_IDX, BLE_SERVC_READ_RSP),
    BLE_AIOC_EVENT_ANALOG_2_CLI_CNFG_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_2_CLI_CNFG_IDX, BLE_SERVC_WRITE_RSP),
    BLE_AIOC_EVENT_ANALOG_2_CHAR_PRESENTATION_FORMAT_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_2_CHAR_PRESENTATION_FORMAT_IDX, BLE_SERVC_READ_RSP),
    BLE_AIOC_EVENT_ANALOG_2_CHAR_USER_DESCRIPTION_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_2_CHAR_USER_DESCRIPTION_IDX, BLE_SERVC_READ_RSP),
    BLE_AIOC_EVENT_ANALOG_2_CHAR_USER_DESCRIPTION_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_2_CHAR_USER_DESCRIPTION_IDX, BLE_SERVC_WRITE_RSP),
    BLE_AIOC_EVENT_ANALOG_2_CHAR_EXTENDED_PROPERTIES_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_2_CHAR_EXTENDED_PROPERTIES_IDX, BLE_SERVC_READ_RSP),
    BLE_AIOC_EVENT_ANALOG_2_VAL_TRIGGER_SETTING_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_2_VAL_TRIGGER_SETTING_IDX, BLE_SERVC_READ_RSP),
    BLE_AIOC_EVENT_ANALOG_2_VAL_TRIGGER_SETTING_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_2_VAL_TRIGGER_SETTING_IDX, BLE_SERVC_WRITE_RSP),
    BLE_AIOC_EVENT_ANALOG_2_TIME_TRIGGER_SETTING_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_2_TIME_TRIGGER_SETTING_IDX, BLE_SERVC_READ_RSP),
    BLE_AIOC_EVENT_ANALOG_2_TIME_TRIGGER_SETTING_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_2_TIME_TRIGGER_SETTING_IDX, BLE_SERVC_WRITE_RSP),
    BLE_AIOC_EVENT_ANALOG_2_VALID_RANGE_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_2_VALID_RANGE_IDX, BLE_SERVC_READ_RSP),
    /* Analog 3 */
    BLE_AIOC_EVENT_ANALOG_3_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_3_IDX, BLE_SERVC_READ_RSP),
    BLE_AIOC_EVENT_ANALOG_3_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_3_IDX, BLE_SERVC_WRITE_RSP),
    BLE_AIOC_EVENT_ANALOG_3_HDL_VAL_NTF = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_3_IDX, BLE_SERVC_HDL_VAL_NTF),
    BLE_AIOC_EVENT_ANALOG_3_HDL_VAL_IND = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_3_IDX, BLE_SERVC_HDL_VAL_IND),
    BLE_AIOC_EVENT_ANALOG_3_CLI_CNFG_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_3_CLI_CNFG_IDX, BLE_SERVC_READ_RSP),
    BLE_AIOC_EVENT_ANALOG_3_CLI_CNFG_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_3_CLI_CNFG_IDX, BLE_SERVC_WRITE_RSP),
    BLE_AIOC_EVENT_ANALOG_3_CHAR_PRESENTATION_FORMAT_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_3_CHAR_PRESENTATION_FORMAT_IDX, BLE_SERVC_READ_RSP),
    BLE_AIOC_EVENT_ANALOG_3_CHAR_USER_DESCRIPTION_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_3_CHAR_USER_DESCRIPTION_IDX, BLE_SERVC_READ_RSP),
    BLE_AIOC_EVENT_ANALOG_3_CHAR_USER_DESCRIPTION_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_3_CHAR_USER_DESCRIPTION_IDX, BLE_SERVC_WRITE_RSP),
    BLE_AIOC_EVENT_ANALOG_3_CHAR_EXTENDED_PROPERTIES_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_3_CHAR_EXTENDED_PROPERTIES_IDX, BLE_SERVC_READ_RSP),
    BLE_AIOC_EVENT_ANALOG_3_VAL_TRIGGER_SETTING_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_3_VAL_TRIGGER_SETTING_IDX, BLE_SERVC_READ_RSP),
    BLE_AIOC_EVENT_ANALOG_3_VAL_TRIGGER_SETTING_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_3_VAL_TRIGGER_SETTING_IDX, BLE_SERVC_WRITE_RSP),
    BLE_AIOC_EVENT_ANALOG_3_TIME_TRIGGER_SETTING_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_3_TIME_TRIGGER_SETTING_IDX, BLE_SERVC_READ_RSP),
    BLE_AIOC_EVENT_ANALOG_3_TIME_TRIGGER_SETTING_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_3_TIME_TRIGGER_SETTING_IDX, BLE_SERVC_WRITE_RSP),
    BLE_AIOC_EVENT_ANALOG_3_VALID_RANGE_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_ANALOG_3_VALID_RANGE_IDX, BLE_SERVC_READ_RSP),
    /* Aggregate */
    BLE_AIOC_EVENT_AGGREGATE_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_AGGREGATE_IDX, BLE_SERVC_READ_RSP),
    BLE_AIOC_EVENT_AGGREGATE_HDL_VAL_NTF = BLE_SERVC_ATTR_EVENT(BLE_AIOC_AGGREGATE_IDX, BLE_SERVC_HDL_VAL_NTF),
    BLE_AIOC_EVENT_AGGREGATE_HDL_VAL_IND = BLE_SERVC_ATTR_EVENT(BLE_AIOC_AGGREGATE_IDX, BLE_SERVC_HDL_VAL_IND),
    BLE_AIOC_EVENT_AGGREGATE_CLI_CNFG_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_AGGREGATE_CLI_CNFG_IDX, BLE_SERVC_READ_RSP),
    BLE_AIOC_EVENT_AGGREGATE_CLI_CNFG_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_AIOC_AGGREGATE_CLI_CNFG_IDX, BLE_SERVC_WRITE_RSP),
} e_ble_aioc_event_t;

/***************************************************************************//**
 * @brief     Initialize Automation IO client.
 * @param[in] cb - Client callback.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_AIOC_Init(ble_servc_app_cb_t cb);

/***************************************************************************//**
 * @brief     Automation IO client discovery callback.
 * @param[in] conn_hdl - Connection handle
 * @param[in] serv_idx - Service instance index.
 * @param[in] type     - Service discovery event type.
 * @param[in] p_param  - Pointer to Service discovery event parameter.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_AIOC_ServDiscCb(uint16_t conn_hdl, uint8_t serv_idx, uint16_t type, void *p_param);

/***************************************************************************//**
 * @brief     Get Automation IO client attribute handle.
 * @param[in]  p_addr - Pointer to Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  - Pointer to store the retrieved attribute handles.
*******************************************************************************/
void R_BLE_AIOC_GetServAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_gatt_hdl_range_t *p_hdl);

#endif /* R_BLE_AIOC_H */

/** @} */
