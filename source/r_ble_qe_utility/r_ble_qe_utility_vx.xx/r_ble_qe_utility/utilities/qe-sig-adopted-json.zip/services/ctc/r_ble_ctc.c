/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_ctc.c
 * Version : 1.0
 * Description : The source file for Current Time Service client.
 **********************************************************************************************************************/
/***********************************************************************************************************************
   * History : DD.MM.YYYY Version Description
   *         : 24.05.2019 1.00 First Release
 ***********************************************************************************************************************/
#include <string.h>
#include "r_ble_ctc.h"
#include "profile_cmn/r_ble_servc_if.h"

static st_ble_servc_info_t gs_client_info;

/*----------------------------------------------------------------------------------------------------------------------
    Current Time Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Current Time characteristic descriptors attribute handles */
static uint16_t gs_cur_time_cli_cnfg_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_cur_time_cli_cnfg =
{
    .uuid_16     = BLE_CTC_CUR_TIME_CLI_CNFG_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint16_t),
    .db_size     = BLE_CTC_CUR_TIME_CLI_CNFG_LEN,
    .desc_idx    = BLE_CTC_CUR_TIME_CLI_CNFG_IDX,
    .p_attr_hdls = gs_cur_time_cli_cnfg_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_CTC_WriteCurTimeCliCnfg(uint16_t conn_hdl, const uint16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_cur_time_cli_cnfg, conn_hdl, p_value);
}

ble_status_t R_BLE_CTC_ReadCurTimeCliCnfg(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_cur_time_cli_cnfg, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Current Time Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Current Time characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_cur_time_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

static ble_status_t decode_st_ble_ctc_cur_time_t(st_ble_ctc_cur_time_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;

    if (BLE_CTC_CUR_TIME_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    memset((uint8_t*)p_app_value, 0x00, sizeof(*p_app_value));

    BT_UNPACK_LE_2_BYTE(&p_app_value->exact_time_256.date_time.year, &p_gatt_value->p_value[pos]);
    pos += 2;

    p_app_value->exact_time_256.date_time.month   = p_gatt_value->p_value[pos++];
    p_app_value->exact_time_256.date_time.day     = p_gatt_value->p_value[pos++];
    p_app_value->exact_time_256.date_time.hours   = p_gatt_value->p_value[pos++];
    p_app_value->exact_time_256.date_time.minutes = p_gatt_value->p_value[pos++];
    p_app_value->exact_time_256.date_time.seconds = p_gatt_value->p_value[pos++];
    p_app_value->exact_time_256.day_of_week       = p_gatt_value->p_value[pos++];
    p_app_value->exact_time_256.fractions256      = p_gatt_value->p_value[pos++];
    
    p_app_value->adjust_reason.is_manual_time_update             = !!(p_gatt_value->p_value[pos] & 0x01);
    p_app_value->adjust_reason.is_external_reference_time_update = !!(p_gatt_value->p_value[pos] & 0x02);
    p_app_value->adjust_reason.is_change_of_time_zone            = !!(p_gatt_value->p_value[pos] & 0x04);
    p_app_value->adjust_reason.is_change_of_dst                  = !!(p_gatt_value->p_value[pos] & 0x08);

    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_ctc_cur_time_t(const st_ble_ctc_cur_time_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos] ,&p_app_value->exact_time_256.date_time.year);
    pos += 2;

    p_gatt_value->p_value[pos++] = p_app_value->exact_time_256.date_time.month;
    p_gatt_value->p_value[pos++] = p_app_value->exact_time_256.date_time.day;
    p_gatt_value->p_value[pos++] = p_app_value->exact_time_256.date_time.hours;
    p_gatt_value->p_value[pos++] = p_app_value->exact_time_256.date_time.minutes;
    p_gatt_value->p_value[pos++] = p_app_value->exact_time_256.date_time.seconds;
    p_gatt_value->p_value[pos++] = p_app_value->exact_time_256.day_of_week;
    p_gatt_value->p_value[pos++] = p_app_value->exact_time_256.fractions256;

    p_gatt_value->p_value[pos] = (uint8_t)((p_app_value->adjust_reason.is_manual_time_update ? 0x01 : 0x00)
                               | (p_app_value->adjust_reason.is_external_reference_time_update ? 0x02 : 0x00)
                               | (p_app_value->adjust_reason.is_change_of_time_zone ? 0x04 : 0x00)
                               | (p_app_value->adjust_reason.is_change_of_dst ? 0x08 : 0x00));
    pos += 1;

    p_gatt_value->value_len = (uint16_t)pos;

    return BLE_SUCCESS;
}

/* Current Time characteristic descriptor definition */
static const st_ble_servc_desc_info_t *gspp_cur_time_descs[] = 
{
    &gs_cur_time_cli_cnfg,
};

/* Current Time characteristic definition */
const st_ble_servc_char_info_t gs_cur_time_char = 
{
    .uuid_16      = BLE_CTC_CUR_TIME_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_ctc_cur_time_t),
    .db_size      = BLE_CTC_CUR_TIME_LEN,
    .char_idx     = BLE_CTC_CUR_TIME_IDX,
    .p_attr_hdls  = gs_cur_time_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_ctc_cur_time_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_ctc_cur_time_t,
    .num_of_descs = ARRAY_SIZE(gspp_cur_time_descs),
    .pp_descs     = gspp_cur_time_descs,
};

ble_status_t R_BLE_CTC_WriteCurTime(uint16_t conn_hdl, const st_ble_ctc_cur_time_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteChar(&gs_cur_time_char, conn_hdl, p_value);
}

ble_status_t R_BLE_CTC_ReadCurTime(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_cur_time_char, conn_hdl);
}

void R_BLE_CTC_GetCurTimeAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_ctc_cur_time_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_cur_time_char_ranges[conn_idx];
    p_hdl->cli_cnfg_desc_hdl = gs_cur_time_cli_cnfg_desc_hdls[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Local Time Information Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Local Time Information characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_local_time_info_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

static ble_status_t decode_st_ble_ctc_local_time_info_t(st_ble_ctc_local_time_info_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;

    if (BLE_CTC_LOCAL_TIME_INFO_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    memset((uint8_t*)p_app_value, 0x00, sizeof(*p_app_value));

    p_app_value->time_zone                   = (int8_t)p_gatt_value->p_value[pos++];
    p_app_value->daylight_saving_time_offset = p_gatt_value->p_value[pos++];

    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_ctc_local_time_info_t(const st_ble_ctc_local_time_info_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;
    
    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);
    
    p_gatt_value->p_value[pos++] = (uint8_t)p_app_value->time_zone;
    p_gatt_value->p_value[pos++] = p_app_value->daylight_saving_time_offset;

    p_gatt_value->value_len = (uint16_t)pos;

    return BLE_SUCCESS;
}

/* Local Time Information characteristic definition */
const st_ble_servc_char_info_t gs_local_time_info_char = 
{
    .uuid_16      = BLE_CTC_LOCAL_TIME_INFO_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_ctc_local_time_info_t),
    .db_size      = BLE_CTC_LOCAL_TIME_INFO_LEN,
    .char_idx     = BLE_CTC_LOCAL_TIME_INFO_IDX,
    .p_attr_hdls  = gs_local_time_info_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_ctc_local_time_info_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_ctc_local_time_info_t,
};

ble_status_t R_BLE_CTC_WriteLocalTimeInfo(uint16_t conn_hdl, const st_ble_ctc_local_time_info_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteChar(&gs_local_time_info_char, conn_hdl, p_value);
}

ble_status_t R_BLE_CTC_ReadLocalTimeInfo(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_local_time_info_char, conn_hdl);
}

void R_BLE_CTC_GetLocalTimeInfoAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_ctc_local_time_info_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_local_time_info_char_ranges[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Reference Time Information Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Reference Time Information characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_ref_time_info_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

static ble_status_t decode_st_ble_ctc_ref_time_info_t(st_ble_ctc_ref_time_info_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;

    if (BLE_CTC_REF_TIME_INFO_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    memset((uint8_t*)p_app_value, 0x00, sizeof(*p_app_value));

    p_app_value->source                 = p_gatt_value->p_value[pos++];
    p_app_value->accuracy               = p_gatt_value->p_value[pos++];
    p_app_value->days_since_update      = p_gatt_value->p_value[pos++];
    p_app_value->hours_since_update     = p_gatt_value->p_value[pos++];
    
    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_ctc_ref_time_info_t(const st_ble_ctc_ref_time_info_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    p_gatt_value->p_value[pos++] = p_app_value->source;
    p_gatt_value->p_value[pos++] = p_app_value->accuracy;
    p_gatt_value->p_value[pos++] = p_app_value->days_since_update;
    p_gatt_value->p_value[pos++] = p_app_value->hours_since_update;
    p_gatt_value->value_len = (uint16_t)pos;

    return BLE_SUCCESS;
}

/* Reference Time Information characteristic definition */
const st_ble_servc_char_info_t gs_ref_time_info_char = 
{
    .uuid_16      = BLE_CTC_REF_TIME_INFO_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_ctc_ref_time_info_t),
    .db_size      = BLE_CTC_REF_TIME_INFO_LEN,
    .char_idx     = BLE_CTC_REF_TIME_INFO_IDX,
    .p_attr_hdls  = gs_ref_time_info_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_ctc_ref_time_info_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_ctc_ref_time_info_t,
};

ble_status_t R_BLE_CTC_ReadRefTimeInfo(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_ref_time_info_char, conn_hdl);
}

void R_BLE_CTC_GetRefTimeInfoAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_ctc_ref_time_info_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_ref_time_info_char_ranges[conn_idx];
}


/*----------------------------------------------------------------------------------------------------------------------
    Current Time Service client
----------------------------------------------------------------------------------------------------------------------*/

/* Current Time Service client attribute handles */
static st_ble_gatt_hdl_range_t gs_ctc_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

const st_ble_servc_char_info_t *gspp_ctc_chars[] = 
{
    &gs_cur_time_char,
    &gs_local_time_info_char,
    &gs_ref_time_info_char,
};

static st_ble_servc_info_t gs_client_info = 
{
    .pp_chars     = gspp_ctc_chars,
    .num_of_chars = ARRAY_SIZE(gspp_ctc_chars),
    .p_attr_hdls  = gs_ctc_ranges,
};

ble_status_t R_BLE_CTC_Init(ble_servc_app_cb_t cb) // @suppress("API function naming")
{
    if (NULL == cb)
    {
        return BLE_ERR_INVALID_PTR;
    }

    gs_client_info.cb = cb;

    return R_BLE_SERVC_RegisterClient(&gs_client_info);
}

void R_BLE_CTC_ServDiscCb(uint16_t conn_hdl, uint8_t serv_idx, uint16_t type, void *p_param) // @suppress("API function naming")
{
    R_BLE_SERVC_ServDiscCb(&gs_client_info, conn_hdl, serv_idx, type, p_param);
}

void R_BLE_CTC_GetServAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_gatt_hdl_range_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    *p_hdl = gs_ctc_ranges[conn_idx];
}
