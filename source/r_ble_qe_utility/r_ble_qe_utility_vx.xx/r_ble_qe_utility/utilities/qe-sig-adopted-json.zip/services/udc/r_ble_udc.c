/***********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
 * SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
 ***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_udc.c
 * Version : 1.0
 * Description : This module implements User Data Service Client.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 22.03.2019 1.00 First Release
 ***********************************************************************************************************************/

/***********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 ***********************************************************************************************************************/
#include <string.h>
#include "profile_cmn/r_ble_serv_common.h"
#include "r_ble_udc.h"
#include "discovery/r_ble_disc.h"

/***********************************************************************************************************************
 Macro definitions
 ***********************************************************************************************************************/
#ifndef UNUSED_ARG
#define UNUSED_ARG(arg)         (void)(arg)
#endif /* UNUSED_ARG */
#ifndef UNUSED_RET
#define UNUSED_RET(ret)         (void)(ret)
#endif /* UNUSED_RET */

/* Version number */
#define BLE_UDC_PRV_VERSION_MAJOR          (1)
#define BLE_UDC_PRV_VERSION_MINOR          (0)

#define BLE_UDC_PRV_CONNECTION_COUNT       (7)

/***********************************************************************************************************************
 Typedef definitions
 ***********************************************************************************************************************/
typedef struct
{
    uint16_t          conn_hdl;
    st_ble_udc_hdls_t hdls;
} st_udc_peer_param_t;

typedef enum
{
    BLE_UDC_FIRST_NAME_READ    = 0,  /**< Long Read for First Name */
    BLE_UDC_LAST_NAME_READ     = 1,  /**< Long Read for Last Name */
    BLE_UDC_EMAIL_ADDRESS_READ = 2,  /**< Long Read for Email Address */
    BLE_UDC_LANGUAGE_READ      = 3,  /**< Long Read for FLanguage */
    BLE_UDC_UNKNOWN_READ       = 4
} e_udc_long_char_read_t;

typedef enum
{
    BLE_UDC_FIRST_NAME_WRITE    = 0,  /**< Long Write for First Name */
    BLE_UDC_LAST_NAME_WRITE     = 1,  /**< Long Write for Last Name */
    BLE_UDC_EMAIL_ADDRESS_WRITE = 2,  /**< Long Write for Email Address */
    BLE_UDC_LANGUAGE_WRITE      = 3,  /**< Long Write for FLanguage */
    BLE_UDC_UNKNOWN_WRITE       = 4
} e_udc_long_char_write_t;

/***********************************************************************************************************************
 Exported global variables (to be accessed by other files)
 ***********************************************************************************************************************/
const uint8_t BLE_UDC_UUID[BLE_GATT_16_BIT_UUID_SIZE]                                                 = { 0x1C, 0x18 };
const uint8_t BLE_UDC_FIRST_NAME_UUID[BLE_GATT_16_BIT_UUID_SIZE]                                      = { 0x8A, 0x2A };
const uint8_t BLE_UDC_LAST_NAME_UUID[BLE_GATT_16_BIT_UUID_SIZE]                                       = { 0x90, 0x2A };
const uint8_t BLE_UDC_EMAIL_ADDRESS_UUID[BLE_GATT_16_BIT_UUID_SIZE]                                   = { 0x87, 0x2A };
const uint8_t BLE_UDC_AGE_UUID[BLE_GATT_16_BIT_UUID_SIZE]                                             = { 0x80, 0x2A };
const uint8_t BLE_UDC_DATE_OF_BIRTH_UUID[BLE_GATT_16_BIT_UUID_SIZE]                                   = { 0x85, 0x2A };
const uint8_t BLE_UDC_GENDER_UUID[BLE_GATT_16_BIT_UUID_SIZE]                                          = { 0x8C, 0x2A };
const uint8_t BLE_UDC_WEIGHT_UUID[BLE_GATT_16_BIT_UUID_SIZE]                                          = { 0x98, 0x2A };
const uint8_t BLE_UDC_HEIGHT_UUID[BLE_GATT_16_BIT_UUID_SIZE]                                          = { 0x8E, 0x2A };
const uint8_t BLE_UDC_VO2_MAX_UUID[BLE_GATT_16_BIT_UUID_SIZE]                                         = { 0x96, 0x2A };
const uint8_t BLE_UDC_HEART_RATE_MAX_UUID[BLE_GATT_16_BIT_UUID_SIZE]                                  = { 0x8D, 0x2A };
const uint8_t BLE_UDC_RESTING_HEART_RATE_UUID[BLE_GATT_16_BIT_UUID_SIZE]                              = { 0x92, 0x2A };
const uint8_t BLE_UDC_MAXIMUM_RECOMMENDED_HEART_RATE_UUID[BLE_GATT_16_BIT_UUID_SIZE]                  = { 0x91, 0x2A };
const uint8_t BLE_UDC_AEROBIC_THRESHOLD_UUID[BLE_GATT_16_BIT_UUID_SIZE]                               = { 0x7F, 0x2A };
const uint8_t BLE_UDC_ANAEROBIC_THRESHOLD_UUID[BLE_GATT_16_BIT_UUID_SIZE]                             = { 0x83, 0x2A };
const uint8_t BLE_UDC_SPORT_TYPE_FOR_AEROBIC_AND_ANAEROBIC_THRESHOLDS_UUID[BLE_GATT_16_BIT_UUID_SIZE] = { 0x93, 0x2A };
const uint8_t BLE_UDC_DATE_OF_THRESHOLD_ASSESSMENT_UUID[BLE_GATT_16_BIT_UUID_SIZE]                    = { 0x86, 0x2A };
const uint8_t BLE_UDC_WAIST_CIRCUMFERENCE_UUID[BLE_GATT_16_BIT_UUID_SIZE]                             = { 0x97, 0x2A };
const uint8_t BLE_UDC_HIP_CIRCUMFERENCE_UUID[BLE_GATT_16_BIT_UUID_SIZE]                               = { 0x8F, 0x2A };
const uint8_t BLE_UDC_FAT_BURN_HEART_RATE_LOWER_LIMIT_UUID[BLE_GATT_16_BIT_UUID_SIZE]                 = { 0x88, 0x2A };
const uint8_t BLE_UDC_FAT_BURN_HEART_RATE_UPPER_LIMIT_UUID[BLE_GATT_16_BIT_UUID_SIZE]                 = { 0x89, 0x2A };
const uint8_t BLE_UDC_AEROBIC_HEART_RATE_LOWER_LIMIT_UUID[BLE_GATT_16_BIT_UUID_SIZE]                  = { 0x7E, 0x2A };
const uint8_t BLE_UDC_AEROBIC_HEART_RATE_UPPER_LIMIT_UUID[BLE_GATT_16_BIT_UUID_SIZE]                  = { 0x84, 0x2A };
const uint8_t BLE_UDC_ANAEROBIC_HEART_RATE_LOWER_LIMIT_UUID[BLE_GATT_16_BIT_UUID_SIZE]                = { 0x81, 0x2A };
const uint8_t BLE_UDC_ANAEROBIC_HEART_RATE_UPPER_LIMIT_UUID[BLE_GATT_16_BIT_UUID_SIZE]                = { 0x82, 0x2A };
const uint8_t BLE_UDC_FIVE_ZONE_HEART_RATE_LIMITS_UUID[BLE_GATT_16_BIT_UUID_SIZE]                     = { 0x8B, 0x2A };
const uint8_t BLE_UDC_THREE_ZONE_HEART_RATE_LIMITS_UUID[BLE_GATT_16_BIT_UUID_SIZE]                    = { 0x94, 0x2A };
const uint8_t BLE_UDC_TWO_ZONE_HEART_RATE_LIMIT_UUID[BLE_GATT_16_BIT_UUID_SIZE]                       = { 0x95, 0x2A };
const uint8_t BLE_UDC_DATABASE_CHANGE_INCREMENT_UUID[BLE_GATT_16_BIT_UUID_SIZE]                       = { 0x99, 0x2A };
const uint8_t BLE_UDC_DATABASE_CHANGE_INCREMENT_CLIENT_CHARACTERISTIC_CONFIGURATION_UUID[BLE_GATT_16_BIT_UUID_SIZE] =
                                                                                                        { 0x02, 0x29 };
const uint8_t BLE_UDC_USER_INDEX_UUID[BLE_GATT_16_BIT_UUID_SIZE]                                      = { 0x9A, 0x2A };
const uint8_t BLE_UDC_USER_CONTROL_POINT_UUID[BLE_GATT_16_BIT_UUID_SIZE]                              = { 0x9F, 0x2A };
const uint8_t BLE_UDC_USER_CONTROL_POINT_CLIENT_CHARACTERISTIC_CONFIGURATION_UUID[BLE_GATT_16_BIT_UUID_SIZE] = 
                                                                                                        { 0x02, 0x29 };
const uint8_t BLE_UDC_LANGUAGE_UUID[BLE_GATT_16_BIT_UUID_SIZE]                                        = { 0xA2, 0x2A };

/***********************************************************************************************************************
 Private global variables and functions
 ***********************************************************************************************************************/
static st_udc_peer_param_t gs_peer_params[BLE_UDC_PRV_CONNECTION_COUNT];
static ble_udc_app_cb_t gs_udc_cb;

static st_ble_udc_first_name_t gs_udc_first_name;
static st_ble_udc_last_name_t gs_udc_last_name;
static st_ble_udc_email_address_t gs_udc_email_address;
static st_ble_udc_language_t gs_udc_language;
static bool gs_read_first_part = true;
static uint16_t gs_read_offset = 0;
static uint8_t gs_current_long_read_char;
static uint8_t gs_current_long_write_char;

/***********************************************************************************************************************
 * Function Name: find_peer_param
 * Description  : This function finds the attribute handles for the given connection handle.
 * Arguments    : conn_hdl - handle to connection
 * Return Value : pointer to the attribute handles structure
 **********************************************************************************************************************/
static st_udc_peer_param_t *find_peer_param (uint16_t conn_hdl)
{
    for (uint8_t i = 0; i < BLE_UDC_PRV_CONNECTION_COUNT; i++)
    {
        if ((BLE_GAP_INVALID_CONN_HDL != gs_peer_params[i].conn_hdl) && (gs_peer_params[i].conn_hdl == conn_hdl))
        {
            return &gs_peer_params[i];
        }
    }
    return NULL;
}

/***********************************************************************************************************************
 * Function Name: get_new_peer_param
 * Description  : This function finds the free attribute handle.
 * Arguments    : conn_hdl - handle to connection.
 * Return Value : pointer to the free attribute handles structure
 **********************************************************************************************************************/
static st_udc_peer_param_t *get_new_peer_param (uint16_t conn_hdl)
{
    for (uint8_t i = 0; i < BLE_UDC_PRV_CONNECTION_COUNT; i++)
    {
        if (BLE_GAP_INVALID_CONN_HDL == gs_peer_params[i].conn_hdl)
        {
            gs_peer_params[i].conn_hdl = conn_hdl;
            return &gs_peer_params[i];
        }
    }
    return NULL;
}

/***********************************************************************************************************************
 * Function Name: clear_peer_param
 * Description  : This function frees all the attribute handles.
 * Arguments    : p_peer - pointer to the attribute handle structure to be freed
 * Return Value : none
 ***********************************************************************************************************************/
static void clear_peer_param (st_udc_peer_param_t *p_peer)
{
    if (NULL != p_peer)
    {
        p_peer->conn_hdl = BLE_GAP_INVALID_CONN_HDL;
        memset( &p_peer->hdls, 0x00, sizeof(p_peer->hdls));
    }
}

/***********************************************************************************************************************
 * Function Name: encode_first_name
 * Description  : This function converts First Name characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the First Name  value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_first_name (const st_ble_udc_first_name_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    /* Clear the gatt_value byte array */
    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    strncpy((char*)p_gatt_value->p_value, (const char*)p_app_value->first_name, BLE_UDC_FIRST_NAME_LEN);

    /* Type case size_t to uint16_t */
    p_gatt_value->value_len = (uint16_t)(strlen((const char*)p_app_value->first_name));

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: decode_first_name
 * Description  : This function converts First Name characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the First Name value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_first_name (st_ble_udc_first_name_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    ble_status_t ret = BLE_SUCCESS;

    if (BLE_UDC_FIRST_NAME_LEN < p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Clear the first name string */
    memset(p_app_value->first_name, 0x00, BLE_UDC_FIRST_NAME_LEN);

    strncpy((char*)p_app_value->first_name, (const char*)p_gatt_value->p_value, p_gatt_value->value_len);

    /*check the length */
    if (p_gatt_value->value_len != strlen((const char*)p_app_value->first_name))
    {
        ret = BLE_ERR_INVALID_DATA;
    }

    return ret;
}

/***********************************************************************************************************************
 * Function Name: encode_last_name
 * Description  : This function converts Last Name characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the Last Name  value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_last_name (const st_ble_udc_last_name_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    /* Clear the gatt_value byte array */
    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    strncpy((char*)p_gatt_value->p_value, (const char*)p_app_value->last_name, BLE_UDC_LAST_NAME_LEN);

    /* Type case size_t to uint16_t */
    p_gatt_value->value_len = (uint16_t)(strlen((const char*)p_app_value->last_name));

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: decode_last_name
 * Description  : This function converts Last Name characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the Last Name value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_last_name (st_ble_udc_last_name_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    ble_status_t ret = BLE_SUCCESS;

    if (BLE_UDC_LAST_NAME_LEN < p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Clear the last name string */
    memset(p_app_value->last_name, 0x00, BLE_UDC_LAST_NAME_LEN);

    strncpy((char*)p_app_value->last_name, (const char*)p_gatt_value->p_value, p_gatt_value->value_len);

    /*check the length */
    if (p_gatt_value->value_len != strlen((const char*)p_app_value->last_name))
    {
        ret = BLE_ERR_INVALID_DATA;
    }

    return ret;
}

/***********************************************************************************************************************
 * Function Name: encode_email_address
 * Description  : This function converts Email Address characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the Email Address  value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_email_address (const st_ble_udc_email_address_t *p_app_value,
        st_ble_gatt_value_t *p_gatt_value)
{
    /* Clear the gatt_value byte array */
    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    /* Copy the email address string */
    strncpy((char*)p_gatt_value->p_value, (const char*)p_app_value->email_address, BLE_UDC_EMAIL_ADDRESS_LEN);

    /* Type case size_t to uint16_t */
    p_gatt_value->value_len = (uint16_t)(strlen((const char*)p_app_value->email_address));

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: decode_email_address
 * Description  : This function converts Email Address characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the Email Address value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_email_address (st_ble_udc_email_address_t *p_app_value,
        const st_ble_gatt_value_t *p_gatt_value)
{
    ble_status_t ret = BLE_SUCCESS;

    if (BLE_UDC_EMAIL_ADDRESS_LEN < p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Clear the mail address string */
    memset(p_app_value->email_address, 0x00, BLE_UDC_EMAIL_ADDRESS_LEN);

    strncpy((char*)p_app_value->email_address, (const char*)p_gatt_value->p_value, p_gatt_value->value_len);

    /*check the length */
    if (p_gatt_value->value_len != strlen((const char*)p_app_value->email_address))
    {
        ret = BLE_ERR_INVALID_DATA;
    }

    return ret;
}

/***********************************************************************************************************************
 * Function Name: encode_date_of_birth
 * Description  : This function converts Date of Birth characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the Date of Birth  value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_date_of_birth (const st_ble_udc_date_of_birth_t *p_app_value,
        st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;

    /* Clear the gatt_db byte array */
    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    /* Copy the year */
    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->year);
    pos += 2;

    /* Copy the Month */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->month);

    /* Copy the Day */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->day);

    /* Update the value_len */
    p_gatt_value->value_len = (uint16_t)pos;

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: decode_date_of_birth
 * Description  : This function converts Date of Birth characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the Date of Birth value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_date_of_birth (st_ble_udc_date_of_birth_t *p_app_value,
        const st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;

    if (BLE_UDC_DATE_OF_BIRTH_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Clear the app_value structure */
    memset(p_app_value, 0x00, sizeof(st_ble_udc_date_of_birth_t));

    /* Copy the year */
    BT_UNPACK_LE_2_BYTE(&(p_app_value->year), &(p_gatt_value->p_value[pos]));
    pos += 2;

    /* Copy the Month */
    BT_UNPACK_LE_1_BYTE(&p_app_value->month, &(p_gatt_value->p_value[pos++]));

    /* Copy the Day */
    BT_UNPACK_LE_1_BYTE(&p_app_value->day, &(p_gatt_value->p_value[pos++]));

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_date_of_threshold_assessment
 * Description  : This function converts Date of Threshold Assessment characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the Date of Threshold Assessment  value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_date_of_threshold_assessment (const st_ble_udc_date_of_threshold_assessment_t *p_app_value,
        st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;

    /* Clear the gatt_db byte array */
    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    /* Copy the year */
    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->year);
    pos += 2;

    /* Copy the Month */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->month);

    /* Copy the Day */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->day);

    /* Update the value_len */
    p_gatt_value->value_len = (uint16_t)pos;

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: decode_date_of_threshold_assessment
 * Description  : This function converts Date of Threshold Assessment characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the Date of Threshold Assessment value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_date_of_threshold_assessment (st_ble_udc_date_of_threshold_assessment_t *p_app_value,
        const st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;

    if (BLE_UDC_DATE_OF_THRESHOLD_ASSESSMENT_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Clear the app_value structure */
    memset(p_app_value, 0x00, sizeof(st_ble_udc_date_of_threshold_assessment_t));

    /* Copy the year */
    BT_UNPACK_LE_2_BYTE(&p_app_value->year, &(p_gatt_value->p_value[pos]));
    pos += 2;

    /* Copy the Month */
    BT_UNPACK_LE_1_BYTE(&p_app_value->month, &(p_gatt_value->p_value[pos++]));

    /* Copy the Day */
    BT_UNPACK_LE_1_BYTE(&p_app_value->day, &(p_gatt_value->p_value[pos++]));

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_five_zone_heart_rate_limits
 * Description  : This function converts Five Zone Heart Rate Limits characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the Five Zone Heart Rate Limits  value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_five_zone_heart_rate_limits (const st_ble_udc_five_zone_heart_rate_limits_t *p_app_value,
        st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;

    /* Clear the gatt_value byte array */
    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    /* Copy all the heart rate limits values */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], 
        &p_app_value->five_zone_heart_rate_limits___very_light___light_limit);
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], 
        &p_app_value->five_zone_heart_rate_limits___light___moderate_limit);
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->five_zone_heart_rate_limits___moderate___hard_limit);
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->five_zone_heart_rate_limits___hard___maximum_limit);

    /* Update the value_len byte */
    p_gatt_value->value_len = (uint16_t)pos;

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: decode_five_zone_heart_rate_limits
 * Description  : This function converts Five Zone Heart Rate Limits characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the Five Zone Heart Rate Limits value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_five_zone_heart_rate_limits (st_ble_udc_five_zone_heart_rate_limits_t *p_app_value,
        const st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;

    if (BLE_UDC_FIVE_ZONE_HEART_RATE_LIMITS_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Clear the gatt_value byte array */
    memset(p_app_value, 0x00, sizeof(st_ble_udc_five_zone_heart_rate_limits_t));

    /* Copy all the heart rate limits values */
    BT_UNPACK_LE_1_BYTE(&p_app_value->five_zone_heart_rate_limits___very_light___light_limit,
        &p_gatt_value->p_value[pos++]);
    BT_UNPACK_LE_1_BYTE(&p_app_value->five_zone_heart_rate_limits___light___moderate_limit,
        &p_gatt_value->p_value[pos++]);
    BT_UNPACK_LE_1_BYTE(&p_app_value->five_zone_heart_rate_limits___moderate___hard_limit,
        &p_gatt_value->p_value[pos++]);
    BT_UNPACK_LE_1_BYTE(&p_app_value->five_zone_heart_rate_limits___hard___maximum_limit,
        &p_gatt_value->p_value[pos++]);

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_three_zone_heart_rate_limits
 * Description  : This function converts Three Zone Heart Rate Limits characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the Three Zone Heart Rate Limits  value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_three_zone_heart_rate_limits (const st_ble_udc_three_zone_heart_rate_limits_t *p_app_value,
        st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;

    /* Clear the gatt_value byte array */
    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    /* Copy all the heart rate limits values */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++],
        &p_app_value->three_zone_heart_rate_limits___light__fat_burn____moderate__aerobic__limit);
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++],
        &p_app_value->three_zone_heart_rate_limits___moderate__aerobic____hard__anaerobic__limit);

    /* Update the value_len byte */
    p_gatt_value->value_len = (uint16_t)pos;

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: decode_three_zone_heart_rate_limits
 * Description  : This function converts Three Zone Heart Rate Limits characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the Three Zone Heart Rate Limits value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_three_zone_heart_rate_limits (st_ble_udc_three_zone_heart_rate_limits_t *p_app_value,
        const st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;

    if (BLE_UDC_THREE_ZONE_HEART_RATE_LIMITS_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Clear the gatt_value byte array */
    memset(p_app_value, 0x00, sizeof(st_ble_udc_three_zone_heart_rate_limits_t));

    /* Copy all the heart rate limits values */
    BT_UNPACK_LE_1_BYTE(&p_app_value->three_zone_heart_rate_limits___light__fat_burn____moderate__aerobic__limit,
        &p_gatt_value->p_value[pos++]);
    BT_UNPACK_LE_1_BYTE(&p_app_value->three_zone_heart_rate_limits___moderate__aerobic____hard__anaerobic__limit,
        &p_gatt_value->p_value[pos++]);

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_user_control_point
 * Description  : This function converts User Control Point characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the User Control Point  value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_user_control_point (const st_ble_udc_user_control_point_t *p_app_value,
        st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;

    /* Clear the gatt_value byte sequence */
    memset(p_gatt_value->p_value, 0x0, BLE_UDC_USER_CONTROL_POINT_LEN);

    /* Copy the Op Code */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->opcode);

    /* Copy the parameter */
    if (BLE_UDC_USER_CONTROL_POINT_OPCODE_REGISTER_NEW_USER == p_app_value->opcode)
    {
        /* Copy the Consent Code */
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->consent_code);
        pos += 2;
    }
    else if (BLE_UDC_USER_CONTROL_POINT_OPCODE_CONSENT == p_app_value->opcode)
    {
        /* Copy the User Index and the Consent Code for the User */
        BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->user_index);
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->consent_code);
        pos += 2;
    }
    else
    {
        /* BLE_UDS_USER_CONTROL_POINT_OPCODE_DELETE_USER_DATA or Not a valid Op Code. */
        /* Do Nothing */
    }
    
    /* Update the length */
    p_gatt_value->value_len = (uint16_t)pos;

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: decode_user_control_point
 * Description  : This function converts User Control Point characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the User Control Point value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_user_control_point (st_ble_udc_user_control_point_t *p_app_value,
        const st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;
    ble_status_t ret = BLE_SUCCESS;

    /* Clear the gatt_value byte sequence */
    memset(p_app_value, 0x0, sizeof(st_ble_udc_user_control_point_t));

    /* Copy the Response Code */
    BT_UNPACK_LE_1_BYTE(&p_app_value->response_code, &p_gatt_value->p_value[pos++]);

    /* Copy the Request Op Code */
    BT_UNPACK_LE_1_BYTE(&p_app_value->request_opcode, &p_gatt_value->p_value[pos++]);

    /* Copy the Response Value */
    BT_UNPACK_LE_1_BYTE(&p_app_value->response_value, &p_gatt_value->p_value[pos++]);

    /* Copy the Response Parameter if applicable */
    if (BLE_UDC_USER_CONTROL_POINT_OPCODE_REGISTER_NEW_USER == p_app_value->request_opcode)
    {
        /* Copy the User Index for the new record */
        BT_UNPACK_LE_1_BYTE(&p_app_value->user_index, &p_gatt_value->p_value[pos++]);
    }

    if (p_gatt_value->value_len != pos)
    {
        ret = BLE_ERR_INVALID_DATA;
    }

    return ret;
}

/***********************************************************************************************************************
 * Function Name: encode_language
 * Description  : This function converts Language characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the Language  value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_language (const st_ble_udc_language_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    /* Clear the gatt_value byte array */
    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    strncpy((char*)p_gatt_value->p_value, (const char*)p_app_value->language, BLE_UDC_LANGUAGE_LEN);

    /* Type case size_t to uint16_t */
    p_gatt_value->value_len = (uint16_t)(strlen((const char*)p_app_value->language));

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: decode_language
 * Description  : This function converts Language characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the Language value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_language (st_ble_udc_language_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    ble_status_t ret = BLE_SUCCESS;

    if (BLE_UDC_LANGUAGE_LEN < p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Clear the app_value language string */
    memset(p_app_value->language, 0x00, BLE_UDC_LANGUAGE_LEN);

    strncpy((char*)p_app_value->language, (const char*)p_gatt_value->p_value, p_gatt_value->value_len);

    /*check the length */
    if (p_gatt_value->value_len != strlen((const char*)p_app_value->language))
    {
        ret = BLE_ERR_INVALID_DATA;
    }

    return ret;
}

/***********************************************************************************************************************
 * Function Name: udc_gattc_cb
 * Description  : Callback function for the User Data GATTC events.
 * Arguments    : conn_hdl - handle to the connection
 *                result - ble status
 *              : p_data - pointer to GATTC event data
 * Return Value : none
 ***********************************************************************************************************************/
static void udc_gattc_cb (uint16_t type, ble_status_t result, st_ble_gattc_evt_data_t *p_data) // @suppress("Function length")
{
    st_udc_peer_param_t *p_peer = find_peer_param(p_data->conn_hdl);

    switch (type)
    {
        case BLE_GATTC_EVENT_CHAR_PART_READ_RSP:
        {
            /* Partial read, append to the first name */
            st_ble_gattc_rd_char_evt_t *p_rd_char_evt_param = (st_ble_gattc_rd_char_evt_t *)p_data->p_param;

            if (p_rd_char_evt_param->read_data.attr_hdl == p_peer->hdls.first_name_char_val_hdl)
            {
                ble_status_t ret;
                st_ble_udc_first_name_t app_value;

                if (gs_read_first_part)
                {
                    gs_read_offset     = 0;
                    gs_read_first_part = false;
                    memset(gs_udc_first_name.first_name, 0x00, BLE_UDC_FIRST_NAME_LEN);
                }

                gs_current_long_read_char = (uint8_t)BLE_UDC_FIRST_NAME_READ;

                ret = decode_first_name(&app_value, &p_rd_char_evt_param->read_data.value);
                UNUSED_RET(ret);

                /*
                st_ble_udc_evt_data_t evt_data =
                {
                    .conn_hdl  = p_data->conn_hdl,
                    .param_len = sizeof(app_value),
                    .p_param   = &app_value,
                };
                */
            
                /* Append to the first name string */
                strcat((char*)&gs_udc_first_name.first_name[gs_read_offset], (const char*)app_value.first_name);
                gs_read_offset = (uint16_t)strlen((const char*)gs_udc_first_name.first_name);
            }
            else if (p_rd_char_evt_param->read_data.attr_hdl == p_peer->hdls.last_name_char_val_hdl)
            {
                ble_status_t ret;
                st_ble_udc_last_name_t app_value;

                if (gs_read_first_part)
                {
                    gs_read_offset     = 0;
                    gs_read_first_part = false;
                    memset(gs_udc_last_name.last_name, 0x00, BLE_UDC_LAST_NAME_LEN);
                }

                gs_current_long_read_char = (uint8_t)BLE_UDC_LAST_NAME_READ;

                ret = decode_last_name(&app_value, &p_rd_char_evt_param->read_data.value);
                UNUSED_RET(ret);

                /*
                st_ble_udc_evt_data_t evt_data =
                {
                    .conn_hdl  = p_data->conn_hdl,
                    .param_len = sizeof(app_value),
                    .p_param   = &app_value,
                };
                */

                /* Append to the last name string */
                strcat((char*)&gs_udc_last_name.last_name[gs_read_offset], (const char*)app_value.last_name);
                gs_read_offset = (uint16_t)strlen((const char*)gs_udc_last_name.last_name);
            }
            else if (p_rd_char_evt_param->read_data.attr_hdl == p_peer->hdls.email_address_char_val_hdl)
            {
                ble_status_t ret;
                st_ble_udc_email_address_t app_value;

                if (gs_read_first_part)
                {
                    gs_read_offset     = 0;
                    gs_read_first_part = false;
                    memset(gs_udc_email_address.email_address, 0x00, BLE_UDC_EMAIL_ADDRESS_LEN);
                }

                gs_current_long_read_char = (uint8_t)BLE_UDC_EMAIL_ADDRESS_READ;

                ret = decode_email_address(&app_value, &p_rd_char_evt_param->read_data.value);
                UNUSED_RET(ret);

                /*
                st_ble_udc_evt_data_t evt_data =
                {
                    .conn_hdl  = p_data->conn_hdl,
                    .param_len = sizeof(app_value),
                    .p_param   = &app_value,
                };
                */

                /* Append to the first name string */
                strcat((char*)&gs_udc_email_address.email_address[gs_read_offset], (const char*)app_value.email_address);
                gs_read_offset = (uint16_t)strlen((const char*)gs_udc_email_address.email_address);
            }
            else if (p_rd_char_evt_param->read_data.attr_hdl == p_peer->hdls.language_char_val_hdl)
            {
                ble_status_t ret;
                st_ble_udc_language_t app_value;

                if (gs_read_first_part)
                {
                    gs_read_offset     = 0;
                    gs_read_first_part = false;
                    memset(gs_udc_language.language, 0x00, BLE_UDC_LANGUAGE_LEN);
                }

                gs_current_long_read_char = (uint8_t)BLE_UDC_LANGUAGE_READ;

                ret = decode_language(&app_value, &p_rd_char_evt_param->read_data.value);
                UNUSED_RET(ret);

                /*
                st_ble_udc_evt_data_t evt_data =
                {
                    .conn_hdl  = p_data->conn_hdl,
                    .param_len = sizeof(app_value),
                    .p_param   = &app_value,
                };
                */

                /* Append to the first name string */
                strcat((char*)&gs_udc_language.language[gs_read_offset], (const char*)app_value.language);
                gs_read_offset = (uint16_t)strlen((const char*)gs_udc_language.language);
            }
            else
            {
                /* Do Nothing */
            }
        }
        break;

        case BLE_GATTC_EVENT_LONG_CHAR_READ_COMP:
        {
            /* TODO: Read completed.
             How to check char_val_hdl since the pointer is NULL ?? */
            
            if(BLE_UDC_FIRST_NAME_READ == gs_current_long_read_char)
            {
                st_ble_udc_evt_data_t evt_data =
                {
                    .conn_hdl  = p_data->conn_hdl,
                    .param_len = sizeof(gs_udc_first_name),
                    .p_param   = &gs_udc_first_name,
                };
                gs_udc_cb(BLE_UDC_EVENT_FIRST_NAME_READ_RSP, BLE_SUCCESS, &evt_data);

                gs_read_first_part        = true;
                gs_read_offset            = 0;
                gs_current_long_read_char = BLE_UDC_UNKNOWN_READ;
            }
            else if (BLE_UDC_LAST_NAME_READ == gs_current_long_read_char)
            {
                st_ble_udc_evt_data_t evt_data =
                {
                    .conn_hdl  = p_data->conn_hdl,
                    .param_len = sizeof(gs_udc_last_name),
                    .p_param   = &gs_udc_last_name,
                };
                gs_udc_cb(BLE_UDC_EVENT_LAST_NAME_READ_RSP, BLE_SUCCESS, &evt_data);

                gs_read_first_part        = true;
                gs_read_offset            = 0;
                gs_current_long_read_char = BLE_UDC_UNKNOWN_READ;
            }
            else if (BLE_UDC_EMAIL_ADDRESS_READ == gs_current_long_read_char)
            {
                st_ble_udc_evt_data_t evt_data =
                {
                    .conn_hdl  = p_data->conn_hdl,
                    .param_len = sizeof(gs_udc_email_address),
                    .p_param   = &gs_udc_email_address,
                };
                gs_udc_cb(BLE_UDC_EVENT_EMAIL_ADDRESS_READ_RSP, BLE_SUCCESS, &evt_data);

                gs_read_first_part        = true;
                gs_read_offset            = 0;
                gs_current_long_read_char = BLE_UDC_UNKNOWN_READ;
            }
            else if (BLE_UDC_LANGUAGE_READ == gs_current_long_read_char)
            {
                st_ble_udc_evt_data_t evt_data =
                {
                    .conn_hdl = p_data->conn_hdl,
                    .param_len = sizeof(gs_udc_language),
                    .p_param = &gs_udc_language,
                };
                gs_udc_cb(BLE_UDC_EVENT_LANGUAGE_READ_RSP, BLE_SUCCESS, &evt_data);

                gs_read_first_part        = true;
                gs_read_offset            = 0;
                gs_current_long_read_char = BLE_UDC_UNKNOWN_READ;
            }
            else
            {
                /* Do Nothing */
            }
        }
        break;

        case BLE_GATTC_EVENT_CHAR_READ_RSP:
        {
            st_ble_gattc_rd_char_evt_t *p_rd_char_evt_param = (st_ble_gattc_rd_char_evt_t *) p_data->p_param;

            if (p_rd_char_evt_param->read_data.attr_hdl == p_peer->hdls.age_char_val_hdl)
            {
                uint8_t app_value;

                BT_UNPACK_LE_1_BYTE( &app_value, p_rd_char_evt_param->read_data.value.p_value);

                st_ble_udc_evt_data_t evt_data =
                { 
                    .conn_hdl  = p_data->conn_hdl, 
                    .param_len = sizeof(app_value), 
                    .p_param   = &app_value, 
                };
                gs_udc_cb(BLE_UDC_EVENT_AGE_READ_RSP, result, &evt_data);
            }
            else if (p_rd_char_evt_param->read_data.attr_hdl == p_peer->hdls.date_of_birth_char_val_hdl)
            {
                ble_status_t ret;
                st_ble_udc_date_of_birth_t app_value;

                ret = decode_date_of_birth( &app_value, &p_rd_char_evt_param->read_data.value);

                st_ble_udc_evt_data_t evt_data =
                { 
                    .conn_hdl  = p_data->conn_hdl, 
                    .param_len = sizeof(app_value), 
                    .p_param   = &app_value, 
                };
                gs_udc_cb(BLE_UDC_EVENT_DATE_OF_BIRTH_READ_RSP, ret, &evt_data);
            }
            else if (p_rd_char_evt_param->read_data.attr_hdl == p_peer->hdls.gender_char_val_hdl)
            {
                uint8_t app_value;
                BT_UNPACK_LE_1_BYTE( &app_value, p_rd_char_evt_param->read_data.value.p_value);

                st_ble_udc_evt_data_t evt_data =
                { 
                    .conn_hdl  = p_data->conn_hdl, 
                    .param_len = sizeof(app_value), 
                    .p_param   = &app_value, 
                };
                gs_udc_cb(BLE_UDC_EVENT_GENDER_READ_RSP, result, &evt_data);
            }
            else if (p_rd_char_evt_param->read_data.attr_hdl == p_peer->hdls.weight_char_val_hdl)
            {
                uint16_t app_value;
                BT_UNPACK_LE_2_BYTE( &app_value, p_rd_char_evt_param->read_data.value.p_value);

                st_ble_udc_evt_data_t evt_data =
                { 
                    .conn_hdl  = p_data->conn_hdl, 
                    .param_len = sizeof(app_value), 
                    .p_param   = &app_value, 
                };
                gs_udc_cb(BLE_UDC_EVENT_WEIGHT_READ_RSP, result, &evt_data);
            }
            else if (p_rd_char_evt_param->read_data.attr_hdl == p_peer->hdls.height_char_val_hdl)
            {
                uint16_t app_value;
                BT_UNPACK_LE_2_BYTE( &app_value, p_rd_char_evt_param->read_data.value.p_value);

                st_ble_udc_evt_data_t evt_data =
                { 
                    .conn_hdl  = p_data->conn_hdl,
                    .param_len = sizeof(app_value),
                    .p_param   = &app_value, 
                };
                gs_udc_cb(BLE_UDC_EVENT_HEIGHT_READ_RSP, result, &evt_data);
            }
            else if (p_rd_char_evt_param->read_data.attr_hdl == p_peer->hdls.vo2_max_char_val_hdl)
            {
                uint8_t app_value;
                BT_UNPACK_LE_1_BYTE( &app_value, p_rd_char_evt_param->read_data.value.p_value);

                st_ble_udc_evt_data_t evt_data =
                { 
                    .conn_hdl  = p_data->conn_hdl, 
                    .param_len = sizeof(app_value), 
                    .p_param   = &app_value, 
                };
                gs_udc_cb(BLE_UDC_EVENT_VO2_MAX_READ_RSP, result, &evt_data);
            }
            else if (p_rd_char_evt_param->read_data.attr_hdl == p_peer->hdls.heart_rate_max_char_val_hdl)
            {
                uint8_t app_value;

                BT_UNPACK_LE_1_BYTE( &app_value, p_rd_char_evt_param->read_data.value.p_value);

                st_ble_udc_evt_data_t evt_data =
                { 
                    .conn_hdl  = p_data->conn_hdl,
                    .param_len = sizeof(app_value),
                    .p_param   = &app_value,
                };
                gs_udc_cb(BLE_UDC_EVENT_HEART_RATE_MAX_READ_RSP, result, &evt_data);
            }
            else if (p_rd_char_evt_param->read_data.attr_hdl == p_peer->hdls.resting_heart_rate_char_val_hdl)
            {
                uint8_t app_value;
                BT_UNPACK_LE_1_BYTE( &app_value, p_rd_char_evt_param->read_data.value.p_value);

                st_ble_udc_evt_data_t evt_data =
                { 
                    .conn_hdl  = p_data->conn_hdl, 
                    .param_len = sizeof(app_value), 
                    .p_param   = &app_value, 
                };
                gs_udc_cb(BLE_UDC_EVENT_RESTING_HEART_RATE_READ_RSP, result, &evt_data);
            }
            else if (p_rd_char_evt_param->read_data.attr_hdl
                    == p_peer->hdls.maximum_recommended_heart_rate_char_val_hdl)
            {
                uint8_t app_value;
                BT_UNPACK_LE_1_BYTE( &app_value, p_rd_char_evt_param->read_data.value.p_value);

                st_ble_udc_evt_data_t evt_data =
                { 
                    .conn_hdl  = p_data->conn_hdl, 
                    .param_len = sizeof(app_value), 
                    .p_param   = &app_value, 
                };
                gs_udc_cb(BLE_UDC_EVENT_MAXIMUM_RECOMMENDED_HEART_RATE_READ_RSP, result, &evt_data);
            }
            else if (p_rd_char_evt_param->read_data.attr_hdl == p_peer->hdls.aerobic_threshold_char_val_hdl)
            {
                uint8_t app_value;
                
                BT_UNPACK_LE_1_BYTE( &app_value, p_rd_char_evt_param->read_data.value.p_value);

                st_ble_udc_evt_data_t evt_data =
                { 
                    .conn_hdl  = p_data->conn_hdl, 
                    .param_len = sizeof(app_value), 
                    .p_param   = &app_value, 
                };
                gs_udc_cb(BLE_UDC_EVENT_AEROBIC_THRESHOLD_READ_RSP, result, &evt_data);
            }
            else if (p_rd_char_evt_param->read_data.attr_hdl == p_peer->hdls.anaerobic_threshold_char_val_hdl)
            {
                uint8_t app_value;
                
                BT_UNPACK_LE_1_BYTE( &app_value, p_rd_char_evt_param->read_data.value.p_value);

                st_ble_udc_evt_data_t evt_data =
                { 
                    .conn_hdl  = p_data->conn_hdl, 
                    .param_len = sizeof(app_value), 
                    .p_param   = &app_value, 
                };
                gs_udc_cb(BLE_UDC_EVENT_ANAEROBIC_THRESHOLD_READ_RSP, result, &evt_data);
            }
            else if (p_rd_char_evt_param->read_data.attr_hdl
                    == p_peer->hdls.sport_type_for_aerobic_and_anaerobic_thresholds_char_val_hdl)
            {
                uint8_t app_value;

                BT_UNPACK_LE_1_BYTE( &app_value, p_rd_char_evt_param->read_data.value.p_value);

                st_ble_udc_evt_data_t evt_data =
                { 
                    .conn_hdl  = p_data->conn_hdl, 
                    .param_len = sizeof(app_value), 
                    .p_param   = &app_value, 
                };
                gs_udc_cb(BLE_UDC_EVENT_SPORT_TYPE_FOR_AEROBIC_AND_ANAEROBIC_THRESHOLDS_READ_RSP, result, &evt_data);
            }
            else if (p_rd_char_evt_param->read_data.attr_hdl == p_peer->hdls.date_of_threshold_assessment_char_val_hdl)
            {
                ble_status_t ret;
                st_ble_udc_date_of_threshold_assessment_t app_value;

                ret = decode_date_of_threshold_assessment( &app_value, &p_rd_char_evt_param->read_data.value);

                st_ble_udc_evt_data_t evt_data =
                { 
                    .conn_hdl  = p_data->conn_hdl, 
                    .param_len = sizeof(app_value), 
                    .p_param   = &app_value, 
                };
                gs_udc_cb(BLE_UDC_EVENT_DATE_OF_THRESHOLD_ASSESSMENT_READ_RSP, ret, &evt_data);
            }
            else if (p_rd_char_evt_param->read_data.attr_hdl == p_peer->hdls.waist_circumference_char_val_hdl)
            {
                uint16_t app_value;

                BT_UNPACK_LE_2_BYTE( &app_value, p_rd_char_evt_param->read_data.value.p_value);

                st_ble_udc_evt_data_t evt_data =
                { 
                    .conn_hdl  = p_data->conn_hdl, 
                    .param_len = sizeof(app_value), 
                    .p_param   = &app_value, 
                };
                gs_udc_cb(BLE_UDC_EVENT_WAIST_CIRCUMFERENCE_READ_RSP, result, &evt_data);
            }
            else if (p_rd_char_evt_param->read_data.attr_hdl == p_peer->hdls.hip_circumference_char_val_hdl)
            {
                uint16_t app_value;
                
                BT_UNPACK_LE_2_BYTE( &app_value, p_rd_char_evt_param->read_data.value.p_value);

                st_ble_udc_evt_data_t evt_data =
                { 
                    .conn_hdl  = p_data->conn_hdl, 
                    .param_len = sizeof(app_value), 
                    .p_param   = &app_value, 
                };
                gs_udc_cb(BLE_UDC_EVENT_HIP_CIRCUMFERENCE_READ_RSP, result, &evt_data);
            }
            else if (p_rd_char_evt_param->read_data.attr_hdl
                    == p_peer->hdls.fat_burn_heart_rate_lower_limit_char_val_hdl)
            {
                uint8_t app_value;
                
                BT_UNPACK_LE_1_BYTE( &app_value, p_rd_char_evt_param->read_data.value.p_value);

                st_ble_udc_evt_data_t evt_data =
                { 
                    .conn_hdl  = p_data->conn_hdl, 
                    .param_len = sizeof(app_value), 
                    .p_param   = &app_value, 
                };
                gs_udc_cb(BLE_UDC_EVENT_FAT_BURN_HEART_RATE_LOWER_LIMIT_READ_RSP, result, &evt_data);
            }
            else if (p_rd_char_evt_param->read_data.attr_hdl
                    == p_peer->hdls.fat_burn_heart_rate_upper_limit_char_val_hdl)
            {
                uint8_t app_value;
                
                BT_UNPACK_LE_1_BYTE( &app_value, p_rd_char_evt_param->read_data.value.p_value);

                st_ble_udc_evt_data_t evt_data =
                { 
                    .conn_hdl  = p_data->conn_hdl, 
                    .param_len = sizeof(app_value), 
                    .p_param   = &app_value, 
                };
                gs_udc_cb(BLE_UDC_EVENT_FAT_BURN_HEART_RATE_UPPER_LIMIT_READ_RSP, result, &evt_data);
            }
            else if (p_rd_char_evt_param->read_data.attr_hdl
                    == p_peer->hdls.aerobic_heart_rate_lower_limit_char_val_hdl)
            {
                uint8_t app_value;
                
                BT_UNPACK_LE_1_BYTE( &app_value, p_rd_char_evt_param->read_data.value.p_value);

                st_ble_udc_evt_data_t evt_data =
                { 
                    .conn_hdl  = p_data->conn_hdl, 
                    .param_len = sizeof(app_value), 
                    .p_param   = &app_value, 
                };
                gs_udc_cb(BLE_UDC_EVENT_AEROBIC_HEART_RATE_LOWER_LIMIT_READ_RSP, result, &evt_data);
            }
            else if (p_rd_char_evt_param->read_data.attr_hdl
                    == p_peer->hdls.aerobic_heart_rate_upper_limit_char_val_hdl)
            {
                uint8_t app_value;

                BT_UNPACK_LE_1_BYTE( &app_value, p_rd_char_evt_param->read_data.value.p_value);

                st_ble_udc_evt_data_t evt_data =
                { 
                    .conn_hdl  = p_data->conn_hdl, 
                    .param_len = sizeof(app_value), 
                    .p_param   = &app_value, 
                };
                gs_udc_cb(BLE_UDC_EVENT_AEROBIC_HEART_RATE_UPPER_LIMIT_READ_RSP, result, &evt_data);
            }
            else if (p_rd_char_evt_param->read_data.attr_hdl
                    == p_peer->hdls.anaerobic_heart_rate_lower_limit_char_val_hdl)
            {
                uint8_t app_value;
                
                BT_UNPACK_LE_1_BYTE( &app_value, p_rd_char_evt_param->read_data.value.p_value);

                st_ble_udc_evt_data_t evt_data =
                { 
                    .conn_hdl  = p_data->conn_hdl, 
                    .param_len = sizeof(app_value), 
                    .p_param   = &app_value, 
                };
                gs_udc_cb(BLE_UDC_EVENT_ANAEROBIC_HEART_RATE_LOWER_LIMIT_READ_RSP, result, &evt_data);
            }
            else if (p_rd_char_evt_param->read_data.attr_hdl
                    == p_peer->hdls.anaerobic_heart_rate_upper_limit_char_val_hdl)
            {
                uint8_t app_value;
                
                BT_UNPACK_LE_1_BYTE( &app_value, p_rd_char_evt_param->read_data.value.p_value);

                st_ble_udc_evt_data_t evt_data =
                { 
                    .conn_hdl  = p_data->conn_hdl, 
                    .param_len = sizeof(app_value), 
                    .p_param   = &app_value, 
                };
                gs_udc_cb(BLE_UDC_EVENT_ANAEROBIC_HEART_RATE_UPPER_LIMIT_READ_RSP, result, &evt_data);
            }
            else if (p_rd_char_evt_param->read_data.attr_hdl == p_peer->hdls.five_zone_heart_rate_limits_char_val_hdl)
            {
                ble_status_t ret;
                st_ble_udc_five_zone_heart_rate_limits_t app_value;

                ret = decode_five_zone_heart_rate_limits( &app_value, &p_rd_char_evt_param->read_data.value);

                st_ble_udc_evt_data_t evt_data =
                { 
                    .conn_hdl  = p_data->conn_hdl, 
                    .param_len = sizeof(app_value), 
                    .p_param   = &app_value, 
                };
                gs_udc_cb(BLE_UDC_EVENT_FIVE_ZONE_HEART_RATE_LIMITS_READ_RSP, ret, &evt_data);
            }
            else if (p_rd_char_evt_param->read_data.attr_hdl == p_peer->hdls.three_zone_heart_rate_limits_char_val_hdl)
            {
                ble_status_t ret;
                st_ble_udc_three_zone_heart_rate_limits_t app_value;

                ret = decode_three_zone_heart_rate_limits( &app_value, &p_rd_char_evt_param->read_data.value);

                st_ble_udc_evt_data_t evt_data =
                { 
                    .conn_hdl  = p_data->conn_hdl, 
                    .param_len = sizeof(app_value), 
                    .p_param   = &app_value, 
                };
                gs_udc_cb(BLE_UDC_EVENT_THREE_ZONE_HEART_RATE_LIMITS_READ_RSP, ret, &evt_data);
            }
            else if (p_rd_char_evt_param->read_data.attr_hdl == p_peer->hdls.two_zone_heart_rate_limit_char_val_hdl)
            {
                uint8_t app_value;
                BT_UNPACK_LE_1_BYTE( &app_value, p_rd_char_evt_param->read_data.value.p_value);

                st_ble_udc_evt_data_t evt_data =
                { 
                    .conn_hdl  = p_data->conn_hdl, 
                    .param_len = sizeof(app_value), 
                    .p_param   = &app_value, 
                };
                gs_udc_cb(BLE_UDC_EVENT_TWO_ZONE_HEART_RATE_LIMIT_READ_RSP, result, &evt_data);
            }
            else if (p_rd_char_evt_param->read_data.attr_hdl == p_peer->hdls.database_change_increment_char_val_hdl)
            {
                uint32_t app_value;

                BT_UNPACK_LE_4_BYTE( &app_value, p_rd_char_evt_param->read_data.value.p_value);

                st_ble_udc_evt_data_t evt_data =
                { 
                    .conn_hdl  = p_data->conn_hdl, 
                    .param_len = sizeof(app_value), 
                    .p_param   = &app_value, 
                };
                gs_udc_cb(BLE_UDC_EVENT_DATABASE_CHANGE_INCREMENT_READ_RSP, result, &evt_data);
            }
            else if (p_rd_char_evt_param->read_data.attr_hdl == p_peer->hdls.user_index_char_val_hdl)
            {
                uint8_t app_value;

                BT_UNPACK_LE_1_BYTE( &app_value, p_rd_char_evt_param->read_data.value.p_value);

                st_ble_udc_evt_data_t evt_data =
                { 
                    .conn_hdl  = p_data->conn_hdl, 
                    .param_len = sizeof(app_value), 
                    .p_param   = &app_value, 
                };
                gs_udc_cb(BLE_UDC_EVENT_USER_INDEX_READ_RSP, result, &evt_data);
            }
            else
            {
                /* Do Nothing */
            }
        }
        break;

        case BLE_GATTC_EVENT_CHAR_PART_WRITE_RSP:
        {
            st_ble_gattc_wr_char_evt_t *p_wr_char_evt_param = (st_ble_gattc_wr_char_evt_t *)p_data->p_param;

            if (p_wr_char_evt_param->value_hdl == p_peer->hdls.first_name_char_val_hdl)
            {
                gs_current_long_write_char = BLE_UDC_FIRST_NAME_WRITE;
            }
            else if (p_wr_char_evt_param->value_hdl == p_peer->hdls.last_name_char_val_hdl)
            {
                gs_current_long_write_char = BLE_UDC_LAST_NAME_WRITE;
            }
            else if (p_wr_char_evt_param->value_hdl == p_peer->hdls.email_address_char_val_hdl)
            {
                gs_current_long_write_char = BLE_UDC_EMAIL_ADDRESS_WRITE;
            }
            else if (p_wr_char_evt_param->value_hdl == p_peer->hdls.language_char_val_hdl)
            {
                gs_current_long_write_char = BLE_UDC_LANGUAGE_WRITE;
            }
            else
            {
                gs_current_long_write_char = BLE_UDC_UNKNOWN_WRITE;
            }
            
        }
        break;

        case BLE_GATTC_EVENT_LONG_CHAR_WRITE_COMP:
        {
            /*st_ble_gattc_wr_char_evt_t *p_wr_char_evt_param = (st_ble_gattc_wr_char_evt_t *)p_data->p_param;*/

            st_ble_udc_evt_data_t evt_data =
            {
                .conn_hdl  = p_data->conn_hdl,
                .param_len = 0,
                .p_param   = NULL,
            };

            if (BLE_UDC_FIRST_NAME_WRITE == gs_current_long_write_char)
            {
                gs_udc_cb(BLE_UDC_EVENT_FIRST_NAME_WRITE_RSP, result, &evt_data);
            }
            else if (BLE_UDC_LAST_NAME_WRITE == gs_current_long_write_char)
            {
                gs_udc_cb(BLE_UDC_EVENT_LAST_NAME_WRITE_RSP, result, &evt_data);
            }
            else if (BLE_UDC_EMAIL_ADDRESS_WRITE == gs_current_long_write_char)
            {
                gs_udc_cb(BLE_UDC_EVENT_EMAIL_ADDRESS_WRITE_RSP, result, &evt_data);
            }
            else if (BLE_UDC_LANGUAGE_WRITE == gs_current_long_write_char)
            {
                gs_udc_cb(BLE_UDC_EVENT_LANGUAGE_WRITE_RSP, result, &evt_data);
            }
            else
            {
                /* Do Nothing */
            }

            gs_current_long_write_char = BLE_UDC_UNKNOWN_WRITE;
        }
        break;

        case BLE_GATTC_EVENT_CHAR_WRITE_RSP:
        {
            st_ble_gattc_wr_char_evt_t *p_wr_char_evt_param = (st_ble_gattc_wr_char_evt_t *) p_data->p_param;

            st_ble_udc_evt_data_t evt_data =
            { 
                .conn_hdl  = p_data->conn_hdl, 
                .param_len = 0, 
                .p_param   = NULL, 
            };

            if (p_wr_char_evt_param->value_hdl == p_peer->hdls.first_name_char_val_hdl)
            {
                gs_udc_cb(BLE_UDC_EVENT_FIRST_NAME_WRITE_RSP, result, &evt_data);
            }
            else if (p_wr_char_evt_param->value_hdl == p_peer->hdls.last_name_char_val_hdl)
            {
                gs_udc_cb(BLE_UDC_EVENT_LAST_NAME_WRITE_RSP, result, &evt_data);
            }
            else if (p_wr_char_evt_param->value_hdl == p_peer->hdls.email_address_char_val_hdl)
            {
                gs_udc_cb(BLE_UDC_EVENT_EMAIL_ADDRESS_WRITE_RSP, result, &evt_data);
            }
            else if (p_wr_char_evt_param->value_hdl == p_peer->hdls.age_char_val_hdl)
            {
                gs_udc_cb(BLE_UDC_EVENT_AGE_WRITE_RSP, result, &evt_data);
            }
            else if (p_wr_char_evt_param->value_hdl == p_peer->hdls.date_of_birth_char_val_hdl)
            {
                gs_udc_cb(BLE_UDC_EVENT_DATE_OF_BIRTH_WRITE_RSP, result, &evt_data);
            }
            else if (p_wr_char_evt_param->value_hdl == p_peer->hdls.gender_char_val_hdl)
            {
                gs_udc_cb(BLE_UDC_EVENT_GENDER_WRITE_RSP, result, &evt_data);
            }
            else if (p_wr_char_evt_param->value_hdl == p_peer->hdls.weight_char_val_hdl)
            {
                gs_udc_cb(BLE_UDC_EVENT_WEIGHT_WRITE_RSP, result, &evt_data);
            }
            else if (p_wr_char_evt_param->value_hdl == p_peer->hdls.height_char_val_hdl)
            {
                gs_udc_cb(BLE_UDC_EVENT_HEIGHT_WRITE_RSP, result, &evt_data);
            }
            else if (p_wr_char_evt_param->value_hdl == p_peer->hdls.vo2_max_char_val_hdl)
            {
                gs_udc_cb(BLE_UDC_EVENT_VO2_MAX_WRITE_RSP, result, &evt_data);
            }
            else if (p_wr_char_evt_param->value_hdl == p_peer->hdls.heart_rate_max_char_val_hdl)
            {
                gs_udc_cb(BLE_UDC_EVENT_HEART_RATE_MAX_WRITE_RSP, result, &evt_data);
            }
            else if (p_wr_char_evt_param->value_hdl == p_peer->hdls.resting_heart_rate_char_val_hdl)
            {
                gs_udc_cb(BLE_UDC_EVENT_RESTING_HEART_RATE_WRITE_RSP, result, &evt_data);
            }
            else if (p_wr_char_evt_param->value_hdl == p_peer->hdls.maximum_recommended_heart_rate_char_val_hdl)
            {
                gs_udc_cb(BLE_UDC_EVENT_MAXIMUM_RECOMMENDED_HEART_RATE_WRITE_RSP, result, &evt_data);
            }
            else if (p_wr_char_evt_param->value_hdl == p_peer->hdls.aerobic_threshold_char_val_hdl)
            {
                gs_udc_cb(BLE_UDC_EVENT_AEROBIC_THRESHOLD_WRITE_RSP, result, &evt_data);
            }
            else if (p_wr_char_evt_param->value_hdl == p_peer->hdls.anaerobic_threshold_char_val_hdl)
            {
                gs_udc_cb(BLE_UDC_EVENT_ANAEROBIC_THRESHOLD_WRITE_RSP, result, &evt_data);
            }
            else if (p_wr_char_evt_param->value_hdl
                    == p_peer->hdls.sport_type_for_aerobic_and_anaerobic_thresholds_char_val_hdl)
            {
                gs_udc_cb(BLE_UDC_EVENT_SPORT_TYPE_FOR_AEROBIC_AND_ANAEROBIC_THRESHOLDS_WRITE_RSP, result, &evt_data);
            }
            else if (p_wr_char_evt_param->value_hdl == p_peer->hdls.date_of_threshold_assessment_char_val_hdl)
            {
                gs_udc_cb(BLE_UDC_EVENT_DATE_OF_THRESHOLD_ASSESSMENT_WRITE_RSP, result, &evt_data);
            }
            else if (p_wr_char_evt_param->value_hdl == p_peer->hdls.waist_circumference_char_val_hdl)
            {
                gs_udc_cb(BLE_UDC_EVENT_WAIST_CIRCUMFERENCE_WRITE_RSP, result, &evt_data);
            }
            else if (p_wr_char_evt_param->value_hdl == p_peer->hdls.hip_circumference_char_val_hdl)
            {
                gs_udc_cb(BLE_UDC_EVENT_HIP_CIRCUMFERENCE_WRITE_RSP, result, &evt_data);
            }
            else if (p_wr_char_evt_param->value_hdl == p_peer->hdls.fat_burn_heart_rate_lower_limit_char_val_hdl)
            {
                gs_udc_cb(BLE_UDC_EVENT_FAT_BURN_HEART_RATE_LOWER_LIMIT_WRITE_RSP, result, &evt_data);
            }
            else if (p_wr_char_evt_param->value_hdl == p_peer->hdls.fat_burn_heart_rate_upper_limit_char_val_hdl)
            {
                gs_udc_cb(BLE_UDC_EVENT_FAT_BURN_HEART_RATE_UPPER_LIMIT_WRITE_RSP, result, &evt_data);
            }
            else if (p_wr_char_evt_param->value_hdl == p_peer->hdls.aerobic_heart_rate_lower_limit_char_val_hdl)
            {
                gs_udc_cb(BLE_UDC_EVENT_AEROBIC_HEART_RATE_LOWER_LIMIT_WRITE_RSP, result, &evt_data);
            }
            else if (p_wr_char_evt_param->value_hdl == p_peer->hdls.aerobic_heart_rate_upper_limit_char_val_hdl)
            {
                gs_udc_cb(BLE_UDC_EVENT_AEROBIC_HEART_RATE_UPPER_LIMIT_WRITE_RSP, result, &evt_data);
            }
            else if (p_wr_char_evt_param->value_hdl == p_peer->hdls.anaerobic_heart_rate_lower_limit_char_val_hdl)
            {
                gs_udc_cb(BLE_UDC_EVENT_ANAEROBIC_HEART_RATE_LOWER_LIMIT_WRITE_RSP, result, &evt_data);
            }
            else if (p_wr_char_evt_param->value_hdl == p_peer->hdls.anaerobic_heart_rate_upper_limit_char_val_hdl)
            {
                gs_udc_cb(BLE_UDC_EVENT_ANAEROBIC_HEART_RATE_UPPER_LIMIT_WRITE_RSP, result, &evt_data);
            }
            else if (p_wr_char_evt_param->value_hdl == p_peer->hdls.five_zone_heart_rate_limits_char_val_hdl)
            {
                gs_udc_cb(BLE_UDC_EVENT_FIVE_ZONE_HEART_RATE_LIMITS_WRITE_RSP, result, &evt_data);
            }
            else if (p_wr_char_evt_param->value_hdl == p_peer->hdls.three_zone_heart_rate_limits_char_val_hdl)
            {
                gs_udc_cb(BLE_UDC_EVENT_THREE_ZONE_HEART_RATE_LIMITS_WRITE_RSP, result, &evt_data);
            }
            else if (p_wr_char_evt_param->value_hdl == p_peer->hdls.two_zone_heart_rate_limit_char_val_hdl)
            {
                gs_udc_cb(BLE_UDC_EVENT_TWO_ZONE_HEART_RATE_LIMIT_WRITE_RSP, result, &evt_data);
            }
            else if (p_wr_char_evt_param->value_hdl == p_peer->hdls.database_change_increment_char_val_hdl)
            {
                gs_udc_cb(BLE_UDC_EVENT_DATABASE_CHANGE_INCREMENT_WRITE_RSP, result, &evt_data);
            }
            else if (p_wr_char_evt_param->value_hdl == p_peer->hdls.user_control_point_char_val_hdl)
            {
                gs_udc_cb(BLE_UDC_EVENT_USER_CONTROL_POINT_WRITE_RSP, result, &evt_data);
            }
            else if (p_wr_char_evt_param->value_hdl == p_peer->hdls.language_char_val_hdl)
            {
                gs_udc_cb(BLE_UDC_EVENT_LANGUAGE_WRITE_RSP, result, &evt_data);
            }
            else if ((p_wr_char_evt_param->value_hdl == p_peer->hdls.database_change_increment_cli_cnfg_hdl)
                    || (p_wr_char_evt_param->value_hdl == p_peer->hdls.user_control_point_cli_cnfg_hdl))
            {
                gs_udc_cb(BLE_UDC_EVENT_CLI_CNFG_WRITE_RSP, result, &evt_data);
            }
            else
            {
                /* Do Nothing */
            }
        }
        break;

        case BLE_GATTC_EVENT_HDL_VAL_IND:
        {
            st_ble_gattc_ind_evt_t *p_ind_evt_param = (st_ble_gattc_ind_evt_t *) p_data->p_param;

            if (p_ind_evt_param->data.attr_hdl == p_peer->hdls.user_control_point_char_val_hdl)
            {
                ble_status_t ret;
                st_ble_udc_user_control_point_t app_value;

                ret = decode_user_control_point( &app_value, &p_ind_evt_param->data.value);

                st_ble_udc_evt_data_t evt_data =
                { 
                    .conn_hdl  = p_data->conn_hdl, 
                    .param_len = sizeof(app_value), 
                    .p_param   = &app_value, 
                };
                gs_udc_cb(BLE_UDC_EVENT_USER_CONTROL_POINT_HDL_VAL_IND, ret, &evt_data);
            }
        }
        break;

        case BLE_GATTC_EVENT_HDL_VAL_NTF:
        {
            st_ble_gattc_ntf_evt_t *p_ntf_evt_param = (st_ble_gattc_ntf_evt_t *) p_data->p_param;
            if (p_ntf_evt_param->data.attr_hdl == p_peer->hdls.database_change_increment_char_val_hdl)
            {
                uint32_t app_value;

                BT_UNPACK_LE_4_BYTE( &app_value, p_ntf_evt_param->data.value.p_value);

                st_ble_udc_evt_data_t evt_data =
                { 
                    .conn_hdl  = p_data->conn_hdl, 
                    .param_len = sizeof(app_value), 
                    .p_param   = &app_value, 
                };
                gs_udc_cb(BLE_UDC_EVENT_DATABASE_CHANGE_INCREMENT_HDL_VAL_NTF, result, &evt_data);
            }
        }
        break;

        case BLE_GATTC_EVENT_ERROR_RSP:
        {
            st_ble_gattc_err_rsp_evt_t *p_err_rsp_evt_param = (st_ble_gattc_err_rsp_evt_t *) p_data->p_param;

            st_ble_udc_evt_data_t evt_data =
            { 
                .conn_hdl  = p_data->conn_hdl, 
                .param_len = sizeof(st_ble_gattc_err_rsp_evt_t), 
                .p_param   = p_err_rsp_evt_param, 
            };

            if ((p_err_rsp_evt_param->attr_hdl == p_peer->hdls.first_name_char_val_hdl)
                    || (p_err_rsp_evt_param->attr_hdl == p_peer->hdls.last_name_char_val_hdl)
                    || (p_err_rsp_evt_param->attr_hdl == p_peer->hdls.email_address_char_val_hdl)
                    || (p_err_rsp_evt_param->attr_hdl == p_peer->hdls.age_char_val_hdl)
                    || (p_err_rsp_evt_param->attr_hdl == p_peer->hdls.date_of_birth_char_val_hdl)
                    || (p_err_rsp_evt_param->attr_hdl == p_peer->hdls.gender_char_val_hdl)
                    || (p_err_rsp_evt_param->attr_hdl == p_peer->hdls.weight_char_val_hdl)
                    || (p_err_rsp_evt_param->attr_hdl == p_peer->hdls.height_char_val_hdl)
                    || (p_err_rsp_evt_param->attr_hdl == p_peer->hdls.vo2_max_char_val_hdl)
                    || (p_err_rsp_evt_param->attr_hdl == p_peer->hdls.heart_rate_max_char_val_hdl)
                    || (p_err_rsp_evt_param->attr_hdl == p_peer->hdls.resting_heart_rate_char_val_hdl)
                    || (p_err_rsp_evt_param->attr_hdl == p_peer->hdls.maximum_recommended_heart_rate_char_val_hdl)
                    || (p_err_rsp_evt_param->attr_hdl == p_peer->hdls.aerobic_threshold_char_val_hdl)
                    || (p_err_rsp_evt_param->attr_hdl == p_peer->hdls.anaerobic_threshold_char_val_hdl)
                    || (p_err_rsp_evt_param->attr_hdl
                            == p_peer->hdls.sport_type_for_aerobic_and_anaerobic_thresholds_char_val_hdl)
                    || (p_err_rsp_evt_param->attr_hdl == p_peer->hdls.date_of_threshold_assessment_char_val_hdl)
                    || (p_err_rsp_evt_param->attr_hdl == p_peer->hdls.waist_circumference_char_val_hdl)
                    || (p_err_rsp_evt_param->attr_hdl == p_peer->hdls.hip_circumference_char_val_hdl)
                    || (p_err_rsp_evt_param->attr_hdl == p_peer->hdls.fat_burn_heart_rate_lower_limit_char_val_hdl)
                    || (p_err_rsp_evt_param->attr_hdl == p_peer->hdls.fat_burn_heart_rate_upper_limit_char_val_hdl)
                    || (p_err_rsp_evt_param->attr_hdl == p_peer->hdls.aerobic_heart_rate_lower_limit_char_val_hdl)
                    || (p_err_rsp_evt_param->attr_hdl == p_peer->hdls.aerobic_heart_rate_upper_limit_char_val_hdl)
                    || (p_err_rsp_evt_param->attr_hdl == p_peer->hdls.anaerobic_heart_rate_lower_limit_char_val_hdl)
                    || (p_err_rsp_evt_param->attr_hdl == p_peer->hdls.anaerobic_heart_rate_upper_limit_char_val_hdl)
                    || (p_err_rsp_evt_param->attr_hdl == p_peer->hdls.five_zone_heart_rate_limits_char_val_hdl)
                    || (p_err_rsp_evt_param->attr_hdl == p_peer->hdls.three_zone_heart_rate_limits_char_val_hdl)
                    || (p_err_rsp_evt_param->attr_hdl == p_peer->hdls.two_zone_heart_rate_limit_char_val_hdl)
                    || (p_err_rsp_evt_param->attr_hdl == p_peer->hdls.database_change_increment_char_val_hdl)
                    || (p_err_rsp_evt_param->attr_hdl == p_peer->hdls.user_index_char_val_hdl)
                    || (p_err_rsp_evt_param->attr_hdl == p_peer->hdls.user_control_point_char_val_hdl)
                    || (p_err_rsp_evt_param->attr_hdl == p_peer->hdls.language_char_val_hdl))
            {
                gs_udc_cb(BLE_UDC_EVENT_ERROR_RSP, result, &evt_data);
            }
        }
        break;

        default:
        {
            /* Do nothing. */
        }
        break;
    }
}

ble_status_t R_BLE_UDC_Init (const st_ble_udc_init_param_t *p_param) // @suppress("API function naming")
{
    if (NULL == p_param)
    {
        return BLE_ERR_INVALID_PTR;
    }

    if (NULL == p_param->cb)
    {
        return BLE_ERR_INVALID_ARG;
    }

    for (uint8_t i = 0; i < BLE_UDC_PRV_CONNECTION_COUNT; i++)
    {
        clear_peer_param( &gs_peer_params[i]);
    }

    R_BLE_GATTC_RegisterCb(udc_gattc_cb, 6);

    gs_udc_cb = p_param->cb;

    return BLE_SUCCESS;
}

ble_status_t R_BLE_UDC_Connect (uint16_t conn_hdl, const st_ble_udc_connect_param_t *p_param) // @suppress("API function naming")
{
    st_udc_peer_param_t *p_peer = get_new_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if ((NULL != p_param) && (NULL != p_param->p_hdls))
    {
        memcpy( &p_peer->hdls, p_param->p_hdls, sizeof(p_peer->hdls));
    }

    return BLE_SUCCESS;
}

ble_status_t R_BLE_UDC_Disconnect (uint16_t conn_hdl, st_ble_udc_disconnect_param_t *p_param) // @suppress("API function naming")
{
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if ((NULL != p_param) && (NULL != p_param->p_hdls))
    {
        memcpy(p_param->p_hdls, &p_peer->hdls, sizeof( *p_param->p_hdls));
    }

    clear_peer_param(p_peer);

    /* Reset UDC Long read variables */
    gs_read_first_part = true;
    gs_read_offset = 0;
    gs_current_long_read_char = BLE_UDC_UNKNOWN_READ;

    return BLE_SUCCESS;
}

ble_status_t R_BLE_UDC_ReadFirstName (uint16_t conn_hdl) // @suppress("API function naming")
{
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.first_name_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    return R_BLE_GATTC_ReadLongChar(conn_hdl, p_peer->hdls.first_name_char_val_hdl, 0);
}

ble_status_t R_BLE_UDC_WriteFirstName (uint16_t conn_hdl, const st_ble_udc_first_name_t *p_app_value) // @suppress("API function naming")
{
    ble_status_t ret;
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (NULL == p_app_value)
    {
        return BLE_ERR_INVALID_PTR;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.first_name_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    uint8_t byte_value[BLE_UDC_FIRST_NAME_LEN];

    st_ble_gatt_hdl_value_pair_t write_value =
    { 
        .attr_hdl = p_peer->hdls.first_name_char_val_hdl, 
        .value =
        { 
            .p_value   = byte_value, 
            .value_len = BLE_UDC_FIRST_NAME_LEN, 
        } 
    };

    ret = encode_first_name(p_app_value, &write_value.value);
    if (BLE_SUCCESS == ret)
    {
        ret = R_BLE_GATTC_WriteLongChar(conn_hdl, &write_value, 0);
    }

    return ret;
}

ble_status_t R_BLE_UDC_ReadLastName (uint16_t conn_hdl) // @suppress("API function naming")
{
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.last_name_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    return R_BLE_GATTC_ReadLongChar(conn_hdl, p_peer->hdls.last_name_char_val_hdl, 0);
}

ble_status_t R_BLE_UDC_WriteLastName (uint16_t conn_hdl, const st_ble_udc_last_name_t *p_app_value) // @suppress("API function naming")
{
    ble_status_t ret;
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (NULL == p_app_value)
    {
        return BLE_ERR_INVALID_PTR;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.last_name_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    uint8_t byte_value[BLE_UDC_LAST_NAME_LEN];

    st_ble_gatt_hdl_value_pair_t write_value =
    { 
        .attr_hdl = p_peer->hdls.last_name_char_val_hdl, 
        .value    =
        { 
            .p_value   = byte_value, 
            .value_len = BLE_UDC_LAST_NAME_LEN, 
        } 
    };
    
    ret = encode_last_name(p_app_value, &write_value.value);
    ret = R_BLE_GATTC_WriteLongChar(conn_hdl, &write_value, 0);

    return ret;
}

ble_status_t R_BLE_UDC_ReadEmailAddress (uint16_t conn_hdl) // @suppress("API function naming")
{
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.email_address_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    return R_BLE_GATTC_ReadLongChar(conn_hdl, p_peer->hdls.email_address_char_val_hdl, 0);
}

ble_status_t R_BLE_UDC_WriteEmailAddress (uint16_t conn_hdl, const st_ble_udc_email_address_t *p_app_value) // @suppress("API function naming")
{
    ble_status_t ret;
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (NULL == p_app_value)
    {
        return BLE_ERR_INVALID_PTR;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.email_address_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    uint8_t byte_value[BLE_UDC_EMAIL_ADDRESS_LEN];

    st_ble_gatt_hdl_value_pair_t write_value =
    { 
        .attr_hdl = p_peer->hdls.email_address_char_val_hdl, 
        .value    =
        { 
            .p_value   = byte_value, 
            .value_len = BLE_UDC_EMAIL_ADDRESS_LEN, 
        } 
    };
    
    ret = encode_email_address(p_app_value, &write_value.value);
    ret = R_BLE_GATTC_WriteLongChar(conn_hdl, &write_value, 0);

    return ret;
}

ble_status_t R_BLE_UDC_ReadAge (uint16_t conn_hdl) // @suppress("API function naming")
{
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.age_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    return R_BLE_GATTC_ReadChar(conn_hdl, p_peer->hdls.age_char_val_hdl);
}

ble_status_t R_BLE_UDC_WriteAge (uint16_t conn_hdl, uint8_t app_value) // @suppress("API function naming")
{
    /*ble_status_t ret;*/
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.age_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    uint8_t byte_value[BLE_UDC_AGE_LEN];

    BT_PACK_LE_1_BYTE(byte_value, &app_value);

    st_ble_gatt_hdl_value_pair_t write_value =
    { 
        .attr_hdl = p_peer->hdls.age_char_val_hdl, 
        .value    =
        { 
            .p_value   = byte_value, 
            .value_len = BLE_UDC_AGE_LEN, 
    } 
    };

    return R_BLE_GATTC_WriteChar(conn_hdl, &write_value);
}

ble_status_t R_BLE_UDC_ReadDateOfBirth (uint16_t conn_hdl) // @suppress("API function naming")
{
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.date_of_birth_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    return R_BLE_GATTC_ReadChar(conn_hdl, p_peer->hdls.date_of_birth_char_val_hdl);
}

ble_status_t R_BLE_UDC_WriteDateOfBirth (uint16_t conn_hdl, const st_ble_udc_date_of_birth_t *p_app_value) // @suppress("API function naming")
{
    ble_status_t ret;
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (NULL == p_app_value)
    {
        return BLE_ERR_INVALID_PTR;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.date_of_birth_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    uint8_t byte_value[BLE_UDC_DATE_OF_BIRTH_LEN];

    st_ble_gatt_hdl_value_pair_t write_value =
    { 
        .attr_hdl = p_peer->hdls.date_of_birth_char_val_hdl, 
        .value    =
        { 
            .p_value   = byte_value, 
            .value_len = BLE_UDC_DATE_OF_BIRTH_LEN, 
        } 
    };

    ret = encode_date_of_birth(p_app_value, &write_value.value);
    if (BLE_SUCCESS != ret)
    {
        return ret;
    }

    return R_BLE_GATTC_WriteChar(conn_hdl, &write_value);
}

ble_status_t R_BLE_UDC_ReadGender (uint16_t conn_hdl) // @suppress("API function naming")
{
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.gender_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    return R_BLE_GATTC_ReadChar(conn_hdl, p_peer->hdls.gender_char_val_hdl);
}

ble_status_t R_BLE_UDC_WriteGender (uint16_t conn_hdl, uint8_t app_value) // @suppress("API function naming")
{
    /*ble_status_t ret;*/
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.gender_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    uint8_t byte_value[BLE_UDC_GENDER_LEN];

    BT_PACK_LE_1_BYTE(byte_value, &app_value);

    st_ble_gatt_hdl_value_pair_t write_value =
    { 
        .attr_hdl = p_peer->hdls.gender_char_val_hdl, 
        .value    =
        { 
            .p_value   = byte_value, 
            .value_len = BLE_UDC_GENDER_LEN, 
        } 
    };

    return R_BLE_GATTC_WriteChar(conn_hdl, &write_value);
}

ble_status_t R_BLE_UDC_ReadWeight (uint16_t conn_hdl) // @suppress("API function naming")
{
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.weight_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    return R_BLE_GATTC_ReadChar(conn_hdl, p_peer->hdls.weight_char_val_hdl);
}

ble_status_t R_BLE_UDC_WriteWeight (uint16_t conn_hdl, uint16_t app_value) // @suppress("API function naming")
{
    /*ble_status_t ret;*/
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.weight_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    uint8_t byte_value[BLE_UDC_WEIGHT_LEN];
    
    BT_PACK_LE_2_BYTE(byte_value, &app_value);

    st_ble_gatt_hdl_value_pair_t write_value =
    { 
        .attr_hdl = p_peer->hdls.weight_char_val_hdl, 
        .value    =
        { 
            .p_value   = byte_value, 
            .value_len = BLE_UDC_WEIGHT_LEN, 
        } 
    };

    return R_BLE_GATTC_WriteChar(conn_hdl, &write_value);
}

ble_status_t R_BLE_UDC_ReadHeight (uint16_t conn_hdl) // @suppress("API function naming")
{
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.height_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    return R_BLE_GATTC_ReadChar(conn_hdl, p_peer->hdls.height_char_val_hdl);
}

ble_status_t R_BLE_UDC_WriteHeight (uint16_t conn_hdl, uint16_t app_value) // @suppress("API function naming")
{
    /*ble_status_t ret;*/
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.height_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    uint8_t byte_value[BLE_UDC_HEIGHT_LEN];

    BT_PACK_LE_2_BYTE(byte_value, &app_value);

    st_ble_gatt_hdl_value_pair_t write_value =
    { 
        .attr_hdl = p_peer->hdls.height_char_val_hdl, 
        .value    =
        { 
            .p_value   = byte_value,
            .value_len = BLE_UDC_HEIGHT_LEN,
        } 
    };

    return R_BLE_GATTC_WriteChar(conn_hdl, &write_value);
}

ble_status_t R_BLE_UDC_ReadVo2Max (uint16_t conn_hdl) // @suppress("API function naming")
{
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.vo2_max_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    return R_BLE_GATTC_ReadChar(conn_hdl, p_peer->hdls.vo2_max_char_val_hdl);
}

ble_status_t R_BLE_UDC_WriteVo2Max (uint16_t conn_hdl, uint8_t app_value) // @suppress("API function naming")
{
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.vo2_max_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    uint8_t byte_value[BLE_UDC_VO2_MAX_LEN];
    
    BT_PACK_LE_1_BYTE(byte_value, &app_value);

    st_ble_gatt_hdl_value_pair_t write_value =
    { 
        .attr_hdl = p_peer->hdls.vo2_max_char_val_hdl, 
        .value    =
        { 
            .p_value   = byte_value, 
            .value_len = BLE_UDC_VO2_MAX_LEN, 
        } 
    };

    return R_BLE_GATTC_WriteChar(conn_hdl, &write_value);
}

ble_status_t R_BLE_UDC_ReadHeartRateMax (uint16_t conn_hdl) // @suppress("API function naming")
{
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.heart_rate_max_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    return R_BLE_GATTC_ReadChar(conn_hdl, p_peer->hdls.heart_rate_max_char_val_hdl);
}

ble_status_t R_BLE_UDC_WriteHeartRateMax (uint16_t conn_hdl, uint8_t app_value) // @suppress("API function naming")
{
    /*ble_status_t ret;*/
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.heart_rate_max_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    uint8_t byte_value[BLE_UDC_HEART_RATE_MAX_LEN];

    BT_PACK_LE_1_BYTE(byte_value, &app_value);

    st_ble_gatt_hdl_value_pair_t write_value =
    { 
        .attr_hdl = p_peer->hdls.heart_rate_max_char_val_hdl, 
        .value    =
        { 
            .p_value   = byte_value, 
            .value_len = BLE_UDC_HEART_RATE_MAX_LEN, 
        } 
    };

    return R_BLE_GATTC_WriteChar(conn_hdl, &write_value);
}

ble_status_t R_BLE_UDC_ReadRestingHeartRate (uint16_t conn_hdl) // @suppress("API function naming")
{
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.resting_heart_rate_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    return R_BLE_GATTC_ReadChar(conn_hdl, p_peer->hdls.resting_heart_rate_char_val_hdl);
}

ble_status_t R_BLE_UDC_WriteRestingHeartRate (uint16_t conn_hdl, uint8_t app_value) // @suppress("API function naming")
{
    /*ble_status_t ret;*/
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.resting_heart_rate_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    uint8_t byte_value[BLE_UDC_RESTING_HEART_RATE_LEN];
    
    BT_PACK_LE_1_BYTE(byte_value, &app_value);

    st_ble_gatt_hdl_value_pair_t write_value =
    { 
        .attr_hdl = p_peer->hdls.resting_heart_rate_char_val_hdl,
        .value    =
        {
            .p_value   = byte_value,
            .value_len = BLE_UDC_RESTING_HEART_RATE_LEN,
        }
    };

    return R_BLE_GATTC_WriteChar(conn_hdl, &write_value);
}

ble_status_t R_BLE_UDC_ReadMaximumRecommendedHeartRate (uint16_t conn_hdl) // @suppress("API function naming")
{
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.maximum_recommended_heart_rate_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    return R_BLE_GATTC_ReadChar(conn_hdl, p_peer->hdls.maximum_recommended_heart_rate_char_val_hdl);
}

ble_status_t R_BLE_UDC_WriteMaximumRecommendedHeartRate (uint16_t conn_hdl, uint8_t app_value) // @suppress("API function naming")
{
    /*ble_status_t ret;*/
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.maximum_recommended_heart_rate_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    uint8_t byte_value[BLE_UDC_MAXIMUM_RECOMMENDED_HEART_RATE_LEN];

    BT_PACK_LE_1_BYTE(byte_value, &app_value);

    st_ble_gatt_hdl_value_pair_t write_value =
    { 
        .attr_hdl = p_peer->hdls.maximum_recommended_heart_rate_char_val_hdl, 
        .value    =
        { 
            .p_value   = byte_value, 
            .value_len = BLE_UDC_MAXIMUM_RECOMMENDED_HEART_RATE_LEN, 
        }
    };

    return R_BLE_GATTC_WriteChar(conn_hdl, &write_value);
}

ble_status_t R_BLE_UDC_ReadAerobicThreshold (uint16_t conn_hdl) // @suppress("API function naming")
{
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.aerobic_threshold_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    return R_BLE_GATTC_ReadChar(conn_hdl, p_peer->hdls.aerobic_threshold_char_val_hdl);
}

ble_status_t R_BLE_UDC_WriteAerobicThreshold (uint16_t conn_hdl, uint8_t app_value) // @suppress("API function naming")
{
    /*ble_status_t ret;*/
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.aerobic_threshold_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    uint8_t byte_value[BLE_UDC_AEROBIC_THRESHOLD_LEN];

    BT_PACK_LE_1_BYTE(byte_value, &app_value);

    st_ble_gatt_hdl_value_pair_t write_value =
    { 
        .attr_hdl = p_peer->hdls.aerobic_threshold_char_val_hdl, 
        .value    =
        { 
            .p_value   = byte_value, 
            .value_len = BLE_UDC_AEROBIC_THRESHOLD_LEN, 
        } 
    };

    return R_BLE_GATTC_WriteChar(conn_hdl, &write_value);
}

ble_status_t R_BLE_UDC_ReadAnaerobicThreshold (uint16_t conn_hdl) // @suppress("API function naming")
{
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.anaerobic_threshold_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    return R_BLE_GATTC_ReadChar(conn_hdl, p_peer->hdls.anaerobic_threshold_char_val_hdl);
}

ble_status_t R_BLE_UDC_WriteAnaerobicThreshold (uint16_t conn_hdl, uint8_t app_value) // @suppress("API function naming")
{
    /*ble_status_t ret;*/
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.anaerobic_threshold_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    uint8_t byte_value[BLE_UDC_ANAEROBIC_THRESHOLD_LEN];

    BT_PACK_LE_1_BYTE(byte_value, &app_value);

    st_ble_gatt_hdl_value_pair_t write_value =
    { 
        .attr_hdl = p_peer->hdls.anaerobic_threshold_char_val_hdl, 
        .value    =
        { 
            .p_value   = byte_value, 
            .value_len = BLE_UDC_ANAEROBIC_THRESHOLD_LEN, 
        } 
    };

    return R_BLE_GATTC_WriteChar(conn_hdl, &write_value);
}

ble_status_t R_BLE_UDC_ReadSportTypeForAerobicAndAnaerobicThresholds (uint16_t conn_hdl) // @suppress("API function naming")
{
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.sport_type_for_aerobic_and_anaerobic_thresholds_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    return R_BLE_GATTC_ReadChar(conn_hdl, p_peer->hdls.sport_type_for_aerobic_and_anaerobic_thresholds_char_val_hdl);
}

ble_status_t R_BLE_UDC_WriteSportTypeForAerobicAndAnaerobicThresholds (uint16_t conn_hdl, uint8_t app_value) // @suppress("API function naming")
{
    /*ble_status_t ret;*/
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.sport_type_for_aerobic_and_anaerobic_thresholds_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    uint8_t byte_value[BLE_UDC_SPORT_TYPE_FOR_AEROBIC_AND_ANAEROBIC_THRESHOLDS_LEN];

    BT_PACK_LE_1_BYTE(byte_value, &app_value);

    st_ble_gatt_hdl_value_pair_t write_value =
    { 
        .attr_hdl = p_peer->hdls.sport_type_for_aerobic_and_anaerobic_thresholds_char_val_hdl, 
        .value    =
        { 
            .p_value   = byte_value, 
            .value_len = BLE_UDC_SPORT_TYPE_FOR_AEROBIC_AND_ANAEROBIC_THRESHOLDS_LEN, 
        } 
    };

    return R_BLE_GATTC_WriteChar(conn_hdl, &write_value);
}

ble_status_t R_BLE_UDC_ReadDateOfThresholdAssessment (uint16_t conn_hdl) // @suppress("API function naming")
{
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.date_of_threshold_assessment_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    return R_BLE_GATTC_ReadChar(conn_hdl, p_peer->hdls.date_of_threshold_assessment_char_val_hdl);
}

ble_status_t R_BLE_UDC_WriteDateOfThresholdAssessment (uint16_t conn_hdl,
        const st_ble_udc_date_of_threshold_assessment_t *p_app_value) // @suppress("API function naming")
{
    ble_status_t ret;
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (NULL == p_app_value)
    {
        return BLE_ERR_INVALID_PTR;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.date_of_threshold_assessment_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    uint8_t byte_value[BLE_UDC_DATE_OF_THRESHOLD_ASSESSMENT_LEN];

    st_ble_gatt_hdl_value_pair_t write_value =
    { 
        .attr_hdl = p_peer->hdls.date_of_threshold_assessment_char_val_hdl, 
        .value =
        { 
            .p_value   = byte_value, 
            .value_len = BLE_UDC_DATE_OF_THRESHOLD_ASSESSMENT_LEN, 
        } 
    };

    ret = encode_date_of_threshold_assessment(p_app_value, &write_value.value);
    ret = R_BLE_GATTC_WriteChar(conn_hdl, &write_value);

    return ret;
}

ble_status_t R_BLE_UDC_ReadWaistCircumference (uint16_t conn_hdl) // @suppress("API function naming")
{
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.waist_circumference_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    return R_BLE_GATTC_ReadChar(conn_hdl, p_peer->hdls.waist_circumference_char_val_hdl);
}

ble_status_t R_BLE_UDC_WriteWaistCircumference (uint16_t conn_hdl, uint16_t app_value) // @suppress("API function naming")
{
    /*ble_status_t ret;*/
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.waist_circumference_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    uint8_t byte_value[BLE_UDC_WAIST_CIRCUMFERENCE_LEN];

    BT_PACK_LE_2_BYTE(byte_value, &app_value);

    st_ble_gatt_hdl_value_pair_t write_value =
    { 
        .attr_hdl = p_peer->hdls.waist_circumference_char_val_hdl, 
        .value    =
        { 
            .p_value   = byte_value, 
            .value_len = BLE_UDC_WAIST_CIRCUMFERENCE_LEN, 
        } 
    };

    return R_BLE_GATTC_WriteChar(conn_hdl, &write_value);
}

ble_status_t R_BLE_UDC_ReadHipCircumference (uint16_t conn_hdl) // @suppress("API function naming")
{
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.hip_circumference_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    return R_BLE_GATTC_ReadChar(conn_hdl, p_peer->hdls.hip_circumference_char_val_hdl);
}

ble_status_t R_BLE_UDC_WriteHipCircumference (uint16_t conn_hdl, uint16_t app_value) // @suppress("API function naming")
{
    /*ble_status_t ret;*/
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.hip_circumference_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    uint8_t byte_value[BLE_UDC_HIP_CIRCUMFERENCE_LEN];

    BT_PACK_LE_2_BYTE(byte_value, &app_value);

    st_ble_gatt_hdl_value_pair_t write_value =
    { 
        .attr_hdl = p_peer->hdls.hip_circumference_char_val_hdl, 
        .value    =
        { 
            .p_value   = byte_value, 
            .value_len = BLE_UDC_HIP_CIRCUMFERENCE_LEN, 
        } 
    };

    return R_BLE_GATTC_WriteChar(conn_hdl, &write_value);
}

ble_status_t R_BLE_UDC_ReadFatBurnHeartRateLowerLimit (uint16_t conn_hdl) // @suppress("API function naming")
{
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.fat_burn_heart_rate_lower_limit_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    return R_BLE_GATTC_ReadChar(conn_hdl, p_peer->hdls.fat_burn_heart_rate_lower_limit_char_val_hdl);
}

ble_status_t R_BLE_UDC_WriteFatBurnHeartRateLowerLimit (uint16_t conn_hdl, uint8_t app_value) // @suppress("API function naming")
{
    /*ble_status_t ret;*/
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.fat_burn_heart_rate_lower_limit_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    uint8_t byte_value[BLE_UDC_FAT_BURN_HEART_RATE_LOWER_LIMIT_LEN];

    BT_PACK_LE_1_BYTE(byte_value, &app_value);

    st_ble_gatt_hdl_value_pair_t write_value =
    { 
        .attr_hdl = p_peer->hdls.fat_burn_heart_rate_lower_limit_char_val_hdl, 
        .value    =
        { 
            .p_value   = byte_value, 
            .value_len = BLE_UDC_FAT_BURN_HEART_RATE_LOWER_LIMIT_LEN, 
        } 
    };

    return R_BLE_GATTC_WriteChar(conn_hdl, &write_value);
}

ble_status_t R_BLE_UDC_ReadFatBurnHeartRateUpperLimit (uint16_t conn_hdl) // @suppress("API function naming")
{
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.fat_burn_heart_rate_upper_limit_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    return R_BLE_GATTC_ReadChar(conn_hdl, p_peer->hdls.fat_burn_heart_rate_upper_limit_char_val_hdl);
}

ble_status_t R_BLE_UDC_WriteFatBurnHeartRateUpperLimit (uint16_t conn_hdl, uint8_t app_value) // @suppress("API function naming")
{
    /*ble_status_t ret;*/
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.fat_burn_heart_rate_upper_limit_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    uint8_t byte_value[BLE_UDC_FAT_BURN_HEART_RATE_UPPER_LIMIT_LEN];

    BT_PACK_LE_1_BYTE(byte_value, &app_value);

    st_ble_gatt_hdl_value_pair_t write_value =
    { 
        .attr_hdl = p_peer->hdls.fat_burn_heart_rate_upper_limit_char_val_hdl, 
        .value    =
        { 
            .p_value   = byte_value, 
            .value_len = BLE_UDC_FAT_BURN_HEART_RATE_UPPER_LIMIT_LEN, 
        } 
    };

    return R_BLE_GATTC_WriteChar(conn_hdl, &write_value);
}

ble_status_t R_BLE_UDC_ReadAerobicHeartRateLowerLimit (uint16_t conn_hdl) // @suppress("API function naming")
{
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.aerobic_heart_rate_lower_limit_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    return R_BLE_GATTC_ReadChar(conn_hdl, p_peer->hdls.aerobic_heart_rate_lower_limit_char_val_hdl);
}

ble_status_t R_BLE_UDC_WriteAerobicHeartRateLowerLimit (uint16_t conn_hdl, uint8_t app_value) // @suppress("API function naming")
{
    /*ble_status_t ret;*/
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.aerobic_heart_rate_lower_limit_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    uint8_t byte_value[BLE_UDC_AEROBIC_HEART_RATE_LOWER_LIMIT_LEN];

    BT_PACK_LE_1_BYTE(byte_value, &app_value);

    st_ble_gatt_hdl_value_pair_t write_value =
    { 
        .attr_hdl = p_peer->hdls.aerobic_heart_rate_lower_limit_char_val_hdl, 
        .value    =
        { 
            .p_value   = byte_value, 
            .value_len = BLE_UDC_AEROBIC_HEART_RATE_LOWER_LIMIT_LEN, 
        } 
    };

    return R_BLE_GATTC_WriteChar(conn_hdl, &write_value);
}

ble_status_t R_BLE_UDC_ReadAerobicHeartRateUpperLimit (uint16_t conn_hdl) // @suppress("API function naming")
{
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.aerobic_heart_rate_upper_limit_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    return R_BLE_GATTC_ReadChar(conn_hdl, p_peer->hdls.aerobic_heart_rate_upper_limit_char_val_hdl);
}

ble_status_t R_BLE_UDC_WriteAerobicHeartRateUpperLimit (uint16_t conn_hdl, uint8_t app_value) // @suppress("API function naming")
{
    /*ble_status_t ret;*/
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.aerobic_heart_rate_upper_limit_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    uint8_t byte_value[BLE_UDC_AEROBIC_HEART_RATE_UPPER_LIMIT_LEN];

    BT_PACK_LE_1_BYTE(byte_value, &app_value);

    st_ble_gatt_hdl_value_pair_t write_value =
    { 
        .attr_hdl = p_peer->hdls.aerobic_heart_rate_upper_limit_char_val_hdl, 
        .value    =
        { 
            .p_value   = byte_value, 
            .value_len = BLE_UDC_AEROBIC_HEART_RATE_UPPER_LIMIT_LEN, 
        } 
    };

    return R_BLE_GATTC_WriteChar(conn_hdl, &write_value);
}

ble_status_t R_BLE_UDC_ReadAnaerobicHeartRateLowerLimit (uint16_t conn_hdl) // @suppress("API function naming")
{
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.anaerobic_heart_rate_lower_limit_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    return R_BLE_GATTC_ReadChar(conn_hdl, p_peer->hdls.anaerobic_heart_rate_lower_limit_char_val_hdl);
}

ble_status_t R_BLE_UDC_WriteAnaerobicHeartRateLowerLimit (uint16_t conn_hdl, uint8_t app_value) // @suppress("API function naming")
{
    /*ble_status_t ret;*/
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.anaerobic_heart_rate_lower_limit_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    uint8_t byte_value[BLE_UDC_ANAEROBIC_HEART_RATE_LOWER_LIMIT_LEN];

    BT_PACK_LE_1_BYTE(byte_value, &app_value);

    st_ble_gatt_hdl_value_pair_t write_value =
    { 
        .attr_hdl = p_peer->hdls.anaerobic_heart_rate_lower_limit_char_val_hdl, 
        .value    =
        { 
            .p_value   = byte_value, 
            .value_len = BLE_UDC_ANAEROBIC_HEART_RATE_LOWER_LIMIT_LEN, 
        } 
    };

    return R_BLE_GATTC_WriteChar(conn_hdl, &write_value);
}

ble_status_t R_BLE_UDC_ReadAnaerobicHeartRateUpperLimit (uint16_t conn_hdl) // @suppress("API function naming")
{
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.anaerobic_heart_rate_upper_limit_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    return R_BLE_GATTC_ReadChar(conn_hdl, p_peer->hdls.anaerobic_heart_rate_upper_limit_char_val_hdl);
}

ble_status_t R_BLE_UDC_WriteAnaerobicHeartRateUpperLimit (uint16_t conn_hdl, uint8_t app_value) // @suppress("API function naming")
{
    /*ble_status_t ret;*/
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.anaerobic_heart_rate_upper_limit_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    uint8_t byte_value[BLE_UDC_ANAEROBIC_HEART_RATE_UPPER_LIMIT_LEN];

    BT_PACK_LE_1_BYTE(byte_value, &app_value);

    st_ble_gatt_hdl_value_pair_t write_value =
    { 
        .attr_hdl = p_peer->hdls.anaerobic_heart_rate_upper_limit_char_val_hdl, 
        .value    =
        { 
            .p_value   = byte_value, 
            .value_len = BLE_UDC_ANAEROBIC_HEART_RATE_UPPER_LIMIT_LEN, 
        } 
    };

    return R_BLE_GATTC_WriteChar(conn_hdl, &write_value);
}

ble_status_t R_BLE_UDC_ReadFiveZoneHeartRateLimits (uint16_t conn_hdl) // @suppress("API function naming")
{
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.five_zone_heart_rate_limits_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    return R_BLE_GATTC_ReadChar(conn_hdl, p_peer->hdls.five_zone_heart_rate_limits_char_val_hdl);
}

ble_status_t R_BLE_UDC_WriteFiveZoneHeartRateLimits (uint16_t conn_hdl,
        const st_ble_udc_five_zone_heart_rate_limits_t *p_app_value) // @suppress("API function naming")
{
    ble_status_t ret;
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (NULL == p_app_value)
    {
        return BLE_ERR_INVALID_PTR;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.five_zone_heart_rate_limits_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    uint8_t byte_value[BLE_UDC_FIVE_ZONE_HEART_RATE_LIMITS_LEN];

    st_ble_gatt_hdl_value_pair_t write_value =
    { 
        .attr_hdl = p_peer->hdls.five_zone_heart_rate_limits_char_val_hdl, 
        .value    =
        { 
            .p_value   = byte_value, 
            .value_len = BLE_UDC_FIVE_ZONE_HEART_RATE_LIMITS_LEN, 
        } 
    };

    ret = encode_five_zone_heart_rate_limits(p_app_value, &write_value.value);
    ret = R_BLE_GATTC_WriteChar(conn_hdl, &write_value);

    return ret;
}

ble_status_t R_BLE_UDC_ReadThreeZoneHeartRateLimits (uint16_t conn_hdl) // @suppress("API function naming")
{
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.three_zone_heart_rate_limits_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    return R_BLE_GATTC_ReadChar(conn_hdl, p_peer->hdls.three_zone_heart_rate_limits_char_val_hdl);
}

ble_status_t R_BLE_UDC_WriteThreeZoneHeartRateLimits (uint16_t conn_hdl,
        const st_ble_udc_three_zone_heart_rate_limits_t *p_app_value) // @suppress("API function naming")
{
    ble_status_t ret;
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (NULL == p_app_value)
    {
        return BLE_ERR_INVALID_PTR;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.three_zone_heart_rate_limits_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    uint8_t byte_value[BLE_UDC_THREE_ZONE_HEART_RATE_LIMITS_LEN];

    st_ble_gatt_hdl_value_pair_t write_value =
    { 
        .attr_hdl = p_peer->hdls.three_zone_heart_rate_limits_char_val_hdl, 
        .value    =
        { 
            .p_value   = byte_value, 
            .value_len = BLE_UDC_THREE_ZONE_HEART_RATE_LIMITS_LEN, 
        } 
    };
    
    ret = encode_three_zone_heart_rate_limits(p_app_value, &write_value.value);
    ret = R_BLE_GATTC_WriteChar(conn_hdl, &write_value);

    return ret;
}

ble_status_t R_BLE_UDC_ReadTwoZoneHeartRateLimit (uint16_t conn_hdl) // @suppress("API function naming")
{
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.two_zone_heart_rate_limit_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    return R_BLE_GATTC_ReadChar(conn_hdl, p_peer->hdls.two_zone_heart_rate_limit_char_val_hdl);
}

ble_status_t R_BLE_UDC_WriteTwoZoneHeartRateLimit (uint16_t conn_hdl, uint8_t app_value) // @suppress("API function naming")
{
    /*ble_status_t ret;*/
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.two_zone_heart_rate_limit_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    uint8_t byte_value[BLE_UDC_TWO_ZONE_HEART_RATE_LIMIT_LEN];
    
    BT_PACK_LE_1_BYTE(byte_value, &app_value);

    st_ble_gatt_hdl_value_pair_t write_value =
    { 
        .attr_hdl = p_peer->hdls.two_zone_heart_rate_limit_char_val_hdl, 
        .value    =
        { 
            .p_value   = byte_value, 
            .value_len = BLE_UDC_TWO_ZONE_HEART_RATE_LIMIT_LEN, 
        } 
    };

    return R_BLE_GATTC_WriteChar(conn_hdl, &write_value);
}

ble_status_t R_BLE_UDC_ReadDatabaseChangeIncrement (uint16_t conn_hdl) // @suppress("API function naming")
{
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.database_change_increment_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    return R_BLE_GATTC_ReadChar(conn_hdl, p_peer->hdls.database_change_increment_char_val_hdl);
}

ble_status_t R_BLE_UDC_WriteDatabaseChangeIncrement (uint16_t conn_hdl, uint32_t app_value) // @suppress("API function naming")
{
    /*ble_status_t ret;*/
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.database_change_increment_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    uint8_t byte_value[BLE_UDC_DATABASE_CHANGE_INCREMENT_LEN];

    BT_PACK_LE_4_BYTE(byte_value, &app_value);

    st_ble_gatt_hdl_value_pair_t write_value =
    { 
        .attr_hdl = p_peer->hdls.database_change_increment_char_val_hdl, 
        .value    =
        {
            .p_value   = byte_value, 
            .value_len = BLE_UDC_DATABASE_CHANGE_INCREMENT_LEN, 
        }
    };

    return R_BLE_GATTC_WriteChar(conn_hdl, &write_value);
}

ble_status_t R_BLE_UDC_SetDatabaseChangeIncrementCliCnfg (uint16_t conn_hdl, uint16_t cli_cnfg) // @suppress("API function naming")
{
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.database_change_increment_cli_cnfg_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    if (0 != (cli_cnfg & 0xFFFC))
    {
        return BLE_ERR_INVALID_ARG;
    }

    uint8_t byte_value[2] = { 0 };

    BT_PACK_LE_2_BYTE(byte_value, &cli_cnfg);

    st_ble_gatt_hdl_value_pair_t gatt_value =
    { 
        .attr_hdl = p_peer->hdls.database_change_increment_cli_cnfg_hdl, 
        .value    =
        { 
            .p_value   = byte_value, 
            .value_len = 2, 
        } 
    };

    return R_BLE_GATTC_WriteChar(conn_hdl, &gatt_value);
}

ble_status_t R_BLE_UDC_ReadUserIndex (uint16_t conn_hdl) // @suppress("API function naming")
{
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.user_index_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    return R_BLE_GATTC_ReadChar(conn_hdl, p_peer->hdls.user_index_char_val_hdl);
}

ble_status_t R_BLE_UDC_WriteUserControlPoint (uint16_t conn_hdl, const st_ble_udc_user_control_point_t *p_app_value) // @suppress("API function naming")
{
    ble_status_t ret;
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (NULL == p_app_value)
    {
        return BLE_ERR_INVALID_PTR;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.user_control_point_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    uint8_t byte_value[BLE_UDC_USER_CONTROL_POINT_LEN];

    st_ble_gatt_hdl_value_pair_t write_value =
    { 
        .attr_hdl = p_peer->hdls.user_control_point_char_val_hdl, 
        .value    =
        { 
            .p_value   = byte_value, 
            .value_len = BLE_UDC_USER_CONTROL_POINT_LEN, 
        } 
    };

    ret = encode_user_control_point(p_app_value, &write_value.value);
    ret = R_BLE_GATTC_WriteChar(conn_hdl, &write_value);

    return ret;
}

ble_status_t R_BLE_UDC_SetUserControlPointCliCnfg (uint16_t conn_hdl, uint16_t cli_cnfg) // @suppress("API function naming")
{
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.user_control_point_cli_cnfg_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    if (0 != (cli_cnfg & 0xFFFC))
    {
        return BLE_ERR_INVALID_ARG;
    }

    uint8_t byte_value[2] = { 0 };

    BT_PACK_LE_2_BYTE(byte_value, &cli_cnfg);

    st_ble_gatt_hdl_value_pair_t gatt_value =
    { 
        .attr_hdl = p_peer->hdls.user_control_point_cli_cnfg_hdl,
        .value    =
        {
            .p_value   = byte_value,
            .value_len = 2,
        }
    };

    return R_BLE_GATTC_WriteChar(conn_hdl, &gatt_value);
}

ble_status_t R_BLE_UDC_ReadLanguage (uint16_t conn_hdl) // @suppress("API function naming")
{
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.language_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    return R_BLE_GATTC_ReadLongChar(conn_hdl, p_peer->hdls.language_char_val_hdl, 0);
}

ble_status_t R_BLE_UDC_WriteLanguage (uint16_t conn_hdl, const st_ble_udc_language_t *p_app_value) // @suppress("API function naming")
{
    ble_status_t ret;
    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (NULL == p_app_value)
    {
        return BLE_ERR_INVALID_PTR;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.language_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    uint8_t byte_value[BLE_UDC_LANGUAGE_LEN];

    st_ble_gatt_hdl_value_pair_t write_value =
    { 
        .attr_hdl = p_peer->hdls.language_char_val_hdl, 
        .value    =
        { 
            .p_value   = byte_value, 
            .value_len = BLE_UDC_LANGUAGE_LEN, 
        }
    };

    ret = encode_language(p_app_value, &write_value.value);
    ret = R_BLE_GATTC_WriteLongChar(conn_hdl, &write_value, 0);

    return ret;
}

void R_BLE_UDC_ServDiscCb (uint16_t conn_hdl, uint8_t idx, uint16_t type, void *p_param) // @suppress("API function naming")
{
    UNUSED_ARG(idx);

    st_udc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    switch (type)
    {
        case BLE_DISC_PRIM_SERV_FOUND:
        {
            st_disc_serv_param_t *p_serv_param = (st_disc_serv_param_t *) p_param;
            memcpy( &p_peer->hdls.service_range, &p_serv_param->value.serv_16.range,
                    sizeof(p_peer->hdls.service_range));
        }
        break;

        case BLE_DISC_CHAR_FOUND:
        {
            st_disc_char_param_t *p_char_param = (st_disc_char_param_t *) p_param;

            if (BLE_GATT_16_BIT_UUID_FORMAT == p_char_param->uuid_type)
            {
                uint8_t uuid_16[BLE_GATT_16_BIT_UUID_SIZE];
                BT_PACK_LE_2_BYTE(uuid_16, &p_char_param->value.char_16.uuid_16);

                if (0 == memcmp(uuid_16, BLE_UDC_FIRST_NAME_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.first_name_char_val_hdl = p_char_param->value.char_16.value_hdl;

                }
                else if (0 == memcmp(uuid_16, BLE_UDC_LAST_NAME_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.last_name_char_val_hdl = p_char_param->value.char_16.value_hdl;

                }
                else if (0 == memcmp(uuid_16, BLE_UDC_EMAIL_ADDRESS_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.email_address_char_val_hdl = p_char_param->value.char_16.value_hdl;

                }
                else if (0 == memcmp(uuid_16, BLE_UDC_AGE_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.age_char_val_hdl = p_char_param->value.char_16.value_hdl;

                }
                else if (0 == memcmp(uuid_16, BLE_UDC_DATE_OF_BIRTH_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.date_of_birth_char_val_hdl = p_char_param->value.char_16.value_hdl;

                }
                else if (0 == memcmp(uuid_16, BLE_UDC_GENDER_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.gender_char_val_hdl = p_char_param->value.char_16.value_hdl;

                }
                else if (0 == memcmp(uuid_16, BLE_UDC_WEIGHT_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.weight_char_val_hdl = p_char_param->value.char_16.value_hdl;

                }
                else if (0 == memcmp(uuid_16, BLE_UDC_HEIGHT_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.height_char_val_hdl = p_char_param->value.char_16.value_hdl;

                }
                else if (0 == memcmp(uuid_16, BLE_UDC_VO2_MAX_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.vo2_max_char_val_hdl = p_char_param->value.char_16.value_hdl;

                }
                else if (0 == memcmp(uuid_16, BLE_UDC_HEART_RATE_MAX_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.heart_rate_max_char_val_hdl = p_char_param->value.char_16.value_hdl;

                }
                else if (0 == memcmp(uuid_16, BLE_UDC_RESTING_HEART_RATE_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.resting_heart_rate_char_val_hdl = p_char_param->value.char_16.value_hdl;

                }
                else if (0 == memcmp(uuid_16, BLE_UDC_MAXIMUM_RECOMMENDED_HEART_RATE_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.maximum_recommended_heart_rate_char_val_hdl = p_char_param->value.char_16.value_hdl;

                }
                else if (0 == memcmp(uuid_16, BLE_UDC_AEROBIC_THRESHOLD_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.aerobic_threshold_char_val_hdl = p_char_param->value.char_16.value_hdl;

                }
                else if (0 == memcmp(uuid_16, BLE_UDC_ANAEROBIC_THRESHOLD_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.anaerobic_threshold_char_val_hdl = p_char_param->value.char_16.value_hdl;

                }
                else if (0
                        == memcmp(uuid_16, BLE_UDC_SPORT_TYPE_FOR_AEROBIC_AND_ANAEROBIC_THRESHOLDS_UUID,
                                BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.sport_type_for_aerobic_and_anaerobic_thresholds_char_val_hdl =
                            p_char_param->value.char_16.value_hdl;

                }
                else if (0 == memcmp(uuid_16, BLE_UDC_DATE_OF_THRESHOLD_ASSESSMENT_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.date_of_threshold_assessment_char_val_hdl = p_char_param->value.char_16.value_hdl;

                }
                else if (0 == memcmp(uuid_16, BLE_UDC_WAIST_CIRCUMFERENCE_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.waist_circumference_char_val_hdl = p_char_param->value.char_16.value_hdl;

                }
                else if (0 == memcmp(uuid_16, BLE_UDC_HIP_CIRCUMFERENCE_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.hip_circumference_char_val_hdl = p_char_param->value.char_16.value_hdl;

                }
                else if (0 == memcmp(uuid_16, BLE_UDC_FAT_BURN_HEART_RATE_LOWER_LIMIT_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.fat_burn_heart_rate_lower_limit_char_val_hdl = p_char_param->value.char_16.value_hdl;

                }
                else if (0 == memcmp(uuid_16, BLE_UDC_FAT_BURN_HEART_RATE_UPPER_LIMIT_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.fat_burn_heart_rate_upper_limit_char_val_hdl = p_char_param->value.char_16.value_hdl;

                }
                else if (0 == memcmp(uuid_16, BLE_UDC_AEROBIC_HEART_RATE_LOWER_LIMIT_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.aerobic_heart_rate_lower_limit_char_val_hdl = p_char_param->value.char_16.value_hdl;

                }
                else if (0 == memcmp(uuid_16, BLE_UDC_AEROBIC_HEART_RATE_UPPER_LIMIT_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.aerobic_heart_rate_upper_limit_char_val_hdl = p_char_param->value.char_16.value_hdl;

                }
                else if (0 == memcmp(uuid_16, BLE_UDC_ANAEROBIC_HEART_RATE_LOWER_LIMIT_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.anaerobic_heart_rate_lower_limit_char_val_hdl = p_char_param->value.char_16.value_hdl;

                }
                else if (0 == memcmp(uuid_16, BLE_UDC_ANAEROBIC_HEART_RATE_UPPER_LIMIT_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.anaerobic_heart_rate_upper_limit_char_val_hdl = p_char_param->value.char_16.value_hdl;

                }
                else if (0 == memcmp(uuid_16, BLE_UDC_FIVE_ZONE_HEART_RATE_LIMITS_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.five_zone_heart_rate_limits_char_val_hdl = p_char_param->value.char_16.value_hdl;

                }
                else if (0 == memcmp(uuid_16, BLE_UDC_THREE_ZONE_HEART_RATE_LIMITS_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.three_zone_heart_rate_limits_char_val_hdl = p_char_param->value.char_16.value_hdl;

                }
                else if (0 == memcmp(uuid_16, BLE_UDC_TWO_ZONE_HEART_RATE_LIMIT_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.two_zone_heart_rate_limit_char_val_hdl = p_char_param->value.char_16.value_hdl;

                }
                else if (0 == memcmp(uuid_16, BLE_UDC_DATABASE_CHANGE_INCREMENT_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.database_change_increment_char_val_hdl = p_char_param->value.char_16.value_hdl;

                    for (uint8_t i = 0; i < p_char_param->num_of_descs; i++)
                    {
                        BT_PACK_LE_2_BYTE(uuid_16, &p_char_param->descs[i].value.desc_16.uuid_16);

                        if (0
                                == memcmp(uuid_16,
                                        BLE_UDC_DATABASE_CHANGE_INCREMENT_CLIENT_CHARACTERISTIC_CONFIGURATION_UUID,
                                        BLE_GATT_16_BIT_UUID_SIZE))
                        {
                            p_peer->hdls.database_change_increment_cli_cnfg_hdl =
                                    p_char_param->descs[i].value.desc_16.desc_hdl;
                        }
                    }
                }
                else if (0 == memcmp(uuid_16, BLE_UDC_USER_INDEX_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.user_index_char_val_hdl = p_char_param->value.char_16.value_hdl;

                }
                else if (0 == memcmp(uuid_16, BLE_UDC_USER_CONTROL_POINT_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.user_control_point_char_val_hdl = p_char_param->value.char_16.value_hdl;

                    for (uint8_t i = 0; i < p_char_param->num_of_descs; i++)
                    {
                        BT_PACK_LE_2_BYTE(uuid_16, &p_char_param->descs[i].value.desc_16.uuid_16);

                        if (0
                                == memcmp(uuid_16, BLE_UDC_USER_CONTROL_POINT_CLIENT_CHARACTERISTIC_CONFIGURATION_UUID,
                                        BLE_GATT_16_BIT_UUID_SIZE))
                        {
                            p_peer->hdls.user_control_point_cli_cnfg_hdl =
                                    p_char_param->descs[i].value.desc_16.desc_hdl;
                        }
                    }
                }
                else if (0 == memcmp(uuid_16, BLE_UDC_LANGUAGE_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.language_char_val_hdl = p_char_param->value.char_16.value_hdl;
                }
            }
        }
        break;

        default:
        {
            /* Do nothing. */
        }
        break;
    }
}

uint32_t R_BLE_UDC_GetVersion (void) // @suppress("API function naming")
{
    uint32_t version;

    version = ((BLE_UDC_PRV_VERSION_MAJOR << 16) | (BLE_UDC_PRV_VERSION_MINOR << 8));

    return version;
}

