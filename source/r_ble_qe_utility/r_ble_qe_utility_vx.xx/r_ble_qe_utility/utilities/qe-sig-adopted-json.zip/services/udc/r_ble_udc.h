/***********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
 * SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
 ***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_udc.h
 * Version : 1.0
 * Description : This module implements User Data Service Client.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 22.03.2019 1.00 First Release
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @file
 * @defgroup udc User Data Service Client
 * @{
 * @ingroup profile
 * @brief This is the client for the User Data Service.
 **********************************************************************************************************************/

/***********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 ***********************************************************************************************************************/
#include "profile_cmn/r_ble_serv_common.h"

/***********************************************************************************************************************
 Macro definitions
 ***********************************************************************************************************************/
#ifndef R_BLE_UDC_H
#define R_BLE_UDC_H

/*******************************************************************************************************************//**
 * @brief First Name characteristic value length.
 ***********************************************************************************************************************/
#define BLE_UDC_FIRST_NAME_LEN                                                     (512)
/*******************************************************************************************************************//**
 * @brief Last Name characteristic value length.
 ***********************************************************************************************************************/
#define BLE_UDC_LAST_NAME_LEN                                                      (512)
/*******************************************************************************************************************//**
 * @brief Email Address characteristic value length.
 ***********************************************************************************************************************/
#define BLE_UDC_EMAIL_ADDRESS_LEN                                                  (512)
/*******************************************************************************************************************//**
 * @brief Age characteristic value length.
 ***********************************************************************************************************************/
#define BLE_UDC_AGE_LEN                                                            (1)
/*******************************************************************************************************************//**
 * @brief Date of Birth characteristic value length.
 ***********************************************************************************************************************/
#define BLE_UDC_DATE_OF_BIRTH_LEN                                                  (4)
/*******************************************************************************************************************//**
 * @brief Gender characteristic value length.
 ***********************************************************************************************************************/
#define BLE_UDC_GENDER_LEN                                                         (1)
/*******************************************************************************************************************//**
 * @brief Weight characteristic value length.
 ***********************************************************************************************************************/
#define BLE_UDC_WEIGHT_LEN                                                         (2)
/*******************************************************************************************************************//**
 * @brief Height characteristic value length.
 ***********************************************************************************************************************/
#define BLE_UDC_HEIGHT_LEN                                                         (2)
/*******************************************************************************************************************//**
 * @brief VO2 Max characteristic value length.
 ***********************************************************************************************************************/
#define BLE_UDC_VO2_MAX_LEN                                                        (1)
/*******************************************************************************************************************//**
 * @brief Heart Rate Max characteristic value length.
 ***********************************************************************************************************************/
#define BLE_UDC_HEART_RATE_MAX_LEN                                                 (1)
/*******************************************************************************************************************//**
 * @brief Resting Heart Rate characteristic value length.
 ***********************************************************************************************************************/
#define BLE_UDC_RESTING_HEART_RATE_LEN                                             (1)
/*******************************************************************************************************************//**
 * @brief Maximum Recommended Heart Rate characteristic value length.
 ***********************************************************************************************************************/
#define BLE_UDC_MAXIMUM_RECOMMENDED_HEART_RATE_LEN                                 (1)
/*******************************************************************************************************************//**
 * @brief Aerobic Threshold characteristic value length.
 ***********************************************************************************************************************/
#define BLE_UDC_AEROBIC_THRESHOLD_LEN                                              (1)
/*******************************************************************************************************************//**
 * @brief Anaerobic Threshold characteristic value length.
 ***********************************************************************************************************************/
#define BLE_UDC_ANAEROBIC_THRESHOLD_LEN                                            (1)
/*******************************************************************************************************************//**
 * @brief Sport Type for Aerobic and Anaerobic Thresholds characteristic value length.
 ***********************************************************************************************************************/
#define BLE_UDC_SPORT_TYPE_FOR_AEROBIC_AND_ANAEROBIC_THRESHOLDS_LEN                (1)
/*******************************************************************************************************************//**
 * @brief Date of Threshold Assessment characteristic value length.
 ***********************************************************************************************************************/
#define BLE_UDC_DATE_OF_THRESHOLD_ASSESSMENT_LEN                                   (4)
/*******************************************************************************************************************//**
 * @brief Waist Circumference characteristic value length.
 ***********************************************************************************************************************/
#define BLE_UDC_WAIST_CIRCUMFERENCE_LEN                                            (2)
/*******************************************************************************************************************//**
 * @brief Hip Circumference characteristic value length.
 ***********************************************************************************************************************/
#define BLE_UDC_HIP_CIRCUMFERENCE_LEN                                              (2)
/*******************************************************************************************************************//**
 * @brief Fat Burn Heart Rate Lower Limit characteristic value length.
 ***********************************************************************************************************************/
#define BLE_UDC_FAT_BURN_HEART_RATE_LOWER_LIMIT_LEN                                (1)
/*******************************************************************************************************************//**
 * @brief Fat Burn Heart Rate Upper Limit characteristic value length.
 ***********************************************************************************************************************/
#define BLE_UDC_FAT_BURN_HEART_RATE_UPPER_LIMIT_LEN                                (1)
/*******************************************************************************************************************//**
 * @brief Aerobic Heart Rate Lower Limit characteristic value length.
 ***********************************************************************************************************************/
#define BLE_UDC_AEROBIC_HEART_RATE_LOWER_LIMIT_LEN                                 (1)
/*******************************************************************************************************************//**
 * @brief Aerobic Heart Rate Upper Limit characteristic value length.
 ***********************************************************************************************************************/
#define BLE_UDC_AEROBIC_HEART_RATE_UPPER_LIMIT_LEN                                 (1)
/*******************************************************************************************************************//**
 * @brief Anaerobic Heart Rate Lower Limit characteristic value length.
 ***********************************************************************************************************************/
#define BLE_UDC_ANAEROBIC_HEART_RATE_LOWER_LIMIT_LEN                               (1)
/*******************************************************************************************************************//**
 * @brief Anaerobic Heart Rate Upper Limit characteristic value length.
 ***********************************************************************************************************************/
#define BLE_UDC_ANAEROBIC_HEART_RATE_UPPER_LIMIT_LEN                               (1)
/*******************************************************************************************************************//**
 * @brief Five Zone Heart Rate Limits characteristic value length.
 ***********************************************************************************************************************/
#define BLE_UDC_FIVE_ZONE_HEART_RATE_LIMITS_LEN                                    (4)
/*******************************************************************************************************************//**
 * @brief Three Zone Heart Rate Limits characteristic value length.
 ***********************************************************************************************************************/
#define BLE_UDC_THREE_ZONE_HEART_RATE_LIMITS_LEN                                   (2)
/*******************************************************************************************************************//**
 * @brief Two Zone Heart Rate Limit characteristic value length.
 ***********************************************************************************************************************/
#define BLE_UDC_TWO_ZONE_HEART_RATE_LIMIT_LEN                                      (1)
/*******************************************************************************************************************//**
 * @brief Database Change Increment characteristic value length.
 ***********************************************************************************************************************/
#define BLE_UDC_DATABASE_CHANGE_INCREMENT_LEN                                      (4)
/*******************************************************************************************************************//**
 * @brief User Index characteristic value length.
 ***********************************************************************************************************************/
#define BLE_UDC_USER_INDEX_LEN                                                     (1)
/*******************************************************************************************************************//**
 * @brief User Control Point characteristic value length.
 ***********************************************************************************************************************/
#define BLE_UDC_USER_CONTROL_POINT_LEN                                             (20)
/*******************************************************************************************************************//**
 * @brief Language characteristic value length.
 ***********************************************************************************************************************/
#define BLE_UDC_LANGUAGE_LEN                                                       (20)
/*******************************************************************************************************************//**
 * @brief User Data Access Not Permitted error code.
 ***********************************************************************************************************************/
#define BLE_UDC_USER_DATA_ACCESS_NOT_PERMITTED                                     (BLE_ERR_GROUP_GATT | 0x80)

 /*******************************************************************************************************************//**
  * @brief User Data Control Point Opcode Parameter length.
 ***********************************************************************************************************************/
#define BLE_UDC_CONTROL_POINT_OPCODE_PARAMETER_LEN                                 (18)

 /*******************************************************************************************************************//**
  * @brief User Data Control Point Response Parameter length.
 ***********************************************************************************************************************/
#define BLE_UDC_CONTROL_POINT_RESPONSE_PARAMETER_LEN                               (17)

/***********************************************************************************************************************
 Typedef definitions
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @brief User Data Service Client event data.
 ***********************************************************************************************************************/
typedef struct
{
    uint16_t conn_hdl; /**< Connection handle */
    uint16_t param_len; /**< Event parameter length */
    void     *p_param; /**< Event parameter */
} st_ble_udc_evt_data_t;

/*******************************************************************************************************************//**
 * @brief User Data Service Client event callback.
 ***********************************************************************************************************************/
typedef void (*ble_udc_app_cb_t) (uint16_t type, ble_status_t result, st_ble_udc_evt_data_t *p_data);

/*******************************************************************************************************************//**
 * @brief User Data Service Client event type.
 ***********************************************************************************************************************/
typedef enum
{
    BLE_UDC_EVENT_FIRST_NAME_WRITE_RSP, /**< First Name characteristic write response event */
    BLE_UDC_EVENT_FIRST_NAME_READ_RSP, /**< First Name characteristic read response event */
    BLE_UDC_EVENT_LAST_NAME_WRITE_RSP, /**< Last Name characteristic write response event */
    BLE_UDC_EVENT_LAST_NAME_READ_RSP, /**< Last Name characteristic read response event */
    BLE_UDC_EVENT_EMAIL_ADDRESS_WRITE_RSP, /**< Email Address characteristic write response event */
    BLE_UDC_EVENT_EMAIL_ADDRESS_READ_RSP, /**< Email Address characteristic read response event */
    BLE_UDC_EVENT_AGE_WRITE_RSP, /**< Age characteristic write response event */
    BLE_UDC_EVENT_AGE_READ_RSP, /**< Age characteristic read response event */
    BLE_UDC_EVENT_DATE_OF_BIRTH_WRITE_RSP, /**< Date of Birth characteristic write response event */
    BLE_UDC_EVENT_DATE_OF_BIRTH_READ_RSP, /**< Date of Birth characteristic read response event */
    BLE_UDC_EVENT_GENDER_WRITE_RSP, /**< Gender characteristic write response event */
    BLE_UDC_EVENT_GENDER_READ_RSP, /**< Gender characteristic read response event */
    BLE_UDC_EVENT_WEIGHT_WRITE_RSP, /**< Weight characteristic write response event */
    BLE_UDC_EVENT_WEIGHT_READ_RSP, /**< Weight characteristic read response event */
    BLE_UDC_EVENT_HEIGHT_WRITE_RSP, /**< Height characteristic write response event */
    BLE_UDC_EVENT_HEIGHT_READ_RSP, /**< Height characteristic read response event */
    BLE_UDC_EVENT_VO2_MAX_WRITE_RSP, /**< VO2 Max characteristic write response event */
    BLE_UDC_EVENT_VO2_MAX_READ_RSP, /**< VO2 Max characteristic read response event */
    BLE_UDC_EVENT_HEART_RATE_MAX_WRITE_RSP, /**< Heart Rate Max characteristic write response event */
    BLE_UDC_EVENT_HEART_RATE_MAX_READ_RSP, /**< Heart Rate Max characteristic read response event */
    BLE_UDC_EVENT_RESTING_HEART_RATE_WRITE_RSP, /**< Resting Heart Rate characteristic write response event */
    BLE_UDC_EVENT_RESTING_HEART_RATE_READ_RSP, /**< Resting Heart Rate characteristic read response event */
    BLE_UDC_EVENT_MAXIMUM_RECOMMENDED_HEART_RATE_WRITE_RSP, /**< Maximum Recommended Heart Rate characteristic write 
                                                            response event */
    BLE_UDC_EVENT_MAXIMUM_RECOMMENDED_HEART_RATE_READ_RSP, /**< Maximum Recommended Heart Rate characteristic read 
                                                           response event */
    BLE_UDC_EVENT_AEROBIC_THRESHOLD_WRITE_RSP, /**< Aerobic Threshold characteristic write response event */
    BLE_UDC_EVENT_AEROBIC_THRESHOLD_READ_RSP, /**< Aerobic Threshold characteristic read response event */
    BLE_UDC_EVENT_ANAEROBIC_THRESHOLD_WRITE_RSP, /**< Anaerobic Threshold characteristic write response event */
    BLE_UDC_EVENT_ANAEROBIC_THRESHOLD_READ_RSP, /**< Anaerobic Threshold characteristic read response event */
    BLE_UDC_EVENT_SPORT_TYPE_FOR_AEROBIC_AND_ANAEROBIC_THRESHOLDS_WRITE_RSP, /**< Sport Type for Aerobic and Anaerobic 
                                                                        Thresholds characteristic write response event */
    BLE_UDC_EVENT_SPORT_TYPE_FOR_AEROBIC_AND_ANAEROBIC_THRESHOLDS_READ_RSP, /**< Sport Type for Aerobic and Anaerobic 
                                                                        Thresholds characteristic read response event */
    BLE_UDC_EVENT_DATE_OF_THRESHOLD_ASSESSMENT_WRITE_RSP, /**< Date of Threshold Assessment characteristic write response 
                                                          event */
    BLE_UDC_EVENT_DATE_OF_THRESHOLD_ASSESSMENT_READ_RSP, /**< Date of Threshold Assessment characteristic read response 
                                                         event */
    BLE_UDC_EVENT_WAIST_CIRCUMFERENCE_WRITE_RSP, /**< Waist Circumference characteristic write response event */
    BLE_UDC_EVENT_WAIST_CIRCUMFERENCE_READ_RSP, /**< Waist Circumference characteristic read response event */
    BLE_UDC_EVENT_HIP_CIRCUMFERENCE_WRITE_RSP, /**< Hip Circumference characteristic write response event */
    BLE_UDC_EVENT_HIP_CIRCUMFERENCE_READ_RSP, /**< Hip Circumference characteristic read response event */
    BLE_UDC_EVENT_FAT_BURN_HEART_RATE_LOWER_LIMIT_WRITE_RSP, /**< Fat Burn Heart Rate Lower Limit characteristic 
                                                             write response event */
    BLE_UDC_EVENT_FAT_BURN_HEART_RATE_LOWER_LIMIT_READ_RSP, /**< Fat Burn Heart Rate Lower Limit characteristic 
                                                            read response event */
    BLE_UDC_EVENT_FAT_BURN_HEART_RATE_UPPER_LIMIT_WRITE_RSP, /**< Fat Burn Heart Rate Upper Limit characteristic 
                                                             write response event */
    BLE_UDC_EVENT_FAT_BURN_HEART_RATE_UPPER_LIMIT_READ_RSP, /**< Fat Burn Heart Rate Upper Limit characteristic 
                                                            read response event */
    BLE_UDC_EVENT_AEROBIC_HEART_RATE_LOWER_LIMIT_WRITE_RSP, /**< Aerobic Heart Rate Lower Limit characteristic 
                                                            write response event */
    BLE_UDC_EVENT_AEROBIC_HEART_RATE_LOWER_LIMIT_READ_RSP, /**< Aerobic Heart Rate Lower Limit characteristic 
                                                           read response event */
    BLE_UDC_EVENT_AEROBIC_HEART_RATE_UPPER_LIMIT_WRITE_RSP, /**< Aerobic Heart Rate Upper Limit characteristic 
                                                            write response event */
    BLE_UDC_EVENT_AEROBIC_HEART_RATE_UPPER_LIMIT_READ_RSP, /**< Aerobic Heart Rate Upper Limit characteristic 
                                                           read response event */
    BLE_UDC_EVENT_ANAEROBIC_HEART_RATE_LOWER_LIMIT_WRITE_RSP, /**< Anaerobic Heart Rate Lower Limit characteristic 
                                                              write response event */
    BLE_UDC_EVENT_ANAEROBIC_HEART_RATE_LOWER_LIMIT_READ_RSP, /**< Anaerobic Heart Rate Lower Limit characteristic 
                                                             read response event */
    BLE_UDC_EVENT_ANAEROBIC_HEART_RATE_UPPER_LIMIT_WRITE_RSP, /**< Anaerobic Heart Rate Upper Limit characteristic 
                                                              write response event */
    BLE_UDC_EVENT_ANAEROBIC_HEART_RATE_UPPER_LIMIT_READ_RSP, /**< Anaerobic Heart Rate Upper Limit characteristic 
                                                             read response event */
    BLE_UDC_EVENT_FIVE_ZONE_HEART_RATE_LIMITS_WRITE_RSP, /**< Five Zone Heart Rate Limits characteristic write 
                                                         response event */
    BLE_UDC_EVENT_FIVE_ZONE_HEART_RATE_LIMITS_READ_RSP, /**< Five Zone Heart Rate Limits characteristic read 
                                                        response event */
    BLE_UDC_EVENT_THREE_ZONE_HEART_RATE_LIMITS_WRITE_RSP, /**< Three Zone Heart Rate Limits characteristic write 
                                                          response event */
    BLE_UDC_EVENT_THREE_ZONE_HEART_RATE_LIMITS_READ_RSP, /**< Three Zone Heart Rate Limits characteristic read 
                                                         response event */
    BLE_UDC_EVENT_TWO_ZONE_HEART_RATE_LIMIT_WRITE_RSP, /**< Two Zone Heart Rate Limit characteristic write response 
                                                       event */
    BLE_UDC_EVENT_TWO_ZONE_HEART_RATE_LIMIT_READ_RSP, /**< Two Zone Heart Rate Limit characteristic read response 
                                                      event */
    BLE_UDC_EVENT_DATABASE_CHANGE_INCREMENT_HDL_VAL_NTF, /**< Database Change Increment characteristic handle value 
                                                         notification event */
    BLE_UDC_EVENT_DATABASE_CHANGE_INCREMENT_WRITE_RSP, /**< Database Change Increment characteristic write response 
                                                       event */
    BLE_UDC_EVENT_DATABASE_CHANGE_INCREMENT_READ_RSP, /**< Database Change Increment characteristic read response 
                                                      event */
    BLE_UDC_EVENT_USER_INDEX_READ_RSP, /**< User Index characteristic read response event */
    BLE_UDC_EVENT_USER_CONTROL_POINT_HDL_VAL_IND, /**< User Control Point characteristic handle value indication 
                                                  event */
    BLE_UDC_EVENT_USER_CONTROL_POINT_WRITE_RSP, /**< User Control Point characteristic write response event */
    BLE_UDC_EVENT_LANGUAGE_WRITE_RSP, /**< Language characteristic write response event */
    BLE_UDC_EVENT_LANGUAGE_READ_RSP, /**< Language characteristic read response event */
    BLE_UDC_EVENT_CLI_CNFG_WRITE_RSP, /**< Cli Cnfig write response */
    BLE_UDC_EVENT_ERROR_RSP, /**< error response */
} e_ble_udc_event_t;

/*******************************************************************************************************************//**
 * @brief Month enumeration.
 ***********************************************************************************************************************/
typedef enum
{
    BLE_UDC_DATE_OF_BIRTH_MONTH_MONTH_IS_NOT_KNOWN = 0,  /**< Unknown Month of Birth */
    BLE_UDC_DATE_OF_BIRTH_MONTH_JANUARY            = 1,  /**< Birth Month - January */
    BLE_UDC_DATE_OF_BIRTH_MONTH_FEBRUARY           = 2,  /**< Birth Month - February*/
    BLE_UDC_DATE_OF_BIRTH_MONTH_MARCH              = 3,  /**< Birth Month - March */
    BLE_UDC_DATE_OF_BIRTH_MONTH_APRIL              = 4,  /**< Birth Month - April */
    BLE_UDC_DATE_OF_BIRTH_MONTH_MAY                = 5,  /**< Birth Month - May */
    BLE_UDC_DATE_OF_BIRTH_MONTH_JUNE               = 6,  /**< Birth Month - June */
    BLE_UDC_DATE_OF_BIRTH_MONTH_JULY               = 7,  /**< Birth Month - July */
    BLE_UDC_DATE_OF_BIRTH_MONTH_AUGUST             = 8,  /**< Birth Month - August */
    BLE_UDC_DATE_OF_BIRTH_MONTH_SEPTEMBER          = 9,  /**< Birth Month - September */
    BLE_UDC_DATE_OF_BIRTH_MONTH_OCTOBER            = 10, /**< Birth Month - October */
    BLE_UDC_DATE_OF_BIRTH_MONTH_NOVEMBER           = 11, /**< Birth Month - November */
    BLE_UDC_DATE_OF_BIRTH_MONTH_DECEMBER           = 12, /**< Birth Month - December */
} e_ble_udc_date_of_birth_t;

/*******************************************************************************************************************//**
 * @brief Gender enumeration.
 ***********************************************************************************************************************/
typedef enum
{
    BLE_UDC_GENDER_GENDER_MALE        = 0, /**< Gender - Male */
    BLE_UDC_GENDER_GENDER_FEMALE      = 1, /**< Gender - Female */
    BLE_UDC_GENDER_GENDER_UNSPECIFIED = 2, /**< Gender - Unspecified */
} e_ble_udc_gender_t;

/*******************************************************************************************************************//**
 * @brief Sport Type for Aerobic and Anaerobic Thresholds enumeration.
 ***********************************************************************************************************************/
typedef enum
{
    BLE_UDC_SPORT_TYPE_FOR_AEROBIC_AND_ANAEROBIC_THRESHOLDS_UNSPECIFIED                 = 0, /**< Threshold Unspecified */
    BLE_UDC_SPORT_TYPE_FOR_AEROBIC_AND_ANAEROBIC_THRESHOLDS_RUNNING__TREADMILL_         = 1, /**< Running (Treadmill) */
    BLE_UDC_SPORT_TYPE_FOR_AEROBIC_AND_ANAEROBIC_THRESHOLDS_CYCLING__ERGOMETER_         = 2, /**< Cycling (Ergometer) */
    BLE_UDC_SPORT_TYPE_FOR_AEROBIC_AND_ANAEROBIC_THRESHOLDS_ROWING__ERGOMETER_          = 3, /**< Rowing (Ergometer) */
    BLE_UDC_SPORT_TYPE_FOR_AEROBIC_AND_ANAEROBIC_THRESHOLDS_CROSS_TRAINING__ELLIPTICAL_ = 4, /**< Cross Training (Elliptical) */
    BLE_UDC_SPORT_TYPE_FOR_AEROBIC_AND_ANAEROBIC_THRESHOLDS_CLIMBING                    = 5, /**< Climbing */
    BLE_UDC_SPORT_TYPE_FOR_AEROBIC_AND_ANAEROBIC_THRESHOLDS_SKIING                      = 6, /**< Skiing */
    BLE_UDC_SPORT_TYPE_FOR_AEROBIC_AND_ANAEROBIC_THRESHOLDS_SKATING                     = 7, /**< Skating */
    BLE_UDC_SPORT_TYPE_FOR_AEROBIC_AND_ANAEROBIC_THRESHOLDS_ARM_EXERCISING              = 8, /**< Arm exercising */
    BLE_UDC_SPORT_TYPE_FOR_AEROBIC_AND_ANAEROBIC_THRESHOLDS_LOWER_BODY_EXERCISING       = 9, /**< Lower body exercising */
    BLE_UDC_SPORT_TYPE_FOR_AEROBIC_AND_ANAEROBIC_THRESHOLDS_UPPER_BODY_EXERCISING       = 10, /**< Upper body exercising */
    BLE_UDC_SPORT_TYPE_FOR_AEROBIC_AND_ANAEROBIC_THRESHOLDS_WHOLE_BODY_EXERCISING       = 11, /**< Whole body exercising */
} e_ble_udc_sport_type_for_aerobic_and_anaerobic_thresholds_t;

/*******************************************************************************************************************//**
 * @brief Month enumeration.
 ***********************************************************************************************************************/
typedef enum
{
    BLE_UDC_DATE_OF_THRESHOLD_ASSESSMENT_MONTH_MONTH_IS_NOT_KNOWN = 0, /**< Month is not known */
    BLE_UDC_DATE_OF_THRESHOLD_ASSESSMENT_MONTH_JANUARY            = 1, /**< January */
    BLE_UDC_DATE_OF_THRESHOLD_ASSESSMENT_MONTH_FEBRUARY           = 2, /**< February */
    BLE_UDC_DATE_OF_THRESHOLD_ASSESSMENT_MONTH_MARCH              = 3, /**< March */
    BLE_UDC_DATE_OF_THRESHOLD_ASSESSMENT_MONTH_APRIL              = 4, /**< April */
    BLE_UDC_DATE_OF_THRESHOLD_ASSESSMENT_MONTH_MAY                = 5, /**< May */
    BLE_UDC_DATE_OF_THRESHOLD_ASSESSMENT_MONTH_JUNE               = 6, /**< June */
    BLE_UDC_DATE_OF_THRESHOLD_ASSESSMENT_MONTH_JULY               = 7, /**< July */
    BLE_UDC_DATE_OF_THRESHOLD_ASSESSMENT_MONTH_AUGUST             = 8, /**< August */
    BLE_UDC_DATE_OF_THRESHOLD_ASSESSMENT_MONTH_SEPTEMBER          = 9, /**< September */
    BLE_UDC_DATE_OF_THRESHOLD_ASSESSMENT_MONTH_OCTOBER            = 10, /**< October */
    BLE_UDC_DATE_OF_THRESHOLD_ASSESSMENT_MONTH_NOVEMBER           = 11, /**< November */
    BLE_UDC_DATE_OF_THRESHOLD_ASSESSMENT_MONTH_DECEMBER           = 12, /**< December */
} e_ble_udc_date_of_threshold_assessment_t;

/*******************************************************************************************************************//**
 * @brief User Index enumeration.
 ***********************************************************************************************************************/
typedef enum
{
    BLE_UDC_USER_INDEX_USER_INDEX_UNKNOWN_USER = 255, /**< Unknown User */
} e_ble_udc_user_index_t;

/*******************************************************************************************************************//**
 * @brief OpCode enumeration.
 ***********************************************************************************************************************/
typedef enum
{
    BLE_UDC_USER_CONTROL_POINT_OPCODE_RESERVED_FOR_FUTURE_USE = 0,  /**< Reserved for future use */
    BLE_UDC_USER_CONTROL_POINT_OPCODE_REGISTER_NEW_USER       = 1,  /**< Register New User */
    BLE_UDC_USER_CONTROL_POINT_OPCODE_CONSENT                 = 2,  /**< Consent */
    BLE_UDC_USER_CONTROL_POINT_OPCODE_DELETE_USER_DATA        = 3,  /**< Delete User Data */
    BLE_UDC_USER_CONTROL_POINT_OPCODE_RESPONSE_CODE           = 32,  /**< Response Code */
} e_ble_udc_user_control_point_opcode_t;

/*******************************************************************************************************************//**
 * @brief Response Value enumeration.
 ***********************************************************************************************************************/
typedef enum
{
    BLE_UDC_USER_CONTROL_POINT_RESPONSE_VALUE_RESERVED_FOR_FUTURE_USE = 0, /**< Reserved for future use */
    BLE_UDC_USER_CONTROL_POINT_RESPONSE_VALUE_SUCCESS                 = 1, /**< Success */
    BLE_UDC_USER_CONTROL_POINT_RESPONSE_VALUE_OP_CODE_NOT_SUPPORTED   = 2, /**< Op Code not supported */
    BLE_UDC_USER_CONTROL_POINT_RESPONSE_VALUE_INVALID_PARAMETER       = 3, /**< Invalid Parameter */
    BLE_UDC_USER_CONTROL_POINT_RESPONSE_VALUE_OPERATION_FAILED        = 4, /**< Operation Failed */
    BLE_UDC_USER_CONTROL_POINT_RESPONSE_VALUE_USER_NOT_AUTHORIZED     = 5, /**< User Not Authorized */
} e_ble_udc_user_control_point_response_value_t;

/*******************************************************************************************************************//**
 * @brief User Data Service attribute handles.
 ***********************************************************************************************************************/
typedef struct
{
    st_ble_gatt_hdl_range_t service_range; /**< User Data Service range */
    uint16_t                first_name_char_val_hdl; /**< First Name characteristic value handle */
    uint16_t                last_name_char_val_hdl; /**< Last Name characteristic value handle */
    uint16_t                email_address_char_val_hdl; /**< Email Address characteristic value handle */
    uint16_t                age_char_val_hdl; /**< Age characteristic value handle */
    uint16_t                date_of_birth_char_val_hdl; /**< Date of Birth characteristic value handle */
    uint16_t                gender_char_val_hdl; /**< Gender characteristic value handle */
    uint16_t                weight_char_val_hdl; /**< Weight characteristic value handle */
    uint16_t                height_char_val_hdl; /**< Height characteristic value handle */
    uint16_t                vo2_max_char_val_hdl; /**< VO2 Max characteristic value handle */
    uint16_t                heart_rate_max_char_val_hdl; /**< Heart Rate Max characteristic value handle */
    uint16_t                resting_heart_rate_char_val_hdl; /**< Resting Heart Rate characteristic value handle */
    uint16_t                maximum_recommended_heart_rate_char_val_hdl; /**< Maximum Recommended Heart Rate 
                                                                         characteristic value handle */
    uint16_t                aerobic_threshold_char_val_hdl; /**< Aerobic Threshold characteristic value handle */
    uint16_t                anaerobic_threshold_char_val_hdl; /**< Anaerobic Threshold characteristic value handle */
    uint16_t                sport_type_for_aerobic_and_anaerobic_thresholds_char_val_hdl; /**< Sport Type for Aerobic 
                                                                    and Anaerobic Thresholds characteristic value handle */
    uint16_t                date_of_threshold_assessment_char_val_hdl; /**< Date of Threshold Assessment characteristic 
                                                                       value handle */
    uint16_t                waist_circumference_char_val_hdl; /**< Waist Circumference characteristic value handle */
    uint16_t                hip_circumference_char_val_hdl; /**< Hip Circumference characteristic value handle */
    uint16_t                fat_burn_heart_rate_lower_limit_char_val_hdl; /**< Fat Burn Heart Rate Lower Limit 
                                                                          characteristic value handle */
    uint16_t                fat_burn_heart_rate_upper_limit_char_val_hdl; /**< Fat Burn Heart Rate Upper Limit 
                                                                          characteristic value handle */
    uint16_t                aerobic_heart_rate_lower_limit_char_val_hdl; /**< Aerobic Heart Rate Lower Limit 
                                                                         characteristic value handle */
    uint16_t                aerobic_heart_rate_upper_limit_char_val_hdl; /**< Aerobic Heart Rate Upper Limit 
                                                                         characteristic value handle */
    uint16_t                anaerobic_heart_rate_lower_limit_char_val_hdl; /**< Anaerobic Heart Rate Lower Limit 
                                                                           characteristic value handle */
    uint16_t                anaerobic_heart_rate_upper_limit_char_val_hdl; /**< Anaerobic Heart Rate Upper Limit 
                                                                           characteristic value handle */
    uint16_t                five_zone_heart_rate_limits_char_val_hdl; /**< Five Zone Heart Rate Limits characteristic 
                                                                      value handle */
    uint16_t                three_zone_heart_rate_limits_char_val_hdl; /**< Three Zone Heart Rate Limits characteristic 
                                                                       value handle */
    uint16_t                two_zone_heart_rate_limit_char_val_hdl; /**< Two Zone Heart Rate Limit characteristic value 
                                                                    handle */
    uint16_t                database_change_increment_char_val_hdl; /**< Database Change Increment characteristic value 
                                                                    handle */
    uint16_t                database_change_increment_cli_cnfg_hdl; /**< Database Change Increment characteristic Client 
                                                                    Characteristic Configuration descriptor handle */
    uint16_t                user_index_char_val_hdl; /**< User Index characteristic value handle */
    uint16_t                user_control_point_char_val_hdl; /**< User Control Point characteristic value handle */
    uint16_t                user_control_point_cli_cnfg_hdl; /**< User Control Point characteristic Client Characteristic 
                                                             Configuration descriptor handle */
    uint16_t                language_char_val_hdl; /**< Language characteristic value handle */
} st_ble_udc_hdls_t;

/*******************************************************************************************************************//**
 * @brief User Data Service initialization parameters.
 ***********************************************************************************************************************/
typedef struct
{
    ble_udc_app_cb_t cb; /**< User Data Service Client event handler */
} st_ble_udc_init_param_t;

/*******************************************************************************************************************//**
 * @brief User Data Service Client connection parameters.
 ***********************************************************************************************************************/
typedef struct
{
    st_ble_udc_hdls_t *p_hdls; /**< User Data Service handles */
} st_ble_udc_connect_param_t;

/*******************************************************************************************************************//**
 * @brief User Data Service disconnection parameters.
 ***********************************************************************************************************************/
typedef struct
{
    st_ble_udc_hdls_t *p_hdls; /**< User Data Service handles */
} st_ble_udc_disconnect_param_t;

/*******************************************************************************************************************//**
 * @brief First Name characteristic parameters.
 ***********************************************************************************************************************/
typedef struct
{
    uint8_t first_name[BLE_UDC_FIRST_NAME_LEN]; /**< First Name value */
} st_ble_udc_first_name_t;

/*******************************************************************************************************************//**
 * @brief Last Name characteristic parameters.
 ***********************************************************************************************************************/
typedef struct
{
    uint8_t last_name[BLE_UDC_LAST_NAME_LEN]; /**< Last Name value */
} st_ble_udc_last_name_t;

/*******************************************************************************************************************//**
 * @brief Email Address characteristic parameters.
 ***********************************************************************************************************************/
typedef struct
{
    uint8_t email_address[BLE_UDC_EMAIL_ADDRESS_LEN]; /**< Email Address value */
} st_ble_udc_email_address_t;

/*******************************************************************************************************************//**
 * @brief Date of Birth characteristic parameters.
 ***********************************************************************************************************************/
typedef struct
{
    uint16_t year; /**< Year value */
    uint8_t  month; /**< Month value */
    uint8_t  day; /**< Day value */
} st_ble_udc_date_of_birth_t;

/*******************************************************************************************************************//**
 * @brief Date of Threshold Assessment characteristic parameters.
 ***********************************************************************************************************************/
typedef struct
{
    uint16_t year; /**< Year value */
    uint8_t  month; /**< Month value */
    uint8_t  day; /**< Day value */
} st_ble_udc_date_of_threshold_assessment_t;

/*******************************************************************************************************************//**
 * @brief Five Zone Heart Rate Limits characteristic parameters.
 ***********************************************************************************************************************/
typedef struct
{
    uint8_t five_zone_heart_rate_limits___very_light___light_limit; /**< Five Zone Heart Rate Limits - Very light / 
                                                                    Light Limit value */
    uint8_t five_zone_heart_rate_limits___light___moderate_limit; /**< Five Zone Heart Rate Limits - Light / 
                                                                  Moderate Limit value */
    uint8_t five_zone_heart_rate_limits___moderate___hard_limit; /**< Five Zone Heart Rate Limits - Moderate / 
                                                                 Hard Limit value */
    uint8_t five_zone_heart_rate_limits___hard___maximum_limit; /**< Five Zone Heart Rate Limits - Hard / 
                                                                Maximum Limit value */
} st_ble_udc_five_zone_heart_rate_limits_t;

/*******************************************************************************************************************//**
 * @brief Three Zone Heart Rate Limits characteristic parameters.
 ***********************************************************************************************************************/
typedef struct
{
    uint8_t three_zone_heart_rate_limits___light__fat_burn____moderate__aerobic__limit; /**< Three zone Heart Rate Limits
                                                                    - Light (Fat burn) / Moderate (Aerobic) Limit value */
    uint8_t three_zone_heart_rate_limits___moderate__aerobic____hard__anaerobic__limit; /**< Three zone Heart Rate Limits
                                                                    - Moderate (Aerobic) / Hard (Anaerobic) Limit value */
} st_ble_udc_three_zone_heart_rate_limits_t;

/*******************************************************************************************************************//**
 * @brief User Control Point characteristic parameters.
 ***********************************************************************************************************************/
typedef struct
{
    uint8_t  opcode;                                                           /**< OpCode value */
    uint16_t consent_code;                                                     /**< Consent Code value */
    uint8_t  user_index;                                                       /**< User Index value */
    uint8_t  parameter[BLE_UDC_CONTROL_POINT_OPCODE_PARAMETER_LEN];            /**< Parameter value */
    uint8_t  response_code;                                                    /**< Response Code value */
    uint8_t  request_opcode;                                                   /**< Request OpCode value */
    uint8_t  response_value;                                                   /**< Response Value value */
    uint8_t  response_parameter[BLE_UDC_CONTROL_POINT_RESPONSE_PARAMETER_LEN]; /**< Response Parameter value */
} st_ble_udc_user_control_point_t;

/*******************************************************************************************************************//**
 * @brief Language characteristic parameters.
 ***********************************************************************************************************************/
typedef struct
{
    uint8_t language[20]; /**< Language value */
} st_ble_udc_language_t;

/***********************************************************************************************************************
 Exported global variables (to be accessed by other files)
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @brief User Data Service UUID.
 ***********************************************************************************************************************/
extern const uint8_t BLE_UDC_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief First Name characteristic UUID.
 ***********************************************************************************************************************/
extern const uint8_t BLE_UDC_FIRST_NAME_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Last Name characteristic UUID.
 ***********************************************************************************************************************/
extern const uint8_t BLE_UDC_LAST_NAME_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Email Address characteristic UUID.
 ***********************************************************************************************************************/
extern const uint8_t BLE_UDC_EMAIL_ADDRESS_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Age characteristic UUID.
 ***********************************************************************************************************************/
extern const uint8_t BLE_UDC_AGE_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Date of Birth characteristic UUID.
 ***********************************************************************************************************************/
extern const uint8_t BLE_UDC_DATE_OF_BIRTH_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Gender characteristic UUID.
 ***********************************************************************************************************************/
extern const uint8_t BLE_UDC_GENDER_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Weight characteristic UUID.
 ***********************************************************************************************************************/
extern const uint8_t BLE_UDC_WEIGHT_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Height characteristic UUID.
 ***********************************************************************************************************************/
extern const uint8_t BLE_UDC_HEIGHT_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief VO2 Max characteristic UUID.
 ***********************************************************************************************************************/
extern const uint8_t BLE_UDC_VO2_MAX_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Heart Rate Max characteristic UUID.
 ***********************************************************************************************************************/
extern const uint8_t BLE_UDC_HEART_RATE_MAX_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Resting Heart Rate characteristic UUID.
 ***********************************************************************************************************************/
extern const uint8_t BLE_UDC_RESTING_HEART_RATE_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Maximum Recommended Heart Rate characteristic UUID.
 ***********************************************************************************************************************/
extern const uint8_t BLE_UDC_MAXIMUM_RECOMMENDED_HEART_RATE_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Aerobic Threshold characteristic UUID.
 ***********************************************************************************************************************/
extern const uint8_t BLE_UDC_AEROBIC_THRESHOLD_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Anaerobic Threshold characteristic UUID.
 ***********************************************************************************************************************/
extern const uint8_t BLE_UDC_ANAEROBIC_THRESHOLD_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Sport Type for Aerobic and Anaerobic Thresholds characteristic UUID.
 ***********************************************************************************************************************/
extern const uint8_t BLE_UDC_SPORT_TYPE_FOR_AEROBIC_AND_ANAEROBIC_THRESHOLDS_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Date of Threshold Assessment characteristic UUID.
 ***********************************************************************************************************************/
extern const uint8_t BLE_UDC_DATE_OF_THRESHOLD_ASSESSMENT_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Waist Circumference characteristic UUID.
 ***********************************************************************************************************************/
extern const uint8_t BLE_UDC_WAIST_CIRCUMFERENCE_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Hip Circumference characteristic UUID.
 ***********************************************************************************************************************/
extern const uint8_t BLE_UDC_HIP_CIRCUMFERENCE_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Fat Burn Heart Rate Lower Limit characteristic UUID.
 ***********************************************************************************************************************/
extern const uint8_t BLE_UDC_FAT_BURN_HEART_RATE_LOWER_LIMIT_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Fat Burn Heart Rate Upper Limit characteristic UUID.
 ***********************************************************************************************************************/
extern const uint8_t BLE_UDC_FAT_BURN_HEART_RATE_UPPER_LIMIT_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Aerobic Heart Rate Lower Limit characteristic UUID.
 ***********************************************************************************************************************/
extern const uint8_t BLE_UDC_AEROBIC_HEART_RATE_LOWER_LIMIT_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Aerobic Heart Rate Upper Limit characteristic UUID.
 ***********************************************************************************************************************/
extern const uint8_t BLE_UDC_AEROBIC_HEART_RATE_UPPER_LIMIT_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Anaerobic Heart Rate Lower Limit characteristic UUID.
 ***********************************************************************************************************************/
extern const uint8_t BLE_UDC_ANAEROBIC_HEART_RATE_LOWER_LIMIT_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Anaerobic Heart Rate Upper Limit characteristic UUID.
 ***********************************************************************************************************************/
extern const uint8_t BLE_UDC_ANAEROBIC_HEART_RATE_UPPER_LIMIT_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Five Zone Heart Rate Limits characteristic UUID.
 ***********************************************************************************************************************/
extern const uint8_t BLE_UDC_FIVE_ZONE_HEART_RATE_LIMITS_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Three Zone Heart Rate Limits characteristic UUID.
 ***********************************************************************************************************************/
extern const uint8_t BLE_UDC_THREE_ZONE_HEART_RATE_LIMITS_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Two Zone Heart Rate Limit characteristic UUID.
 ***********************************************************************************************************************/
extern const uint8_t BLE_UDC_TWO_ZONE_HEART_RATE_LIMIT_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Database Change Increment characteristic UUID.
 ***********************************************************************************************************************/
extern const uint8_t BLE_UDC_DATABASE_CHANGE_INCREMENT_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief User Index characteristic UUID.
 ***********************************************************************************************************************/
extern const uint8_t BLE_UDC_USER_INDEX_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief User Control Point characteristic UUID.
 ***********************************************************************************************************************/
extern const uint8_t BLE_UDC_USER_CONTROL_POINT_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Language characteristic UUID.
 ***********************************************************************************************************************/
extern const uint8_t BLE_UDC_LANGUAGE_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/***********************************************************************************************************************
 Exported global functions (to be accessed by other files)
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @brief     Initialize User Data Service  Client.
 * @details   This function shall be called once at startup.
 * @param[in] p_param Pointer to User Data Service Client initialization parameters.
 * @return    @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_Init (const st_ble_udc_init_param_t *p_param);

/*******************************************************************************************************************//**
 * @brief     Perform User Data Service Client connection settings.
 * @details   This function shall be called on each connection establishment.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_param    Pointer to Connection parameters.
 * @return    @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_Connect (uint16_t conn_hdl, const st_ble_udc_connect_param_t *p_param);

/*******************************************************************************************************************//**
 * @brief     Retrieve User Data Service Client connection specific settings before disconnection.
 * @details   This function shall be called on each disconnection.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_param  Pointer to Disconnection parameters.
 * @return    @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_Disconnect (uint16_t conn_hdl, st_ble_udc_disconnect_param_t *p_param);

/*******************************************************************************************************************//**
 * @brief      Read First Name characteristic value from remote GATT database.
 * @param[in]  conn_hdl Connection handle.
 * @return     @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_ReadFirstName (uint16_t conn_hdl);

/*******************************************************************************************************************//**
 * @brief     Write First Name characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] p_app_value Pointer to First Name characteristic value to write.
 * @return    @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_WriteFirstName (uint16_t conn_hdl, const st_ble_udc_first_name_t *p_app_value);

/*******************************************************************************************************************//**
 * @brief      Read Last Name characteristic value from remote GATT database.
 * @param[in]  conn_hdl Connection handle.
 * @return     @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_ReadLastName (uint16_t conn_hdl);

/*******************************************************************************************************************//**
 * @brief     Write Last Name characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] p_app_value Pointer to Last Name characteristic value to write.
 * @return    @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_WriteLastName (uint16_t conn_hdl, const st_ble_udc_last_name_t *p_app_value);

/*******************************************************************************************************************//**
 * @brief      Read Email Address characteristic value from remote GATT database.
 * @param[in]  conn_hdl Connection handle.
 * @return     @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_ReadEmailAddress (uint16_t conn_hdl);

/*******************************************************************************************************************//**
 * @brief     Write Email Address characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] p_app_value Pointer to Email Address characteristic value to write.
 * @return    @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_WriteEmailAddress (uint16_t conn_hdl, const st_ble_udc_email_address_t *p_app_value);

/*******************************************************************************************************************//**
 * @brief      Read Age characteristic value from remote GATT database.
 * @param[in]  conn_hdl Connection handle.
 * @return     @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_ReadAge (uint16_t conn_hdl);

/*******************************************************************************************************************//**
 * @brief     Write Age characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] app_value Age characteristic value to write.
 * @return    @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_WriteAge (uint16_t conn_hdl, uint8_t app_value);

/*******************************************************************************************************************//**
 * @brief      Read Date of Birth characteristic value from remote GATT database.
 * @param[in]  conn_hdl Connection handle.
 * @return     @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_ReadDateOfBirth (uint16_t conn_hdl);

/*******************************************************************************************************************//**
 * @brief     Write Date of Birth characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] p_app_value Pointer to Date of Birth characteristic value to write.
 * @return    @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_WriteDateOfBirth (uint16_t conn_hdl, const st_ble_udc_date_of_birth_t *p_app_value);

/*******************************************************************************************************************//**
 * @brief      Read Gender characteristic value from remote GATT database.
 * @param[in]  conn_hdl Connection handle.
 * @return     @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_ReadGender (uint16_t conn_hdl);

/*******************************************************************************************************************//**
 * @brief     Write Gender characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] app_value Gender characteristic value to write.
 * @return    @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_WriteGender (uint16_t conn_hdl, uint8_t app_value);

/*******************************************************************************************************************//**
 * @brief      Read Weight characteristic value from remote GATT database.
 * @param[in]  conn_hdl Connection handle.
 * @return     @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_ReadWeight (uint16_t conn_hdl);

/*******************************************************************************************************************//**
 * @brief     Write Weight characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] app_value Weight characteristic value to write.
 * @return    @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_WriteWeight (uint16_t conn_hdl, uint16_t app_value);

/*******************************************************************************************************************//**
 * @brief      Read Height characteristic value from remote GATT database.
 * @param[in]  conn_hdl Connection handle.
 * @return     @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_ReadHeight (uint16_t conn_hdl);

/*******************************************************************************************************************//**
 * @brief     Write Height characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] app_value Height characteristic value to write.
 * @return    @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_WriteHeight (uint16_t conn_hdl, uint16_t app_value);

/*******************************************************************************************************************//**
 * @brief      Read VO2 Max characteristic value from remote GATT database.
 * @param[in]  conn_hdl Connection handle.
 * @return     @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_ReadVo2Max (uint16_t conn_hdl);

/*******************************************************************************************************************//**
 * @brief     Write VO2 Max characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] app_value VO2 Max characteristic value to write.
 * @return    @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_WriteVo2Max (uint16_t conn_hdl, uint8_t app_value);

/*******************************************************************************************************************//**
 * @brief      Read Heart Rate Max characteristic value from remote GATT database.
 * @param[in]  conn_hdl Connection handle.
 * @return     @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_ReadHeartRateMax (uint16_t conn_hdl);

/*******************************************************************************************************************//**
 * @brief     Write Heart Rate Max characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] app_value Heart Rate Max characteristic value to write.
 * @return    @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_WriteHeartRateMax (uint16_t conn_hdl, uint8_t app_value);

/*******************************************************************************************************************//**
 * @brief      Read Resting Heart Rate characteristic value from remote GATT database.
 * @param[in]  conn_hdl Connection handle.
 * @return     @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_ReadRestingHeartRate (uint16_t conn_hdl);

/*******************************************************************************************************************//**
 * @brief     Write Resting Heart Rate characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] app_value Resting Heart Rate characteristic value to write.
 * @return    @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_WriteRestingHeartRate (uint16_t conn_hdl, uint8_t app_value);

/*******************************************************************************************************************//**
 * @brief      Read Maximum Recommended Heart Rate characteristic value from remote GATT database.
 * @param[in]  conn_hdl Connection handle.
 * @return     @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_ReadMaximumRecommendedHeartRate (uint16_t conn_hdl);

/*******************************************************************************************************************//**
 * @brief     Write Maximum Recommended Heart Rate characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] app_value Maximum Recommended Heart Rate characteristic value to write.
 * @return    @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_WriteMaximumRecommendedHeartRate (uint16_t conn_hdl, uint8_t app_value);

/*******************************************************************************************************************//**
 * @brief      Read Aerobic Threshold characteristic value from remote GATT database.
 * @param[in]  conn_hdl Connection handle.
 * @return     @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_ReadAerobicThreshold (uint16_t conn_hdl);

/*******************************************************************************************************************//**
 * @brief     Write Aerobic Threshold characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] app_value Aerobic Threshold characteristic value to write.
 * @return    @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_WriteAerobicThreshold (uint16_t conn_hdl, uint8_t app_value);

/*******************************************************************************************************************//**
 * @brief      Read Anaerobic Threshold characteristic value from remote GATT database.
 * @param[in]  conn_hdl Connection handle.
 * @return     @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_ReadAnaerobicThreshold (uint16_t conn_hdl);

/*******************************************************************************************************************//**
 * @brief     Write Anaerobic Threshold characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] app_value Anaerobic Threshold characteristic value to write.
 * @return    @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_WriteAnaerobicThreshold (uint16_t conn_hdl, uint8_t app_value);

/*******************************************************************************************************************//**
 * @brief      Read Sport Type for Aerobic and Anaerobic Thresholds characteristic value from remote GATT database.
 * @param[in]  conn_hdl Connection handle.
 * @return     @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_ReadSportTypeForAerobicAndAnaerobicThresholds (uint16_t conn_hdl);

/*******************************************************************************************************************//**
 * @brief     Write Sport Type for Aerobic and Anaerobic Thresholds characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] app_value Sport Type for Aerobic and Anaerobic Thresholds characteristic value to write.
 * @return    @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_WriteSportTypeForAerobicAndAnaerobicThresholds (uint16_t conn_hdl, uint8_t app_value);

/*******************************************************************************************************************//**
 * @brief      Read Date of Threshold Assessment characteristic value from remote GATT database.
 * @param[in]  conn_hdl Connection handle.
 * @return     @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_ReadDateOfThresholdAssessment (uint16_t conn_hdl);

/*******************************************************************************************************************//**
 * @brief     Write Date of Threshold Assessment characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] p_app_value Pointer to Date of Threshold Assessment characteristic value to write.
 * @return    @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_WriteDateOfThresholdAssessment (uint16_t conn_hdl,
        const st_ble_udc_date_of_threshold_assessment_t *p_app_value);

/*******************************************************************************************************************//**
 * @brief      Read Waist Circumference characteristic value from remote GATT database.
 * @param[in]  conn_hdl Connection handle.
 * @return     @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_ReadWaistCircumference (uint16_t conn_hdl);

/*******************************************************************************************************************//**
 * @brief     Write Waist Circumference characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] app_value Waist Circumference characteristic value to write.
 * @return    @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_WriteWaistCircumference (uint16_t conn_hdl, uint16_t app_value);

/*******************************************************************************************************************//**
 * @brief      Read Hip Circumference characteristic value from remote GATT database.
 * @param[in]  conn_hdl Connection handle.
 * @return     @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_ReadHipCircumference (uint16_t conn_hdl);

/*******************************************************************************************************************//**
 * @brief     Write Hip Circumference characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] app_value Hip Circumference characteristic value to write.
 * @return    @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_WriteHipCircumference (uint16_t conn_hdl, uint16_t app_value);

/*******************************************************************************************************************//**
 * @brief      Read Fat Burn Heart Rate Lower Limit characteristic value from remote GATT database.
 * @param[in]  conn_hdl Connection handle.
 * @return     @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_ReadFatBurnHeartRateLowerLimit (uint16_t conn_hdl);

/*******************************************************************************************************************//**
 * @brief     Write Fat Burn Heart Rate Lower Limit characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] app_value Fat Burn Heart Rate Lower Limit characteristic value to write.
 * @return    @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_WriteFatBurnHeartRateLowerLimit (uint16_t conn_hdl, uint8_t app_value);

/*******************************************************************************************************************//**
 * @brief      Read Fat Burn Heart Rate Upper Limit characteristic value from remote GATT database.
 * @param[in]  conn_hdl Connection handle.
 * @return     @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_ReadFatBurnHeartRateUpperLimit (uint16_t conn_hdl);

/*******************************************************************************************************************//**
 * @brief     Write Fat Burn Heart Rate Upper Limit characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] app_value Fat Burn Heart Rate Upper Limit characteristic value to write.
 * @return    @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_WriteFatBurnHeartRateUpperLimit (uint16_t conn_hdl, uint8_t app_value);

/*******************************************************************************************************************//**
 * @brief      Read Aerobic Heart Rate Lower Limit characteristic value from remote GATT database.
 * @param[in]  conn_hdl Connection handle.
 * @return     @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_ReadAerobicHeartRateLowerLimit (uint16_t conn_hdl);

/*******************************************************************************************************************//**
 * @brief     Write Aerobic Heart Rate Lower Limit characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] app_value Aerobic Heart Rate Lower Limit characteristic value to write.
 * @return    @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_WriteAerobicHeartRateLowerLimit (uint16_t conn_hdl, uint8_t app_value);

/*******************************************************************************************************************//**
 * @brief      Read Aerobic Heart Rate Upper Limit characteristic value from remote GATT database.
 * @param[in]  conn_hdl Connection handle.
 * @return     @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_ReadAerobicHeartRateUpperLimit (uint16_t conn_hdl);

/*******************************************************************************************************************//**
 * @brief     Write Aerobic Heart Rate Upper Limit characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] app_value Aerobic Heart Rate Upper Limit characteristic value to write.
 * @return    @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_WriteAerobicHeartRateUpperLimit (uint16_t conn_hdl, uint8_t app_value);

/*******************************************************************************************************************//**
 * @brief      Read Anaerobic Heart Rate Lower Limit characteristic value from remote GATT database.
 * @param[in]  conn_hdl Connection handle.
 * @return     @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_ReadAnaerobicHeartRateLowerLimit (uint16_t conn_hdl);

/*******************************************************************************************************************//**
 * @brief     Write Anaerobic Heart Rate Lower Limit characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] app_value Anaerobic Heart Rate Lower Limit characteristic value to write.
 * @return    @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_WriteAnaerobicHeartRateLowerLimit (uint16_t conn_hdl, uint8_t app_value);

/*******************************************************************************************************************//**
 * @brief      Read Anaerobic Heart Rate Upper Limit characteristic value from remote GATT database.
 * @param[in]  conn_hdl Connection handle.
 * @return     @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_ReadAnaerobicHeartRateUpperLimit (uint16_t conn_hdl);

/*******************************************************************************************************************//**
 * @brief     Write Anaerobic Heart Rate Upper Limit characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] app_value Anaerobic Heart Rate Upper Limit characteristic value to write.
 * @return    @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_WriteAnaerobicHeartRateUpperLimit (uint16_t conn_hdl, uint8_t app_value);

/*******************************************************************************************************************//**
 * @brief      Read Five Zone Heart Rate Limits characteristic value from remote GATT database.
 * @param[in]  conn_hdl Connection handle.
 * @return     @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_ReadFiveZoneHeartRateLimits (uint16_t conn_hdl);

/*******************************************************************************************************************//**
 * @brief     Write Five Zone Heart Rate Limits characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] p_app_value Pointer to Five Zone Heart Rate Limits characteristic value to write.
 * @return    @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_WriteFiveZoneHeartRateLimits (uint16_t conn_hdl,
        const st_ble_udc_five_zone_heart_rate_limits_t *p_app_value);

/*******************************************************************************************************************//**
 * @brief      Read Three Zone Heart Rate Limits characteristic value from remote GATT database.
 * @param[in]  conn_hdl Connection handle.
 * @return     @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_ReadThreeZoneHeartRateLimits (uint16_t conn_hdl);

/*******************************************************************************************************************//**
 * @brief     Write Three Zone Heart Rate Limits characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] p_app_value Pointer to Three Zone Heart Rate Limits characteristic value to write.
 * @return    @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_WriteThreeZoneHeartRateLimits (uint16_t conn_hdl,
        const st_ble_udc_three_zone_heart_rate_limits_t *p_app_value);

/*******************************************************************************************************************//**
 * @brief      Read Two Zone Heart Rate Limit characteristic value from remote GATT database.
 * @param[in]  conn_hdl Connection handle.
 * @return     @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_ReadTwoZoneHeartRateLimit (uint16_t conn_hdl);

/*******************************************************************************************************************//**
 * @brief     Write Two Zone Heart Rate Limit characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] app_value Two Zone Heart Rate Limit characteristic value to write.
 * @return    @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_WriteTwoZoneHeartRateLimit (uint16_t conn_hdl, uint8_t app_value);

/*******************************************************************************************************************//**
 * @brief      Read Database Change Increment characteristic value from remote GATT database.
 * @param[in]  conn_hdl Connection handle.
 * @return     @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_ReadDatabaseChangeIncrement (uint16_t conn_hdl);

/*******************************************************************************************************************//**
 * @brief     Write Database Change Increment characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] app_value Database Change Increment characteristic value to write.
 * @return    @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_WriteDatabaseChangeIncrement (uint16_t conn_hdl, uint32_t app_value);

/*******************************************************************************************************************//**
 * @brief     Set Database Change Increment characteristic cli cnfg.
 * @param[in] conn_hdl Connection handle.
 * @param[in] cli_cnfg Database Change Increment characteristic cli cnfg to set.
 * @return    @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_SetDatabaseChangeIncrementCliCnfg (uint16_t conn_hdl, uint16_t cli_cnfg);

/*******************************************************************************************************************//**
 * @brief      Read User Index characteristic value from remote GATT database.
 * @param[in]  conn_hdl Connection handle.
 * @return     @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_ReadUserIndex (uint16_t conn_hdl);

/*******************************************************************************************************************//**
 * @brief     Write User Control Point characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] p_app_value Pointer to User Control Point characteristic value to write.
 * @return    @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_WriteUserControlPoint (uint16_t conn_hdl, const st_ble_udc_user_control_point_t *p_app_value);

/*******************************************************************************************************************//**
 * @brief     Set User Control Point characteristic cli cnfg.
 * @param[in] conn_hdl Connection handle.
 * @param[in] cli_cnfg User Control Point characteristic cli cnfg to set.
 * @return    @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_SetUserControlPointCliCnfg (uint16_t conn_hdl, uint16_t cli_cnfg);

/*******************************************************************************************************************//**
 * @brief      Read Language characteristic value from remote GATT database.
 * @param[in]  conn_hdl Connection handle.
 * @return     @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_ReadLanguage (uint16_t conn_hdl);

/*******************************************************************************************************************//**
 * @brief     Write Language characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] p_app_value Pointer to Language characteristic value to write.
 * @return    @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_UDC_WriteLanguage (uint16_t conn_hdl, const st_ble_udc_language_t *p_app_value);

/***********************************************************************************************************************
 * @brief      Callback function for the User Data Discovery events.
 * @param[out] conn_hdl Connection handle.
 * @param[out] idx      Service index used to distinguish the multiple same UUID service.
 * @param[out] type     Discovery event type
 * @param[out] p_param  Pointer to GATTC event data.
 ***********************************************************************************************************************/
void R_BLE_UDC_ServDiscCb (uint16_t conn_hdl, uint8_t idx, uint16_t type, void *p_param);

/*******************************************************************************************************************//**
 * @brief     Return version of the UDC service client.
 * @return    version
 ***********************************************************************************************************************/
uint32_t R_BLE_UDC_GetVersion (void);

#endif /* R_BLE_UDC_H */

/** @} */
