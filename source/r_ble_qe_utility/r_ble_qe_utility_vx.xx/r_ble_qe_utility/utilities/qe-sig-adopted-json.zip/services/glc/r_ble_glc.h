/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_glc.h
 * Version : 1.0
 * Description : The header file for Glucose client.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 31.12.2999 1.00 First Release
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @file
 * @defgroup glc Glucose Client
 * @{
 * @ingroup profile
 * @brief   This is the client for the Glucose Service.
 **********************************************************************************************************************/
#include "r_ble_rx23w_if.h"

#include "profile_cmn/r_ble_profile_cmn.h"
#include "profile_cmn/r_ble_servc_if.h"

#ifndef R_BLE_GLC_H
#define R_BLE_GLC_H

/*----------------------------------------------------------------------------------------------------------------------
    Glucose Measurement Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_GLC_MEAS_UUID (0x2A18)
#define BLE_GLC_MEAS_LEN (19)
#define BLE_GLC_MEAS_CLI_CNFG_UUID (0x2902)
#define BLE_GLC_MEAS_CLI_CNFG_LEN (2)

      
/***************************************************************************//**
 * @brief Glucose Measurement Type enumeration.
*******************************************************************************/
typedef enum {
    BLE_GLC_MEAS_TYPE_CAPILLARY_WHOLE_BLOOD = 1, /**< Capillary Whole blood */
    BLE_GLC_MEAS_TYPE_CAPILLARY_PLASMA = 2, /**< Capillary Plasma */
    BLE_GLC_MEAS_TYPE_VENOUS_WHOLE_BLOOD = 3, /**< Venous Whole blood */
    BLE_GLC_MEAS_TYPE_VENOUS_PLASMA = 4, /**< Venous Plasma */
    BLE_GLC_MEAS_TYPE_ARTERIAL_WHOLE_BLOOD = 5, /**< Arterial Whole blood */
    BLE_GLC_MEAS_TYPE_ARTERIAL_PLASMA = 6, /**< Arterial Plasma */
    BLE_GLC_MEAS_TYPE_UNDETERMINED_WHOLE_BLOOD = 7, /**< Undetermined Whole blood */
    BLE_GLC_MEAS_TYPE_UNDETERMINED_PLASMA = 8, /**< Undetermined Plasma */
    BLE_GLC_MEAS_TYPE_INTERSTITIAL_FLUID = 9, /**< Interstitial Fluid (ISF) */
    BLE_GLC_MEAS_TYPE_CONTROL_SOLUTION = 10, /**< Control Solution */
} e_ble_glc_meas_type_t;

/***************************************************************************//**
 * @brief Glucose Measurement Sample Location enumeration.
*******************************************************************************/
typedef enum {
    BLE_GLC_MEAS_SAMPLE_LOCATION_FINGER = 1, /**< Finger */
    BLE_GLC_MEAS_SAMPLE_LOCATION_ALTERNATE_SITE_TEST = 2, /**< Alternate Site Test */
    BLE_GLC_MEAS_SAMPLE_LOCATION_EARLOBE = 3, /**< Earlobe */
    BLE_GLC_MEAS_SAMPLE_LOCATION_CONTROL_SOLUTION = 4, /**< Control solution */
    BLE_GLC_MEAS_SAMPLE_LOCATION_SAMPLE_LOCATION_VALUE_NOT_AVAILABLE = 15, /**< Sample Location value not available */
} e_ble_glc_meas_sample_location_t;

      
      
/***************************************************************************//**
 * @brief Glucose Measurement Flags value structure.
*******************************************************************************/
typedef struct {
    bool is_time_offset_present; /**< Time Offset Present */
    bool is_glucose_concentration_type_and_sample_location_present; /**< Glucose Concentration, Type and Sample Location Present */
    bool is_glucose_concentration_units_mol_per_liter; /**< Glucose Concentration Units (mol/L) */
    bool is_sensor_status_annunciation_present; /**< Sensor Status Annunciation Present */
    bool is_context_information_follows; /**< Context Information Follows */
} st_ble_glc_meas_flags_t;

      
/***************************************************************************//**
 * @brief Glucose Measurement Sensor Status Annunciation value structure.
*******************************************************************************/
typedef struct {
    bool is_device_battery_low_at_time_of_measurement; /**< Device battery low at time of measurement */
    bool is_sensor_malfunction_or_faulting_at_time_of_measurement; /**< Sensor malfunction or faulting at time of measurement */
    bool is_sample_size_for_blood_or_control_solution_insufficient_at_time_of_measurement; /**< Sample size for blood or control solution insufficient at time of measurement */
    bool is_strip_insertion_error; /**< Strip insertion error */
    bool is_strip_type_incorrect_for_device; /**< Strip type incorrect for device */
    bool is_sensor_result_higher_than_the_device_can_process; /**< Sensor result higher than the device can process */
    bool is_sensor_result_lower_than_the_device_can_process; /**< Sensor result lower than the device can process */
    bool is_sensor_temperature_too_high_for_valid_test_result_at_time_of_measurement; /**< Sensor temperature too high for valid test/result at time of measurement */
    bool is_sensor_temperature_too_low_for_valid_test_result_at_time_of_measurement; /**< Sensor temperature too low for valid test/result at time of measurement */
    bool is_sensor_read_interrupted_because_strip_was_pulled_too_soon_at_time_of_measurement; /**< Sensor read interrupted because strip was pulled too soon at time of measurement */
    bool is_general_device_fault_has_occurred_in_the_sensor; /**< General device fault has occurred in the sensor */
    bool is_time_fault_has_occurred_in_the_sensor_and_time_may_be_inaccurate; /**< Time fault has occurred in the sensor and time may be inaccurate */
} st_ble_glc_meas_sensor_status_annunciation_t;

/***************************************************************************//**
 * @brief Glucose Measurement value structure.
*******************************************************************************/
typedef struct {
    st_ble_glc_meas_flags_t flags; /**< Flags */
    uint16_t sequence_number; /**< Sequence Number */
    st_ble_date_time_t base_time; /**< Base Time */
    int16_t time_offset; /**< Time Offset */
    st_ble_ieee11073_sfloat_t glucose_concentration; /**< Glucose Concentration - units is kg/L or mol/L */
    uint8_t type; /**< Type */
    uint8_t sample_location; /**< Sample Location */
    st_ble_glc_meas_sensor_status_annunciation_t sensor_status_annunciation; /**< Sensor Status Annunciation */
} st_ble_glc_meas_t;

/***************************************************************************//**
 * @brief Glucose Measurement attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
    uint16_t cli_cnfg_desc_hdl;
} st_ble_glc_meas_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Glucose Measurement characteristic Client Characteristic Configuration descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_GLC_ReadMeasCliCnfg(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Glucose Measurement characteristic Client Characteristic Configuration descriptor value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value Glucose Measurement characteristic Client Characteristic Configuration descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_GLC_WriteMeasCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief      Get Glucose Measurement attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_GLC_GetMeasAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_glc_meas_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Glucose Measurement Context Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_GLC_MEAS_CONTEXT_UUID (0x2A34)
#define BLE_GLC_MEAS_CONTEXT_LEN (19)
#define BLE_GLC_MEAS_CONTEXT_CLI_CNFG_UUID (0x2902)
#define BLE_GLC_MEAS_CONTEXT_CLI_CNFG_LEN (2)

      
/***************************************************************************//**
 * @brief Glucose Measurement Context Carbohydrate ID enumeration.
*******************************************************************************/
typedef enum {
    BLE_GLC_MEAS_CONTEXT_CARBOHYDRATE_ID_BREAKFAST = 1, /**< Breakfast */
    BLE_GLC_MEAS_CONTEXT_CARBOHYDRATE_ID_LUNCH = 2, /**< Lunch */
    BLE_GLC_MEAS_CONTEXT_CARBOHYDRATE_ID_DINNER = 3, /**< Dinner */
    BLE_GLC_MEAS_CONTEXT_CARBOHYDRATE_ID_SNACK = 4, /**< Snack */
    BLE_GLC_MEAS_CONTEXT_CARBOHYDRATE_ID_DRINK = 5, /**< Drink */
    BLE_GLC_MEAS_CONTEXT_CARBOHYDRATE_ID_SUPPER = 6, /**< Supper */
    BLE_GLC_MEAS_CONTEXT_CARBOHYDRATE_ID_BRUNCH = 7, /**< Brunch */
} e_ble_glc_meas_context_carbohydrate_id_t;

/***************************************************************************//**
 * @brief Glucose Measurement Context Meal enumeration.
*******************************************************************************/
typedef enum {
    BLE_GLC_MEAS_CONTEXT_MEAL_PREPRANDIAL_BEFORE_MEAL = 1, /**< Preprandial (before meal) */
    BLE_GLC_MEAS_CONTEXT_MEAL_POSTPRANDIAL_AFTER_MEAL = 2, /**< Postprandial (after meal) */
    BLE_GLC_MEAS_CONTEXT_MEAL_FASTING = 3, /**< Fasting */
    BLE_GLC_MEAS_CONTEXT_MEAL_CASUAL = 4, /**< Casual (snacks, drinks, etc.) */
    BLE_GLC_MEAS_CONTEXT_MEAL_BEDTIME = 5, /**< Bedtime */
} e_ble_glc_meas_context_meal_t;

/***************************************************************************//**
 * @brief Glucose Measurement Context Tester enumeration.
*******************************************************************************/
typedef enum {
    BLE_GLC_MEAS_CONTEXT_TESTER_SELF = 1, /**< Self */
    BLE_GLC_MEAS_CONTEXT_TESTER_HEALTH_CARE_PROFESSIONAL = 2, /**< Health Care Professional */
    BLE_GLC_MEAS_CONTEXT_TESTER_LAB_TEST = 3, /**< Lab test */
    BLE_GLC_MEAS_CONTEXT_TESTER_TESTER_VALUE_NOT_AVAILABLE = 15, /**< Tester value not available */
} e_ble_glc_meas_context_tester_t;

/***************************************************************************//**
 * @brief Glucose Measurement Context Health enumeration.
*******************************************************************************/
typedef enum {
    BLE_GLC_MEAS_CONTEXT_HEALTH_MINOR_HEALTH_ISSUES = 1, /**< Minor health issues */
    BLE_GLC_MEAS_CONTEXT_HEALTH_MAJOR_HEALTH_ISSUES = 2, /**< Major health issues */
    BLE_GLC_MEAS_CONTEXT_HEALTH_DURING_MENSES = 3, /**< During menses */
    BLE_GLC_MEAS_CONTEXT_HEALTH_UNDER_STRESS = 4, /**< Under stress */
    BLE_GLC_MEAS_CONTEXT_HEALTH_NO_HEALTH_ISSUES = 5, /**< No health issues */
    BLE_GLC_MEAS_CONTEXT_HEALTH_HEALTH_VALUE_NOT_AVAILABLE = 15, /**< Health value not available */
} e_ble_glc_meas_context_health_t;

/***************************************************************************//**
 * @brief Glucose Measurement Context Exercise Duration enumeration.
*******************************************************************************/
typedef enum {
    BLE_GLC_MEAS_CONTEXT_EXERCISE_DURATION_OVERRUN = 65535, /**< Overrun */
} e_ble_glc_meas_context_exercise_duration_t;

/***************************************************************************//**
 * @brief Glucose Measurement Context Medication ID enumeration.
*******************************************************************************/
typedef enum {
    BLE_GLC_MEAS_CONTEXT_MEDICATION_ID_RAPID_ACTING_INSULIN = 1, /**< Rapid acting insulin */
    BLE_GLC_MEAS_CONTEXT_MEDICATION_ID_SHORT_ACTING_INSULIN = 2, /**< Short acting insulin */
    BLE_GLC_MEAS_CONTEXT_MEDICATION_ID_INTERMEDIATE_ACTING_INSULIN = 3, /**< Intermediate acting insulin */
    BLE_GLC_MEAS_CONTEXT_MEDICATION_ID_LONG_ACTING_INSULIN = 4, /**< Long acting insulin */
    BLE_GLC_MEAS_CONTEXT_MEDICATION_ID_PRE_MIXED_INSULIN = 5, /**< Pre-mixed insulin */
} e_ble_glc_meas_context_medication_id_t;

      
/***************************************************************************//**
 * @brief Glucose Measurement Context Flags value structure.
*******************************************************************************/
typedef struct {
    bool is_carbohydrate_id_and_carbohydrate_present; /**< Carbohydrate ID And Carbohydrate Present */
    bool is_meal_present; /**< Meal Present */
    bool is_tester_health_present; /**< Tester-Health Present */
    bool is_exercise_duration_and_exercise_intensity_present; /**< Exercise Duration And Exercise Intensity Present */
    bool is_medication_id_and_medication_present; /**< Medication ID And Medication Present */
    bool is_medication_value_units_liters; /**< Medication Value Units (liters) */
    bool is_hba1c_present; /**< HbA1c Present */
    bool is_extended_flags_present; /**< Extended Flags Present */
} st_ble_glc_meas_context_flags_t;

/***************************************************************************//**
 * @brief Glucose Measurement Context value structure.
*******************************************************************************/
typedef struct {
    st_ble_glc_meas_context_flags_t flags; /**< Flags */
    uint16_t sequence_number; /**< Sequence Number */
    uint8_t extended_flags; /**< Extended Flags */
    uint8_t carbohydrate_id; /**< Carbohydrate ID */
    st_ble_ieee11073_sfloat_t carbohydrate; /**< Carbohydrate - units of kilograms */
    uint8_t meal; /**< Meal */
    uint8_t tester; /**< Tester */
    uint8_t health; /**< Health */
    uint16_t exercise_duration; /**< Exercise Duration */
    uint8_t exercise_intensity; /**< Exercise Intensity */
    uint8_t medication_id; /**< Medication ID */
    st_ble_ieee11073_sfloat_t medication; /**< Medication - units is kilograms or liters */
    st_ble_ieee11073_sfloat_t hba1c; /**< HbA1c */
} st_ble_glc_meas_context_t;

/***************************************************************************//**
 * @brief Glucose Measurement Context attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
    uint16_t cli_cnfg_desc_hdl;
} st_ble_glc_meas_context_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Glucose Measurement Context characteristic Client Characteristic Configuration descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_GLC_ReadMeasContextCliCnfg(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Glucose Measurement Context characteristic Client Characteristic Configuration descriptor value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value Glucose Measurement Context characteristic Client Characteristic Configuration descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_GLC_WriteMeasContextCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief      Get Glucose Measurement Context attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_GLC_GetMeasContextAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_glc_meas_context_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Glucose Feature Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_GLC_FEAT_UUID (0x2A51)
#define BLE_GLC_FEAT_LEN (2)
/***************************************************************************//**
 * @brief Glucose Feature value structure.
*******************************************************************************/
typedef struct {
    bool is_low_battery_detection_during_measurement_supported; /**< Low Battery Detection During Measurement Supported */
    bool is_sensor_malfunction_detection_supported; /**< Sensor Malfunction Detection Supported */
    bool is_sensor_sample_size_supported; /**< Sensor Sample Size Supported */
    bool is_sensor_strip_insertion_error_detection_supported; /**< Sensor Strip Insertion Error Detection Supported */
    bool is_sensor_strip_type_error_detection_supported; /**< Sensor Strip Type Error Detection Supported */
    bool is_sensor_result_high_low_detection_supported; /**< Sensor Result High-Low Detection Supported */
    bool is_sensor_temperature_high_low_detection_supported; /**< Sensor Temperature High-Low Detection Supported */
    bool is_sensor_read_interrupt_detection_supported; /**< Sensor Read Interrupt Detection Supported */
    bool is_general_device_fault_supported; /**< General Device Fault Supported */
    bool is_time_fault_supported; /**< Time Fault Supported */
    bool is_multiple_bond_supported; /**< Multiple Bond Supported */
} st_ble_glc_feat_t;

/***************************************************************************//**
 * @brief Glucose Feature attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
} st_ble_glc_feat_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Glucose Feature characteristic value from the remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_GLC_ReadFeat(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief      Get Glucose Feature attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_GLC_GetFeatAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_glc_feat_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Record Access Control Point Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_GLC_RA_CTRL_PT_UUID (0x2A52)
#define BLE_GLC_RA_CTRL_PT_LEN (20)
#define BLE_GLC_RA_CTRL_PT_CLI_CNFG_UUID (0x2902)
#define BLE_GLC_RA_CTRL_PT_CLI_CNFG_LEN (2)
#define BLE_GLC_RA_CTRL_PT_OPERAND_LEN (20)

/***************************************************************************//**
 * @brief Record Access Control Point Op Code enumeration.
*******************************************************************************/
typedef enum {
    BLE_GLC_RA_CTRL_PT_OP_CODE_REPORT_STORED_RECORDS = 1, /**< Report stored records (Operator: Value from Operator Table) */
    BLE_GLC_RA_CTRL_PT_OP_CODE_DELETE_STORED_RECORDS = 2, /**< Delete stored records (Operator: Value from Operator Table) */
    BLE_GLC_RA_CTRL_PT_OP_CODE_ABORT_OPERATION = 3, /**< Abort operation (Operator: Null 'value of 0x00 from Operator Table') */
    BLE_GLC_RA_CTRL_PT_OP_CODE_REPORT_NUMBER_OF_STORED_RECORDS = 4, /**< Report number of stored records (Operator: Value from Operator Table) */
    BLE_GLC_RA_CTRL_PT_OP_CODE_NUMBER_OF_STORED_RECORDS_RESPONSE = 5, /**< Number of stored records response (Operator: Null 'value of 0x00 from Operator Table') */
    BLE_GLC_RA_CTRL_PT_OP_CODE_RESPONSE_CODE = 6, /**< Response Code (Operator: Null 'value of 0x00 from Operator Table') */
} e_ble_glc_ra_ctrl_pt_op_code_t;

/***************************************************************************//**
 * @brief Record Access Control Point Operator enumeration.
*******************************************************************************/
typedef enum {
    BLE_GLC_RA_CTRL_PT_OPERATOR_NULL = 0, /**< Null */
    BLE_GLC_RA_CTRL_PT_OPERATOR_ALL_RECORDS = 1, /**< All records */
    BLE_GLC_RA_CTRL_PT_OPERATOR_LESS_THAN_OR_EQUAL_TO = 2, /**< Less than or equal to */
    BLE_GLC_RA_CTRL_PT_OPERATOR_GREATER_THAN_OR_EQUAL_TO = 3, /**< Greater than or equal to */
    BLE_GLC_RA_CTRL_PT_OPERATOR_WITHIN_RANGE_OF = 4, /**< Within range of (inclusive) */
    BLE_GLC_RA_CTRL_PT_OPERATOR_FIRST_RECORD = 5, /**< First record(i.e. oldest record) */
    BLE_GLC_RA_CTRL_PT_OPERATOR_LAST_RECORD = 6, /**< Last record (i.e. most recent record) */
} e_ble_glc_ra_ctrl_pt_operator_t;

/***************************************************************************//**
 * @brief Record Access Control Point Operand enumeration.
*******************************************************************************/
typedef enum {
    BLE_GLC_RA_CTRL_PT_OPERAND_SUCCESS = 1, /**< Normal response for successful operation */
    BLE_GLC_RA_CTRL_PT_OPERAND_OP_CODE_NOT_SUPPORTED = 2, /**< Normal response if unsupported Op Code is received */
    BLE_GLC_RA_CTRL_PT_OPERAND_INVALID_OPERATOR = 3, /**< Normal response if Operator received does not meet the requirements of the service (e.g. Null was expected) */
    BLE_GLC_RA_CTRL_PT_OPERAND_OPERATOR_NOT_SUPPORTED = 4, /**< Normal response if unsupported Operator is received */
    BLE_GLC_RA_CTRL_PT_OPERAND_INVALID_OPERAND = 5, /**< Normal response if Operand received does not meet the requirements of the service */
    BLE_GLC_RA_CTRL_PT_OPERAND_NO_RECORDS_FOUND = 6, /**< Normal response if request to report stored records or request to delete stored records resulted in no records meeting criteria. */
    BLE_GLC_RA_CTRL_PT_OPERAND_ABORT_UNSUCCESSFUL = 7, /**< Normal response if request for Abort cannot be completed */
    BLE_GLC_RA_CTRL_PT_OPERAND_PROCEDURE_NOT_COMPLETED = 8, /**< Normal response if unable to complete a procedure for any reason */
    BLE_GLC_RA_CTRL_PT_OPERAND_OPERAND_NOT_SUPPORTED = 9, /**< Normal response if unsupported Operand is received */
} e_ble_glc_ra_ctrl_pt_operand_t;

/***************************************************************************//**
 * @brief Record Access Control Point Filtrer Type enumeration.
*******************************************************************************/
typedef enum {
    BLE_GLC_RA_CTRL_PT_FILTER_TYPE_SEQUENCE_NUMBER = 1,
    BLE_GLC_RA_CTRL_PT_FILTER_TYPE_USER_FACING_TIME = 2,
} e_ble_glc_ra_ctrl_pt_filter_type_t;

/***************************************************************************//**
 * @brief Record Access Control Point value structure.
*******************************************************************************/
typedef struct {
    uint8_t op_code; /**< Op Code */
    uint8_t operator; /**< Operator */
    uint8_t operand[BLE_GLC_RA_CTRL_PT_OPERAND_LEN]; /**< Operand */
} st_ble_glc_ra_ctrl_pt_t;

/***************************************************************************//**
 * @brief Record Access Control Point attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
    uint16_t cli_cnfg_desc_hdl;
} st_ble_glc_ra_ctrl_pt_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Record Access Control Point characteristic Client Characteristic Configuration descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_GLC_ReadRaCtrlPtCliCnfg(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Record Access Control Point characteristic Client Characteristic Configuration descriptor value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value Record Access Control Point characteristic Client Characteristic Configuration descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_GLC_WriteRaCtrlPtCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Write Record Access Control Point characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] p_value Record Access Control Point characteristic value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_GLC_WriteRaCtrlPt(uint16_t conn_hdl, const st_ble_glc_ra_ctrl_pt_t *p_value);
;
/***************************************************************************//**
 * @brief      Get Record Access Control Point attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_GLC_GetRaCtrlPtAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_glc_ra_ctrl_pt_attr_hdl_t *p_hdl);


/*----------------------------------------------------------------------------------------------------------------------
    Glucose Client
----------------------------------------------------------------------------------------------------------------------*/

/***************************************************************************//**
 * @brief A Record Access Control Point request cannot be serviced because a previously triggered RACP operation is still in progress
*******************************************************************************/
#define BLE_GLC_PROCEDURE_ALREADY_IN_PROGRESS_ERROR (BLE_ERR_GROUP_GATT | 0x80)

/***************************************************************************//**
 * @brief The Client Characteristic Configuration descriptor is not configured according to the requirements of the service.
*******************************************************************************/
#define BLE_GLC_CLI_CNFG_IMPROPERLY_CONFIGURED_ERROR (BLE_ERR_GROUP_GATT | 0x81)

/***************************************************************************//**
 * @brief Glucose client event data.
*******************************************************************************/
typedef struct {
    uint16_t    conn_hdl;  /**< Connection handle */
    uint16_t    param_len; /**< Event parameter length */
    const void *p_param;   /**< Event parameter */
} st_ble_glc_evt_data_t;

/***************************************************************************//**
 * @brief Glucose characteristic ID.
*******************************************************************************/
typedef enum {
    BLE_GLC_MEAS_IDX,
    BLE_GLC_MEAS_CLI_CNFG_IDX,
    BLE_GLC_MEAS_CONTEXT_IDX,
    BLE_GLC_MEAS_CONTEXT_CLI_CNFG_IDX,
    BLE_GLC_FEAT_IDX,
    BLE_GLC_RA_CTRL_PT_IDX,
    BLE_GLC_RA_CTRL_PT_CLI_CNFG_IDX,
} e_ble_glc_char_idx_t;

/***************************************************************************//**
 * @brief Glucose client event type.
*******************************************************************************/
typedef enum {
    /* Glucose Measurement */
    BLE_GLC_EVENT_MEAS_HDL_VAL_NTF = BLE_SERVC_ATTR_EVENT(BLE_GLC_MEAS_IDX, BLE_SERVC_HDL_VAL_NTF),
    BLE_GLC_EVENT_MEAS_CLI_CNFG_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_GLC_MEAS_CLI_CNFG_IDX, BLE_SERVC_READ_RSP),
    BLE_GLC_EVENT_MEAS_CLI_CNFG_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_GLC_MEAS_CLI_CNFG_IDX, BLE_SERVC_WRITE_RSP),
    /* Glucose Measurement Context */
    BLE_GLC_EVENT_MEAS_CONTEXT_HDL_VAL_NTF = BLE_SERVC_ATTR_EVENT(BLE_GLC_MEAS_CONTEXT_IDX, BLE_SERVC_HDL_VAL_NTF),
    BLE_GLC_EVENT_MEAS_CONTEXT_CLI_CNFG_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_GLC_MEAS_CONTEXT_CLI_CNFG_IDX, BLE_SERVC_READ_RSP),
    BLE_GLC_EVENT_MEAS_CONTEXT_CLI_CNFG_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_GLC_MEAS_CONTEXT_CLI_CNFG_IDX, BLE_SERVC_WRITE_RSP),
    /* Glucose Feature */
    BLE_GLC_EVENT_FEAT_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_GLC_FEAT_IDX, BLE_SERVC_READ_RSP),
    /* Record Access Control Point */
    BLE_GLC_EVENT_RA_CTRL_PT_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_GLC_RA_CTRL_PT_IDX, BLE_SERVC_WRITE_RSP),
    BLE_GLC_EVENT_RA_CTRL_PT_HDL_VAL_IND = BLE_SERVC_ATTR_EVENT(BLE_GLC_RA_CTRL_PT_IDX, BLE_SERVC_HDL_VAL_IND),
    BLE_GLC_EVENT_RA_CTRL_PT_CLI_CNFG_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_GLC_RA_CTRL_PT_CLI_CNFG_IDX, BLE_SERVC_READ_RSP),
    BLE_GLC_EVENT_RA_CTRL_PT_CLI_CNFG_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_GLC_RA_CTRL_PT_CLI_CNFG_IDX, BLE_SERVC_WRITE_RSP),
} e_ble_glc_event_t;

/***************************************************************************//**
 * @brief     Initialize Glucose client.
 * @param[in] cb Client callback.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_GLC_Init(ble_servc_app_cb_t cb);

/***************************************************************************//**
 * @brief     Glucose client discovery callback.
 * @param[in] conn_hdl Connection handle
 * @param[in] serv_idx Service instance index.
 * @param[in] type     Service discovery event type.
 * @param[in] p_param  Service discovery event parameter.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_GLC_ServDiscCb(uint16_t conn_hdl, uint8_t serv_idx, uint16_t type, void *p_param);

/***************************************************************************//**
 * @brief     Get Glucose client attribute handle.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
*******************************************************************************/
void R_BLE_GLC_GetServAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_gatt_hdl_range_t *p_hdl);

#endif /* R_BLE_GLC_H */

/** @} */
