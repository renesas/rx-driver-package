/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_glc.c
 * Version : 1.0
 * Description : The source file for Glucose client.
 **********************************************************************************************************************/
#include <string.h>
#include "r_ble_glc.h"
#include "profile_cmn/r_ble_servc_if.h"

static st_ble_servc_info_t gs_client_info;

/*----------------------------------------------------------------------------------------------------------------------
    Glucose Measurement Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Glucose Measurement characteristic descriptors attribute handles */
static uint16_t gs_meas_cli_cnfg_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_meas_cli_cnfg ={
    .uuid_16     = BLE_GLC_MEAS_CLI_CNFG_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint16_t),
    .db_size     = BLE_GLC_MEAS_CLI_CNFG_LEN,
    .desc_idx    = BLE_GLC_MEAS_CLI_CNFG_IDX,
    .p_attr_hdls = gs_meas_cli_cnfg_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_GLC_WriteMeasCliCnfg(uint16_t conn_hdl, const uint16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_meas_cli_cnfg, conn_hdl, p_value);
}

ble_status_t R_BLE_GLC_ReadMeasCliCnfg(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_meas_cli_cnfg, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Glucose Measurement Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Glucose Measurement characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_meas_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

static ble_status_t decode_st_ble_glc_meas_t(st_ble_glc_meas_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    p_app_value->flags.is_time_offset_present                                    = !!(p_gatt_value->p_value[pos] & 0x01);
    p_app_value->flags.is_glucose_concentration_type_and_sample_location_present = !!(p_gatt_value->p_value[pos] & 0x02);
    p_app_value->flags.is_glucose_concentration_units_mol_per_liter              = !!(p_gatt_value->p_value[pos] & 0x04);
    p_app_value->flags.is_sensor_status_annunciation_present                     = !!(p_gatt_value->p_value[pos] & 0x08);
    p_app_value->flags.is_context_information_follows                            = !!(p_gatt_value->p_value[pos] & 0x10);
    pos++;

    BT_UNPACK_LE_2_BYTE(&p_app_value->sequence_number, &p_gatt_value->p_value[pos]);
    pos += 2;

    pos += unpack_st_ble_date_time_t(&p_app_value->base_time, &p_gatt_value->p_value[pos]);

    if (p_app_value->flags.is_time_offset_present)
    {
        BT_UNPACK_LE_2_BYTE(&p_app_value->time_offset, &p_gatt_value->p_value[pos]);
        pos += 2;
    }

    if (p_app_value->flags.is_glucose_concentration_type_and_sample_location_present)
    {
        pos += unpack_st_ble_ieee11073_sfloat_t(&p_app_value->glucose_concentration, &p_gatt_value->p_value[pos]);
        p_app_value->type = p_gatt_value->p_value[pos] & 0x0F;
        p_app_value->sample_location = (p_gatt_value->p_value[pos] >> 4) & 0x0F;
        pos++;
    }

    if (p_app_value->flags.is_sensor_status_annunciation_present)
    {
        p_app_value->sensor_status_annunciation.is_device_battery_low_at_time_of_measurement                                        = !!(p_gatt_value->p_value[pos] & 0x01);
        p_app_value->sensor_status_annunciation.is_sensor_malfunction_or_faulting_at_time_of_measurement                            = !!(p_gatt_value->p_value[pos] & 0x02);
        p_app_value->sensor_status_annunciation.is_sample_size_for_blood_or_control_solution_insufficient_at_time_of_measurement    = !!(p_gatt_value->p_value[pos] & 0x04);
        p_app_value->sensor_status_annunciation.is_strip_insertion_error                                                            = !!(p_gatt_value->p_value[pos] & 0x08);
        p_app_value->sensor_status_annunciation.is_strip_type_incorrect_for_device                                                  = !!(p_gatt_value->p_value[pos] & 0x10);
        p_app_value->sensor_status_annunciation.is_sensor_result_higher_than_the_device_can_process                                 = !!(p_gatt_value->p_value[pos] & 0x20);
        p_app_value->sensor_status_annunciation.is_sensor_result_lower_than_the_device_can_process                                  = !!(p_gatt_value->p_value[pos] & 0x40);
        p_app_value->sensor_status_annunciation.is_sensor_temperature_too_high_for_valid_test_result_at_time_of_measurement         = !!(p_gatt_value->p_value[pos] & 0x80);
        pos++;

        p_app_value->sensor_status_annunciation.is_sensor_temperature_too_low_for_valid_test_result_at_time_of_measurement          = !!(p_gatt_value->p_value[pos] & 0x01);
        p_app_value->sensor_status_annunciation.is_sensor_read_interrupted_because_strip_was_pulled_too_soon_at_time_of_measurement = !!(p_gatt_value->p_value[pos] & 0x02);
        p_app_value->sensor_status_annunciation.is_general_device_fault_has_occurred_in_the_sensor                                  = !!(p_gatt_value->p_value[pos] & 0x04);
        p_app_value->sensor_status_annunciation.is_time_fault_has_occurred_in_the_sensor_and_time_may_be_inaccurate                 = !!(p_gatt_value->p_value[pos] & 0x08);
        pos++;
    }

    return BLE_SUCCESS;
}

/* Glucose Measurement characteristic descriptor definition */
static const st_ble_servc_desc_info_t *gspp_meas_descs[] = {
    &gs_meas_cli_cnfg,
};

/* Glucose Measurement characteristic definition */
static const st_ble_servc_char_info_t gs_meas_char = {
    .uuid_16      = BLE_GLC_MEAS_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_glc_meas_t),
    .db_size      = BLE_GLC_MEAS_LEN,
    .char_idx     = BLE_GLC_MEAS_IDX,
    .p_attr_hdls  = gs_meas_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_glc_meas_t,
    .num_of_descs = ARRAY_SIZE(gspp_meas_descs),
    .pp_descs     = gspp_meas_descs,
};

void R_BLE_GLC_GetMeasAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_glc_meas_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_meas_char_ranges[conn_idx];
    p_hdl->cli_cnfg_desc_hdl = gs_meas_cli_cnfg_desc_hdls[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Glucose Measurement Context Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Glucose Measurement Context characteristic descriptors attribute handles */
static uint16_t gs_meas_context_cli_cnfg_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_meas_context_cli_cnfg ={
    .uuid_16     = BLE_GLC_MEAS_CONTEXT_CLI_CNFG_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint16_t),
    .db_size     = BLE_GLC_MEAS_CONTEXT_CLI_CNFG_LEN,
    .desc_idx    = BLE_GLC_MEAS_CONTEXT_CLI_CNFG_IDX,
    .p_attr_hdls = gs_meas_context_cli_cnfg_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_GLC_WriteMeasContextCliCnfg(uint16_t conn_hdl, const uint16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_meas_context_cli_cnfg, conn_hdl, p_value);
}

ble_status_t R_BLE_GLC_ReadMeasContextCliCnfg(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_meas_context_cli_cnfg, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Glucose Measurement Context Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Glucose Measurement Context characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_meas_context_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

static ble_status_t decode_st_ble_glc_meas_context_t(st_ble_glc_meas_context_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    p_app_value->flags.is_carbohydrate_id_and_carbohydrate_present         = !!(p_gatt_value->p_value[pos] & 0x01);
    p_app_value->flags.is_meal_present                                     = !!(p_gatt_value->p_value[pos] & 0x02);
    p_app_value->flags.is_tester_health_present                            = !!(p_gatt_value->p_value[pos] & 0x04);
    p_app_value->flags.is_exercise_duration_and_exercise_intensity_present = !!(p_gatt_value->p_value[pos] & 0x08);
    p_app_value->flags.is_medication_id_and_medication_present             = !!(p_gatt_value->p_value[pos] & 0x10);
    p_app_value->flags.is_medication_value_units_liters                    = !!(p_gatt_value->p_value[pos] & 0x20);
    p_app_value->flags.is_hba1c_present                                    = !!(p_gatt_value->p_value[pos] & 0x40);
    p_app_value->flags.is_extended_flags_present                           = !!(p_gatt_value->p_value[pos] & 0x80);
    pos++;

    BT_UNPACK_LE_2_BYTE(&p_app_value->sequence_number, &p_gatt_value->p_value[pos]);
    pos += 2;

    if (p_app_value->flags.is_extended_flags_present)
    {
        p_app_value->extended_flags = p_gatt_value->p_value[pos++];
    }

    if (p_app_value->flags.is_carbohydrate_id_and_carbohydrate_present)
    {
        p_app_value->carbohydrate_id = p_gatt_value->p_value[pos++];
        pos += unpack_st_ble_ieee11073_sfloat_t(&p_app_value->carbohydrate, &p_gatt_value->p_value[pos]);
    }

    if (p_app_value->flags.is_meal_present)
    {
        p_app_value->meal = p_gatt_value->p_value[pos++];
    }

    if (p_app_value->flags.is_tester_health_present)
    {
        p_app_value->tester = p_gatt_value->p_value[pos] & 0x0F;
        p_app_value->health = (p_gatt_value->p_value[pos] >> 4) & 0x0F;
        pos++;
    }

    if (p_app_value->flags.is_exercise_duration_and_exercise_intensity_present)
    {
        BT_UNPACK_LE_2_BYTE(&p_app_value->exercise_duration, &p_gatt_value->p_value[pos]);
        pos += 2;
        p_app_value->exercise_intensity = p_gatt_value->p_value[pos++];
    }

    if (p_app_value->flags.is_medication_id_and_medication_present)
    {
        p_app_value->medication_id = p_gatt_value->p_value[pos++];
        pos += unpack_st_ble_ieee11073_sfloat_t(&p_app_value->medication, &p_gatt_value->p_value[pos]);
    }

    if (p_app_value->flags.is_hba1c_present)
    {
        pos += unpack_st_ble_ieee11073_sfloat_t(&p_app_value->hba1c, &p_gatt_value->p_value[pos]);
    }

    return BLE_SUCCESS;
}

/* Glucose Measurement Context characteristic descriptor definition */
static const st_ble_servc_desc_info_t *gspp_meas_context_descs[] = {
    &gs_meas_context_cli_cnfg,
};

/* Glucose Measurement Context characteristic definition */
const st_ble_servc_char_info_t gs_meas_context_char = {
    .uuid_16      = BLE_GLC_MEAS_CONTEXT_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_glc_meas_context_t),
    .db_size      = BLE_GLC_MEAS_CONTEXT_LEN,
    .char_idx     = BLE_GLC_MEAS_CONTEXT_IDX,
    .p_attr_hdls  = gs_meas_context_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_glc_meas_context_t,
    .num_of_descs = ARRAY_SIZE(gspp_meas_context_descs),
    .pp_descs     = gspp_meas_context_descs,
};

void R_BLE_GLC_GetMeasContextAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_glc_meas_context_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_meas_context_char_ranges[conn_idx];
    p_hdl->cli_cnfg_desc_hdl = gs_meas_context_cli_cnfg_desc_hdls[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Glucose Feature Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Glucose Feature characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_feat_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

static ble_status_t decode_st_ble_glc_feat_t(st_ble_glc_feat_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    p_app_value->is_low_battery_detection_during_measurement_supported = p_gatt_value->p_value[pos] & 0x01;
    p_app_value->is_sensor_malfunction_detection_supported             = p_gatt_value->p_value[pos] & 0x02;
    p_app_value->is_sensor_sample_size_supported                       = p_gatt_value->p_value[pos] & 0x04;
    p_app_value->is_sensor_strip_insertion_error_detection_supported   = p_gatt_value->p_value[pos] & 0x08;
    p_app_value->is_sensor_strip_type_error_detection_supported        = p_gatt_value->p_value[pos] & 0x10;
    p_app_value->is_sensor_result_high_low_detection_supported         = p_gatt_value->p_value[pos] & 0x20;
    p_app_value->is_sensor_temperature_high_low_detection_supported    = p_gatt_value->p_value[pos] & 0x40;
    p_app_value->is_sensor_read_interrupt_detection_supported          = p_gatt_value->p_value[pos] & 0x80;
    pos++;

    p_app_value->is_general_device_fault_supported                     = p_gatt_value->p_value[pos] & 0x01;
    p_app_value->is_time_fault_supported                               = p_gatt_value->p_value[pos] & 0x02;
    p_app_value->is_multiple_bond_supported                            = p_gatt_value->p_value[pos] & 0x04;
    pos++;

    return BLE_SUCCESS;
}

/* Glucose Feature characteristic definition */
static const st_ble_servc_char_info_t gs_feat_char = {
    .uuid_16      = BLE_GLC_FEAT_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_glc_feat_t),
    .db_size      = BLE_GLC_FEAT_LEN,
    .char_idx     = BLE_GLC_FEAT_IDX,
    .p_attr_hdls  = gs_feat_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_glc_feat_t,
};

ble_status_t R_BLE_GLC_ReadFeat(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_feat_char, conn_hdl);
}

void R_BLE_GLC_GetFeatAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_glc_feat_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_feat_char_ranges[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Record Access Control Point Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Record Access Control Point characteristic descriptors attribute handles */
static uint16_t gs_ra_ctrl_pt_cli_cnfg_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_ra_ctrl_pt_cli_cnfg ={
    .uuid_16     = BLE_GLC_RA_CTRL_PT_CLI_CNFG_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint16_t),
    .db_size     = BLE_GLC_RA_CTRL_PT_CLI_CNFG_LEN,
    .desc_idx    = BLE_GLC_RA_CTRL_PT_CLI_CNFG_IDX,
    .p_attr_hdls = gs_ra_ctrl_pt_cli_cnfg_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_GLC_WriteRaCtrlPtCliCnfg(uint16_t conn_hdl, const uint16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_ra_ctrl_pt_cli_cnfg, conn_hdl, p_value);
}

ble_status_t R_BLE_GLC_ReadRaCtrlPtCliCnfg(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_ra_ctrl_pt_cli_cnfg, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Record Access Control Point Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Record Access Control Point characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_ra_ctrl_pt_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

static ble_status_t decode_st_ble_glc_ra_ctrl_pt_t(st_ble_glc_ra_ctrl_pt_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    p_app_value->op_code = p_gatt_value->p_value[pos++];
    p_app_value->operator = p_gatt_value->p_value[pos++];

    switch (p_app_value->operator)
    {
        case BLE_GLC_RA_CTRL_PT_OPERATOR_LESS_THAN_OR_EQUAL_TO:
        case BLE_GLC_RA_CTRL_PT_OPERATOR_GREATER_THAN_OR_EQUAL_TO:
        {
            p_app_value->operand[0] = p_gatt_value->p_value[pos++];

            if (BLE_GLC_RA_CTRL_PT_FILTER_TYPE_USER_FACING_TIME == p_app_value->operand[0])
            {
                memcpy(p_app_value->operand, &p_gatt_value->p_value[pos], 8);
                pos += 8;
            }
            else if (BLE_GLC_RA_CTRL_PT_FILTER_TYPE_SEQUENCE_NUMBER == p_app_value->operand[0])
            {
                memcpy(p_app_value->operand, &p_gatt_value->p_value[pos], 3);
                pos += 3;
            }
        } break;
    
        case BLE_GLC_RA_CTRL_PT_OPERATOR_WITHIN_RANGE_OF:
        {
            p_app_value->operand[0] = p_gatt_value->p_value[pos++];

            if (BLE_GLC_RA_CTRL_PT_FILTER_TYPE_USER_FACING_TIME == p_app_value->operand[0])
            {
                memcpy(p_app_value->operand, &p_gatt_value->p_value[pos], 15);
                pos += 15;
            }
            else if (BLE_GLC_RA_CTRL_PT_FILTER_TYPE_SEQUENCE_NUMBER == p_app_value->operand[0])
            {
                memcpy(p_app_value->operand, &p_gatt_value->p_value[pos], 5);
                pos += 5;
            }
        } break;
    }

    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_glc_ra_ctrl_pt_t(const st_ble_glc_ra_ctrl_pt_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    p_gatt_value->p_value[pos++] = p_app_value->op_code;
    p_gatt_value->p_value[pos++] = p_app_value->operator;

    switch (p_app_value->operator)
    {
        case BLE_GLC_RA_CTRL_PT_OPERATOR_LESS_THAN_OR_EQUAL_TO:
        case BLE_GLC_RA_CTRL_PT_OPERATOR_GREATER_THAN_OR_EQUAL_TO:
        {
            
            if (BLE_GLC_RA_CTRL_PT_FILTER_TYPE_USER_FACING_TIME == p_app_value->operand[0])
            {
                memcpy(&p_gatt_value->p_value[pos], p_app_value->operand, 8);
                pos += 8;
            }
            else if (BLE_GLC_RA_CTRL_PT_FILTER_TYPE_SEQUENCE_NUMBER == p_app_value->operand[0])
            {
                memcpy(&p_gatt_value->p_value[pos], p_app_value->operand, 3);
                pos += 3;
            }
        } break;
    
        case BLE_GLC_RA_CTRL_PT_OPERATOR_WITHIN_RANGE_OF:
        {
            if (BLE_GLC_RA_CTRL_PT_FILTER_TYPE_USER_FACING_TIME == p_app_value->operand[0])
            {
                memcpy(&p_gatt_value->p_value[pos], p_app_value->operand, 15);
                pos += 15;
            }
            else if (BLE_GLC_RA_CTRL_PT_FILTER_TYPE_SEQUENCE_NUMBER == p_app_value->operand[0])
            {
                memcpy(&p_gatt_value->p_value[pos], p_app_value->operand, 5);
                pos += 5;
            }
        } break;
    }

    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

/* Record Access Control Point characteristic descriptor definition */
static const st_ble_servc_desc_info_t *gspp_ra_ctrl_pt_descs[] = {
    &gs_ra_ctrl_pt_cli_cnfg,
};

/* Record Access Control Point characteristic definition */
const st_ble_servc_char_info_t gs_ra_ctrl_pt_char = {
    .uuid_16      = BLE_GLC_RA_CTRL_PT_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_glc_ra_ctrl_pt_t),
    .db_size      = BLE_GLC_RA_CTRL_PT_LEN,
    .char_idx     = BLE_GLC_RA_CTRL_PT_IDX,
    .p_attr_hdls  = gs_ra_ctrl_pt_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_glc_ra_ctrl_pt_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_glc_ra_ctrl_pt_t,
    .num_of_descs = ARRAY_SIZE(gspp_ra_ctrl_pt_descs),
    .pp_descs     = gspp_ra_ctrl_pt_descs,
};

ble_status_t R_BLE_GLC_WriteRaCtrlPt(uint16_t conn_hdl, const st_ble_glc_ra_ctrl_pt_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteChar(&gs_ra_ctrl_pt_char, conn_hdl, p_value);
}

void R_BLE_GLC_GetRaCtrlPtAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_glc_ra_ctrl_pt_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_ra_ctrl_pt_char_ranges[conn_idx];
    p_hdl->cli_cnfg_desc_hdl = gs_ra_ctrl_pt_cli_cnfg_desc_hdls[conn_idx];
}


/*----------------------------------------------------------------------------------------------------------------------
    Glucose client
----------------------------------------------------------------------------------------------------------------------*/

/* Glucose client attribute handles */
static st_ble_gatt_hdl_range_t gs_glc_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

const st_ble_servc_char_info_t *gspp_glc_chars[] = {
    &gs_meas_char,
    &gs_meas_context_char,
    &gs_feat_char,
    &gs_ra_ctrl_pt_char,
};

static st_ble_servc_info_t gs_client_info = {
    .pp_chars     = gspp_glc_chars,
    .num_of_chars = ARRAY_SIZE(gspp_glc_chars),
    .p_attr_hdls  = gs_glc_ranges,
};

ble_status_t R_BLE_GLC_Init(ble_servc_app_cb_t cb) // @suppress("API function naming")
{
    if (NULL == cb)
    {
        return BLE_ERR_INVALID_PTR;
    }

    gs_client_info.cb = cb;

    return R_BLE_SERVC_RegisterClient(&gs_client_info);
}

void R_BLE_GLC_ServDiscCb(uint16_t conn_hdl, uint8_t serv_idx, uint16_t type, void *p_param) // @suppress("API function naming")
{
    R_BLE_SERVC_ServDiscCb(&gs_client_info, conn_hdl, serv_idx, type, p_param);
}

void R_BLE_GLC_GetServAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_gatt_hdl_range_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    *p_hdl = gs_glc_ranges[conn_idx];
}
