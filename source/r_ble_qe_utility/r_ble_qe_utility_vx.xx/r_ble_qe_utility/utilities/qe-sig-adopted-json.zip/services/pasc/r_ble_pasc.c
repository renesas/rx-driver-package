/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_pasc.c
 * Version : 1.0
 * Description : The source file for Phone Alert Status Service client.
 **********************************************************************************************************************/
#include "r_ble_pasc.h"
#include "profile_cmn/r_ble_servc_if.h"

#ifndef UNUSED_ARG
#define UNUSED_ARG(arg)         (void)(arg)
#endif /* UNUSED_ARG */

static st_ble_servc_info_t gs_client_info;

/*----------------------------------------------------------------------------------------------------------------------
    Alert Status Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Alert Status characteristic descriptors attribute handles */
static uint16_t gs_alert_status_cli_cnfg_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_alert_status_cli_cnfg ={
    .uuid_16     = BLE_PASC_ALERT_STATUS_CLI_CNFG_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint16_t),
    .db_size     = BLE_PASC_ALERT_STATUS_CLI_CNFG_LEN,
    .desc_idx    = BLE_PASC_ALERT_STATUS_CLI_CNFG_IDX,
    .p_attr_hdls = gs_alert_status_cli_cnfg_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_PASC_WriteAlertStatusCliCnfg(uint16_t conn_hdl, const uint16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_alert_status_cli_cnfg, conn_hdl, p_value);
}

ble_status_t R_BLE_PASC_ReadAlertStatusCliCnfg(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_alert_status_cli_cnfg, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Alert Status Characteristic
----------------------------------------------------------------------------------------------------------------------*/


/* Alert Status characteristic 128 bit UUID */

/* Alert Status characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_alert_status_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

static ble_status_t decode_st_ble_pasc_alert_status_t(st_ble_pasc_alert_status_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    /* Convert byte sequence to application data. */
    if (p_gatt_value->value_len > 0)
    {
        p_app_value->is_ringer_active           =
            ((p_gatt_value->p_value[0] & BLE_PRV_PASC_ALERT_STATUS_ALERT_STATUS_RINGER_STATE) != 0);

        p_app_value->is_vibrate_active          =
            ((p_gatt_value->p_value[0] & BLE_PRV_PASC_ALERT_STATUS_ALERT_STATUS_VIBRATE_STATE) != 0);

        p_app_value->is_display_alert_active    =
            ((p_gatt_value->p_value[0] & BLE_PRV_PASC_ALERT_STATUS_ALERT_STATUS_DISPLAY_ALERT_STATUS) != 0);
    }

    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_pasc_alert_status_t(const st_ble_pasc_alert_status_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    UNUSED_ARG(p_app_value);
    UNUSED_ARG(p_gatt_value);

    /* TODO */
    return BLE_SUCCESS;
}

/* Alert Status characteristic descriptor definition */
static const st_ble_servc_desc_info_t *gspp_alert_status_descs[] = {
    &gs_alert_status_cli_cnfg,
};

/* Alert Status characteristic definition */
const st_ble_servc_char_info_t gs_alert_status_char = {
    .uuid_16      = BLE_PASC_ALERT_STATUS_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_pasc_alert_status_t),
    .db_size      = BLE_PASC_ALERT_STATUS_LEN,
    .char_idx     = BLE_PASC_ALERT_STATUS_IDX,
    .p_attr_hdls  = gs_alert_status_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_pasc_alert_status_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_pasc_alert_status_t,
    .num_of_descs = ARRAY_SIZE(gspp_alert_status_descs),
    .pp_descs     = gspp_alert_status_descs,
};

ble_status_t R_BLE_PASC_ReadAlertStatus(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_alert_status_char, conn_hdl);
}

void R_BLE_PASC_GetAlertStatusAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_pasc_alert_status_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_alert_status_char_ranges[conn_idx];
    p_hdl->cli_cnfg_desc_hdl = gs_alert_status_cli_cnfg_desc_hdls[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Ringer Setting Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Ringer Setting characteristic descriptors attribute handles */
static uint16_t gs_ringer_setting_cli_cnfg_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_ringer_setting_cli_cnfg ={
    .uuid_16     = BLE_PASC_RINGER_SETTING_CLI_CNFG_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint16_t),
    .db_size     = BLE_PASC_RINGER_SETTING_CLI_CNFG_LEN,
    .desc_idx    = BLE_PASC_RINGER_SETTING_CLI_CNFG_IDX,
    .p_attr_hdls = gs_ringer_setting_cli_cnfg_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_PASC_WriteRingerSettingCliCnfg(uint16_t conn_hdl, const uint16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_ringer_setting_cli_cnfg, conn_hdl, p_value);
}

ble_status_t R_BLE_PASC_ReadRingerSettingCliCnfg(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_ringer_setting_cli_cnfg, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Ringer Setting Characteristic
----------------------------------------------------------------------------------------------------------------------*/


/* Ringer Setting characteristic 128 bit UUID */

/* Ringer Setting characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_ringer_setting_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

/* Ringer Setting characteristic descriptor definition */
static const st_ble_servc_desc_info_t *gspp_ringer_setting_descs[] = {
    &gs_ringer_setting_cli_cnfg,
};

/* Ringer Setting characteristic definition */
const st_ble_servc_char_info_t gs_ringer_setting_char = {
    .uuid_16      = BLE_PASC_RINGER_SETTING_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(uint8_t),
    .db_size      = BLE_PASC_RINGER_SETTING_LEN,
    .char_idx     = BLE_PASC_RINGER_SETTING_IDX,
    .p_attr_hdls  = gs_ringer_setting_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_uint8_t,
    .encode       = (ble_servc_attr_encode_t)encode_uint8_t,
    .num_of_descs = ARRAY_SIZE(gspp_ringer_setting_descs),
    .pp_descs     = gspp_ringer_setting_descs,
};

ble_status_t R_BLE_PASC_ReadRingerSetting(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_ringer_setting_char, conn_hdl);
}

void R_BLE_PASC_GetRingerSettingAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_pasc_ringer_setting_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_ringer_setting_char_ranges[conn_idx];
    p_hdl->cli_cnfg_desc_hdl = gs_ringer_setting_cli_cnfg_desc_hdls[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Ringer Control point Characteristic
----------------------------------------------------------------------------------------------------------------------*/


/* Ringer Control point characteristic 128 bit UUID */

/* Ringer Control point characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_ringer_control_point_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

/* Ringer Control point characteristic definition */
const st_ble_servc_char_info_t gs_ringer_control_point_char = {
    .uuid_16      = BLE_PASC_RINGER_CONTROL_POINT_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(uint8_t),
    .db_size      = BLE_PASC_RINGER_CONTROL_POINT_LEN,
    .char_idx     = BLE_PASC_RINGER_CONTROL_POINT_IDX,
    .p_attr_hdls  = gs_ringer_control_point_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_uint8_t,
    .encode       = (ble_servc_attr_encode_t)encode_uint8_t,
};

void R_BLE_PASC_GetRingerControlPointAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_pasc_ringer_control_point_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_ringer_control_point_char_ranges[conn_idx];
}

ble_status_t R_BLE_PASC_WriteWithoutRspRingerControlPoint(uint16_t conn_hdl, const uint16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteCmdChar(&gs_ringer_control_point_char, conn_hdl, p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Phone Alert Status Service client
----------------------------------------------------------------------------------------------------------------------*/

/* Phone Alert Status Service client attribute handles */
static st_ble_gatt_hdl_range_t gs_pasc_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

const st_ble_servc_char_info_t *gspp_pasc_chars[] = {
    &gs_alert_status_char,
    &gs_ringer_setting_char,
    &gs_ringer_control_point_char,
};

static st_ble_servc_info_t gs_client_info = {
    .pp_chars     = gspp_pasc_chars,
    .num_of_chars = ARRAY_SIZE(gspp_pasc_chars),
    .p_attr_hdls  = gs_pasc_ranges,
};

ble_status_t R_BLE_PASC_Init(ble_servc_app_cb_t cb) // @suppress("API function naming")
{
    if (NULL == cb)
    {
        return BLE_ERR_INVALID_PTR;
    }

    gs_client_info.cb = cb;

    return R_BLE_SERVC_RegisterClient(&gs_client_info);
}

void R_BLE_PASC_ServDiscCb(uint16_t conn_hdl, uint8_t serv_idx, uint16_t type, void *p_param) // @suppress("API function naming")
{
    R_BLE_SERVC_ServDiscCb(&gs_client_info, conn_hdl, serv_idx, type, p_param);
}

void R_BLE_PASC_GetServAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_gatt_hdl_range_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    *p_hdl = gs_pasc_ranges[conn_idx];
}
