/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_pasc.h
 * Version : 1.0
 * Description : The header file for Phone Alert Status Service client.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 31.12.2999 1.00 First Release
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @file
 * @defgroup pasc Phone Alert Status Service Client
 * @{
 * @ingroup profile
 * @brief   This is the client for the Phone Alert Status Service Service.
 **********************************************************************************************************************/
#include "r_ble_rx23w_if.h"

#include "profile_cmn/r_ble_profile_cmn.h"
#include "profile_cmn/r_ble_servc_if.h"

#ifndef R_BLE_PASC_H
#define R_BLE_PASC_H

/*----------------------------------------------------------------------------------------------------------------------
    Alert Status Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_PASC_ALERT_STATUS_UUID (0x2A3F)
#define BLE_PASC_ALERT_STATUS_LEN (1)
#define BLE_PASC_ALERT_STATUS_CLI_CNFG_UUID (0x2902)
#define BLE_PASC_ALERT_STATUS_CLI_CNFG_LEN (2)

/*******************************************************************************************************************//**
 * @brief Ringer State bit.
***********************************************************************************************************************/
#define BLE_PRV_PASC_ALERT_STATUS_ALERT_STATUS_RINGER_STATE              (1 << 0)

/*******************************************************************************************************************//**
 * @brief Vibrate State bit.
***********************************************************************************************************************/
#define BLE_PRV_PASC_ALERT_STATUS_ALERT_STATUS_VIBRATE_STATE             (1 << 1)

/*******************************************************************************************************************//**
 * @brief Display Alert Status bit.
***********************************************************************************************************************/
#define BLE_PRV_PASC_ALERT_STATUS_ALERT_STATUS_DISPLAY_ALERT_STATUS      (1 << 2)

/***************************************************************************//**
 * @brief Alert Status value structure.
*******************************************************************************/
typedef struct {
    bool is_ringer_active; /**< Ringer Active */
    bool is_vibrate_active; /**< Vibrate Active */
    bool is_display_alert_active; /**< Display Alert Active */
} st_ble_pasc_alert_status_t;

/***************************************************************************//**
 * @brief Alert Status attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
    uint16_t cli_cnfg_desc_hdl;
} st_ble_pasc_alert_status_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Alert Status characteristic Client Characteristic Configuration descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_PASC_ReadAlertStatusCliCnfg(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Alert Status characteristic Client Characteristic Configuration descriptor value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value Alert Status characteristic Client Characteristic Configuration descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_PASC_WriteAlertStatusCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Read Alert Status characteristic value from the remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_PASC_ReadAlertStatus(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief      Get Alert Status attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_PASC_GetAlertStatusAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_pasc_alert_status_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Ringer Setting Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_PASC_RINGER_SETTING_UUID (0x2A41)
#define BLE_PASC_RINGER_SETTING_LEN (1)
#define BLE_PASC_RINGER_SETTING_CLI_CNFG_UUID (0x2902)
#define BLE_PASC_RINGER_SETTING_CLI_CNFG_LEN (2)

/***************************************************************************//**
 * @brief Ringer Setting Ringer Setting enumeration.
*******************************************************************************/
typedef enum {
    BLE_PASC_RINGER_SETTING_RINGER_SETTING_RINGER_SILENT = 0, /**< Ringer Silent */
    BLE_PASC_RINGER_SETTING_RINGER_SETTING_RINGER_NORMAL = 1, /**< Ringer Normal */
} e_ble_pasc_ringer_setting_ringer_setting_t;

/***************************************************************************//**
 * @brief Ringer Setting attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
    uint16_t cli_cnfg_desc_hdl;
} st_ble_pasc_ringer_setting_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Ringer Setting characteristic Client Characteristic Configuration descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_PASC_ReadRingerSettingCliCnfg(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Ringer Setting characteristic Client Characteristic Configuration descriptor value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value Ringer Setting characteristic Client Characteristic Configuration descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_PASC_WriteRingerSettingCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Read Ringer Setting characteristic value from the remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_PASC_ReadRingerSetting(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief      Get Ringer Setting attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_PASC_GetRingerSettingAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_pasc_ringer_setting_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Ringer Control point Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_PASC_RINGER_CONTROL_POINT_UUID (0x2A40)
#define BLE_PASC_RINGER_CONTROL_POINT_LEN (1)
/***************************************************************************//**
 * @brief Ringer Control point Ringer Control Point enumeration.
*******************************************************************************/
typedef enum {
    BLE_PASC_RINGER_CONTROL_POINT_RINGER_CONTROL_POINT_SILENT_MODE = 1, /**< Silent Mode */
    BLE_PASC_RINGER_CONTROL_POINT_RINGER_CONTROL_POINT_MUTE_ONCE = 2, /**< Mute Once */
    BLE_PASC_RINGER_CONTROL_POINT_RINGER_CONTROL_POINT_CANCEL_SILENT_MODE = 3, /**< Cancel Silent Mode */
} e_ble_pasc_ringer_control_point_ringer_control_point_t;

/***************************************************************************//**
 * @brief Ringer Control point attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
} st_ble_pasc_ringer_control_point_attr_hdl_t;

/***************************************************************************//**
 * @brief      Get Ringer Control point attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_PASC_GetRingerControlPointAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_pasc_ringer_control_point_attr_hdl_t *p_hdl);


/*----------------------------------------------------------------------------------------------------------------------
    Phone Alert Status Service Client
----------------------------------------------------------------------------------------------------------------------*/

/***************************************************************************//**
 * @brief Phone Alert Status Service client event data.
*******************************************************************************/
typedef struct {
    uint16_t    conn_hdl;  /**< Connection handle */
    uint16_t    param_len; /**< Event parameter length */
    const void *p_param;   /**< Event parameter */
} st_ble_pasc_evt_data_t;

/***************************************************************************//**
 * @brief Phone Alert Status Service characteristic ID.
*******************************************************************************/
typedef enum {
    BLE_PASC_ALERT_STATUS_IDX,
    BLE_PASC_ALERT_STATUS_CLI_CNFG_IDX,
    BLE_PASC_RINGER_SETTING_IDX,
    BLE_PASC_RINGER_SETTING_CLI_CNFG_IDX,
    BLE_PASC_RINGER_CONTROL_POINT_IDX,
} e_ble_pasc_char_idx_t;

/***************************************************************************//**
 * @brief Phone Alert Status Service client event type.
*******************************************************************************/
typedef enum {
    /* Alert Status */
    BLE_PASC_EVENT_ALERT_STATUS_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_PASC_ALERT_STATUS_IDX, BLE_SERVC_READ_RSP),
    BLE_PASC_EVENT_ALERT_STATUS_HDL_VAL_NTF = BLE_SERVC_ATTR_EVENT(BLE_PASC_ALERT_STATUS_IDX, BLE_SERVC_HDL_VAL_NTF),
    BLE_PASC_EVENT_ALERT_STATUS_CLI_CNFG_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_PASC_ALERT_STATUS_CLI_CNFG_IDX, BLE_SERVC_READ_RSP),
    BLE_PASC_EVENT_ALERT_STATUS_CLI_CNFG_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_PASC_ALERT_STATUS_CLI_CNFG_IDX, BLE_SERVC_WRITE_RSP),
    /* Ringer Setting */
    BLE_PASC_EVENT_RINGER_SETTING_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_PASC_RINGER_SETTING_IDX, BLE_SERVC_READ_RSP),
    BLE_PASC_EVENT_RINGER_SETTING_HDL_VAL_NTF = BLE_SERVC_ATTR_EVENT(BLE_PASC_RINGER_SETTING_IDX, BLE_SERVC_HDL_VAL_NTF),
    BLE_PASC_EVENT_RINGER_SETTING_CLI_CNFG_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_PASC_RINGER_SETTING_CLI_CNFG_IDX, BLE_SERVC_READ_RSP),
    BLE_PASC_EVENT_RINGER_SETTING_CLI_CNFG_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_PASC_RINGER_SETTING_CLI_CNFG_IDX, BLE_SERVC_WRITE_RSP),
    /* Ringer Control point */
} e_ble_pasc_event_t;

/***************************************************************************//**
 * @brief     Initialize Phone Alert Status Service client.
 * @param[in] cb Client callback.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_PASC_Init(ble_servc_app_cb_t cb);

/***************************************************************************//**
 * @brief     Phone Alert Status Service client discovery callback.
 * @param[in] conn_hdl Connection handle
 * @param[in] serv_idx Service instance index.
 * @param[in] type     Service discovery event type.
 * @param[in] p_param  Service discovery event parameter.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_PASC_ServDiscCb(uint16_t conn_hdl, uint8_t serv_idx, uint16_t type, void *p_param);

/***************************************************************************//**
 * @brief     Get Phone Alert Status Service client attribute handle.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
*******************************************************************************/
void R_BLE_PASC_GetServAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_gatt_hdl_range_t *p_hdl);

#endif /* R_BLE_PASC_H */

/** @} */
