/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2018 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_iac.h
 * Version : 1.0
 * Description : This module implements Immediate Alert Service Client.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 24.05.2019 1.00 First Release
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @file
 * @defgroup iac Immediate Alert Service Client
 * @{
 * @ingroup profile
 * @brief This is the client for the Immediate Alert Service.
 **********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "profile_cmn/r_ble_serv_common.h"

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
#ifndef R_BLE_IAC_H
#define R_BLE_IAC_H

/*******************************************************************************************************************//**
 * @brief Alert Level characteristic value length.
***********************************************************************************************************************/
#define BLE_IAC_ALERT_LEVEL_LEN (1)

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @brief Immediate Alert Service Client event data.
***********************************************************************************************************************/
typedef struct
{
    uint16_t  conn_hdl;  /**< Connection handle */
    uint16_t  param_len; /**< Event parameter length */
    void     *p_param;   /**< Event parameter */
} st_ble_iac_evt_data_t;

/*******************************************************************************************************************//**
 * @brief Immediate Alert Service Client event callback.
***********************************************************************************************************************/
typedef void (*ble_iac_app_cb_t)(uint16_t type, ble_status_t result, st_ble_iac_evt_data_t *p_data);

/*******************************************************************************************************************//**
 * @brief Immediate Alert Service Client event type.
***********************************************************************************************************************/
typedef enum 
{
    BLE_IAC_EVENT_ERROR_RSP              /**< error response */
} e_ble_iac_event_t;

/*******************************************************************************************************************//**
 * @brief Alert Level enumeration.
***********************************************************************************************************************/
typedef enum {
    BLE_IAC_ALERT_LEVEL_ALERT_LEVEL_NO_ALERT   = 0, /**< Alert level no alert shall be done on the device*/
    BLE_IAC_ALERT_LEVEL_ALERT_LEVEL_MILD_ALERT = 1, /**< Alert level mild alert the device shall alert*/
    BLE_IAC_ALERT_LEVEL_ALERT_LEVEL_HIGH_ALERT = 2, /**< Alert level high alert the device shall alert the strongest possible*/
} e_ble_iac_alert_level_t;

/*******************************************************************************************************************//**
 * @brief Immediate Alert Service attribute handles.
***********************************************************************************************************************/
typedef struct 
{
    st_ble_gatt_hdl_range_t service_range;            /**< Immediate Alert Service range */
    uint16_t                alert_level_char_val_hdl; /**< Alert Level characteristic value handle */
} st_ble_iac_hdls_t;

/*******************************************************************************************************************//**
 * @brief Immediate Alert Service initialization parameters.
***********************************************************************************************************************/
typedef struct 
{
    ble_iac_app_cb_t cb; /**< Immediate Alert Service Client event handler */
} st_ble_iac_init_param_t;

/*******************************************************************************************************************//**
 * @brief Immediate Alert Service Client connection parameters.
***********************************************************************************************************************/
typedef struct 
{
    st_ble_iac_hdls_t *p_hdls; /**< Immediate Alert Service handles */
} st_ble_iac_connect_param_t;

/*******************************************************************************************************************//**
 * @brief Immediate Alert Service disconnection parameters.
***********************************************************************************************************************/
typedef struct 
{
    st_ble_iac_hdls_t *p_hdls; /**< Immediate Alert Service handles */
} st_ble_iac_disconnect_param_t;

/***********************************************************************************************************************
Exported global variables (to be accessed by other files)
***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @brief Immediate Alert Service UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_IAC_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Alert Level characteristic UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_IAC_ALERT_LEVEL_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/***********************************************************************************************************************
Exported global functions (to be accessed by other files)
***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @brief     Initialize Immediate Alert Service  Client.
 * @details   This function shall be called once at startup.
 * @param[in] p_param pointer to Immediate Alert Service Client initialization parameters.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_IAC_Init(const st_ble_iac_init_param_t *p_param);

/*******************************************************************************************************************//**
 * @brief     Perform Immediate Alert Service Client connection settings.
 * @details   This function shall be called on each connection establishment.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_param    Pointer to Connection parameters.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_IAC_Connect(uint16_t conn_hdl, const st_ble_iac_connect_param_t *p_param);

/*******************************************************************************************************************//**
 * @brief     Retrieve Immediate Alert Service Client connection specific settings before disconnection.
 * @details   This function shall be called on each disconnection.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_param     Pointer to Disconnection parameters.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_IAC_Disconnect(uint16_t conn_hdl, st_ble_iac_disconnect_param_t *p_param);

/*******************************************************************************************************************//**
 * @brief     Write Alert Level characteristic value without response to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] app_value Alert Level characteristic value to write.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_IAC_WriteWithoutRspAlertLevel(uint16_t conn_hdl, uint8_t app_value);

/*******************************************************************************************************************//**
 * @brief      Callback function for the Immediate Alert Discovery events.
 * @param[in]  conn_hdl Connection handle.
 * @param[in]  idx      Service index used to distiguish the multiple same UUID service.
 * @param[in]  type     Discovery event type
 * @param[out] p_param   Pointer to GATTC event data.
***********************************************************************************************************************/
void R_BLE_IAC_ServDiscCb(uint16_t conn_hdl, uint8_t idx, uint16_t type, void *p_param);

/*******************************************************************************************************************//**
 * @brief     Return version of the IAC service client.
 * @return    version
***********************************************************************************************************************/
uint32_t R_BLE_IAC_GetVersion(void);

#endif /* R_BLE_IAC_H */

/** @} */
