/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_pass.h
 * Version : 1.0
 * Description : The header file for Phone Alert Status Service service.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 31.12.2999 1.00 First Release
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @file
 * @defgroup pass Phone Alert Status Service Server
 * @{
 * @ingroup profile
 * @brief   This service exposes the phone alert status when in a connection.
 **********************************************************************************************************************/

#include "profile_cmn/r_ble_servs_if.h"
#include "gatt_db.h"

#ifndef R_BLE_PASS_H
#define R_BLE_PASS_H

/*----------------------------------------------------------------------------------------------------------------------
    Alert Status Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/***************************************************************************//**
 * @brief Alert Status value structure.
*******************************************************************************/
typedef struct {
    bool is_ringer_active; /**< Ringer Active */
    bool is_vibrate_active; /**< Vibrate Active */
    bool is_display_alert_active; /**< Display Alert Active */
} st_ble_pass_alert_status_t;

/***************************************************************************//**
 * @brief     Set Alert Status characteristic value to the local GATT database.
 * @param[in] p_value  Characteristic value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_PASS_SetAlertStatus(const st_ble_pass_alert_status_t *p_value);

/***************************************************************************//**
 * @brief     Get Alert Status characteristic value from the local GATT database.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_PASS_GetAlertStatus(st_ble_pass_alert_status_t *p_value);

/***************************************************************************//**
 * @brief     Send notification of  Alert Status characteristic value to the remote device.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value  Characteristic value to send.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_PASS_NotifyAlertStatus(uint16_t conn_hdl, const st_ble_pass_alert_status_t *p_value);

/***************************************************************************//**
 * @brief     Set Alert Status cli cnfg descriptor value to the local GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_PASS_SetAlertStatusCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Get Alert Status cli cnfg descriptor value from the local GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_PASS_GetAlertStatusCliCnfg(uint16_t conn_hdl, uint16_t *p_value);

/*----------------------------------------------------------------------------------------------------------------------
    Ringer Setting Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/***************************************************************************//**
 * @brief Ringer Setting Ringer Setting enumeration.
*******************************************************************************/
typedef enum {
    BLE_PASS_RINGER_SETTING_RINGER_SETTING_RINGER_SILENT = 0, /**< Ringer Silent */
    BLE_PASS_RINGER_SETTING_RINGER_SETTING_RINGER_NORMAL = 1, /**< Ringer Normal */
} e_ble_pass_ringer_setting_ringer_setting_t;

/***************************************************************************//**
 * @brief     Set Ringer Setting characteristic value to the local GATT database.
 * @param[in] p_value  Characteristic value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_PASS_SetRingerSetting(const uint8_t *p_value);

/***************************************************************************//**
 * @brief     Get Ringer Setting characteristic value from the local GATT database.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_PASS_GetRingerSetting(uint8_t *p_value);

/***************************************************************************//**
 * @brief     Send notification of  Ringer Setting characteristic value to the remote device.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value  Characteristic value to send.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_PASS_NotifyRingerSetting(uint16_t conn_hdl, const uint8_t *p_value);

/***************************************************************************//**
 * @brief     Set Ringer Setting cli cnfg descriptor value to the local GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_PASS_SetRingerSettingCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Get Ringer Setting cli cnfg descriptor value from the local GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_PASS_GetRingerSettingCliCnfg(uint16_t conn_hdl, uint16_t *p_value);

/*----------------------------------------------------------------------------------------------------------------------
    Ringer Control point Characteristic
----------------------------------------------------------------------------------------------------------------------*/
/***************************************************************************//**
 * @brief Ringer Control point Ringer Control Point enumeration.
*******************************************************************************/
typedef enum {
    BLE_PASS_RINGER_CONTROL_POINT_RINGER_CONTROL_POINT_SILENT_MODE = 1, /**< Silent Mode */
    BLE_PASS_RINGER_CONTROL_POINT_RINGER_CONTROL_POINT_MUTE_ONCE = 2, /**< Mute Once */
    BLE_PASS_RINGER_CONTROL_POINT_RINGER_CONTROL_POINT_CANCEL_SILENT_MODE = 3, /**< Cancel Silent Mode */
} e_ble_pass_ringer_control_point_ringer_control_point_t;

/*----------------------------------------------------------------------------------------------------------------------
    Phone Alert Status Service Service
----------------------------------------------------------------------------------------------------------------------*/

/***************************************************************************//**
 * @brief Phone Alert Status Service characteristic Index.
*******************************************************************************/
typedef enum {
    BLE_PASS_ALERT_STATUS_IDX,
    BLE_PASS_ALERT_STATUS_CLI_CNFG_IDX,
    BLE_PASS_RINGER_SETTING_IDX,
    BLE_PASS_RINGER_SETTING_CLI_CNFG_IDX,
    BLE_PASS_RINGER_CONTROL_POINT_IDX,
} e_ble_pass_char_idx_t;

/***************************************************************************//**
 * @brief Phone Alert Status Service event type.
*******************************************************************************/
typedef enum {
    /* Alert Status */
    BLE_PASS_EVENT_ALERT_STATUS_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_PASS_ALERT_STATUS_IDX, BLE_SERVS_READ_REQ),
    BLE_PASS_EVENT_ALERT_STATUS_CLI_CNFG_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_PASS_ALERT_STATUS_CLI_CNFG_IDX, BLE_SERVS_WRITE_REQ),
    BLE_PASS_EVENT_ALERT_STATUS_CLI_CNFG_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_PASS_ALERT_STATUS_CLI_CNFG_IDX, BLE_SERVS_WRITE_COMP),
    BLE_PASS_EVENT_ALERT_STATUS_CLI_CNFG_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_PASS_ALERT_STATUS_CLI_CNFG_IDX, BLE_SERVS_READ_REQ),
    /* Ringer Setting */
    BLE_PASS_EVENT_RINGER_SETTING_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_PASS_RINGER_SETTING_IDX, BLE_SERVS_READ_REQ),
    BLE_PASS_EVENT_RINGER_SETTING_CLI_CNFG_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_PASS_RINGER_SETTING_CLI_CNFG_IDX, BLE_SERVS_WRITE_REQ),
    BLE_PASS_EVENT_RINGER_SETTING_CLI_CNFG_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_PASS_RINGER_SETTING_CLI_CNFG_IDX, BLE_SERVS_WRITE_COMP),
    BLE_PASS_EVENT_RINGER_SETTING_CLI_CNFG_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_PASS_RINGER_SETTING_CLI_CNFG_IDX, BLE_SERVS_READ_REQ),
    /* Ringer Control point */
    BLE_PASS_EVENT_RINGER_CONTROL_POINT_WRITE_CMD = BLE_SERVS_ATTR_EVENT(BLE_PASS_RINGER_CONTROL_POINT_IDX, BLE_SERVS_WRITE_CMD),
} e_ble_pass_event_t;

/***************************************************************************//**
 * @brief     Initialize Phone Alert Status Service service.
 * @param[in] cb Service callback.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_PASS_Init(ble_servs_app_cb_t cb);

#endif /* R_BLE_PASS_H */

/** @} */
