/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_hts.h
 * Version : 1.0
 * Description : The header file for Health Thermometer Service service.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 31.12.2999 1.00 First Release
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @file
 * @defgroup hts Health Thermometer Service Server
 * @{
 * @ingroup profile
 * @brief   The Health Thermometer service exposes temperature and other data from a thermometer intended for healthcare and fitness applications.
 **********************************************************************************************************************/
#include "profile_cmn/r_ble_serv_common.h"

#include "profile_cmn/r_ble_servs_if.h"
#include "gatt_db.h"

#ifndef R_BLE_HTS_H
#define R_BLE_HTS_H

/*----------------------------------------------------------------------------------------------------------------------
    Temperature Measurement Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/***************************************************************************//**
 * @brief Temperature Measurement Flags value structure.
*******************************************************************************/
#ifndef R_BLE_HTC_H
typedef struct {
    bool temperature_units_flag; /**< Temperature Units Flag */
    bool time_stamp_flag; /**< Time Stamp Flag */
    bool temperature_type_flag; /**< Temperature Type Flag */
} st_ble_temp_meas_flags_t;
#endif /* R_BLE_HTC_H */

/***************************************************************************//**
 * @brief Temperature Measurement value structure.
*******************************************************************************/
typedef struct {
    st_ble_temp_meas_flags_t flags; /**< Flags */
    st_ble_ieee11073_float_t temperature_measurement_value; /**< Temperature Measurement Value. Celsius or Fahrenheit will be defined in flag field. */
    st_ble_date_time_t time_stamp; /**< Time Stamp */
    uint8_t temperature_type; /**< Temperature Type */
} st_ble_hts_temp_meas_t;

/***************************************************************************//**
 * @brief     Send indication of  Temperature Measurement characteristic value to the remote device.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value  Characteristic value to send.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_HTS_IndicateTempMeas(uint16_t conn_hdl, const st_ble_hts_temp_meas_t *p_value);

/***************************************************************************//**
 * @brief     Set Temperature Measurement cli cnfg descriptor value to the local GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_HTS_SetTempMeasCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Get Temperature Measurement cli cnfg descriptor value from the local GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_HTS_GetTempMeasCliCnfg(uint16_t conn_hdl, uint16_t *p_value);

/*----------------------------------------------------------------------------------------------------------------------
    Temperature Type Characteristic
----------------------------------------------------------------------------------------------------------------------*/
/***************************************************************************//**
 * @brief Temperature Type Temperature Text Description enumeration.
*******************************************************************************/
typedef enum {
    BLE_HTS_TEMP_TYPE_TEMPERATURE_TEXT_DESCRIPTION_ARMPIT = 1, /**< Armpit */
    BLE_HTS_TEMP_TYPE_TEMPERATURE_TEXT_DESCRIPTION_BODY = 2, /**< Body (general) */
    BLE_HTS_TEMP_TYPE_TEMPERATURE_TEXT_DESCRIPTION_EAR = 3, /**< Ear (usually ear lobe) */
    BLE_HTS_TEMP_TYPE_TEMPERATURE_TEXT_DESCRIPTION_FINGER = 4, /**< Finger */
    BLE_HTS_TEMP_TYPE_TEMPERATURE_TEXT_DESCRIPTION_GASTRO_INTESTINAL_TRACT = 5, /**< Gastro-intestinal Tract */
    BLE_HTS_TEMP_TYPE_TEMPERATURE_TEXT_DESCRIPTION_MOUTH = 6, /**< Mouth */
    BLE_HTS_TEMP_TYPE_TEMPERATURE_TEXT_DESCRIPTION_RECTUM = 7, /**< Rectum */
    BLE_HTS_TEMP_TYPE_TEMPERATURE_TEXT_DESCRIPTION_TOE = 8, /**< Toe */
    BLE_HTS_TEMP_TYPE_TEMPERATURE_TEXT_DESCRIPTION_TYMPANUM = 9, /**< Tympanum (ear drum) */
} e_ble_temp_type_temperature_text_description_t;

/***************************************************************************//**
 * @brief     Set Temperature Type characteristic value to the local GATT database.
 * @param[in] p_value  Characteristic value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_HTS_SetTempType(const uint8_t *p_value);

/***************************************************************************//**
 * @brief     Get Temperature Type characteristic value from the local GATT database.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_HTS_GetTempType(uint8_t *p_value);

/*----------------------------------------------------------------------------------------------------------------------
    Intermediate Temperature Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/***************************************************************************//**
 * @brief Intermediate Temperature value structure.
*******************************************************************************/
typedef struct {
    st_ble_hts_temp_meas_t temp_meas; /**< Temperature measurement */
} st_ble_hts_intermediate_temperature_t;

/***************************************************************************//**
 * @brief     Send notification of  Intermediate Temperature characteristic value to the remote device.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value  Characteristic value to send.

 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_HTS_NotifyIntermediateTemperature(uint16_t conn_hdl, const st_ble_hts_intermediate_temperature_t *p_value);

/***************************************************************************//**
 * @brief     Set Intermediate Temperature cli cnfg descriptor value to the local GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_HTS_SetIntermediateTemperatureCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Get Intermediate Temperature cli cnfg descriptor value from the local GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_HTS_GetIntermediateTemperatureCliCnfg(uint16_t conn_hdl, uint16_t *p_value);

/*----------------------------------------------------------------------------------------------------------------------
    Measurement Interval Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/***************************************************************************//**
 * @brief Valid Range value structure.
*******************************************************************************/
#ifndef R_BLE_HTC_H
typedef struct {
    uint16_t lower_inclusive_value; /**< Lower inclusive value */
    uint16_t upper_inclusive_value; /**< Upper inclusive value */
} st_ble_meas_interval_valid_range_t;
#endif /* R_BLE_HTC_H */

/***************************************************************************//**
 * @brief     Set Measurement Interval characteristic value to the local GATT database.
 * @param[in] p_value  Characteristic value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_HTS_SetMeasInterval(const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Get Measurement Interval characteristic value from the local GATT database.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_HTS_GetMeasInterval(uint16_t *p_value);

/***************************************************************************//**
 * @brief     Send indication of  Measurement Interval characteristic value to the remote device.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value  Characteristic value to send.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_HTS_IndicateMeasInterval(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Set Measurement Interval cli cnfg descriptor value to the local GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_HTS_SetMeasIntervalCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Get Measurement Interval cli cnfg descriptor value from the local GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_HTS_GetMeasIntervalCliCnfg(uint16_t conn_hdl, uint16_t *p_value);

/***************************************************************************//**
 * @brief     Set Measurement Interval valid range descriptor value to the local GATT database.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_HTS_SetMeasIntervalValidRange(const st_ble_meas_interval_valid_range_t *p_value);

/***************************************************************************//**
 * @brief     Get Measurement Interval valid range descriptor value from the local GATT database.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_HTS_GetMeasIntervalValidRange(st_ble_meas_interval_valid_range_t *p_value);

/*----------------------------------------------------------------------------------------------------------------------
    Health Thermometer Service Service
----------------------------------------------------------------------------------------------------------------------*/

/***************************************************************************//**
 * @brief 
*******************************************************************************/
#define BLE_HTS_OUT_OF_RANGE_ERROR (BLE_ERR_GROUP_GATT | 0x80)

/***************************************************************************//**
 * @brief Health Thermometer Service characteristic Index.
*******************************************************************************/
typedef enum {
    BLE_HTS_TEMP_MEAS_IDX,
    BLE_HTS_TEMP_MEAS_CLI_CNFG_IDX,
    BLE_HTS_TEMP_TYPE_IDX,
    BLE_HTS_INTERMEDIATE_TEMPERATURE_IDX,
    BLE_HTS_INTERMEDIATE_TEMPERATURE_CLI_CNFG_IDX,
    BLE_HTS_MEAS_INTERVAL_IDX,
    BLE_HTS_MEAS_INTERVAL_CLI_CNFG_IDX,
    BLE_HTS_MEAS_INTERVAL_VALID_RANGE_IDX,
} e_ble_hts_char_idx_t;

/***************************************************************************//**
 * @brief Health Thermometer Service event type.
*******************************************************************************/
typedef enum {
    /* Temperature Measurement */
    BLE_HTS_EVENT_TEMP_MEAS_HDL_VAL_CNF = BLE_SERVS_ATTR_EVENT(BLE_HTS_TEMP_MEAS_IDX, BLE_SERVS_HDL_VAL_CNF),
    BLE_HTS_EVENT_TEMP_MEAS_CLI_CNFG_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_HTS_TEMP_MEAS_CLI_CNFG_IDX, BLE_SERVS_WRITE_REQ),
    BLE_HTS_EVENT_TEMP_MEAS_CLI_CNFG_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_HTS_TEMP_MEAS_CLI_CNFG_IDX, BLE_SERVS_WRITE_COMP),
    BLE_HTS_EVENT_TEMP_MEAS_CLI_CNFG_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_HTS_TEMP_MEAS_CLI_CNFG_IDX, BLE_SERVS_READ_REQ),
    /* Temperature Type */
    BLE_HTS_EVENT_TEMP_TYPE_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_HTS_TEMP_TYPE_IDX, BLE_SERVS_READ_REQ),
    /* Intermediate Temperature */
    BLE_HTS_EVENT_INTERMEDIATE_TEMPERATURE_CLI_CNFG_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_HTS_INTERMEDIATE_TEMPERATURE_CLI_CNFG_IDX, BLE_SERVS_WRITE_REQ),
    BLE_HTS_EVENT_INTERMEDIATE_TEMPERATURE_CLI_CNFG_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_HTS_INTERMEDIATE_TEMPERATURE_CLI_CNFG_IDX, BLE_SERVS_WRITE_COMP),
    BLE_HTS_EVENT_INTERMEDIATE_TEMPERATURE_CLI_CNFG_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_HTS_INTERMEDIATE_TEMPERATURE_CLI_CNFG_IDX, BLE_SERVS_READ_REQ),
    /* Measurement Interval */
    BLE_HTS_EVENT_MEAS_INTERVAL_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_HTS_MEAS_INTERVAL_IDX, BLE_SERVS_WRITE_REQ),
    BLE_HTS_EVENT_MEAS_INTERVAL_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_HTS_MEAS_INTERVAL_IDX, BLE_SERVS_WRITE_COMP),
    BLE_HTS_EVENT_MEAS_INTERVAL_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_HTS_MEAS_INTERVAL_IDX, BLE_SERVS_READ_REQ),
    BLE_HTS_EVENT_MEAS_INTERVAL_HDL_VAL_CNF = BLE_SERVS_ATTR_EVENT(BLE_HTS_MEAS_INTERVAL_IDX, BLE_SERVS_HDL_VAL_CNF),
    BLE_HTS_EVENT_MEAS_INTERVAL_CLI_CNFG_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_HTS_MEAS_INTERVAL_CLI_CNFG_IDX, BLE_SERVS_WRITE_REQ),
    BLE_HTS_EVENT_MEAS_INTERVAL_CLI_CNFG_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_HTS_MEAS_INTERVAL_CLI_CNFG_IDX, BLE_SERVS_WRITE_COMP),
    BLE_HTS_EVENT_MEAS_INTERVAL_CLI_CNFG_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_HTS_MEAS_INTERVAL_CLI_CNFG_IDX, BLE_SERVS_READ_REQ),
    BLE_HTS_EVENT_MEAS_INTERVAL_VALID_RANGE_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_HTS_MEAS_INTERVAL_VALID_RANGE_IDX, BLE_SERVS_READ_REQ),
} e_ble_hts_event_t;

/***************************************************************************//**
 * @brief     Initialize Health Thermometer Service service.
 * @param[in] cb Service callback.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_HTS_Init(ble_servs_app_cb_t cb);

#endif /* R_BLE_HTS_H */

/** @} */
