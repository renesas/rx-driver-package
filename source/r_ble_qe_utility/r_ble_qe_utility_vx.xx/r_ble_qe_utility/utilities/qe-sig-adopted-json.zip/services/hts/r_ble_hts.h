/***********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
 * SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2018 Renesas Electronics Corporation. All rights reserved.
 ***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_hts.h
 * Version : 1.0
 * Description: This file provides APIs to interface Health Thermometer Service Server
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 30.11.2018 1.00 First Release
 **********************************************************************************************************************/
/*******************************************************************************************************************//**
 * @file
 * @defgroup hts Health Thermometer Service 
 * @{
 * @ingroup profile
 * @brief   This file provides APIs to interface Health Thermometer Service.
 **********************************************************************************************************************/

/***********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 ***********************************************************************************************************************/
#include "r_ble_rx23w_if.h"
#include "profile_cmn/r_ble_profile_cmn.h"

/***********************************************************************************************************************
 Macro definitions
 ***********************************************************************************************************************/
#ifndef R_BLE_HTS_H
#define R_BLE_HTS_H

/*******************************************************************************************************************//**
 * @brief Out of Range error code.
 ***********************************************************************************************************************/
#define BLE_HTS_OUT_OF_RANGE                                            (BLE_ERR_GROUP_GATT | 0x80)

/*******************************************************************************************************************//**
 * @brief Temperature Units Flag bit.
 ***********************************************************************************************************************/
#define BLE_HTS_TEMPERATURE_MEASUREMENT_FLAGS_TEMPERATURE_UNITS_FLAG    (1 << 0)

/*******************************************************************************************************************//**
 * @brief Time Stamp Flag bit.
 ***********************************************************************************************************************/
#define BLE_HTS_TEMPERATURE_MEASUREMENT_FLAGS_TIME_STAMP_FLAG           (1 << 1)

/*******************************************************************************************************************//**
 * @brief Temperature Type Flag bit.
 ***********************************************************************************************************************/
#define BLE_HTS_TEMPERATURE_MEASUREMENT_FLAGS_TEMPERATURE_TYPE_FLAG     (1 << 2)

/***********************************************************************************************************************
 Typedef definitions
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @brief Health Thermometer Service event data.
 ***********************************************************************************************************************/
typedef struct
{
    uint16_t conn_hdl; /**< Connection handle */
    uint16_t event_param_len; /**< Event parameter length */
    void     *p_event_param; /**< Event parameter */
} st_ble_hts_evt_data_t;

/*******************************************************************************************************************//**
 * @brief Health Thermometer Service event callback.
 ***********************************************************************************************************************/
typedef void (*ble_hts_app_cb_t) (uint16_t type, ble_status_t result, st_ble_hts_evt_data_t *p_data);

/*******************************************************************************************************************//**
 * @brief Health Thermometer Service event type.
 ***********************************************************************************************************************/
typedef enum
{
    BLE_HTS_EVENT_TEMPERATURE_MEASUREMENT_CLI_CNFG_ENABLED, /**< Temperature Measurement characteristic cli cnfg enabled event */
    BLE_HTS_EVENT_TEMPERATURE_MEASUREMENT_CLI_CNFG_DISABLED, /**< Temperature Measurement characteristic cli cnfg disabled event */
    BLE_HTS_EVENT_TEMPERATURE_MEASUREMENT_HDL_VAL_CNF, /**< Temperature Measurement characteristic handle value confiration event */
    BLE_HTS_EVENT_MEASUREMENT_INTERVAL_CLI_CNFG_ENABLED, /**< Measurement Interval characteristic cli cnfg enabled event */
    BLE_HTS_EVENT_MEASUREMENT_INTERVAL_CLI_CNFG_DISABLED, /**< Measurement Interval characteristic cli cnfg disabled event */
    BLE_HTS_EVENT_MEASUREMENT_INTERVAL_HDL_VAL_CNF, /**< Measurement Interval characteristic handle value confiration event */
    BLE_HTS_EVENT_INTERMEDIATE_TEMPERATURE_CLI_CNFG_ENABLED, /**< Intermediate Temperature characteristic cli cnfg enabled event */
    BLE_HTS_EVENT_INTERMEDIATE_TEMPERATURE_CLI_CNFG_DISABLED, /**< Intermediate Temperature characteristic cli cnfg disabled event */
    BLE_HTS_EVENT_MEASUREMENT_INTERVAL_WRITE_REQ, /**< Measurement Interval characteristic write request event */
} e_ble_hts_event_t;

/*******************************************************************************************************************//**
 * @brief Temperature Text Description enumeration.
 ***********************************************************************************************************************/
typedef enum
{
    BLE_HTS_TEMPERATURE_TYPE_ARMPIT                     = 1, /**< Armpit Tempearture */
    BLE_HTS_TEMPERATURE_TYPE_BODY                       = 2, /**< Body (General) Temperature */
    BLE_HTS_TEMPERATURE_TYPE_EAR                        = 3, /**< Ear Lobe Temperature */
    BLE_HTS_TEMPERATURE_TYPE_FINGER                     = 4, /**< Finger Temperature */
    BLE_HTS_TEMPERATURE_TYPE_GASTRO_INTESTINAL_TRACT    = 5, /**< Gastro-intestinal Tract Temperature  */
    BLE_HTS_TEMPERATURE_TYPE_MOUTH                      = 6, /**< Mouth Temperature */
    BLE_HTS_TEMPERATURE_TYPE_RECTUM                     = 7, /**< Rectum Temperature */
    BLE_HTS_TEMPERATURE_TYPE_TOE                        = 8, /**< Toe Temperature */
    BLE_HTS_TEMPERATURE_TYPE_TYMPANUM                   = 9, /**< Tympaunm (Ear Drum) Temperature */
} e_ble_hts_temperature_type_t;

/*******************************************************************************************************************//**
 * @brief Health Thermometer Service initialization parameters.
 ***********************************************************************************************************************/
typedef struct
{
    ble_hts_app_cb_t cb; /**< Health Thermometer Service event callback */
} st_ble_hts_init_param_t;

/*******************************************************************************************************************//**
 * @brief Temperature Measurement characteristic parameters.
 ***********************************************************************************************************************/
typedef struct
{
    bool                         is_temperature_in_fahrenheit; /**< Temperature unit is fahrenheit or celsius */
    bool                         is_timestamp_present; /**< Timestamp present or not */
    bool                         is_temperature_type_present; /**< Temperature type present or not */
    st_ble_ieee11073_float_t     temperature_measurement_value; /**< Temperature Measurement Value value */
    st_ble_date_time_t           time_stamp; /**< Time Stamp value */
    e_ble_hts_temperature_type_t temperature_type; /**< Temperature Type value */
} st_ble_hts_temperature_measurement_t;

/*******************************************************************************************************************//**
 * @brief Intermediate Temperature characteristic parameters.
 ***********************************************************************************************************************/
typedef st_ble_hts_temperature_measurement_t st_ble_hts_intermediate_temperature_t;

/*******************************************************************************************************************//**
 * @brief Measurement Interval Valid Range parameters.
 ***********************************************************************************************************************/
typedef struct
{
    uint16_t lower_inclusive_value;
    uint16_t upper_inclusive_value;
} st_ble_hts_measurement_interval_valid_range_t;

/***********************************************************************************************************************
 Exported global functions (to be accessed by other files)
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @brief     Initialize Health Thermometer Service.
 * @details   This function shall be called once at startup.
 * @param[in] p_param Health Thermometer Service initialization parameters.
 * @return
 ***********************************************************************************************************************/
ble_status_t R_BLE_HTS_Init (st_ble_hts_init_param_t *p_param);

/*******************************************************************************************************************//**
 * @brief     Send Temperature Measurement indication.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] p_app_value Temperature Measurement value to send.
 * @return    @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_HTS_IndicateTemperatureMeasurement (uint16_t conn_hdl,
        st_ble_hts_temperature_measurement_t *p_app_value);

/*******************************************************************************************************************//**
 * @brief      Get Temperature Type characteristic value from local GATT database.
 * @param[out] p_app_value Retrieved Temperature Type characteristic value.
 * @return     @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_HTS_GetTemperatureType (uint8_t *p_app_value);

/*******************************************************************************************************************//**
 * @brief     Set Temperature Type characteristic value to local GATT database.
 * @param[in] app_value Temperature Type characteristic value to set.
 * @return    @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_HTS_SetTemperatureType (uint8_t app_value);

/*******************************************************************************************************************//**
 * @brief     Send Intermediate Temperature notification.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] p_app_value Intermediate Temperature value to send.
 * @return    @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_HTS_NotifyIntermediateTemperature (uint16_t conn_hdl,
        st_ble_hts_intermediate_temperature_t *p_app_value);

/*******************************************************************************************************************//**
 * @brief      Get Measurement Interval characteristic value from local GATT database.
 * @param[out] p_app_value Retrieved Measurement Interval characteristic value.
 * @return     @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_HTS_GetMeasurementInterval (uint16_t *p_app_value);

/*******************************************************************************************************************//**
 * @brief     Set Measurement Interval characteristic value to local GATT database.
 * @param[in] app_value Measurement Interval characteristic value to set.
 * @return    @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_HTS_SetMeasurementInterval (uint16_t app_value);

/*******************************************************************************************************************//**
 * @brief     Get Measurement Interval Valid Range descriptor value from local GATT database.
 * @param[in] p_app_value Measurement Interval Valid Range value to set.
 * @return    @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_HTS_GetMeasurementIntervalValidRange (st_ble_hts_measurement_interval_valid_range_t *p_app_value);

/*******************************************************************************************************************//**
 * @brief     Set Measurement Interval Valid Range descriptor value to local GATT database.
 * @param[in] app_value Measurement Interval Valid Range value to set.
 * @return    @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_HTS_SetMeasurementIntervalValidRange (st_ble_hts_measurement_interval_valid_range_t app_value);

/*******************************************************************************************************************//**
 * @brief     Send Measurement Interval indication.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] app_value Measurement Interval value to send.
 * @return    @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_HTS_IndicateMeasurementInterval (uint16_t conn_hdl, uint16_t app_value);

/*******************************************************************************************************************//**
 * @brief     Return version of the Health Thermometer service.
 * @return    version
***********************************************************************************************************************/
uint32_t R_BLE_HTS_GetVersion(void);

#endif /* R_BLE_HTS_H */

/** @} */
