/***********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
 * SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2018 Renesas Electronics Corporation. All rights reserved.
 ***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_hts.c
 * Version : 1.0
 * Description : This module implements Health Thermometer Service Server
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 30.11.2018 1.00 First Release
 ***********************************************************************************************************************/
/***********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 ***********************************************************************************************************************/
#include <string.h>

#include "r_ble_hts.h"
#include "gatt_db.h"

/* Version number */
#define BLE_HTS_PRV_VERSION_MAJOR                                      (1)
#define BLE_HTS_PRV_VERSION_MINOR                                      (0)

/***********************************************************************************************************************
 Private global variables and functions
 ***********************************************************************************************************************/
static ble_hts_app_cb_t gs_hts_cb;

/***********************************************************************************************************************
 * Function Name: set_cli_cnfg
 * Description  : Set Characteristic value notification configuration in local GATT database.
 * Arguments    : conn_hdl - handle to connection.
 *                attr_hadl - handle to the attribute
 *                cli_cnfg - configuration value
 * Return Value : none
 **********************************************************************************************************************/
static void set_cli_cnfg (uint16_t conn_hdl, uint16_t attr_hdl, uint16_t cli_cnfg)
{
    uint8_t data[2];

    BT_PACK_LE_2_BYTE(data, &cli_cnfg);

    st_ble_gatt_value_t gatt_value =
    {
            .p_value    = data,
            .value_len  = 2,
    };
    ble_status_t result;
    result =
    R_BLE_GATTS_SetAttr(conn_hdl, attr_hdl, &gatt_value);
}

/***********************************************************************************************************************
 * Function Name: get_cli_cnfg
 * Description  : Get Characteristic value notification configuration from local GATT database.
 * Arguments    : conn_hdl - handle to connection.
 *                attr_hadl - handle to the attribute
 *                p_cli_cnfg - pointer to variable to store configuration value
 * Return Value : none
 **********************************************************************************************************************/
static void get_cli_cnfg (uint16_t conn_hdl, uint16_t attr_hdl, uint16_t *p_cli_cnfg)
{
    st_ble_gatt_value_t gatt_value;
    
    ble_status_t result;
    result = R_BLE_GATTS_GetAttr(conn_hdl, attr_hdl, &gatt_value);

    BT_UNPACK_LE_2_BYTE(p_cli_cnfg, gatt_value.p_value);

}

/***********************************************************************************************************************
 * Function Name: a2b_temperature_measurement
 * Description  : This function converts temperature measurement characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the temperature measurement value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : none
 **********************************************************************************************************************/
static void a2b_temperature_measurement (st_ble_hts_temperature_measurement_t *p_app_value,
        st_ble_gatt_value_t *p_gatt_value)
{
    /* Convert application data to byte sequence. */
    uint8_t pos = 1;

    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    /* Temperature Units Flag */
    if (p_app_value->is_temperature_in_fahrenheit)
    {
        p_gatt_value->p_value[0] |= BLE_HTS_TEMPERATURE_MEASUREMENT_FLAGS_TEMPERATURE_UNITS_FLAG;
    }

    uint32_t temperature_measurement_value = ((p_app_value->temperature_measurement_value.exponent << 24) & 0xFF000000)
            | ((p_app_value->temperature_measurement_value.mantissa << 0) & 0x00FFFFFF);

    BT_PACK_LE_4_BYTE( &p_gatt_value->p_value[pos], &temperature_measurement_value);
    pos += (sizeof(temperature_measurement_value));

    /* Time stamp flag */
    if (p_app_value->is_timestamp_present)
    {
        p_gatt_value->p_value[0] |= BLE_HTS_TEMPERATURE_MEASUREMENT_FLAGS_TIME_STAMP_FLAG;

        BT_PACK_LE_2_BYTE( &p_gatt_value->p_value[pos], &(p_app_value->time_stamp.year));
        pos += (sizeof(p_app_value->time_stamp.year));

        BT_PACK_LE_1_BYTE( &p_gatt_value->p_value[pos++], &(p_app_value->time_stamp.month));
        BT_PACK_LE_1_BYTE( &p_gatt_value->p_value[pos++], &(p_app_value->time_stamp.day));
        BT_PACK_LE_1_BYTE( &p_gatt_value->p_value[pos++], &(p_app_value->time_stamp.hours));
        BT_PACK_LE_1_BYTE( &p_gatt_value->p_value[pos++], &(p_app_value->time_stamp.minutes));
        BT_PACK_LE_1_BYTE( &p_gatt_value->p_value[pos++], &(p_app_value->time_stamp.seconds));
    }

    /* Temperature Type Present flag */
    if (p_app_value->is_temperature_type_present)
    {
        p_gatt_value->p_value[0] |= BLE_HTS_TEMPERATURE_MEASUREMENT_FLAGS_TEMPERATURE_TYPE_FLAG;
        BT_PACK_LE_1_BYTE( &p_gatt_value->p_value[pos++], (uint8_t * )( &(p_app_value->temperature_type)));
    }

    /* Update the length */
    p_gatt_value->value_len = pos;
}

/***********************************************************************************************************************
 * Function Name: a2b_intermediate_temperature
 * Description  : This function converts intermediate temperature characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the intermediate temperature value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : none
 **********************************************************************************************************************/
static void a2b_intermediate_temperature (st_ble_hts_intermediate_temperature_t *p_app_value,
        st_ble_gatt_value_t *p_gatt_value)
{
    /* Convert application data to byte sequence. */
    uint8_t pos = 1;

    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    /* Temperature Units Flag */
    if (p_app_value->is_temperature_in_fahrenheit)
    {
        p_gatt_value->p_value[0] |= BLE_HTS_TEMPERATURE_MEASUREMENT_FLAGS_TEMPERATURE_UNITS_FLAG;
    }

    uint32_t intermediate_temperature_value = ((p_app_value->temperature_measurement_value.exponent << 24) & 0xFF000000)
            | ((p_app_value->temperature_measurement_value.mantissa << 0) & 0x00FFFFFF);

    BT_PACK_LE_4_BYTE( &(p_gatt_value->p_value[pos]), &intermediate_temperature_value);
    pos += (sizeof(intermediate_temperature_value));

    /* Time stamp flag */
    if (p_app_value->is_timestamp_present)
    {
        p_gatt_value->p_value[0] |= BLE_HTS_TEMPERATURE_MEASUREMENT_FLAGS_TIME_STAMP_FLAG;

        BT_PACK_LE_2_BYTE( &(p_gatt_value->p_value[pos]), &(p_app_value->time_stamp.year));
        pos += (sizeof(p_app_value->time_stamp.year));

        BT_PACK_LE_1_BYTE( &(p_gatt_value->p_value[pos++]), &(p_app_value->time_stamp.month));
        BT_PACK_LE_1_BYTE( &(p_gatt_value->p_value[pos++]), &(p_app_value->time_stamp.day));
        BT_PACK_LE_1_BYTE( &(p_gatt_value->p_value[pos++]), &(p_app_value->time_stamp.hours));
        BT_PACK_LE_1_BYTE( &(p_gatt_value->p_value[pos++]), &(p_app_value->time_stamp.minutes));
        BT_PACK_LE_1_BYTE( &(p_gatt_value->p_value[pos++]), &(p_app_value->time_stamp.seconds));
    }

    /* Temperature Type Present flag */
    if (p_app_value->is_temperature_type_present)
    {
        p_gatt_value->p_value[0] |= BLE_HTS_TEMPERATURE_MEASUREMENT_FLAGS_TEMPERATURE_TYPE_FLAG;
        BT_PACK_LE_1_BYTE( &(p_gatt_value->p_value[pos++]), (uint8_t * )( &(p_app_value->temperature_type)));
    }

    /* Update the length */
    p_gatt_value->value_len = pos;
}

/***********************************************************************************************************************
 * Function Name: evt_write_req_measurement_interval
 * Description  : This function handles the measurement interval characteristic write request event.
 * Arguments    : conn_hdl - connection handle
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : none
 **********************************************************************************************************************/
static void evt_write_req_measurement_interval (uint16_t conn_hdl, st_ble_gatt_value_t *p_gatt_value)
{
    uint16_t                                        req_interval;
    st_ble_hts_measurement_interval_valid_range_t   valid_range   = { 0,0 };

    BT_UNPACK_LE_2_BYTE( &req_interval, p_gatt_value->p_value);

    /* Read the measurement Interval Valid Range */
    R_BLE_HTS_GetMeasurementIntervalValidRange(&valid_range);

    /* Check if the value is in the valid range */
    if (((req_interval >= valid_range.lower_inclusive_value) && (req_interval <= valid_range.upper_inclusive_value))
        || (0 == req_interval))
    {
        st_ble_hts_evt_data_t evt_data =
        {
                .conn_hdl           = conn_hdl,
                .event_param_len    = sizeof(req_interval),
                .p_event_param      = &req_interval,
        };

        gs_hts_cb(BLE_HTS_EVENT_MEASUREMENT_INTERVAL_WRITE_REQ, BLE_SUCCESS, &evt_data);
    }
    else
    {
        R_BLE_GATTS_SendErrRsp(BLE_HTS_OUT_OF_RANGE);
    }
}

/***********************************************************************************************************************
 * Function Name: a2b_measurement_interval_valid_range
 * Description  : This function converts measurement interval valid range descriptor value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the valid range value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : none
 **********************************************************************************************************************/
static void a2b_measurement_interval_valid_range (st_ble_hts_measurement_interval_valid_range_t *p_app_value,
        st_ble_gatt_value_t *p_gatt_value)
{
    BT_PACK_LE_2_BYTE( &p_gatt_value->p_value[0], &p_app_value->lower_inclusive_value);
    BT_PACK_LE_2_BYTE( &p_gatt_value->p_value[2], &p_app_value->upper_inclusive_value);
}

/***********************************************************************************************************************
 * Function Name: b2a_measurement_interval_valid_range
 * Description  : This function converts measurement interval valid range descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the valid range value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : none
 **********************************************************************************************************************/
static void b2a_measurement_interval_valid_range (st_ble_hts_measurement_interval_valid_range_t *p_app_value,
        st_ble_gatt_value_t *p_gatt_value)
{
    BT_UNPACK_LE_2_BYTE( &p_app_value->lower_inclusive_value, &p_gatt_value->p_value[0]);
    BT_UNPACK_LE_2_BYTE( &p_app_value->upper_inclusive_value, &p_gatt_value->p_value[2]);
}

/***********************************************************************************************************************
 * Function Name: hts_gatt_db_cb
 * Description  : Callback function for the Health Thermometer Service GATT Server events.
 * Arguments    : conn_hdl - handle to the connection
 *                p_params - pointer to GATTS db parameter
 * Return Value : none
 **********************************************************************************************************************/
static void hts_gatt_db_cb (uint16_t conn_hdl, uint8_t db_op, uint16_t attr_hdl, st_ble_gatt_value_t *p_params)
{
    switch (db_op)
    {
        case BLE_GATTS_OP_CHAR_PEER_READ_REQ:
        {
            /* Do nothing. */
        }

        break;

        case BLE_GATTS_OP_CHAR_PEER_WRITE_REQ:
        {
            if (BLE_HTS_MEASUREMENT_INTERVAL_VAL_HDL == attr_hdl)
            {
                evt_write_req_measurement_interval(conn_hdl, p_params);
            }
        }
        break;

        case BLE_GATTS_OP_CHAR_PEER_CLI_CNFG_WRITE_REQ:
        {
            uint16_t cli_cnfg;

            BT_UNPACK_LE_2_BYTE( &cli_cnfg, p_params->p_value);

            if (BLE_HTS_TEMPERATURE_MEASUREMENT_CLI_CNFG_DESC_HDL == attr_hdl)
            {
                st_ble_hts_evt_data_t evt_data =
                {
                        .conn_hdl           = conn_hdl,
                        .event_param_len    = 0,
                        .p_event_param      = NULL,
                };

                if (BLE_GATTS_CLI_CNFG_INDICATION == cli_cnfg)
                {
                    gs_hts_cb(BLE_HTS_EVENT_TEMPERATURE_MEASUREMENT_CLI_CNFG_ENABLED, BLE_SUCCESS, &evt_data);
                }
                else
                {
                    gs_hts_cb(BLE_HTS_EVENT_TEMPERATURE_MEASUREMENT_CLI_CNFG_DISABLED, BLE_SUCCESS, &evt_data);
                }
            }
            else if (BLE_HTS_INTERMEDIATE_TEMPERATURE_CLI_CNFG_DESC_HDL == attr_hdl)
            {
                st_ble_hts_evt_data_t evt_data =
                {
                        .conn_hdl           = conn_hdl,
                        .event_param_len    = 0,
                        .p_event_param      = NULL,
                };

                if (BLE_GATTS_CLI_CNFG_NOTIFICATION == cli_cnfg)
                {
                    gs_hts_cb(BLE_HTS_EVENT_INTERMEDIATE_TEMPERATURE_CLI_CNFG_ENABLED, BLE_SUCCESS, &evt_data);
                }
                else
                {
                    gs_hts_cb(BLE_HTS_EVENT_INTERMEDIATE_TEMPERATURE_CLI_CNFG_DISABLED, BLE_SUCCESS, &evt_data);
                }
            }
            else if (BLE_HTS_MEASUREMENT_INTERVAL_CLI_CNFG_DESC_HDL == attr_hdl)
            {
                st_ble_hts_evt_data_t evt_data =
                {
                        .conn_hdl           = conn_hdl,
                        .event_param_len    = 0,
                        .p_event_param      = NULL,
                };

                if (BLE_GATTS_CLI_CNFG_INDICATION == cli_cnfg)
                {
                    gs_hts_cb(BLE_HTS_EVENT_MEASUREMENT_INTERVAL_CLI_CNFG_ENABLED, BLE_SUCCESS, &evt_data);
                }
                else
                {
                    gs_hts_cb(BLE_HTS_EVENT_MEASUREMENT_INTERVAL_CLI_CNFG_DISABLED, BLE_SUCCESS, &evt_data);
                }
            }
        }
        break;

        default:
        {
            /* Do nothing. */
        }
        break;
    }
}

/***********************************************************************************************************************
 * Function Name: hts_gatts_cb
 * Description  : Callback function for the GATT Server events.
 * Arguments    : type - event id
 *                result - ble status
 *                p_data - pointer to the event data
 * Return Value : none
 **********************************************************************************************************************/
static void hts_gatts_cb (uint16_t type, ble_status_t result, st_ble_gatts_evt_data_t *p_data)
{
    switch (type)
    {
        case BLE_GATTS_EVENT_DB_ACCESS_IND:
        {
            /* Type casting to st_ble_gatt_db_access_evt_param_t */
            st_ble_gatts_db_access_evt_t *p_db_access_evt_param =
                    (st_ble_gatts_db_access_evt_t *) p_data->p_param;

            hts_gatt_db_cb(p_data->conn_hdl,
                           p_db_access_evt_param->p_params->db_op,
                           p_db_access_evt_param->p_params->attr_hdl,
                           &p_db_access_evt_param->p_params->value);
        }
        break;

        case BLE_GATTS_EVENT_HDL_VAL_CNF:
        {
            /* Type casting to st_ble_gatt_cfm_evt_param_t */
            st_ble_gatts_cfm_evt_t *p_cfm_evt_param = (st_ble_gatts_cfm_evt_t *) p_data->p_param;

            if (BLE_HTS_TEMPERATURE_MEASUREMENT_VAL_HDL == p_cfm_evt_param->attr_hdl)
            {
                st_ble_hts_evt_data_t evt_data =
                {
                        .conn_hdl           = p_data->conn_hdl,
                        .event_param_len    = 0,
                        .p_event_param      = NULL,
                };

                gs_hts_cb(BLE_HTS_EVENT_TEMPERATURE_MEASUREMENT_HDL_VAL_CNF, result, &evt_data);
            }

            if (BLE_HTS_MEASUREMENT_INTERVAL_VAL_HDL == p_cfm_evt_param->attr_hdl)
            {
                st_ble_hts_evt_data_t evt_data =
                {
                        .conn_hdl           = p_data->conn_hdl,
                        .event_param_len    = 0,
                        .p_event_param      = NULL,
                };

                gs_hts_cb(BLE_HTS_EVENT_MEASUREMENT_INTERVAL_HDL_VAL_CNF, result, &evt_data);
            }
        }

        break;

        default:
        {
            /* Do nothing. */
        }

        break;
    }
}

ble_status_t R_BLE_HTS_Init (st_ble_hts_init_param_t *p_param) // @suppress("API function naming")
{
    if (NULL == p_param)
    {
        return BLE_ERR_INVALID_PTR;
    }

    if (NULL == p_param->cb)
    {
        return BLE_ERR_INVALID_ARG;
    }

    R_BLE_GATTS_RegisterCb(hts_gatts_cb, 3);

    gs_hts_cb = p_param->cb;

    return BLE_SUCCESS;
}

ble_status_t R_BLE_HTS_IndicateTemperatureMeasurement (uint16_t conn_hdl,
        st_ble_hts_temperature_measurement_t *p_app_value) // @suppress("API function naming")
{
    uint16_t        cli_cnfg;
    ble_status_t    ret;

    get_cli_cnfg(conn_hdl, BLE_HTS_TEMPERATURE_MEASUREMENT_CLI_CNFG_DESC_HDL, &cli_cnfg);

    if (cli_cnfg & BLE_GATTS_CLI_CNFG_INDICATION)
    {
        uint8_t byte_value[BLE_HTS_TEMPERATURE_MEASUREMENT_LEN] = { 0 };

        st_ble_gatt_hdl_value_pair_t ind_data =
        {
                .attr_hdl           = BLE_HTS_TEMPERATURE_MEASUREMENT_VAL_HDL,
                .value.p_value        = byte_value,
                .value.value_len    = BLE_HTS_TEMPERATURE_MEASUREMENT_LEN,
        };

        a2b_temperature_measurement(p_app_value, &ind_data.value);

        ret = R_BLE_GATTS_Indication(conn_hdl, &ind_data);
    }
    else
    {
        ret = BLE_ERR_INVALID_STATE;
    }

    return ret;
}

ble_status_t R_BLE_HTS_GetTemperatureType (uint8_t *p_app_value) // @suppress("API function naming")
{
    st_ble_gatt_value_t gatt_value;
    ble_status_t        ret;

    ret = R_BLE_GATTS_GetAttr(BLE_GAP_INVALID_CONN_HDL, BLE_HTS_TEMPERATURE_TYPE_VAL_HDL, &gatt_value);

    if (BLE_SUCCESS == ret)
    {
        BT_UNPACK_LE_1_BYTE(p_app_value, gatt_value.p_value);
    }

    return ret;
}

ble_status_t R_BLE_HTS_SetTemperatureType (uint8_t app_value) // @suppress("API function naming")
{
    uint8_t byte_value[BLE_HTS_TEMPERATURE_TYPE_LEN] = { 0 };

    BT_PACK_LE_1_BYTE(byte_value, &app_value);

    st_ble_gatt_value_t gatt_value =
    {
            .p_value      = byte_value,
            .value_len  = sizeof(app_value),
    };

    return R_BLE_GATTS_SetAttr(BLE_GAP_INVALID_CONN_HDL, BLE_HTS_TEMPERATURE_TYPE_VAL_HDL, &gatt_value);
}

ble_status_t R_BLE_HTS_NotifyIntermediateTemperature (uint16_t conn_hdl,
        st_ble_hts_intermediate_temperature_t *p_app_value) // @suppress("API function naming")
{
    uint16_t        cli_cnfg;
    ble_status_t    ret;

    get_cli_cnfg(conn_hdl, BLE_HTS_INTERMEDIATE_TEMPERATURE_CLI_CNFG_DESC_HDL, &cli_cnfg);

    if (cli_cnfg & BLE_GATTS_CLI_CNFG_NOTIFICATION)
    {
        uint8_t byte_value[BLE_HTS_INTERMEDIATE_TEMPERATURE_LEN] = { 0 };

        st_ble_gatt_hdl_value_pair_t ntf_data =
        {
                .attr_hdl           = BLE_HTS_INTERMEDIATE_TEMPERATURE_VAL_HDL,
                .value.p_value        = byte_value,
                .value.value_len    = BLE_HTS_INTERMEDIATE_TEMPERATURE_LEN,
        };

        a2b_intermediate_temperature(p_app_value, &ntf_data.value);

        ret = R_BLE_GATTS_Notification(conn_hdl, &ntf_data);
    }
    else
    {
        ret = BLE_ERR_INVALID_STATE;
    }

    return ret;
}

ble_status_t R_BLE_HTS_GetMeasurementInterval (uint16_t *p_app_value) // @suppress("API function naming")
{
    st_ble_gatt_value_t gatt_value;
    ble_status_t        ret;

    ret = R_BLE_GATTS_GetAttr(BLE_GAP_INVALID_CONN_HDL, BLE_HTS_MEASUREMENT_INTERVAL_VAL_HDL, &gatt_value);

    if (BLE_SUCCESS == ret)
    {
        BT_UNPACK_LE_2_BYTE( &p_app_value, gatt_value.p_value);
    }

    return ret;
}

ble_status_t R_BLE_HTS_SetMeasurementInterval (uint16_t app_value) // @suppress("API function naming")
{
    uint8_t byte_value[BLE_HTS_MEASUREMENT_INTERVAL_LEN] = { 0 };

    BT_PACK_LE_2_BYTE(byte_value, &app_value);

    st_ble_gatt_value_t gatt_value =
    {
            .p_value      = byte_value,
            .value_len  = sizeof(app_value),
    };

    return R_BLE_GATTS_SetAttr(BLE_GAP_INVALID_CONN_HDL, BLE_HTS_MEASUREMENT_INTERVAL_VAL_HDL, &gatt_value);
}

ble_status_t R_BLE_HTS_GetMeasurementIntervalValidRange (st_ble_hts_measurement_interval_valid_range_t *p_app_value)
{
    st_ble_gatt_value_t gatt_value;
    ble_status_t        ret;

    ret = R_BLE_GATTS_GetAttr(BLE_GAP_INVALID_CONN_HDL, BLE_HTS_MEASUREMENT_INTERVAL_VALID_RANGE_DESC_HDL, &gatt_value);

    if (BLE_SUCCESS == ret)
    {
        b2a_measurement_interval_valid_range(p_app_value, &gatt_value);
    }

    return ret;
}

ble_status_t R_BLE_HTS_SetMeasurementIntervalValidRange (st_ble_hts_measurement_interval_valid_range_t app_value)
{
    uint8_t byte_value[BLE_HTS_MEASUREMENT_INTERVAL_VALID_RANGE_LEN] = { 0 };

    st_ble_gatt_value_t gatt_value =
    {
            .p_value      = byte_value,
            .value_len  = sizeof(app_value),
    };

    a2b_measurement_interval_valid_range( &app_value, &gatt_value);

    return R_BLE_GATTS_SetAttr(BLE_GAP_INVALID_CONN_HDL, BLE_HTS_MEASUREMENT_INTERVAL_VALID_RANGE_DESC_HDL, &gatt_value);
}

ble_status_t R_BLE_HTS_IndicateMeasurementInterval (uint16_t conn_hdl, uint16_t app_value) // @suppress("API function naming")
{
    uint16_t        cli_cnfg;
    ble_status_t    ret;

    get_cli_cnfg(conn_hdl, BLE_HTS_MEASUREMENT_INTERVAL_CLI_CNFG_DESC_HDL, &cli_cnfg);

    if (cli_cnfg & BLE_GATTS_CLI_CNFG_INDICATION)
    {
        uint8_t byte_value[BLE_HTS_MEASUREMENT_INTERVAL_LEN] = { 0 };

        BT_PACK_LE_2_BYTE(byte_value, &app_value);

        st_ble_gatt_hdl_value_pair_t ind_data =
        {
                .attr_hdl           = BLE_HTS_MEASUREMENT_INTERVAL_VAL_HDL,
                .value.p_value        = byte_value,
                .value.value_len    = sizeof(app_value),
        };

        ret = R_BLE_GATTS_Indication(conn_hdl, &ind_data);
    }
    else
    {
        ret = BLE_ERR_INVALID_STATE;
    }

    return ret;
}

uint32_t R_BLE_HTS_GetVersion (void) // @suppress("API function naming")
{
    uint32_t version;

    version = ((BLE_HTS_PRV_VERSION_MAJOR << 16) | (BLE_HTS_PRV_VERSION_MINOR << 8));

    return version;
}
