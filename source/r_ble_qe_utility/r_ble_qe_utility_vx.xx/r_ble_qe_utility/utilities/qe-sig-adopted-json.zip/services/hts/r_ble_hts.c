/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_hts.c
 * Version : 1.0
 * Description : The source file for Health Thermometer Service service.
 **********************************************************************************************************************/

#include "r_ble_hts.h"
#include "profile_cmn/r_ble_servs_if.h"
#include "gatt_db.h"

#ifndef UNUSED_ARG
#define UNUSED_ARG(arg)         (void)(arg)
#endif /* UNUSED_ARG */

static st_ble_servs_info_t gs_servs_info;

/*----------------------------------------------------------------------------------------------------------------------
    Temperature Measurement Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

static const st_ble_servs_desc_info_t gs_temp_meas_cli_cnfg = {
    .attr_hdl = BLE_HTS_TEMP_MEAS_CLI_CNFG_DESC_HDL,
    .app_size = sizeof(uint16_t),
    .desc_idx = BLE_HTS_TEMP_MEAS_CLI_CNFG_IDX,
    .db_size  = BLE_HTS_TEMP_MEAS_CLI_CNFG_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_uint16_t,
    .encode   = (ble_servs_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_HTS_SetTempMeasCliCnfg(uint16_t conn_hdl, const uint16_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_temp_meas_cli_cnfg, conn_hdl, (const void *)p_value);
}

ble_status_t R_BLE_HTS_GetTempMeasCliCnfg(uint16_t conn_hdl, uint16_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_temp_meas_cli_cnfg, conn_hdl, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Temperature Measurement characteristic
----------------------------------------------------------------------------------------------------------------------*/

static ble_status_t decode_st_ble_hts_temp_meas_t(st_ble_hts_temp_meas_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;

    p_app_value->flags.temperature_units_flag = p_gatt_value->p_value[pos] & 0x01;
    p_app_value->flags.time_stamp_flag = (p_gatt_value->p_value[pos] >> 1) & 0x01;
    p_app_value->flags.temperature_type_flag = (p_gatt_value->p_value[pos] >> 2) & 0x01;
    pos++;

    BT_UNPACK_LE_3_BYTE(&p_app_value->temperature_measurement_value.mantissa, &p_gatt_value->p_value[pos]);
    pos += 3;
    BT_UNPACK_LE_1_BYTE(&p_app_value->temperature_measurement_value.exponent, &p_gatt_value->p_value[pos]);
    pos++;

    if(true == p_app_value->flags.time_stamp_flag)
    {
        unpack_st_ble_date_time_t(&p_app_value->time_stamp, &p_gatt_value->p_value[pos]);
        pos += 7;
    }

    if(true == p_app_value->flags.temperature_type_flag)
    {
        BT_UNPACK_LE_1_BYTE(&p_app_value->temperature_type, &p_gatt_value->p_value[pos]);
        pos++;
    }

    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_hts_temp_meas_t(const st_ble_hts_temp_meas_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;

    p_gatt_value->p_value[pos] = (uint8_t)((p_app_value->flags.temperature_units_flag & 0x01) |
                                 ((p_app_value->flags.time_stamp_flag & 0x01) << 1) |
                                 ((p_app_value->flags.temperature_type_flag & 0x01) << 2));
    pos++;

    BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], &p_app_value->temperature_measurement_value.mantissa);
    pos += 3;
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->temperature_measurement_value.exponent);
    pos++;

    if(true == p_app_value->flags.time_stamp_flag)
    {
        pack_st_ble_date_time_t(&p_gatt_value->p_value[pos], &p_app_value->time_stamp);
        pos += 7;
    }

    if(true == p_app_value->flags.temperature_type_flag)
    {
        BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->temperature_type);
        pos++;
    }

    p_gatt_value->value_len = (uint16_t)pos;
    return BLE_SUCCESS;
}

/* Temperature Measurement characteristic descriptor definition */
static const st_ble_servs_desc_info_t *gspp_temp_meas_descs[] = {
    &gs_temp_meas_cli_cnfg,
};

/* Temperature Measurement characteristic definition */
static const st_ble_servs_char_info_t gs_temp_meas_char = {
    .start_hdl    = BLE_HTS_TEMP_MEAS_DECL_HDL,
    .end_hdl      = BLE_HTS_TEMP_MEAS_CLI_CNFG_DESC_HDL,
    .char_idx     = BLE_HTS_TEMP_MEAS_IDX,
    .app_size     = sizeof(st_ble_hts_temp_meas_t),
    .db_size      = BLE_HTS_TEMP_MEAS_LEN,
    .decode       = (ble_servs_attr_decode_t)decode_st_ble_hts_temp_meas_t,
    .encode       = (ble_servs_attr_encode_t)encode_st_ble_hts_temp_meas_t,
    .pp_descs     = gspp_temp_meas_descs,
    .num_of_descs = ARRAY_SIZE(gspp_temp_meas_descs),
};

ble_status_t R_BLE_HTS_IndicateTempMeas(uint16_t conn_hdl, const st_ble_hts_temp_meas_t *p_value)
{
    return R_BLE_SERVS_SendHdlVal(&gs_temp_meas_char, conn_hdl, (const void *)p_value, false);
}

/*----------------------------------------------------------------------------------------------------------------------
    Temperature Type characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Temperature Type characteristic definition */
static const st_ble_servs_char_info_t gs_temp_type_char = {
    .start_hdl    = BLE_HTS_TEMP_TYPE_DECL_HDL,
    .end_hdl      = BLE_HTS_TEMP_TYPE_VAL_HDL,
    .char_idx     = BLE_HTS_TEMP_TYPE_IDX,
    .app_size     = sizeof(uint8_t),
    .db_size      = BLE_HTS_TEMP_TYPE_LEN,
    .decode       = (ble_servs_attr_decode_t)decode_uint8_t,
    .encode       = (ble_servs_attr_encode_t)encode_uint8_t,
};

ble_status_t R_BLE_HTS_SetTempType(const uint8_t *p_value)
{
    return R_BLE_SERVS_SetChar(&gs_temp_type_char, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_HTS_GetTempType(uint8_t *p_value)
{
    return R_BLE_SERVS_GetChar(&gs_temp_type_char, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Intermediate Temperature Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

static const st_ble_servs_desc_info_t gs_intermediate_temperature_cli_cnfg = {
    .attr_hdl = BLE_HTS_INTERMEDIATE_TEMPERATURE_CLI_CNFG_DESC_HDL,
    .app_size = sizeof(uint16_t),
    .desc_idx = BLE_HTS_INTERMEDIATE_TEMPERATURE_CLI_CNFG_IDX,
    .db_size  = BLE_HTS_INTERMEDIATE_TEMPERATURE_CLI_CNFG_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_uint16_t,
    .encode   = (ble_servs_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_HTS_SetIntermediateTemperatureCliCnfg(uint16_t conn_hdl, const uint16_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_intermediate_temperature_cli_cnfg, conn_hdl, (const void *)p_value);
}

ble_status_t R_BLE_HTS_GetIntermediateTemperatureCliCnfg(uint16_t conn_hdl, uint16_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_intermediate_temperature_cli_cnfg, conn_hdl, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Intermediate Temperature characteristic
----------------------------------------------------------------------------------------------------------------------*/

static ble_status_t decode_st_ble_hts_intermediate_temperature_t(st_ble_hts_intermediate_temperature_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    decode_st_ble_hts_temp_meas_t(&p_app_value->temp_meas, p_gatt_value);
    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_hts_intermediate_temperature_t(const st_ble_hts_intermediate_temperature_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    encode_st_ble_hts_temp_meas_t(&p_app_value->temp_meas, p_gatt_value);
    return BLE_SUCCESS;
}

/* Intermediate Temperature characteristic descriptor definition */
static const st_ble_servs_desc_info_t *gspp_intermediate_temperature_descs[] = {
    &gs_intermediate_temperature_cli_cnfg,
};

/* Intermediate Temperature characteristic definition */
static const st_ble_servs_char_info_t gs_intermediate_temperature_char = {
    .start_hdl    = BLE_HTS_INTERMEDIATE_TEMPERATURE_DECL_HDL,
    .end_hdl      = BLE_HTS_INTERMEDIATE_TEMPERATURE_CLI_CNFG_DESC_HDL,
    .char_idx     = BLE_HTS_INTERMEDIATE_TEMPERATURE_IDX,
    .app_size     = sizeof(st_ble_hts_intermediate_temperature_t),
    .db_size      = BLE_HTS_INTERMEDIATE_TEMPERATURE_LEN,
    .decode       = (ble_servs_attr_decode_t)decode_st_ble_hts_intermediate_temperature_t,
    .encode       = (ble_servs_attr_encode_t)encode_st_ble_hts_intermediate_temperature_t,
    .pp_descs     = gspp_intermediate_temperature_descs,
    .num_of_descs = ARRAY_SIZE(gspp_intermediate_temperature_descs),
};

ble_status_t R_BLE_HTS_NotifyIntermediateTemperature(uint16_t conn_hdl, const st_ble_hts_intermediate_temperature_t *p_value)
{
    return R_BLE_SERVS_SendHdlVal(&gs_intermediate_temperature_char, conn_hdl, (const void *)p_value, true);
}

/*----------------------------------------------------------------------------------------------------------------------
    Measurement Interval Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

static const st_ble_servs_desc_info_t gs_meas_interval_cli_cnfg = {
    .attr_hdl = BLE_HTS_MEAS_INTERVAL_CLI_CNFG_DESC_HDL,
    .app_size = sizeof(uint16_t),
    .desc_idx = BLE_HTS_MEAS_INTERVAL_CLI_CNFG_IDX,
    .db_size  = BLE_HTS_MEAS_INTERVAL_CLI_CNFG_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_uint16_t,
    .encode   = (ble_servs_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_HTS_SetMeasIntervalCliCnfg(uint16_t conn_hdl, const uint16_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_meas_interval_cli_cnfg, conn_hdl, (const void *)p_value);
}

ble_status_t R_BLE_HTS_GetMeasIntervalCliCnfg(uint16_t conn_hdl, uint16_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_meas_interval_cli_cnfg, conn_hdl, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Measurement Interval Valid Range descriptor
----------------------------------------------------------------------------------------------------------------------*/

static ble_status_t decode_st_ble_meas_interval_valid_range_t(st_ble_meas_interval_valid_range_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;

    BT_UNPACK_LE_2_BYTE(&p_app_value->lower_inclusive_value, &p_gatt_value->p_value[pos]);
    pos += 2;

    BT_UNPACK_LE_2_BYTE(&p_app_value->upper_inclusive_value, &p_gatt_value->p_value[pos]);
    pos += 2;

    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_meas_interval_valid_range_t(const st_ble_meas_interval_valid_range_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->lower_inclusive_value);
    pos += 2;

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->upper_inclusive_value);
    pos += 2;

    p_gatt_value->value_len = (uint16_t)pos;

    return BLE_SUCCESS;
}

static const st_ble_servs_desc_info_t gs_meas_interval_valid_range = {
    .attr_hdl = BLE_HTS_MEAS_INTERVAL_VALID_RANGE_DESC_HDL,
    .app_size = sizeof(st_ble_meas_interval_valid_range_t),
    .desc_idx = BLE_HTS_MEAS_INTERVAL_VALID_RANGE_IDX,
    .db_size  = BLE_HTS_MEAS_INTERVAL_VALID_RANGE_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_st_ble_meas_interval_valid_range_t,
    .encode   = (ble_servs_attr_encode_t)encode_st_ble_meas_interval_valid_range_t,
};

ble_status_t R_BLE_HTS_SetMeasIntervalValidRange(const st_ble_meas_interval_valid_range_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_meas_interval_valid_range, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_HTS_GetMeasIntervalValidRange(st_ble_meas_interval_valid_range_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_meas_interval_valid_range, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Measurement Interval characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Measurement Interval characteristic descriptor definition */
static const st_ble_servs_desc_info_t *gspp_meas_interval_descs[] = {
    &gs_meas_interval_cli_cnfg,
    &gs_meas_interval_valid_range,
};

static void meas_interval_write_req(const void *p_attr, uint16_t conn_hdl, ble_status_t result, const void *p_app_value)
{
    UNUSED_ARG(p_attr);
    UNUSED_ARG(result);

    ble_status_t ret;
    st_ble_gap_auth_info_t p_sec_info;
    st_ble_meas_interval_valid_range_t valid_range;

    uint16_t meas_interval = *(uint16_t *)p_app_value;

    ret = R_BLE_GAP_GetDevSecInfo(conn_hdl, &p_sec_info);
    if((BLE_ERR_INVALID_STATE == ret) || (BLE_ERR_INVALID_HDL == ret) ||
       (0x02 == p_sec_info.security))
        {
            R_BLE_GATTS_SendErrRsp(BLE_ERR_GATT_INSUFFICIENT_AUTHENTICATION);
            return;
        }


    R_BLE_HTS_GetMeasIntervalValidRange(&valid_range);
    if((meas_interval != 0) && 
      ((meas_interval < valid_range.lower_inclusive_value) || 
       (valid_range.upper_inclusive_value < meas_interval)))
        {
            R_BLE_GATTS_SendErrRsp(BLE_HTS_OUT_OF_RANGE_ERROR);
            return;
        }

    return;
}

/* Measurement Interval characteristic definition */
static const st_ble_servs_char_info_t gs_meas_interval_char = {
    .start_hdl    = BLE_HTS_MEAS_INTERVAL_DECL_HDL,
    .end_hdl      = BLE_HTS_MEAS_INTERVAL_VALID_RANGE_DESC_HDL,
    .char_idx     = BLE_HTS_MEAS_INTERVAL_IDX,
    .app_size     = sizeof(uint16_t),
    .db_size      = BLE_HTS_MEAS_INTERVAL_LEN,
    .decode       = (ble_servs_attr_decode_t)decode_uint16_t,
    .encode       = (ble_servs_attr_encode_t)encode_uint16_t,
    .pp_descs     = gspp_meas_interval_descs,
    .num_of_descs = ARRAY_SIZE(gspp_meas_interval_descs),
    .write_req_cb = (ble_servs_attr_write_req_t)meas_interval_write_req,
};

ble_status_t R_BLE_HTS_SetMeasInterval(const uint16_t *p_value)
{
    return R_BLE_SERVS_SetChar(&gs_meas_interval_char, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_HTS_GetMeasInterval(uint16_t *p_value)
{
    return R_BLE_SERVS_GetChar(&gs_meas_interval_char, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

ble_status_t R_BLE_HTS_IndicateMeasInterval(uint16_t conn_hdl, const uint16_t *p_value)
{
    return R_BLE_SERVS_SendHdlVal(&gs_meas_interval_char, conn_hdl, (const void *)p_value, false);
}

/*----------------------------------------------------------------------------------------------------------------------
    Health Thermometer Service server
----------------------------------------------------------------------------------------------------------------------*/

/* Health Thermometer Service characteristics definition */
static const st_ble_servs_char_info_t *gspp_chars[] = {
    &gs_temp_meas_char,
    &gs_temp_type_char,
    &gs_intermediate_temperature_char,
    &gs_meas_interval_char,
};

/* Health Thermometer Service service definition */
static st_ble_servs_info_t gs_servs_info = {
    .pp_chars     = gspp_chars,
    .num_of_chars = ARRAY_SIZE(gspp_chars),
};

ble_status_t R_BLE_HTS_Init(ble_servs_app_cb_t cb)
{
    if (NULL == cb)
    {
        return BLE_ERR_INVALID_PTR;
    }

    gs_servs_info.cb = cb;

    return R_BLE_SERVS_RegisterServer(&gs_servs_info);
}
