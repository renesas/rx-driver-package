/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_ans.c
 * Version : 1.0
 * Description : The source file for Alert Notification Service service.
 **********************************************************************************************************************/
 /***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 20.12.2019 1.00 First Release
 ***********************************************************************************************************************/

 #include "string.h"
#include "r_ble_ans.h"
#include "profile_cmn/r_ble_servs_if.h"
#include "gatt_db.h"

 /***********************************************************************************************************************
 Macro definitions
 ***********************************************************************************************************************/
#define BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_SIMPLE_ALERT                                        ( 1 << 0 )
#define BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_EMAIL                                               ( 1 << 1 )
#define BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_NEWS                                                ( 1 << 2 )
#define BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_CALL                                                ( 1 << 3 )
#define BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_MISSED_CALL                                         ( 1 << 4 )
#define BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_SMS_MMS                                             ( 1 << 5 )
#define BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_VOICE_MAIL                                          ( 1 << 6 )
#define BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_SCHEDULE                                            ( 1 << 7 )
#define BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_HIGH_PRIORITIZED_ALERT                              ( 1 << 8 )
#define BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_INSTANT_MESSAGE                                     ( 1 << 9 )

#define BLE_ANS_PRV_ANS_SUPPORTED                                                                           (true)
#define BLE_ANS_PRV_ANS_NOTSUPPORTED                                                                        (false)

#ifndef UNUSED_ARG
#define UNUSED_ARG(arg)         (void)(arg)
#endif /* UNUSED_ARG */

/***********************************************************************************************************************
Private global variables and functions
***********************************************************************************************************************/
static st_ble_servs_info_t                              gs_servs_info;
static bool gs_is_sc_in_progress                      = false;
static st_ble_ans_alert_notification_control_point_t    gs_ans_sc_control_point;

/*----------------------------------------------------------------------------------------------------------------------
    Supported New Alert Category characteristic
----------------------------------------------------------------------------------------------------------------------*/

static ble_status_t decode_st_ble_ans_supnw_atcat_t(st_ble_ans_supported_new_alert_category_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint16_t flag = 0;
    BT_UNPACK_LE_2_BYTE(&flag, &p_gatt_value->p_value[0]);

    /* check the length */
    if (BLE_ANS_SUPPORTED_NEW_ALERT_CATEGORY_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Clear the feature bit flags */
    memset((uint8_t*)p_app_value, 0x00, sizeof(st_ble_ans_supported_new_alert_category_t));

    /* Simple alert supported bit */
    if ((flag & BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_SIMPLE_ALERT))
    {
        p_app_value->is_simple_alert = BLE_ANS_PRV_ANS_SUPPORTED;
    }
    else
    {
        p_app_value->is_simple_alert = BLE_ANS_PRV_ANS_NOTSUPPORTED;
    }

    /* Email field supported bit */
    if ((flag & BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_EMAIL))
    {
        p_app_value->is_email = BLE_ANS_PRV_ANS_SUPPORTED;
    }
    else
    {
        p_app_value->is_email = BLE_ANS_PRV_ANS_NOTSUPPORTED;
    }

    /* News field supported bit */
    if ((flag & BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_NEWS))
    {
        p_app_value->is_news = BLE_ANS_PRV_ANS_SUPPORTED;
    }
    else
    {
        p_app_value->is_news = BLE_ANS_PRV_ANS_NOTSUPPORTED;
    }

    /* Call field supported bit */
    if ((flag & BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_CALL))
    {
        p_app_value->is_call = BLE_ANS_PRV_ANS_SUPPORTED;
    }
    else
    {
        p_app_value->is_call = BLE_ANS_PRV_ANS_NOTSUPPORTED;
    }

    /* Missed Call field supported bit */
    if ((flag & BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_MISSED_CALL))
    {
        p_app_value->is_missed_call = BLE_ANS_PRV_ANS_SUPPORTED;
    }
    else
    {
        p_app_value->is_missed_call = BLE_ANS_PRV_ANS_NOTSUPPORTED;
    }

    /* SMS MMS field supported bit */
    if ((flag & BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_SMS_MMS))
    {
        p_app_value->is_sms_mms = BLE_ANS_PRV_ANS_SUPPORTED;
    }
    else
    {
        p_app_value->is_sms_mms = BLE_ANS_PRV_ANS_NOTSUPPORTED;
    }

    /* Voice Mail field supported bit */
    if ((flag & BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_VOICE_MAIL))
    {
        p_app_value->is_voice_mail = BLE_ANS_PRV_ANS_SUPPORTED;
    }
    else
    {
        p_app_value->is_voice_mail = BLE_ANS_PRV_ANS_NOTSUPPORTED;
    }

    /* Schedule field supported bit */
    if ((flag & BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_SCHEDULE))
    {
        p_app_value->is_schedule = BLE_ANS_PRV_ANS_SUPPORTED;
    }
    else
    {
        p_app_value->is_schedule = BLE_ANS_PRV_ANS_NOTSUPPORTED;
    }

    /* High Prioritized Alert field supported bit */
    if ((flag & BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_HIGH_PRIORITIZED_ALERT))
    {
        p_app_value->is_high_prioritized_alert = BLE_ANS_PRV_ANS_SUPPORTED;
    }
    else
    {
        p_app_value->is_high_prioritized_alert = BLE_ANS_PRV_ANS_NOTSUPPORTED;
    }

    /* Instant Message field supported bit */
    if ((flag & BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_INSTANT_MESSAGE))
    {
        p_app_value->is_instant_message = BLE_ANS_PRV_ANS_SUPPORTED;
    }
    else
    {
        p_app_value->is_instant_message = BLE_ANS_PRV_ANS_NOTSUPPORTED;
    }

    return BLE_SUCCESS;
}
/* End of function decode_st_ble_ans_supnw_atcat_t */

static ble_status_t encode_st_ble_ans_supnw_atcat_t(const st_ble_ans_supported_new_alert_category_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint16_t flag = 0;


    /* Clear the byte array */
    memset(p_gatt_value, 0x00, p_gatt_value->value_len);

    /* Simple alert supported bit */
    if (p_app_value->is_simple_alert)
    {
        flag |= BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_SIMPLE_ALERT;
    }

    /* Email field supported bit */
    if (p_app_value->is_email)
    {
        flag |= BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_EMAIL;
    }

    /* News field supported bit */
    if (p_app_value->is_news)
    {
        flag |= BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_NEWS;
    }

    /* Call field supported bit */
    if (p_app_value->is_call)
    {
        flag |= BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_CALL;
    }

    /* Missed Call field supported bit */
    if (p_app_value->is_missed_call)
    {
        flag |= BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_MISSED_CALL;
    }

    /* SMS MMS supported bit */
    if (p_app_value->is_sms_mms)
    {
        flag |= BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_SMS_MMS;
    }

    /* Voice Mail field supported bit */
    if (p_app_value->is_voice_mail)
    {
        flag |= BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_VOICE_MAIL;
    }

    /* Schedule field supported bit */
    if (p_app_value->is_schedule)
    {
        flag |= BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_SCHEDULE;
    }

    /* High Prioritized Alert field supported bit */
    if (p_app_value->is_high_prioritized_alert)
    {
        flag |= BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_HIGH_PRIORITIZED_ALERT;
    }

    /* Instant Message field supported bit */
    if (p_app_value->is_instant_message)
    {
        flag |= BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_INSTANT_MESSAGE;
    }

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[0], &flag);
    p_gatt_value->value_len = BLE_ANS_SUPPORTED_NEW_ALERT_CATEGORY_LEN;

    return BLE_SUCCESS;
}
/* End of function encode_st_ble_ans_supnw_atcat_t */

/* Supported New Alert Category characteristic definition */
static const st_ble_servs_char_info_t gs_supported_new_alert_category_char = 
{
    .start_hdl    = BLE_ANS_SUPPORTED_NEW_ALERT_CATEGORY_DECL_HDL,
    .end_hdl      = BLE_ANS_SUPPORTED_NEW_ALERT_CATEGORY_VAL_HDL,
    .char_idx     = BLE_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IDX,
    .app_size     = sizeof(st_ble_ans_supported_new_alert_category_t),
    .db_size      = BLE_ANS_SUPPORTED_NEW_ALERT_CATEGORY_LEN,
    .decode       = (ble_servs_attr_decode_t)decode_st_ble_ans_supnw_atcat_t,
    .encode       = (ble_servs_attr_encode_t)encode_st_ble_ans_supnw_atcat_t,
};

ble_status_t R_BLE_ANS_SetSup_nw_alt_cat(const st_ble_ans_supported_new_alert_category_t *p_value)
{
    return R_BLE_SERVS_SetChar(&gs_supported_new_alert_category_char, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_ANS_GetSup_nw_alt_cat(st_ble_ans_supported_new_alert_category_t *p_value)
{
    return R_BLE_SERVS_GetChar(&gs_supported_new_alert_category_char, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    New Alert Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

static const st_ble_servs_desc_info_t gs_new_alert_cli_cnfg = 
{
    .attr_hdl = BLE_ANS_NEW_ALERT_CLI_CNFG_DESC_HDL,
    .app_size = sizeof(uint16_t),
    .desc_idx = BLE_ANS_NEW_ALERT_CLI_CNFG_IDX,
    .db_size  = BLE_ANS_NEW_ALERT_CLI_CNFG_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_uint16_t,
    .encode   = (ble_servs_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_ANS_SetNew_alerttCliCnfg(uint16_t conn_hdl, const uint16_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_new_alert_cli_cnfg, conn_hdl, (const void *)p_value);
}

ble_status_t R_BLE_ANS_GetNew_alertCliCnfg(uint16_t conn_hdl, uint16_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_new_alert_cli_cnfg, conn_hdl, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    New Alert characteristic
----------------------------------------------------------------------------------------------------------------------*/
static ble_status_t decode_st_ble_ans_new_alert_t(st_ble_ans_new_alert_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    UNUSED_ARG(p_app_value);
    UNUSED_ARG(p_gatt_value);

    /*Do Nothing as flow is not hitting here*/
    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_ans_new_alert_t(const st_ble_ans_new_alert_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    /*Convert application data to byte sequence*/
    uint32_t pos = 0;
    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->category_id);
    pos += 1;

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->number_of_new_alert);
    pos += 1;

    if (0 < p_app_value->number_of_new_alert)
    {
        for (uint8_t i = 0; i < BLE_ANS_NEW_ALERT_TEXT_LEN; i++)
        {
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->text_string_information[i]);
            pos += 1;
        }
    }

    p_gatt_value->value_len = (uint16_t)pos;

    return BLE_SUCCESS;
}
/* End of function encode_st_ble_ans_new_alert_t */

/* New Alert characteristic descriptor definition */
static const st_ble_servs_desc_info_t *gspp_new_alert_descs[] = 
{
    &gs_new_alert_cli_cnfg,
};

/* New Alert characteristic definition */
static const st_ble_servs_char_info_t gs_new_alert_char = 
{
    .start_hdl    = BLE_ANS_NEW_ALERT_DECL_HDL,
    .end_hdl      = BLE_ANS_NEW_ALERT_CLI_CNFG_DESC_HDL,
    .char_idx     = BLE_ANS_NEW_ALERT_IDX,
    .app_size     = sizeof(st_ble_ans_new_alert_t),
    .db_size      = BLE_ANS_NEW_ALERT_LEN,
    .decode       = (ble_servs_attr_decode_t)decode_st_ble_ans_new_alert_t,
    .encode       = (ble_servs_attr_encode_t)encode_st_ble_ans_new_alert_t,
    .pp_descs     = gspp_new_alert_descs,
    .num_of_descs = ARRAY_SIZE(gspp_new_alert_descs),
};

ble_status_t R_BLE_ANS_NotifyNew_alert(uint16_t conn_hdl, const st_ble_ans_new_alert_t *p_value)
{
    return R_BLE_SERVS_SendHdlVal(&gs_new_alert_char, conn_hdl, (const void *)p_value, true);
}

/*----------------------------------------------------------------------------------------------------------------------
    Supported Unread Alert Category characteristic
----------------------------------------------------------------------------------------------------------------------*/
static ble_status_t decode_st_ble_ans_su_un_atcat_t(st_ble_ans_supported_unread_alert_category_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint16_t flag = 0;

    BT_UNPACK_LE_2_BYTE(&flag, &p_gatt_value->p_value[0]);

    /* check the length */
    if (BLE_ANS_SUPPORTED_UNREAD_ALERT_CATEGORY_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Clear the feature bit flags */
    memset((uint8_t*)p_app_value, 0x00, sizeof(st_ble_ans_supported_unread_alert_category_t));

    /* Simple alert supported bit */
    if ((flag & BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_SIMPLE_ALERT))
    {
        p_app_value->is_simple_alert = BLE_ANS_PRV_ANS_SUPPORTED;
    }
    else
    {
        p_app_value->is_simple_alert = BLE_ANS_PRV_ANS_NOTSUPPORTED;
    }

    /* Email field supported bit */
    if ((flag & BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_EMAIL))
    {
        p_app_value->is_email = BLE_ANS_PRV_ANS_SUPPORTED;
    }
    else
    {
        p_app_value->is_email = BLE_ANS_PRV_ANS_NOTSUPPORTED;
    }

    /* News field supported bit */
    if ((flag & BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_NEWS))
    {
        p_app_value->is_news = BLE_ANS_PRV_ANS_SUPPORTED;
    }
    else
    {
        p_app_value->is_news = BLE_ANS_PRV_ANS_NOTSUPPORTED;
    }

    /* Call field supported bit */
    if ((flag & BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_CALL))
    {
        p_app_value->is_call = BLE_ANS_PRV_ANS_SUPPORTED;
    }
    else
    {
        p_app_value->is_call = BLE_ANS_PRV_ANS_NOTSUPPORTED;
    }

    /* Missed Call field supported bit */
    if ((flag & BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_MISSED_CALL))
    {
        p_app_value->is_missed_call = BLE_ANS_PRV_ANS_SUPPORTED;
    }
    else
    {
        p_app_value->is_missed_call = BLE_ANS_PRV_ANS_NOTSUPPORTED;
    }

    /* SMS MMS field supported bit */
    if ((flag & BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_SMS_MMS))
    {
        p_app_value->is_sms_mms = BLE_ANS_PRV_ANS_SUPPORTED;
    }
    else
    {
        p_app_value->is_sms_mms = BLE_ANS_PRV_ANS_NOTSUPPORTED;
    }

    /* Voice Mail field supported bit */
    if ((flag & BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_VOICE_MAIL))
    {
        p_app_value->is_voice_mail = BLE_ANS_PRV_ANS_SUPPORTED;
    }
    else
    {
        p_app_value->is_voice_mail = BLE_ANS_PRV_ANS_NOTSUPPORTED;
    }

    /* Schedule field supported bit */
    if ((flag & BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_SCHEDULE))
    {
        p_app_value->is_schedule = BLE_ANS_PRV_ANS_SUPPORTED;
    }
    else
    {
        p_app_value->is_schedule = BLE_ANS_PRV_ANS_NOTSUPPORTED;
    }

    /* High Prioritized Alert field supported bit */
    if ((flag & BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_HIGH_PRIORITIZED_ALERT))
    {
        p_app_value->is_high_prioritized_alert = BLE_ANS_PRV_ANS_SUPPORTED;
    }
    else
    {
        p_app_value->is_high_prioritized_alert = BLE_ANS_PRV_ANS_NOTSUPPORTED;
    }

    /* Instant Message field supported bit */
    if ((flag & BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_INSTANT_MESSAGE))
    {
        p_app_value->is_instant_message = BLE_ANS_PRV_ANS_SUPPORTED;
    }
    else
    {
        p_app_value->is_instant_message = BLE_ANS_PRV_ANS_NOTSUPPORTED;
    }

    return BLE_SUCCESS;
}
/* End of function decode_st_ble_ans_su_un_atcat_t */

static ble_status_t encode_st_ble_ans_su_un_atcat_t(const st_ble_ans_supported_unread_alert_category_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    /*Convert application data to byte sequence*/
    uint16_t flag = 0;

    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    /* Simple alert supported bit */
    if (p_app_value->is_simple_alert)
    {
        flag |= BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_SIMPLE_ALERT;
    }

    /* Email field supported bit */
    if (p_app_value->is_email)
    {
        flag |= BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_EMAIL;
    }

    /* News field supported bit */
    if (p_app_value->is_news)
    {
        flag |= BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_NEWS;
    }

    /* Call field supported bit */
    if (p_app_value->is_call)
    {
        flag |= BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_CALL;
    }

    /* Missed Call field supported bit */
    if (p_app_value->is_missed_call)
    {
        flag |= BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_MISSED_CALL;
    }

    /* SMS MMS field supported bit */
    if (p_app_value->is_sms_mms)
    {
        flag |= BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_SMS_MMS;
    }

    /* Voice Mail field supported bit */
    if (p_app_value->is_voice_mail)
    {
        flag |= BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_VOICE_MAIL;
    }

    /* Schedule field supported bit */
    if (p_app_value->is_schedule)
    {
        flag |= BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_SCHEDULE;
    }

    /* High Prioritized Alert field supported bit */
    if (p_app_value->is_high_prioritized_alert)
    {
        flag |= BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_HIGH_PRIORITIZED_ALERT;
    }

    /* Instant Message field supported bit */
    if (p_app_value->is_instant_message)
    {
        flag |= BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_INSTANT_MESSAGE;
    }

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[0], &flag);
    p_gatt_value->value_len = BLE_ANS_SUPPORTED_UNREAD_ALERT_CATEGORY_LEN;

    return BLE_SUCCESS;
}
/* End of function encode_st_ble_ans_su_un_atcat_t */

/* Supported Unread Alert Category characteristic definition */
static const st_ble_servs_char_info_t gs_supported_unread_alert_category_char = 
{
    .start_hdl    = BLE_ANS_SUPPORTED_UNREAD_ALERT_CATEGORY_DECL_HDL,
    .end_hdl      = BLE_ANS_SUPPORTED_UNREAD_ALERT_CATEGORY_VAL_HDL,
    .char_idx     = BLE_ANS_SUPPORTED_UNREAD_ALERT_CATEGORY_IDX,
    .app_size     = sizeof(st_ble_ans_supported_unread_alert_category_t),
    .db_size      = BLE_ANS_SUPPORTED_UNREAD_ALERT_CATEGORY_LEN,
    .decode       = (ble_servs_attr_decode_t)decode_st_ble_ans_su_un_atcat_t,
    .encode       = (ble_servs_attr_encode_t)encode_st_ble_ans_su_un_atcat_t,
};

ble_status_t R_BLE_ANS_SetSup_un_alt_cat(const st_ble_ans_supported_unread_alert_category_t *p_value)
{
    return R_BLE_SERVS_SetChar(&gs_supported_unread_alert_category_char, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_ANS_GetSup_un_alt_cat(st_ble_ans_supported_unread_alert_category_t *p_value)
{
    return R_BLE_SERVS_GetChar(&gs_supported_unread_alert_category_char, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Unread Alert Status Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

static const st_ble_servs_desc_info_t gs_unread_alert_status_cli_cnfg = 
{
    .attr_hdl = BLE_ANS_UNREAD_ALERT_STATUS_CLI_CNFG_DESC_HDL,
    .app_size = sizeof(uint16_t),
    .desc_idx = BLE_ANS_UNREAD_ALERT_STATUS_CLI_CNFG_IDX,
    .db_size  = BLE_ANS_UNREAD_ALERT_STATUS_CLI_CNFG_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_uint16_t,
    .encode   = (ble_servs_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_ANS_SetUnd_at_stCliCnfg(uint16_t conn_hdl, const uint16_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_unread_alert_status_cli_cnfg, conn_hdl, (const void *)p_value);
}

ble_status_t R_BLE_ANS_GetUnd_at_stCliCnfg(uint16_t conn_hdl, uint16_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_unread_alert_status_cli_cnfg, conn_hdl, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Unread Alert Status characteristic
----------------------------------------------------------------------------------------------------------------------*/
static ble_status_t decode_st_ble_ans_und_altst_t(st_ble_ans_unread_alert_status_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    UNUSED_ARG(p_app_value);
    UNUSED_ARG(p_gatt_value);

    /*Do Nothing as flow is not hitting here*/
    return BLE_SUCCESS;
}
/* End of function decode_st_ble_ans_und_altst_t */

static ble_status_t encode_st_ble_ans_und_altst_t(const st_ble_ans_unread_alert_status_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    /*Convert application data to byte sequence*/
    uint32_t pos = 0;

    /* Clear the byte array */
    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->category_id);
    pos += 1;

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->unread_count);
    pos += 1;

    p_gatt_value->value_len = (uint16_t)pos;

    return BLE_SUCCESS;
}
/* End of function encode_st_ble_ans_und_altst_t */

/* Unread Alert Status characteristic descriptor definition */
static const st_ble_servs_desc_info_t *gspp_unread_alert_status_descs[] = 
{
    &gs_unread_alert_status_cli_cnfg,
};

/* Unread Alert Status characteristic definition */
static const st_ble_servs_char_info_t gs_unread_alert_status_char = 
{
    .start_hdl    = BLE_ANS_UNREAD_ALERT_STATUS_DECL_HDL,
    .end_hdl      = BLE_ANS_UNREAD_ALERT_STATUS_CLI_CNFG_DESC_HDL,
    .char_idx     = BLE_ANS_UNREAD_ALERT_STATUS_IDX,
    .app_size     = sizeof(st_ble_ans_unread_alert_status_t),
    .db_size      = BLE_ANS_UNREAD_ALERT_STATUS_LEN,
    .decode       = (ble_servs_attr_decode_t)decode_st_ble_ans_und_altst_t,
    .encode       = (ble_servs_attr_encode_t)encode_st_ble_ans_und_altst_t,
    .pp_descs     = gspp_unread_alert_status_descs,
    .num_of_descs = ARRAY_SIZE(gspp_unread_alert_status_descs),
};

ble_status_t R_BLE_ANS_NotifyUnread_alt_st(uint16_t conn_hdl, const st_ble_ans_unread_alert_status_t *p_value)
{
    return R_BLE_SERVS_SendHdlVal(&gs_unread_alert_status_char, conn_hdl, (const void *)p_value, true);
}

/*----------------------------------------------------------------------------------------------------------------------
    Alert Notification Control Point characteristic
----------------------------------------------------------------------------------------------------------------------*/
static ble_status_t decode_st_ble_ans_alt_ntfy_cp_t(st_ble_ans_alert_notification_control_point_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    /*Convert byte sequence to app data*/
    uint32_t pos = 0;
    ble_status_t                   ret;

    memset((uint8_t*)p_app_value, 0x00, sizeof(*p_app_value));

    BT_UNPACK_LE_1_BYTE(&gs_ans_sc_control_point.command_id, &p_gatt_value->p_value[pos]);
    pos += 1;
    BT_UNPACK_LE_1_BYTE(&gs_ans_sc_control_point.category_id, &p_gatt_value->p_value[pos]);
    if ((p_gatt_value->value_len <= BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_LEN) && (p_gatt_value->value_len == pos))
    {
        memcpy(p_app_value, &gs_ans_sc_control_point, sizeof(st_ble_ans_alert_notification_control_point_t));

        ret = BLE_SUCCESS;
    }
    else
    {
        ret = BLE_ANS_PRV_WRITE_REQUEST_REJECTED;
    }

    return ret;
}
/* End of function decode_st_ble_ans_alt_ntfy_cp_t */

static ble_status_t encode_st_ble_ans_alt_ntfy_cp_t(const st_ble_ans_alert_notification_control_point_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    UNUSED_ARG(p_app_value);
    UNUSED_ARG(p_gatt_value);

    /*Do Nothing as flow is not hitting here*/
    return BLE_SUCCESS;
}
/* End of function encode_st_ble_ans_alt_ntfy_cp_t */

static void write_req_sc_ctrl_pt(const void *p_attr, uint16_t conn_hdl, ble_status_t result,  st_ble_ans_alert_notification_control_point_t *p_app_value)
{
    UNUSED_ARG(p_attr);
    UNUSED_ARG(conn_hdl);
    UNUSED_ARG(result);
    UNUSED_ARG(p_app_value);

    if (gs_ans_sc_control_point.command_id > BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_COMMAND_ID_NOTIFY_UNREAD_CATEGORY_STATUS_IMMEDIATELY)  // && (0x01 == p_app_value->response_code))
    {
        gs_is_sc_in_progress = true;
    }

    if (gs_is_sc_in_progress)
    {
        R_BLE_GATTS_SendErrRsp(BLE_ANS_COMMAND_NOT_SUPPORTED);
        return;
    }
}
/* End of function write_req_sc_ctrl_pt */

static void write_comp_sc_ctrl_pt(const void *p_attr, uint16_t conn_hdl, ble_status_t result, st_ble_ans_alert_notification_control_point_t *p_app_value)
{
    UNUSED_ARG(result);
    UNUSED_ARG(p_app_value);

    st_ble_servs_evt_data_t evt_data =
    {
        .conn_hdl = conn_hdl,
        .param_len = sizeof(gs_ans_sc_control_point),
        .p_param = &gs_ans_sc_control_point,
    };
    st_ble_servs_char_info_t p_char = *(st_ble_servs_char_info_t *)p_attr;
    gs_servs_info.cb(BLE_SERVS_MULTI_ATTR_EVENT(p_char.char_idx, p_char.inst_idx, BLE_SERVS_WRITE_REQ), BLE_SUCCESS, &evt_data);

}
/* End of function write_comp_sc_ctrl_pt */

/* Alert Notification Control Point characteristic definition */
static const st_ble_servs_char_info_t gs_alert_notification_control_point_char = 
{
    .start_hdl     = BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_DECL_HDL,
    .end_hdl       = BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_VAL_HDL,
    .char_idx      = BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_IDX,
    .app_size      = sizeof(st_ble_ans_alert_notification_control_point_t),
    .db_size       = BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_LEN,
    .write_req_cb  = (ble_servs_attr_write_req_t)write_req_sc_ctrl_pt,
    .write_comp_cb = (ble_servs_attr_write_comp_t)write_comp_sc_ctrl_pt,
    .decode        = (ble_servs_attr_decode_t)decode_st_ble_ans_alt_ntfy_cp_t,
    .encode        = (ble_servs_attr_encode_t)encode_st_ble_ans_alt_ntfy_cp_t,
};

/*----------------------------------------------------------------------------------------------------------------------
    Alert Notification Service server
----------------------------------------------------------------------------------------------------------------------*/

/* Alert Notification Service characteristics definition */
static const st_ble_servs_char_info_t *gspp_chars[] = 
{
    &gs_supported_new_alert_category_char,
    &gs_new_alert_char,
    &gs_supported_unread_alert_category_char,
    &gs_unread_alert_status_char,
    &gs_alert_notification_control_point_char,
};

/* Alert Notification Service service definition */
static st_ble_servs_info_t gs_servs_info = 
{
    .pp_chars     = gspp_chars,
    .num_of_chars = ARRAY_SIZE(gspp_chars),
};

ble_status_t R_BLE_ANS_Init(ble_servs_app_cb_t cb)
{
    if (NULL == cb)
    {
        return BLE_ERR_INVALID_PTR;
    }

    gs_servs_info.cb = cb;

    return R_BLE_SERVS_RegisterServer(&gs_servs_info);
}
/* End of function R_BLE_ANS_Init */
