/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name   : r_ble_ans.c
 * Version     : 1.0
 * Description : This module implements Alert Notification Service Server.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 24.05.2019 1.00 First Release
 ***********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <string.h>
#include "r_ble_rx23w_if.h"
#include "r_ble_ans.h"
#include "gatt_db.h"

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
#define BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_SIMPLE_ALERT                                        ( 1 << 0 )
#define BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_EMAIL                                               ( 1 << 1 )
#define BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_NEWS                                                ( 1 << 2 )
#define BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_CALL                                                ( 1 << 3 )
#define BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_MISSED_CALL                                         ( 1 << 4 )
#define BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_SMS_MMS                                             ( 1 << 5 )
#define BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_VOICE_MAIL                                          ( 1 << 6 )
#define BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_SCHEDULE                                            ( 1 << 7 )
#define BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_HIGH_PRIORITIZED_ALERT                              ( 1 << 8 )
#define BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_INSTANT_MESSAGE                                     ( 1 << 9 )


#define BLE_ANS_PRV_ANS_SUPPORTED                                                                           (true)
#define BLE_ANS_PRV_ANS_NOTSUPPORTED                                                                        (false)

/* Version number */
#define BLE_ANS_PRV_VERSION_MAJOR                                                                           (1)
#define BLE_ANS_PRV_VERSION_MINOR                                                                           (0)

/***********************************************************************************************************************
Private global variables and functions
***********************************************************************************************************************/

static ble_ans_app_cb_t                              gs_ans_cb;
static uint16_t                                      gs_conn_hdl;
static st_ble_ans_alert_notification_control_point_t gs_ans_control_point;
static bool                                          gs_ans_cp_in_progress       = false;

/***********************************************************************************************************************
 * Function Name: set_cli_cnfg
 * Description  : Set Characteristic value notification configuration in local GATT database.
 * Arguments    : conn_hdl  - handle to connection.
 *                attr_hadl - handle to the attribute
 *                cli_cnfg  - configuration value
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t set_cli_cnfg(uint16_t conn_hdl, uint16_t attr_hdl, uint16_t cli_cnfg)
{
    uint8_t data[2];

    BT_PACK_LE_2_BYTE(data, &cli_cnfg);

    st_ble_gatt_value_t gatt_value = 
    {
        .p_value   = data,
        .value_len = 2,
    };

    return R_BLE_GATTS_SetAttr(conn_hdl, attr_hdl, &gatt_value);
}

/* End of function set_cli_cnfg */

/***********************************************************************************************************************
 * Function Name: get_cli_cnfg
 * Description  : Get Characteristic value notification configuration from local GATT database.
 * Arguments    : conn_hdl   - handle to connection.
 *                attr_hadl  - handle to the attribute
 *                p_cli_cnfg - pointer to variable to store configuration value
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t get_cli_cnfg(uint16_t conn_hdl, uint16_t attr_hdl, uint16_t *p_cli_cnfg)
{
    ble_status_t ret;
    st_ble_gatt_value_t gatt_value;

    ret = R_BLE_GATTS_GetAttr(conn_hdl, attr_hdl, &gatt_value);

    if (BLE_SUCCESS == ret)
    {
        BT_UNPACK_LE_2_BYTE(p_cli_cnfg, gatt_value.p_value);
    }

    return ret;
}
/* End of function get_cli_cnfg */

/***********************************************************************************************************************
 * Function Name: encode_supported_new_alert_category
 * Description  : This function converts Supported New Alert Category characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the Supported New Alert Category  value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_supported_new_alert_category(const st_ble_ans_supported_new_alert_category_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint16_t flag = 0;
    
    /* Clear the byte array */
    memset(p_gatt_value, 0x00, p_gatt_value->value_len);

    /* Simple alert supported bit */
    if (p_app_value->is_simple_alert)
    {
        flag |= BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_SIMPLE_ALERT;
    }

    /* Email field supported bit */
    if (p_app_value->is_email)
    {
        flag |= BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_EMAIL;
    }

    /* News field supported bit */
    if (p_app_value->is_news)
    {
        flag |= BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_NEWS;
    }

    /* Call field supported bit */
    if (p_app_value->is_call)
    {
        flag |= BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_CALL;
    }

    /* Missed Call field supported bit */
    if (p_app_value->is_missed_call)
    {
        flag |= BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_MISSED_CALL;
    }

    /* SMS MMS supported bit */
    if (p_app_value->is_sms_mms)
    {
        flag |= BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_SMS_MMS;
    }

    /* Voice Mail field supported bit */
    if (p_app_value->is_voice_mail)
    {
        flag |= BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_VOICE_MAIL;
    }

    /* Schedule field supported bit */
    if (p_app_value->is_schedule)
    {
        flag |= BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_SCHEDULE;
    }

    /* High Prioritized Alert field supported bit */
    if (p_app_value->is_high_prioritized_alert)
    {
        flag |= BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_HIGH_PRIORITIZED_ALERT;
    }

    /* Instant Message field supported bit */
    if (p_app_value->is_instant_message)
    {
        flag |= BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_INSTANT_MESSAGE;
    }
    
    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[0], &flag);
    p_gatt_value->value_len = BLE_ANS_SUPPORTED_NEW_ALERT_CATEGORY_LEN;

    return BLE_SUCCESS;
}
/* End of function encode_supported_new_alert_category */

/***********************************************************************************************************************
 * Function Name: decode_supported_new_alert_category
 * Description  : This function converts Supported New Alert Category characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the Supported New Alert Category value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_supported_new_alert_category(st_ble_ans_supported_new_alert_category_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint16_t flag = 0;
    
    BT_UNPACK_LE_2_BYTE(&flag, &p_gatt_value->p_value[0]);

    /* check the length */
    if (BLE_ANS_SUPPORTED_NEW_ALERT_CATEGORY_LEN != p_gatt_value->value_len)
    {	
        return BLE_ERR_INVALID_DATA;
    }

    /* Clear the feature bit flags */
    memset((uint8_t*)p_app_value, 0x00, sizeof(st_ble_ans_supported_new_alert_category_t));

    /* Simple alert supported bit */
    if ((flag & BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_SIMPLE_ALERT))
    {
        p_app_value->is_simple_alert = BLE_ANS_PRV_ANS_SUPPORTED;
    }
    else
    {
        p_app_value->is_simple_alert = BLE_ANS_PRV_ANS_NOTSUPPORTED;
    }

    /* Email field supported bit */
    if ((flag & BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_EMAIL))
    {
        p_app_value->is_email = BLE_ANS_PRV_ANS_SUPPORTED;
    }
    else
    {
        p_app_value->is_email = BLE_ANS_PRV_ANS_NOTSUPPORTED;
    }

    /* News field supported bit */
    if ((flag & BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_NEWS))
    {
        p_app_value->is_news = BLE_ANS_PRV_ANS_SUPPORTED;
    }
    else
    {
        p_app_value->is_news = BLE_ANS_PRV_ANS_NOTSUPPORTED;
    }

    /* Call field supported bit */
    if ((flag & BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_CALL))
    {
        p_app_value->is_call = BLE_ANS_PRV_ANS_SUPPORTED;
    }
    else
    {
        p_app_value->is_call = BLE_ANS_PRV_ANS_NOTSUPPORTED;
    }

    /* Missed Call field supported bit */
    if ((flag & BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_MISSED_CALL))
    {
        p_app_value->is_missed_call = BLE_ANS_PRV_ANS_SUPPORTED;		
    }
    else
    {
        p_app_value->is_missed_call = BLE_ANS_PRV_ANS_NOTSUPPORTED;
    }

    /* SMS MMS field supported bit */
    if ((flag & BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_SMS_MMS))
    {
        p_app_value->is_sms_mms = BLE_ANS_PRV_ANS_SUPPORTED;
    }
    else
    {
        p_app_value->is_sms_mms = BLE_ANS_PRV_ANS_NOTSUPPORTED;
    }

    /* Voice Mail field supported bit */
    if ((flag & BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_VOICE_MAIL))
    {
        p_app_value->is_voice_mail = BLE_ANS_PRV_ANS_SUPPORTED;
    }
    else
    {
        p_app_value->is_voice_mail = BLE_ANS_PRV_ANS_NOTSUPPORTED;
    }

    /* Schedule field supported bit */
    if ((flag & BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_SCHEDULE))
    {
        p_app_value->is_schedule = BLE_ANS_PRV_ANS_SUPPORTED;
    }
    else
    {
        p_app_value->is_schedule = BLE_ANS_PRV_ANS_NOTSUPPORTED;
    }

    /* High Prioritized Alert field supported bit */
    if ((flag & BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_HIGH_PRIORITIZED_ALERT))
    {
        p_app_value->is_high_prioritized_alert = BLE_ANS_PRV_ANS_SUPPORTED;
    }
    else
    {
        p_app_value->is_high_prioritized_alert = BLE_ANS_PRV_ANS_NOTSUPPORTED;
    }

    /* Instant Message field supported bit */
    if ((flag & BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_INSTANT_MESSAGE))
    {
        p_app_value->is_instant_message = BLE_ANS_PRV_ANS_SUPPORTED;
    }
    else
    {
        p_app_value->is_instant_message = BLE_ANS_PRV_ANS_NOTSUPPORTED;
    }

    return BLE_SUCCESS;
 }
 /* End of function decode_supported_new_alert_category */

 /***********************************************************************************************************************
 * Function Name: encode_new_alert
 * Description  : This function converts New Alert characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the New Alert  value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_new_alert(const st_ble_ans_new_alert_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    /*Convert application data to byte sequence*/
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->category_id);
    pos += 1;

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->number_of_new_alert);
    pos += 1;
    
    if (0 < p_app_value->number_of_new_alert)
    {
        for (uint8_t i = 0; i < BLE_ANS_NEW_ALERT_TEXT_LEN; i++)
        {
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->text_string_information[i]);
            pos += 1;
        }
    }

    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}
/* End of function encode_new_alert */

/***********************************************************************************************************************
 * Function Name: encode_supported_unread_alert_category
 * Description  : This function converts Supported Unread Alert Category characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the Supported Unread Alert Category  value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_supported_unread_alert_category(const st_ble_ans_supported_unread_alert_category_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    /*Convert application data to byte sequence*/
    uint16_t flag = 0;

    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    /* Simple alert supported bit */
    if (p_app_value->is_simple_alert)
    {
        flag |= BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_SIMPLE_ALERT;
    }

    /* Email field supported bit */
    if (p_app_value->is_email)
    {
        flag |= BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_EMAIL;
    }

    /* News field supported bit */
    if (p_app_value->is_news)
    {
        flag |= BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_NEWS;
    }

    /* Call field supported bit */
    if (p_app_value->is_call)
    {
        flag |= BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_CALL;
    }

    /* Missed Call field supported bit */
    if (p_app_value->is_missed_call)
    {
        flag |= BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_MISSED_CALL;
    }

    /* SMS MMS field supported bit */
    if (p_app_value->is_sms_mms)
    {
        flag |= BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_SMS_MMS;
    }

    /* Voice Mail field supported bit */
    if (p_app_value->is_voice_mail)
    {
        flag |= BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_VOICE_MAIL;
    }

    /* Schedule field supported bit */
    if (p_app_value->is_schedule)
    {
        flag |= BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_SCHEDULE;
    }

    /* High Prioritized Alert field supported bit */
    if (p_app_value->is_high_prioritized_alert)
    {
        flag |= BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_HIGH_PRIORITIZED_ALERT;
    }

    /* Instant Message field supported bit */
    if (p_app_value->is_instant_message)
    {
        flag |= BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_INSTANT_MESSAGE;
    }

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[0], &flag);
    p_gatt_value->value_len = BLE_ANS_SUPPORTED_UNREAD_ALERT_CATEGORY_LEN;

    return BLE_SUCCESS;

}
/* End of function encode_supported_unread_alert_category */

/***********************************************************************************************************************
 * Function Name: decode_supported_unread_alert_category
 * Description  : This function converts Supported Unread Alert Category characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the Supported Unread Alert Category value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_supported_unread_alert_category(st_ble_ans_supported_unread_alert_category_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
   
    uint16_t flag = 0;
    
    BT_UNPACK_LE_2_BYTE(&flag, &p_gatt_value->p_value[0]);

    /* check the length */
    if (BLE_ANS_SUPPORTED_UNREAD_ALERT_CATEGORY_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Clear the feature bit flags */
    memset((uint8_t*)p_app_value, 0x00, sizeof(st_ble_ans_supported_unread_alert_category_t));

    /* Simple alert supported bit */
    if ((flag & BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_SIMPLE_ALERT))
    {
        p_app_value->is_simple_alert = BLE_ANS_PRV_ANS_SUPPORTED;
    }
    else
    {
        p_app_value->is_simple_alert = BLE_ANS_PRV_ANS_NOTSUPPORTED;
    }

    /* Email field supported bit */
    if ((flag & BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_EMAIL))
    {
        p_app_value->is_email = BLE_ANS_PRV_ANS_SUPPORTED;
    }
    else
    {
        p_app_value->is_email = BLE_ANS_PRV_ANS_NOTSUPPORTED;
    }

    /* News field supported bit */
    if ((flag & BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_NEWS))
    {
        p_app_value->is_news = BLE_ANS_PRV_ANS_SUPPORTED;
    }
    else
    {
        p_app_value->is_news = BLE_ANS_PRV_ANS_NOTSUPPORTED;
    }

    /* Call field supported bit */
    if ((flag & BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_CALL))
    {
        p_app_value->is_call = BLE_ANS_PRV_ANS_SUPPORTED;
    }
    else
    {
        p_app_value->is_call = BLE_ANS_PRV_ANS_NOTSUPPORTED;
    }

    /* Missed Call field supported bit */
    if ((flag & BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_MISSED_CALL))
    {
        p_app_value->is_missed_call = BLE_ANS_PRV_ANS_SUPPORTED;
    }
    else
    {
        p_app_value->is_missed_call = BLE_ANS_PRV_ANS_NOTSUPPORTED;
    }

    /* SMS MMS field supported bit */
    if ((flag & BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_SMS_MMS))
    {
        p_app_value->is_sms_mms = BLE_ANS_PRV_ANS_SUPPORTED;
    }
    else
    {
        p_app_value->is_sms_mms = BLE_ANS_PRV_ANS_NOTSUPPORTED;
    }

    /* Voice Mail field supported bit */
    if ((flag & BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_VOICE_MAIL))
    {
        p_app_value->is_voice_mail = BLE_ANS_PRV_ANS_SUPPORTED;
    }
    else
    {
        p_app_value->is_voice_mail = BLE_ANS_PRV_ANS_NOTSUPPORTED;
    }

    /* Schedule field supported bit */
    if ((flag & BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_SCHEDULE))
    {
        p_app_value->is_schedule = BLE_ANS_PRV_ANS_SUPPORTED;
    }
    else
    {
        p_app_value->is_schedule = BLE_ANS_PRV_ANS_NOTSUPPORTED;
    }

    /* High Prioritized Alert field supported bit */
    if ((flag & BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_HIGH_PRIORITIZED_ALERT))
    {
        p_app_value->is_high_prioritized_alert = BLE_ANS_PRV_ANS_SUPPORTED;
    }
    else
    {
        p_app_value->is_high_prioritized_alert = BLE_ANS_PRV_ANS_NOTSUPPORTED;
    }

    /* Instant Message field supported bit */
    if ((flag & BLE_ANS_PRV_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IS_INSTANT_MESSAGE))
    {
        p_app_value->is_instant_message = BLE_ANS_PRV_ANS_SUPPORTED;
    }
    else
    {
        p_app_value->is_instant_message = BLE_ANS_PRV_ANS_NOTSUPPORTED;
    }

    return BLE_SUCCESS;
}
/* End of function decode_supported_unread_alert_category */


/***********************************************************************************************************************
 * Function Name: encode_unread_alert_status
 * Description  : This function converts Unread Alert Status characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the Unread Alert Status  value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_unread_alert_status(const st_ble_ans_unread_alert_status_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    /*Convert application data to byte sequence*/
    uint8_t pos = 0;

    /* Clear the byte array */
    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->category_id);
    pos += 1;

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->unread_count);
    pos += 1;

    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}
/* End of function encode_unread_alert_status */

/***********************************************************************************************************************
 * Function Name: decode_alert_notification_control_point
 * Description  : This function converts Alert Notification Control Point characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the Alert Notification Control Point value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_alert_notification_control_point(st_ble_ans_alert_notification_control_point_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    /*Convert byte sequence to app data*/
    uint8_t pos = 0;
    uint8_t cmd_id = 0;

    if (BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    BT_UNPACK_LE_1_BYTE(&cmd_id, &p_gatt_value->p_value[pos]); 
    
    if (cmd_id > BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_COMMAND_ID_NOTIFY_UNREAD_CATEGORY_STATUS_IMMEDIATELY)
    {
        return BLE_ANS_COMMAND_NOT_SUPPORTED;
    }

    memset((uint8_t*)p_app_value, 0x00, sizeof(*p_app_value));

    BT_UNPACK_LE_1_BYTE(&p_app_value->command_id, &p_gatt_value->p_value[pos]);
    pos += 1;

    BT_UNPACK_LE_1_BYTE(&p_app_value->category_id, &p_gatt_value->p_value[pos]);

    return BLE_SUCCESS;
}
/* End of function decode_alert_notification_control_point */

/***********************************************************************************************************************
 * Function Name: ans_cp_event_cb
 * Description  : This function is callback to the Alert Notification Control Point events.
 * Arguments    : event  control point event
 * Return Value : none
 **********************************************************************************************************************/
static void ans_cp_event_cb(void)
{
    st_ble_ans_supported_unread_alert_category_t supported_unread_alert_category  = { 0 };
    st_ble_ans_supported_new_alert_category_t    supported_new_alert_category     = { 0 };
    uint16_t cli_cfg = 0;
    ble_status_t ret;
    st_ble_ans_evt_data_t evt_data =
    {
        .conn_hdl  = gs_conn_hdl,
        .param_len = sizeof(gs_ans_control_point),
        .p_param   = &gs_ans_control_point,
    };
    
    switch (gs_ans_control_point.command_id)
    {
        case BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_COMMAND_ID_ENABLE_NEW_INCOMING_ALERT_NOTIFICATION:
        {
            switch (gs_ans_control_point.category_id)
            {
                case BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_SIMPLE_ALERT__GENERAL_TEXT_ALERT_OR_NON_TEXT_ALERT:
                {
                    supported_new_alert_category.is_simple_alert      = true;
                    R_BLE_ANS_SetSupportedNewAlertCategory(&supported_new_alert_category);
                }
                break;

                case BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_EMAIL__ALERT_WHEN_EMAIL_MESSAGES_ARRIVES:
                {
                    supported_new_alert_category.is_email             = true;
                    R_BLE_ANS_SetSupportedNewAlertCategory(&supported_new_alert_category);
                }
                break;

                case BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_NEWS__NEWS_FEEDS_SUCH_AS_RSS__ATOM:
                {
                    supported_new_alert_category.is_news              = true;
                    R_BLE_ANS_SetSupportedNewAlertCategory(&supported_new_alert_category);
                }
                break;

                case BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID__CALL__INCOMING_CALL:
                {
                    supported_new_alert_category.is_call              = true;
                    R_BLE_ANS_SetSupportedNewAlertCategory(&supported_new_alert_category);
                }
                break;

                case BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_MISSED_CALL__MISSED_CALL:
                {
                    supported_new_alert_category.is_missed_call       = true;
                    R_BLE_ANS_SetSupportedNewAlertCategory(&supported_new_alert_category);
                }
                break;

                case BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_SMS_MMS__SMS_MMS_MESSAGE_ARRIVES:
                {
                    supported_new_alert_category.is_sms_mms           = true;
                    R_BLE_ANS_SetSupportedNewAlertCategory(&supported_new_alert_category);
                }
                break;

                case BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_VOICE_MAIL__VOICE_MAIL:
                {
                    supported_new_alert_category.is_voice_mail        = true;
                    R_BLE_ANS_SetSupportedNewAlertCategory(&supported_new_alert_category);
                }
                break;

                case BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_SCHEDULE__ALERT_OCCURRED_ON_CALENDAR__PLANNER:
                {
                    supported_new_alert_category.is_schedule          = true;
                    R_BLE_ANS_SetSupportedNewAlertCategory(&supported_new_alert_category);
                }
                break;

                case BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_HIGH_PRIORITIZED_ALERT__ALERT_THAT_SHOULD_BE_HANDLED_AS_HIGH_PRIORITY:
                {
                    supported_new_alert_category.is_high_prioritized_alert = true;
                    R_BLE_ANS_SetSupportedNewAlertCategory(&supported_new_alert_category);
                }
                break;

                case BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_INSTANT_MESSAGE__ALERT_FOR_INCOMING_INSTANT_MESSAGES:
                {
                    supported_new_alert_category.is_instant_message   = true;
                    R_BLE_ANS_SetSupportedNewAlertCategory(&supported_new_alert_category);
                }
                break;

                case BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_ALL:
                {
                    /*All other flags making true*/
                    supported_new_alert_category.is_simple_alert           = true;
                    supported_new_alert_category.is_email                  = true;
                    supported_new_alert_category.is_news                   = true;
                    supported_new_alert_category.is_call                   = true;
                    supported_new_alert_category.is_missed_call            = true;
                    supported_new_alert_category.is_sms_mms                = true;
                    supported_new_alert_category.is_voice_mail             = true;
                    supported_new_alert_category.is_schedule               = true;
                    supported_new_alert_category.is_high_prioritized_alert = true;
                    supported_new_alert_category.is_instant_message        = true;
                    R_BLE_ANS_SetSupportedNewAlertCategory(&supported_new_alert_category);
                }
                break;

                default:
                {
                    /* DO NOTHING */
                }
                break;
            }
            
            gs_ans_cb(BLE_ANS_EVENT_ALERT_NOTIFICATION_CONTROL_POINT_WRITE_REQ, BLE_SUCCESS, &evt_data);
        }
        break;

        case BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_COMMAND_ID_ENABLE_UNREAD_CATEGORY_STATUS_NOTIFICATION:
        {
            switch (gs_ans_control_point.category_id)
            {
                case BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_SIMPLE_ALERT__GENERAL_TEXT_ALERT_OR_NON_TEXT_ALERT:
                {
                    supported_unread_alert_category.is_simple_alert  = true;
                    R_BLE_ANS_SetSupportedUnreadAlertCategory(&supported_unread_alert_category);
                }
                break;

                case BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_EMAIL__ALERT_WHEN_EMAIL_MESSAGES_ARRIVES:
                {
                    supported_unread_alert_category.is_email                       = true;
                    R_BLE_ANS_SetSupportedUnreadAlertCategory(&supported_unread_alert_category);
                }
                break;

                case BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_NEWS__NEWS_FEEDS_SUCH_AS_RSS__ATOM:
                {
                    supported_unread_alert_category.is_news                        = true;
                    R_BLE_ANS_SetSupportedUnreadAlertCategory(&supported_unread_alert_category);
                }
                break;

                case BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID__CALL__INCOMING_CALL:
                {
                    supported_unread_alert_category.is_call                        = true;
                    R_BLE_ANS_SetSupportedUnreadAlertCategory(&supported_unread_alert_category);
                }
                break;

                case BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_MISSED_CALL__MISSED_CALL:
                {
                    supported_unread_alert_category.is_missed_call = true;
                    R_BLE_ANS_SetSupportedUnreadAlertCategory(&supported_unread_alert_category);
                }
                break;

                case BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_SMS_MMS__SMS_MMS_MESSAGE_ARRIVES:
                {
                    supported_unread_alert_category.is_sms_mms                     = true;
                    R_BLE_ANS_SetSupportedUnreadAlertCategory(&supported_unread_alert_category);
                }
                break;

                case BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_VOICE_MAIL__VOICE_MAIL:
                {
                    supported_unread_alert_category.is_voice_mail                  = true;
                    R_BLE_ANS_SetSupportedUnreadAlertCategory(&supported_unread_alert_category);
                }
                break;

                case BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_SCHEDULE__ALERT_OCCURRED_ON_CALENDAR__PLANNER:
                {
                    supported_unread_alert_category.is_schedule                    = true;
                    R_BLE_ANS_SetSupportedUnreadAlertCategory(&supported_unread_alert_category);
                }
                break;

                case BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_HIGH_PRIORITIZED_ALERT__ALERT_THAT_SHOULD_BE_HANDLED_AS_HIGH_PRIORITY:
                {
                    supported_unread_alert_category.is_high_prioritized_alert      = true;
                    R_BLE_ANS_SetSupportedUnreadAlertCategory(&supported_unread_alert_category);
                }
                break;

                case BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_INSTANT_MESSAGE__ALERT_FOR_INCOMING_INSTANT_MESSAGES:
                {
                    supported_unread_alert_category.is_instant_message             = true;
                    R_BLE_ANS_SetSupportedUnreadAlertCategory(&supported_unread_alert_category);
                }
                break;

                case BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_ALL:
                {
                    /*All other flags making true*/
                    supported_unread_alert_category.is_simple_alert           = true;
                    supported_unread_alert_category.is_email                  = true;
                    supported_unread_alert_category.is_news                   = true;
                    supported_unread_alert_category.is_call                   = true;
                    supported_unread_alert_category.is_missed_call            = true;
                    supported_unread_alert_category.is_sms_mms                = true;
                    supported_unread_alert_category.is_voice_mail             = true;
                    supported_unread_alert_category.is_schedule               = true;
                    supported_unread_alert_category.is_high_prioritized_alert = true;
                    supported_unread_alert_category.is_instant_message        = true;
                    
                    R_BLE_ANS_SetSupportedUnreadAlertCategory(&supported_unread_alert_category);
                }
                break;

                default:
                {
                    /* DO NOTHING*/
                }
                break;
            }
            
            gs_ans_cb(BLE_ANS_EVENT_ALERT_NOTIFICATION_CONTROL_POINT_WRITE_REQ, BLE_SUCCESS, &evt_data);
        }
        break;

        case BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_COMMAND_ID_DISABLE_NEW_INCOMING_ALERT_NOTIFICATION:
        {
            switch (gs_ans_control_point.category_id)
            {
                case BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_SIMPLE_ALERT__GENERAL_TEXT_ALERT_OR_NON_TEXT_ALERT:
                {
                    supported_new_alert_category.is_simple_alert      = false;
                    R_BLE_ANS_SetSupportedNewAlertCategory(&supported_new_alert_category);
                }
                break;

                case BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_EMAIL__ALERT_WHEN_EMAIL_MESSAGES_ARRIVES:
                {
                    supported_new_alert_category.is_email             = false;
                    R_BLE_ANS_SetSupportedNewAlertCategory(&supported_new_alert_category);
                }
                break;

                case BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_NEWS__NEWS_FEEDS_SUCH_AS_RSS__ATOM:
                {
                    supported_new_alert_category.is_news = false;
                    R_BLE_ANS_SetSupportedNewAlertCategory(&supported_new_alert_category);
                }
                break;

                case BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID__CALL__INCOMING_CALL:
                {
                    supported_new_alert_category.is_call = false;
                    R_BLE_ANS_SetSupportedNewAlertCategory(&supported_new_alert_category);
                }
                break;

                case BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_MISSED_CALL__MISSED_CALL:
                {
                    supported_new_alert_category.is_missed_call = false;
                    R_BLE_ANS_SetSupportedNewAlertCategory(&supported_new_alert_category);
                }
                break;

                case BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_SMS_MMS__SMS_MMS_MESSAGE_ARRIVES:
                {
                    supported_new_alert_category.is_sms_mms = false;
                    R_BLE_ANS_SetSupportedNewAlertCategory(&supported_new_alert_category);
                }
                break;

                case BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_VOICE_MAIL__VOICE_MAIL:
                {
                    supported_new_alert_category.is_voice_mail = false;
                    R_BLE_ANS_SetSupportedNewAlertCategory(&supported_new_alert_category);
                }
                break;

                case BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_SCHEDULE__ALERT_OCCURRED_ON_CALENDAR__PLANNER:
                {
                    supported_new_alert_category.is_schedule = false;
                    R_BLE_ANS_SetSupportedNewAlertCategory(&supported_new_alert_category);
                }
                break;

                case BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_HIGH_PRIORITIZED_ALERT__ALERT_THAT_SHOULD_BE_HANDLED_AS_HIGH_PRIORITY:
                {
                    supported_new_alert_category.is_high_prioritized_alert = false;
                    R_BLE_ANS_SetSupportedNewAlertCategory(&supported_new_alert_category);
                }
                break;

                case BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_INSTANT_MESSAGE__ALERT_FOR_INCOMING_INSTANT_MESSAGES:
                {
                    supported_new_alert_category.is_instant_message = false;
                    R_BLE_ANS_SetSupportedNewAlertCategory(&supported_new_alert_category);
                }
                break;

                case BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_ALL:
                {
                    /*All other flags making true*/
                    supported_new_alert_category.is_simple_alert           = false;
                    supported_new_alert_category.is_email                  = false;
                    supported_new_alert_category.is_news                   = false;
                    supported_new_alert_category.is_call                   = false;
                    supported_new_alert_category.is_missed_call            = false;
                    supported_new_alert_category.is_sms_mms                = false;
                    supported_new_alert_category.is_voice_mail             = false;
                    supported_new_alert_category.is_schedule               = false;
                    supported_new_alert_category.is_high_prioritized_alert = false;
                    supported_new_alert_category.is_instant_message        = false;
                    
                    R_BLE_ANS_SetSupportedNewAlertCategory(&supported_new_alert_category);
                }
                break;

                default:
                {
                    /* DO NOTHING */
                }
                break;
            }
            
            gs_ans_cb(BLE_ANS_EVENT_ALERT_NOTIFICATION_CONTROL_POINT_WRITE_REQ, BLE_SUCCESS, &evt_data);
        }
        break;

        case BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_COMMAND_ID_DISABLE_UNREAD_CATEGORY_STATUS_NOTIFICATION:
        {
            switch (gs_ans_control_point.category_id)
            {
                case BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_SIMPLE_ALERT__GENERAL_TEXT_ALERT_OR_NON_TEXT_ALERT:
                {
                    supported_unread_alert_category.is_simple_alert                = false;
                    R_BLE_ANS_SetSupportedUnreadAlertCategory(&supported_unread_alert_category);
                }
                break;

                case BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_EMAIL__ALERT_WHEN_EMAIL_MESSAGES_ARRIVES:
                {
                    supported_unread_alert_category.is_email                       = false;
                    R_BLE_ANS_SetSupportedUnreadAlertCategory(&supported_unread_alert_category);
                }
                break;

                case BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_NEWS__NEWS_FEEDS_SUCH_AS_RSS__ATOM:
                {
                    supported_unread_alert_category.is_news                        = false;
                    R_BLE_ANS_SetSupportedUnreadAlertCategory(&supported_unread_alert_category);
                }
                break;

                case BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID__CALL__INCOMING_CALL:
                {
                    supported_unread_alert_category.is_call                        = false;
                    R_BLE_ANS_SetSupportedUnreadAlertCategory(&supported_unread_alert_category);
                }
                break;

                case BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_MISSED_CALL__MISSED_CALL:
                {
                    supported_unread_alert_category.is_missed_call                 = false;
                    R_BLE_ANS_SetSupportedUnreadAlertCategory(&supported_unread_alert_category);
                }
                break;

                case BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_SMS_MMS__SMS_MMS_MESSAGE_ARRIVES:
                {
                    supported_unread_alert_category.is_sms_mms                     = false;
                    R_BLE_ANS_SetSupportedUnreadAlertCategory(&supported_unread_alert_category);
                }
                break;

                case BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_VOICE_MAIL__VOICE_MAIL:
                {
                    supported_unread_alert_category.is_voice_mail                  = false;
                    
                    R_BLE_ANS_SetSupportedUnreadAlertCategory(&supported_unread_alert_category);
                }
                break;

                case BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_SCHEDULE__ALERT_OCCURRED_ON_CALENDAR__PLANNER:
                {
                    supported_unread_alert_category.is_schedule                    = false;
                    R_BLE_ANS_SetSupportedUnreadAlertCategory(&supported_unread_alert_category);
                }
                break;

                case BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_HIGH_PRIORITIZED_ALERT__ALERT_THAT_SHOULD_BE_HANDLED_AS_HIGH_PRIORITY:
                {
                    supported_unread_alert_category.is_high_prioritized_alert      = false;
                    R_BLE_ANS_SetSupportedUnreadAlertCategory(&supported_unread_alert_category);
                }
                break;

                case BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_INSTANT_MESSAGE__ALERT_FOR_INCOMING_INSTANT_MESSAGES:
                {
                    supported_unread_alert_category.is_instant_message             = false;
                    R_BLE_ANS_SetSupportedUnreadAlertCategory(&supported_unread_alert_category);
                }
                break;

                case BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_ALL:
                {
                    /*All other flags making true*/
                    supported_unread_alert_category.is_simple_alert           = false;
                    supported_unread_alert_category.is_email                  = false;
                    supported_unread_alert_category.is_news                   = false;
                    supported_unread_alert_category.is_call                   = false;
                    supported_unread_alert_category.is_missed_call            = false;
                    supported_unread_alert_category.is_sms_mms                = false;
                    supported_unread_alert_category.is_voice_mail             = false;
                    supported_unread_alert_category.is_schedule               = false;
                    supported_unread_alert_category.is_high_prioritized_alert = false;
                    supported_unread_alert_category.is_instant_message        = false;
                    
                    R_BLE_ANS_SetSupportedUnreadAlertCategory(&supported_unread_alert_category);
                }
                break;

                default:
                {
                    /* DO NOTHING*/
                }
                break;
            }
            
            gs_ans_cb(BLE_ANS_EVENT_ALERT_NOTIFICATION_CONTROL_POINT_WRITE_REQ, BLE_SUCCESS, &evt_data);
        }
        break;

        case BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_COMMAND_ID_NOTIFY_NEW_INCOMING_ALERT_IMMEDIATELY:
        {
            /* Check if Notification Enabled for the Control Point */
            ret = get_cli_cnfg(gs_conn_hdl, BLE_ANS_NEW_ALERT_CLI_CNFG_DESC_HDL, &cli_cfg);

            if (cli_cfg & BLE_GATTS_CLI_CNFG_NOTIFICATION)
            {
                gs_ans_cb(BLE_ANS_EVENT_ALERT_NOTIFICATION_CONTROL_POINT_WRITE_REQ, BLE_SUCCESS, &evt_data);
            }
            else
            {
                R_BLE_GATTS_SendErrRsp(ret);
            }
        }
        break;

        case BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_COMMAND_ID_NOTIFY_UNREAD_CATEGORY_STATUS_IMMEDIATELY:
        {
            /* Check if Notification Enabled for the Control Point */
            ret = get_cli_cnfg(gs_conn_hdl, BLE_ANS_UNREAD_ALERT_STATUS_CLI_CNFG_DESC_HDL, &cli_cfg);

            if (cli_cfg & BLE_GATTS_CLI_CNFG_NOTIFICATION)
            {
                gs_ans_cb(BLE_ANS_EVENT_ALERT_NOTIFICATION_CONTROL_POINT_WRITE_REQ, BLE_SUCCESS, &evt_data);
            }
            else
            {
                R_BLE_GATTS_SendErrRsp(ret);
            }
        }
        break;

        default:
        {
            /* Do Nothing */
        }
        break;
    }
}
/* End of function ans_cp_event_cb */

/***********************************************************************************************************************
 * Function Name: evt_write_req_alert_notification_control_point
 * Description  : This function handles the Alert Notification Control Point characteristic write request event.
 * Arguments    : conn_hdl - connection handle
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static void evt_write_req_alert_notification_control_point(uint16_t conn_hdl, st_ble_gatt_value_t *p_gatt_value)
{
    ble_status_t ret;

    /* Alert Notification Control Point Notification Enabled */
    ret = decode_alert_notification_control_point(&gs_ans_control_point, p_gatt_value);

    if (BLE_SUCCESS == ret)
    {
        gs_conn_hdl = conn_hdl;

        /* Set an event to execute the control point */
        R_BLE_SetEvent(ans_cp_event_cb);
    }
    else if (BLE_ERR_INVALID_DATA == ret)
    {           
        st_ble_ans_evt_data_t evt_data =
        {
            .conn_hdl  = gs_conn_hdl,
            .param_len = sizeof(gs_ans_control_point),
            .p_param   = &gs_ans_control_point,
        };
        
        gs_ans_cb(gs_ans_control_point.category_id, ret, &evt_data);
    }
    else
    {
        R_BLE_GATTS_SendErrRsp(ret);
    }
}
/* End of function evt_write_req_alert_notification_control_point */

/***********************************************************************************************************************
 * Function Name: ans_gatts_db_cb
 * Description  : Callback function for Alert Notification Service GATT Server events.
 * Arguments    : conn_hdl - handle to the connection
 *                p_params - pointer to GATTS db parameter
 * Return Value : none
 **********************************************************************************************************************/
static void ans_gatts_db_cb(uint16_t conn_hdl, st_ble_gatts_db_params_t *p_params) // @suppress("Function length")
{

    switch (p_params->db_op)
    {
        case BLE_GATTS_OP_CHAR_PEER_WRITE_REQ:
        {
            if (BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_VAL_HDL == p_params->attr_hdl)
            {
                evt_write_req_alert_notification_control_point(conn_hdl, &p_params->value);
            }
        } 
        break;

        case BLE_GATTS_OP_CHAR_PEER_CLI_CNFG_WRITE_REQ:
        {
            uint16_t cli_cnfg;

            st_ble_ans_evt_data_t evt_data =
            {
                .conn_hdl = conn_hdl,
                .param_len = 0,
                .p_param = NULL,
            };

            BT_UNPACK_LE_2_BYTE(&cli_cnfg, p_params->value.p_value);

            if (BLE_ANS_NEW_ALERT_CLI_CNFG_DESC_HDL == p_params->attr_hdl)
            {
                if (BLE_GATTS_CLI_CNFG_NOTIFICATION == cli_cnfg)
                {
                    gs_ans_cb(BLE_ANS_EVENT_NEW_ALERT_CLI_CNFG_ENABLED, BLE_SUCCESS, &evt_data);
                }
                else
                {
                    gs_ans_cb(BLE_ANS_EVENT_NEW_ALERT_CLI_CNFG_DISABLED, BLE_SUCCESS, &evt_data);
                }
            }
            else if (BLE_ANS_UNREAD_ALERT_STATUS_CLI_CNFG_DESC_HDL == p_params->attr_hdl)
            {
                if (BLE_GATTS_CLI_CNFG_NOTIFICATION == cli_cnfg)
                {
                    gs_ans_cb(BLE_ANS_EVENT_UNREAD_ALERT_STATUS_CLI_CNFG_ENABLED, BLE_SUCCESS, &evt_data);
                }
                else
                {
                    gs_ans_cb(BLE_ANS_EVENT_UNREAD_ALERT_STATUS_CLI_CNFG_DISABLED, BLE_SUCCESS, &evt_data);
                }
            }
            else
            {
                /* DO NOTHING*/
            }
        } 
        break;

        default:
        {
            /* DO NOTHING*/
        } 
        break;
    }
}
/* End of function ans_gatts_db_cb */

/***********************************************************************************************************************
 * Function Name: ans_gatts_cb
 * Description  : Callback function for the GATT Server events.
 * Arguments    : type - event id
 *                result - ble status
 *                p_data - pointer to the event data
 * Return Value : none
 **********************************************************************************************************************/
static void ans_gatts_cb(uint16_t type, ble_status_t result, st_ble_gatts_evt_data_t *p_data)
{
    switch (type)
    {
        case BLE_GATTS_EVENT_DB_ACCESS_IND:
        {
            st_ble_gatts_db_access_evt_t *p_db_access_evt_param =
                (st_ble_gatts_db_access_evt_t *)p_data->p_param;

            ans_gatts_db_cb(p_data->conn_hdl, p_db_access_evt_param->p_params);
        } 
        break;

        default:
        {
            /* DO NOTHING*/
        } 
        break;
    }
}

ble_status_t R_BLE_ANS_Init(const st_ble_ans_init_param_t *p_param) // @suppress("API function naming")
{
    if (NULL == p_param)
    {
        return BLE_ERR_INVALID_PTR;
    }

    if (NULL == p_param->cb)
    {
        return BLE_ERR_INVALID_ARG;
    }

    R_BLE_GATTS_RegisterCb(ans_gatts_cb, 2);

    gs_ans_cb = p_param->cb;

    return BLE_SUCCESS;
}

ble_status_t R_BLE_ANS_Connect(uint16_t conn_hdl, const st_ble_ans_connect_param_t *p_param) // @suppress("API function naming")
{
    if (BLE_GAP_INVALID_CONN_HDL == conn_hdl)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (NULL != p_param)
    {
        set_cli_cnfg(conn_hdl, BLE_ANS_NEW_ALERT_CLI_CNFG_DESC_HDL, p_param->new_alert_cli_cnfg);
        set_cli_cnfg(conn_hdl, BLE_ANS_UNREAD_ALERT_STATUS_CLI_CNFG_DESC_HDL, p_param->unread_alert_status_cli_cnfg);
    }

    return BLE_SUCCESS;
}

ble_status_t R_BLE_ANS_Disconnect(uint16_t conn_hdl, st_ble_ans_disconnect_param_t *p_param) // @suppress("API function naming")
{
    if (BLE_GAP_INVALID_CONN_HDL == conn_hdl)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (NULL != p_param)
    {
        get_cli_cnfg(conn_hdl, BLE_ANS_NEW_ALERT_CLI_CNFG_DESC_HDL, &p_param->new_alert_cli_cnfg);
        get_cli_cnfg(conn_hdl, BLE_ANS_UNREAD_ALERT_STATUS_CLI_CNFG_DESC_HDL, &p_param->unread_alert_status_cli_cnfg);
    }

    return BLE_SUCCESS;
}

ble_status_t R_BLE_ANS_GetSupportedNewAlertCategory(st_ble_ans_supported_new_alert_category_t *p_app_value) // @suppress("API function naming")
{
    st_ble_gatt_value_t gatt_value;
    ble_status_t ret;

    if (NULL == p_app_value)
    {
        return BLE_ERR_INVALID_PTR;
    }

    ret = R_BLE_GATTS_GetAttr(BLE_GAP_INVALID_CONN_HDL, BLE_ANS_SUPPORTED_NEW_ALERT_CATEGORY_VAL_HDL, &gatt_value);

    if (BLE_SUCCESS == ret)
    {
        ret = decode_supported_new_alert_category(p_app_value, &gatt_value);
    }

    return ret;
}

ble_status_t R_BLE_ANS_SetSupportedNewAlertCategory(const st_ble_ans_supported_new_alert_category_t *p_app_value) // @suppress("API function naming")
{
    ble_status_t ret;
    uint8_t byte_value[BLE_ANS_SUPPORTED_NEW_ALERT_CATEGORY_LEN] = { 0 };

    st_ble_gatt_value_t gatt_value = 
    {
        .p_value   = byte_value,
        .value_len = BLE_ANS_SUPPORTED_NEW_ALERT_CATEGORY_LEN,
    };

    ret = encode_supported_new_alert_category(p_app_value, &gatt_value);
    if (BLE_SUCCESS != ret)
    {
        return BLE_ERR_INVALID_DATA;
    }

        return R_BLE_GATTS_SetAttr(BLE_GAP_INVALID_CONN_HDL, BLE_ANS_SUPPORTED_NEW_ALERT_CATEGORY_VAL_HDL, &gatt_value);
}

ble_status_t R_BLE_ANS_NotifyNewAlert(uint16_t conn_hdl, const st_ble_ans_new_alert_t *p_app_value) // @suppress("API function naming")
{
    ble_status_t ret;
    uint16_t cli_cnfg;

    if (NULL == p_app_value)
    {
        return BLE_ERR_INVALID_PTR;
    }

    ret = get_cli_cnfg(conn_hdl, BLE_ANS_NEW_ALERT_CLI_CNFG_DESC_HDL, &cli_cnfg);

    if (BLE_SUCCESS != ret)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if ((cli_cnfg & BLE_GATTS_CLI_CNFG_NOTIFICATION) == 0x0000)
    {
        return BLE_ERR_INVALID_STATE;
    }


    uint8_t byte_value[BLE_ANS_NEW_ALERT_LEN] = { 0 };

    st_ble_gatt_hdl_value_pair_t ntf_data = 
    {
        .attr_hdl        = BLE_ANS_NEW_ALERT_VAL_HDL,
        .value.p_value   = byte_value,
        .value.value_len = BLE_ANS_NEW_ALERT_LEN,
    };

    ret = encode_new_alert(p_app_value, &ntf_data.value);
    if (BLE_SUCCESS != ret)
    {
        return BLE_ERR_INVALID_DATA;
    }

    return R_BLE_GATTS_Notification(conn_hdl, &ntf_data);
}

ble_status_t R_BLE_ANS_GetSupportedUnreadAlertCategory(st_ble_ans_supported_unread_alert_category_t *p_app_value) // @suppress("API function naming")
{
    st_ble_gatt_value_t gatt_value;
    ble_status_t ret;

    if (NULL == p_app_value)
    {
        return BLE_ERR_INVALID_PTR;
    }

    ret = R_BLE_GATTS_GetAttr(BLE_GAP_INVALID_CONN_HDL, BLE_ANS_SUPPORTED_UNREAD_ALERT_CATEGORY_VAL_HDL, &gatt_value);

    if (BLE_SUCCESS == ret)
    {
        ret = decode_supported_unread_alert_category(p_app_value, &gatt_value);
    }

    return ret;
}

ble_status_t R_BLE_ANS_SetSupportedUnreadAlertCategory(const st_ble_ans_supported_unread_alert_category_t *p_app_value) // @suppress("API function naming")
{
    ble_status_t ret;
    uint8_t byte_value[BLE_ANS_SUPPORTED_UNREAD_ALERT_CATEGORY_LEN] = { 0 };

    st_ble_gatt_value_t gatt_value = 
    {
        .p_value   = byte_value,
        .value_len = BLE_ANS_SUPPORTED_UNREAD_ALERT_CATEGORY_LEN,
    };

    ret = encode_supported_unread_alert_category(p_app_value, &gatt_value);

    if (BLE_SUCCESS != ret)
    {
        return BLE_ERR_INVALID_DATA;
    }

    return R_BLE_GATTS_SetAttr(BLE_GAP_INVALID_CONN_HDL, BLE_ANS_SUPPORTED_UNREAD_ALERT_CATEGORY_VAL_HDL, &gatt_value);
}

ble_status_t R_BLE_ANS_NotifyUnreadAlertStatus(uint16_t conn_hdl, const st_ble_ans_unread_alert_status_t *p_app_value) // @suppress("API function naming")
{
    ble_status_t ret;
    uint16_t cli_cnfg;

    if (NULL == p_app_value)
    {
        return BLE_ERR_INVALID_PTR;
    }

    ret = get_cli_cnfg(conn_hdl, BLE_ANS_UNREAD_ALERT_STATUS_CLI_CNFG_DESC_HDL, &cli_cnfg);

    if (BLE_SUCCESS != ret)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if ((cli_cnfg & BLE_GATTS_CLI_CNFG_NOTIFICATION) == 0x0000)
    {
        return BLE_ERR_INVALID_STATE;
    }

    uint8_t byte_value[BLE_ANS_UNREAD_ALERT_STATUS_LEN] = { 0 };

    st_ble_gatt_hdl_value_pair_t ntf_data = 
    {
        .attr_hdl        = BLE_ANS_UNREAD_ALERT_STATUS_VAL_HDL,
        .value.p_value   = byte_value,
        .value.value_len = BLE_ANS_UNREAD_ALERT_STATUS_LEN,
    };

    ret = encode_unread_alert_status(p_app_value, &ntf_data.value);

    if (BLE_SUCCESS != ret)
    {
        return BLE_ERR_INVALID_DATA;
    }
     
    return R_BLE_GATTS_Notification(conn_hdl, &ntf_data);
}

uint32_t R_BLE_ANS_GetVersion(void) // @suppress("API function naming")
{
    uint32_t version;

    version = ((BLE_ANS_PRV_VERSION_MAJOR << 16) | (BLE_ANS_PRV_VERSION_MINOR << 8));

    return version;
}
/* End of function ans_gatts_cb */

