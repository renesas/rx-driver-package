/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_ans.h
 * Version : 1.0
 * Description : The header file for Alert Notification Service service.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 20.12.2019 1.00 First Release
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @file
 * @defgroup ans Alert Notification Service Server
 * @{
 * @ingroup profile
 * @brief   Alert Notification Service exposes: The different types of alerts with the short text messages. The information how many count of new alert messages. The information how many count of unread alerts.
 **********************************************************************************************************************/

#include "profile_cmn/r_ble_servs_if.h"
#include "gatt_db.h"

#ifndef R_BLE_ANS_H
#define R_BLE_ANS_H

 /*******************************************************************************************************************//**
  * @brief New Alert Text length.
 ***********************************************************************************************************************/
#define BLE_ANS_NEW_ALERT_TEXT_LEN                          (18)


/*----------------------------------------------------------------------------------------------------------------------
    Supported New Alert Category Characteristic
----------------------------------------------------------------------------------------------------------------------*/
/***************************************************************************//**
 * @brief Supported New Alert Category value structure.
*******************************************************************************/
typedef struct
{
    bool is_simple_alert;            /**< is simple alert */
    bool is_email;                   /**< Is email */
    bool is_news;                    /**< is news */
    bool is_call;                    /**< is call */
    bool is_sms_mms;                 /**< is sms mms */
    bool is_missed_call;             /**< is missed call */
    bool is_voice_mail;              /**< is voice mail */
    bool is_schedule;                /**< is schedule */
    bool is_high_prioritized_alert;  /**< is high prioritized alert */
    bool is_instant_message;         /**< is instant message */
} st_ble_ans_supported_new_alert_category_t;

/***************************************************************************//**
 * @brief     Set Supported New Alert Category characteristic value to the local GATT database.
 * @param[in] p_value  Characteristic value to set pointer to supported new alert category.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ANS_SetSup_nw_alt_cat(const st_ble_ans_supported_new_alert_category_t *p_value);

/***************************************************************************//**
 * @brief     Get Supported New Alert Category characteristic value from the local GATT database.
 * @param[out] p_value Pointer to Retrieved Supported new alert category characteristic value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ANS_GetSup_nw_alt_cat(st_ble_ans_supported_new_alert_category_t *p_value);

/*----------------------------------------------------------------------------------------------------------------------
    New Alert Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/***************************************************************************//**
 * @brief New Alert value structure.
*******************************************************************************/
typedef struct
{
    uint8_t category_id;                                            /**< Category ID */
    uint8_t number_of_new_alert;                                    /**< Number of New Alert */
    uint8_t text_string_information[BLE_ANS_NEW_ALERT_TEXT_LEN];    /**< Text String Information */
} st_ble_ans_new_alert_t;

/***************************************************************************//**
 * @brief     Send notificatoin of  New Alert characteristic value to the remote device.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value  Characteristic value to send pointer to new alert category.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ANS_NotifyNew_alert(uint16_t conn_hdl, const st_ble_ans_new_alert_t *p_value);

/***************************************************************************//**
 * @brief     Set New Alert cli cnfg descriptor value to the local GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value  Descriptor value to set pointer to uint16_t.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ANS_SetNew_alerttCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Get New Alert cli cnfg descriptor value from the local GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ANS_GetNew_alertCliCnfg(uint16_t conn_hdl, uint16_t *p_value);

/*----------------------------------------------------------------------------------------------------------------------
    Supported Unread Alert Category Characteristic
----------------------------------------------------------------------------------------------------------------------*/
/***************************************************************************//**
 * @brief Supported Unread Alert Category value structure.
*******************************************************************************/
typedef struct
{
    bool is_simple_alert;                   /**< is simple alert */
    bool is_email;                          /**< Is email */
    bool is_news;                           /**< is news */
    bool is_call;                           /**< is call */
    bool is_sms_mms;                        /**< is sms mms */
    bool is_missed_call;                    /**< is missed call */
    bool is_voice_mail;                     /**< is voice mail */
    bool is_schedule;                       /**< is schedule */
    bool is_high_prioritized_alert;         /**< is high prioritized alert */
    bool is_instant_message;                /**< is instant message */
} st_ble_ans_supported_unread_alert_category_t;

/***************************************************************************//**
 * @brief     Set Supported Unread Alert Category characteristic value to the local GATT database.
 * @param[in] p_value  Characteristic value to set pointer to supported unread alert category.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ANS_SetSup_un_alt_cat(const st_ble_ans_supported_unread_alert_category_t *p_value);

/***************************************************************************//**
 * @brief     Get Supported Unread Alert Category characteristic value from the local GATT database.
 * @param[out] p_value  Pointer to Retrieved Supported unread alert category characteristic value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ANS_GetSup_un_alt_cat(st_ble_ans_supported_unread_alert_category_t *p_value);

/*----------------------------------------------------------------------------------------------------------------------
    Unread Alert Status Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/***************************************************************************//**
 * @brief Unread Alert Status value structure.
*******************************************************************************/
typedef struct
{
    uint8_t category_id;    /**< Category ID */
    uint8_t unread_count;   /**< Unread count */
} st_ble_ans_unread_alert_status_t;

/***************************************************************************//**
 * @brief     Send notificatoin of  Unread Alert Status characteristic value to the remote device.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value  pointer to unread alert Characteristic value to send .
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ANS_NotifyUnread_alt_st(uint16_t conn_hdl, const st_ble_ans_unread_alert_status_t *p_value);

/***************************************************************************//**
 * @brief     Set Unread Alert Status cli cnfg descriptor value to the local GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value  Descriptor value to set pointer to uint16_t.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ANS_SetUnd_at_stCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Get Unread Alert Status cli cnfg descriptor value from the local GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ANS_GetUnd_at_stCliCnfg(uint16_t conn_hdl, uint16_t *p_value);

/*----------------------------------------------------------------------------------------------------------------------
    Alert Notification Control Point Characteristic
----------------------------------------------------------------------------------------------------------------------*/
/***************************************************************************//**
 * @brief Alert Notification Control Point Command ID enumeration.
*******************************************************************************/
typedef enum
{
    BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_COMMAND_ID_ENABLE_NEW_INCOMING_ALERT_NOTIFICATION      = 0, /**< Enable New Incoming Alert Notification */
    BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_COMMAND_ID_ENABLE_UNREAD_CATEGORY_STATUS_NOTIFICATION  = 1, /**< Enable Unread Category Status Notification */
    BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_COMMAND_ID_DISABLE_NEW_INCOMING_ALERT_NOTIFICATION     = 2, /**< Disable New Incoming Alert Notification */
    BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_COMMAND_ID_DISABLE_UNREAD_CATEGORY_STATUS_NOTIFICATION = 3, /**< Disable Unread Category Status Notification */
    BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_COMMAND_ID_NOTIFY_NEW_INCOMING_ALERT_IMMEDIATELY       = 4, /**< Notify New Incoming Alert immediately */
    BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_COMMAND_ID_NOTIFY_UNREAD_CATEGORY_STATUS_IMMEDIATELY   = 5, /**< Notify Unread Category Status immediately */
} e_ble_ans_alert_notification_control_point_command_id_t;

/***************************************************************************//**
 * @brief Alert Notification Control Point Category ID enumeration.
*******************************************************************************/
typedef enum
{
    BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_SIMPLE_ALERT__GENERAL_TEXT_ALERT_OR_NON_TEST_ALERT                     = 0, /**< Simple Alert: General or non */
    BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_EMAIL__ALERT_WHEN_EMAIL_MESSAGES_ARRIVES                               = 1, /**< Email: Alert when Email messages arrives */
    BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_NEWS_NEWS_FEEDS_SUCH_AS_RSS_ATOM                                       = 2, /**< News: News feeds such as RSS, Atom */
    BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_CALL_INCOMING_CALL                                                     = 3, /**< Call: Incoming call  */
    BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_MISSED_CALL_MISSED_CALL                                                = 4, /**< Missed call: Missed Call */
    BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_SMS_MMS__SMS_MMS_MESSAGES_ARRIVES                                      = 5, /**< SMS/MMS: SMS/MMS message arrives */
    BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_VOICE_MAIL__VOICE_MAIL                                                 = 6, /**< Voice mail: Voice mail */
    BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_SCHEDULE__ALERT_OCCURED_ON_CALENDAR_PLANNER                            = 7, /**< Schedule: Alert occurred on calendar, planner */
    BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_HIGH_PRIORITIDED_ALERT__ALERT_THAT_SHOULD_BE_HANDLED_AS_HIGH_PRIORITY  = 8, /**< High Prioritized Alert: Alert that should be handled as high priority */
    BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_INSTANT_MESSAGE_ALERT_FOR_INCOMING_INSTANT_MESSAGES                    = 9, /**< Instant Message: Alert for incoming instant messages */
    BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_ALL                                                                    = 255, /**< Category ID: All category(0xff) */
} e_ble_ans_alert_notification_control_point_category_id_t;

/***************************************************************************//**
 * @brief Alert Notification Control Point value structure.
*******************************************************************************/
typedef struct
{
    uint8_t command_id;  /**< Command ID */
    uint8_t category_id; /**< Category ID */
} st_ble_ans_alert_notification_control_point_t;

/*----------------------------------------------------------------------------------------------------------------------
    Alert Notification Service Service
----------------------------------------------------------------------------------------------------------------------*/
/*******************************************************************************************************************//**
  * @brief Command not supported error code.
 ***********************************************************************************************************************/
#define BLE_ANS_COMMAND_NOT_SUPPORTED                       (BLE_ERR_GROUP_GATT | 0xA0)

/*******************************************************************************************************************//**
 * @brief Write Request Rejected error code.
***********************************************************************************************************************/
#define BLE_ANS_PRV_WRITE_REQUEST_REJECTED                  (BLE_ERR_GROUP_GATT | 0xA1)

/***************************************************************************//**
 * @brief Alert Notification Service characteristic Index.
*******************************************************************************/
typedef enum
{
    BLE_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IDX,
    BLE_ANS_NEW_ALERT_IDX,
    BLE_ANS_NEW_ALERT_CLI_CNFG_IDX,
    BLE_ANS_SUPPORTED_UNREAD_ALERT_CATEGORY_IDX,
    BLE_ANS_UNREAD_ALERT_STATUS_IDX,
    BLE_ANS_UNREAD_ALERT_STATUS_CLI_CNFG_IDX,
    BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_IDX,
} e_ble_ans_char_idx_t;

/***************************************************************************//**
 * @brief Alert Notification Service event type.
*******************************************************************************/
typedef enum
{
    /* Supported New Alert Category */
    BLE_ANS_EVENT_SUPPORTED_NEW_ALERT_CATEGORY_READ_REQ         = BLE_SERVS_ATTR_EVENT(BLE_ANS_SUPPORTED_NEW_ALERT_CATEGORY_IDX, BLE_SERVS_READ_REQ),

    /* New Alert */
    BLE_ANS_EVENT_NEW_ALERT_CLI_CNFG_WRITE_REQ                  = BLE_SERVS_ATTR_EVENT(BLE_ANS_NEW_ALERT_CLI_CNFG_IDX, BLE_SERVS_WRITE_REQ),
    BLE_ANS_EVENT_NEW_ALERT_CLI_CNFG_WRITE_COMP                 = BLE_SERVS_ATTR_EVENT(BLE_ANS_NEW_ALERT_CLI_CNFG_IDX, BLE_SERVS_WRITE_COMP),
    BLE_ANS_EVENT_NEW_ALERT_CLI_CNFG_READ_REQ                   = BLE_SERVS_ATTR_EVENT(BLE_ANS_NEW_ALERT_CLI_CNFG_IDX, BLE_SERVS_READ_REQ),

    /* Supported Unread Alert Category */
    BLE_ANS_EVENT_SUPPORTED_UNREAD_ALERT_CATEGORY_READ_REQ      = BLE_SERVS_ATTR_EVENT(BLE_ANS_SUPPORTED_UNREAD_ALERT_CATEGORY_IDX, BLE_SERVS_READ_REQ),

    /* Unread Alert Status */
    BLE_ANS_EVENT_UNREAD_ALERT_STATUS_CLI_CNFG_WRITE_REQ        = BLE_SERVS_ATTR_EVENT(BLE_ANS_UNREAD_ALERT_STATUS_CLI_CNFG_IDX, BLE_SERVS_WRITE_REQ),
    BLE_ANS_EVENT_UNREAD_ALERT_STATUS_CLI_CNFG_WRITE_COMP       = BLE_SERVS_ATTR_EVENT(BLE_ANS_UNREAD_ALERT_STATUS_CLI_CNFG_IDX, BLE_SERVS_WRITE_COMP),
    BLE_ANS_EVENT_UNREAD_ALERT_STATUS_CLI_CNFG_READ_REQ         = BLE_SERVS_ATTR_EVENT(BLE_ANS_UNREAD_ALERT_STATUS_CLI_CNFG_IDX, BLE_SERVS_READ_REQ),

    /* Alert Notification Control Point */
    BLE_ANS_EVENT_ALERT_NOTIFICATION_CONTROL_POINT_WRITE_REQ    = BLE_SERVS_ATTR_EVENT(BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_IDX, BLE_SERVS_WRITE_REQ),
    BLE_ANS_EVENT_ALERT_NOTIFICATION_CONTROL_POINT_WRITE_COMP   = BLE_SERVS_ATTR_EVENT(BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_IDX, BLE_SERVS_WRITE_COMP),
} e_ble_ans_event_t;

/***************************************************************************//**
 * @brief     Initialize Alert Notification Service service.
 * @param[in] cb Service callback.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ANS_Init(ble_servs_app_cb_t cb);

#endif /* R_BLE_ANS_H */

/** @} */
