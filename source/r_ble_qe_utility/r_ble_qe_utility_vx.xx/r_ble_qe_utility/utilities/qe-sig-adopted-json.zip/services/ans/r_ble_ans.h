/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
 * File Name   : r_ble_ans.h
 * Version     : 1.0
 * Description : This module implements Alert Notification Service Server.
 **********************************************************************************************************************/

/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 24.05.2019 1.00 First Release
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @file
 * @defgroup ans Alert Notification Service
 * @{
 * @ingroup profile
 * @brief   This file provides APIs to interface Alert Notification Service.
 **********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/

#include "r_ble_rx23w_if.h"

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
#ifndef R_BLE_ANS_H
#define R_BLE_ANS_H

/*******************************************************************************************************************//**
 * @brief New Alert Text length.
***********************************************************************************************************************/
#define BLE_ANS_NEW_ALERT_TEXT_LEN                          (18)

/*******************************************************************************************************************//**
 * @brief Supported New Alert Category characteristic value length.
***********************************************************************************************************************/
#define BLE_ANS_SUPPORTED_NEW_ALERT_CATEGORY_LEN            (2)
/*******************************************************************************************************************//**
 * @brief New Alert characteristic value length.
***********************************************************************************************************************/
#define BLE_ANS_NEW_ALERT_LEN                               (20)
/*******************************************************************************************************************//**
 * @brief Supported Unread Alert Category characteristic value length.
***********************************************************************************************************************/
#define BLE_ANS_SUPPORTED_UNREAD_ALERT_CATEGORY_LEN         (2)
/*******************************************************************************************************************//**
 * @brief Unread Alert Status characteristic value length.
***********************************************************************************************************************/
#define BLE_ANS_UNREAD_ALERT_STATUS_LEN                     (2)
/*******************************************************************************************************************//**
 * @brief Alert Notification Control Point characteristic value length.
***********************************************************************************************************************/
#define BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_LEN        (2)
/*******************************************************************************************************************//**
/*******************************************************************************************************************//**
 * @brief Command not supported error code.
***********************************************************************************************************************/
#define BLE_ANS_COMMAND_NOT_SUPPORTED                       (BLE_ERR_GROUP_GATT | 0xA0)

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @brief Alert Notification Service event data.
***********************************************************************************************************************/
typedef struct
{
    uint16_t  conn_hdl;                                                /**< Connection handle */
    uint16_t  param_len;                                               /**< Event parameter length */
    void     *p_param;                                                 /**< Event parameter */
} st_ble_ans_evt_data_t;

/*******************************************************************************************************************//**
 * @brief Alert Notification Service event callback.
***********************************************************************************************************************/
typedef void (*ble_ans_app_cb_t)(uint16_t type, ble_status_t result, st_ble_ans_evt_data_t *data);

/*******************************************************************************************************************//**
 * @brief Alert Notification Service event type.
***********************************************************************************************************************/
typedef enum 
{
    BLE_ANS_EVENT_NEW_ALERT_CLI_CNFG_ENABLED,                 /**< New Alert characteristic cli cnfg enabled event */
    BLE_ANS_EVENT_NEW_ALERT_CLI_CNFG_DISABLED,                /**< New Alert characteristic cli cnfg disabled event */
    BLE_ANS_EVENT_UNREAD_ALERT_STATUS_CLI_CNFG_ENABLED,       /**< Unread Alert Status characteristic cli cnfg enabled 
    event */
    BLE_ANS_EVENT_UNREAD_ALERT_STATUS_CLI_CNFG_DISABLED,      /**< Unread Alert Status characteristic cli cnfg disabled 
    event */
    BLE_ANS_EVENT_ALERT_NOTIFICATION_CONTROL_POINT_WRITE_REQ, /**< Alert Notification Control Point characteristic write 
    request event */
    BLE_ANS_EVENT_SUPPORTED_NEW_ALERT_CATEGORY_READ_REQ,      /**< Supported New Alert Category characteristic read 
    request event */
    BLE_ANS_EVENT_SUPPORTED_UNREAD_ALERT_CATEGORY_READ_REQ,   /**< Supported Unread Alert Category characteristic read 
    request event */
} e_ble_ans_event_t;

/*******************************************************************************************************************//**
 * @brief Command ID enumeration.
***********************************************************************************************************************/
typedef enum 
{
    BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_COMMAND_ID_ENABLE_NEW_INCOMING_ALERT_NOTIFICATION       = 0,     
    /**< Enable New Incoming Alert Notification */
    BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_COMMAND_ID_ENABLE_UNREAD_CATEGORY_STATUS_NOTIFICATION   = 1,     
    /**< Enable Unread Category Status Notification */
    BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_COMMAND_ID_DISABLE_NEW_INCOMING_ALERT_NOTIFICATION      = 2,     
    /**< Disable New Incoming Alert Notification */
    BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_COMMAND_ID_DISABLE_UNREAD_CATEGORY_STATUS_NOTIFICATION  = 3,     
    /**< Disable Unread Category Status Notification */
    BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_COMMAND_ID_NOTIFY_NEW_INCOMING_ALERT_IMMEDIATELY        = 4,     
    /**< Notify New Incoming Alert immediately */
    BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_COMMAND_ID_NOTIFY_UNREAD_CATEGORY_STATUS_IMMEDIATELY    = 5,     
    /**< Notify Unread Category Status immediately */
} e_ble_ans_alert_notification_control_point_command_id_t;

/*******************************************************************************************************************//**
 * @brief Category ID enumeration.
***********************************************************************************************************************/
typedef enum 
{
    BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_SIMPLE_ALERT__GENERAL_TEXT_ALERT_OR_NON_TEXT_ALERT  
    = 0,    /**< Simple Alert: General or non */
    BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_EMAIL__ALERT_WHEN_EMAIL_MESSAGES_ARRIVES                              
    = 1,    /**< Email: Alert when Email messages arrives */
    BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_NEWS__NEWS_FEEDS_SUCH_AS_RSS__ATOM                                    
    = 2,    /**< News: News feeds such as RSS, Atom */
    BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID__CALL__INCOMING_CALL                                                  
    = 3,    /**< Call: Incoming call */
    BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_MISSED_CALL__MISSED_CALL                                              
    = 4,    /**< Missed call: Missed Call */
    BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_SMS_MMS__SMS_MMS_MESSAGE_ARRIVES                                      
    = 5,    /**< SMS/MMS: SMS/MMS message arrives */
    BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_VOICE_MAIL__VOICE_MAIL                                                
    = 6,    /**< Voice mail: Voice mail */
    BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_SCHEDULE__ALERT_OCCURRED_ON_CALENDAR__PLANNER                         
    = 7,    /**< Schedule: Alert occurred on calendar, planner */
    BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_HIGH_PRIORITIZED_ALERT__ALERT_THAT_SHOULD_BE_HANDLED_AS_HIGH_PRIORITY 
    = 8,    /**< High Prioritized Alert: Alert that should be handled as high priority */
    BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_INSTANT_MESSAGE__ALERT_FOR_INCOMING_INSTANT_MESSAGES                  
    = 9,    /**< Instant Message: Alert for incoming instant messages */
    BLE_ANS_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_ALL                                                            
    = 0xFF, /**< Category ID: All category(0xff) */
} e_ble_ans_alert_notification_control_point_category_id_t;

/*******************************************************************************************************************//**
 * @brief Alert Notification Service initialization parameters.
***********************************************************************************************************************/
typedef struct
{
    ble_ans_app_cb_t cb;                                               /**< Alert Notification Service event callback */
} st_ble_ans_init_param_t;

/*******************************************************************************************************************//**
 * @brief Alert Notification Service connection parameters.
***********************************************************************************************************************/
typedef struct
{
    uint16_t new_alert_cli_cnfg;                                      /**< New Alert characteristic cli cnfg */
    uint16_t unread_alert_status_cli_cnfg;                            /**< Unread Alert Status characteristic cli cnfg */
} st_ble_ans_connect_param_t;

/*******************************************************************************************************************//**
 * @brief Alert Notification Service disconnection parameters.
***********************************************************************************************************************/
typedef struct 
{
    uint16_t new_alert_cli_cnfg;                                     /**< New Alert characteristic cli cnfg */
    uint16_t unread_alert_status_cli_cnfg;                           /**< Unread Alert Status characteristic cli cnfg */
} st_ble_ans_disconnect_param_t;

/*******************************************************************************************************************//**
 * @brief Supported New Alert Category characteristic parameters.
***********************************************************************************************************************/
typedef struct
{
    bool is_simple_alert;                                      /**< Simple Alert field is supported or not*/
    bool is_email;                                             /**< Email field is supported or not*/
    bool is_news;                                              /**< News field is supported or not*/
    bool is_call;                                              /**< Call field is supported or not*/
    bool is_missed_call;                                       /**< Missed call field is supported or not*/ 
    bool is_sms_mms;                                           /**< SMS MMS field is supported or not*/ 
    bool is_voice_mail;                                        /**< Voice mail field is supported or not*/                                    
    bool is_schedule;                                          /**< Schedule field is supported or not*/ 
    bool is_high_prioritized_alert;                            /**< High Prioritized Alert field is supported or not*/ 
    bool is_instant_message;                                   /**< Instant_Message Alert field is supported or not*/ 
} st_ble_ans_supported_new_alert_category_t;

/*******************************************************************************************************************//**
 * @brief New Alert characteristic parameters.
***********************************************************************************************************************/
typedef struct 
{
    uint8_t category_id;                                              /**< Category ID value */
    uint8_t number_of_new_alert;                                      /**< Number of New Alert value */
    uint8_t text_string_information[BLE_ANS_NEW_ALERT_TEXT_LEN];      /**< Text String Information value */
} st_ble_ans_new_alert_t;

/*******************************************************************************************************************//**
 * @brief Supported Unread Alert Category characteristic parameters.
***********************************************************************************************************************/
typedef struct
{
    bool is_simple_alert;                                       /**< Simple Alert field is supported or not*/
    bool is_email;                                              /**< Email field is supported or not*/
    bool is_news;                                               /**< News field is supported or not*/
    bool is_call;                                               /**< Call field is supported or not*/
    bool is_missed_call;                                        /**< Missed call field is supported or not*/
    bool is_sms_mms;                                            /**< SMS MMS field is supported or not*/
    bool is_voice_mail;                                         /**< Voice mail field is supported or not*/
    bool is_schedule;                                           /**< Schedule field is supported or not*/
    bool is_high_prioritized_alert;                             /**< High Prioritized Alert field is supported or not*/
    bool is_instant_message;                                    /**< Instant_Message Alert field is supported or not*/
} st_ble_ans_supported_unread_alert_category_t;

/*******************************************************************************************************************//**
 * @brief Unread Alert Status characteristic parameters.
***********************************************************************************************************************/
typedef struct 
{
    uint8_t category_id;                                            /**< Category ID value */
    uint8_t unread_count;                                           /**< Unread count value */
} st_ble_ans_unread_alert_status_t;

/*******************************************************************************************************************//**
 * @brief Alert Notification Control Point characteristic parameters.
***********************************************************************************************************************/
typedef struct
{
    uint8_t command_id;                                             /**< Command ID value */
    uint8_t category_id;                                            /**< Category ID value */
} st_ble_ans_alert_notification_control_point_t;


/*******************************************************************************************************************//**
Exported global functions (to be accessed by other files)
***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @brief     Initialize Alert Notification Service .
 * @details   This function shall be called once at startup.
 * @param[in] p_param Pointer to Alert Notification Service  initialization parameters.
 * @return
***********************************************************************************************************************/
ble_status_t R_BLE_ANS_Init(const st_ble_ans_init_param_t *p_param);

/*******************************************************************************************************************//**
 * @brief     Perform Alert Notification Service connection settings.
 * @details   This function shall be called on each connection establishment.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_param    Pointer to Connection parameters.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_ANS_Connect(uint16_t conn_hdl, const st_ble_ans_connect_param_t *p_param);

/*******************************************************************************************************************//**
 * @brief     Retrieve Alert Notification Service connection specific settings before disconnection.
 * @details   This function shall be called on each disconnection.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_param   Pointer to Disconnection parameters.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_ANS_Disconnect(uint16_t conn_hdl, st_ble_ans_disconnect_param_t *p_param);

/*******************************************************************************************************************//**
 * @brief      Get Supported New Alert Category characteristic value from local GATT database.
 * @param[out] p_app_value  Pointer to Retrieved Supported New Alert Category characteristic value.
 * @return     @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_ANS_GetSupportedNewAlertCategory(st_ble_ans_supported_new_alert_category_t *p_app_value);

/*******************************************************************************************************************//**
 * @brief     Set Supported New Alert Category characteristic value to local GATT database.
 * @param[in] p_app_value  Pointer to Supported New Alert Category characteristic value to set.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_ANS_SetSupportedNewAlertCategory(const st_ble_ans_supported_new_alert_category_t *p_app_value);

/*******************************************************************************************************************//**
 * @brief     Send New Alert notification.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] p_app_value  Pointer to New Alert value to send.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_ANS_NotifyNewAlert(uint16_t conn_hdl, const st_ble_ans_new_alert_t *p_app_value);

/*******************************************************************************************************************//**
 * @brief      Get Supported Unread Alert Category characteristic value from local GATT database.
 * @param[out] p_app_value  Pointer to Retrieved Supported Unread Alert Category characteristic value.
 * @return     @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_ANS_GetSupportedUnreadAlertCategory(st_ble_ans_supported_unread_alert_category_t *p_app_value);

/*******************************************************************************************************************//**
 * @brief     Set Supported Unread Alert Category characteristic value to local GATT database.
 * @param[in] p_app_value  Pointer to Supported Unread Alert Category characteristic value to set.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_ANS_SetSupportedUnreadAlertCategory(const st_ble_ans_supported_unread_alert_category_t *p_app_value);

/*******************************************************************************************************************//**
 * @brief     Send Unread Alert Status notification.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] p_app_value  Pointer to Unread Alert Status value to send.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_ANS_NotifyUnreadAlertStatus(uint16_t conn_hdl, const st_ble_ans_unread_alert_status_t *p_app_value);

/*******************************************************************************************************************//**
 * @brief     Return version of the ANS service server.
 * @return    version
***********************************************************************************************************************/
uint32_t R_BLE_ANS_GetVersion(void);

#endif /* R_BLE_ANS_H */

/** @} */
