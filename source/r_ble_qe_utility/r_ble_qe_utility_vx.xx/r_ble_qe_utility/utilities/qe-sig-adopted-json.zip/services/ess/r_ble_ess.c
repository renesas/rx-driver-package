/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_ess.c
 * Version : 1.0
 * Description : The source file for Environmental Sensing service.
 **********************************************************************************************************************/
#include <string.h>
#include "r_ble_ess.h"
#include "profile_cmn/r_ble_servs_if.h"
#include "gatt_db.h"

/***********************************************************************************************************************
Descriptor value change macro definitions
***********************************************************************************************************************/
#define BLE_ESS_PRV_DESCRIPTER_VALUE_CHANGED_FLAG_SOURCE_OF_CHANGE                                        ( 1 << 0 )
#define BLE_ESS_PRV_DESCRIPTER_VALUE_CHANGED_FLAG_CHANGE_TO_MORE_ES_TRIGGER_SETTING_DESCRIPTORS           ( 1 << 1 )
#define BLE_ESS_PRV_DESCRIPTER_VALUE_CHANGED_FLAG_CHANGE_TO_ES_CONFIGURATION_DESCRIPTOR                   ( 1 << 2 )
#define BLE_ESS_PRV_DESCRIPTER_VALUE_CHANGED_FLAG_CHANGE_TO_ES_MEASUREMENT_DESCRIPTOR                     ( 1 << 3 )
#define BLE_ESS_PRV_DESCRIPTER_VALUE_CHANGED_FLAG_CHANGE_TO_CHARACTERISTIC_USER_DESCRIPTION_DESCRIPTOR    ( 1 << 4 )

static st_ble_servs_info_t gs_servs_info;

/*----------------------------------------------------------------------------------------------------------------------
    Descriptor Value Changed Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

static const st_ble_servs_desc_info_t gs_desc_value_changed_cli_cnfg = {
    .attr_hdl = BLE_ESS_DESC_VALUE_CHANGED_CLI_CNFG_DESC_HDL,
    .app_size = sizeof(uint16_t),
    .desc_idx = BLE_ESS_DESC_VALUE_CHANGED_CLI_CNFG_IDX,
    .db_size  = BLE_ESS_DESC_VALUE_CHANGED_CLI_CNFG_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_uint16_t,
    .encode   = (ble_servs_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_ESS_SetDescValueChangedCliCnfg(const uint16_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_desc_value_changed_cli_cnfg, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_ESS_GetDescValueChangedCliCnfg(uint16_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_desc_value_changed_cli_cnfg, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Descriptor Value Changed characteristic
----------------------------------------------------------------------------------------------------------------------*/
/***********************************************************************************************************************
* Function Name: decode_st_ble_ess_desc_value_changed_t
* Description  : This function converts descriptor value changed characteristic representation in
*                GATT (uint8_t[]) to representation in application layer (struct).
* Arguments    : p_app_value  - Pointer to the characteristic value in the application layer
*                p_gatt_value - Pointer to the characteristic value in the GATT database
* Return Value : ble_status_t
**********************************************************************************************************************/
static ble_status_t decode_st_ble_ess_desc_value_changed_t(st_ble_ess_desc_value_changed_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;
    uint16_t flag = 0;

    /* check the length */
    if (BLE_ESS_DESC_VALUE_CHANGED_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Clear the app_value structure */
    memset(p_app_value, 0x00, sizeof(st_ble_ess_desc_value_changed_t));

    /* Copy the 16-bit flags */
    BT_UNPACK_LE_2_BYTE(&flag, &p_gatt_value->p_value[0]);
    pos += 2;

    /* Decode descriptor value flags bit fields */
    if ((flag & BLE_ESS_PRV_DESCRIPTER_VALUE_CHANGED_FLAG_SOURCE_OF_CHANGE))
    {
        p_app_value->flags.is_changed_by_client = true;
    }
    else
    {
        p_app_value->flags.is_changed_by_client = false;
    }

    if ((flag & BLE_ESS_PRV_DESCRIPTER_VALUE_CHANGED_FLAG_CHANGE_TO_MORE_ES_TRIGGER_SETTING_DESCRIPTORS))
    {
        p_app_value->flags.is_one_or_more_es_trigger_setting_descriptors_changed = true;
    }
    else
    {
        p_app_value->flags.is_one_or_more_es_trigger_setting_descriptors_changed = false;
    }

    if ((flag & BLE_ESS_PRV_DESCRIPTER_VALUE_CHANGED_FLAG_CHANGE_TO_ES_CONFIGURATION_DESCRIPTOR))
    {
        p_app_value->flags.is_es_configuration_descriptor_changed = true;
    }
    else
    {
        p_app_value->flags.is_es_configuration_descriptor_changed = false;
    }

    if ((flag & BLE_ESS_PRV_DESCRIPTER_VALUE_CHANGED_FLAG_CHANGE_TO_ES_MEASUREMENT_DESCRIPTOR))
    {
        p_app_value->flags.is_es_measurement_descriptor_changed = true;
    }
    else
    {
        p_app_value->flags.is_es_measurement_descriptor_changed = false;
    }

    if ((flag & BLE_ESS_PRV_DESCRIPTER_VALUE_CHANGED_FLAG_CHANGE_TO_CHARACTERISTIC_USER_DESCRIPTION_DESCRIPTOR))
    {
        p_app_value->flags.is_characteristic_user_description_descriptor_changed = true;
    }
    else
    {
        p_app_value->flags.is_characteristic_user_description_descriptor_changed = false;
    }

    /* Convert characteristic uuid[] byte sequence */
    for (uint8_t i = 0; i < (p_gatt_value->value_len - 2); i++)
    {
        BT_UNPACK_LE_1_BYTE(&p_app_value->uuid[i], &p_gatt_value->p_value[pos++]);
    }

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
* Function Name: encode_st_ble_ess_desc_value_changed_t
* Description  : This function converts descriptor value changed characteristic representation in
*                in application layer (struct) to GATT (uint8_t[])representation.
* Arguments    : p_app_value  - Pointer to the characteristic value in the application layer
*                p_gatt_value - Pointer to the characteristic value in the GATT database
* Return Value : ble_status_t
**********************************************************************************************************************/
static ble_status_t encode_st_ble_ess_desc_value_changed_t(const st_ble_ess_desc_value_changed_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    p_gatt_value->p_value[pos] |= p_app_value->flags.is_changed_by_client ? 0x01 : 0x00;
    p_gatt_value->p_value[pos] |= p_app_value->flags.is_one_or_more_es_trigger_setting_descriptors_changed ? 0x02 : 0x00;
    p_gatt_value->p_value[pos] |= p_app_value->flags.is_es_configuration_descriptor_changed ? 0x04 : 0x00;
    p_gatt_value->p_value[pos] |= p_app_value->flags.is_es_measurement_descriptor_changed ? 0x08 : 0x00;
    p_gatt_value->p_value[pos] |= p_app_value->flags.is_characteristic_user_description_descriptor_changed ? 0x10 : 0x00;
    pos += 2;

    if (BLE_GATT_16_BIT_UUID_FORMAT == p_app_value->uuid_format)
    {
        memcpy(&p_gatt_value->p_value[pos], p_app_value->uuid, BLE_GATT_16_BIT_UUID_SIZE);
        pos += 2;
    }
    else
    {
        memcpy(&p_gatt_value->p_value[pos], p_app_value->uuid, BLE_GATT_128_BIT_UUID_SIZE);
        pos += 16;
    }

    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

/* Descriptor Value Changed characteristic descriptor definition */
static const st_ble_servs_desc_info_t *gspp_desc_value_changed_descs[] = {
    &gs_desc_value_changed_cli_cnfg,
};

/* Descriptor Value Changed characteristic definition */
static const st_ble_servs_char_info_t gs_desc_value_changed_char = {
    .start_hdl    = BLE_ESS_DESC_VALUE_CHANGED_DECL_HDL,
    .end_hdl      = BLE_ESS_DESC_VALUE_CHANGED_CLI_CNFG_DESC_HDL,
    .char_idx     = BLE_ESS_DESC_VALUE_CHANGED_IDX,
    .app_size     = sizeof(st_ble_ess_desc_value_changed_t),
    .db_size      = BLE_ESS_DESC_VALUE_CHANGED_LEN,
    .decode       = (ble_servs_attr_decode_t)decode_st_ble_ess_desc_value_changed_t,
    .encode       = (ble_servs_attr_encode_t)encode_st_ble_ess_desc_value_changed_t,
    .pp_descs     = gspp_desc_value_changed_descs,
    .num_of_descs = ARRAY_SIZE(gspp_desc_value_changed_descs),
};

ble_status_t R_BLE_ESS_IndicateDescValueChanged(uint16_t conn_hdl, const st_ble_ess_desc_value_changed_t *p_value)
{
    return R_BLE_SERVS_SendHdlVal(&gs_desc_value_changed_char, conn_hdl, (const void *)p_value, false);
}

/*----------------------------------------------------------------------------------------------------------------------
    Temperature 0 Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

static const st_ble_servs_desc_info_t gs_temperature_0_cli_cnfg = {
    .attr_hdl = BLE_ESS_TEMPERATURE_0_CLI_CNFG_DESC_HDL,
    .app_size = sizeof(uint16_t),
    .desc_idx = BLE_ESS_TEMPERATURE_0_CLI_CNFG_IDX,
    .db_size  = BLE_ESS_TEMPERATURE_0_CLI_CNFG_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_uint16_t,
    .encode   = (ble_servs_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_ESS_SetTemperature0CliCnfg(const uint16_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_temperature_0_cli_cnfg, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_ESS_GetTemperature0CliCnfg(uint16_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_temperature_0_cli_cnfg, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Temperature 0 Environmental Sensing Measurement descriptor
----------------------------------------------------------------------------------------------------------------------*/
/***********************************************************************************************************************
 * Function Name: decode_st_ble_ess_temperature_0_es_meas_t
 * Description  : This function converts ES Measurement descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - Pointer to the ES Measurement descriptor value structure in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_ess_temperature_0_es_meas_t(st_ble_ess_temperature_0_es_meas_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    /* check the length */
    if (BLE_ESS_TEMPERATURE_0_ES_MEAS_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    memset(p_app_value, 0x00, sizeof(st_ble_ess_temperature_0_es_meas_t));

    /* Copy the flag */
    BT_UNPACK_LE_2_BYTE(&p_app_value->flags, &p_gatt_value->p_value[pos]);
    pos += 2;

    BT_UNPACK_LE_1_BYTE(&p_app_value->sampling_function, &p_gatt_value->p_value[pos]);
    pos += 1;

    BT_UNPACK_LE_3_BYTE(&p_app_value->measurement_period, &p_gatt_value->p_value[pos]);
    pos += 3;

    BT_UNPACK_LE_3_BYTE(&p_app_value->update_interval, &p_gatt_value->p_value[pos]);
    pos += 3;

    BT_UNPACK_LE_1_BYTE(&p_app_value->application, &p_gatt_value->p_value[pos]);
    pos += 1;

    BT_UNPACK_LE_1_BYTE(&p_app_value->measurement_uncertainty, &p_gatt_value->p_value[pos]);

    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_ess_temperature_0_es_meas_t(const st_ble_ess_temperature_0_es_meas_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_ESS_TEMPERATURE_0_ES_MEAS_LEN);

    /* Encode descriptor value flags - reserved for future use */
    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->flags);
    pos += 2;

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->sampling_function);
    pos += 1;

    BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], &p_app_value->measurement_period);
    pos += 3;

    BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], &p_app_value->update_interval);
    pos += 3;

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->application);
    pos += 1;

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->measurement_uncertainty);
    pos += 1;

    /* update length*/
    p_gatt_value->value_len = BLE_ESS_TEMPERATURE_0_ES_MEAS_LEN;

    return BLE_SUCCESS;
}

static const st_ble_servs_desc_info_t gs_temperature_0_es_meas = {
    .attr_hdl = BLE_ESS_TEMPERATURE_0_ES_MEAS_DESC_HDL,
    .app_size = sizeof(st_ble_ess_temperature_0_es_meas_t),
    .desc_idx = BLE_ESS_TEMPERATURE_0_ES_MEAS_IDX,
    .db_size  = BLE_ESS_TEMPERATURE_0_ES_MEAS_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_st_ble_ess_temperature_0_es_meas_t,
    .encode   = (ble_servs_attr_encode_t)encode_st_ble_ess_temperature_0_es_meas_t,
};

ble_status_t R_BLE_ESS_SetTemperature0EsMeas(const st_ble_ess_temperature_0_es_meas_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_temperature_0_es_meas, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_ESS_GetTemperature0EsMeas(st_ble_ess_temperature_0_es_meas_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_temperature_0_es_meas, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Temperature 0 Characteristic Extended Properties descriptor
----------------------------------------------------------------------------------------------------------------------*/

static const st_ble_servs_desc_info_t gs_temperature_0_char_extended_properties = {
    .attr_hdl = BLE_ESS_TEMPERATURE_0_CHAR_EXTENDED_PROPERTIES_DESC_HDL,
    .app_size = sizeof(uint16_t),
    .desc_idx = BLE_ESS_TEMPERATURE_0_CHAR_EXTENDED_PROPERTIES_IDX,
    .db_size  = BLE_ESS_TEMPERATURE_0_CHAR_EXTENDED_PROPERTIES_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_uint16_t,
    .encode   = (ble_servs_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_ESS_SetTemperature0CharExtendedProperties(const uint16_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_temperature_0_char_extended_properties, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_ESS_GetTemperature0CharExtendedProperties(uint16_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_temperature_0_char_extended_properties, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Temperature 0 Environmental Sensing Trigger Setting 0 descriptor
----------------------------------------------------------------------------------------------------------------------*/

static ble_status_t decode_st_ble_ess_temperature_0_es_trigger_0_t(st_ble_ess_temperature_0_es_trigger_0_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    p_app_value->condition = p_gatt_value->p_value[0];
    if(p_gatt_value->value_len > 1)
    {
        memcpy(&p_app_value->operand[0], &p_gatt_value->p_value[1], p_gatt_value->value_len - 1);
    }
    
    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_ess_temperature_0_es_trigger_0_t(const st_ble_ess_temperature_0_es_trigger_0_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_ESS_TEMPERATURE_0_ES_TRIGGER_0_LEN);

    /* Copy the condition byte */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->condition);
    pos += 1;

    if ((BLE_ESS_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_USE_A_FIXED_TIME_INTERVAL_BETWEEN_TRANSMISSIONS == p_app_value->condition)
        || (BLE_ESS_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_NO_LESS_THAN_THE_SPECIFIED_TIME_BETWEEN_TRANSMISSIONS == p_app_value->condition))
    {
        /* Convert operand (24 bits) to byte sequence */
        BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], (uint32_t *)&p_app_value->operand[0]);
        pos += 3;
    }
    else if ((BLE_ESS_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_TRIGGER_INACTIVE == p_app_value->condition) ||
        (BLE_ESS_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_WHEN_VALUE_CHANGES_COMPARED_TO_PREVIOUS_VALUE == p_app_value->condition))
    {
        /* Do Nothing */
    }
    else
    {
        /* Convert operand (16 bits) to byte sequence */
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], (uint16_t *)&p_app_value->operand[0]);
        pos += 2;
    }

    /* Update length */
    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

static void write_req_temperature0_es_trigger(const void *p_attr, uint16_t conn_hdl, ble_status_t result, const st_ble_ess_temperature_0_es_trigger_0_t *p_app_value)
{
    if (BLE_ESS_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_WHILE_NOT_EQUAL_TO_THE_SPECIFIED_VALUE < p_app_value->condition)
    {
        R_BLE_GATTS_SendErrRsp(BLE_ESS_CONDITION_NOT_SUPPORTED_ERROR);
    }
    else
    {
        st_ble_ess_temperature_0_valid_range_t valid_range;
        R_BLE_ESS_GetTemperature0ValidRange(&valid_range);

        if ((BLE_ESS_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_TRIGGER_INACTIVE != p_app_value->condition) &&
            (BLE_ESS_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_USE_A_FIXED_TIME_INTERVAL_BETWEEN_TRANSMISSIONS != p_app_value->condition) &&
            (BLE_ESS_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_NO_LESS_THAN_THE_SPECIFIED_TIME_BETWEEN_TRANSMISSIONS != p_app_value->condition) &&
            (BLE_ESS_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_WHEN_VALUE_CHANGES_COMPARED_TO_PREVIOUS_VALUE != p_app_value->condition))
        {
            int16_t value;
            BT_UNPACK_LE_2_BYTE(&value, &p_app_value->operand[0]);

            if ((valid_range.lower_inclusive_value > value) || (valid_range.upper_inclusive_value < value))
            {
                R_BLE_GATTS_SendErrRsp(BLE_ERR_GATT_OUT_OF_RANGE);
            }
        }
    }
}

static bool check_temperature_trigger_condtion(st_ble_ess_temperature_1_es_trigger_0_t *p_trigger, int16_t value)
{
    if ((BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_TRIGGER_INACTIVE == p_trigger->condition) ||
        (BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_USE_A_FIXED_TIME_INTERVAL_BETWEEN_TRANSMISSIONS == p_trigger->condition) ||
        (BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_NO_LESS_THAN_THE_SPECIFIED_TIME_BETWEEN_TRANSMISSIONS == p_trigger->condition))
    {
        return true;
    }

    int16_t cond_value;
    BT_UNPACK_LE_2_BYTE(&cond_value, &p_trigger->operand[0]);
    
    switch (p_trigger->condition)
    {
        case BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_WHILE_LESS_THAN_THE_SPECIFIED_VALUE:
        {
            return cond_value > value;
        } break;

        case BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_WHILE_LESS_THAN_OR_EQUAL_TO_THE_SPECIFIED_VALUE:
        {
            return cond_value >= value;
        } break;

        case BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_WHILE_GREATER_THAN_THE_SPECIFIED_VALUE:
        {
            return cond_value < value;
        } break;

        case BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_WHILE_GREATER_THAN_OR_EQUAL_TO_THE_SPECIFIED_VALUE:
        {
            return cond_value <= value;
        } break;

        case BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_WHILE_EQUAL_TO_THE_SPECIFIED_VALUE:
        {
            return cond_value == value;
        } break;

        case BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_WHILE_NOT_EQUAL_TO_THE_SPECIFIED_VALUE:
        {
            return cond_value != value;
        } break;

        default:
        {
            return false;
        } break;
    }
}

static const st_ble_servs_desc_info_t gs_temperature_0_es_trigger_0 = {
    .attr_hdl = BLE_ESS_TEMPERATURE_0_ES_TRIGGER_0_DESC_HDL,
    .app_size = sizeof(st_ble_ess_temperature_0_es_trigger_0_t),
    .desc_idx = BLE_ESS_TEMPERATURE_0_ES_TRIGGER_0_IDX,
    .db_size  = BLE_ESS_TEMPERATURE_0_ES_TRIGGER_0_LEN,
    .write_req_cb = (ble_servs_attr_write_req_t)write_req_temperature0_es_trigger,
    .decode   = (ble_servs_attr_decode_t)decode_st_ble_ess_temperature_0_es_trigger_0_t,
    .encode   = (ble_servs_attr_encode_t)encode_st_ble_ess_temperature_0_es_trigger_0_t,
};

ble_status_t R_BLE_ESS_SetTemperature0EsTrigger0(const st_ble_ess_temperature_0_es_trigger_0_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_temperature_0_es_trigger_0, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_ESS_GetTemperature0EsTrigger0(st_ble_ess_temperature_0_es_trigger_0_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_temperature_0_es_trigger_0, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Temperature 0 Environmental Sensing Trigger Setting 1 descriptor
----------------------------------------------------------------------------------------------------------------------*/

static ble_status_t decode_st_ble_ess_temperature_0_es_trigger_1_t(st_ble_ess_temperature_0_es_trigger_1_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    p_app_value->condition = p_gatt_value->p_value[0];
    memcpy(&p_app_value->operand[0], &p_gatt_value->p_value[1], p_gatt_value->value_len - 1);
    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_ess_temperature_0_es_trigger_1_t(const st_ble_ess_temperature_0_es_trigger_1_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_ESS_TEMPERATURE_0_ES_TRIGGER_1_LEN);

    /* Copy the condition byte */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->condition);
    pos += 1;

    if ((BLE_ESS_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_USE_A_FIXED_TIME_INTERVAL_BETWEEN_TRANSMISSIONS == p_app_value->condition)
        || (BLE_ESS_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_NO_LESS_THAN_THE_SPECIFIED_TIME_BETWEEN_TRANSMISSIONS == p_app_value->condition))
    {
        /* Convert operand (24 bits) to byte sequence */
        BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], (uint32_t *)&p_app_value->operand[0]);
        pos += 3;
    }
    else if ((BLE_ESS_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_TRIGGER_INACTIVE == p_app_value->condition) ||
        (BLE_ESS_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_WHEN_VALUE_CHANGES_COMPARED_TO_PREVIOUS_VALUE == p_app_value->condition))
    {
        /* Do Nothing */
    }
    else
    {
        /* Convert operand (16 bits) to byte sequence */
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], (uint16_t *)&p_app_value->operand);
        pos += 2;
    }

    /* Update length */
    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

static const st_ble_servs_desc_info_t gs_temperature_0_es_trigger_1 = {
    .attr_hdl = BLE_ESS_TEMPERATURE_0_ES_TRIGGER_1_DESC_HDL,
    .app_size = sizeof(st_ble_ess_temperature_0_es_trigger_1_t),
    .desc_idx = BLE_ESS_TEMPERATURE_0_ES_TRIGGER_1_IDX,
    .db_size  = BLE_ESS_TEMPERATURE_0_ES_TRIGGER_1_LEN,
    .write_req_cb = (ble_servs_attr_write_req_t)write_req_temperature0_es_trigger,
    .decode   = (ble_servs_attr_decode_t)decode_st_ble_ess_temperature_0_es_trigger_1_t,
    .encode   = (ble_servs_attr_encode_t)encode_st_ble_ess_temperature_0_es_trigger_1_t,
};

ble_status_t R_BLE_ESS_SetTemperature0EsTrigger1(const st_ble_ess_temperature_0_es_trigger_1_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_temperature_0_es_trigger_1, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_ESS_GetTemperature0EsTrigger1(st_ble_ess_temperature_0_es_trigger_1_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_temperature_0_es_trigger_1, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Temperature 0 Environmental Sensing Trigger Setting 2 descriptor
----------------------------------------------------------------------------------------------------------------------*/

static ble_status_t decode_st_ble_ess_temperature_0_es_trigger_2_t(st_ble_ess_temperature_0_es_trigger_2_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    p_app_value->condition = p_gatt_value->p_value[0];
    memcpy(&p_app_value->operand[0], &p_gatt_value->p_value[1], p_gatt_value->value_len - 1);
    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_ess_temperature_0_es_trigger_2_t(const st_ble_ess_temperature_0_es_trigger_2_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_ESS_TEMPERATURE_0_ES_TRIGGER_2_LEN);

    /* Copy the condition byte */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->condition);
    pos += 1;

    if ((BLE_ESS_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_USE_A_FIXED_TIME_INTERVAL_BETWEEN_TRANSMISSIONS == p_app_value->condition)
        || (BLE_ESS_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_NO_LESS_THAN_THE_SPECIFIED_TIME_BETWEEN_TRANSMISSIONS == p_app_value->condition))
    {
        /* Convert operand (24 bits) to byte sequence */
        BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], (uint32_t *)&p_app_value->operand[0]);
        pos += 3;
    }
    else if ((BLE_ESS_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_TRIGGER_INACTIVE == p_app_value->condition) ||
        (BLE_ESS_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_WHEN_VALUE_CHANGES_COMPARED_TO_PREVIOUS_VALUE == p_app_value->condition))
    {
        /* Do Nothing */
    }
    else
    {
        /* Convert operand (16 bits) to byte sequence */
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], (uint16_t *)&p_app_value->operand[0]);
        pos += 2;
    }

    /* Update length */
    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

static const st_ble_servs_desc_info_t gs_temperature_0_es_trigger_2 = {
    .attr_hdl = BLE_ESS_TEMPERATURE_0_ES_TRIGGER_2_DESC_HDL,
    .app_size = sizeof(st_ble_ess_temperature_0_es_trigger_2_t),
    .desc_idx = BLE_ESS_TEMPERATURE_0_ES_TRIGGER_2_IDX,
    .db_size  = BLE_ESS_TEMPERATURE_0_ES_TRIGGER_2_LEN,
    .write_req_cb = (ble_servs_attr_write_req_t)write_req_temperature0_es_trigger,
    .decode   = (ble_servs_attr_decode_t)decode_st_ble_ess_temperature_0_es_trigger_2_t,
    .encode   = (ble_servs_attr_encode_t)encode_st_ble_ess_temperature_0_es_trigger_2_t,
};

ble_status_t R_BLE_ESS_SetTemperature0EsTrigger2(const st_ble_ess_temperature_0_es_trigger_2_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_temperature_0_es_trigger_2, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_ESS_GetTemperature0EsTrigger2(st_ble_ess_temperature_0_es_trigger_2_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_temperature_0_es_trigger_2, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Temperature 0 Environmental Sensing Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

static const st_ble_servs_desc_info_t gs_temperature_0_es_conf = {
    .attr_hdl = BLE_ESS_TEMPERATURE_0_ES_CONF_DESC_HDL,
    .app_size = sizeof(uint8_t),
    .desc_idx = BLE_ESS_TEMPERATURE_0_ES_CONF_IDX,
    .db_size  = BLE_ESS_TEMPERATURE_0_ES_CONF_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_uint8_t,
    .encode   = (ble_servs_attr_encode_t)encode_uint8_t,
};

ble_status_t R_BLE_ESS_SetTemperature0EsConf(const uint8_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_temperature_0_es_conf, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_ESS_GetTemperature0EsConf(uint8_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_temperature_0_es_conf, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Temperature 0 Characteristic User Description descriptor
----------------------------------------------------------------------------------------------------------------------*/

static ble_status_t decode_st_ble_ess_temperature_0_char_user_desc_t(st_ble_ess_temperature_0_char_user_desc_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    memset(&p_app_value->user_description[0], 0x00, sizeof(p_app_value->user_description));
    memcpy(&p_app_value->user_description[0], p_gatt_value->p_value, p_gatt_value->value_len);
    p_app_value->length = p_gatt_value->value_len;
    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_ess_temperature_0_char_user_desc_t(const st_ble_ess_temperature_0_char_user_desc_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    memcpy(p_gatt_value->p_value, p_app_value->user_description, p_app_value->length);
    p_gatt_value->value_len = p_app_value->length;

    return BLE_SUCCESS;
}

static const st_ble_servs_desc_info_t gs_temperature_0_char_user_desc = {
    .attr_hdl = BLE_ESS_TEMPERATURE_0_CHAR_USER_DESC_DESC_HDL,
    .app_size = sizeof(st_ble_ess_temperature_0_char_user_desc_t),
    .desc_idx = BLE_ESS_TEMPERATURE_0_CHAR_USER_DESC_IDX,
    .db_size  = BLE_ESS_TEMPERATURE_0_CHAR_USER_DESC_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_st_ble_ess_temperature_0_char_user_desc_t,
    .encode   = (ble_servs_attr_encode_t)encode_st_ble_ess_temperature_0_char_user_desc_t,
};

ble_status_t R_BLE_ESS_SetTemperature0CharUserDesc(const st_ble_ess_temperature_0_char_user_desc_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_temperature_0_char_user_desc, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_ESS_GetTemperature0CharUserDesc(st_ble_ess_temperature_0_char_user_desc_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_temperature_0_char_user_desc, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Temperature 0 Valid Range descriptor
----------------------------------------------------------------------------------------------------------------------*/

static ble_status_t decode_st_ble_ess_temperature_0_valid_range_t(st_ble_ess_temperature_0_valid_range_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    if (BLE_ESS_TEMPERATURE_0_VALID_RANGE_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    BT_UNPACK_LE_2_BYTE(&p_app_value->lower_inclusive_value, &p_gatt_value->p_value[0]);
    BT_UNPACK_LE_2_BYTE(&p_app_value->upper_inclusive_value, &p_gatt_value->p_value[2]);

    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_ess_temperature_0_valid_range_t(const st_ble_ess_temperature_0_valid_range_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_ESS_TEMPERATURE_0_VALID_RANGE_LEN);

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->lower_inclusive_value);
    pos += 2;

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->upper_inclusive_value);

    /* Update length */
    p_gatt_value->value_len = BLE_ESS_TEMPERATURE_0_VALID_RANGE_LEN;

    return BLE_SUCCESS;
}

static const st_ble_servs_desc_info_t gs_temperature_0_valid_range = {
    .attr_hdl = BLE_ESS_TEMPERATURE_0_VALID_RANGE_DESC_HDL,
    .app_size = sizeof(st_ble_ess_temperature_0_valid_range_t),
    .desc_idx = BLE_ESS_TEMPERATURE_0_VALID_RANGE_IDX,
    .db_size  = BLE_ESS_TEMPERATURE_0_VALID_RANGE_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_st_ble_ess_temperature_0_valid_range_t,
    .encode   = (ble_servs_attr_encode_t)encode_st_ble_ess_temperature_0_valid_range_t,
};

ble_status_t R_BLE_ESS_SetTemperature0ValidRange(const st_ble_ess_temperature_0_valid_range_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_temperature_0_valid_range, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_ESS_GetTemperature0ValidRange(st_ble_ess_temperature_0_valid_range_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_temperature_0_valid_range, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Temperature 0 characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Temperature 0 characteristic descriptor definition */
static const st_ble_servs_desc_info_t *gspp_temperature_0_descs[] = {
    &gs_temperature_0_cli_cnfg,
    &gs_temperature_0_es_meas,
    &gs_temperature_0_char_extended_properties,
    &gs_temperature_0_es_trigger_0,
    &gs_temperature_0_es_trigger_1,
    &gs_temperature_0_es_trigger_2,
    &gs_temperature_0_es_conf,
    &gs_temperature_0_char_user_desc,
    &gs_temperature_0_valid_range,
};

/* Temperature 0 characteristic definition */
static const st_ble_servs_char_info_t gs_temperature_0_char = {
    .start_hdl    = BLE_ESS_TEMPERATURE_0_DECL_HDL,
    .end_hdl      = BLE_ESS_TEMPERATURE_0_VALID_RANGE_DESC_HDL,
    .char_idx     = BLE_ESS_TEMPERATURE_0_IDX,
    .app_size     = sizeof(int16_t),
    .db_size      = BLE_ESS_TEMPERATURE_0_LEN,
    .decode       = (ble_servs_attr_decode_t)decode_int16_t,
    .encode       = (ble_servs_attr_encode_t)encode_int16_t,
    .pp_descs     = gspp_temperature_0_descs,
    .num_of_descs = ARRAY_SIZE(gspp_temperature_0_descs),
};

ble_status_t R_BLE_ESS_SetTemperature0(const int16_t *p_value)
{
    return R_BLE_SERVS_SetChar(&gs_temperature_0_char, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_ESS_GetTemperature0(int16_t *p_value)
{
    return R_BLE_SERVS_GetChar(&gs_temperature_0_char, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

ble_status_t R_BLE_ESS_NotifyTemperature0(uint16_t conn_hdl, const int16_t *p_value)
{
    return R_BLE_SERVS_SendHdlVal(&gs_temperature_0_char, conn_hdl, (const void *)p_value, true);
}

/*----------------------------------------------------------------------------------------------------------------------
    Temperature 1 Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

static const st_ble_servs_desc_info_t gs_temperature_1_cli_cnfg = {
    .attr_hdl = BLE_ESS_TEMPERATURE_1_CLI_CNFG_DESC_HDL,
    .app_size = sizeof(uint16_t),
    .desc_idx = BLE_ESS_TEMPERATURE_1_CLI_CNFG_IDX,
    .db_size  = BLE_ESS_TEMPERATURE_1_CLI_CNFG_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_uint16_t,
    .encode   = (ble_servs_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_ESS_SetTemperature1CliCnfg(const uint16_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_temperature_1_cli_cnfg, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_ESS_GetTemperature1CliCnfg(uint16_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_temperature_1_cli_cnfg, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Temperature 1 Environmental Sensing Measurement descriptor
----------------------------------------------------------------------------------------------------------------------*/
/***********************************************************************************************************************
 * Function Name: decode_st_ble_ess_temperature_1_es_meas_t
 * Description  : This function converts ES Measurement descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - Pointer to the ES Measurement descriptor value structure in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_ess_temperature_1_es_meas_t(st_ble_ess_temperature_1_es_meas_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    /* check the length */
    if (BLE_ESS_TEMPERATURE_1_ES_MEAS_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    memset(p_app_value, 0x00, sizeof(st_ble_ess_temperature_0_es_meas_t));

    /* Copy the flag */
    BT_UNPACK_LE_2_BYTE(&p_app_value->flags, &p_gatt_value->p_value[pos]);
    pos += 2;

    BT_UNPACK_LE_1_BYTE(&p_app_value->sampling_function, &p_gatt_value->p_value[pos]);
    pos += 1;

    BT_UNPACK_LE_3_BYTE(&p_app_value->measurement_period, &p_gatt_value->p_value[pos]);
    pos += 3;

    BT_UNPACK_LE_3_BYTE(&p_app_value->update_interval, &p_gatt_value->p_value[pos]);
    pos += 3;

    BT_UNPACK_LE_1_BYTE(&p_app_value->application, &p_gatt_value->p_value[pos]);
    pos += 1;

    BT_UNPACK_LE_1_BYTE(&p_app_value->measurement_uncertainty, &p_gatt_value->p_value[pos]);

    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_ess_temperature_1_es_meas_t(const st_ble_ess_temperature_1_es_meas_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_ESS_TEMPERATURE_1_ES_MEAS_LEN);

    /* Encode descriptor value flags - reserved for future use */
    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->flags);
    pos += 2;

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->sampling_function);
    pos += 1;

    BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], &p_app_value->measurement_period);
    pos += 3;

    BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], &p_app_value->update_interval);
    pos += 3;

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->application);
    pos += 1;

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->measurement_uncertainty);
    pos += 1;

    /* update length*/
    p_gatt_value->value_len = BLE_ESS_TEMPERATURE_1_ES_MEAS_LEN;

    return BLE_SUCCESS;
}

static const st_ble_servs_desc_info_t gs_temperature_1_es_meas = {
    .attr_hdl = BLE_ESS_TEMPERATURE_1_ES_MEAS_DESC_HDL,
    .app_size = sizeof(st_ble_ess_temperature_1_es_meas_t),
    .desc_idx = BLE_ESS_TEMPERATURE_1_ES_MEAS_IDX,
    .db_size  = BLE_ESS_TEMPERATURE_1_ES_MEAS_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_st_ble_ess_temperature_1_es_meas_t,
    .encode   = (ble_servs_attr_encode_t)encode_st_ble_ess_temperature_1_es_meas_t,
};

ble_status_t R_BLE_ESS_SetTemperature1EsMeas(const st_ble_ess_temperature_1_es_meas_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_temperature_1_es_meas, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_ESS_GetTemperature1EsMeas(st_ble_ess_temperature_1_es_meas_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_temperature_1_es_meas, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Temperature 1 Characteristic Extended Properties descriptor
----------------------------------------------------------------------------------------------------------------------*/

static const st_ble_servs_desc_info_t gs_temperature_1_char_extended_properties = {
    .attr_hdl = BLE_ESS_TEMPERATURE_1_CHAR_EXTENDED_PROPERTIES_DESC_HDL,
    .app_size = sizeof(uint16_t),
    .desc_idx = BLE_ESS_TEMPERATURE_1_CHAR_EXTENDED_PROPERTIES_IDX,
    .db_size  = BLE_ESS_TEMPERATURE_1_CHAR_EXTENDED_PROPERTIES_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_uint16_t,
    .encode   = (ble_servs_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_ESS_SetTemperature1CharExtendedProperties(const uint16_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_temperature_1_char_extended_properties, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_ESS_GetTemperature1CharExtendedProperties(uint16_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_temperature_1_char_extended_properties, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Temperature 1 Environmental Sensing Trigger Setting 0 descriptor
----------------------------------------------------------------------------------------------------------------------*/

static ble_status_t decode_st_ble_ess_temperature_1_es_trigger_0_t(st_ble_ess_temperature_1_es_trigger_0_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    memset(p_app_value, 0x00, sizeof(st_ble_ess_temperature_1_es_trigger_0_t));
    p_app_value->condition = p_gatt_value->p_value[0];
    
    if (p_gatt_value->value_len > 1)
    {
        memcpy(&p_app_value->operand[0], &p_gatt_value->p_value[1], ((p_gatt_value->value_len) - 1));
    }
    
    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_ess_temperature_1_es_trigger_0_t(const st_ble_ess_temperature_1_es_trigger_0_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;
    
    memset(p_gatt_value->p_value, 0x00, BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_LEN);

    /* Copy the condition byte */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->condition);
    pos += 1;

    if ((BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_USE_A_FIXED_TIME_INTERVAL_BETWEEN_TRANSMISSIONS == p_app_value->condition)
        || (BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_NO_LESS_THAN_THE_SPECIFIED_TIME_BETWEEN_TRANSMISSIONS == p_app_value->condition))
    {
        /* Convert operand (24 bits) to byte sequence */
        BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], (uint32_t *)&p_app_value->operand[0]);
        pos += 3;
    }
    else if ((BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_TRIGGER_INACTIVE == p_app_value->condition) ||
        (BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_WHEN_VALUE_CHANGES_COMPARED_TO_PREVIOUS_VALUE == p_app_value->condition))
    {
        /* Do Nothing */
    }
    else
    {
        /* Convert operand (16 bits) to byte sequence */
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], (uint16_t *)&p_app_value->operand[0]);
        pos += 2;
    }

    /* Update length */
    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

static void write_req_temperature1_es_trigger(const void *p_attr, uint16_t conn_hdl, ble_status_t result, const st_ble_ess_temperature_1_es_trigger_0_t *p_app_value)
{
    if (BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_WHILE_NOT_EQUAL_TO_THE_SPECIFIED_VALUE < p_app_value->condition)
    {
        R_BLE_GATTS_SendErrRsp(BLE_ESS_CONDITION_NOT_SUPPORTED_ERROR);
    }
    else
    {
        st_ble_ess_temperature_1_valid_range_t valid_range;
        R_BLE_ESS_GetTemperature1ValidRange(&valid_range);

        if ((BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_TRIGGER_INACTIVE != p_app_value->condition) &&
            (BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_USE_A_FIXED_TIME_INTERVAL_BETWEEN_TRANSMISSIONS != p_app_value->condition) &&
            (BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_NO_LESS_THAN_THE_SPECIFIED_TIME_BETWEEN_TRANSMISSIONS != p_app_value->condition) &&
            (BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_WHEN_VALUE_CHANGES_COMPARED_TO_PREVIOUS_VALUE != p_app_value->condition))
        {
            int16_t value;
            BT_UNPACK_LE_2_BYTE(&value, &p_app_value->operand[0]);

            if ((valid_range.lower_inclusive_value > value) || (valid_range.upper_inclusive_value < value))
            {
                R_BLE_GATTS_SendErrRsp(BLE_ERR_GATT_OUT_OF_RANGE);
            }
        }
    }
}

static const st_ble_servs_desc_info_t gs_temperature_1_es_trigger_0 = {
    .attr_hdl = BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_DESC_HDL,
    .app_size = sizeof(st_ble_ess_temperature_1_es_trigger_0_t),
    .desc_idx = BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_IDX,
    .db_size  = BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_LEN,
    .write_req_cb = (ble_servs_attr_write_req_t)write_req_temperature1_es_trigger,
    .decode   = (ble_servs_attr_decode_t)decode_st_ble_ess_temperature_1_es_trigger_0_t,
    .encode   = (ble_servs_attr_encode_t)encode_st_ble_ess_temperature_1_es_trigger_0_t,
};

ble_status_t R_BLE_ESS_SetTemperature1EsTrigger0(const st_ble_ess_temperature_1_es_trigger_0_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_temperature_1_es_trigger_0, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_ESS_GetTemperature1EsTrigger0(st_ble_ess_temperature_1_es_trigger_0_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_temperature_1_es_trigger_0, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Temperature 1 Environmental Sensing Trigger Setting 1 descriptor
----------------------------------------------------------------------------------------------------------------------*/

static ble_status_t decode_st_ble_ess_temperature_1_es_trigger_1_t(st_ble_ess_temperature_1_es_trigger_1_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    memset(p_app_value, 0x00, sizeof(st_ble_ess_temperature_1_es_trigger_0_t));
    p_app_value->condition = p_gatt_value->p_value[0];
    
    if (p_gatt_value->value_len > 1)
    {
        memcpy(&p_app_value->operand[0], &p_gatt_value->p_value[1], p_gatt_value->value_len - 1);
    }
    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_ess_temperature_1_es_trigger_1_t(const st_ble_ess_temperature_1_es_trigger_1_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_ESS_TEMPERATURE_1_ES_TRIGGER_1_LEN);

    /* Copy the condition byte */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->condition);
    pos += 1;

    if ((BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_USE_A_FIXED_TIME_INTERVAL_BETWEEN_TRANSMISSIONS == p_app_value->condition)
        || (BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_NO_LESS_THAN_THE_SPECIFIED_TIME_BETWEEN_TRANSMISSIONS == p_app_value->condition))
    {
        /* Convert operand (24 bits) to byte sequence */
        BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], (uint32_t *)&p_app_value->operand[0]);
        pos += 3;
    }
    else if ((BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_TRIGGER_INACTIVE == p_app_value->condition) ||
        (BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_WHEN_VALUE_CHANGES_COMPARED_TO_PREVIOUS_VALUE == p_app_value->condition))
    {
        /* Do Nothing */
    }
    else
    {
        /* Convert operand (16 bits) to byte sequence */
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], (uint16_t *)&p_app_value->operand[0]);
        pos += 2;
    }

    /* Update length */
    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

static const st_ble_servs_desc_info_t gs_temperature_1_es_trigger_1 = {
    .attr_hdl = BLE_ESS_TEMPERATURE_1_ES_TRIGGER_1_DESC_HDL,
    .app_size = sizeof(st_ble_ess_temperature_1_es_trigger_1_t),
    .desc_idx = BLE_ESS_TEMPERATURE_1_ES_TRIGGER_1_IDX,
    .db_size  = BLE_ESS_TEMPERATURE_1_ES_TRIGGER_1_LEN,
    .write_req_cb = (ble_servs_attr_write_req_t)write_req_temperature1_es_trigger,
    .decode   = (ble_servs_attr_decode_t)decode_st_ble_ess_temperature_1_es_trigger_1_t,
    .encode   = (ble_servs_attr_encode_t)encode_st_ble_ess_temperature_1_es_trigger_1_t,
};

ble_status_t R_BLE_ESS_SetTemperature1EsTrigger1(const st_ble_ess_temperature_1_es_trigger_1_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_temperature_1_es_trigger_1, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_ESS_GetTemperature1EsTrigger1(st_ble_ess_temperature_1_es_trigger_1_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_temperature_1_es_trigger_1, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Temperature 1 Environmental Sensing Trigger Setting 2 descriptor
----------------------------------------------------------------------------------------------------------------------*/

static ble_status_t decode_st_ble_ess_temperature_1_es_trigger_2_t(st_ble_ess_temperature_1_es_trigger_2_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    memset(p_app_value, 0x00, sizeof(st_ble_ess_temperature_1_es_trigger_0_t));
    p_app_value->condition = p_gatt_value->p_value[0];
    
    if (p_gatt_value->value_len > 1)
    {
        memcpy(&p_app_value->operand[0], &p_gatt_value->p_value[1], p_gatt_value->value_len - 1);
    }
    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_ess_temperature_1_es_trigger_2_t(const st_ble_ess_temperature_1_es_trigger_2_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_ESS_TEMPERATURE_1_ES_TRIGGER_2_LEN);

    /* Copy the condition byte */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->condition);
    pos += 1;

    if ((BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_USE_A_FIXED_TIME_INTERVAL_BETWEEN_TRANSMISSIONS == p_app_value->condition)
        || (BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_NO_LESS_THAN_THE_SPECIFIED_TIME_BETWEEN_TRANSMISSIONS == p_app_value->condition))
    {
        /* Convert operand (24 bits) to byte sequence */
        BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], (uint32_t *)&p_app_value->operand[0]);
        pos += 3;
    }
    else if ((BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_TRIGGER_INACTIVE == p_app_value->condition) ||
        (BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_WHEN_VALUE_CHANGES_COMPARED_TO_PREVIOUS_VALUE == p_app_value->condition))
    {
        /* Do Nothing */
    }
    else
    {
        /* Convert operand (16 bits) to byte sequence */
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], (uint16_t *)&p_app_value->operand[0]);
        pos += 2;
    }

    /* Update length */
    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

static const st_ble_servs_desc_info_t gs_temperature_1_es_trigger_2 = {
    .attr_hdl = BLE_ESS_TEMPERATURE_1_ES_TRIGGER_2_DESC_HDL,
    .app_size = sizeof(st_ble_ess_temperature_1_es_trigger_2_t),
    .desc_idx = BLE_ESS_TEMPERATURE_1_ES_TRIGGER_2_IDX,
    .db_size  = BLE_ESS_TEMPERATURE_1_ES_TRIGGER_2_LEN,
    .write_req_cb = (ble_servs_attr_write_req_t)write_req_temperature1_es_trigger,
    .decode   = (ble_servs_attr_decode_t)decode_st_ble_ess_temperature_1_es_trigger_2_t,
    .encode   = (ble_servs_attr_encode_t)encode_st_ble_ess_temperature_1_es_trigger_2_t,
};

ble_status_t R_BLE_ESS_SetTemperature1EsTrigger2(const st_ble_ess_temperature_1_es_trigger_2_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_temperature_1_es_trigger_2, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_ESS_GetTemperature1EsTrigger2(st_ble_ess_temperature_1_es_trigger_2_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_temperature_1_es_trigger_2, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Temperature 1 Environmental Sensing Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

static const st_ble_servs_desc_info_t gs_temperature_1_es_conf = {
    .attr_hdl = BLE_ESS_TEMPERATURE_1_ES_CONF_DESC_HDL,
    .app_size = sizeof(uint8_t),
    .desc_idx = BLE_ESS_TEMPERATURE_1_ES_CONF_IDX,
    .db_size  = BLE_ESS_TEMPERATURE_1_ES_CONF_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_uint8_t,
    .encode   = (ble_servs_attr_encode_t)encode_uint8_t,
};

ble_status_t R_BLE_ESS_SetTemperature1EsConf(const uint8_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_temperature_1_es_conf, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_ESS_GetTemperature1EsConf(uint8_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_temperature_1_es_conf, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Temperature 1 Characteristic User Description descriptor
----------------------------------------------------------------------------------------------------------------------*/

static ble_status_t decode_st_ble_ess_temperature_1_char_user_desc_t(st_ble_ess_temperature_1_char_user_desc_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    memset(&p_app_value->user_description[0], 0x00, sizeof(p_app_value->user_description));
    memcpy(&p_app_value->user_description[0], p_gatt_value->p_value, p_gatt_value->value_len);
    p_app_value->length = p_gatt_value->value_len;
    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_ess_temperature_1_char_user_desc_t(const st_ble_ess_temperature_1_char_user_desc_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    memcpy(p_gatt_value->p_value, p_app_value->user_description, p_app_value->length);
    p_gatt_value->value_len = p_app_value->length;

    return BLE_SUCCESS;
}

static const st_ble_servs_desc_info_t gs_temperature_1_char_user_desc = {
    .attr_hdl = BLE_ESS_TEMPERATURE_1_CHAR_USER_DESC_DESC_HDL,
    .app_size = sizeof(st_ble_ess_temperature_1_char_user_desc_t),
    .desc_idx = BLE_ESS_TEMPERATURE_1_CHAR_USER_DESC_IDX,
    .db_size  = BLE_ESS_TEMPERATURE_1_CHAR_USER_DESC_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_st_ble_ess_temperature_1_char_user_desc_t,
    .encode   = (ble_servs_attr_encode_t)encode_st_ble_ess_temperature_1_char_user_desc_t,
};

ble_status_t R_BLE_ESS_SetTemperature1CharUserDesc(const st_ble_ess_temperature_1_char_user_desc_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_temperature_1_char_user_desc, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_ESS_GetTemperature1CharUserDesc(st_ble_ess_temperature_1_char_user_desc_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_temperature_1_char_user_desc, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Temperature 1 Valid Range descriptor
----------------------------------------------------------------------------------------------------------------------*/

static ble_status_t decode_st_ble_ess_temperature_1_valid_range_t(st_ble_ess_temperature_1_valid_range_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    if (BLE_ESS_TEMPERATURE_1_VALID_RANGE_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    BT_UNPACK_LE_2_BYTE(&p_app_value->lower_inclusive_value, &p_gatt_value->p_value[0]);
    BT_UNPACK_LE_2_BYTE(&p_app_value->upper_inclusive_value, &p_gatt_value->p_value[2]);

    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_ess_temperature_1_valid_range_t(const st_ble_ess_temperature_1_valid_range_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_ESS_TEMPERATURE_1_VALID_RANGE_LEN);

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->lower_inclusive_value);
    pos += 2;

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->upper_inclusive_value);

    /* Update length */
    p_gatt_value->value_len = BLE_ESS_TEMPERATURE_1_VALID_RANGE_LEN;

    return BLE_SUCCESS;
}

static const st_ble_servs_desc_info_t gs_temperature_1_valid_range = {
    .attr_hdl = BLE_ESS_TEMPERATURE_1_VALID_RANGE_DESC_HDL,
    .app_size = sizeof(st_ble_ess_temperature_1_valid_range_t),
    .desc_idx = BLE_ESS_TEMPERATURE_1_VALID_RANGE_IDX,
    .db_size  = BLE_ESS_TEMPERATURE_1_VALID_RANGE_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_st_ble_ess_temperature_1_valid_range_t,
    .encode   = (ble_servs_attr_encode_t)encode_st_ble_ess_temperature_1_valid_range_t,
};

ble_status_t R_BLE_ESS_SetTemperature1ValidRange(const st_ble_ess_temperature_1_valid_range_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_temperature_1_valid_range, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_ESS_GetTemperature1ValidRange(st_ble_ess_temperature_1_valid_range_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_temperature_1_valid_range, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Temperature 1 characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Temperature 1 characteristic descriptor definition */
static const st_ble_servs_desc_info_t *gspp_temperature_1_descs[] = {
    &gs_temperature_1_cli_cnfg,
    &gs_temperature_1_es_meas,
    &gs_temperature_1_char_extended_properties,
    &gs_temperature_1_es_trigger_0,
    &gs_temperature_1_es_trigger_1,
    &gs_temperature_1_es_trigger_2,
    &gs_temperature_1_es_conf,
    &gs_temperature_1_char_user_desc,
    &gs_temperature_1_valid_range,
};

/* Temperature 1 characteristic definition */
static const st_ble_servs_char_info_t gs_temperature_1_char = {
    .start_hdl    = BLE_ESS_TEMPERATURE_1_DECL_HDL,
    .end_hdl      = BLE_ESS_TEMPERATURE_1_VALID_RANGE_DESC_HDL,
    .char_idx     = BLE_ESS_TEMPERATURE_1_IDX,
    .app_size     = sizeof(int16_t),
    .db_size      = BLE_ESS_TEMPERATURE_1_LEN,
    .decode       = (ble_servs_attr_decode_t)decode_int16_t,
    .encode       = (ble_servs_attr_encode_t)encode_int16_t,
    .pp_descs     = gspp_temperature_1_descs,
    .num_of_descs = ARRAY_SIZE(gspp_temperature_1_descs),
};

ble_status_t R_BLE_ESS_SetTemperature1(const int16_t *p_value)
{
    return R_BLE_SERVS_SetChar(&gs_temperature_1_char, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_ESS_GetTemperature1(int16_t *p_value)
{
    return R_BLE_SERVS_GetChar(&gs_temperature_1_char, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

ble_status_t R_BLE_ESS_NotifyTemperature1(uint16_t conn_hdl, const int16_t *p_value)
{
    return R_BLE_SERVS_SendHdlVal(&gs_temperature_1_char, conn_hdl, (const void *)p_value, true);
}

bool R_BLE_ESS_CheckTemperature1Condition(const int16_t *p_value)
{
    if (NULL == p_value)
    {
        return false;
    }

    uint8_t conf;
    R_BLE_ESS_GetTemperature1EsConf(&conf);

    st_ble_ess_temperature_1_es_trigger_0_t trigger[3];
    R_BLE_ESS_GetTemperature1EsTrigger0(&trigger[0]);
    R_BLE_ESS_GetTemperature1EsTrigger1((st_ble_ess_temperature_1_es_trigger_1_t *)(&trigger[1]));
    R_BLE_ESS_GetTemperature1EsTrigger2((st_ble_ess_temperature_1_es_trigger_2_t *)(&trigger[2]));

    if (BLE_ESS_TEMPERATURE_1_ES_CONF_TRIGGER_LOGIC_BOOLEAN_AND == conf)
    {
        return
            check_temperature_trigger_condtion(&trigger[0], *p_value) &&
            check_temperature_trigger_condtion(&trigger[1], *p_value) &&
            check_temperature_trigger_condtion(&trigger[2], *p_value);
    }
    else if (BLE_ESS_TEMPERATURE_1_ES_CONF_TRIGGER_LOGIC_BOOLEAN_OR == conf)
    {
        uint8_t num_of_inactive = 0;

        for (uint8_t i = 0; i < 3; i++)
        {
            if (BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_TRIGGER_INACTIVE == trigger[i].condition)
            {
                num_of_inactive++;
            }
            else
            {
                bool ret;
                ret = check_temperature_trigger_condtion(&trigger[i], *p_value);
                if (ret)
                {
                    return true;
                }
            }
        }

        return (num_of_inactive == 3);
    }
    else
    {
        return false;
    }
}

/*----------------------------------------------------------------------------------------------------------------------
    Elevation 0 Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

static const st_ble_servs_desc_info_t gs_elevation_0_cli_cnfg = {
    .attr_hdl = BLE_ESS_ELEVATION_0_CLI_CNFG_DESC_HDL,
    .app_size = sizeof(uint16_t),
    .desc_idx = BLE_ESS_ELEVATION_0_CLI_CNFG_IDX,
    .db_size  = BLE_ESS_ELEVATION_0_CLI_CNFG_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_uint16_t,
    .encode   = (ble_servs_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_ESS_SetElevation0CliCnfg(const uint16_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_elevation_0_cli_cnfg, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_ESS_GetElevation0CliCnfg(uint16_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_elevation_0_cli_cnfg, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Elevation 0 Environmental Sensing Measurement descriptor
----------------------------------------------------------------------------------------------------------------------*/
/***********************************************************************************************************************
 * Function Name: decode_st_ble_ess_elevation_0_es_meas_t
 * Description  : This function converts ES Measurement descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - Pointer to the ES Measurement descriptor value structure in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_ess_elevation_0_es_meas_t(st_ble_ess_elevation_0_es_meas_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    /* check the length */
    if (BLE_ESS_ELEVATION_0_ES_MEAS_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    memset(p_app_value, 0x00, sizeof(st_ble_ess_elevation_0_es_meas_t));
    
    /* Copy the flag */
    BT_UNPACK_LE_2_BYTE(&p_app_value->flags, &p_gatt_value->p_value[pos]);
    pos += 2;

    BT_UNPACK_LE_1_BYTE(&p_app_value->sampling_function, &p_gatt_value->p_value[pos]);
    pos += 1;

    BT_UNPACK_LE_3_BYTE(&p_app_value->measurement_period, &p_gatt_value->p_value[pos]);
    pos += 3;

    BT_UNPACK_LE_3_BYTE(&p_app_value->update_interval, &p_gatt_value->p_value[pos]);
    pos += 3;

    BT_UNPACK_LE_1_BYTE(&p_app_value->application, &p_gatt_value->p_value[pos]);
    pos += 1;

    BT_UNPACK_LE_1_BYTE(&p_app_value->measurement_uncertainty, &p_gatt_value->p_value[pos]);

    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_ess_elevation_0_es_meas_t(const st_ble_ess_elevation_0_es_meas_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_ESS_ELEVATION_0_ES_MEAS_LEN);

    /* Encode descriptor value flags - reserved for future use */
    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->flags);
    pos += 2;
    
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->sampling_function);
    pos += 1;

    BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], (uint32_t *)&p_app_value->measurement_period);
    pos += 3;

    BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], (uint32_t *)&p_app_value->update_interval);
    pos += 3;

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->application);
    pos += 1;

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->measurement_uncertainty);
    pos += 1;

    /* update length*/
    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

static const st_ble_servs_desc_info_t gs_elevation_0_es_meas = {
    .attr_hdl = BLE_ESS_ELEVATION_0_ES_MEAS_DESC_HDL,
    .app_size = sizeof(st_ble_ess_elevation_0_es_meas_t),
    .desc_idx = BLE_ESS_ELEVATION_0_ES_MEAS_IDX,
    .db_size  = BLE_ESS_ELEVATION_0_ES_MEAS_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_st_ble_ess_elevation_0_es_meas_t,
    .encode   = (ble_servs_attr_encode_t)encode_st_ble_ess_elevation_0_es_meas_t,
};

ble_status_t R_BLE_ESS_SetElevation0EsMeas(const st_ble_ess_elevation_0_es_meas_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_elevation_0_es_meas, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_ESS_GetElevation0EsMeas(st_ble_ess_elevation_0_es_meas_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_elevation_0_es_meas, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Elevation 0 Characteristic Extended Properties descriptor
----------------------------------------------------------------------------------------------------------------------*/

static const st_ble_servs_desc_info_t gs_elevation_0_char_extended_properties = {
    .attr_hdl = BLE_ESS_ELEVATION_0_CHAR_EXTENDED_PROPERTIES_DESC_HDL,
    .app_size = sizeof(uint16_t),
    .desc_idx = BLE_ESS_ELEVATION_0_CHAR_EXTENDED_PROPERTIES_IDX,
    .db_size  = BLE_ESS_ELEVATION_0_CHAR_EXTENDED_PROPERTIES_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_uint16_t,
    .encode   = (ble_servs_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_ESS_SetElevation0CharExtendedProperties(const uint16_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_elevation_0_char_extended_properties, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_ESS_GetElevation0CharExtendedProperties(uint16_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_elevation_0_char_extended_properties, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Elevation 0 Environmental Sensing Trigger Setting 0 descriptor
----------------------------------------------------------------------------------------------------------------------*/

static ble_status_t decode_st_ble_ess_elevation_0_es_trigger_0_t(st_ble_ess_elevation_0_es_trigger_0_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    p_app_value->condition = p_gatt_value->p_value[0];
    if (p_gatt_value->value_len > 1)
    {
        memcpy(&p_app_value->operand[0], &p_gatt_value->p_value[1], p_gatt_value->value_len - 1);
    }
    
    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_ess_elevation_0_es_trigger_0_t(const st_ble_ess_elevation_0_es_trigger_0_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_ESS_ELEVATION_0_ES_TRIGGER_0_LEN);

    /* Copy the condition byte */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->condition);
    pos += 1;

    if ((BLE_ESS_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_USE_A_FIXED_TIME_INTERVAL_BETWEEN_TRANSMISSIONS == p_app_value->condition)
        || (BLE_ESS_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_NO_LESS_THAN_THE_SPECIFIED_TIME_BETWEEN_TRANSMISSIONS == p_app_value->condition))
    {
        /* Convert operand (24 bits) to byte sequence */
        BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], (uint32_t *)&p_app_value->operand[0]);
        pos += 3;
    }
    else if ((BLE_ESS_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_TRIGGER_INACTIVE == p_app_value->condition) ||
        (BLE_ESS_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_WHEN_VALUE_CHANGES_COMPARED_TO_PREVIOUS_VALUE == p_app_value->condition))
    {
        /* Do Nothing */
    }
    else
    {
        /* Convert operand (24 bits) to byte sequence */
        BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], (uint32_t *)&p_app_value->operand[0]);
        pos += 3;
    }

    /* Update length */
    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

static void write_req_elevation0_es_trigger(const void *p_attr, uint16_t conn_hdl, ble_status_t result, const st_ble_ess_elevation_0_es_trigger_0_t *p_app_value)
{
    if (BLE_ESS_ELEVATION_0_ES_TRIGGER_0_CONDITION_WHILE_NOT_EQUAL_TO_THE_SPECIFIED_VALUE < p_app_value->condition)
    {
        R_BLE_GATTS_SendErrRsp(BLE_ESS_CONDITION_NOT_SUPPORTED_ERROR);
    }
    else
    {
        st_ble_ess_elevation_0_valid_range_t valid_range;
        R_BLE_ESS_GetElevation0ValidRange(&valid_range);

        if ((BLE_ESS_ELEVATION_0_ES_TRIGGER_0_CONDITION_TRIGGER_INACTIVE != p_app_value->condition) &&
            (BLE_ESS_ELEVATION_0_ES_TRIGGER_0_CONDITION_USE_A_FIXED_TIME_INTERVAL_BETWEEN_TRANSMISSIONS != p_app_value->condition) &&
            (BLE_ESS_ELEVATION_0_ES_TRIGGER_0_CONDITION_NO_LESS_THAN_THE_SPECIFIED_TIME_BETWEEN_TRANSMISSIONS != p_app_value->condition) &&
            (BLE_ESS_ELEVATION_0_ES_TRIGGER_0_CONDITION_WHEN_VALUE_CHANGES_COMPARED_TO_PREVIOUS_VALUE != p_app_value->condition))
        {
            int32_t value;
            BT_UNPACK_LE_3_BYTE(&value, &p_app_value->operand[0]);

            if ((valid_range.lower_inclusive_value > value) || (valid_range.upper_inclusive_value < value))
            {
                R_BLE_GATTS_SendErrRsp(BLE_ERR_GATT_OUT_OF_RANGE);
            }
        }
    }
}

static bool check_elevation_trigger_condtion(st_ble_ess_elevation_1_es_trigger_0_t *p_trigger, int32_t value)
{
    if ((BLE_ESS_ELEVATION_1_ES_TRIGGER_0_CONDITION_TRIGGER_INACTIVE == p_trigger->condition) ||
        (BLE_ESS_ELEVATION_1_ES_TRIGGER_0_CONDITION_USE_A_FIXED_TIME_INTERVAL_BETWEEN_TRANSMISSIONS == p_trigger->condition) ||
        (BLE_ESS_ELEVATION_1_ES_TRIGGER_0_CONDITION_NO_LESS_THAN_THE_SPECIFIED_TIME_BETWEEN_TRANSMISSIONS == p_trigger->condition))
    {
        return true;
    }

    int32_t cond_value = 0;
    BT_UNPACK_LE_3_BYTE(&cond_value, &p_trigger->operand[0]);
    
    switch (p_trigger->condition)
    {
        case BLE_ESS_ELEVATION_1_ES_TRIGGER_0_CONDITION_WHILE_LESS_THAN_THE_SPECIFIED_VALUE:
        {
            return cond_value > value;
        } break;

        case BLE_ESS_ELEVATION_1_ES_TRIGGER_0_CONDITION_WHILE_LESS_THAN_OR_EQUAL_TO_THE_SPECIFIED_VALUE:
        {
            return cond_value >= value;
        } break;

        case BLE_ESS_ELEVATION_1_ES_TRIGGER_0_CONDITION_WHILE_GREATER_THAN_THE_SPECIFIED_VALUE:
        {
            return cond_value < value;
        } break;

        case BLE_ESS_ELEVATION_1_ES_TRIGGER_0_CONDITION_WHILE_GREATER_THAN_OR_EQUAL_TO_THE_SPECIFIED_VALUE:
        {
            return cond_value <= value;
        } break;

        case BLE_ESS_ELEVATION_1_ES_TRIGGER_0_CONDITION_WHILE_EQUAL_TO_THE_SPECIFIED_VALUE:
        {
            return cond_value == value;
        } break;

        case BLE_ESS_ELEVATION_1_ES_TRIGGER_0_CONDITION_WHILE_NOT_EQUAL_TO_THE_SPECIFIED_VALUE:
        {
            return cond_value != value;
        } break;

        default:
        {
            return false;
        } break;
    }

}
static const st_ble_servs_desc_info_t gs_elevation_0_es_trigger_0 = {
    .attr_hdl = BLE_ESS_ELEVATION_0_ES_TRIGGER_0_DESC_HDL,
    .app_size = sizeof(st_ble_ess_elevation_0_es_trigger_0_t),
    .desc_idx = BLE_ESS_ELEVATION_0_ES_TRIGGER_0_IDX,
    .db_size  = BLE_ESS_ELEVATION_0_ES_TRIGGER_0_LEN,
    .write_req_cb = (ble_servs_attr_write_req_t)write_req_elevation0_es_trigger,
    .decode   = (ble_servs_attr_decode_t)decode_st_ble_ess_elevation_0_es_trigger_0_t,
    .encode   = (ble_servs_attr_encode_t)encode_st_ble_ess_elevation_0_es_trigger_0_t,
};

ble_status_t R_BLE_ESS_SetElevation0EsTrigger0(const st_ble_ess_elevation_0_es_trigger_0_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_elevation_0_es_trigger_0, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_ESS_GetElevation0EsTrigger0(st_ble_ess_elevation_0_es_trigger_0_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_elevation_0_es_trigger_0, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Elevation 0 Environmental Sensing Trigger Setting 1 descriptor
----------------------------------------------------------------------------------------------------------------------*/

static ble_status_t decode_st_ble_ess_elevation_0_es_trigger_1_t(st_ble_ess_elevation_0_es_trigger_1_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    p_app_value->condition = p_gatt_value->p_value[0];
    if (p_gatt_value->value_len > 1)
    {
        memcpy(&p_app_value->operand[0], &p_gatt_value->p_value[1], p_gatt_value->value_len - 1);
    }
    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_ess_elevation_0_es_trigger_1_t(const st_ble_ess_elevation_0_es_trigger_1_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_ESS_ELEVATION_0_ES_TRIGGER_1_LEN);

    /* Copy the condition byte */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->condition);
    pos += 1;

    if ((BLE_ESS_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_USE_A_FIXED_TIME_INTERVAL_BETWEEN_TRANSMISSIONS == p_app_value->condition)
        || (BLE_ESS_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_NO_LESS_THAN_THE_SPECIFIED_TIME_BETWEEN_TRANSMISSIONS == p_app_value->condition))
    {
        /* Convert operand (24 bits) to byte sequence */
        BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], (uint32_t *)&p_app_value->operand[0]);
        pos += 3;
    }
    else if ((BLE_ESS_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_TRIGGER_INACTIVE == p_app_value->condition) ||
        (BLE_ESS_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_WHEN_VALUE_CHANGES_COMPARED_TO_PREVIOUS_VALUE == p_app_value->condition))
    {
        /* Do Nothing */
    }
    else
    {
        /* Convert operand (24 bits) to byte sequence */
        BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], (uint32_t *)&p_app_value->operand[0]);
        pos += 3;
    }

    /* Update length */
    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

static const st_ble_servs_desc_info_t gs_elevation_0_es_trigger_1 = {
    .attr_hdl = BLE_ESS_ELEVATION_0_ES_TRIGGER_1_DESC_HDL,
    .app_size = sizeof(st_ble_ess_elevation_0_es_trigger_1_t),
    .desc_idx = BLE_ESS_ELEVATION_0_ES_TRIGGER_1_IDX,
    .db_size  = BLE_ESS_ELEVATION_0_ES_TRIGGER_1_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_st_ble_ess_elevation_0_es_trigger_1_t,
    .encode   = (ble_servs_attr_encode_t)encode_st_ble_ess_elevation_0_es_trigger_1_t,
};

ble_status_t R_BLE_ESS_SetElevation0EsTrigger1(const st_ble_ess_elevation_0_es_trigger_1_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_elevation_0_es_trigger_1, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_ESS_GetElevation0EsTrigger1(st_ble_ess_elevation_0_es_trigger_1_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_elevation_0_es_trigger_1, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Elevation 0 Environmental Sensing Trigger Setting 2 descriptor
----------------------------------------------------------------------------------------------------------------------*/

static ble_status_t decode_st_ble_ess_elevation_0_es_trigger_2_t(st_ble_ess_elevation_0_es_trigger_2_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    p_app_value->condition = p_gatt_value->p_value[0];
    memcpy(&p_app_value->operand[0], &p_gatt_value->p_value[1], p_gatt_value->value_len - 1);
    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_ess_elevation_0_es_trigger_2_t(const st_ble_ess_elevation_0_es_trigger_2_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_ESS_ELEVATION_0_ES_TRIGGER_2_LEN);

    /* Copy the condition byte */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->condition);
    pos += 1;

    if ((BLE_ESS_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_USE_A_FIXED_TIME_INTERVAL_BETWEEN_TRANSMISSIONS == p_app_value->condition)
        || (BLE_ESS_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_NO_LESS_THAN_THE_SPECIFIED_TIME_BETWEEN_TRANSMISSIONS == p_app_value->condition))
    {
        /* Convert operand (24 bits) to byte sequence */
        BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], (uint32_t *)&p_app_value->operand[0]);
        pos += 3;
    }
    else if ((BLE_ESS_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_TRIGGER_INACTIVE == p_app_value->condition) ||
        (BLE_ESS_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_WHEN_VALUE_CHANGES_COMPARED_TO_PREVIOUS_VALUE == p_app_value->condition))
    {
        /* Do Nothing */
    }
    else
    {
        /* Convert operand (24 bits) to byte sequence */
        BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], (uint32_t *)&p_app_value->operand[0]);
        pos += 3;
    }

    /* Update length */
    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

static const st_ble_servs_desc_info_t gs_elevation_0_es_trigger_2 = {
    .attr_hdl = BLE_ESS_ELEVATION_0_ES_TRIGGER_2_DESC_HDL,
    .app_size = sizeof(st_ble_ess_elevation_0_es_trigger_2_t),
    .desc_idx = BLE_ESS_ELEVATION_0_ES_TRIGGER_2_IDX,
    .db_size  = BLE_ESS_ELEVATION_0_ES_TRIGGER_2_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_st_ble_ess_elevation_0_es_trigger_2_t,
    .encode   = (ble_servs_attr_encode_t)encode_st_ble_ess_elevation_0_es_trigger_2_t,
};

ble_status_t R_BLE_ESS_SetElevation0EsTrigger2(const st_ble_ess_elevation_0_es_trigger_2_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_elevation_0_es_trigger_2, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_ESS_GetElevation0EsTrigger2(st_ble_ess_elevation_0_es_trigger_2_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_elevation_0_es_trigger_2, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Elevation 0 Environmental Sensing Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

static const st_ble_servs_desc_info_t gs_elevation_0_es_conf = {
    .attr_hdl = BLE_ESS_ELEVATION_0_ES_CONF_DESC_HDL,
    .app_size = sizeof(uint8_t),
    .desc_idx = BLE_ESS_ELEVATION_0_ES_CONF_IDX,
    .db_size  = BLE_ESS_ELEVATION_0_ES_CONF_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_uint8_t,
    .encode   = (ble_servs_attr_encode_t)encode_uint8_t,
};

ble_status_t R_BLE_ESS_SetElevation0EsConf(const uint8_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_elevation_0_es_conf, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_ESS_GetElevation0EsConf(uint8_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_elevation_0_es_conf, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Elevation 0 Characteristic User Description descriptor
----------------------------------------------------------------------------------------------------------------------*/

static ble_status_t decode_st_ble_ess_elevation_0_char_user_desc_t(st_ble_ess_elevation_0_char_user_desc_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    memset(&p_app_value->user_description[0], 0x00, sizeof(p_app_value->user_description));
    memcpy(&p_app_value->user_description[0], p_gatt_value->p_value, p_gatt_value->value_len);
    p_app_value->length = p_gatt_value->value_len;
    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_ess_elevation_0_char_user_desc_t(const st_ble_ess_elevation_0_char_user_desc_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    memcpy(p_gatt_value->p_value, p_app_value->user_description, p_app_value->length);
    p_gatt_value->value_len = p_app_value->length;

    return BLE_SUCCESS;
}

static const st_ble_servs_desc_info_t gs_elevation_0_char_user_desc = {
    .attr_hdl = BLE_ESS_ELEVATION_0_CHAR_USER_DESC_DESC_HDL,
    .app_size = sizeof(st_ble_ess_elevation_0_char_user_desc_t),
    .desc_idx = BLE_ESS_ELEVATION_0_CHAR_USER_DESC_IDX,
    .db_size  = BLE_ESS_ELEVATION_0_CHAR_USER_DESC_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_st_ble_ess_elevation_0_char_user_desc_t,
    .encode   = (ble_servs_attr_encode_t)encode_st_ble_ess_elevation_0_char_user_desc_t,
};

ble_status_t R_BLE_ESS_SetElevation0CharUserDesc(const st_ble_ess_elevation_0_char_user_desc_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_elevation_0_char_user_desc, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_ESS_GetElevation0CharUserDesc(st_ble_ess_elevation_0_char_user_desc_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_elevation_0_char_user_desc, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Elevation 0 Valid Range descriptor
----------------------------------------------------------------------------------------------------------------------*/

static ble_status_t decode_st_ble_ess_elevation_0_valid_range_t(st_ble_ess_elevation_0_valid_range_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    if (BLE_ESS_ELEVATION_0_VALID_RANGE_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    BT_UNPACK_LE_3_BYTE(&p_app_value->lower_inclusive_value, &p_gatt_value->p_value[0]);
    BT_UNPACK_LE_3_BYTE(&p_app_value->upper_inclusive_value, &p_gatt_value->p_value[3]);

    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_ess_elevation_0_valid_range_t(const st_ble_ess_elevation_0_valid_range_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_ESS_ELEVATION_0_VALID_RANGE_LEN);

    BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], (uint32_t *)&p_app_value->lower_inclusive_value);
    pos += 3;

    BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], (uint32_t *)&p_app_value->upper_inclusive_value);

    /* Update length */
    p_gatt_value->value_len = BLE_ESS_ELEVATION_0_VALID_RANGE_LEN;

    return BLE_SUCCESS;
}

static const st_ble_servs_desc_info_t gs_elevation_0_valid_range = {
    .attr_hdl = BLE_ESS_ELEVATION_0_VALID_RANGE_DESC_HDL,
    .app_size = sizeof(st_ble_ess_elevation_0_valid_range_t),
    .desc_idx = BLE_ESS_ELEVATION_0_VALID_RANGE_IDX,
    .db_size  = BLE_ESS_ELEVATION_0_VALID_RANGE_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_st_ble_ess_elevation_0_valid_range_t,
    .encode   = (ble_servs_attr_encode_t)encode_st_ble_ess_elevation_0_valid_range_t,
};

ble_status_t R_BLE_ESS_SetElevation0ValidRange(const st_ble_ess_elevation_0_valid_range_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_elevation_0_valid_range, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_ESS_GetElevation0ValidRange(st_ble_ess_elevation_0_valid_range_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_elevation_0_valid_range, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Elevation 0 characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Elevation 0 characteristic descriptor definition */
static const st_ble_servs_desc_info_t *gspp_elevation_0_descs[] = {
    &gs_elevation_0_cli_cnfg,
    &gs_elevation_0_es_meas,
    &gs_elevation_0_char_extended_properties,
    &gs_elevation_0_es_trigger_0,
    &gs_elevation_0_es_trigger_1,
    &gs_elevation_0_es_trigger_2,
    &gs_elevation_0_es_conf,
    &gs_elevation_0_char_user_desc,
    &gs_elevation_0_valid_range,
};

/* Elevation 0 characteristic definition */
static const st_ble_servs_char_info_t gs_elevation_0_char = {
    .start_hdl    = BLE_ESS_ELEVATION_0_DECL_HDL,
    .end_hdl      = BLE_ESS_ELEVATION_0_VALID_RANGE_DESC_HDL,
    .char_idx     = BLE_ESS_ELEVATION_0_IDX,
    .app_size     = sizeof(uint32_t),
    .db_size      = BLE_ESS_ELEVATION_0_LEN,
    .decode       = (ble_servs_attr_decode_t)decode_24bit,
    .encode       = (ble_servs_attr_encode_t)encode_24bit,
    .pp_descs     = gspp_elevation_0_descs,
    .num_of_descs = ARRAY_SIZE(gspp_elevation_0_descs),
};

ble_status_t R_BLE_ESS_SetElevation0(const int32_t *p_value)
{
    return R_BLE_SERVS_SetChar(&gs_elevation_0_char, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_ESS_GetElevation0(int32_t *p_value)
{
    return R_BLE_SERVS_GetChar(&gs_elevation_0_char, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

ble_status_t R_BLE_ESS_NotifyElevation0(uint16_t conn_hdl, const int32_t *p_value)
{
    return R_BLE_SERVS_SendHdlVal(&gs_elevation_0_char, conn_hdl, (const void *)p_value, true);
}

/*----------------------------------------------------------------------------------------------------------------------
    Elevation 1 Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

static const st_ble_servs_desc_info_t gs_elevation_1_cli_cnfg = {
    .attr_hdl = BLE_ESS_ELEVATION_1_CLI_CNFG_DESC_HDL,
    .app_size = sizeof(uint16_t),
    .desc_idx = BLE_ESS_ELEVATION_1_CLI_CNFG_IDX,
    .db_size  = BLE_ESS_ELEVATION_1_CLI_CNFG_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_uint16_t,
    .encode   = (ble_servs_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_ESS_SetElevation1CliCnfg(const uint16_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_elevation_1_cli_cnfg, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_ESS_GetElevation1CliCnfg(uint16_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_elevation_1_cli_cnfg, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Elevation 1 Environmental Sensing Measurement descriptor
----------------------------------------------------------------------------------------------------------------------*/
/***********************************************************************************************************************
 * Function Name: decode_st_ble_ess_elevation_1_es_meas_t
 * Description  : This function converts ES Measurement descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - Pointer to the ES Measurement descriptor value structure in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_ess_elevation_1_es_meas_t(st_ble_ess_elevation_1_es_meas_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    /* check the length */
    if (BLE_ESS_ELEVATION_1_ES_MEAS_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    memset(p_app_value, 0x00, sizeof(st_ble_ess_elevation_1_es_meas_t));

    /* Copy the flag */
    BT_UNPACK_LE_2_BYTE(&p_app_value->flags, &p_gatt_value->p_value[pos]);
    pos += 2;
    
    BT_UNPACK_LE_1_BYTE(&p_app_value->sampling_function, &p_gatt_value->p_value[pos]);
    pos += 1;

    BT_UNPACK_LE_3_BYTE(&p_app_value->measurement_period, &p_gatt_value->p_value[pos]);
    pos += 3;

    BT_UNPACK_LE_3_BYTE(&p_app_value->update_interval, &p_gatt_value->p_value[pos]);
    pos += 3;

    BT_UNPACK_LE_1_BYTE(&p_app_value->application, &p_gatt_value->p_value[pos]);
    pos += 1;

    BT_UNPACK_LE_1_BYTE(&p_app_value->measurement_uncertainty, &p_gatt_value->p_value[pos]);

    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_ess_elevation_1_es_meas_t(const st_ble_ess_elevation_1_es_meas_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_ESS_ELEVATION_1_ES_MEAS_LEN);

    /* Encode descriptor value fields */
    
    /* Copy the flag */
    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->flags);
    pos += 2;
    
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->sampling_function);
    pos += 1;

    BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], (uint32_t *)&p_app_value->measurement_period);
    pos += 3;

    BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], (uint32_t *)&p_app_value->update_interval);
    pos += 3;

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->application);
    pos += 1;

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->measurement_uncertainty);
    pos += 1;

    /* update length*/
    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

static const st_ble_servs_desc_info_t gs_elevation_1_es_meas = {
    .attr_hdl = BLE_ESS_ELEVATION_1_ES_MEAS_DESC_HDL,
    .app_size = sizeof(st_ble_ess_elevation_1_es_meas_t),
    .desc_idx = BLE_ESS_ELEVATION_1_ES_MEAS_IDX,
    .db_size  = BLE_ESS_ELEVATION_1_ES_MEAS_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_st_ble_ess_elevation_1_es_meas_t,
    .encode   = (ble_servs_attr_encode_t)encode_st_ble_ess_elevation_1_es_meas_t,
};

ble_status_t R_BLE_ESS_SetElevation1EsMeas(const st_ble_ess_elevation_1_es_meas_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_elevation_1_es_meas, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_ESS_GetElevation1EsMeas(st_ble_ess_elevation_1_es_meas_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_elevation_1_es_meas, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Elevation 1 Characteristic Extended Properties descriptor
----------------------------------------------------------------------------------------------------------------------*/

static const st_ble_servs_desc_info_t gs_elevation_1_char_extended_properties = {
    .attr_hdl = BLE_ESS_ELEVATION_1_CHAR_EXTENDED_PROPERTIES_DESC_HDL,
    .app_size = sizeof(uint16_t),
    .desc_idx = BLE_ESS_ELEVATION_1_CHAR_EXTENDED_PROPERTIES_IDX,
    .db_size  = BLE_ESS_ELEVATION_1_CHAR_EXTENDED_PROPERTIES_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_uint16_t,
    .encode   = (ble_servs_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_ESS_SetElevation1CharExtendedProperties(const uint16_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_elevation_1_char_extended_properties, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_ESS_GetElevation1CharExtendedProperties(uint16_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_elevation_1_char_extended_properties, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Elevation 1 Environmental Sensing Trigger Setting 0 descriptor
----------------------------------------------------------------------------------------------------------------------*/

static ble_status_t decode_st_ble_ess_elevation_1_es_trigger_0_t(st_ble_ess_elevation_1_es_trigger_0_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    memset(p_app_value, 0x00, sizeof(st_ble_ess_temperature_1_es_trigger_0_t));
    p_app_value->condition = p_gatt_value->p_value[0];
    if (p_gatt_value->value_len > 1)
    {
        memcpy(&p_app_value->operand[0], &p_gatt_value->p_value[1], p_gatt_value->value_len - 1);
    }
    
    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_ess_elevation_1_es_trigger_0_t(const st_ble_ess_elevation_1_es_trigger_0_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_ESS_ELEVATION_1_ES_TRIGGER_0_LEN);

    /* Copy the condition byte */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->condition);
    pos += 1;

    if ((BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_USE_A_FIXED_TIME_INTERVAL_BETWEEN_TRANSMISSIONS == p_app_value->condition)
        || (BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_NO_LESS_THAN_THE_SPECIFIED_TIME_BETWEEN_TRANSMISSIONS == p_app_value->condition))
    {
        /* Convert operand (24 bits) to byte sequence */
        BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], (uint32_t *)&p_app_value->operand[0]);
        pos += 3;
    }
    else if ((BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_TRIGGER_INACTIVE == p_app_value->condition) ||
        (BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_WHEN_VALUE_CHANGES_COMPARED_TO_PREVIOUS_VALUE == p_app_value->condition))
    {
        /* Do Nothing */
    }
    else
    {
        /* Convert operand (24 bits) to byte sequence */
        BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], (uint32_t *)&p_app_value->operand[0]);
        pos += 3;
    }

    /* Update length */
    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

static void write_req_elevation1_es_trigger(const void *p_attr, uint16_t conn_hdl, ble_status_t result, const st_ble_ess_elevation_1_es_trigger_0_t *p_app_value)
{
    if (BLE_ESS_ELEVATION_1_ES_TRIGGER_0_CONDITION_WHILE_NOT_EQUAL_TO_THE_SPECIFIED_VALUE < p_app_value->condition)
    {
        R_BLE_GATTS_SendErrRsp(BLE_ESS_CONDITION_NOT_SUPPORTED_ERROR);
    }
    else
    {
        st_ble_ess_elevation_1_valid_range_t valid_range;
        R_BLE_ESS_GetElevation1ValidRange(&valid_range);

        if ((BLE_ESS_ELEVATION_1_ES_TRIGGER_0_CONDITION_TRIGGER_INACTIVE != p_app_value->condition) &&
            (BLE_ESS_ELEVATION_1_ES_TRIGGER_0_CONDITION_USE_A_FIXED_TIME_INTERVAL_BETWEEN_TRANSMISSIONS != p_app_value->condition) &&
            (BLE_ESS_ELEVATION_1_ES_TRIGGER_0_CONDITION_NO_LESS_THAN_THE_SPECIFIED_TIME_BETWEEN_TRANSMISSIONS != p_app_value->condition) &&
            (BLE_ESS_ELEVATION_1_ES_TRIGGER_0_CONDITION_WHEN_VALUE_CHANGES_COMPARED_TO_PREVIOUS_VALUE != p_app_value->condition))
        {
            int32_t value;
            BT_UNPACK_LE_3_BYTE(&value, &p_app_value->operand[0]);

            if ((valid_range.lower_inclusive_value > value) || (valid_range.upper_inclusive_value < value))
            {
                R_BLE_GATTS_SendErrRsp(BLE_ERR_GATT_OUT_OF_RANGE);
            }
        }
    }
}

static const st_ble_servs_desc_info_t gs_elevation_1_es_trigger_0 = {
    .attr_hdl = BLE_ESS_ELEVATION_1_ES_TRIGGER_0_DESC_HDL,
    .app_size = sizeof(st_ble_ess_elevation_1_es_trigger_0_t),
    .desc_idx = BLE_ESS_ELEVATION_1_ES_TRIGGER_0_IDX,
    .db_size  = BLE_ESS_ELEVATION_1_ES_TRIGGER_0_LEN,
    .write_req_cb = (ble_servs_attr_write_req_t)write_req_elevation1_es_trigger,
    .decode   = (ble_servs_attr_decode_t)decode_st_ble_ess_elevation_1_es_trigger_0_t,
    .encode   = (ble_servs_attr_encode_t)encode_st_ble_ess_elevation_1_es_trigger_0_t,
};

ble_status_t R_BLE_ESS_SetElevation1EsTrigger0(const st_ble_ess_elevation_1_es_trigger_0_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_elevation_1_es_trigger_0, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_ESS_GetElevation1EsTrigger0(st_ble_ess_elevation_1_es_trigger_0_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_elevation_1_es_trigger_0, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Elevation 1 Environmental Sensing Trigger Setting 1 descriptor
----------------------------------------------------------------------------------------------------------------------*/

static ble_status_t decode_st_ble_ess_elevation_1_es_trigger_1_t(st_ble_ess_elevation_1_es_trigger_1_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    memset(p_app_value, 0x00, sizeof(st_ble_ess_temperature_1_es_trigger_0_t));
    p_app_value->condition = p_gatt_value->p_value[0];
    if (p_gatt_value->value_len > 1)
    {
        memcpy(&p_app_value->operand[0], &p_gatt_value->p_value[1], p_gatt_value->value_len - 1);
    }
    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_ess_elevation_1_es_trigger_1_t(const st_ble_ess_elevation_1_es_trigger_1_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_ESS_ELEVATION_1_ES_TRIGGER_1_LEN);

    /* Copy the condition byte */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->condition);
    pos += 1;

    if ((BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_USE_A_FIXED_TIME_INTERVAL_BETWEEN_TRANSMISSIONS == p_app_value->condition)
        || (BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_NO_LESS_THAN_THE_SPECIFIED_TIME_BETWEEN_TRANSMISSIONS == p_app_value->condition))
    {
        /* Convert operand (24 bits) to byte sequence */
        BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], (uint32_t *)&p_app_value->operand[0]);
        pos += 3;
    }
    else if ((BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_TRIGGER_INACTIVE == p_app_value->condition) ||
        (BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_WHEN_VALUE_CHANGES_COMPARED_TO_PREVIOUS_VALUE == p_app_value->condition))
    {
        /* Do Nothing */
    }
    else
    {
        /* Convert operand (24 bits) to byte sequence */
        BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], (uint32_t *)&p_app_value->operand[0]);
        pos += 3;
    }

    /* Update length */
    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

static const st_ble_servs_desc_info_t gs_elevation_1_es_trigger_1 = {
    .attr_hdl = BLE_ESS_ELEVATION_1_ES_TRIGGER_1_DESC_HDL,
    .app_size = sizeof(st_ble_ess_elevation_1_es_trigger_1_t),
    .desc_idx = BLE_ESS_ELEVATION_1_ES_TRIGGER_1_IDX,
    .db_size  = BLE_ESS_ELEVATION_1_ES_TRIGGER_1_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_st_ble_ess_elevation_1_es_trigger_1_t,
    .encode   = (ble_servs_attr_encode_t)encode_st_ble_ess_elevation_1_es_trigger_1_t,
};

ble_status_t R_BLE_ESS_SetElevation1EsTrigger1(const st_ble_ess_elevation_1_es_trigger_1_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_elevation_1_es_trigger_1, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_ESS_GetElevation1EsTrigger1(st_ble_ess_elevation_1_es_trigger_1_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_elevation_1_es_trigger_1, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Elevation 1 Environmental Sensing Trigger Setting 2 descriptor
----------------------------------------------------------------------------------------------------------------------*/

static ble_status_t decode_st_ble_ess_elevation_1_es_trigger_2_t(st_ble_ess_elevation_1_es_trigger_2_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    memset(p_app_value, 0x00, sizeof(st_ble_ess_temperature_1_es_trigger_0_t));
    p_app_value->condition = p_gatt_value->p_value[0];
    if (p_gatt_value->value_len > 1)
    {
        memcpy(&p_app_value->operand[0], &p_gatt_value->p_value[1], p_gatt_value->value_len - 1);
    }
    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_ess_elevation_1_es_trigger_2_t(const st_ble_ess_elevation_1_es_trigger_2_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_ESS_ELEVATION_1_ES_TRIGGER_2_LEN);

    /* Copy the condition byte */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->condition);
    pos += 1;

    if ((BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_USE_A_FIXED_TIME_INTERVAL_BETWEEN_TRANSMISSIONS == p_app_value->condition)
        || (BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_NO_LESS_THAN_THE_SPECIFIED_TIME_BETWEEN_TRANSMISSIONS == p_app_value->condition))
    {
        /* Convert operand (24 bits) to byte sequence */
        BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], (uint32_t *)&p_app_value->operand[0]);
        pos += 3;
    }
    else if ((BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_TRIGGER_INACTIVE == p_app_value->condition) ||
        (BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_WHEN_VALUE_CHANGES_COMPARED_TO_PREVIOUS_VALUE == p_app_value->condition))
    {
        /* Do Nothing */
    }
    else
    {
        /* Convert operand (24 bits) to byte sequence */
        BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], (uint32_t *)&p_app_value->operand[0]);
        pos += 3;
    }

    /* Update length */
    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

static const st_ble_servs_desc_info_t gs_elevation_1_es_trigger_2 = {
    .attr_hdl = BLE_ESS_ELEVATION_1_ES_TRIGGER_2_DESC_HDL,
    .app_size = sizeof(st_ble_ess_elevation_1_es_trigger_2_t),
    .desc_idx = BLE_ESS_ELEVATION_1_ES_TRIGGER_2_IDX,
    .db_size  = BLE_ESS_ELEVATION_1_ES_TRIGGER_2_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_st_ble_ess_elevation_1_es_trigger_2_t,
    .encode   = (ble_servs_attr_encode_t)encode_st_ble_ess_elevation_1_es_trigger_2_t,
};

ble_status_t R_BLE_ESS_SetElevation1EsTrigger2(const st_ble_ess_elevation_1_es_trigger_2_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_elevation_1_es_trigger_2, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_ESS_GetElevation1EsTrigger2(st_ble_ess_elevation_1_es_trigger_2_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_elevation_1_es_trigger_2, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Elevation 1 Environmental Sensing Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

static const st_ble_servs_desc_info_t gs_elevation_1_es_conf = {
    .attr_hdl = BLE_ESS_ELEVATION_1_ES_CONF_DESC_HDL,
    .app_size = sizeof(uint8_t),
    .desc_idx = BLE_ESS_ELEVATION_1_ES_CONF_IDX,
    .db_size  = BLE_ESS_ELEVATION_1_ES_CONF_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_uint8_t,
    .encode   = (ble_servs_attr_encode_t)encode_uint8_t,
};

ble_status_t R_BLE_ESS_SetElevation1EsConf(const uint8_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_elevation_1_es_conf, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_ESS_GetElevation1EsConf(uint8_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_elevation_1_es_conf, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Elevation 1 Characteristic User Description descriptor
----------------------------------------------------------------------------------------------------------------------*/

static ble_status_t decode_st_ble_ess_elevation_1_char_user_desc_t(st_ble_ess_elevation_1_char_user_desc_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    memset(&p_app_value->user_description[0], 0x00, sizeof(p_app_value->user_description));
    memcpy(&p_app_value->user_description[0], p_gatt_value->p_value, p_gatt_value->value_len);
    p_app_value->length = p_gatt_value->value_len;
    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_ess_elevation_1_char_user_desc_t(const st_ble_ess_elevation_1_char_user_desc_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    memcpy(p_gatt_value->p_value, p_app_value->user_description, p_app_value->length);
    p_gatt_value->value_len = p_app_value->length;

    return BLE_SUCCESS;
}

static const st_ble_servs_desc_info_t gs_elevation_1_char_user_desc = {
    .attr_hdl = BLE_ESS_ELEVATION_1_CHAR_USER_DESC_DESC_HDL,
    .app_size = sizeof(st_ble_ess_elevation_1_char_user_desc_t),
    .desc_idx = BLE_ESS_ELEVATION_1_CHAR_USER_DESC_IDX,
    .db_size  = BLE_ESS_ELEVATION_1_CHAR_USER_DESC_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_st_ble_ess_elevation_1_char_user_desc_t,
    .encode   = (ble_servs_attr_encode_t)encode_st_ble_ess_elevation_1_char_user_desc_t,
};

ble_status_t R_BLE_ESS_SetElevation1CharUserDesc(const st_ble_ess_elevation_1_char_user_desc_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_elevation_1_char_user_desc, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_ESS_GetElevation1CharUserDesc(st_ble_ess_elevation_1_char_user_desc_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_elevation_1_char_user_desc, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Elevation 1 Valid Range descriptor
----------------------------------------------------------------------------------------------------------------------*/

static ble_status_t decode_st_ble_ess_elevation_1_valid_range_t(st_ble_ess_elevation_1_valid_range_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    if (BLE_ESS_ELEVATION_1_VALID_RANGE_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    BT_UNPACK_LE_3_BYTE(&p_app_value->lower_inclusive_value, &p_gatt_value->p_value[0]);
    BT_UNPACK_LE_3_BYTE(&p_app_value->upper_inclusive_value, &p_gatt_value->p_value[3]);

    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_ess_elevation_1_valid_range_t(const st_ble_ess_elevation_1_valid_range_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_ESS_ELEVATION_1_VALID_RANGE_LEN);

    BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], (uint32_t *)&p_app_value->lower_inclusive_value);
    pos += 3;

    BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], (uint32_t *)&p_app_value->upper_inclusive_value);

    /* Update length */
    p_gatt_value->value_len = BLE_ESS_ELEVATION_1_VALID_RANGE_LEN;

    return BLE_SUCCESS;
}

static const st_ble_servs_desc_info_t gs_elevation_1_valid_range = {
    .attr_hdl = BLE_ESS_ELEVATION_1_VALID_RANGE_DESC_HDL,
    .app_size = sizeof(st_ble_ess_elevation_1_valid_range_t),
    .desc_idx = BLE_ESS_ELEVATION_1_VALID_RANGE_IDX,
    .db_size  = BLE_ESS_ELEVATION_1_VALID_RANGE_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_st_ble_ess_elevation_1_valid_range_t,
    .encode   = (ble_servs_attr_encode_t)encode_st_ble_ess_elevation_1_valid_range_t,
};

ble_status_t R_BLE_ESS_SetElevation1ValidRange(const st_ble_ess_elevation_1_valid_range_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_elevation_1_valid_range, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_ESS_GetElevation1ValidRange(st_ble_ess_elevation_1_valid_range_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_elevation_1_valid_range, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Elevation 1 characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Elevation 1 characteristic descriptor definition */
static const st_ble_servs_desc_info_t *gspp_elevation_1_descs[] = {
    &gs_elevation_1_cli_cnfg,
    &gs_elevation_1_es_meas,
    &gs_elevation_1_char_extended_properties,
    &gs_elevation_1_es_trigger_0,
    &gs_elevation_1_es_trigger_1,
    &gs_elevation_1_es_trigger_2,
    &gs_elevation_1_es_conf,
    &gs_elevation_1_char_user_desc,
    &gs_elevation_1_valid_range,
};

/* Elevation 1 characteristic definition */
static const st_ble_servs_char_info_t gs_elevation_1_char = {
    .start_hdl    = BLE_ESS_ELEVATION_1_DECL_HDL,
    .end_hdl      = BLE_ESS_ELEVATION_1_VALID_RANGE_DESC_HDL,
    .char_idx     = BLE_ESS_ELEVATION_1_IDX,
    .app_size     = sizeof(uint32_t),
    .db_size      = BLE_ESS_ELEVATION_1_LEN,
    .decode       = (ble_servs_attr_decode_t)decode_24bit,
    .encode       = (ble_servs_attr_encode_t)encode_24bit,
    .pp_descs     = gspp_elevation_1_descs,
    .num_of_descs = ARRAY_SIZE(gspp_elevation_1_descs),
};

ble_status_t R_BLE_ESS_SetElevation1(const int32_t *p_value)
{
    return R_BLE_SERVS_SetChar(&gs_elevation_1_char, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_ESS_GetElevation1(int32_t *p_value)
{
    return R_BLE_SERVS_GetChar(&gs_elevation_1_char, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

ble_status_t R_BLE_ESS_NotifyElevation1(uint16_t conn_hdl, const int32_t *p_value)
{
    return R_BLE_SERVS_SendHdlVal(&gs_elevation_1_char, conn_hdl, (const void *)p_value, true);
}

bool R_BLE_ESS_CheckElevation1Condition(const int32_t *p_value)
{
    if (NULL == p_value)
    {
        return false;
    }

    uint8_t conf;
    R_BLE_ESS_GetElevation1EsConf(&conf);

    st_ble_ess_elevation_1_es_trigger_0_t trigger[3];
    R_BLE_ESS_GetElevation1EsTrigger0(&trigger[0]);
    R_BLE_ESS_GetElevation1EsTrigger1((st_ble_ess_elevation_1_es_trigger_1_t *)(&trigger[1]));
    R_BLE_ESS_GetElevation1EsTrigger2((st_ble_ess_elevation_1_es_trigger_2_t *)(&trigger[2]));

    if (BLE_ESS_ELEVATION_1_ES_CONF_TRIGGER_LOGIC_BOOLEAN_AND == conf)
    {
        return
            check_elevation_trigger_condtion(&trigger[0], *p_value) &&
            check_elevation_trigger_condtion(&trigger[1], *p_value) &&
            check_elevation_trigger_condtion(&trigger[2], *p_value);
    }
    else if (BLE_ESS_ELEVATION_1_ES_CONF_TRIGGER_LOGIC_BOOLEAN_OR == conf)
    {
        uint8_t num_of_inactive = 0;

        for (uint8_t i = 0; i < 3; i++)
        {
            if (BLE_ESS_ELEVATION_1_ES_TRIGGER_0_CONDITION_TRIGGER_INACTIVE == trigger[i].condition)
            {
                num_of_inactive++;
            }
            else
            {
                bool ret;

                ret = check_elevation_trigger_condtion(&trigger[i], *p_value);
                if (ret)
                {
                    return true;
                }
            }
        }

        return (num_of_inactive == 3);
    }
    else
    {
        return false;
    }
}

/*----------------------------------------------------------------------------------------------------------------------
    Environmental Sensing server
----------------------------------------------------------------------------------------------------------------------*/

/* Environmental Sensing characteristics definition */
static const st_ble_servs_char_info_t *gspp_chars[] = {
    &gs_desc_value_changed_char,
    &gs_temperature_0_char,
    &gs_temperature_1_char,
    &gs_elevation_0_char,
    &gs_elevation_1_char,
};

/* Environmental Sensing service definition */
static st_ble_servs_info_t gs_servs_info = {
    .pp_chars     = gspp_chars,
    .num_of_chars = ARRAY_SIZE(gspp_chars),
};

ble_status_t R_BLE_ESS_Init(ble_servs_app_cb_t cb)
{
    if (NULL == cb)
    {
        return BLE_ERR_INVALID_PTR;
    }

    gs_servs_info.cb = cb;

    return R_BLE_SERVS_RegisterServer(&gs_servs_info);
}
