/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_ess.h
 * Version : 1.0
 * Description : The header file for Environmental Sensing service.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 31.12.2999 1.00 First Release
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @file
 * @defgroup ess Environmental Sensing Service Server
 * @{
 * @ingroup profile
 * @brief   This service exposes measurement data from an environmental sensor intended for sports and fitness applications. A wide range of environmental parameters is supported.
 **********************************************************************************************************************/
#include "profile_cmn/r_ble_servs_if.h"
#include "gatt_db.h"

#ifndef R_BLE_ESS_H
#define R_BLE_ESS_H

/*----------------------------------------------------------------------------------------------------------------------
    Descriptor Value Changed Characteristic
----------------------------------------------------------------------------------------------------------------------*/
/***************************************************************************//**
 * @brief Descriptor Value Changed Flags value structure.
*******************************************************************************/
typedef struct {
    bool is_changed_by_client; /**< Source of Change */
    bool is_one_or_more_es_trigger_setting_descriptors_changed; /**< Change to one or more ES Trigger Setting Descriptors */
    bool is_es_configuration_descriptor_changed; /**< Change to ES Configuration Descriptor */
    bool is_es_measurement_descriptor_changed; /**< Change to ES Measurement Descriptor */
    bool is_characteristic_user_description_descriptor_changed; /**< Change to Characteristic User Description Descriptor */
} st_ble_ess_desc_value_changed_flags_t;

/***************************************************************************//**
 * @brief Descriptor Value Changed value structure.
*******************************************************************************/
typedef struct {
    st_ble_ess_desc_value_changed_flags_t flags; /**< Flags */
    uint8_t uuid[16]; /**< UUID */
    uint8_t uuid_format; /**< UUID Format */
} st_ble_ess_desc_value_changed_t;

/***************************************************************************//**
 * @brief     Send indication of  Descriptor Value Changed characteristic value to the remote device.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value  Characteristic value to send.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_IndicateDescValueChanged(uint16_t conn_hdl, const st_ble_ess_desc_value_changed_t *p_value);

/***************************************************************************//**
 * @brief     Set Descriptor Value Changed cli cnfg descriptor value to the local GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_SetDescValueChangedCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Get Descriptor Value Changed cli cnfg descriptor value from the local GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_GetDescValueChangedCliCnfg(uint16_t conn_hdl, uint16_t *p_value);

/*----------------------------------------------------------------------------------------------------------------------
    Temperature 0 Characteristic
----------------------------------------------------------------------------------------------------------------------*/


/***************************************************************************//**
 * @brief Environmental Sensing Measurement Sampling Function enumeration.
*******************************************************************************/
typedef enum {
    BLE_ESS_TEMPERATURE_0_ES_MEAS_SAMPLING_FUNCTION_UNSPECIFIED = 0, /**< Unspecified */
    BLE_ESS_TEMPERATURE_0_ES_MEAS_SAMPLING_FUNCTION_INSTANTANEOUS = 1, /**< Instantaneous */
    BLE_ESS_TEMPERATURE_0_ES_MEAS_SAMPLING_FUNCTION_ARITHMETIC_MEAN = 2, /**< Arithmetic Mean */
    BLE_ESS_TEMPERATURE_0_ES_MEAS_SAMPLING_FUNCTION_RMS = 3, /**< RMS */
    BLE_ESS_TEMPERATURE_0_ES_MEAS_SAMPLING_FUNCTION_MAXIMUM = 4, /**< Maximum */
    BLE_ESS_TEMPERATURE_0_ES_MEAS_SAMPLING_FUNCTION_MINIMUM = 5, /**< Minimum */
    BLE_ESS_TEMPERATURE_0_ES_MEAS_SAMPLING_FUNCTION_ACCUMULATED = 6, /**< Accumulated */
    BLE_ESS_TEMPERATURE_0_ES_MEAS_SAMPLING_FUNCTION_COUNT = 7, /**< Count */
} e_ble_ess_temperature_0_es_meas_temp_0_sampling_function_t;

/***************************************************************************//**
 * @brief Environmental Sensing Measurement value structure.
*******************************************************************************/
typedef struct {
    uint16_t flags; /**< Flags */
    uint8_t sampling_function; /**< Sampling Function */
    uint32_t measurement_period; /**< Measurement Period */
    uint32_t update_interval; /**< Update Interval */
    uint8_t application; /**< Application */
    uint8_t measurement_uncertainty; /**< Measurement Uncertainty */
} st_ble_ess_temperature_0_es_meas_t;



/***************************************************************************//**
 * @brief Environmental Sensing Trigger Setting 0 Condition enumeration.
*******************************************************************************/
typedef enum {
    BLE_ESS_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_TRIGGER_INACTIVE = 0, /**< Trigger Inactive */
    BLE_ESS_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_USE_A_FIXED_TIME_INTERVAL_BETWEEN_TRANSMISSIONS = 1, /**< Use a fixed time interval between transmissions */
    BLE_ESS_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_NO_LESS_THAN_THE_SPECIFIED_TIME_BETWEEN_TRANSMISSIONS = 2, /**< No less than the specified time between transmissions */
    BLE_ESS_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_WHEN_VALUE_CHANGES_COMPARED_TO_PREVIOUS_VALUE = 3, /**< When value changes compared to previous value */
    BLE_ESS_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_WHILE_LESS_THAN_THE_SPECIFIED_VALUE = 4, /**< While less than the specified value */
    BLE_ESS_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_WHILE_LESS_THAN_OR_EQUAL_TO_THE_SPECIFIED_VALUE = 5, /**< While less than or equal to the specified value */
    BLE_ESS_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_WHILE_GREATER_THAN_THE_SPECIFIED_VALUE = 6, /**< While greater than the specified value */
    BLE_ESS_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_WHILE_GREATER_THAN_OR_EQUAL_TO_THE_SPECIFIED_VALUE = 7, /**< While greater than or equal to the specified value */
    BLE_ESS_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_WHILE_EQUAL_TO_THE_SPECIFIED_VALUE = 8, /**< While equal to the specified value */
    BLE_ESS_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_WHILE_NOT_EQUAL_TO_THE_SPECIFIED_VALUE = 9, /**< While not equal to the specified value */
} e_ble_ess_temperature_0_es_temp_0_trigger_0_condition_t;

/***************************************************************************//**
 * @brief Environmental Sensing Trigger Setting 0 value structure.
*******************************************************************************/
typedef struct {
    uint8_t condition; /**< Condition */
    uint8_t operand[3]; /**< Operand */
} st_ble_ess_temperature_0_es_trigger_0_t;


/***************************************************************************//**
 * @brief Environmental Sensing Trigger Setting 1 value structure.
*******************************************************************************/
typedef struct {
    uint8_t condition; /**< Condition */
    uint8_t operand[3]; /**< Operand */
} st_ble_ess_temperature_0_es_trigger_1_t;


/***************************************************************************//**
 * @brief Environmental Sensing Trigger Setting 2 value structure.
*******************************************************************************/
typedef struct {
    uint8_t condition; /**< Condition */
    uint8_t operand[3]; /**< Operand */
} st_ble_ess_temperature_0_es_trigger_2_t;


/***************************************************************************//**
 * @brief Environmental Sensing Configuration Trigger Logic enumeration.
*******************************************************************************/
typedef enum {
    BLE_ESS_TEMPERATURE_0_ES_CONF_TRIGGER_LOGIC_BOOLEAN_AND = 0, /**< Boolean AND */
    BLE_ESS_TEMPERATURE_0_ES_CONF_TRIGGER_LOGIC_BOOLEAN_OR = 1, /**< Boolean OR */
} e_ble_ess_temperature_0_es_conf_temp_0_trigger_logic_t;


/***************************************************************************//**
 * @brief Characteristic User Description value structure.
*******************************************************************************/
typedef struct {
    uint8_t user_description[98]; /**< User Description */
    uint16_t length; /**< Length */
} st_ble_ess_temperature_0_char_user_desc_t;


/***************************************************************************//**
 * @brief Valid Range value structure.
*******************************************************************************/
typedef struct {
    int16_t lower_inclusive_value; /**< Lower inclusive value */
    int16_t upper_inclusive_value; /**< Upper inclusive value */
} st_ble_ess_temperature_0_valid_range_t;

/***************************************************************************//**
 * @brief     Set Temperature 0 characteristic value to the local GATT database.
 * @param[in] p_value  Characteristic value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_SetTemperature0(const int16_t *p_value);

/***************************************************************************//**
 * @brief     Get Temperature 0 characteristic value from the local GATT database.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_GetTemperature0(int16_t *p_value);

/***************************************************************************//**
 * @brief     Send notification of  Temperature 0 characteristic value to the remote device.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value  Characteristic value to send.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_NotifyTemperature0(uint16_t conn_hdl, const int16_t *p_value);

/***************************************************************************//**
 * @brief     Set Temperature 0 cli cnfg descriptor value to the local GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_SetTemperature0CliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Get Temperature 0 cli cnfg descriptor value from the local GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_GetTemperature0CliCnfg(uint16_t conn_hdl, uint16_t *p_value);

/***************************************************************************//**
 * @brief     Set Temperature 0 es meas descriptor value to the local GATT database.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_SetTemperature0EsMeas(const st_ble_ess_temperature_0_es_meas_t *p_value);

/***************************************************************************//**
 * @brief     Get Temperature 0 es meas descriptor value from the local GATT database.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_GetTemperature0EsMeas(st_ble_ess_temperature_0_es_meas_t *p_value);

/***************************************************************************//**
 * @brief     Set Temperature 0 char extended properties descriptor value to the local GATT database.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_SetTemperature0CharExtendedProperties(const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Get Temperature 0 char extended properties descriptor value from the local GATT database.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_GetTemperature0CharExtendedProperties(uint16_t *p_value);

/***************************************************************************//**
 * @brief     Set Temperature 0 es trigger 0 descriptor value to the local GATT database.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_SetTemperature0EsTrigger0(const st_ble_ess_temperature_0_es_trigger_0_t *p_value);

/***************************************************************************//**
 * @brief     Get Temperature 0 es trigger 0 descriptor value from the local GATT database.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_GetTemperature0EsTrigger0(st_ble_ess_temperature_0_es_trigger_0_t *p_value);

/***************************************************************************//**
 * @brief     Set Temperature 0 es trigger 1 descriptor value to the local GATT database.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_SetTemperature0EsTrigger1(const st_ble_ess_temperature_0_es_trigger_1_t *p_value);

/***************************************************************************//**
 * @brief     Get Temperature 0 es trigger 1 descriptor value from the local GATT database.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_GetTemperature0EsTrigger1(st_ble_ess_temperature_0_es_trigger_1_t *p_value);

/***************************************************************************//**
 * @brief     Set Temperature 0 es trigger 2 descriptor value to the local GATT database.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_SetTemperature0EsTrigger2(const st_ble_ess_temperature_0_es_trigger_2_t *p_value);

/***************************************************************************//**
 * @brief     Get Temperature 0 es trigger 2 descriptor value from the local GATT database.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_GetTemperature0EsTrigger2(st_ble_ess_temperature_0_es_trigger_2_t *p_value);

/***************************************************************************//**
 * @brief     Set Temperature 0 es conf descriptor value to the local GATT database.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_SetTemperature0EsConf(const uint8_t *p_value);

/***************************************************************************//**
 * @brief     Get Temperature 0 es conf descriptor value from the local GATT database.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_GetTemperature0EsConf(uint8_t *p_value);

/***************************************************************************//**
 * @brief     Set Temperature 0 char user desc descriptor value to the local GATT database.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_SetTemperature0CharUserDesc(const st_ble_ess_temperature_0_char_user_desc_t *p_value);

/***************************************************************************//**
 * @brief     Get Temperature 0 char user desc descriptor value from the local GATT database.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_GetTemperature0CharUserDesc(st_ble_ess_temperature_0_char_user_desc_t *p_value);

/***************************************************************************//**
 * @brief     Set Temperature 0 valid range descriptor value to the local GATT database.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_SetTemperature0ValidRange(const st_ble_ess_temperature_0_valid_range_t *p_value);

/***************************************************************************//**
 * @brief     Get Temperature 0 valid range descriptor value from the local GATT database.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_GetTemperature0ValidRange(st_ble_ess_temperature_0_valid_range_t *p_value);

/*----------------------------------------------------------------------------------------------------------------------
    Temperature 1 Characteristic
----------------------------------------------------------------------------------------------------------------------*/


/***************************************************************************//**
 * @brief Environmental Sensing Measurement Sampling Function enumeration.
*******************************************************************************/
typedef enum {
    BLE_ESS_TEMPERATURE_1_ES_MEAS_SAMPLING_FUNCTION_UNSPECIFIED = 0, /**< Unspecified */
    BLE_ESS_TEMPERATURE_1_ES_MEAS_SAMPLING_FUNCTION_INSTANTANEOUS = 1, /**< Instantaneous */
    BLE_ESS_TEMPERATURE_1_ES_MEAS_SAMPLING_FUNCTION_ARITHMETIC_MEAN = 2, /**< Arithmetic Mean */
    BLE_ESS_TEMPERATURE_1_ES_MEAS_SAMPLING_FUNCTION_RMS = 3, /**< RMS */
    BLE_ESS_TEMPERATURE_1_ES_MEAS_SAMPLING_FUNCTION_MAXIMUM = 4, /**< Maximum */
    BLE_ESS_TEMPERATURE_1_ES_MEAS_SAMPLING_FUNCTION_MINIMUM = 5, /**< Minimum */
    BLE_ESS_TEMPERATURE_1_ES_MEAS_SAMPLING_FUNCTION_ACCUMULATED = 6, /**< Accumulated */
    BLE_ESS_TEMPERATURE_1_ES_MEAS_SAMPLING_FUNCTION_COUNT = 7, /**< Count */
} e_ble_ess_temperature_1_es_meas_temp_1_sampling_function_t;

/***************************************************************************//**
 * @brief Environmental Sensing Measurement value structure.
*******************************************************************************/
typedef struct {
    uint16_t flags; /**< Flags */
    uint8_t sampling_function; /**< Sampling Function */
    uint32_t measurement_period; /**< Measurement Period */
    uint32_t update_interval; /**< Update Interval */
    uint8_t application; /**< Application */
    uint8_t measurement_uncertainty; /**< Measurement Uncertainty */
} st_ble_ess_temperature_1_es_meas_t;



/***************************************************************************//**
 * @brief Environmental Sensing Trigger Setting 0 Condition enumeration.
*******************************************************************************/
typedef enum {
    BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_TRIGGER_INACTIVE = 0, /**< Trigger Inactive */
    BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_USE_A_FIXED_TIME_INTERVAL_BETWEEN_TRANSMISSIONS = 1, /**< Use a fixed time interval between transmissions */
    BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_NO_LESS_THAN_THE_SPECIFIED_TIME_BETWEEN_TRANSMISSIONS = 2, /**< No less than the specified time between transmissions */
    BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_WHEN_VALUE_CHANGES_COMPARED_TO_PREVIOUS_VALUE = 3, /**< When value chances compared to previous value */
    BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_WHILE_LESS_THAN_THE_SPECIFIED_VALUE = 4, /**< While less than the specified value */
    BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_WHILE_LESS_THAN_OR_EQUAL_TO_THE_SPECIFIED_VALUE = 5, /**< While less than or equal to the specified value */
    BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_WHILE_GREATER_THAN_THE_SPECIFIED_VALUE = 6, /**< While greater than the specified value */
    BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_WHILE_GREATER_THAN_OR_EQUAL_TO_THE_SPECIFIED_VALUE = 7, /**< While greater than or equal to the specified value */
    BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_WHILE_EQUAL_TO_THE_SPECIFIED_VALUE = 8, /**< While equal to the specified value */
    BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_WHILE_NOT_EQUAL_TO_THE_SPECIFIED_VALUE = 9, /**< While not equal to the specified value */
} e_ble_ess_temperature_1_es_temp_1_trigger_0_condition_t;

/***************************************************************************//**
 * @brief Environmental Sensing Trigger Setting 0 value structure.
*******************************************************************************/
typedef struct {
    uint8_t condition; /**< Condition */
    uint8_t operand[3]; /**< Operand */
} st_ble_ess_temperature_1_es_trigger_0_t;


/***************************************************************************//**
 * @brief Environmental Sensing Trigger Setting 1 value structure.
*******************************************************************************/
typedef struct {
    uint8_t condition; /**< Condition */
    uint8_t operand[3]; /**< Operand */
} st_ble_ess_temperature_1_es_trigger_1_t;


/***************************************************************************//**
 * @brief Environmental Sensing Trigger Setting 2 value structure.
*******************************************************************************/
typedef struct {
    uint8_t condition; /**< Condition */
    uint8_t operand[3]; /**< Operand */
} st_ble_ess_temperature_1_es_trigger_2_t;


/***************************************************************************//**
 * @brief Environmental Sensing Configuration Trigger Logic enumeration.
*******************************************************************************/
typedef enum {
    BLE_ESS_TEMPERATURE_1_ES_CONF_TRIGGER_LOGIC_BOOLEAN_AND = 0, /**< Boolean AND */
    BLE_ESS_TEMPERATURE_1_ES_CONF_TRIGGER_LOGIC_BOOLEAN_OR = 1, /**< Boolean OR */
} e_ble_ess_temperature_1_es_conf_temp_1_trigger_logic_t;


/***************************************************************************//**
 * @brief Characteristic User Description value structure.
*******************************************************************************/
typedef struct {
    uint8_t user_description[98]; /**< User Description */
    uint16_t length; /**< Length */
} st_ble_ess_temperature_1_char_user_desc_t;


/***************************************************************************//**
 * @brief Valid Range value structure.
*******************************************************************************/
typedef struct {
    int16_t lower_inclusive_value; /**< Lower inclusive value */
    int16_t upper_inclusive_value; /**< Upper inclusive value */
} st_ble_ess_temperature_1_valid_range_t;

/***************************************************************************//**
 * @brief     Set Temperature 1 characteristic value to the local GATT database.
 * @param[in] p_value  Characteristic value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_SetTemperature1(const int16_t *p_value);

/***************************************************************************//**
 * @brief     Get Temperature 1 characteristic value from the local GATT database.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_GetTemperature1(int16_t *p_value);

/***************************************************************************//**
 * @brief     Send notification of  Temperature 1 characteristic value to the remote device.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value  Characteristic value to send.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_NotifyTemperature1(uint16_t conn_hdl, const int16_t *p_value);

/***************************************************************************//**
 * @brief     Check whether p_value satisfy the ES trigger conditions.
 * @param[in] p_value  Characteristic value to check.
 * @return    @ref ble_status_t
*******************************************************************************/
bool R_BLE_ESS_CheckTemperature1Condition(const int16_t *p_value);

/***************************************************************************//**
 * @brief     Set Temperature 1 cli cnfg descriptor value to the local GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_SetTemperature1CliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Get Temperature 1 cli cnfg escriptor value from the local GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_GetTemperature1CliCnfg(uint16_t conn_hdl, uint16_t *p_value);

/***************************************************************************//**
 * @brief     Set Temperature 1 es meas descriptor value to the local GATT database.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_SetTemperature1EsMeas(const st_ble_ess_temperature_1_es_meas_t *p_value);

/***************************************************************************//**
 * @brief     Get Temperature 1 es meas descriptor value from the local GATT database.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_GetTemperature1EsMeas(st_ble_ess_temperature_1_es_meas_t *p_value);

/***************************************************************************//**
 * @brief     Set Temperature 1 char extended properties descriptor value to the local GATT database.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_SetTemperature1CharExtendedProperties(const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Get Temperature 1 char extended properties descriptor value from the local GATT database.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_GetTemperature1CharExtendedProperties(uint16_t *p_value);

/***************************************************************************//**
 * @brief     Set Temperature 1 es trigger 0 descriptor value to the local GATT database.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_SetTemperature1EsTrigger0(const st_ble_ess_temperature_1_es_trigger_0_t *p_value);

/***************************************************************************//**
 * @brief     Get Temperature 1 es trigger 0 descriptor value from the local GATT database.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_GetTemperature1EsTrigger0(st_ble_ess_temperature_1_es_trigger_0_t *p_value);

/***************************************************************************//**
 * @brief     Set Temperature 1 es trigger 1 descriptor value to the local GATT database.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_SetTemperature1EsTrigger1(const st_ble_ess_temperature_1_es_trigger_1_t *p_value);

/***************************************************************************//**
 * @brief     Get Temperature 1 es trigger 1 descriptor value from the local GATT database.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_GetTemperature1EsTrigger1(st_ble_ess_temperature_1_es_trigger_1_t *p_value);

/***************************************************************************//**
 * @brief     Set Temperature 1 es trigger 2 descriptor value to the local GATT database.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_SetTemperature1EsTrigger2(const st_ble_ess_temperature_1_es_trigger_2_t *p_value);

/***************************************************************************//**
 * @brief     Get Temperature 1 es trigger 2 descriptor value from the local GATT database.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_GetTemperature1EsTrigger2(st_ble_ess_temperature_1_es_trigger_2_t *p_value);

/***************************************************************************//**
 * @brief     Set Temperature 1 es conf descriptor value to the local GATT database.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_SetTemperature1EsConf(const uint8_t *p_value);

/***************************************************************************//**
 * @brief     Get Temperature 1 es conf descriptor value from the local GATT database.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_GetTemperature1EsConf(uint8_t *p_value);

/***************************************************************************//**
 * @brief     Set Temperature 1 char user desc descriptor value to the local GATT database.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_SetTemperature1CharUserDesc(const st_ble_ess_temperature_1_char_user_desc_t *p_value);

/***************************************************************************//**
 * @brief     Get Temperature 1 char user desc descriptor value from the local GATT database.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_GetTemperature1CharUserDesc(st_ble_ess_temperature_1_char_user_desc_t *p_value);

/***************************************************************************//**
 * @brief     Set Temperature 1 valid range descriptor value to the local GATT database.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_SetTemperature1ValidRange(const st_ble_ess_temperature_1_valid_range_t *p_value);

/***************************************************************************//**
 * @brief     Get Temperature 1 valid range descriptor value from the local GATT database.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_GetTemperature1ValidRange(st_ble_ess_temperature_1_valid_range_t *p_value);

/*----------------------------------------------------------------------------------------------------------------------
    Elevation 0 Characteristic
----------------------------------------------------------------------------------------------------------------------*/


/***************************************************************************//**
 * @brief Environmental Sensing Measurement Sampling Function enumeration.
*******************************************************************************/
typedef enum {
    BLE_ESS_ELEVATION_0_ES_MEAS_SAMPLING_FUNCTION_UNSPECIFIED = 0, /**< Unspecified */
    BLE_ESS_ELEVATION_0_ES_MEAS_SAMPLING_FUNCTION_INSTANTANEOUS = 1, /**< Instantaneous */
    BLE_ESS_ELEVATION_0_ES_MEAS_SAMPLING_FUNCTION_ARITHMETIC_MEAN = 2, /**< Arithmetic Mean */
    BLE_ESS_ELEVATION_0_ES_MEAS_SAMPLING_FUNCTION_RMS = 3, /**< RMS */
    BLE_ESS_ELEVATION_0_ES_MEAS_SAMPLING_FUNCTION_MAXIMUM = 4, /**< Maximum */
    BLE_ESS_ELEVATION_0_ES_MEAS_SAMPLING_FUNCTION_MINIMUM = 5, /**< Minimum */
    BLE_ESS_ELEVATION_0_ES_MEAS_SAMPLING_FUNCTION_ACCUMULATED = 6, /**< Accumulated */
    BLE_ESS_ELEVATION_0_ES_MEAS_SAMPLING_FUNCTION_COUNT = 7, /**< Count */
} e_ble_ess_elevation_0_es_meas_elev_0_sampling_function_t;

/***************************************************************************//**
 * @brief Environmental Sensing Measurement value structure.
*******************************************************************************/
typedef struct {
    uint16_t flags; /**< Flags */
    uint8_t sampling_function; /**< Sampling Function */
    uint32_t measurement_period; /**< Measurement Period */
    uint32_t update_interval; /**< Update Interval */
    uint8_t application; /**< Application */
    uint8_t measurement_uncertainty; /**< Measurement Uncertainty */
} st_ble_ess_elevation_0_es_meas_t;



/***************************************************************************//**
 * @brief Environmental Sensing Trigger Setting 0 Condition enumeration.
*******************************************************************************/
typedef enum {
    BLE_ESS_ELEVATION_0_ES_TRIGGER_0_CONDITION_TRIGGER_INACTIVE = 0, /**< Trigger Inactive */
    BLE_ESS_ELEVATION_0_ES_TRIGGER_0_CONDITION_USE_A_FIXED_TIME_INTERVAL_BETWEEN_TRANSMISSIONS = 1, /**< Use a fixed time interval between transmissions */
    BLE_ESS_ELEVATION_0_ES_TRIGGER_0_CONDITION_NO_LESS_THAN_THE_SPECIFIED_TIME_BETWEEN_TRANSMISSIONS = 2, /**< No less than the specified time between transmissions */
    BLE_ESS_ELEVATION_0_ES_TRIGGER_0_CONDITION_WHEN_VALUE_CHANGES_COMPARED_TO_PREVIOUS_VALUE = 3, /**< When value changes compared to previous value */
    BLE_ESS_ELEVATION_0_ES_TRIGGER_0_CONDITION_WHILE_LESS_THAN_THE_SPECIFIED_VALUE = 4, /**< While less than the specified value */
    BLE_ESS_ELEVATION_0_ES_TRIGGER_0_CONDITION_WHILE_LESS_THAN_OR_EQUAL_TO_THE_SPECIFIED_VALUE = 5, /**< While less than or equal to the specified value */
    BLE_ESS_ELEVATION_0_ES_TRIGGER_0_CONDITION_WHILE_GREATER_THAN_THE_SPECIFIED_VALUE = 6, /**< While greater than the specified value */
    BLE_ESS_ELEVATION_0_ES_TRIGGER_0_CONDITION_WHILE_GREATER_THAN_OR_EQUAL_TO_THE_SPECIFIED_VALUE = 7, /**< While greater than or equal to the specified value */
    BLE_ESS_ELEVATION_0_ES_TRIGGER_0_CONDITION_WHILE_EQUAL_TO_THE_SPECIFIED_VALUE = 8, /**< While equal to the specified value */
    BLE_ESS_ELEVATION_0_ES_TRIGGER_0_CONDITION_WHILE_NOT_EQUAL_TO_THE_SPECIFIED_VALUE = 9, /**< While not equal to the specified value */
} e_ble_ess_elevation_0_es_elev_0_trigger_0_condition_t;

/***************************************************************************//**
 * @brief Environmental Sensing Trigger Setting 0 value structure.
*******************************************************************************/
typedef struct {
    uint8_t condition; /**< Condition */
    uint8_t operand[3]; /**< Operand */
} st_ble_ess_elevation_0_es_trigger_0_t;


/***************************************************************************//**
 * @brief Environmental Sensing Trigger Setting 1 value structure.
*******************************************************************************/
typedef struct {
    uint8_t condition; /**< Condition */
    uint8_t operand[3]; /**< Operand */
} st_ble_ess_elevation_0_es_trigger_1_t;


/***************************************************************************//**
 * @brief Environmental Sensing Trigger Setting 2 value structure.
*******************************************************************************/
typedef struct {
    uint8_t condition; /**< Condition */
    uint8_t operand[3]; /**< Operand */
} st_ble_ess_elevation_0_es_trigger_2_t;


/***************************************************************************//**
 * @brief Environmental Sensing Configuration Trigger Logic enumeration.
*******************************************************************************/
typedef enum {
    BLE_ESS_ELEVATION_0_ES_CONF_TRIGGER_LOGIC_BOOLEAN_AND = 0, /**< Boolean AND */
    BLE_ESS_ELEVATION_0_ES_CONF_TRIGGER_LOGIC_BOOLEAN_OR = 1, /**< Boolean OR */
} e_ble_ess_elevation_0_es_conf_elev_0_trigger_logic_t;


/***************************************************************************//**
 * @brief Characteristic User Description value structure.
*******************************************************************************/
typedef struct {
    uint8_t user_description[98]; /**< User Description */
    uint16_t length; /**< Length */
} st_ble_ess_elevation_0_char_user_desc_t;


/***************************************************************************//**
 * @brief Valid Range value structure.
*******************************************************************************/
typedef struct {
    int32_t lower_inclusive_value; /**< Lower inclusive value */
    int32_t upper_inclusive_value; /**< Upper inclusive value */
} st_ble_ess_elevation_0_valid_range_t;

/***************************************************************************//**
 * @brief     Set Elevation 0 characteristic value to the local GATT database.
 * @param[in] p_value  Characteristic value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_SetElevation0(const int32_t *p_value);

/***************************************************************************//**
 * @brief     Get Elevation 0 characteristic value from the local GATT database.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_GetElevation0(int32_t *p_value);

/***************************************************************************//**
 * @brief     Send notification of  Elevation 0 characteristic value to the remote device.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value  Characteristic value to send.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_NotifyElevation0(uint16_t conn_hdl, const int32_t *p_value);

/***************************************************************************//**
 * @brief     Set Elevation 0 cli cnfg descriptor value to the local GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_SetElevation0CliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Get Elevation 0 cli cnfg descriptor value from the local GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_GetElevation0CliCnfg(uint16_t conn_hdl, uint16_t *p_value);

/***************************************************************************//**
 * @brief     Set Elevation 0 es meas descriptor value to the local GATT database.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_SetElevation0EsMeas(const st_ble_ess_elevation_0_es_meas_t *p_value);

/***************************************************************************//**
 * @brief     Get Elevation 0 es meas descriptor value from the local GATT database.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_GetElevation0EsMeas(st_ble_ess_elevation_0_es_meas_t *p_value);

/***************************************************************************//**
 * @brief     Set Elevation 0 char extended properties descriptor value to the local GATT database.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_SetElevation0CharExtendedProperties(const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Get Elevation 0 char extended properties descriptor value from the local GATT database.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_GetElevation0CharExtendedProperties(uint16_t *p_value);

/***************************************************************************//**
 * @brief     Set Elevation 0 es trigger 0 descriptor value to the local GATT database.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_SetElevation0EsTrigger0(const st_ble_ess_elevation_0_es_trigger_0_t *p_value);

/***************************************************************************//**
 * @brief     Get Elevation 0 es trigger 0 descriptor value from the local GATT database.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_GetElevation0EsTrigger0(st_ble_ess_elevation_0_es_trigger_0_t *p_value);

/***************************************************************************//**
 * @brief     Set Elevation 0 es trigger 1 descriptor value to the local GATT database.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_SetElevation0EsTrigger1(const st_ble_ess_elevation_0_es_trigger_1_t *p_value);

/***************************************************************************//**
 * @brief     Get Elevation 0 es trigger 1 descriptor value from the local GATT database.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_GetElevation0EsTrigger1(st_ble_ess_elevation_0_es_trigger_1_t *p_value);

/***************************************************************************//**
 * @brief     Set Elevation 0 es trigger 2 descriptor value to the local GATT database.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_SetElevation0EsTrigger2(const st_ble_ess_elevation_0_es_trigger_2_t *p_value);

/***************************************************************************//**
 * @brief     Get Elevation 0 es trigger 2 descriptor value from the local GATT database.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_GetElevation0EsTrigger2(st_ble_ess_elevation_0_es_trigger_2_t *p_value);

/***************************************************************************//**
 * @brief     Set Elevation 0 es conf descriptor value to the local GATT database.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_SetElevation0EsConf(const uint8_t *p_value);

/***************************************************************************//**
 * @brief     Get Elevation 0 es conf descriptor value from the local GATT database.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_GetElevation0EsConf(uint8_t *p_value);

/***************************************************************************//**
 * @brief     Set Elevation 0 char user desc descriptor value to the local GATT database.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_SetElevation0CharUserDesc(const st_ble_ess_elevation_0_char_user_desc_t *p_value);

/***************************************************************************//**
 * @brief     Get Elevation 0 char user desc descriptor value from the local GATT database.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_GetElevation0CharUserDesc(st_ble_ess_elevation_0_char_user_desc_t *p_value);

/***************************************************************************//**
 * @brief     Set Elevation 0 valid range descriptor value to the local GATT database.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_SetElevation0ValidRange(const st_ble_ess_elevation_0_valid_range_t *p_value);

/***************************************************************************//**
 * @brief     Get Elevation 0 valid range descriptor value from the local GATT database.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_GetElevation0ValidRange(st_ble_ess_elevation_0_valid_range_t *p_value);

/*----------------------------------------------------------------------------------------------------------------------
    Elevation 1 Characteristic
----------------------------------------------------------------------------------------------------------------------*/


/***************************************************************************//**
 * @brief Environmental Sensing Measurement Sampling Function enumeration.
*******************************************************************************/
typedef enum {
    BLE_ESS_ELEVATION_1_ES_MEAS_SAMPLING_FUNCTION_UNSPECIFIED = 0, /**< Unspecified */
    BLE_ESS_ELEVATION_1_ES_MEAS_SAMPLING_FUNCTION_INSTANTANEOUS = 1, /**< Instantaneous */
    BLE_ESS_ELEVATION_1_ES_MEAS_SAMPLING_FUNCTION_ARITHMETIC_MEAN = 2, /**< Arithmetic Mean */
    BLE_ESS_ELEVATION_1_ES_MEAS_SAMPLING_FUNCTION_RMS = 3, /**< RMS */
    BLE_ESS_ELEVATION_1_ES_MEAS_SAMPLING_FUNCTION_MAXIMUM = 4, /**< Maximum */
    BLE_ESS_ELEVATION_1_ES_MEAS_SAMPLING_FUNCTION_MINIMUM = 5, /**< Minimum */
    BLE_ESS_ELEVATION_1_ES_MEAS_SAMPLING_FUNCTION_ACCUMULATED = 6, /**< Accumulated */
    BLE_ESS_ELEVATION_1_ES_MEAS_SAMPLING_FUNCTION_COUNT = 7, /**< Count */
} e_ble_ess_elevation_1_es_meas_elev_1_sampling_function_t;

/***************************************************************************//**
 * @brief Environmental Sensing Measurement value structure.
*******************************************************************************/
typedef struct {
    uint16_t flags; /**< Flags */
    uint8_t sampling_function; /**< Sampling Function */
    uint32_t measurement_period; /**< Measurement Period */
    uint32_t update_interval; /**< Update Interval */
    uint8_t application; /**< Application */
    uint8_t measurement_uncertainty; /**< Measurement Uncertainty */
} st_ble_ess_elevation_1_es_meas_t;



/***************************************************************************//**
 * @brief Environmental Sensing Trigger Setting 0 Condition enumeration.
*******************************************************************************/
typedef enum {
    BLE_ESS_ELEVATION_1_ES_TRIGGER_0_CONDITION_TRIGGER_INACTIVE = 0, /**< Trigger Inactive */
    BLE_ESS_ELEVATION_1_ES_TRIGGER_0_CONDITION_USE_A_FIXED_TIME_INTERVAL_BETWEEN_TRANSMISSIONS = 1, /**< Use a fixed time interval between transmissions */
    BLE_ESS_ELEVATION_1_ES_TRIGGER_0_CONDITION_NO_LESS_THAN_THE_SPECIFIED_TIME_BETWEEN_TRANSMISSIONS = 2, /**< No less than the specified time between transmissions */
    BLE_ESS_ELEVATION_1_ES_TRIGGER_0_CONDITION_WHEN_VALUE_CHANGES_COMPARED_TO_PREVIOUS_VALUE = 3, /**< When value changes compared to previous value */
    BLE_ESS_ELEVATION_1_ES_TRIGGER_0_CONDITION_WHILE_LESS_THAN_THE_SPECIFIED_VALUE = 4, /**< While less than the specified value */
    BLE_ESS_ELEVATION_1_ES_TRIGGER_0_CONDITION_WHILE_LESS_THAN_OR_EQUAL_TO_THE_SPECIFIED_VALUE = 5, /**< While less than or equal to the specified value */
    BLE_ESS_ELEVATION_1_ES_TRIGGER_0_CONDITION_WHILE_GREATER_THAN_THE_SPECIFIED_VALUE = 6, /**< While greater than the specified value */
    BLE_ESS_ELEVATION_1_ES_TRIGGER_0_CONDITION_WHILE_GREATER_THAN_OR_EQUAL_TO_THE_SPECIFIED_VALUE = 7, /**< While greater than or equal to the specified value */
    BLE_ESS_ELEVATION_1_ES_TRIGGER_0_CONDITION_WHILE_EQUAL_TO_THE_SPECIFIED_VALUE = 8, /**< While equal to the specified value */
    BLE_ESS_ELEVATION_1_ES_TRIGGER_0_CONDITION_WHILE_NOT_EQUAL_TO_THE_SPECIFIED_VALUE = 9, /**< While not equal to the specified value */
} e_ble_ess_elevation_1_es_elev_1_trigger_0_condition_t;

/***************************************************************************//**
 * @brief Environmental Sensing Trigger Setting 0 value structure.
*******************************************************************************/
typedef struct {
    uint8_t condition; /**< Condition */
    uint8_t operand[3]; /**< Operand */
} st_ble_ess_elevation_1_es_trigger_0_t;


/***************************************************************************//**
 * @brief Environmental Sensing Trigger Setting 1 value structure.
*******************************************************************************/
typedef struct {
    uint8_t condition; /**< Condition */
    uint8_t operand[3]; /**< Operand */
} st_ble_ess_elevation_1_es_trigger_1_t;


/***************************************************************************//**
 * @brief Environmental Sensing Trigger Setting 2 value structure.
*******************************************************************************/
typedef struct {
    uint8_t condition; /**< Condition */
    uint8_t operand[3]; /**< Operand */
} st_ble_ess_elevation_1_es_trigger_2_t;


/***************************************************************************//**
 * @brief Environmental Sensing Configuration Trigger Logic enumeration.
*******************************************************************************/
typedef enum {
    BLE_ESS_ELEVATION_1_ES_CONF_TRIGGER_LOGIC_BOOLEAN_AND = 0, /**< Boolean AND */
    BLE_ESS_ELEVATION_1_ES_CONF_TRIGGER_LOGIC_BOOLEAN_OR = 1, /**< Boolean OR */
} e_ble_ess_elevation_1_es_conf_elev_1_trigger_logic_t;


/***************************************************************************//**
 * @brief Characteristic User Description value structure.
*******************************************************************************/
typedef struct {
    uint8_t user_description[98]; /**< User Description */
    uint16_t length; /**< Length */
} st_ble_ess_elevation_1_char_user_desc_t;


/***************************************************************************//**
 * @brief Valid Range value structure.
*******************************************************************************/
typedef struct {
    int32_t lower_inclusive_value; /**< Lower inclusive value */
    int32_t upper_inclusive_value; /**< Upper inclusive value */
} st_ble_ess_elevation_1_valid_range_t;

/***************************************************************************//**
 * @brief     Set Elevation 1 characteristic value to the local GATT database.
 * @param[in] p_value  Characteristic value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_SetElevation1(const int32_t *p_value);

/***************************************************************************//**
 * @brief     Get Elevation 1 characteristic value from the local GATT database.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_GetElevation1(int32_t *p_value);

/***************************************************************************//**
 * @brief     Send notification of  Elevation 1 characteristic value to the remote device.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value  Characteristic value to send.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_NotifyElevation1(uint16_t conn_hdl, const int32_t *p_value);

/***************************************************************************//**
 * @brief     Check whether p_value satisfy the ES trigger conditions.
 * @param[in] p_value  Characteristic value to check.
 * @return    @ref ble_status_t
*******************************************************************************/
bool R_BLE_ESS_CheckElevation1Condition(const int32_t *p_value);

/***************************************************************************//**
 * @brief     Set Elevation 1 cli cnfg descriptor value to the local GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_SetElevation1CliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Get Elevation 1 cli cnfg descriptor value from the local GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_GetElevation1CliCnfg(uint16_t conn_hdl, uint16_t *p_value);

/***************************************************************************//**
 * @brief     Set Elevation 1 es meas descriptor value to the local GATT database.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_SetElevation1EsMeas(const st_ble_ess_elevation_1_es_meas_t *p_value);

/***************************************************************************//**
 * @brief     Get Elevation 1 es meas descriptor value from the local GATT database.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_GetElevation1EsMeas(st_ble_ess_elevation_1_es_meas_t *p_value);

/***************************************************************************//**
 * @brief     Set Elevation 1 char extended properties descriptor value to the local GATT database.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_SetElevation1CharExtendedProperties(const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Get Elevation 1 char extended properties descriptor value from the local GATT database.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_GetElevation1CharExtendedProperties(uint16_t *p_value);

/***************************************************************************//**
 * @brief     Set Elevation 1 es trigger 0 descriptor value to the local GATT database.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_SetElevation1EsTrigger0(const st_ble_ess_elevation_1_es_trigger_0_t *p_value);

/***************************************************************************//**
 * @brief     Get Elevation 1 es trigger 0 descriptor value from the local GATT database.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_GetElevation1EsTrigger0(st_ble_ess_elevation_1_es_trigger_0_t *p_value);

/***************************************************************************//**
 * @brief     Set Elevation 1 es trigger 1 descriptor value to the local GATT database.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_SetElevation1EsTrigger1(const st_ble_ess_elevation_1_es_trigger_1_t *p_value);

/***************************************************************************//**
 * @brief     Get Elevation 1 es trigger 1 descriptor value from the local GATT database.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_GetElevation1EsTrigger1(st_ble_ess_elevation_1_es_trigger_1_t *p_value);

/***************************************************************************//**
 * @brief     Set Elevation 1 es trigger 2 descriptor value to the local GATT database.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_SetElevation1EsTrigger2(const st_ble_ess_elevation_1_es_trigger_2_t *p_value);

/***************************************************************************//**
 * @brief     Get Elevation 1 es trigger 2 descriptor value from the local GATT database.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_GetElevation1EsTrigger2(st_ble_ess_elevation_1_es_trigger_2_t *p_value);

/***************************************************************************//**
 * @brief     Set Elevation 1 es conf descriptor value to the local GATT database.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_SetElevation1EsConf(const uint8_t *p_value);

/***************************************************************************//**
 * @brief     Get Elevation 1 es conf descriptor value from the local GATT database.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_GetElevation1EsConf(uint8_t *p_value);

/***************************************************************************//**
 * @brief     Set Elevation 1 char user desc descriptor value to the local GATT database.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_SetElevation1CharUserDesc(const st_ble_ess_elevation_1_char_user_desc_t *p_value);

/***************************************************************************//**
 * @brief     Get Elevation 1 char user desc descriptor value from the local GATT database.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_GetElevation1CharUserDesc(st_ble_ess_elevation_1_char_user_desc_t *p_value);

/***************************************************************************//**
 * @brief     Set Elevation 1 valid range descriptor value to the local GATT database.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_SetElevation1ValidRange(const st_ble_ess_elevation_1_valid_range_t *p_value);

/***************************************************************************//**
 * @brief     Get Elevation 1 valid range descriptor value from the local GATT database.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_GetElevation1ValidRange(st_ble_ess_elevation_1_valid_range_t *p_value);

/*----------------------------------------------------------------------------------------------------------------------
    Environmental Sensing Service
----------------------------------------------------------------------------------------------------------------------*/

/***************************************************************************//**
 * @brief An attempt was made to write a value to the descriptor that is invalid or not supported by this Server.
*******************************************************************************/
#define BLE_ESS_WRITE_REQUEST_REJECTED_ERROR (BLE_ERR_GROUP_GATT | 0x80)

/***************************************************************************//**
 * @brief An attempt was made to write a value to the Condition field of the ES Trigger Setting descriptor that is invalid or not supported by this Server.
*******************************************************************************/
#define BLE_ESS_CONDITION_NOT_SUPPORTED_ERROR (BLE_ERR_GROUP_GATT | 0x81)

/***************************************************************************//**
 * @brief Environmental Sensing characteristic Index.
*******************************************************************************/
typedef enum {
    BLE_ESS_DESC_VALUE_CHANGED_IDX,
    BLE_ESS_DESC_VALUE_CHANGED_CLI_CNFG_IDX,
    BLE_ESS_TEMPERATURE_0_IDX,
    BLE_ESS_TEMPERATURE_0_CLI_CNFG_IDX,
    BLE_ESS_TEMPERATURE_0_ES_MEAS_IDX,
    BLE_ESS_TEMPERATURE_0_CHAR_EXTENDED_PROPERTIES_IDX,
    BLE_ESS_TEMPERATURE_0_ES_TRIGGER_0_IDX,
    BLE_ESS_TEMPERATURE_0_ES_TRIGGER_1_IDX,
    BLE_ESS_TEMPERATURE_0_ES_TRIGGER_2_IDX,
    BLE_ESS_TEMPERATURE_0_ES_CONF_IDX,
    BLE_ESS_TEMPERATURE_0_CHAR_USER_DESC_IDX,
    BLE_ESS_TEMPERATURE_0_VALID_RANGE_IDX,
    BLE_ESS_TEMPERATURE_1_IDX,
    BLE_ESS_TEMPERATURE_1_CLI_CNFG_IDX,
    BLE_ESS_TEMPERATURE_1_ES_MEAS_IDX,
    BLE_ESS_TEMPERATURE_1_CHAR_EXTENDED_PROPERTIES_IDX,
    BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_IDX,
    BLE_ESS_TEMPERATURE_1_ES_TRIGGER_1_IDX,
    BLE_ESS_TEMPERATURE_1_ES_TRIGGER_2_IDX,
    BLE_ESS_TEMPERATURE_1_ES_CONF_IDX,
    BLE_ESS_TEMPERATURE_1_CHAR_USER_DESC_IDX,
    BLE_ESS_TEMPERATURE_1_VALID_RANGE_IDX,
    BLE_ESS_ELEVATION_0_IDX,
    BLE_ESS_ELEVATION_0_CLI_CNFG_IDX,
    BLE_ESS_ELEVATION_0_ES_MEAS_IDX,
    BLE_ESS_ELEVATION_0_CHAR_EXTENDED_PROPERTIES_IDX,
    BLE_ESS_ELEVATION_0_ES_TRIGGER_0_IDX,
    BLE_ESS_ELEVATION_0_ES_TRIGGER_1_IDX,
    BLE_ESS_ELEVATION_0_ES_TRIGGER_2_IDX,
    BLE_ESS_ELEVATION_0_ES_CONF_IDX,
    BLE_ESS_ELEVATION_0_CHAR_USER_DESC_IDX,
    BLE_ESS_ELEVATION_0_VALID_RANGE_IDX,
    BLE_ESS_ELEVATION_1_IDX,
    BLE_ESS_ELEVATION_1_CLI_CNFG_IDX,
    BLE_ESS_ELEVATION_1_ES_MEAS_IDX,
    BLE_ESS_ELEVATION_1_CHAR_EXTENDED_PROPERTIES_IDX,
    BLE_ESS_ELEVATION_1_ES_TRIGGER_0_IDX,
    BLE_ESS_ELEVATION_1_ES_TRIGGER_1_IDX,
    BLE_ESS_ELEVATION_1_ES_TRIGGER_2_IDX,
    BLE_ESS_ELEVATION_1_ES_CONF_IDX,
    BLE_ESS_ELEVATION_1_CHAR_USER_DESC_IDX,
    BLE_ESS_ELEVATION_1_VALID_RANGE_IDX,
} e_ble_ess_char_idx_t;

/***************************************************************************//**
 * @brief Environmental Sensing event type.
*******************************************************************************/
typedef enum {
    /* Descriptor Value Changed */
    BLE_ESS_EVENT_DESC_VALUE_CHANGED_HDL_VAL_CNF = BLE_SERVS_ATTR_EVENT(BLE_ESS_DESC_VALUE_CHANGED_IDX, BLE_SERVS_HDL_VAL_CNF),
    BLE_ESS_EVENT_DESC_VALUE_CHANGED_CLI_CNFG_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_DESC_VALUE_CHANGED_CLI_CNFG_IDX, BLE_SERVS_WRITE_REQ),
    BLE_ESS_EVENT_DESC_VALUE_CHANGED_CLI_CNFG_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_ESS_DESC_VALUE_CHANGED_CLI_CNFG_IDX, BLE_SERVS_WRITE_COMP),
    BLE_ESS_EVENT_DESC_VALUE_CHANGED_CLI_CNFG_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_DESC_VALUE_CHANGED_CLI_CNFG_IDX, BLE_SERVS_READ_REQ),
    /* Temperature 0 */
    BLE_ESS_EVENT_TEMPERATURE_0_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_TEMPERATURE_0_IDX, BLE_SERVS_READ_REQ),
    BLE_ESS_EVENT_TEMPERATURE_0_CLI_CNFG_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_TEMPERATURE_0_CLI_CNFG_IDX, BLE_SERVS_WRITE_REQ),
    BLE_ESS_EVENT_TEMPERATURE_0_CLI_CNFG_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_ESS_TEMPERATURE_0_CLI_CNFG_IDX, BLE_SERVS_WRITE_COMP),
    BLE_ESS_EVENT_TEMPERATURE_0_CLI_CNFG_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_TEMPERATURE_0_CLI_CNFG_IDX, BLE_SERVS_READ_REQ),
    BLE_ESS_EVENT_TEMPERATURE_0_ES_MEAS_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_TEMPERATURE_0_ES_MEAS_IDX, BLE_SERVS_READ_REQ),
    BLE_ESS_EVENT_TEMPERATURE_0_CHAR_EXTENDED_PROPERTIES_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_TEMPERATURE_0_CHAR_EXTENDED_PROPERTIES_IDX, BLE_SERVS_READ_REQ),
    BLE_ESS_EVENT_TEMPERATURE_0_ES_TRIGGER_0_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_TEMPERATURE_0_ES_TRIGGER_0_IDX, BLE_SERVS_WRITE_REQ),
    BLE_ESS_EVENT_TEMPERATURE_0_ES_TRIGGER_0_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_ESS_TEMPERATURE_0_ES_TRIGGER_0_IDX, BLE_SERVS_WRITE_COMP),
    BLE_ESS_EVENT_TEMPERATURE_0_ES_TRIGGER_0_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_TEMPERATURE_0_ES_TRIGGER_0_IDX, BLE_SERVS_READ_REQ),
    BLE_ESS_EVENT_TEMPERATURE_0_ES_TRIGGER_1_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_TEMPERATURE_0_ES_TRIGGER_1_IDX, BLE_SERVS_WRITE_REQ),
    BLE_ESS_EVENT_TEMPERATURE_0_ES_TRIGGER_1_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_ESS_TEMPERATURE_0_ES_TRIGGER_1_IDX, BLE_SERVS_WRITE_COMP),
    BLE_ESS_EVENT_TEMPERATURE_0_ES_TRIGGER_1_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_TEMPERATURE_0_ES_TRIGGER_1_IDX, BLE_SERVS_READ_REQ),
    BLE_ESS_EVENT_TEMPERATURE_0_ES_TRIGGER_2_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_TEMPERATURE_0_ES_TRIGGER_2_IDX, BLE_SERVS_WRITE_REQ),
    BLE_ESS_EVENT_TEMPERATURE_0_ES_TRIGGER_2_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_ESS_TEMPERATURE_0_ES_TRIGGER_2_IDX, BLE_SERVS_WRITE_COMP),
    BLE_ESS_EVENT_TEMPERATURE_0_ES_TRIGGER_2_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_TEMPERATURE_0_ES_TRIGGER_2_IDX, BLE_SERVS_READ_REQ),
    BLE_ESS_EVENT_TEMPERATURE_0_ES_CONF_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_TEMPERATURE_0_ES_CONF_IDX, BLE_SERVS_WRITE_REQ),
    BLE_ESS_EVENT_TEMPERATURE_0_ES_CONF_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_ESS_TEMPERATURE_0_ES_CONF_IDX, BLE_SERVS_WRITE_COMP),
    BLE_ESS_EVENT_TEMPERATURE_0_ES_CONF_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_TEMPERATURE_0_ES_CONF_IDX, BLE_SERVS_READ_REQ),
    BLE_ESS_EVENT_TEMPERATURE_0_CHAR_USER_DESC_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_TEMPERATURE_0_CHAR_USER_DESC_IDX, BLE_SERVS_WRITE_REQ),
    BLE_ESS_EVENT_TEMPERATURE_0_CHAR_USER_DESC_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_ESS_TEMPERATURE_0_CHAR_USER_DESC_IDX, BLE_SERVS_WRITE_COMP),
    BLE_ESS_EVENT_TEMPERATURE_0_CHAR_USER_DESC_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_TEMPERATURE_0_CHAR_USER_DESC_IDX, BLE_SERVS_READ_REQ),
    BLE_ESS_EVENT_TEMPERATURE_0_VALID_RANGE_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_TEMPERATURE_0_VALID_RANGE_IDX, BLE_SERVS_READ_REQ),
    /* Temperature 1 */
    BLE_ESS_EVENT_TEMPERATURE_1_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_TEMPERATURE_1_IDX, BLE_SERVS_READ_REQ),
    BLE_ESS_EVENT_TEMPERATURE_1_CLI_CNFG_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_TEMPERATURE_1_CLI_CNFG_IDX, BLE_SERVS_WRITE_REQ),
    BLE_ESS_EVENT_TEMPERATURE_1_CLI_CNFG_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_ESS_TEMPERATURE_1_CLI_CNFG_IDX, BLE_SERVS_WRITE_COMP),
    BLE_ESS_EVENT_TEMPERATURE_1_CLI_CNFG_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_TEMPERATURE_1_CLI_CNFG_IDX, BLE_SERVS_READ_REQ),
    BLE_ESS_EVENT_TEMPERATURE_1_ES_MEAS_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_TEMPERATURE_1_ES_MEAS_IDX, BLE_SERVS_READ_REQ),
    BLE_ESS_EVENT_TEMPERATURE_1_CHAR_EXTENDED_PROPERTIES_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_TEMPERATURE_1_CHAR_EXTENDED_PROPERTIES_IDX, BLE_SERVS_READ_REQ),
    BLE_ESS_EVENT_TEMPERATURE_1_ES_TRIGGER_0_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_IDX, BLE_SERVS_WRITE_REQ),
    BLE_ESS_EVENT_TEMPERATURE_1_ES_TRIGGER_0_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_IDX, BLE_SERVS_WRITE_COMP),
    BLE_ESS_EVENT_TEMPERATURE_1_ES_TRIGGER_0_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_TEMPERATURE_1_ES_TRIGGER_0_IDX, BLE_SERVS_READ_REQ),
    BLE_ESS_EVENT_TEMPERATURE_1_ES_TRIGGER_1_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_TEMPERATURE_1_ES_TRIGGER_1_IDX, BLE_SERVS_WRITE_REQ),
    BLE_ESS_EVENT_TEMPERATURE_1_ES_TRIGGER_1_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_ESS_TEMPERATURE_1_ES_TRIGGER_1_IDX, BLE_SERVS_WRITE_COMP),
    BLE_ESS_EVENT_TEMPERATURE_1_ES_TRIGGER_1_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_TEMPERATURE_1_ES_TRIGGER_1_IDX, BLE_SERVS_READ_REQ),
    BLE_ESS_EVENT_TEMPERATURE_1_ES_TRIGGER_2_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_TEMPERATURE_1_ES_TRIGGER_2_IDX, BLE_SERVS_WRITE_REQ),
    BLE_ESS_EVENT_TEMPERATURE_1_ES_TRIGGER_2_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_ESS_TEMPERATURE_1_ES_TRIGGER_2_IDX, BLE_SERVS_WRITE_COMP),
    BLE_ESS_EVENT_TEMPERATURE_1_ES_TRIGGER_2_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_TEMPERATURE_1_ES_TRIGGER_2_IDX, BLE_SERVS_READ_REQ),
    BLE_ESS_EVENT_TEMPERATURE_1_ES_CONF_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_TEMPERATURE_1_ES_CONF_IDX, BLE_SERVS_WRITE_REQ),
    BLE_ESS_EVENT_TEMPERATURE_1_ES_CONF_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_ESS_TEMPERATURE_1_ES_CONF_IDX, BLE_SERVS_WRITE_COMP),
    BLE_ESS_EVENT_TEMPERATURE_1_ES_CONF_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_TEMPERATURE_1_ES_CONF_IDX, BLE_SERVS_READ_REQ),
    BLE_ESS_EVENT_TEMPERATURE_1_CHAR_USER_DESC_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_TEMPERATURE_1_CHAR_USER_DESC_IDX, BLE_SERVS_WRITE_REQ),
    BLE_ESS_EVENT_TEMPERATURE_1_CHAR_USER_DESC_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_ESS_TEMPERATURE_1_CHAR_USER_DESC_IDX, BLE_SERVS_WRITE_COMP),
    BLE_ESS_EVENT_TEMPERATURE_1_CHAR_USER_DESC_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_TEMPERATURE_1_CHAR_USER_DESC_IDX, BLE_SERVS_READ_REQ),
    BLE_ESS_EVENT_TEMPERATURE_1_VALID_RANGE_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_TEMPERATURE_1_VALID_RANGE_IDX, BLE_SERVS_READ_REQ),
    /* Elevation 0 */
    BLE_ESS_EVENT_ELEVATION_0_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_ELEVATION_0_IDX, BLE_SERVS_READ_REQ),
    BLE_ESS_EVENT_ELEVATION_0_CLI_CNFG_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_ELEVATION_0_CLI_CNFG_IDX, BLE_SERVS_WRITE_REQ),
    BLE_ESS_EVENT_ELEVATION_0_CLI_CNFG_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_ESS_ELEVATION_0_CLI_CNFG_IDX, BLE_SERVS_WRITE_COMP),
    BLE_ESS_EVENT_ELEVATION_0_CLI_CNFG_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_ELEVATION_0_CLI_CNFG_IDX, BLE_SERVS_READ_REQ),
    BLE_ESS_EVENT_ELEVATION_0_ES_MEAS_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_ELEVATION_0_ES_MEAS_IDX, BLE_SERVS_READ_REQ),
    BLE_ESS_EVENT_ELEVATION_0_CHAR_EXTENDED_PROPERTIES_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_ELEVATION_0_CHAR_EXTENDED_PROPERTIES_IDX, BLE_SERVS_READ_REQ),
    BLE_ESS_EVENT_ELEVATION_0_ES_TRIGGER_0_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_ELEVATION_0_ES_TRIGGER_0_IDX, BLE_SERVS_WRITE_REQ),
    BLE_ESS_EVENT_ELEVATION_0_ES_TRIGGER_0_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_ESS_ELEVATION_0_ES_TRIGGER_0_IDX, BLE_SERVS_WRITE_COMP),
    BLE_ESS_EVENT_ELEVATION_0_ES_TRIGGER_0_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_ELEVATION_0_ES_TRIGGER_0_IDX, BLE_SERVS_READ_REQ),
    BLE_ESS_EVENT_ELEVATION_0_ES_TRIGGER_1_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_ELEVATION_0_ES_TRIGGER_1_IDX, BLE_SERVS_WRITE_REQ),
    BLE_ESS_EVENT_ELEVATION_0_ES_TRIGGER_1_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_ESS_ELEVATION_0_ES_TRIGGER_1_IDX, BLE_SERVS_WRITE_COMP),
    BLE_ESS_EVENT_ELEVATION_0_ES_TRIGGER_1_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_ELEVATION_0_ES_TRIGGER_1_IDX, BLE_SERVS_READ_REQ),
    BLE_ESS_EVENT_ELEVATION_0_ES_TRIGGER_2_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_ELEVATION_0_ES_TRIGGER_2_IDX, BLE_SERVS_WRITE_REQ),
    BLE_ESS_EVENT_ELEVATION_0_ES_TRIGGER_2_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_ESS_ELEVATION_0_ES_TRIGGER_2_IDX, BLE_SERVS_WRITE_COMP),
    BLE_ESS_EVENT_ELEVATION_0_ES_TRIGGER_2_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_ELEVATION_0_ES_TRIGGER_2_IDX, BLE_SERVS_READ_REQ),
    BLE_ESS_EVENT_ELEVATION_0_ES_CONF_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_ELEVATION_0_ES_CONF_IDX, BLE_SERVS_WRITE_REQ),
    BLE_ESS_EVENT_ELEVATION_0_ES_CONF_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_ESS_ELEVATION_0_ES_CONF_IDX, BLE_SERVS_WRITE_COMP),
    BLE_ESS_EVENT_ELEVATION_0_ES_CONF_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_ELEVATION_0_ES_CONF_IDX, BLE_SERVS_READ_REQ),
    BLE_ESS_EVENT_ELEVATION_0_CHAR_USER_DESC_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_ELEVATION_0_CHAR_USER_DESC_IDX, BLE_SERVS_WRITE_REQ),
    BLE_ESS_EVENT_ELEVATION_0_CHAR_USER_DESC_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_ESS_ELEVATION_0_CHAR_USER_DESC_IDX, BLE_SERVS_WRITE_COMP),
    BLE_ESS_EVENT_ELEVATION_0_CHAR_USER_DESC_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_ELEVATION_0_CHAR_USER_DESC_IDX, BLE_SERVS_READ_REQ),
    BLE_ESS_EVENT_ELEVATION_0_VALID_RANGE_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_ELEVATION_0_VALID_RANGE_IDX, BLE_SERVS_READ_REQ),
    /* Elevation 1 */
    BLE_ESS_EVENT_ELEVATION_1_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_ELEVATION_1_IDX, BLE_SERVS_READ_REQ),
    BLE_ESS_EVENT_ELEVATION_1_CLI_CNFG_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_ELEVATION_1_CLI_CNFG_IDX, BLE_SERVS_WRITE_REQ),
    BLE_ESS_EVENT_ELEVATION_1_CLI_CNFG_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_ESS_ELEVATION_1_CLI_CNFG_IDX, BLE_SERVS_WRITE_COMP),
    BLE_ESS_EVENT_ELEVATION_1_CLI_CNFG_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_ELEVATION_1_CLI_CNFG_IDX, BLE_SERVS_READ_REQ),
    BLE_ESS_EVENT_ELEVATION_1_ES_MEAS_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_ELEVATION_1_ES_MEAS_IDX, BLE_SERVS_READ_REQ),
    BLE_ESS_EVENT_ELEVATION_1_CHAR_EXTENDED_PROPERTIES_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_ELEVATION_1_CHAR_EXTENDED_PROPERTIES_IDX, BLE_SERVS_READ_REQ),
    BLE_ESS_EVENT_ELEVATION_1_ES_TRIGGER_0_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_ELEVATION_1_ES_TRIGGER_0_IDX, BLE_SERVS_WRITE_REQ),
    BLE_ESS_EVENT_ELEVATION_1_ES_TRIGGER_0_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_ESS_ELEVATION_1_ES_TRIGGER_0_IDX, BLE_SERVS_WRITE_COMP),
    BLE_ESS_EVENT_ELEVATION_1_ES_TRIGGER_0_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_ELEVATION_1_ES_TRIGGER_0_IDX, BLE_SERVS_READ_REQ),
    BLE_ESS_EVENT_ELEVATION_1_ES_TRIGGER_1_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_ELEVATION_1_ES_TRIGGER_1_IDX, BLE_SERVS_WRITE_REQ),
    BLE_ESS_EVENT_ELEVATION_1_ES_TRIGGER_1_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_ESS_ELEVATION_1_ES_TRIGGER_1_IDX, BLE_SERVS_WRITE_COMP),
    BLE_ESS_EVENT_ELEVATION_1_ES_TRIGGER_1_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_ELEVATION_1_ES_TRIGGER_1_IDX, BLE_SERVS_READ_REQ),
    BLE_ESS_EVENT_ELEVATION_1_ES_TRIGGER_2_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_ELEVATION_1_ES_TRIGGER_2_IDX, BLE_SERVS_WRITE_REQ),
    BLE_ESS_EVENT_ELEVATION_1_ES_TRIGGER_2_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_ESS_ELEVATION_1_ES_TRIGGER_2_IDX, BLE_SERVS_WRITE_COMP),
    BLE_ESS_EVENT_ELEVATION_1_ES_TRIGGER_2_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_ELEVATION_1_ES_TRIGGER_2_IDX, BLE_SERVS_READ_REQ),
    BLE_ESS_EVENT_ELEVATION_1_ES_CONF_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_ELEVATION_1_ES_CONF_IDX, BLE_SERVS_WRITE_REQ),
    BLE_ESS_EVENT_ELEVATION_1_ES_CONF_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_ESS_ELEVATION_1_ES_CONF_IDX, BLE_SERVS_WRITE_COMP),
    BLE_ESS_EVENT_ELEVATION_1_ES_CONF_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_ELEVATION_1_ES_CONF_IDX, BLE_SERVS_READ_REQ),
    BLE_ESS_EVENT_ELEVATION_1_CHAR_USER_DESC_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_ELEVATION_1_CHAR_USER_DESC_IDX, BLE_SERVS_WRITE_REQ),
    BLE_ESS_EVENT_ELEVATION_1_CHAR_USER_DESC_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_ESS_ELEVATION_1_CHAR_USER_DESC_IDX, BLE_SERVS_WRITE_COMP),
    BLE_ESS_EVENT_ELEVATION_1_CHAR_USER_DESC_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_ELEVATION_1_CHAR_USER_DESC_IDX, BLE_SERVS_READ_REQ),
    BLE_ESS_EVENT_ELEVATION_1_VALID_RANGE_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_ESS_ELEVATION_1_VALID_RANGE_IDX, BLE_SERVS_READ_REQ),
} e_ble_ess_event_t;

/***************************************************************************//**
 * @brief     Initialize Environmental Sensing service.
 * @param[in] cb Service callback.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESS_Init(ble_servs_app_cb_t cb);

#endif /* R_BLE_ESS_H */

/** @} */
