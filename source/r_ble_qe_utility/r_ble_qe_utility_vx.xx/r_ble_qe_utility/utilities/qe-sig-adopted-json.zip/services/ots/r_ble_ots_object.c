/***********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
 * SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2018 Renesas Electronics Corporation. All rights reserved.
 ***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name   : r_ble_ots_object.c
 * Version     : 1.0
 * Description : This module implements Objects for Object Transfer Service
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 29.05.2019 1.00 First Release
***********************************************************************************************************************/

/***********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <string.h>
#include "r_ble_ots_object.h"

#include "gatt_db.h"

/***********************************************************************************************************************
 Private global variables and functions
 ***********************************************************************************************************************/
static uint16_t             gs_newest_index;
static uint16_t             gs_root_index;
static uint16_t             gs_num_of_objects;
static st_ble_ots_object_t  gs_objects[BLE_OTS_DB_MAX_NUM_OF_OBJECTS];

void ots_db_init (void)
{
    gs_root_index     = BLE_OTS_DB_INVALID_INDEX;
    gs_num_of_objects = 0;

    for (uint16_t i = 0; i < BLE_OTS_DB_MAX_NUM_OF_OBJECTS; i++)
    {
        gs_objects[i].valid      = BLE_OTS_DB_INVALID_OBJECT;
        gs_objects[i].is_valid   = BLE_OTS_DB_INVALID_OBJECT;
        gs_objects[i].next_index = BLE_OTS_DB_INVALID_INDEX;
        gs_objects[i].prev_index = BLE_OTS_DB_INVALID_INDEX;

        //gs_objects[i].obj_size   = 0;
        memset(&gs_objects[i].obj_name, 0x00, (BLE_OTS_OBJ_NAME_OBJECT_NAME_LEN * sizeof(char)));
        memset(&gs_objects[i].obj_type, 0x00, sizeof(gs_objects[i].obj_type));
        memset(&gs_objects[i].obj_first_created, 0x00, sizeof(gs_objects[i].obj_first_created));
        memset(&gs_objects[i].obj_last_modified, 0x00, sizeof(gs_objects[i].obj_last_modified));
        memset(&gs_objects[i].obj_size, 0x00, sizeof(gs_objects[i].obj_size));
        memset(&gs_objects[i].obj_id, 0x00, (6 * sizeof(uint8_t)));
        memset(&gs_objects[i].obj_properties, 0x00, sizeof(gs_objects[i].obj_properties));
    }
}

uint16_t ots_db_get_newest_index(void)
{
    st_ble_ots_object_t *p_object = ots_db_get_object(gs_root_index);
    return p_object->prev_index;
}

uint16_t ots_db_get_oldest_index(void)
{
    return gs_newest_index;
}

uint16_t ots_db_get_next_index(uint16_t index)
{
    st_ble_ots_object_t *p_record = ots_db_get_object(index);
    return p_record->next_index;
}

st_ble_ots_object_t *ots_db_get_object(uint16_t index)
{
    if (BLE_OTS_DB_MAX_NUM_OF_OBJECTS <= index)
    {
        return NULL;
    }

    if (BLE_OTS_DB_INVALID_OBJECT == gs_objects[index].valid)
    {
        return NULL;
    }

    return &gs_objects[index];
}

st_ble_ots_object_t *ots_db_create_object(void)
{
    if (BLE_OTS_DB_INVALID_INDEX == gs_root_index)
    {
        gs_objects[0].valid      = BLE_OTS_DB_VALID_OBJECT;
        gs_objects[0].is_valid   = BLE_OTS_DB_VALID_OBJECT;
        gs_objects[0].prev_index = BLE_OTS_DB_INVALID_OBJECT;
        gs_objects[0].next_index = 1;
        gs_root_index            = 0;
        gs_num_of_objects++;
        return &gs_objects[0];
    }
    /* No space to save a new object, hence remove oldest one. */
    else if (BLE_OTS_DB_MAX_NUM_OF_OBJECTS <= gs_num_of_objects)
    {
        uint16_t newest_index = ots_db_get_newest_index();
        uint16_t next_index   = ots_db_get_next_index(gs_root_index);

        gs_objects[gs_root_index].prev_index = newest_index;
        gs_objects[gs_root_index].next_index = next_index;
        gs_objects[next_index].prev_index    = gs_root_index;
        gs_root_index                        = next_index;
        return &gs_objects[gs_root_index];
    }
    /* Free space exist, save the new object on it. */
    else
    {
        for (uint8_t i = 0; i < BLE_OTS_DB_MAX_NUM_OF_OBJECTS; i++)
        {
            if ((BLE_OTS_DB_INVALID_OBJECT == gs_objects[i].valid) && (BLE_OTS_DB_INVALID_OBJECT == gs_objects[i].is_valid))
            {
                uint8_t index          = i;
                gs_objects[i].valid    = BLE_OTS_DB_VALID_OBJECT;
                gs_objects[i].is_valid = BLE_OTS_DB_VALID_OBJECT;

                gs_objects[i].prev_index = index - 1;
                gs_objects[i].next_index = index + 1;

                gs_num_of_objects++;
                gs_newest_index = i;
                return &gs_objects[i];
            }
        }
    }
}

void ots_db_mark_delete_object(uint16_t index)
{
    st_ble_ots_object_t *p_object;

    p_object = ots_db_get_object(index);

    if (NULL != p_object)
    {
        p_object->valid = BLE_OTS_DB_WILL_DELETE;
    }
}

void ots_db_delete_object(st_ble_ots_object_t *p_object)
{
    gs_objects[p_object->prev_index].next_index = p_object->next_index;
    gs_objects[p_object->next_index].prev_index = p_object->prev_index;

    p_object->valid = BLE_OTS_DB_INVALID_OBJECT;
    p_object->is_valid = BLE_OTS_DB_INVALID_OBJECT;
}

st_ble_ots_object_t * ots_db_get_object_id(st_ble_ots_obj_list_cp_t *p_app_value)
{
    uint16_t i = 0;
    int ret;

    st_ble_ots_object_t *p_object = NULL;

    for (i = 0; i < BLE_OTS_DB_MAX_NUM_OF_OBJECTS; i++)
    {
        p_object = &gs_objects[i];
        if (BLE_OTS_DB_INVALID_OBJECT != p_object->valid)
        {
            ret = memcmp(p_object->obj_id, p_app_value->parameter, 6);
            if (ret == 0)
            {
                return p_object;
            }
        }
    }
}
