/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_rcc.c
 * Version : 1.0
 * Description : The source file for Reconnection Configuration client.
 **********************************************************************************************************************/
#include <string.h>
#include "r_ble_rcc.h"
#include "profile_cmn/r_ble_servc_if.h"


/*******************************************************************************************************************//**
 * RC Features Field - RC Features Fields Bits Definition.
 ***********************************************************************************************************************/
#define BLE_RCC_PRV_RC_FEATURES_FIELD_E2ECRC_SUPPORTED (1 << 0)
#define BLE_RCC_PRV_RC_FEATURES_FIELD_ENABLE_DISCONNECT_SUPPORTED (1 << 1)
#define BLE_RCC_PRV_RC_FEATURES_FIELD_READY_FOR_DISCONNECT_SUPPORTED (1 << 2)
#define BLE_RCC_PRV_RC_FEATURES_FIELD_PROPOSE_RECONNECTION_TIMEOUT_SUPPORTED (1 << 3)
#define BLE_RCC_PRV_RC_FEATURES_FIELD_PROPOSE_CONNECTION_INTERVAL_SUPPORTED (1 << 4)
#define BLE_RCC_PRV_RC_FEATURES_FIELD_PROPOSE_SLAVE_LATENCY_SUPPORTED (1 << 5)
#define BLE_RCC_PRV_RC_FEATURES_FIELD_PROPOSE_SUPERVISION_TIMEOUT_SUPPORTED	(1 << 6)
#define BLE_RCC_PRV_RC_FEATURES_FIELD_PROPOSE_ADVERTISEMENT_INTERVAL_SUPPORTED (1 << 7)
#define BLE_RCC_PRV_RC_FEATURES_FIELD_PROPOSE_ADVERTISEMENT_COUNT_SUPPORTED	(1 << 8)
#define BLE_RCC_PRV_RC_FEATURES_FIELD_PROPOSE_ADVERTISEMENT_REPETETION_TIME_SUPPORTED (1 << 9)
#define BLE_RCC_PRV_RC_FEATURES_FIELD_ADVERTISEMENT_CONFIGURATION_1_SUPPORTED (1 << 10)
#define BLE_RCC_PRV_RC_FEATURES_FIELD_ADVERTISEMENT_CONFIGURATION_2_SUPPORTED (1 << 11)
#define BLE_RCC_PRV_RC_FEATURES_FIELD_ADVERTISEMENT_CONFIGURATION_3_SUPPORTED (1 << 12)
#define BLE_RCC_PRV_RC_FEATURES_FIELD_ADVERTISEMENT_CONFIGURATION_4_SUPPORTED (1 << 13)
#define BLE_RCC_PRV_RC_FEATURES_FIELD_UPGRADE_TO_LESC_ONLY_SUPPORTED (1 << 14)
#define BLE_RCC_PRV_RC_FEATURES_FIELD_NEXT_PAIRING_OOB_SUPPORTED (1 << 15)
#define BLE_RCC_PRV_RC_FEATURES_FIELD_USE_OF_WHITE_LIST_SUPPORTED (1 << 16)
#define BLE_RCC_PRV_RC_FEATURES_FIELD_LIMITED_ACCESS_SUPPORTED (1 << 17)
#define BLE_RCC_PRV_RC_FEATURES_FIELD_FEATURE_EXTENSION (1 << 23)

 /*******************************************************************************************************************//**
 * RC Settings Field - RC Settings Fields Bits Defination.
 ***********************************************************************************************************************/
#define BLE_RCC_PRV_RC_SETTINGS_FIELD_RFU (1 << 0)
#define BLE_RCC_PRV_RC_SETTINGS_FIELD_LESC_ONLY (1 << 1)
#define BLE_RCC_PRV_RC_SETTINGS_FIELD_USE_OOB_PAIRING (1 << 2)
#define BLE_RCC_PRV_RC_SETTINGS_FIELD_READY_FOR_DISCONNECT (1 << 4)
#define BLE_RCC_PRV_RC_SETTINGS_FIELD_LIMITED_ACCESS (1 << 5)
#define BLE_RCC_PRV_RC_SETTINGS_FIELD_ACCESS_PERMITTED (1 << 6)
#define BLE_RCC_PRV_RC_SETTINGS_FIELD_ADVT_MODE_0 (1 << 8)
#define BLE_RCC_PRV_RC_SETTINGS_FIELD_ADVT_MODE_1 (1 << 9)

static st_ble_servc_info_t gs_client_info;
static uint8_t gs_error_response = 0;
static bool gs_param_set = 0;
static uint16_t gs_conn_hdl;
static bool gs_e2ecrc_supported = false;

static uint16_t e2e_crc_calculation(uint8_t *message, uint16_t length);
static ble_status_t e2e_crc_check(uint8_t *message, uint8_t length, uint16_t rec_crc);
static void rcc_feat_read_rsp_cb(const st_ble_servc_char_info_t *p_attr, uint16_t conn_hdl, ble_status_t result, const st_ble_rcc_feat_t *p_app_value);


/***********************************************************************************************************************
 * Function Name: e2e_crc_calculation
 * Description  : to calculate e2e crc.
 * Arguments    : message - message data.
 *                length - message length
 * Return Value : uint16_t
 **********************************************************************************************************************/
static uint16_t e2e_crc_calculation(uint8_t *message, uint16_t length)
{
    uint32_t i = 0;
    uint8_t data = 0;
    uint8_t msb;
    uint16_t crc_result;
    uint8_t crc_calc[2] = { 0xff,0xff };

    while (length--)
    {
        data = *message++;
        for(i = 0; i < 8; i++, data >>= 1)
        {
            msb = crc_calc[0] >> 7;
            crc_calc[0] <<= 1;

            if(crc_calc[1] & 0x80)
            {
                crc_calc[0] |= 1;
            }
            crc_calc[1] <<= 1;

            if(msb != (data & 1))
            {
                crc_calc[1] ^= 0x21;
                crc_calc[0] ^= 0x10;
            }
        }
    }

    crc_result = ((((crc_calc[1] & 0x01) << 7) |
        ((crc_calc[1] & 0x02) << 5) |
        ((crc_calc[1] & 0x04) << 3) |
        ((crc_calc[1] & 0x08) << 1) |
        ((crc_calc[1] & 0x10) >> 1) |
        ((crc_calc[1] & 0x20) >> 3) |
        ((crc_calc[1] & 0x40) >> 5) |
        ((crc_calc[1] & 0x80) >> 7)) << 8) |
        (((crc_calc[0] & 0x01) << 7) |
        ((crc_calc[0] & 0x02) << 5) |
        ((crc_calc[0] & 0x04) << 3) |
        ((crc_calc[0] & 0x08) << 1) |
        ((crc_calc[0] & 0x10) >> 1) |
        ((crc_calc[0] & 0x20) >> 3) |
        ((crc_calc[0] & 0x40) >> 5) |
        ((crc_calc[0] & 0x80) >> 7));
    return (crc_result & 0xffff);
}

/***********************************************************************************************************************
 * Function Name: e2e_crc_check
 * Description  : to check crc.
 * Arguments    : message - message data.
 *                length - message length
 *                rec_crc - received crc value
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t e2e_crc_check(uint8_t *message, uint8_t length, uint16_t rec_crc)
{
    ble_status_t ret;
    uint16_t crc = e2e_crc_calculation(message, length);
    
    if (rec_crc == crc)
    {
        ret = BLE_SUCCESS;
    }
    else
    {
        ret = BLE_RCC_INVALID_CRC_ERROR;
    }

    return ret;
}

/*----------------------------------------------------------------------------------------------------------------------
    RC Feature Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* RC Feature characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_feat_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************//**
 * Function Name: decode_st_ble_rcs_feat_t
 * Description  : This function converts RC Features characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the RC Features value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_rcc_feat_t(st_ble_rcc_feat_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;
    uint8_t crc_ok = 0;
    uint32_t feature_byte = 0;
    uint16_t rec_crc = 0;
    uint16_t crc_default = 0xFFFF;

    if (BLE_RCC_FEAT_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    memset((uint8_t *)p_app_value, 0x00, sizeof(st_ble_rcc_feat_t));
    pos = 0;
    BT_UNPACK_LE_2_BYTE(&p_app_value->e2e_crc, &p_gatt_value->p_value[pos]);
    pos = 2;
    for (uint8_t i = 0; i < 3; i++)
    {
        p_app_value->feature_bytes[i] = p_gatt_value->p_value[pos];
        pos += 1;
    }

    /*Check crc and report*/
    rec_crc = p_app_value->e2e_crc;
    crc_ok = e2e_crc_check(&p_gatt_value->p_value[2], p_gatt_value->value_len - 2, rec_crc);
    pos += 2;
    BT_UNPACK_LE_3_BYTE(&feature_byte, &p_gatt_value->p_value[pos]);

    if (0xFFFF != rec_crc)
    {
        if (crc_ok!= BLE_SUCCESS)
        {
            return BLE_RCC_INVALID_CRC_ERROR;
        }
    }

    return BLE_SUCCESS;
}

/***********************************************************************************************************************//**
 * Function Name: encode_st_ble_rcc_feat_t
 * Description  : This function converts rc features characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the Record Access Control Point  value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_rcc_feat_t(const st_ble_rcc_feat_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    /* app data to byte sequence. */
    uint8_t pos = 0;
    uint8_t crc_present = 0;
    uint16_t e2e_crc = 0xFFFF;

    memset(&p_gatt_value->p_value[0], 0x00, p_gatt_value->value_len);
    
    /*check crc presence*/
    crc_present = p_app_value->feature_bytes[0];
    if ((crc_present & BLE_RCC_PRV_RC_FEATURES_FIELD_E2ECRC_SUPPORTED) == 1)
    {
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->e2e_crc);
        pos += 2;
        p_gatt_value->p_value[pos++] = p_app_value->feature_bytes[0];
        p_gatt_value->p_value[pos++] = p_app_value->feature_bytes[1];
        p_gatt_value->p_value[pos++] = p_app_value->feature_bytes[2];
    }
    else
    {
        p_gatt_value->p_value[pos++] = p_app_value->feature_bytes[0];
        p_gatt_value->p_value[pos++] = p_app_value->feature_bytes[1];
        p_gatt_value->p_value[pos++] = p_app_value->feature_bytes[2];
    }

    p_gatt_value->value_len = pos;
    
    return BLE_SUCCESS;
}

/* RC Feature characteristic definition */
const st_ble_servc_char_info_t gs_rcc_feat_char = {
    .uuid_16      = BLE_RCC_FEAT_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_rcc_feat_t),
    .db_size      = BLE_RCC_FEAT_LEN,
    .char_idx     = BLE_RCC_FEAT_IDX,
    .p_attr_hdls  = gs_feat_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_rcc_feat_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_rcc_feat_t,
    .read_rsp_cb  = (ble_servc_attr_read_rsp_t)rcc_feat_read_rsp_cb,
};

ble_status_t R_BLE_RCC_ReadFeat(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_rcc_feat_char, conn_hdl);
}

void R_BLE_RCC_GetFeatAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_rcc_feat_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_feat_char_ranges[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    RC Settings Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* RC Settings characteristic descriptors attribute handles */
static uint16_t gs_setting_cli_cnfg_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_setting_cli_cnfg ={
    .uuid_16     = BLE_RCC_SETTING_CLI_CNFG_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint16_t),
    .db_size     = BLE_RCC_SETTING_CLI_CNFG_LEN,
    .desc_idx    = BLE_RCC_SETTING_CLI_CNFG_IDX,
    .p_attr_hdls = gs_setting_cli_cnfg_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_RCC_WriteSettingCliCnfg(uint16_t conn_hdl, const uint16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_setting_cli_cnfg, conn_hdl, p_value);
}

ble_status_t R_BLE_RCC_ReadSettingCliCnfg(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_setting_cli_cnfg, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    RC Settings Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* RC Settings characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_setting_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************//**
* Function Name: decode_st_ble_rcc_setting_t
* Description  : This function converts RC Settings characteristic value representation in
*                GATT (uint8_t[]) to representation in application layer (struct).
* Arguments    : p_app_value - pointer to the RC Features value in the application layer
*                p_gatt_value - pointer to the characteristic value in the GATT database
* Return Value : ble_status_t
**********************************************************************************************************************/
static ble_status_t decode_st_ble_rcc_setting_t(st_ble_rcc_setting_t *p_app_value, 
                    const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;
    uint8_t settings_byte = 0;
    uint16_t e2e_crc = 0xFFFF;
    uint16_t rec_crc = 0;
    uint16_t check_crc = 0;
    
    if (BLE_RCC_SETTING_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    memset((uint8_t *)p_app_value, 0x00, sizeof(st_ble_rcc_setting_t));
    
    p_app_value->length = p_gatt_value->p_value[pos++];
    BT_UNPACK_LE_2_BYTE(&p_app_value->setting_bytes[0], &p_gatt_value->p_value[pos]);
    pos += 2;
    
    if (p_app_value->length > 3)
    {
        BT_UNPACK_LE_2_BYTE(&rec_crc, &p_gatt_value->p_value[pos]);
        check_crc = e2e_crc_check(&p_gatt_value->p_value[0], (p_gatt_value->value_len - 2), rec_crc);
        if (check_crc == BLE_SUCCESS)
        {
            BT_UNPACK_LE_2_BYTE(&p_app_value->e2e_crc, &p_gatt_value->p_value[pos]);
            pos += 2;
        }
        else
        {
            pos += 2;
            return BLE_RCC_INVALID_CRC_ERROR;
        }
    }
  
    return BLE_SUCCESS;
}

/***********************************************************************************************************************//**
 * Function Name: encode_st_ble_rcc_setting_t
 * Description  : This function converts RC Settings characteristic value representation in
 *                application layer (struct) to representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the RC settings value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_rcc_setting_t(const st_ble_rcc_setting_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint16_t pos = 0;
    uint16_t rcs_setting = 0;
    uint16_t e2e_crc = 0xFFFF;

    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    /*Copy the bytes*/
    p_gatt_value->p_value[pos++] = p_app_value->length;
    p_gatt_value->p_value[pos++] = p_app_value->setting_bytes[0];
    p_gatt_value->p_value[pos++] = p_app_value->setting_bytes[1];

    if (pos < p_app_value->length)
    {
        e2e_crc = e2e_crc_calculation(&p_gatt_value->p_value[0], 3);
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &e2e_crc);
        pos += 2;
    }

    p_gatt_value->value_len = pos;
    
    return BLE_SUCCESS;
}

/* RC Settings characteristic descriptor definition */
static const st_ble_servc_desc_info_t *gspp_setting_descs[] = {
    &gs_setting_cli_cnfg,
};

/* RC Settings characteristic definition */
const st_ble_servc_char_info_t gs_setting_char = {
    .uuid_16      = BLE_RCC_SETTING_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_rcc_setting_t),
    .db_size      = BLE_RCC_SETTING_LEN,
    .char_idx     = BLE_RCC_SETTING_IDX,
    .p_attr_hdls  = gs_setting_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_rcc_setting_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_rcc_setting_t,
    .num_of_descs = ARRAY_SIZE(gspp_setting_descs),
    .pp_descs     = gspp_setting_descs,
};

ble_status_t R_BLE_RCC_ReadSetting(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_setting_char, conn_hdl);
}

void R_BLE_RCC_GetSettingAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_rcc_setting_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_setting_char_ranges[conn_idx];
    p_hdl->cli_cnfg_desc_hdl = gs_setting_cli_cnfg_desc_hdls[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Reconnection Configuration Control Point Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Reconnection Configuration Control Point characteristic descriptors attribute handles */
static uint16_t gs_rccp_cli_cnfg_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_rccp_cli_cnfg ={
    .uuid_16     = BLE_RCC_RCCP_CLI_CNFG_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint16_t),
    .db_size     = BLE_RCC_RCCP_CLI_CNFG_LEN,
    .desc_idx    = BLE_RCC_RCCP_CLI_CNFG_IDX,
    .p_attr_hdls = gs_rccp_cli_cnfg_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_RCC_WriteRccpCliCnfg(uint16_t conn_hdl, const uint16_t *p_value) // @suppress("API function naming")
{
    gs_conn_hdl = conn_hdl;
    return R_BLE_SERVC_WriteDesc(&gs_rccp_cli_cnfg, conn_hdl, p_value);
}

ble_status_t R_BLE_RCC_ReadRccpCliCnfg(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_rccp_cli_cnfg, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Reconnection Configuration Control Point Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Reconnection Configuration Control Point characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_rccp_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************//**
 * Function Name: decode_st_ble_rcc_rccp_t
 * Description  : This function converts RC Control Point characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - pointer to the RC Control Point value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_rcc_rccp_t(st_ble_rcc_rccp_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;
    uint8_t ret = 0;
    uint16_t rec_crc = 0;
    uint16_t check_crc = 0;
   
    /* app data to byte sequence. */
    if ((BLE_RCC_RCCP_LEN < p_gatt_value->value_len) || (0 == p_gatt_value->value_len))
    {
        return BLE_ERR_INVALID_DATA;
    }

    memset((uint8_t*)p_app_value, 0x00, sizeof(st_ble_rcc_rccp_t));
    p_app_value->op_code = p_gatt_value->p_value[pos++];

    /*Check the opcode received and receive operand*/
    switch (p_app_value->op_code)
    {
        case BLE_RCC_RCCP_OP_CODE_SET_WHITE_LIST_TIMER:
        {
            for (int8_t i = 0; (i < 4); i++)
            {
                p_app_value->operand[i] = p_gatt_value->p_value[pos++];
            }
        }
        break;

        case BLE_RCC_RCCP_OP_CODE_ACTIVATE_STORED_SETTINGS:
        case BLE_RCC_RCCP_OP_CODE_GET_STORED_VALUES:
        case BLE_RCC_RCCP_OP_CODE_SET_ADVERTISEMENT_CONFIGURATION:
        case BLE_RCC_RCCP_OP_CODE_UPGRADE_TO_LESC_ONLY:
        case BLE_RCC_RCCP_OP_CODE_SWITCH_OOB_PAIRING:
        case BLE_RCC_RCCP_OP_CODE_LIMITED_ACCESS:
        {
            p_app_value->operand[0] = p_gatt_value->p_value[pos++];
        }
        break;

        case BLE_RCC_RCCP_OP_CODE_PROCEDURE_RESPONSE:
        {
            p_app_value->operand[0] = p_gatt_value->p_value[pos++];
            p_app_value->operand[1] = p_gatt_value->p_value[pos++];
        }
        break;

        case BLE_RCC_RCCP_OP_CODE_COMMUNICATION_PARAMETER_RESPONSE:
        case BLE_RCC_RCCP_OP_CODE_PROPOSE_SETTINGS:
        case BLE_RCC_RCCP_OP_CODE_CLIENT_PARAMETER_INDICATION:
        {
            for (int8_t i = 0; (i < 16); i++)
            {
                p_app_value->operand[i] = p_gatt_value->p_value[pos++];
            }
        }
        break;

        default:
        {
            /* do nothing */
        }
        break;

    }

    if ((p_gatt_value->value_len) == pos)
    {
        return BLE_SUCCESS;
    }
    else
    {
        /* Check whether E2ECRC is supported in RC Features*/
        BT_UNPACK_LE_2_BYTE(&rec_crc, &p_gatt_value->p_value[pos]);
        ret = e2e_crc_check(&p_gatt_value->p_value[0], p_gatt_value->value_len - 2, rec_crc);
        if (BLE_SUCCESS == ret)
        {
            memcpy(&p_app_value->e2e_crc[0], &p_gatt_value->p_value[pos], p_gatt_value->value_len - pos);
            pos += 2;
            return BLE_SUCCESS;
        }
        else
        {
            memset((uint8_t*)p_app_value, 0x00, sizeof(st_ble_rcc_rccp_t));
            return BLE_RCC_INVALID_CRC_ERROR;
        }
    }

    return BLE_SUCCESS;
}

/***********************************************************************************************************************//**
 * Function Name: encode_st_ble_rcs_rccp_t
 * Description  : This function converts RC Control Point characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the RC Control Point  value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_rcc_rccp_t(const st_ble_rcc_rccp_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;
    uint16_t e2e_crc = 0;
    memset(&p_gatt_value->p_value[0], 0x00, p_gatt_value->value_len);
    st_ble_rcc_feat_t rc_features = { 0 };
    
    /* response code */
    p_gatt_value->p_value[pos++] = p_app_value->op_code;
    
   /*Check the opcode received and receive operand*/
    switch (p_app_value->op_code)
    {
        case BLE_RCC_RCCP_OP_CODE_ACTIVATE_STORED_SETTINGS:
        case BLE_RCC_RCCP_OP_CODE_GET_STORED_VALUES:
        case BLE_RCC_RCCP_OP_CODE_SET_ADVERTISEMENT_CONFIGURATION:
        case BLE_RCC_RCCP_OP_CODE_UPGRADE_TO_LESC_ONLY:
        case BLE_RCC_RCCP_OP_CODE_SWITCH_OOB_PAIRING:
        case BLE_RCC_RCCP_OP_CODE_LIMITED_ACCESS:
        {
            p_gatt_value->p_value[pos++] = p_app_value->operand[0];
        }
        break;

        case BLE_RCC_RCCP_OP_CODE_PROCEDURE_RESPONSE:
        {
            p_gatt_value->p_value[pos++] = p_app_value->operand[0];
            p_gatt_value->p_value[pos++] = p_app_value->operand[1];
        }
        break;

        case BLE_RCC_RCCP_OP_CODE_COMMUNICATION_PARAMETER_RESPONSE:
        case BLE_RCC_RCCP_OP_CODE_PROPOSE_SETTINGS:
        case BLE_RCC_RCCP_OP_CODE_CLIENT_PARAMETER_INDICATION:
        {
            for (int8_t i = 0; (i < 16); i++)
            {
                p_gatt_value->p_value[pos++] = p_app_value->operand[i];
            }

        }
        break;
        
        case BLE_RCC_RCCP_OP_CODE_GET_MIN_VALUES:
        case BLE_RCC_RCCP_OP_CODE_GET_MAX_VALUES:
        {
            for (int8_t i = 0; (i < 4); i++)
            {
                p_gatt_value->p_value[pos++] = p_app_value->operand[i];
            }
            for (pos; pos < 16; pos++)
            {
                p_gatt_value->p_value[pos] = 0xFF;
            }
        }
        break;

        case BLE_RCC_RCCP_OP_CODE_SET_WHITE_LIST_TIMER:
        case BLE_RCC_RCCP_OP_CODE_GET_WHITE_LIST_TIMER:
        {
            for (int8_t i = 0; (i < 4); i++)
            {
                p_gatt_value->p_value[pos++] = p_app_value->operand[i];
            }
        }
        break;

        default:
        {
            /* do nothing */
        }
        break;
    }
   
   //if (1 != gs_e2ecrc_supported)Note: required for test cases RCPROC/BV after 3 
    if (gs_e2ecrc_supported)
    {
        e2e_crc = e2e_crc_calculation(&p_gatt_value->p_value[0], pos);
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &e2e_crc);
        pos += 2;
    }

    p_gatt_value->value_len = pos;
    gs_param_set = 0;
    gs_error_response = 0;
    return BLE_SUCCESS;
}

/* Reconnection Configuration Control Point characteristic descriptor definition */
static const st_ble_servc_desc_info_t *gspp_rccp_descs[] = {
    &gs_rccp_cli_cnfg,
};

/* Reconnection Configuration Control Point characteristic definition */
const st_ble_servc_char_info_t gs_rccp_char = {
    .uuid_16      = BLE_RCC_RCCP_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_rcc_rccp_t),
    .db_size      = BLE_RCC_RCCP_LEN,
    .char_idx     = BLE_RCC_RCCP_IDX,
    .p_attr_hdls  = gs_rccp_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_rcc_rccp_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_rcc_rccp_t,
    .num_of_descs = ARRAY_SIZE(gspp_rccp_descs),
    .pp_descs     = gspp_rccp_descs,
};

ble_status_t R_BLE_RCC_WriteRccp(uint16_t conn_hdl, const st_ble_rcc_rccp_t *p_value) // @suppress("API function naming")
{
    gs_conn_hdl = conn_hdl;
    return R_BLE_SERVC_WriteChar(&gs_rccp_char, conn_hdl, p_value);
}

void R_BLE_RCC_GetRccpAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_rcc_rccp_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_rccp_char_ranges[conn_idx];
    p_hdl->cli_cnfg_desc_hdl = gs_rccp_cli_cnfg_desc_hdls[conn_idx];
}


/*----------------------------------------------------------------------------------------------------------------------
    Reconnection Configuration client
----------------------------------------------------------------------------------------------------------------------*/

/* Reconnection Configuration client attribute handles */
static st_ble_gatt_hdl_range_t gs_rcc_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

const st_ble_servc_char_info_t *gspp_rcc_chars[] = {
    &gs_rcc_feat_char,
    &gs_setting_char,
    &gs_rccp_char,
};

static st_ble_servc_info_t gs_client_info = {
    .pp_chars     = gspp_rcc_chars,
    .num_of_chars = ARRAY_SIZE(gspp_rcc_chars),
    .p_attr_hdls  = gs_rcc_ranges,
};

ble_status_t R_BLE_RCC_Init(ble_servc_app_cb_t cb) // @suppress("API function naming")
{
    if (NULL == cb)
    {
        return BLE_ERR_INVALID_PTR;
    }

    gs_client_info.cb = cb;

    return R_BLE_SERVC_RegisterClient(&gs_client_info);
}

void R_BLE_RCC_ServDiscCb(uint16_t conn_hdl, uint8_t serv_idx, uint16_t type, void *p_param) // @suppress("API function naming")
{
    R_BLE_SERVC_ServDiscCb(&gs_client_info, conn_hdl, serv_idx, type, p_param);
}

void R_BLE_RCC_GetServAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_gatt_hdl_range_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    *p_hdl = gs_rcc_ranges[conn_idx];
}

static void rcc_feat_read_rsp_cb(const st_ble_servc_char_info_t *p_attr, uint16_t conn_hdl, ble_status_t result, const st_ble_rcc_feat_t *p_app_value)
{
    gs_e2ecrc_supported = p_app_value->feature_bytes[0] & BLE_RCC_PRV_RC_FEATURES_FIELD_E2ECRC_SUPPORTED;

    st_ble_servc_evt_data_t evt_data = {
        .conn_hdl = conn_hdl,
        .param_len = p_attr->app_size,
        .p_param = p_app_value
    };
    gs_client_info.cb(BLE_SERVC_MULTI_ATTR_EVENT(p_attr->char_idx, p_attr->inst_idx, BLE_SERVC_READ_RSP), BLE_SUCCESS, &evt_data);
};
