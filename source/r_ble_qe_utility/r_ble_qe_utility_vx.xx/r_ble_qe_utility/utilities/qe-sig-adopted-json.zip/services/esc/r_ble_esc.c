/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_esc.c
 * Version : 1.0
 * Description : The source file for Environmental Sensing client.
 **********************************************************************************************************************/
#include <string.h>
#include "r_ble_esc.h"
#include "profile_cmn/r_ble_servc_if.h"

static st_ble_servc_info_t gs_client_info;

/***********************************************************************************************************************
Descriptor value change macro definitions
***********************************************************************************************************************/
#define BLE_ESC_PRV_DESCRIPTER_VALUE_CHANGED_FLAG_SOURCE_OF_CHANGE                                        ( 1 << 0 )
#define BLE_ESC_PRV_DESCRIPTER_VALUE_CHANGED_FLAG_CHANGE_TO_MORE_ES_TRIGGER_SETTING_DESCRIPTORS           ( 1 << 1 )
#define BLE_ESC_PRV_DESCRIPTER_VALUE_CHANGED_FLAG_CHANGE_TO_ES_CONFIGURATION_DESCRIPTOR                   ( 1 << 2 )
#define BLE_ESC_PRV_DESCRIPTER_VALUE_CHANGED_FLAG_CHANGE_TO_ES_MEASUREMENT_DESCRIPTOR                     ( 1 << 3 )
#define BLE_ESC_PRV_DESCRIPTER_VALUE_CHANGED_FLAG_CHANGE_TO_CHARACTERISTIC_USER_DESCRIPTION_DESCRIPTOR    ( 1 << 4 )

#define BLE_ESC_PRV_TEMPERATURE_TRIGGER_SETTING_TIME_INTERVAL_LEN                                         (3)
#define BLE_ESC_PRV_TEMPERATURE_TRIGGER_SETTING_SPECIFIED_VALUE_LEN                                       (2)
#define BLE_ESC_PRV_ELEVATION_TRIGGER_SETTING_TIME_INTERVAL_LEN                                           (3)
#define BLE_ESC_PRV_ELEVATION_TRIGGER_SETTING_SPECIFIED_VALUE_LEN                                         (3)
#define BLE_ESC_PRV_ES_TRIGGER_SETTING_CONDITION_LEN                                                      (1)

/*----------------------------------------------------------------------------------------------------------------------
    Descriptor Value Changed Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Descriptor Value Changed characteristic descriptors attribute handles */
static uint16_t gs_desc_value_changed_cli_cnfg_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_desc_value_changed_cli_cnfg ={
    .uuid_16     = BLE_ESC_DESC_VALUE_CHANGED_CLI_CNFG_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint16_t),
    .db_size     = BLE_ESC_DESC_VALUE_CHANGED_CLI_CNFG_LEN,
    .desc_idx    = BLE_ESC_DESC_VALUE_CHANGED_CLI_CNFG_IDX,
    .p_attr_hdls = gs_desc_value_changed_cli_cnfg_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_ESC_WriteDescValueChangedCliCnfg(uint16_t conn_hdl, const uint16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_desc_value_changed_cli_cnfg, conn_hdl, p_value);
}

ble_status_t R_BLE_ESC_ReadDescValueChangedCliCnfg(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_desc_value_changed_cli_cnfg, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Descriptor Value Changed Characteristic
----------------------------------------------------------------------------------------------------------------------*/
/* Descriptor Value Changed characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_desc_value_changed_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************
 * Function Name: decode_st_ble_esc_desc_value_changed_t
 * Description  : This function converts descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - Pointer to the characteristic value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_esc_desc_value_changed_t(st_ble_esc_desc_value_changed_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos   = 0;
    uint16_t flag = 0;

    /* check the length */

    if (BLE_ESC_DESC_VALUE_CHANGED_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    memset(p_app_value, 0x00, sizeof(st_ble_esc_desc_value_changed_t));

    BT_UNPACK_LE_2_BYTE(&flag, &p_gatt_value->p_value[0]);
    pos += 2;

    /* Decode descriptor value flags bit fields */
    if ((flag & BLE_ESC_PRV_DESCRIPTER_VALUE_CHANGED_FLAG_SOURCE_OF_CHANGE))
    {
        p_app_value->flags.is_changed_by_client = true;
    }
    else
    {
        p_app_value->flags.is_changed_by_client = false;
    }

    if ((flag & BLE_ESC_PRV_DESCRIPTER_VALUE_CHANGED_FLAG_CHANGE_TO_MORE_ES_TRIGGER_SETTING_DESCRIPTORS))
    {
        p_app_value->flags.is_one_or_more_es_trigger_setting_descriptors_changed = true;
    }
    else
    {
        p_app_value->flags.is_one_or_more_es_trigger_setting_descriptors_changed = false;
    }

    if ((flag & BLE_ESC_PRV_DESCRIPTER_VALUE_CHANGED_FLAG_CHANGE_TO_ES_CONFIGURATION_DESCRIPTOR))
    {
        p_app_value->flags.is_es_configuration_descriptor_changed = true;
    }
    else
    {
        p_app_value->flags.is_es_configuration_descriptor_changed = false;
    }

    if ((flag & BLE_ESC_PRV_DESCRIPTER_VALUE_CHANGED_FLAG_CHANGE_TO_ES_MEASUREMENT_DESCRIPTOR))
    {
        p_app_value->flags.is_es_measurement_descriptor_changed = true;
    }
    else
    {
        p_app_value->flags.is_es_measurement_descriptor_changed = false;
    }

    if ((flag & BLE_ESC_PRV_DESCRIPTER_VALUE_CHANGED_FLAG_CHANGE_TO_CHARACTERISTIC_USER_DESCRIPTION_DESCRIPTOR))
    {
        p_app_value->flags.is_characteristic_user_description_descriptor_changed = true;
    }
    else
    {
        p_app_value->flags.is_characteristic_user_description_descriptor_changed = false;
    }

    /* Convert characteristic uuid[] byte sequence */
    for (uint8_t i = 0; i < (p_gatt_value->value_len - 2); i++)
    {
        BT_UNPACK_LE_1_BYTE(&p_app_value->uuid[i], &p_gatt_value->p_value[pos++]);
    }

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_st_ble_esc_desc_value_changed_t
 * Description  : This function converts characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value  - Pointer to the characteristic  value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_esc_desc_value_changed_t(const st_ble_esc_desc_value_changed_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_ESC_DESC_VALUE_CHANGED_LEN);

    /* Encode descriptor value flags */
    if (p_app_value->flags.is_changed_by_client)
    {
        p_gatt_value->p_value[0] |= BLE_ESC_PRV_DESCRIPTER_VALUE_CHANGED_FLAG_SOURCE_OF_CHANGE;
    }

    if (p_app_value->flags.is_one_or_more_es_trigger_setting_descriptors_changed)
    {
        p_gatt_value->p_value[0] |= BLE_ESC_PRV_DESCRIPTER_VALUE_CHANGED_FLAG_CHANGE_TO_MORE_ES_TRIGGER_SETTING_DESCRIPTORS;
    }

    if (p_app_value->flags.is_es_measurement_descriptor_changed)
    {
        p_gatt_value->p_value[0] |= BLE_ESC_PRV_DESCRIPTER_VALUE_CHANGED_FLAG_CHANGE_TO_ES_CONFIGURATION_DESCRIPTOR;
    }

    if (p_app_value->flags.is_es_configuration_descriptor_changed)
    {
        p_gatt_value->p_value[0] |= BLE_ESC_PRV_DESCRIPTER_VALUE_CHANGED_FLAG_CHANGE_TO_ES_MEASUREMENT_DESCRIPTOR;
    }

    if (p_app_value->flags.is_characteristic_user_description_descriptor_changed)
    {
        p_gatt_value->p_value[0] |= BLE_ESC_PRV_DESCRIPTER_VALUE_CHANGED_FLAG_CHANGE_TO_CHARACTERISTIC_USER_DESCRIPTION_DESCRIPTOR;
    }

    pos += 2;

    /* Convert characteristic uuid[] to byte sequence */
    for (uint8_t i = 0; i <= 15; i++)
    {
        BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->uuid[i]);
    }

    /* Update length */
    p_gatt_value->value_len = BLE_ESC_DESC_VALUE_CHANGED_LEN;

    return BLE_SUCCESS;
}

/* Descriptor Value Changed characteristic descriptor definition */
static const st_ble_servc_desc_info_t *gspp_desc_value_changed_descs[] = {
    &gs_desc_value_changed_cli_cnfg,
};

/* Descriptor Value Changed characteristic definition */
const st_ble_servc_char_info_t gs_desc_value_changed_char = {
    .uuid_16      = BLE_ESC_DESC_VALUE_CHANGED_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_esc_desc_value_changed_t),
    .db_size      = BLE_ESC_DESC_VALUE_CHANGED_LEN,
    .char_idx     = BLE_ESC_DESC_VALUE_CHANGED_IDX,
    .p_attr_hdls  = gs_desc_value_changed_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_esc_desc_value_changed_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_esc_desc_value_changed_t,
    .num_of_descs = ARRAY_SIZE(gspp_desc_value_changed_descs),
    .pp_descs     = gspp_desc_value_changed_descs,
};

void R_BLE_ESC_GetDescValueChangedAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_esc_desc_value_changed_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_desc_value_changed_char_ranges[conn_idx];
    p_hdl->cli_cnfg_desc_hdl = gs_desc_value_changed_cli_cnfg_desc_hdls[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Temperature 0 Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Temperature 0 characteristic descriptors attribute handles */
static uint16_t gs_temperature_0_cli_cnfg_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_temperature_0_cli_cnfg ={
    .uuid_16     = BLE_ESC_TEMPERATURE_0_CLI_CNFG_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint16_t),
    .db_size     = BLE_ESC_TEMPERATURE_0_CLI_CNFG_LEN,
    .desc_idx    = BLE_ESC_TEMPERATURE_0_CLI_CNFG_IDX,
    .p_attr_hdls = gs_temperature_0_cli_cnfg_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_ESC_WriteTemperature0CliCnfg(uint16_t conn_hdl, const uint16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_temperature_0_cli_cnfg, conn_hdl, p_value);
}

ble_status_t R_BLE_ESC_ReadTemperature0CliCnfg(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_temperature_0_cli_cnfg, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Temperature 0 Environmental Sensing Measurement descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Temperature 0 characteristic descriptors attribute handles */
static uint16_t gs_temperature_0_es_meas_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************
 * Function Name: decode_st_ble_esc_temperature_0_es_meas_t
 * Description  : This function converts Temperature descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - Pointer to the Temperature  value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_esc_temperature_0_es_meas_t(st_ble_esc_temperature_0_es_meas_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    /* check the length */
    if (BLE_ESC_TEMPERATURE_0_ES_MEAS_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    memset(p_app_value, 0x00, sizeof(st_ble_esc_temperature_0_es_meas_t));

    /* Copy the flag */
    BT_UNPACK_LE_2_BYTE(&p_app_value->flags, &p_gatt_value->p_value[pos]);
    pos += 2;

    BT_UNPACK_LE_1_BYTE(&p_app_value->sampling_function, &p_gatt_value->p_value[pos]);
    pos += 1;

    BT_UNPACK_LE_3_BYTE(&p_app_value->measurement_period, &p_gatt_value->p_value[pos]);
    pos += 3;

    BT_UNPACK_LE_3_BYTE(&p_app_value->update_interval, &p_gatt_value->p_value[pos]);
    pos += 3;

    BT_UNPACK_LE_1_BYTE(&p_app_value->application, &p_gatt_value->p_value[pos]);
    pos += 1;

    BT_UNPACK_LE_1_BYTE(&p_app_value->measurement_uncertainty, &p_gatt_value->p_value[pos]);

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_st_ble_esc_temperature_0_es_meas_t
 * Description  : This function converts Temperature characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value  - Pointer to the Temperature  value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_esc_temperature_0_es_meas_t(const st_ble_esc_temperature_0_es_meas_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_ESC_TEMPERATURE_0_ES_MEAS_LEN);

    /* Encode descriptor value flags - reserved for future use */
    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->flags);
    pos += 2;

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->sampling_function);
    pos += 1;

    BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], &p_app_value->measurement_period);
    pos += 3;

    BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], &p_app_value->update_interval);
    pos += 3;

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->application);
    pos += 1;

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->measurement_uncertainty);
    pos += 1;

    /* update length*/
    p_gatt_value->value_len = BLE_ESC_TEMPERATURE_0_ES_MEAS_LEN;

    return BLE_SUCCESS;
}

static const st_ble_servc_desc_info_t gs_temperature_0_es_meas ={
    .uuid_16     = BLE_ESC_TEMPERATURE_0_ES_MEAS_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(st_ble_esc_temperature_0_es_meas_t),
    .db_size     = BLE_ESC_TEMPERATURE_0_ES_MEAS_LEN,
    .desc_idx    = BLE_ESC_TEMPERATURE_0_ES_MEAS_IDX,
    .p_attr_hdls = gs_temperature_0_es_meas_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_st_ble_esc_temperature_0_es_meas_t,
    .encode      = (ble_servc_attr_encode_t)encode_st_ble_esc_temperature_0_es_meas_t,
};

ble_status_t R_BLE_ESC_ReadTemperature0EsMeas(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_temperature_0_es_meas, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Temperature 0 Characteristic Extended Properties descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Temperature 0 characteristic descriptors attribute handles */
static uint16_t gs_temperature_0_char_extended_properties_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_temperature_0_char_extended_properties ={
    .uuid_16     = BLE_ESC_TEMPERATURE_0_CHAR_EXTENDED_PROPERTIES_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint16_t),
    .db_size     = BLE_ESC_TEMPERATURE_0_CHAR_EXTENDED_PROPERTIES_LEN,
    .desc_idx    = BLE_ESC_TEMPERATURE_0_CHAR_EXTENDED_PROPERTIES_IDX,
    .p_attr_hdls = gs_temperature_0_char_extended_properties_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_ESC_ReadTemperature0CharExtendedProperties(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_temperature_0_char_extended_properties, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Temperature 0 Environmental Sensing Trigger Setting 0 descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Temperature 0 characteristic descriptors attribute handles */
static uint16_t gs_temperature_0_es_trigger_0_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************
 * Function Name: decode_st_ble_esc_temperature_0_es_trigger_0_t
 * Description  : This function converts Temperature descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - Pointer to the Temperature value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_esc_temperature_0_es_trigger_0_t(st_ble_esc_temperature_0_es_trigger_0_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    /* Check the length */
    if (BLE_ESC_TEMPERATURE_0_ES_TRIGGER_0_LEN < p_gatt_value->value_len)
    {
        return BLE_ESC_WRITE_REQUEST_REJECTED_ERROR;
    }

    /* Copy the condition byte */
    uint8_t condition = p_gatt_value->p_value[pos];

    memset(p_app_value, 0x00, sizeof(st_ble_esc_temperature_0_es_trigger_0_t));

    p_app_value->condition = condition;
    pos += 1;

    if ((BLE_ESC_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_USE_A_FIXED_TIME_INTERVAL_BETWEEN_TRANSMISSIONS == 
        p_app_value->condition)
        || ((BLE_ESC_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_NO_LESS_THAN_THE_SPECIFIED_TIME_BETWEEN_TRANSMISSIONS == 
            p_app_value->condition)))
    {
        /* Copy operand bytes (3) */
        BT_UNPACK_LE_3_BYTE(p_app_value->operand, &p_gatt_value->p_value[pos]);
    }
    else if ((p_app_value->condition <= BLE_ESC_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_WHILE_NOT_EQUAL_TO_THE_SPECIFIED_VALUE)
        && (p_app_value->condition >= BLE_ESC_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_WHILE_LESS_THAN_THE_SPECIFIED_VALUE))
    {
        /* Copy operand bytes (2) */
        BT_UNPACK_LE_2_BYTE(p_app_value->operand, &p_gatt_value->p_value[pos]);
    }
    else if (BLE_ESC_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_WHILE_NOT_EQUAL_TO_THE_SPECIFIED_VALUE < p_app_value->condition)
    {
        /* Tolerate the RFU value, Set to TRIGGER_SETTING_TRIGGER_INACTIVE */
        p_app_value->condition = BLE_ESC_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_TRIGGER_INACTIVE;
    }
    else //other cases
    {
        /* Do Nothing */
    }

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_st_ble_esc_temperature_0_es_trigger_0_t
 * Description  : This function converts Temperature characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value  - Pointer to the Temperature  value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_esc_temperature_0_es_trigger_0_t(const st_ble_esc_temperature_0_es_trigger_0_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_ESC_TEMPERATURE_0_ES_TRIGGER_0_LEN);

    /* Copy the condition byte */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->condition);
    pos += 1;
    
    if ((BLE_ESC_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_USE_A_FIXED_TIME_INTERVAL_BETWEEN_TRANSMISSIONS == 
        p_app_value->condition)
        || (BLE_ESC_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_NO_LESS_THAN_THE_SPECIFIED_TIME_BETWEEN_TRANSMISSIONS == 
            p_app_value->condition))
    {
        /* Convert operand (24 bits) to byte sequence */
        BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], p_app_value->operand);
        pos += 3;
    }
    else if ((BLE_ESC_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_TRIGGER_INACTIVE == p_app_value->condition) ||
        (BLE_ESC_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_WHEN_VALUE_CHANGES_COMPARED_TO_PREVIOUS_VALUE == 
            p_app_value->condition))
    {
        /* Do Nothing */
    }
    else
    {
        /* Convert operand (16 bits) to byte sequence */
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], p_app_value->operand);
        pos += 2;
    }

    /* Update length */
    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

static const st_ble_servc_desc_info_t gs_temperature_0_es_trigger_0 ={
    .uuid_16     = BLE_ESC_TEMPERATURE_0_ES_TRIGGER_0_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(st_ble_esc_temperature_0_es_trigger_0_t),
    .db_size     = BLE_ESC_TEMPERATURE_0_ES_TRIGGER_0_LEN,
    .desc_idx    = BLE_ESC_TEMPERATURE_0_ES_TRIGGER_0_IDX,
    .p_attr_hdls = gs_temperature_0_es_trigger_0_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_st_ble_esc_temperature_0_es_trigger_0_t,
    .encode      = (ble_servc_attr_encode_t)encode_st_ble_esc_temperature_0_es_trigger_0_t,
};

ble_status_t R_BLE_ESC_WriteTemperature0EsTrigger0(uint16_t conn_hdl, const st_ble_esc_temperature_0_es_trigger_0_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_temperature_0_es_trigger_0, conn_hdl, p_value);
}

ble_status_t R_BLE_ESC_ReadTemperature0EsTrigger0(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_temperature_0_es_trigger_0, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Temperature 0 Environmental Sensing Trigger Setting 1 descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Temperature 0 characteristic descriptors attribute handles */
static uint16_t gs_temperature_0_es_trigger_1_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************
 * Function Name: decode_st_ble_esc_temperature_0_es_trigger_1_t
 * Description  : This function converts Temperature descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - Pointer to the Temperature value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_esc_temperature_0_es_trigger_1_t(st_ble_esc_temperature_0_es_trigger_1_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    /* Check the length */
    if (BLE_ESC_TEMPERATURE_0_ES_TRIGGER_1_LEN < p_gatt_value->value_len)
    {
        return BLE_ESC_WRITE_REQUEST_REJECTED_ERROR;
    }

    /* Copy the condition byte */
    uint8_t condition = p_gatt_value->p_value[pos];

    memset(p_app_value, 0x00, sizeof(st_ble_esc_temperature_0_es_trigger_0_t));

    p_app_value->condition = condition;
    pos += 1;

    if ((BLE_ESC_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_USE_A_FIXED_TIME_INTERVAL_BETWEEN_TRANSMISSIONS == 
        p_app_value->condition)
        || ((BLE_ESC_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_NO_LESS_THAN_THE_SPECIFIED_TIME_BETWEEN_TRANSMISSIONS == 
            p_app_value->condition)))
    {
        /* Copy operand bytes (3) */
        BT_UNPACK_LE_3_BYTE(p_app_value->operand, &p_gatt_value->p_value[pos]);
    }
    else if ((p_app_value->condition <= BLE_ESC_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_WHILE_NOT_EQUAL_TO_THE_SPECIFIED_VALUE)
        && (p_app_value->condition >= BLE_ESC_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_WHILE_LESS_THAN_THE_SPECIFIED_VALUE))
    {
        /* Copy operand bytes (2) */
        BT_UNPACK_LE_2_BYTE(p_app_value->operand, &p_gatt_value->p_value[pos]);
    }
    else if (BLE_ESC_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_WHILE_NOT_EQUAL_TO_THE_SPECIFIED_VALUE < p_app_value->condition)
    {
        /* Tolerate the RFU value, Set to TRIGGER_SETTING_TRIGGER_INACTIVE */
        p_app_value->condition = BLE_ESC_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_TRIGGER_INACTIVE;
    }
    else //other cases
    {
        /* Do Nothing */
    }

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_st_ble_esc_temperature_0_es_trigger_1_t
 * Description  : This function converts Temperature characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value  - Pointer to the Temperature value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_esc_temperature_0_es_trigger_1_t(const st_ble_esc_temperature_0_es_trigger_1_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_ESC_TEMPERATURE_0_ES_TRIGGER_1_LEN);

    /* Copy the condition byte */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->condition);
    pos += 1;

    if ((BLE_ESC_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_USE_A_FIXED_TIME_INTERVAL_BETWEEN_TRANSMISSIONS == 
        p_app_value->condition)
        || (BLE_ESC_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_NO_LESS_THAN_THE_SPECIFIED_TIME_BETWEEN_TRANSMISSIONS == 
            p_app_value->condition))
    {
        /* Convert operand (24 bits) to byte sequence */
        BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], p_app_value->operand);
        pos += 3;
    }
    else if ((BLE_ESC_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_TRIGGER_INACTIVE == p_app_value->condition) ||
        (BLE_ESC_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_WHEN_VALUE_CHANGES_COMPARED_TO_PREVIOUS_VALUE == 
            p_app_value->condition))
    {
        /* Do Nothing */
    }
    else
    {
        /* Convert operand (16 bits) to byte sequence */
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], p_app_value->operand);
        pos += 2;
    }

    /* Update length */
    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

static const st_ble_servc_desc_info_t gs_temperature_0_es_trigger_1 ={
    .uuid_16     = BLE_ESC_TEMPERATURE_0_ES_TRIGGER_1_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(st_ble_esc_temperature_0_es_trigger_1_t),
    .db_size     = BLE_ESC_TEMPERATURE_0_ES_TRIGGER_1_LEN,
    .desc_idx    = BLE_ESC_TEMPERATURE_0_ES_TRIGGER_1_IDX,
    .p_attr_hdls = gs_temperature_0_es_trigger_1_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_st_ble_esc_temperature_0_es_trigger_1_t,
    .encode      = (ble_servc_attr_encode_t)encode_st_ble_esc_temperature_0_es_trigger_1_t,
};

ble_status_t R_BLE_ESC_WriteTemperature0EsTrigger1(uint16_t conn_hdl, const st_ble_esc_temperature_0_es_trigger_1_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_temperature_0_es_trigger_1, conn_hdl, p_value);
}

ble_status_t R_BLE_ESC_ReadTemperature0EsTrigger1(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_temperature_0_es_trigger_1, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Temperature 0 Environmental Sensing Trigger Setting 2 descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Temperature 0 characteristic descriptors attribute handles */
static uint16_t gs_temperature_0_es_trigger_2_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************
 * Function Name: decode_st_ble_esc_temperature_0_es_trigger_2_t
 * Description  : This function converts Temperature descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - Pointer to the Temperature value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_esc_temperature_0_es_trigger_2_t(st_ble_esc_temperature_0_es_trigger_2_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    /* Check the length */
    if (BLE_ESC_TEMPERATURE_0_ES_TRIGGER_2_LEN < p_gatt_value->value_len)
    {
        return BLE_ESC_WRITE_REQUEST_REJECTED_ERROR;
    }

    /* Copy the condition byte */
    uint8_t condition = p_gatt_value->p_value[pos];

    memset(p_app_value, 0x00, sizeof(st_ble_esc_temperature_0_es_trigger_0_t));

    p_app_value->condition = condition;
    pos += 1;

    if ((BLE_ESC_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_USE_A_FIXED_TIME_INTERVAL_BETWEEN_TRANSMISSIONS == 
        p_app_value->condition)
        || ((BLE_ESC_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_NO_LESS_THAN_THE_SPECIFIED_TIME_BETWEEN_TRANSMISSIONS == 
            p_app_value->condition)))
    {
        /* Copy operand bytes (3) */
        BT_UNPACK_LE_3_BYTE(p_app_value->operand, &p_gatt_value->p_value[pos]);
    }
    else if ((p_app_value->condition <= BLE_ESC_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_WHILE_NOT_EQUAL_TO_THE_SPECIFIED_VALUE)
        && (p_app_value->condition >= BLE_ESC_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_WHILE_LESS_THAN_THE_SPECIFIED_VALUE))
    {
        /* Copy operand bytes (2) */
        BT_UNPACK_LE_2_BYTE(p_app_value->operand, &p_gatt_value->p_value[pos]);
    }
    else if (BLE_ESC_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_WHILE_NOT_EQUAL_TO_THE_SPECIFIED_VALUE < p_app_value->condition)
    {
        /* Tolerate the RFU value, Set to TRIGGER_SETTING_TRIGGER_INACTIVE */
        p_app_value->condition = BLE_ESC_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_TRIGGER_INACTIVE;
    }
    else //other cases
    {
        /* Do Nothing */
    }

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_temperature_0_environmental_sensing_trigger_setting_0
 * Description  : This function converts Temperature characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value  - Pointer to the Temperature value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_esc_temperature_0_es_trigger_2_t(const st_ble_esc_temperature_0_es_trigger_2_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_ESC_TEMPERATURE_0_ES_TRIGGER_2_LEN);

    /* Copy the condition byte */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->condition);
    pos += 1;

    if ((BLE_ESC_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_USE_A_FIXED_TIME_INTERVAL_BETWEEN_TRANSMISSIONS ==
        p_app_value->condition)
        || (BLE_ESC_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_NO_LESS_THAN_THE_SPECIFIED_TIME_BETWEEN_TRANSMISSIONS ==
            p_app_value->condition))
    {
        /* Convert operand (24 bits) to byte sequence */
        BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], p_app_value->operand);
        pos += 3;
    }
    else if ((BLE_ESC_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_TRIGGER_INACTIVE == p_app_value->condition) ||
        (BLE_ESC_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_WHEN_VALUE_CHANGES_COMPARED_TO_PREVIOUS_VALUE ==
            p_app_value->condition))
    {
        /* Do Nothing */
    }
    else
    {
        /* Convert operand (16 bits) to byte sequence */
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], p_app_value->operand);
        pos += 2;
    }

    /* Update length */
    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

static const st_ble_servc_desc_info_t gs_temperature_0_es_trigger_2 ={
    .uuid_16     = BLE_ESC_TEMPERATURE_0_ES_TRIGGER_2_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(st_ble_esc_temperature_0_es_trigger_2_t),
    .db_size     = BLE_ESC_TEMPERATURE_0_ES_TRIGGER_2_LEN,
    .desc_idx    = BLE_ESC_TEMPERATURE_0_ES_TRIGGER_2_IDX,
    .p_attr_hdls = gs_temperature_0_es_trigger_2_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_st_ble_esc_temperature_0_es_trigger_2_t,
    .encode      = (ble_servc_attr_encode_t)encode_st_ble_esc_temperature_0_es_trigger_2_t,
};

ble_status_t R_BLE_ESC_WriteTemperature0EsTrigger2(uint16_t conn_hdl, const st_ble_esc_temperature_0_es_trigger_2_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_temperature_0_es_trigger_2, conn_hdl, p_value);
}

ble_status_t R_BLE_ESC_ReadTemperature0EsTrigger2(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_temperature_0_es_trigger_2, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Temperature 0 Environmental Sensing Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Temperature 0 characteristic descriptors attribute handles */
static uint16_t gs_temperature_0_es_conf_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_temperature_0_es_conf ={
    .uuid_16     = BLE_ESC_TEMPERATURE_0_ES_CONF_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint8_t),
    .db_size     = BLE_ESC_TEMPERATURE_0_ES_CONF_LEN,
    .desc_idx    = BLE_ESC_TEMPERATURE_0_ES_CONF_IDX,
    .p_attr_hdls = gs_temperature_0_es_conf_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint8_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint8_t,
};

ble_status_t R_BLE_ESC_WriteTemperature0EsConf(uint16_t conn_hdl, const uint8_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_temperature_0_es_conf, conn_hdl, p_value);
}

ble_status_t R_BLE_ESC_ReadTemperature0EsConf(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_temperature_0_es_conf, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Temperature 0 Characteristic User Description descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Temperature 0 characteristic descriptors attribute handles */
static uint16_t gs_temperature_0_char_user_desc_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************
 * Function Name: decode_st_ble_esc_temperature_0_char_user_desc_t
 * Description  : This function converts Temperature descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - Pointer to the Temperature value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_esc_temperature_0_char_user_desc_t(st_ble_esc_temperature_0_char_user_desc_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    /* Check for length */
    if (BLE_ESC_TEMPERATURE_0_CHAR_USER_DESC_LEN < p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    memset(&p_app_value->user_description[0], 0x00, 98);
    memcpy(&p_app_value->user_description[0], p_gatt_value->p_value, 98);
    
    BT_UNPACK_LE_2_BYTE(&p_app_value->length, (uint8_t *)&p_gatt_value->value_len);

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_st_ble_esc_temperature_0_char_user_desc_t
 * Description  : This function converts Temperature characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value  - Pointer to the Temperature  value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_esc_temperature_0_char_user_desc_t(const st_ble_esc_temperature_0_char_user_desc_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_ESC_TEMPERATURE_0_CHAR_USER_DESC_LEN);

    memcpy(&p_gatt_value->p_value[0], &p_app_value->user_description[0] , p_app_value->length);
    pos += p_app_value->length;

    /* Update length */
    p_gatt_value->value_len = p_app_value->length;

    return BLE_SUCCESS;
}

static const st_ble_servc_desc_info_t gs_temperature_0_char_user_desc ={
    .uuid_16     = BLE_ESC_TEMPERATURE_0_CHAR_USER_DESC_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(st_ble_esc_temperature_0_char_user_desc_t),
    .db_size     = BLE_ESC_TEMPERATURE_0_CHAR_USER_DESC_LEN,
    .desc_idx    = BLE_ESC_TEMPERATURE_0_CHAR_USER_DESC_IDX,
    .p_attr_hdls = gs_temperature_0_char_user_desc_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_st_ble_esc_temperature_0_char_user_desc_t,
    .encode      = (ble_servc_attr_encode_t)encode_st_ble_esc_temperature_0_char_user_desc_t,
};

ble_status_t R_BLE_ESC_WriteTemperature0CharUserDesc(uint16_t conn_hdl, const st_ble_esc_temperature_0_char_user_desc_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc2(&gs_temperature_0_char_user_desc, conn_hdl, p_value);
}

ble_status_t R_BLE_ESC_ReadTemperature0CharUserDesc(uint16_t conn_hdl, int32_t type) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc_with_Type(&gs_temperature_0_char_user_desc, conn_hdl, type);
}

/*----------------------------------------------------------------------------------------------------------------------
    Temperature 0 Valid Range descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Temperature 0 characteristic descriptors attribute handles */
static uint16_t gs_temperature_0_valid_range_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************
 * Function Name: decode_st_ble_esc_temperature_0_valid_range_t
 * Description  : This function converts Temperature descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - Pointer to the Temperature value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_esc_temperature_0_valid_range_t(st_ble_esc_temperature_0_valid_range_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    /* Check for length */
    if (BLE_ESC_TEMPERATURE_0_VALID_RANGE_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Copy the lower inclusive bytes */
    BT_UNPACK_LE_2_BYTE(&p_app_value->lower_inclusive_value, &p_gatt_value->p_value[pos]);
    pos += 2;

    /* Copy the upper inclusive bytes */
    BT_UNPACK_LE_2_BYTE(&p_app_value->upper_inclusive_value, &p_gatt_value->p_value[pos]);

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_st_ble_esc_temperature_0_valid_range_t
 * Description  : This function converts Temperature characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value  - Pointer to the Temperature  value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_esc_temperature_0_valid_range_t(const st_ble_esc_temperature_0_valid_range_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_ESC_TEMPERATURE_0_VALID_RANGE_LEN);

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->lower_inclusive_value);
    pos += 2;

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->upper_inclusive_value);

    /* Update length */
    p_gatt_value->value_len = BLE_ESC_TEMPERATURE_0_VALID_RANGE_LEN;

    return BLE_SUCCESS;
}

static const st_ble_servc_desc_info_t gs_temperature_0_valid_range ={
    .uuid_16     = BLE_ESC_TEMPERATURE_0_VALID_RANGE_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(st_ble_esc_temperature_0_valid_range_t),
    .db_size     = BLE_ESC_TEMPERATURE_0_VALID_RANGE_LEN,
    .desc_idx    = BLE_ESC_TEMPERATURE_0_VALID_RANGE_IDX,
    .p_attr_hdls = gs_temperature_0_valid_range_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_st_ble_esc_temperature_0_valid_range_t,
    .encode      = (ble_servc_attr_encode_t)encode_st_ble_esc_temperature_0_valid_range_t,
};

ble_status_t R_BLE_ESC_ReadTemperature0ValidRange(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_temperature_0_valid_range, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Temperature 0 Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Temperature 0 characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_temperature_0_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

/* Temperature 0 characteristic descriptor definition */
static const st_ble_servc_desc_info_t *gspp_temperature_0_descs[] = {
    &gs_temperature_0_cli_cnfg,
    &gs_temperature_0_es_meas,
    &gs_temperature_0_char_extended_properties,
    &gs_temperature_0_es_trigger_0,
    &gs_temperature_0_es_trigger_1,
    &gs_temperature_0_es_trigger_2,
    &gs_temperature_0_es_conf,
    &gs_temperature_0_char_user_desc,
    &gs_temperature_0_valid_range,
};

/* Temperature 0 characteristic definition */
const st_ble_servc_char_info_t gs_temperature_0_char = {
    .uuid_16      = BLE_ESC_TEMPERATURE_0_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(int16_t),
    .db_size      = BLE_ESC_TEMPERATURE_0_LEN,
    .char_idx     = BLE_ESC_TEMPERATURE_0_IDX,
    .p_attr_hdls  = gs_temperature_0_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_int16_t,
    .encode       = (ble_servc_attr_encode_t)encode_int16_t,
    .num_of_descs = ARRAY_SIZE(gspp_temperature_0_descs),
    .pp_descs     = gspp_temperature_0_descs,
};

ble_status_t R_BLE_ESC_ReadTemperature0(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_temperature_0_char, conn_hdl);
}

void R_BLE_ESC_GetTemperature0AttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_esc_temperature_0_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_temperature_0_char_ranges[conn_idx];
    p_hdl->cli_cnfg_desc_hdl = gs_temperature_0_cli_cnfg_desc_hdls[conn_idx];
    p_hdl->es_meas_desc_hdl = gs_temperature_0_es_meas_desc_hdls[conn_idx];
    p_hdl->char_extended_properties_desc_hdl = gs_temperature_0_char_extended_properties_desc_hdls[conn_idx];
    p_hdl->es_trigger_0_desc_hdl = gs_temperature_0_es_trigger_0_desc_hdls[conn_idx];
    p_hdl->es_trigger_1_desc_hdl = gs_temperature_0_es_trigger_1_desc_hdls[conn_idx];
    p_hdl->es_trigger_2_desc_hdl = gs_temperature_0_es_trigger_2_desc_hdls[conn_idx];
    p_hdl->es_conf_desc_hdl = gs_temperature_0_es_conf_desc_hdls[conn_idx];
    p_hdl->char_user_desc_desc_hdl = gs_temperature_0_char_user_desc_desc_hdls[conn_idx];
    p_hdl->valid_range_desc_hdl = gs_temperature_0_valid_range_desc_hdls[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Temperature 1 Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Temperature 1 characteristic descriptors attribute handles */
static uint16_t gs_temperature_1_cli_cnfg_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_temperature_1_cli_cnfg ={
    .uuid_16     = BLE_ESC_TEMPERATURE_1_CLI_CNFG_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint16_t),
    .db_size     = BLE_ESC_TEMPERATURE_1_CLI_CNFG_LEN,
    .desc_idx    = BLE_ESC_TEMPERATURE_1_CLI_CNFG_IDX,
    .p_attr_hdls = gs_temperature_1_cli_cnfg_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_ESC_WriteTemperature1CliCnfg(uint16_t conn_hdl, const uint16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_temperature_1_cli_cnfg, conn_hdl, p_value);
}

ble_status_t R_BLE_ESC_ReadTemperature1CliCnfg(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_temperature_1_cli_cnfg, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Temperature 1 Environmental Sensing Measurement descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Temperature 1 characteristic descriptors attribute handles */
static uint16_t gs_temperature_1_es_meas_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************
 * Function Name: decode_st_ble_esc_temperature_1_es_meas_t
 * Description  : This function converts Temperature descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - Pointer to the Temperature  value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_esc_temperature_1_es_meas_t(st_ble_esc_temperature_1_es_meas_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    /* check the length */
    if (BLE_ESC_TEMPERATURE_1_ES_MEAS_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    memset(p_app_value, 0x00, sizeof(st_ble_esc_temperature_1_es_meas_t));

    /* Copy the flag */
    BT_UNPACK_LE_2_BYTE(&p_app_value->flags, &p_gatt_value->p_value[pos]);
    pos += 2;

    BT_UNPACK_LE_1_BYTE(&p_app_value->sampling_function, &p_gatt_value->p_value[pos]);
    pos += 1;

    BT_UNPACK_LE_3_BYTE(&p_app_value->measurement_period, &p_gatt_value->p_value[pos]);
    pos += 3;

    BT_UNPACK_LE_3_BYTE(&p_app_value->update_interval, &p_gatt_value->p_value[pos]);
    pos += 3;

    BT_UNPACK_LE_1_BYTE(&p_app_value->application, &p_gatt_value->p_value[pos]);
    pos += 1;

    BT_UNPACK_LE_1_BYTE(&p_app_value->measurement_uncertainty, &p_gatt_value->p_value[pos]);

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_st_ble_esc_temperature_1_es_meas_t
 * Description  : This function converts Temperature characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value  - Pointer to the Temperature  value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_esc_temperature_1_es_meas_t(const st_ble_esc_temperature_1_es_meas_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_ESC_TEMPERATURE_1_ES_MEAS_LEN);

    /* Encode descriptor value flags - reserved for future use */
    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->flags);
    pos += 2;

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->sampling_function);
    pos += 1;

    BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], &p_app_value->measurement_period);
    pos += 3;

    BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], &p_app_value->update_interval);
    pos += 3;

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->application);
    pos += 1;

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->measurement_uncertainty);
    pos += 1;

    /* update length*/
    p_gatt_value->value_len = BLE_ESC_TEMPERATURE_1_ES_MEAS_LEN;

    return BLE_SUCCESS;
}

static const st_ble_servc_desc_info_t gs_temperature_1_es_meas ={
    .uuid_16     = BLE_ESC_TEMPERATURE_1_ES_MEAS_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(st_ble_esc_temperature_1_es_meas_t),
    .db_size     = BLE_ESC_TEMPERATURE_1_ES_MEAS_LEN,
    .desc_idx    = BLE_ESC_TEMPERATURE_1_ES_MEAS_IDX,
    .p_attr_hdls = gs_temperature_1_es_meas_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_st_ble_esc_temperature_1_es_meas_t,
    .encode      = (ble_servc_attr_encode_t)encode_st_ble_esc_temperature_1_es_meas_t,
};

ble_status_t R_BLE_ESC_ReadTemperature1EsMeas(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_temperature_1_es_meas, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Temperature 1 Characteristic Extended Properties descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Temperature 1 characteristic descriptors attribute handles */
static uint16_t gs_temperature_1_char_extended_properties_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_temperature_1_char_extended_properties ={
    .uuid_16     = BLE_ESC_TEMPERATURE_1_CHAR_EXTENDED_PROPERTIES_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint16_t),
    .db_size     = BLE_ESC_TEMPERATURE_1_CHAR_EXTENDED_PROPERTIES_LEN,
    .desc_idx    = BLE_ESC_TEMPERATURE_1_CHAR_EXTENDED_PROPERTIES_IDX,
    .p_attr_hdls = gs_temperature_1_char_extended_properties_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_ESC_ReadTemperature1CharExtendedProperties(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_temperature_1_char_extended_properties, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Temperature 1 Environmental Sensing Trigger Setting 0 descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Temperature 1 characteristic descriptors attribute handles */
static uint16_t gs_temperature_1_es_trigger_0_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************
 * Function Name: decode_st_ble_esc_temperature_1_es_trigger_0_t
 * Description  : This function converts Temperature descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - Pointer to the Temperature value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_esc_temperature_1_es_trigger_0_t(st_ble_esc_temperature_1_es_trigger_0_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    /* Check the length */
    if (BLE_ESC_TEMPERATURE_1_ES_TRIGGER_0_LEN < p_gatt_value->value_len)
    {
        return BLE_ESC_WRITE_REQUEST_REJECTED_ERROR;
    }

    /* Copy the condition byte */
    uint8_t condition = p_gatt_value->p_value[pos];

    memset(p_app_value, 0x00, sizeof(st_ble_esc_temperature_1_es_trigger_0_t));

    p_app_value->condition = condition;
    pos += 1;

    if ((BLE_ESC_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_USE_A_FIXED_TIME_INTERVAL_BETWEEN_TRANSMISSIONS == 
        p_app_value->condition)
        || ((BLE_ESC_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_NO_LESS_THAN_THE_SPECIFIED_TIME_BETWEEN_TRANSMISSIONS == 
            p_app_value->condition)))
    {
        /* Copy operand bytes (3) */
        BT_UNPACK_LE_3_BYTE(p_app_value->operand, &p_gatt_value->p_value[pos]);
    }
    else if ((p_app_value->condition <= BLE_ESC_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_WHILE_NOT_EQUAL_TO_THE_SPECIFIED_VALUE)
        && (p_app_value->condition >= BLE_ESC_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_WHILE_LESS_THAN_THE_SPECIFIED_VALUE))
    {
        /* Copy operand bytes (2) */
        BT_UNPACK_LE_2_BYTE(p_app_value->operand, &p_gatt_value->p_value[pos]);
    }
    else if (BLE_ESC_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_WHILE_NOT_EQUAL_TO_THE_SPECIFIED_VALUE < p_app_value->condition)
    {
        /* Tolerate the RFU value, Set to TRIGGER_SETTING_TRIGGER_INACTIVE */
        p_app_value->condition = BLE_ESC_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_TRIGGER_INACTIVE;
    }
    else //other cases
    {
        /* Do Nothing */
    }

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_st_ble_esc_temperature_1_es_trigger_0_t
 * Description  : This function converts Temperature characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value  - Pointer to the Temperature  value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_esc_temperature_1_es_trigger_0_t(const st_ble_esc_temperature_1_es_trigger_0_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_ESC_TEMPERATURE_1_ES_TRIGGER_0_LEN);

    /* Copy the condition byte */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->condition);
    pos += 1;

    if ((BLE_ESC_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_USE_A_FIXED_TIME_INTERVAL_BETWEEN_TRANSMISSIONS ==
        p_app_value->condition)
        || (BLE_ESC_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_NO_LESS_THAN_THE_SPECIFIED_TIME_BETWEEN_TRANSMISSIONS ==
            p_app_value->condition))
    {
        /* Convert operand (24 bits) to byte sequence */
        BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], p_app_value->operand);
        pos += 3;
    }
    else if ((BLE_ESC_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_TRIGGER_INACTIVE == p_app_value->condition) ||
        (BLE_ESC_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_WHEN_VALUE_CHANGES_COMPARED_TO_PREVIOUS_VALUE ==
            p_app_value->condition))
    {
        /* Do Nothing */
    }
    else
    {
        /* Convert operand (16 bits) to byte sequence */
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], p_app_value->operand);
        pos += 2;
    }

    /* Update length */
    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

static const st_ble_servc_desc_info_t gs_temperature_1_es_trigger_0 ={
    .uuid_16     = BLE_ESC_TEMPERATURE_1_ES_TRIGGER_0_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(st_ble_esc_temperature_1_es_trigger_0_t),
    .db_size     = BLE_ESC_TEMPERATURE_1_ES_TRIGGER_0_LEN,
    .desc_idx    = BLE_ESC_TEMPERATURE_1_ES_TRIGGER_0_IDX,
    .p_attr_hdls = gs_temperature_1_es_trigger_0_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_st_ble_esc_temperature_1_es_trigger_0_t,
    .encode      = (ble_servc_attr_encode_t)encode_st_ble_esc_temperature_1_es_trigger_0_t,
};

ble_status_t R_BLE_ESC_WriteTemperature1EsTrigger0(uint16_t conn_hdl, const st_ble_esc_temperature_1_es_trigger_0_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_temperature_1_es_trigger_0, conn_hdl, p_value);
}

ble_status_t R_BLE_ESC_ReadTemperature1EsTrigger0(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_temperature_1_es_trigger_0, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Temperature 1 Environmental Sensing Trigger Setting 1 descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Temperature 1 characteristic descriptors attribute handles */
static uint16_t gs_temperature_1_es_trigger_1_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************
 * Function Name: decode_st_ble_esc_temperature_1_es_trigger_1_t
 * Description  : This function converts Temperature descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - Pointer to the Temperature value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_esc_temperature_1_es_trigger_1_t(st_ble_esc_temperature_1_es_trigger_1_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    /* Check the length */
    if (BLE_ESC_TEMPERATURE_1_ES_TRIGGER_1_LEN < p_gatt_value->value_len)
    {
        return BLE_ESC_WRITE_REQUEST_REJECTED_ERROR;
    }

    /* Copy the condition byte */
    uint8_t condition = p_gatt_value->p_value[pos];

    memset(p_app_value, 0x00, sizeof(st_ble_esc_temperature_1_es_trigger_1_t));

    p_app_value->condition = condition;
    pos += 1;

    if ((BLE_ESC_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_USE_A_FIXED_TIME_INTERVAL_BETWEEN_TRANSMISSIONS == 
        p_app_value->condition)
        || ((BLE_ESC_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_NO_LESS_THAN_THE_SPECIFIED_TIME_BETWEEN_TRANSMISSIONS == 
            p_app_value->condition)))
    {
        /* Copy operand bytes (3) */
        BT_UNPACK_LE_3_BYTE(p_app_value->operand, &p_gatt_value->p_value[pos]);
    }
    else if ((p_app_value->condition <= BLE_ESC_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_WHILE_NOT_EQUAL_TO_THE_SPECIFIED_VALUE)
        && (p_app_value->condition >= BLE_ESC_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_WHILE_LESS_THAN_THE_SPECIFIED_VALUE))
    {
        /* Copy operand bytes (2) */
        BT_UNPACK_LE_2_BYTE(p_app_value->operand, &p_gatt_value->p_value[pos]);
    }
    else if (BLE_ESC_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_WHILE_NOT_EQUAL_TO_THE_SPECIFIED_VALUE < p_app_value->condition)
    {
        /* Tolerate the RFU value, Set to TRIGGER_SETTING_TRIGGER_INACTIVE */
        p_app_value->condition = BLE_ESC_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_TRIGGER_INACTIVE;
    }
    else //other cases
    {
        /* Do Nothing */
    }

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_st_ble_esc_temperature_1_es_trigger_1_t
 * Description  : This function converts Temperature characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value  - Pointer to the Temperature  value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_esc_temperature_1_es_trigger_1_t(const st_ble_esc_temperature_1_es_trigger_1_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_ESC_TEMPERATURE_1_ES_TRIGGER_1_LEN);

    /* Copy the condition byte */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->condition);
    pos += 1;

    if ((BLE_ESC_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_USE_A_FIXED_TIME_INTERVAL_BETWEEN_TRANSMISSIONS ==
        p_app_value->condition)
        || (BLE_ESC_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_NO_LESS_THAN_THE_SPECIFIED_TIME_BETWEEN_TRANSMISSIONS ==
            p_app_value->condition))
    {
        /* Convert operand (24 bits) to byte sequence */
        BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], p_app_value->operand);
        pos += 3;
    }
    else if ((BLE_ESC_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_TRIGGER_INACTIVE == p_app_value->condition) ||
        (BLE_ESC_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_WHEN_VALUE_CHANGES_COMPARED_TO_PREVIOUS_VALUE ==
            p_app_value->condition))
    {
        /* Do Nothing */
    }
    else
    {
        /* Convert operand (16 bits) to byte sequence */
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], p_app_value->operand);
        pos += 2;
    }

    /* Update length */
    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

static const st_ble_servc_desc_info_t gs_temperature_1_es_trigger_1 ={
    .uuid_16     = BLE_ESC_TEMPERATURE_1_ES_TRIGGER_1_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(st_ble_esc_temperature_1_es_trigger_1_t),
    .db_size     = BLE_ESC_TEMPERATURE_1_ES_TRIGGER_1_LEN,
    .desc_idx    = BLE_ESC_TEMPERATURE_1_ES_TRIGGER_1_IDX,
    .p_attr_hdls = gs_temperature_1_es_trigger_1_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_st_ble_esc_temperature_1_es_trigger_1_t,
    .encode      = (ble_servc_attr_encode_t)encode_st_ble_esc_temperature_1_es_trigger_1_t,
};

ble_status_t R_BLE_ESC_WriteTemperature1EsTrigger1(uint16_t conn_hdl, const st_ble_esc_temperature_1_es_trigger_1_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_temperature_1_es_trigger_1, conn_hdl, p_value);
}

ble_status_t R_BLE_ESC_ReadTemperature1EsTrigger1(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_temperature_1_es_trigger_1, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Temperature 1 Environmental Sensing Trigger Setting 2 descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Temperature 1 characteristic descriptors attribute handles */
static uint16_t gs_temperature_1_es_trigger_2_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************
 * Function Name: decode_st_ble_esc_temperature_1_es_trigger_2_t
 * Description  : This function converts Temperature descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - Pointer to the Temperature value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_esc_temperature_1_es_trigger_2_t(st_ble_esc_temperature_1_es_trigger_2_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    /* Check the length */
    if (BLE_ESC_TEMPERATURE_1_ES_TRIGGER_2_LEN < p_gatt_value->value_len)
    {
        return BLE_ESC_WRITE_REQUEST_REJECTED_ERROR;
    }

    /* Copy the condition byte */
    uint8_t condition = p_gatt_value->p_value[pos];

    memset(p_app_value, 0x00, sizeof(st_ble_esc_temperature_1_es_trigger_2_t));

    p_app_value->condition = condition;
    pos += 1;

    if ((BLE_ESC_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_USE_A_FIXED_TIME_INTERVAL_BETWEEN_TRANSMISSIONS == 
        p_app_value->condition)
        || ((BLE_ESC_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_NO_LESS_THAN_THE_SPECIFIED_TIME_BETWEEN_TRANSMISSIONS == 
            p_app_value->condition)))
    {
        /* Copy operand bytes (3) */
        BT_UNPACK_LE_3_BYTE(p_app_value->operand, &p_gatt_value->p_value[pos]);
    }
    else if ((p_app_value->condition <= BLE_ESC_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_WHILE_NOT_EQUAL_TO_THE_SPECIFIED_VALUE)
        && (p_app_value->condition >= BLE_ESC_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_WHILE_LESS_THAN_THE_SPECIFIED_VALUE))
    {
        /* Copy operand bytes (2) */
        BT_UNPACK_LE_2_BYTE(p_app_value->operand, &p_gatt_value->p_value[pos]);
    }
    else if (BLE_ESC_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_WHILE_NOT_EQUAL_TO_THE_SPECIFIED_VALUE < p_app_value->condition)
    {
        /* Tolerate the RFU value, Set to TRIGGER_SETTING_TRIGGER_INACTIVE */
        p_app_value->condition = BLE_ESC_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_TRIGGER_INACTIVE;
    }
    else //other cases
    {
        /* Do Nothing */
    }

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_st_ble_esc_temperature_1_es_trigger_2_t
 * Description  : This function converts Temperature characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value  - Pointer to the Temperature  value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_esc_temperature_1_es_trigger_2_t(const st_ble_esc_temperature_1_es_trigger_2_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_ESC_TEMPERATURE_1_ES_TRIGGER_2_LEN);

    /* Copy the condition byte */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->condition);
    pos += 1;

    if ((BLE_ESC_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_USE_A_FIXED_TIME_INTERVAL_BETWEEN_TRANSMISSIONS ==
        p_app_value->condition)
        || (BLE_ESC_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_NO_LESS_THAN_THE_SPECIFIED_TIME_BETWEEN_TRANSMISSIONS ==
            p_app_value->condition))
    {
        /* Convert operand (24 bits) to byte sequence */
        BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], p_app_value->operand);
        pos += 3;
    }
    else if ((BLE_ESC_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_TRIGGER_INACTIVE == p_app_value->condition) ||
        (BLE_ESC_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_WHEN_VALUE_CHANGES_COMPARED_TO_PREVIOUS_VALUE ==
            p_app_value->condition))
    {
        /* Do Nothing */
    }
    else
    {
        /* Convert operand (16 bits) to byte sequence */
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], p_app_value->operand);
        pos += 2;
    }

    /* Update length */
    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

static const st_ble_servc_desc_info_t gs_temperature_1_es_trigger_2 ={
    .uuid_16     = BLE_ESC_TEMPERATURE_1_ES_TRIGGER_2_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(st_ble_esc_temperature_1_es_trigger_2_t),
    .db_size     = BLE_ESC_TEMPERATURE_1_ES_TRIGGER_2_LEN,
    .desc_idx    = BLE_ESC_TEMPERATURE_1_ES_TRIGGER_2_IDX,
    .p_attr_hdls = gs_temperature_1_es_trigger_2_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_st_ble_esc_temperature_1_es_trigger_2_t,
    .encode      = (ble_servc_attr_encode_t)encode_st_ble_esc_temperature_1_es_trigger_2_t,
};

ble_status_t R_BLE_ESC_WriteTemperature1EsTrigger2(uint16_t conn_hdl, const st_ble_esc_temperature_1_es_trigger_2_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_temperature_1_es_trigger_2, conn_hdl, p_value);
}

ble_status_t R_BLE_ESC_ReadTemperature1EsTrigger2(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_temperature_1_es_trigger_2, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Temperature 1 Environmental Sensing Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Temperature 1 characteristic descriptors attribute handles */
static uint16_t gs_temperature_1_es_conf_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_temperature_1_es_conf ={
    .uuid_16     = BLE_ESC_TEMPERATURE_1_ES_CONF_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint8_t),
    .db_size     = BLE_ESC_TEMPERATURE_1_ES_CONF_LEN,
    .desc_idx    = BLE_ESC_TEMPERATURE_1_ES_CONF_IDX,
    .p_attr_hdls = gs_temperature_1_es_conf_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint8_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint8_t,
};

ble_status_t R_BLE_ESC_WriteTemperature1EsConf(uint16_t conn_hdl, const uint8_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_temperature_1_es_conf, conn_hdl, p_value);
}

ble_status_t R_BLE_ESC_ReadTemperature1EsConf(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_temperature_1_es_conf, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Temperature 1 Characteristic User Description descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Temperature 1 characteristic descriptors attribute handles */
static uint16_t gs_temperature_1_char_user_desc_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************
 * Function Name: decode_st_ble_esc_temperature_1_char_user_desc_t
 * Description  : This function converts Temperature descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - Pointer to the Temperature value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_esc_temperature_1_char_user_desc_t(st_ble_esc_temperature_1_char_user_desc_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    /* Check for length */
    if (BLE_ESC_TEMPERATURE_1_CHAR_USER_DESC_LEN < p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    memset(&p_app_value->user_description[0], 0x00, 98);
    memcpy(&p_app_value->user_description[0], p_gatt_value->p_value, 98);

    BT_UNPACK_LE_2_BYTE(&p_app_value->length, (uint8_t *)&p_gatt_value->value_len);

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_st_ble_esc_temperature_1_char_user_desc_t
 * Description  : This function converts Temperature characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value  - Pointer to the Temperature  value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_esc_temperature_1_char_user_desc_t(const st_ble_esc_temperature_1_char_user_desc_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_ESC_TEMPERATURE_1_CHAR_USER_DESC_LEN);

    memcpy(&p_gatt_value->p_value[0], &p_app_value->user_description[0] , p_app_value->length);
    pos += p_app_value->length;

    /* Update length */
    p_gatt_value->value_len = p_app_value->length;

    return BLE_SUCCESS;
}

static const st_ble_servc_desc_info_t gs_temperature_1_char_user_desc ={
    .uuid_16     = BLE_ESC_TEMPERATURE_1_CHAR_USER_DESC_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(st_ble_esc_temperature_1_char_user_desc_t),
    .db_size     = BLE_ESC_TEMPERATURE_1_CHAR_USER_DESC_LEN,
    .desc_idx    = BLE_ESC_TEMPERATURE_1_CHAR_USER_DESC_IDX,
    .p_attr_hdls = gs_temperature_1_char_user_desc_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_st_ble_esc_temperature_1_char_user_desc_t,
    .encode      = (ble_servc_attr_encode_t)encode_st_ble_esc_temperature_1_char_user_desc_t,
};

ble_status_t R_BLE_ESC_WriteTemperature1CharUserDesc(uint16_t conn_hdl, const st_ble_esc_temperature_1_char_user_desc_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc2(&gs_temperature_1_char_user_desc, conn_hdl, p_value);
}

ble_status_t R_BLE_ESC_ReadTemperature1CharUserDesc(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_temperature_1_char_user_desc, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Temperature 1 Valid Range descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Temperature 1 characteristic descriptors attribute handles */
static uint16_t gs_temperature_1_valid_range_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************
 * Function Name: decode_st_ble_esc_temperature_1_valid_range_t
 * Description  : This function converts Temperature descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - Pointer to the Temperature value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_esc_temperature_1_valid_range_t(st_ble_esc_temperature_1_valid_range_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    /* Check for length */
    if (BLE_ESC_TEMPERATURE_1_VALID_RANGE_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Copy the lower inclusive bytes */
    BT_UNPACK_LE_2_BYTE(&p_app_value->lower_inclusive_value, &p_gatt_value->p_value[pos]);
    pos += 2;

    /* Copy the upper inclusive bytes */
    BT_UNPACK_LE_2_BYTE(&p_app_value->upper_inclusive_value, &p_gatt_value->p_value[pos]);

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_st_ble_esc_temperature_1_valid_range_t
 * Description  : This function converts Temperature characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value  - Pointer to the Temperature  value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_esc_temperature_1_valid_range_t(const st_ble_esc_temperature_1_valid_range_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_ESC_TEMPERATURE_1_VALID_RANGE_LEN);

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->lower_inclusive_value);
    pos += 2;

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->upper_inclusive_value);

    /* Update length */
    p_gatt_value->value_len = BLE_ESC_TEMPERATURE_1_VALID_RANGE_LEN;

    return BLE_SUCCESS;
}

static const st_ble_servc_desc_info_t gs_temperature_1_valid_range ={
    .uuid_16     = BLE_ESC_TEMPERATURE_1_VALID_RANGE_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(st_ble_esc_temperature_1_valid_range_t),
    .db_size     = BLE_ESC_TEMPERATURE_1_VALID_RANGE_LEN,
    .desc_idx    = BLE_ESC_TEMPERATURE_1_VALID_RANGE_IDX,
    .p_attr_hdls = gs_temperature_1_valid_range_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_st_ble_esc_temperature_1_valid_range_t,
    .encode      = (ble_servc_attr_encode_t)encode_st_ble_esc_temperature_1_valid_range_t,
};

ble_status_t R_BLE_ESC_ReadTemperature1ValidRange(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_temperature_1_valid_range, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Temperature 1 Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Temperature 1 characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_temperature_1_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

/* Temperature 1 characteristic descriptor definition */
static const st_ble_servc_desc_info_t *gspp_temperature_1_descs[] = {
    &gs_temperature_1_cli_cnfg,
    &gs_temperature_1_es_meas,
    &gs_temperature_1_char_extended_properties,
    &gs_temperature_1_es_trigger_0,
    &gs_temperature_1_es_trigger_1,
    &gs_temperature_1_es_trigger_2,
    &gs_temperature_1_es_conf,
    &gs_temperature_1_char_user_desc,
    &gs_temperature_1_valid_range,
};

/* Temperature 1 characteristic definition */
const st_ble_servc_char_info_t gs_temperature_1_char = {
    .uuid_16      = BLE_ESC_TEMPERATURE_1_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(int16_t),
    .db_size      = BLE_ESC_TEMPERATURE_1_LEN,
    .char_idx     = BLE_ESC_TEMPERATURE_1_IDX,
    .p_attr_hdls  = gs_temperature_1_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_int16_t,
    .encode       = (ble_servc_attr_encode_t)encode_int16_t,
    .num_of_descs = ARRAY_SIZE(gspp_temperature_1_descs),
    .pp_descs     = gspp_temperature_1_descs,
};

ble_status_t R_BLE_ESC_ReadTemperature1(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_temperature_1_char, conn_hdl);
}

void R_BLE_ESC_GetTemperature1AttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_esc_temperature_1_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_temperature_1_char_ranges[conn_idx];
    p_hdl->cli_cnfg_desc_hdl = gs_temperature_1_cli_cnfg_desc_hdls[conn_idx];
    p_hdl->es_meas_desc_hdl = gs_temperature_1_es_meas_desc_hdls[conn_idx];
    p_hdl->char_extended_properties_desc_hdl = gs_temperature_1_char_extended_properties_desc_hdls[conn_idx];
    p_hdl->es_trigger_0_desc_hdl = gs_temperature_1_es_trigger_0_desc_hdls[conn_idx];
    p_hdl->es_trigger_1_desc_hdl = gs_temperature_1_es_trigger_1_desc_hdls[conn_idx];
    p_hdl->es_trigger_2_desc_hdl = gs_temperature_1_es_trigger_2_desc_hdls[conn_idx];
    p_hdl->es_conf_desc_hdl = gs_temperature_1_es_conf_desc_hdls[conn_idx];
    p_hdl->char_user_desc_desc_hdl = gs_temperature_1_char_user_desc_desc_hdls[conn_idx];
    p_hdl->valid_range_desc_hdl = gs_temperature_1_valid_range_desc_hdls[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Elevation 0 Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Elevation 0 characteristic descriptors attribute handles */
static uint16_t gs_elevation_0_cli_cnfg_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_elevation_0_cli_cnfg ={
    .uuid_16     = BLE_ESC_ELEVATION_0_CLI_CNFG_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint16_t),
    .db_size     = BLE_ESC_ELEVATION_0_CLI_CNFG_LEN,
    .desc_idx    = BLE_ESC_ELEVATION_0_CLI_CNFG_IDX,
    .p_attr_hdls = gs_elevation_0_cli_cnfg_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_ESC_WriteElevation0CliCnfg(uint16_t conn_hdl, const uint16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_elevation_0_cli_cnfg, conn_hdl, p_value);
}

ble_status_t R_BLE_ESC_ReadElevation0CliCnfg(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_elevation_0_cli_cnfg, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Elevation 0 Environmental Sensing Measurement descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Elevation 0 characteristic descriptors attribute handles */
static uint16_t gs_elevation_0_es_meas_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************
 * Function Name: decode_st_ble_esc_elevation_0_es_meas_t
 * Description  : This function converts Temperature descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - Pointer to the Elevation  value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_esc_elevation_0_es_meas_t(st_ble_esc_elevation_0_es_meas_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    /* check the length */
    if (BLE_ESC_ELEVATION_0_ES_MEAS_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    memset(p_app_value, 0x00, sizeof(st_ble_esc_elevation_0_es_meas_t));

    /* Copy the flag */
    BT_UNPACK_LE_2_BYTE(&p_app_value->flags, &p_gatt_value->p_value[pos]);
    pos += 2;

    BT_UNPACK_LE_1_BYTE(&p_app_value->sampling_function, &p_gatt_value->p_value[pos]);
    pos += 1;

    BT_UNPACK_LE_3_BYTE(&p_app_value->measurement_period, &p_gatt_value->p_value[pos]);
    pos += 3;

    BT_UNPACK_LE_3_BYTE(&p_app_value->update_interval, &p_gatt_value->p_value[pos]);
    pos += 3;

    BT_UNPACK_LE_1_BYTE(&p_app_value->application, &p_gatt_value->p_value[pos]);
    pos += 1;

    BT_UNPACK_LE_1_BYTE(&p_app_value->measurement_uncertainty, &p_gatt_value->p_value[pos]);

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_st_ble_esc_elevation_0_es_meas_t
 * Description  : This function converts Elevation characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value  - Pointer to the Elevation value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_esc_elevation_0_es_meas_t(const st_ble_esc_elevation_0_es_meas_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_ESC_ELEVATION_0_ES_MEAS_LEN);

    /* Encode descriptor value flags - reserved for future use */
    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->flags);
    pos += 2;

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->sampling_function);
    pos += 1;

    BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], &p_app_value->measurement_period);
    pos += 3;

    BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], &p_app_value->update_interval);
    pos += 3;

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->application);
    pos += 1;

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->measurement_uncertainty);
    pos += 1;

    /* update length*/
    p_gatt_value->value_len = BLE_ESC_ELEVATION_0_ES_MEAS_LEN;

    return BLE_SUCCESS;
}

static const st_ble_servc_desc_info_t gs_elevation_0_es_meas ={
    .uuid_16     = BLE_ESC_ELEVATION_0_ES_MEAS_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(st_ble_esc_elevation_0_es_meas_t),
    .db_size     = BLE_ESC_ELEVATION_0_ES_MEAS_LEN,
    .desc_idx    = BLE_ESC_ELEVATION_0_ES_MEAS_IDX,
    .p_attr_hdls = gs_elevation_0_es_meas_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_st_ble_esc_elevation_0_es_meas_t,
    .encode      = (ble_servc_attr_encode_t)encode_st_ble_esc_elevation_0_es_meas_t,
};

ble_status_t R_BLE_ESC_ReadElevation0EsMeas(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_elevation_0_es_meas, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Elevation 0 Characteristic Extended Properties descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Elevation 0 characteristic descriptors attribute handles */
static uint16_t gs_elevation_0_char_extended_properties_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_elevation_0_char_extended_properties ={
    .uuid_16     = BLE_ESC_ELEVATION_0_CHAR_EXTENDED_PROPERTIES_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint16_t),
    .db_size     = BLE_ESC_ELEVATION_0_CHAR_EXTENDED_PROPERTIES_LEN,
    .desc_idx    = BLE_ESC_ELEVATION_0_CHAR_EXTENDED_PROPERTIES_IDX,
    .p_attr_hdls = gs_elevation_0_char_extended_properties_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_ESC_ReadElevation0CharExtendedProperties(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_elevation_0_char_extended_properties, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Elevation 0 Environmental Sensing Trigger Setting 0 descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Elevation 0 characteristic descriptors attribute handles */
static uint16_t gs_elevation_0_es_trigger_0_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************
 * Function Name: decode_st_ble_esc_elevation_0_es_trigger_0_t
 * Description  : This function converts Elevation descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - Pointer to the Elevation value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_esc_elevation_0_es_trigger_0_t(st_ble_esc_elevation_0_es_trigger_0_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    /* Check the length */
    if (BLE_ESC_ELEVATION_0_ES_TRIGGER_0_LEN < p_gatt_value->value_len)
    {
        return BLE_ESC_WRITE_REQUEST_REJECTED_ERROR;
    }

    /* Copy the condition byte */
    uint8_t condition = p_gatt_value->p_value[pos];

    memset(p_app_value, 0x00, sizeof(st_ble_esc_elevation_0_es_trigger_0_t));

    p_app_value->condition = condition;
    pos += 1;

    if ((BLE_ESC_ELEVATION_0_ES_TRIGGER_0_CONDITION_USE_A_FIXED_TIME_INTERVAL_BETWEEN_TRANSMISSIONS == 
        p_app_value->condition)
        || ((BLE_ESC_ELEVATION_0_ES_TRIGGER_0_CONDITION_NO_LESS_THAN_THE_SPECIFIED_TIME_BETWEEN_TRANSMISSIONS == 
            p_app_value->condition)))
    {
        /* Copy operand bytes (3) */
        BT_UNPACK_LE_3_BYTE(p_app_value->operand, &p_gatt_value->p_value[pos]);
    }
    else if ((p_app_value->condition <= BLE_ESC_ELEVATION_0_ES_TRIGGER_0_CONDITION_WHILE_NOT_EQUAL_TO_THE_SPECIFIED_VALUE)
        && (p_app_value->condition >= BLE_ESC_ELEVATION_0_ES_TRIGGER_0_CONDITION_WHILE_LESS_THAN_THE_SPECIFIED_VALUE))
    {
        /* Copy operand bytes (3) */
        BT_UNPACK_LE_3_BYTE(p_app_value->operand, &p_gatt_value->p_value[pos]);
    }
    else if (BLE_ESC_ELEVATION_0_ES_TRIGGER_0_CONDITION_WHILE_NOT_EQUAL_TO_THE_SPECIFIED_VALUE < p_app_value->condition)
    {
        /* Tolerate the RFU value, Set to TRIGGER_SETTING_TRIGGER_INACTIVE */
        p_app_value->condition = BLE_ESC_ELEVATION_0_ES_TRIGGER_0_CONDITION_TRIGGER_INACTIVE;
    }
    else //other cases
    {
        /* Do Nothing */
    }

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_st_ble_esc_elevation_0_es_trigger_0_t
 * Description  : This function converts Elevation characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value  - Pointer to the Elevation value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_esc_elevation_0_es_trigger_0_t(const st_ble_esc_elevation_0_es_trigger_0_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_ESC_ELEVATION_0_ES_TRIGGER_0_LEN);

    /* Copy the condition byte */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->condition);
    pos += 1;

    if ((BLE_ESC_ELEVATION_0_ES_TRIGGER_0_CONDITION_USE_A_FIXED_TIME_INTERVAL_BETWEEN_TRANSMISSIONS == 
        p_app_value->condition)
        || (BLE_ESC_ELEVATION_0_ES_TRIGGER_0_CONDITION_NO_LESS_THAN_THE_SPECIFIED_TIME_BETWEEN_TRANSMISSIONS == 
            p_app_value->condition))
    {
        /* Convert operand (24 bits) to byte sequence */
        BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], p_app_value->operand);
        pos += 3;
    }
    else if ((BLE_ESC_ELEVATION_0_ES_TRIGGER_0_CONDITION_TRIGGER_INACTIVE == p_app_value->condition) ||
        (BLE_ESC_ELEVATION_0_ES_TRIGGER_0_CONDITION_WHEN_VALUE_CHANGES_COMPARED_TO_PREVIOUS_VALUE == 
            p_app_value->condition))
    {
        /* Do Nothing */
    }
    else
    {
        /* Convert operand (24 bits) to byte sequence */
        BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], p_app_value->operand);
        pos += 3;
    }

    /* Update length */
    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

static const st_ble_servc_desc_info_t gs_elevation_0_es_trigger_0 ={
    .uuid_16     = BLE_ESC_ELEVATION_0_ES_TRIGGER_0_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(st_ble_esc_elevation_0_es_trigger_0_t),
    .db_size     = BLE_ESC_ELEVATION_0_ES_TRIGGER_0_LEN,
    .desc_idx    = BLE_ESC_ELEVATION_0_ES_TRIGGER_0_IDX,
    .p_attr_hdls = gs_elevation_0_es_trigger_0_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_st_ble_esc_elevation_0_es_trigger_0_t,
    .encode      = (ble_servc_attr_encode_t)encode_st_ble_esc_elevation_0_es_trigger_0_t,
};

ble_status_t R_BLE_ESC_WriteElevation0EsTrigger0(uint16_t conn_hdl, const st_ble_esc_elevation_0_es_trigger_0_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_elevation_0_es_trigger_0, conn_hdl, p_value);
}

ble_status_t R_BLE_ESC_ReadElevation0EsTrigger0(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_elevation_0_es_trigger_0, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Elevation 0 Environmental Sensing Trigger Setting 1 descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Elevation 0 characteristic descriptors attribute handles */
static uint16_t gs_elevation_0_es_trigger_1_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************
 * Function Name: decode_st_ble_esc_elevation_0_es_trigger_1_t
 * Description  : This function converts Elevation descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - Pointer to the Elevation value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_esc_elevation_0_es_trigger_1_t(st_ble_esc_elevation_0_es_trigger_1_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    /* Check the length */
    if (BLE_ESC_ELEVATION_0_ES_TRIGGER_1_LEN < p_gatt_value->value_len)
    {
        return BLE_ESC_WRITE_REQUEST_REJECTED_ERROR;
    }

    /* Copy the condition byte */
    uint8_t condition = p_gatt_value->p_value[pos];

    memset(p_app_value, 0x00, sizeof(st_ble_esc_elevation_0_es_trigger_1_t));

    p_app_value->condition = condition;
    pos += 1;

    if ((BLE_ESC_ELEVATION_0_ES_TRIGGER_0_CONDITION_USE_A_FIXED_TIME_INTERVAL_BETWEEN_TRANSMISSIONS == 
        p_app_value->condition)
        || ((BLE_ESC_ELEVATION_0_ES_TRIGGER_0_CONDITION_NO_LESS_THAN_THE_SPECIFIED_TIME_BETWEEN_TRANSMISSIONS == 
            p_app_value->condition)))
    {
        /* Copy operand bytes (3) */
        BT_UNPACK_LE_3_BYTE(p_app_value->operand, &p_gatt_value->p_value[pos]);
    }
    else if ((p_app_value->condition <= BLE_ESC_ELEVATION_0_ES_TRIGGER_0_CONDITION_WHILE_NOT_EQUAL_TO_THE_SPECIFIED_VALUE)
        && (p_app_value->condition >= BLE_ESC_ELEVATION_0_ES_TRIGGER_0_CONDITION_WHILE_LESS_THAN_THE_SPECIFIED_VALUE))
    {
        /* Copy operand bytes (3) */
        BT_UNPACK_LE_3_BYTE(p_app_value->operand, &p_gatt_value->p_value[pos]);
    }
    else if (BLE_ESC_ELEVATION_0_ES_TRIGGER_0_CONDITION_WHILE_NOT_EQUAL_TO_THE_SPECIFIED_VALUE < p_app_value->condition)
    {
        /* Tolerate the RFU value, Set to TRIGGER_SETTING_TRIGGER_INACTIVE */
        p_app_value->condition = BLE_ESC_ELEVATION_0_ES_TRIGGER_0_CONDITION_TRIGGER_INACTIVE;
    }
    else //other cases
    {
        /* Do Nothing */
    }

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_st_ble_esc_elevation_0_es_trigger_1_t
 * Description  : This function converts Elevation characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value  - Pointer to the Elevation value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_esc_elevation_0_es_trigger_1_t(const st_ble_esc_elevation_0_es_trigger_1_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_ESC_ELEVATION_0_ES_TRIGGER_1_LEN);

    /* Copy the condition byte */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->condition);
    pos += 1;

    if ((BLE_ESC_ELEVATION_0_ES_TRIGGER_0_CONDITION_USE_A_FIXED_TIME_INTERVAL_BETWEEN_TRANSMISSIONS ==
        p_app_value->condition)
        || (BLE_ESC_ELEVATION_0_ES_TRIGGER_0_CONDITION_NO_LESS_THAN_THE_SPECIFIED_TIME_BETWEEN_TRANSMISSIONS ==
            p_app_value->condition))
    {
        /* Convert operand (24 bits) to byte sequence */
        BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], p_app_value->operand);
        pos += 3;
    }
    else if ((BLE_ESC_ELEVATION_0_ES_TRIGGER_0_CONDITION_TRIGGER_INACTIVE == p_app_value->condition) ||
        (BLE_ESC_ELEVATION_0_ES_TRIGGER_0_CONDITION_WHEN_VALUE_CHANGES_COMPARED_TO_PREVIOUS_VALUE ==
            p_app_value->condition))
    {
        /* Do Nothing */
    }
    else
    {
        /* Convert operand (24 bits) to byte sequence */
        BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], p_app_value->operand);
        pos += 3;
    }

    /* Update length */
    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

static const st_ble_servc_desc_info_t gs_elevation_0_es_trigger_1 ={
    .uuid_16     = BLE_ESC_ELEVATION_0_ES_TRIGGER_1_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(st_ble_esc_elevation_0_es_trigger_1_t),
    .db_size     = BLE_ESC_ELEVATION_0_ES_TRIGGER_1_LEN,
    .desc_idx    = BLE_ESC_ELEVATION_0_ES_TRIGGER_1_IDX,
    .p_attr_hdls = gs_elevation_0_es_trigger_1_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_st_ble_esc_elevation_0_es_trigger_1_t,
    .encode      = (ble_servc_attr_encode_t)encode_st_ble_esc_elevation_0_es_trigger_1_t,
};

ble_status_t R_BLE_ESC_WriteElevation0EsTrigger1(uint16_t conn_hdl, const st_ble_esc_elevation_0_es_trigger_1_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_elevation_0_es_trigger_1, conn_hdl, p_value);
}

ble_status_t R_BLE_ESC_ReadElevation0EsTrigger1(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_elevation_0_es_trigger_1, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Elevation 0 Environmental Sensing Trigger Setting 2 descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Elevation 0 characteristic descriptors attribute handles */
static uint16_t gs_elevation_0_es_trigger_2_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************
 * Function Name: decode_st_ble_esc_elevation_0_es_trigger_2_t
 * Description  : This function converts Elevation descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - Pointer to the Elevation value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_esc_elevation_0_es_trigger_2_t(st_ble_esc_elevation_0_es_trigger_2_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    /* Check the length */
    if (BLE_ESC_ELEVATION_0_ES_TRIGGER_2_LEN < p_gatt_value->value_len)
    {
        return BLE_ESC_WRITE_REQUEST_REJECTED_ERROR;
    }

    /* Copy the condition byte */
    uint8_t condition = p_gatt_value->p_value[pos];

    memset(p_app_value, 0x00, sizeof(st_ble_esc_elevation_0_es_trigger_2_t));

    p_app_value->condition = condition;
    pos += 1;

    if ((BLE_ESC_ELEVATION_0_ES_TRIGGER_0_CONDITION_USE_A_FIXED_TIME_INTERVAL_BETWEEN_TRANSMISSIONS == 
        p_app_value->condition)
        || ((BLE_ESC_ELEVATION_0_ES_TRIGGER_0_CONDITION_NO_LESS_THAN_THE_SPECIFIED_TIME_BETWEEN_TRANSMISSIONS == 
            p_app_value->condition)))
    {
        /* Copy operand bytes (3) */
        BT_UNPACK_LE_3_BYTE(p_app_value->operand, &p_gatt_value->p_value[pos]);
    }
    else if ((p_app_value->condition <= BLE_ESC_ELEVATION_0_ES_TRIGGER_0_CONDITION_WHILE_NOT_EQUAL_TO_THE_SPECIFIED_VALUE)
        && (p_app_value->condition >= BLE_ESC_ELEVATION_0_ES_TRIGGER_0_CONDITION_WHILE_LESS_THAN_THE_SPECIFIED_VALUE))
    {
        /* Copy operand bytes (3) */
        BT_UNPACK_LE_3_BYTE(p_app_value->operand, &p_gatt_value->p_value[pos]);
    }
    else if (BLE_ESC_ELEVATION_0_ES_TRIGGER_0_CONDITION_WHILE_NOT_EQUAL_TO_THE_SPECIFIED_VALUE < p_app_value->condition)
    {
        /* Tolerate the RFU value, Set to TRIGGER_SETTING_TRIGGER_INACTIVE */
        p_app_value->condition = BLE_ESC_ELEVATION_0_ES_TRIGGER_0_CONDITION_TRIGGER_INACTIVE;
    }
    else //other cases
    {
        /* Do Nothing */
    }

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_st_ble_esc_elevation_0_es_trigger_2_t
 * Description  : This function converts Elevation characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value  - Pointer to the Elevation value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_esc_elevation_0_es_trigger_2_t(const st_ble_esc_elevation_0_es_trigger_2_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_ESC_ELEVATION_0_ES_TRIGGER_2_LEN);

    /* Copy the condition byte */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->condition);
    pos += 1;

    if ((BLE_ESC_ELEVATION_0_ES_TRIGGER_0_CONDITION_USE_A_FIXED_TIME_INTERVAL_BETWEEN_TRANSMISSIONS ==
        p_app_value->condition)
        || (BLE_ESC_ELEVATION_0_ES_TRIGGER_0_CONDITION_NO_LESS_THAN_THE_SPECIFIED_TIME_BETWEEN_TRANSMISSIONS ==
            p_app_value->condition))
    {
        /* Convert operand (24 bits) to byte sequence */
        BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], p_app_value->operand);
        pos += 3;
    }
    else if ((BLE_ESC_ELEVATION_0_ES_TRIGGER_0_CONDITION_TRIGGER_INACTIVE == p_app_value->condition) ||
        (BLE_ESC_ELEVATION_0_ES_TRIGGER_0_CONDITION_WHEN_VALUE_CHANGES_COMPARED_TO_PREVIOUS_VALUE ==
            p_app_value->condition))
    {
        /* Do Nothing */
    }
    else
    {
        /* Convert operand (24 bits) to byte sequence */
        BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], p_app_value->operand);
        pos += 3;
    }

    /* Update length */
    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

static const st_ble_servc_desc_info_t gs_elevation_0_es_trigger_2 ={
    .uuid_16     = BLE_ESC_ELEVATION_0_ES_TRIGGER_2_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(st_ble_esc_elevation_0_es_trigger_2_t),
    .db_size     = BLE_ESC_ELEVATION_0_ES_TRIGGER_2_LEN,
    .desc_idx    = BLE_ESC_ELEVATION_0_ES_TRIGGER_2_IDX,
    .p_attr_hdls = gs_elevation_0_es_trigger_2_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_st_ble_esc_elevation_0_es_trigger_2_t,
    .encode      = (ble_servc_attr_encode_t)encode_st_ble_esc_elevation_0_es_trigger_2_t,
};

ble_status_t R_BLE_ESC_WriteElevation0EsTrigger2(uint16_t conn_hdl, const st_ble_esc_elevation_0_es_trigger_2_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_elevation_0_es_trigger_2, conn_hdl, p_value);
}

ble_status_t R_BLE_ESC_ReadElevation0EsTrigger2(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_elevation_0_es_trigger_2, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Elevation 0 Environmental Sensing Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Elevation 0 characteristic descriptors attribute handles */
static uint16_t gs_elevation_0_es_conf_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_elevation_0_es_conf ={
    .uuid_16     = BLE_ESC_ELEVATION_0_ES_CONF_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint8_t),
    .db_size     = BLE_ESC_ELEVATION_0_ES_CONF_LEN,
    .desc_idx    = BLE_ESC_ELEVATION_0_ES_CONF_IDX,
    .p_attr_hdls = gs_elevation_0_es_conf_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint8_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint8_t,
};

ble_status_t R_BLE_ESC_WriteElevation0EsConf(uint16_t conn_hdl, const uint8_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_elevation_0_es_conf, conn_hdl, p_value);
}

ble_status_t R_BLE_ESC_ReadElevation0EsConf(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_elevation_0_es_conf, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Elevation 0 Characteristic User Description descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Elevation 0 characteristic descriptors attribute handles */
static uint16_t gs_elevation_0_char_user_desc_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************
 * Function Name: decode_st_ble_esc_elevation_0_char_user_desc_t
 * Description  : This function converts Elevation descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - Pointer to the Elevation value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_esc_elevation_0_char_user_desc_t(st_ble_esc_elevation_0_char_user_desc_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    /* Check for length */
    if (BLE_ESC_ELEVATION_0_CHAR_USER_DESC_LEN < p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    memset(&p_app_value->user_description[0], 0x00, 98);
    memcpy(&p_app_value->user_description[0], p_gatt_value->p_value, 98);

    BT_UNPACK_LE_2_BYTE(&p_app_value->length, (uint8_t *)&p_gatt_value->value_len);

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_st_ble_esc_elevation_0_char_user_desc_t
 * Description  : This function converts Elevation characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value  - Pointer to the Elevation value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_esc_elevation_0_char_user_desc_t(const st_ble_esc_elevation_0_char_user_desc_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_ESC_ELEVATION_0_CHAR_USER_DESC_LEN);

    memcpy(&p_gatt_value->p_value[0], &p_app_value->user_description[0] , p_app_value->length);
    pos += p_app_value->length;

    /* Update length */
    p_gatt_value->value_len = p_app_value->length;

    return BLE_SUCCESS;
}

static const st_ble_servc_desc_info_t gs_elevation_0_char_user_desc ={
    .uuid_16     = BLE_ESC_ELEVATION_0_CHAR_USER_DESC_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(st_ble_esc_elevation_0_char_user_desc_t),
    .db_size     = BLE_ESC_ELEVATION_0_CHAR_USER_DESC_LEN,
    .desc_idx    = BLE_ESC_ELEVATION_0_CHAR_USER_DESC_IDX,
    .p_attr_hdls = gs_elevation_0_char_user_desc_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_st_ble_esc_elevation_0_char_user_desc_t,
    .encode      = (ble_servc_attr_encode_t)encode_st_ble_esc_elevation_0_char_user_desc_t,
};

ble_status_t R_BLE_ESC_WriteElevation0CharUserDesc(uint16_t conn_hdl, const st_ble_esc_elevation_0_char_user_desc_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc2(&gs_elevation_0_char_user_desc, conn_hdl, p_value);
}

ble_status_t R_BLE_ESC_ReadElevation0CharUserDesc(uint16_t conn_hdl, int32_t type) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc_with_Type(&gs_elevation_0_char_user_desc, conn_hdl, type);
}

/*----------------------------------------------------------------------------------------------------------------------
    Elevation 0 Valid Range descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Elevation 0 characteristic descriptors attribute handles */
static uint16_t gs_elevation_0_valid_range_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************
 * Function Name: decode_st_ble_esc_elevation_0_valid_range_t
 * Description  : This function converts Elevation descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - Pointer to the Elevation value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_esc_elevation_0_valid_range_t(st_ble_esc_elevation_0_valid_range_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    /* Check for length */
    if (BLE_ESC_ELEVATION_0_VALID_RANGE_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    memset(p_app_value, 0x00, sizeof(st_ble_esc_elevation_0_valid_range_t));

    /* Copy the lower inclusive bytes */
    BT_UNPACK_LE_3_BYTE(&p_app_value->lower_inclusive_value, &p_gatt_value->p_value[pos]);
    pos += 3;

    /* Copy the upper inclusive bytes */
    BT_UNPACK_LE_3_BYTE(&p_app_value->upper_inclusive_value, &p_gatt_value->p_value[pos]);

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_st_ble_esc_elevation_0_valid_range_t
 * Description  : This function converts Elevation characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value  - Pointer to the Elevation  value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_esc_elevation_0_valid_range_t(const st_ble_esc_elevation_0_valid_range_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_ESC_ELEVATION_0_VALID_RANGE_LEN);

    BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], &p_app_value->lower_inclusive_value);
    pos += 3;

    BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], &p_app_value->upper_inclusive_value);

    /* Update length */
    p_gatt_value->value_len = BLE_ESC_ELEVATION_0_VALID_RANGE_LEN;

    return BLE_SUCCESS;
}

static const st_ble_servc_desc_info_t gs_elevation_0_valid_range ={
    .uuid_16     = BLE_ESC_ELEVATION_0_VALID_RANGE_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(st_ble_esc_elevation_0_valid_range_t),
    .db_size     = BLE_ESC_ELEVATION_0_VALID_RANGE_LEN,
    .desc_idx    = BLE_ESC_ELEVATION_0_VALID_RANGE_IDX,
    .p_attr_hdls = gs_elevation_0_valid_range_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_st_ble_esc_elevation_0_valid_range_t,
    .encode      = (ble_servc_attr_encode_t)encode_st_ble_esc_elevation_0_valid_range_t,
};

ble_status_t R_BLE_ESC_ReadElevation0ValidRange(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_elevation_0_valid_range, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Elevation 0 Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Elevation 0 characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_elevation_0_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

/* Elevation 0 characteristic descriptor definition */
static const st_ble_servc_desc_info_t *gspp_elevation_0_descs[] = {
    &gs_elevation_0_cli_cnfg,
    &gs_elevation_0_es_meas,
    &gs_elevation_0_char_extended_properties,
    &gs_elevation_0_es_trigger_0,
    &gs_elevation_0_es_trigger_1,
    &gs_elevation_0_es_trigger_2,
    &gs_elevation_0_es_conf,
    &gs_elevation_0_char_user_desc,
    &gs_elevation_0_valid_range,
};

/* Elevation 0 characteristic definition */
const st_ble_servc_char_info_t gs_elevation_0_char = {
    .uuid_16      = BLE_ESC_ELEVATION_0_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(int32_t),
    .db_size      = BLE_ESC_ELEVATION_0_LEN,
    .char_idx     = BLE_ESC_ELEVATION_0_IDX,
    .p_attr_hdls  = gs_elevation_0_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_24bit,
    .encode       = (ble_servc_attr_encode_t)encode_24bit,
    .num_of_descs = ARRAY_SIZE(gspp_elevation_0_descs),
    .pp_descs     = gspp_elevation_0_descs,
};

ble_status_t R_BLE_ESC_ReadElevation0(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_elevation_0_char, conn_hdl);
}

void R_BLE_ESC_GetElevation0AttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_esc_elevation_0_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_elevation_0_char_ranges[conn_idx];
    p_hdl->cli_cnfg_desc_hdl = gs_elevation_0_cli_cnfg_desc_hdls[conn_idx];
    p_hdl->es_meas_desc_hdl = gs_elevation_0_es_meas_desc_hdls[conn_idx];
    p_hdl->char_extended_properties_desc_hdl = gs_elevation_0_char_extended_properties_desc_hdls[conn_idx];
    p_hdl->es_trigger_0_desc_hdl = gs_elevation_0_es_trigger_0_desc_hdls[conn_idx];
    p_hdl->es_trigger_1_desc_hdl = gs_elevation_0_es_trigger_1_desc_hdls[conn_idx];
    p_hdl->es_trigger_2_desc_hdl = gs_elevation_0_es_trigger_2_desc_hdls[conn_idx];
    p_hdl->es_conf_desc_hdl = gs_elevation_0_es_conf_desc_hdls[conn_idx];
    p_hdl->char_user_desc_desc_hdl = gs_elevation_0_char_user_desc_desc_hdls[conn_idx];
    p_hdl->valid_range_desc_hdl = gs_elevation_0_valid_range_desc_hdls[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Elevation 1 Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Elevation 1 characteristic descriptors attribute handles */
static uint16_t gs_elevation_1_cli_cnfg_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_elevation_1_cli_cnfg ={
    .uuid_16     = BLE_ESC_ELEVATION_1_CLI_CNFG_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint16_t),
    .db_size     = BLE_ESC_ELEVATION_1_CLI_CNFG_LEN,
    .desc_idx    = BLE_ESC_ELEVATION_1_CLI_CNFG_IDX,
    .p_attr_hdls = gs_elevation_1_cli_cnfg_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_ESC_WriteElevation1CliCnfg(uint16_t conn_hdl, const uint16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_elevation_1_cli_cnfg, conn_hdl, p_value);
}

ble_status_t R_BLE_ESC_ReadElevation1CliCnfg(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_elevation_1_cli_cnfg, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Elevation 1 Environmental Sensing Measurement descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Elevation 1 characteristic descriptors attribute handles */
static uint16_t gs_elevation_1_es_meas_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************
 * Function Name: decode_st_ble_esc_elevation_1_es_meas_t
 * Description  : This function converts Elevation descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - Pointer to the Elevation value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_esc_elevation_1_es_meas_t(st_ble_esc_elevation_1_es_meas_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    /* check the length */
    if (BLE_ESC_ELEVATION_1_ES_MEAS_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    memset(p_app_value, 0x00, sizeof(st_ble_esc_elevation_1_es_meas_t));

    /* Copy the flag */
    BT_UNPACK_LE_2_BYTE(&p_app_value->flags, &p_gatt_value->p_value[pos]);
    pos += 2;

    BT_UNPACK_LE_1_BYTE(&p_app_value->sampling_function, &p_gatt_value->p_value[pos]);
    pos += 1;

    BT_UNPACK_LE_3_BYTE(&p_app_value->measurement_period, &p_gatt_value->p_value[pos]);
    pos += 3;

    BT_UNPACK_LE_3_BYTE(&p_app_value->update_interval, &p_gatt_value->p_value[pos]);
    pos += 3;

    BT_UNPACK_LE_1_BYTE(&p_app_value->application, &p_gatt_value->p_value[pos]);
    pos += 1;

    BT_UNPACK_LE_1_BYTE(&p_app_value->measurement_uncertainty, &p_gatt_value->p_value[pos]);

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_st_ble_esc_elevation_1_es_meas_t
 * Description  : This function converts Elevation characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value  - Pointer to the Elevation value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_esc_elevation_1_es_meas_t(const st_ble_esc_elevation_1_es_meas_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_ESC_ELEVATION_1_ES_MEAS_LEN);

    /* Encode descriptor value flags - reserved for future use */
    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->flags);
    pos += 2;

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->sampling_function);
    pos += 1;

    BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], &p_app_value->measurement_period);
    pos += 3;

    BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], &p_app_value->update_interval);
    pos += 3;

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->application);
    pos += 1;

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->measurement_uncertainty);
    pos += 1;

    /* update length*/
    p_gatt_value->value_len = BLE_ESC_ELEVATION_1_ES_MEAS_LEN;

    return BLE_SUCCESS;
}

static const st_ble_servc_desc_info_t gs_elevation_1_es_meas ={
    .uuid_16     = BLE_ESC_ELEVATION_1_ES_MEAS_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(st_ble_esc_elevation_1_es_meas_t),
    .db_size     = BLE_ESC_ELEVATION_1_ES_MEAS_LEN,
    .desc_idx    = BLE_ESC_ELEVATION_1_ES_MEAS_IDX,
    .p_attr_hdls = gs_elevation_1_es_meas_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_st_ble_esc_elevation_1_es_meas_t,
    .encode      = (ble_servc_attr_encode_t)encode_st_ble_esc_elevation_1_es_meas_t,
};

ble_status_t R_BLE_ESC_ReadElevation1EsMeas(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_elevation_1_es_meas, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Elevation 1 Characteristic Extended Properties descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Elevation 1 characteristic descriptors attribute handles */
static uint16_t gs_elevation_1_char_extended_properties_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_elevation_1_char_extended_properties ={
    .uuid_16     = BLE_ESC_ELEVATION_1_CHAR_EXTENDED_PROPERTIES_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint16_t),
    .db_size     = BLE_ESC_ELEVATION_1_CHAR_EXTENDED_PROPERTIES_LEN,
    .desc_idx    = BLE_ESC_ELEVATION_1_CHAR_EXTENDED_PROPERTIES_IDX,
    .p_attr_hdls = gs_elevation_1_char_extended_properties_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_ESC_ReadElevation1CharExtendedProperties(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_elevation_1_char_extended_properties, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Elevation 1 Environmental Sensing Trigger Setting 0 descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Elevation 1 characteristic descriptors attribute handles */
static uint16_t gs_elevation_1_es_trigger_0_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************
 * Function Name: decode_st_ble_esc_elevation_1_es_trigger_0_t
 * Description  : This function converts Elevation descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - Pointer to the Elevation value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_esc_elevation_1_es_trigger_0_t(st_ble_esc_elevation_1_es_trigger_0_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    /* Check the length */
    if (BLE_ESC_ELEVATION_1_ES_TRIGGER_0_LEN < p_gatt_value->value_len)
    {
        return BLE_ESC_WRITE_REQUEST_REJECTED_ERROR;
    }

    /* Copy the condition byte */
    uint8_t condition = p_gatt_value->p_value[pos];

    memset(p_app_value, 0x00, sizeof(st_ble_esc_elevation_1_es_trigger_0_t));

    p_app_value->condition = condition;
    pos += 1;

    if ((BLE_ESC_ELEVATION_1_ES_TRIGGER_0_CONDITION_USE_A_FIXED_TIME_INTERVAL_BETWEEN_TRANSMISSIONS == 
        p_app_value->condition)
        || ((BLE_ESC_ELEVATION_1_ES_TRIGGER_0_CONDITION_NO_LESS_THAN_THE_SPECIFIED_TIME_BETWEEN_TRANSMISSIONS == 
            p_app_value->condition)))
    {
        /* Copy operand bytes (3) */
        BT_UNPACK_LE_3_BYTE(p_app_value->operand, &p_gatt_value->p_value[pos]);
    }
    else if ((p_app_value->condition <= BLE_ESC_ELEVATION_1_ES_TRIGGER_0_CONDITION_WHILE_NOT_EQUAL_TO_THE_SPECIFIED_VALUE)
        && (p_app_value->condition >= BLE_ESC_ELEVATION_1_ES_TRIGGER_0_CONDITION_WHILE_LESS_THAN_THE_SPECIFIED_VALUE))
    {
        /* Copy operand bytes (3) */
        BT_UNPACK_LE_3_BYTE(p_app_value->operand, &p_gatt_value->p_value[pos]);
    }
    else if (BLE_ESC_ELEVATION_1_ES_TRIGGER_0_CONDITION_WHILE_NOT_EQUAL_TO_THE_SPECIFIED_VALUE < p_app_value->condition)
    {
        /* Tolerate the RFU value, Set to TRIGGER_SETTING_TRIGGER_INACTIVE */
        p_app_value->condition = BLE_ESC_ELEVATION_1_ES_TRIGGER_0_CONDITION_TRIGGER_INACTIVE;
    }
    else //other cases
    {
        /* Do Nothing */
    }

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_st_ble_esc_elevation_1_es_trigger_0_t
 * Description  : This function converts Elevation characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value  - Pointer to the Elevation value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_esc_elevation_1_es_trigger_0_t(const st_ble_esc_elevation_1_es_trigger_0_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_ESC_ELEVATION_1_ES_TRIGGER_0_LEN);

    /* Copy the condition byte */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->condition);
    pos += 1;

    if ((BLE_ESC_ELEVATION_1_ES_TRIGGER_0_CONDITION_USE_A_FIXED_TIME_INTERVAL_BETWEEN_TRANSMISSIONS ==
        p_app_value->condition)
        || (BLE_ESC_ELEVATION_1_ES_TRIGGER_0_CONDITION_NO_LESS_THAN_THE_SPECIFIED_TIME_BETWEEN_TRANSMISSIONS ==
            p_app_value->condition))
    {
        /* Convert operand (24 bits) to byte sequence */
        BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], p_app_value->operand);
        pos += 3;
    }
    else if ((BLE_ESC_ELEVATION_1_ES_TRIGGER_0_CONDITION_TRIGGER_INACTIVE == p_app_value->condition) ||
        (BLE_ESC_ELEVATION_1_ES_TRIGGER_0_CONDITION_WHEN_VALUE_CHANGES_COMPARED_TO_PREVIOUS_VALUE ==
            p_app_value->condition))
    {
        /* Do Nothing */
    }
    else
    {
        /* Convert operand (24 bits) to byte sequence */
        BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], p_app_value->operand);
        pos += 3;
    }

    /* Update length */
    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

static const st_ble_servc_desc_info_t gs_elevation_1_es_trigger_0 ={
    .uuid_16     = BLE_ESC_ELEVATION_1_ES_TRIGGER_0_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(st_ble_esc_elevation_1_es_trigger_0_t),
    .db_size     = BLE_ESC_ELEVATION_1_ES_TRIGGER_0_LEN,
    .desc_idx    = BLE_ESC_ELEVATION_1_ES_TRIGGER_0_IDX,
    .p_attr_hdls = gs_elevation_1_es_trigger_0_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_st_ble_esc_elevation_1_es_trigger_0_t,
    .encode      = (ble_servc_attr_encode_t)encode_st_ble_esc_elevation_1_es_trigger_0_t,
};

ble_status_t R_BLE_ESC_WriteElevation1EsTrigger0(uint16_t conn_hdl, const st_ble_esc_elevation_1_es_trigger_0_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_elevation_1_es_trigger_0, conn_hdl, p_value);
}

ble_status_t R_BLE_ESC_ReadElevation1EsTrigger0(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_elevation_1_es_trigger_0, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Elevation 1 Environmental Sensing Trigger Setting 1 descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Elevation 1 characteristic descriptors attribute handles */
static uint16_t gs_elevation_1_es_trigger_1_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************
 * Function Name: decode_st_ble_esc_elevation_1_es_trigger_1_t
 * Description  : This function converts Elevation descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - Pointer to the Elevation value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_esc_elevation_1_es_trigger_1_t(st_ble_esc_elevation_1_es_trigger_1_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    /* Check the length */
    if (BLE_ESC_ELEVATION_1_ES_TRIGGER_1_LEN < p_gatt_value->value_len)
    {
        return BLE_ESC_WRITE_REQUEST_REJECTED_ERROR;
    }

    /* Copy the condition byte */
    uint8_t condition = p_gatt_value->p_value[pos];

    memset(p_app_value, 0x00, sizeof(st_ble_esc_elevation_1_es_trigger_1_t));

    p_app_value->condition = condition;
    pos += 1;

    if ((BLE_ESC_ELEVATION_1_ES_TRIGGER_0_CONDITION_USE_A_FIXED_TIME_INTERVAL_BETWEEN_TRANSMISSIONS == 
        p_app_value->condition)
        || ((BLE_ESC_ELEVATION_1_ES_TRIGGER_0_CONDITION_NO_LESS_THAN_THE_SPECIFIED_TIME_BETWEEN_TRANSMISSIONS == 
            p_app_value->condition)))
    {
        /* Copy operand bytes (3) */
        BT_UNPACK_LE_3_BYTE(p_app_value->operand, &p_gatt_value->p_value[pos]);
    }
    else if ((p_app_value->condition <= BLE_ESC_ELEVATION_1_ES_TRIGGER_0_CONDITION_WHILE_NOT_EQUAL_TO_THE_SPECIFIED_VALUE)
        && (p_app_value->condition >= BLE_ESC_ELEVATION_1_ES_TRIGGER_0_CONDITION_WHILE_LESS_THAN_THE_SPECIFIED_VALUE))
    {
        /* Copy operand bytes (3) */
        BT_UNPACK_LE_3_BYTE(p_app_value->operand, &p_gatt_value->p_value[pos]);
    }
    else if (BLE_ESC_ELEVATION_1_ES_TRIGGER_0_CONDITION_WHILE_NOT_EQUAL_TO_THE_SPECIFIED_VALUE < p_app_value->condition)
    {
        /* Tolerate the RFU value, Set to TRIGGER_SETTING_TRIGGER_INACTIVE */
        p_app_value->condition = BLE_ESC_ELEVATION_1_ES_TRIGGER_0_CONDITION_TRIGGER_INACTIVE;
    }
    else //other cases
    {
        /* Do Nothing */
    }

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_st_ble_esc_elevation_1_es_trigger_1_t
 * Description  : This function converts Elevation characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value  - Pointer to the Elevation value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_esc_elevation_1_es_trigger_1_t(const st_ble_esc_elevation_1_es_trigger_1_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_ESC_ELEVATION_1_ES_TRIGGER_1_LEN);

    /* Copy the condition byte */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->condition);
    pos += 1;

    if ((BLE_ESC_ELEVATION_1_ES_TRIGGER_0_CONDITION_USE_A_FIXED_TIME_INTERVAL_BETWEEN_TRANSMISSIONS ==
        p_app_value->condition)
        || (BLE_ESC_ELEVATION_1_ES_TRIGGER_0_CONDITION_NO_LESS_THAN_THE_SPECIFIED_TIME_BETWEEN_TRANSMISSIONS ==
            p_app_value->condition))
    {
        /* Convert operand (24 bits) to byte sequence */
        BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], p_app_value->operand);
        pos += 3;
    }
    else if ((BLE_ESC_ELEVATION_1_ES_TRIGGER_0_CONDITION_TRIGGER_INACTIVE == p_app_value->condition) ||
        (BLE_ESC_ELEVATION_1_ES_TRIGGER_0_CONDITION_WHEN_VALUE_CHANGES_COMPARED_TO_PREVIOUS_VALUE ==
            p_app_value->condition))
    {
        /* Do Nothing */
    }
    else
    {
        /* Convert operand (24 bits) to byte sequence */
        BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], p_app_value->operand);
        pos += 3;
    }

    /* Update length */
    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

static const st_ble_servc_desc_info_t gs_elevation_1_es_trigger_1 ={
    .uuid_16     = BLE_ESC_ELEVATION_1_ES_TRIGGER_1_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(st_ble_esc_elevation_1_es_trigger_1_t),
    .db_size     = BLE_ESC_ELEVATION_1_ES_TRIGGER_1_LEN,
    .desc_idx    = BLE_ESC_ELEVATION_1_ES_TRIGGER_1_IDX,
    .p_attr_hdls = gs_elevation_1_es_trigger_1_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_st_ble_esc_elevation_1_es_trigger_1_t,
    .encode      = (ble_servc_attr_encode_t)encode_st_ble_esc_elevation_1_es_trigger_1_t,
};

ble_status_t R_BLE_ESC_WriteElevation1EsTrigger1(uint16_t conn_hdl, const st_ble_esc_elevation_1_es_trigger_1_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_elevation_1_es_trigger_1, conn_hdl, p_value);
}

ble_status_t R_BLE_ESC_ReadElevation1EsTrigger1(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_elevation_1_es_trigger_1, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Elevation 1 Environmental Sensing Trigger Setting 2 descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Elevation 1 characteristic descriptors attribute handles */
static uint16_t gs_elevation_1_es_trigger_2_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************
 * Function Name: decode_st_ble_esc_elevation_1_es_trigger_2_t
 * Description  : This function converts Elevation descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - Pointer to the Elevation value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_esc_elevation_1_es_trigger_2_t(st_ble_esc_elevation_1_es_trigger_2_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    /* Check the length */
    if (BLE_ESC_ELEVATION_1_ES_TRIGGER_2_LEN < p_gatt_value->value_len)
    {
        return BLE_ESC_WRITE_REQUEST_REJECTED_ERROR;
    }

    /* Copy the condition byte */
    uint8_t condition = p_gatt_value->p_value[pos];

    memset(p_app_value, 0x00, sizeof(st_ble_esc_elevation_1_es_trigger_2_t));

    p_app_value->condition = condition;
    pos += 1;

    if ((BLE_ESC_ELEVATION_1_ES_TRIGGER_0_CONDITION_USE_A_FIXED_TIME_INTERVAL_BETWEEN_TRANSMISSIONS == 
        p_app_value->condition)
        || ((BLE_ESC_ELEVATION_1_ES_TRIGGER_0_CONDITION_NO_LESS_THAN_THE_SPECIFIED_TIME_BETWEEN_TRANSMISSIONS == 
            p_app_value->condition)))
    {
        /* Copy operand bytes (3) */
        BT_UNPACK_LE_3_BYTE(p_app_value->operand, &p_gatt_value->p_value[pos]);
    }
    else if ((p_app_value->condition <= BLE_ESC_ELEVATION_1_ES_TRIGGER_0_CONDITION_WHILE_NOT_EQUAL_TO_THE_SPECIFIED_VALUE)
        && (p_app_value->condition >= BLE_ESC_ELEVATION_1_ES_TRIGGER_0_CONDITION_WHILE_LESS_THAN_THE_SPECIFIED_VALUE))
    {
        /* Copy operand bytes (3) */
        BT_UNPACK_LE_3_BYTE(p_app_value->operand, &p_gatt_value->p_value[pos]);
    }
    else if (BLE_ESC_ELEVATION_1_ES_TRIGGER_0_CONDITION_WHILE_NOT_EQUAL_TO_THE_SPECIFIED_VALUE < p_app_value->condition)
    {
        /* Tolerate the RFU value, Set to TRIGGER_SETTING_TRIGGER_INACTIVE */
        p_app_value->condition = BLE_ESC_ELEVATION_1_ES_TRIGGER_0_CONDITION_TRIGGER_INACTIVE;
    }
    else //other cases
    {
        /* Do Nothing */
    }

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_st_ble_esc_elevation_1_es_trigger_2_t
 * Description  : This function converts Temperature characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value  - Pointer to the Temperature  value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_esc_elevation_1_es_trigger_2_t(const st_ble_esc_elevation_1_es_trigger_2_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_ESC_ELEVATION_1_ES_TRIGGER_2_LEN);

    /* Copy the condition byte */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->condition);
    pos += 1;

    if ((BLE_ESC_ELEVATION_1_ES_TRIGGER_0_CONDITION_USE_A_FIXED_TIME_INTERVAL_BETWEEN_TRANSMISSIONS ==
        p_app_value->condition)
        || (BLE_ESC_ELEVATION_1_ES_TRIGGER_0_CONDITION_NO_LESS_THAN_THE_SPECIFIED_TIME_BETWEEN_TRANSMISSIONS ==
            p_app_value->condition))
    {
        /* Convert operand (24 bits) to byte sequence */
        BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], p_app_value->operand);
        pos += 3;
    }
    else if ((BLE_ESC_ELEVATION_1_ES_TRIGGER_0_CONDITION_TRIGGER_INACTIVE == p_app_value->condition) ||
        (BLE_ESC_ELEVATION_1_ES_TRIGGER_0_CONDITION_WHEN_VALUE_CHANGES_COMPARED_TO_PREVIOUS_VALUE ==
            p_app_value->condition))
    {
        /* Do Nothing */
    }
    else
    {
        /* Convert operand (24 bits) to byte sequence */
        BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], p_app_value->operand);
        pos += 3;
    }

    /* Update length */
    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

static const st_ble_servc_desc_info_t gs_elevation_1_es_trigger_2 ={
    .uuid_16     = BLE_ESC_ELEVATION_1_ES_TRIGGER_2_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(st_ble_esc_elevation_1_es_trigger_2_t),
    .db_size     = BLE_ESC_ELEVATION_1_ES_TRIGGER_2_LEN,
    .desc_idx    = BLE_ESC_ELEVATION_1_ES_TRIGGER_2_IDX,
    .p_attr_hdls = gs_elevation_1_es_trigger_2_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_st_ble_esc_elevation_1_es_trigger_2_t,
    .encode      = (ble_servc_attr_encode_t)encode_st_ble_esc_elevation_1_es_trigger_2_t,
};

ble_status_t R_BLE_ESC_WriteElevation1EsTrigger2(uint16_t conn_hdl, const st_ble_esc_elevation_1_es_trigger_2_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_elevation_1_es_trigger_2, conn_hdl, p_value);
}

ble_status_t R_BLE_ESC_ReadElevation1EsTrigger2(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_elevation_1_es_trigger_2, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Elevation 1 Environmental Sensing Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Elevation 1 characteristic descriptors attribute handles */
static uint16_t gs_elevation_1_es_conf_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_elevation_1_es_conf ={
    .uuid_16     = BLE_ESC_ELEVATION_1_ES_CONF_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint8_t),
    .db_size     = BLE_ESC_ELEVATION_1_ES_CONF_LEN,
    .desc_idx    = BLE_ESC_ELEVATION_1_ES_CONF_IDX,
    .p_attr_hdls = gs_elevation_1_es_conf_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint8_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint8_t,
};

ble_status_t R_BLE_ESC_WriteElevation1EsConf(uint16_t conn_hdl, const uint8_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_elevation_1_es_conf, conn_hdl, p_value);
}

ble_status_t R_BLE_ESC_ReadElevation1EsConf(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_elevation_1_es_conf, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Elevation 1 Characteristic User Description descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Elevation 1 characteristic descriptors attribute handles */
static uint16_t gs_elevation_1_char_user_desc_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************
 * Function Name: decode_st_ble_esc_elevation_1_char_user_desc_t
 * Description  : This function converts Elevation descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - Pointer to the Elevation value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_esc_elevation_1_char_user_desc_t(st_ble_esc_elevation_1_char_user_desc_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    /* Check for length */
    if (BLE_ESC_ELEVATION_1_CHAR_USER_DESC_LEN < p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    memset(&p_app_value->user_description[0], 0x00, 98);
    memcpy(&p_app_value->user_description[0], p_gatt_value->p_value, 98);

    BT_UNPACK_LE_2_BYTE(&p_app_value->length, (uint8_t *)&p_gatt_value->value_len);

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_st_ble_esc_elevation_1_char_user_desc_t
 * Description  : This function converts Elevation characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value  - Pointer to the Elevation value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_esc_elevation_1_char_user_desc_t(const st_ble_esc_elevation_1_char_user_desc_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_ESC_ELEVATION_1_CHAR_USER_DESC_LEN);

    memcpy(&p_gatt_value->p_value[0], &p_app_value->user_description[0] , p_app_value->length);
    pos += p_app_value->length;

    /* Update length */
    p_gatt_value->value_len = p_app_value->length;

    return BLE_SUCCESS;
}

static const st_ble_servc_desc_info_t gs_elevation_1_char_user_desc = {
    .uuid_16     = BLE_ESC_ELEVATION_1_CHAR_USER_DESC_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(st_ble_esc_elevation_1_char_user_desc_t),
    .db_size     = BLE_ESC_ELEVATION_1_CHAR_USER_DESC_LEN,
    .desc_idx    = BLE_ESC_ELEVATION_1_CHAR_USER_DESC_IDX,
    .p_attr_hdls = gs_elevation_1_char_user_desc_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_st_ble_esc_elevation_1_char_user_desc_t,
    .encode      = (ble_servc_attr_encode_t)encode_st_ble_esc_elevation_1_char_user_desc_t,
};

ble_status_t R_BLE_ESC_WriteElevation1CharUserDesc(uint16_t conn_hdl, const st_ble_esc_elevation_1_char_user_desc_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc2(&gs_elevation_1_char_user_desc, conn_hdl, p_value);
}

ble_status_t R_BLE_ESC_ReadElevation1CharUserDesc(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_elevation_1_char_user_desc, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Elevation 1 Valid Range descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Elevation 1 characteristic descriptors attribute handles */
static uint16_t gs_elevation_1_valid_range_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************
 * Function Name: decode_st_ble_esc_elevation_1_valid_range_t
 * Description  : This function converts Elevation descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - Pointer to the Elevation value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_esc_elevation_1_valid_range_t(st_ble_esc_elevation_1_valid_range_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    /* Check for length */
    if (BLE_ESC_ELEVATION_1_VALID_RANGE_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    memset(p_app_value, 0x00, sizeof(st_ble_esc_elevation_1_valid_range_t));

    /* Copy the lower inclusive bytes */
    BT_UNPACK_LE_3_BYTE(&p_app_value->lower_inclusive_value, &p_gatt_value->p_value[pos]);
    pos += 3;

    /* Copy the upper inclusive bytes */
    BT_UNPACK_LE_3_BYTE(&p_app_value->upper_inclusive_value, &p_gatt_value->p_value[pos]);

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_st_ble_esc_elevation_1_valid_range_t
 * Description  : This function converts Elevation characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value  - Pointer to the Elevation  value in the application layer
 *                p_gatt_value - Pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_esc_elevation_1_valid_range_t(const st_ble_esc_elevation_1_valid_range_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_ESC_ELEVATION_1_VALID_RANGE_LEN);

    BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], &p_app_value->lower_inclusive_value);
    pos += 3;

    BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], &p_app_value->upper_inclusive_value);

    /* Update length */
    p_gatt_value->value_len = BLE_ESC_ELEVATION_1_VALID_RANGE_LEN;

    return BLE_SUCCESS;
}

static const st_ble_servc_desc_info_t gs_elevation_1_valid_range ={
    .uuid_16     = BLE_ESC_ELEVATION_1_VALID_RANGE_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(st_ble_esc_elevation_1_valid_range_t),
    .db_size     = BLE_ESC_ELEVATION_1_VALID_RANGE_LEN,
    .desc_idx    = BLE_ESC_ELEVATION_1_VALID_RANGE_IDX,
    .p_attr_hdls = gs_elevation_1_valid_range_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_st_ble_esc_elevation_1_valid_range_t,
    .encode      = (ble_servc_attr_encode_t)encode_st_ble_esc_elevation_1_valid_range_t,
};

ble_status_t R_BLE_ESC_ReadElevation1ValidRange(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_elevation_1_valid_range, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Elevation 1 Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Elevation 1 characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_elevation_1_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

/* Elevation 1 characteristic descriptor definition */
static const st_ble_servc_desc_info_t *gspp_elevation_1_descs[] = {
    &gs_elevation_1_cli_cnfg,
    &gs_elevation_1_es_meas,
    &gs_elevation_1_char_extended_properties,
    &gs_elevation_1_es_trigger_0,
    &gs_elevation_1_es_trigger_1,
    &gs_elevation_1_es_trigger_2,
    &gs_elevation_1_es_conf,
    &gs_elevation_1_char_user_desc,
    &gs_elevation_1_valid_range,
};

/* Elevation 1 characteristic definition */
const st_ble_servc_char_info_t gs_elevation_1_char = {
    .uuid_16      = BLE_ESC_ELEVATION_1_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(int32_t),
    .db_size      = BLE_ESC_ELEVATION_1_LEN,
    .char_idx     = BLE_ESC_ELEVATION_1_IDX,
    .p_attr_hdls  = gs_elevation_1_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_int32_t,
    .encode       = (ble_servc_attr_encode_t)encode_int32_t,
    .num_of_descs = ARRAY_SIZE(gspp_elevation_1_descs),
    .pp_descs     = gspp_elevation_1_descs,
};

ble_status_t R_BLE_ESC_ReadElevation1(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_elevation_1_char, conn_hdl);
}

void R_BLE_ESC_GetElevation1AttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_esc_elevation_1_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_elevation_1_char_ranges[conn_idx];
    p_hdl->cli_cnfg_desc_hdl = gs_elevation_1_cli_cnfg_desc_hdls[conn_idx];
    p_hdl->es_meas_desc_hdl = gs_elevation_1_es_meas_desc_hdls[conn_idx];
    p_hdl->char_extended_properties_desc_hdl = gs_elevation_1_char_extended_properties_desc_hdls[conn_idx];
    p_hdl->es_trigger_0_desc_hdl = gs_elevation_1_es_trigger_0_desc_hdls[conn_idx];
    p_hdl->es_trigger_1_desc_hdl = gs_elevation_1_es_trigger_1_desc_hdls[conn_idx];
    p_hdl->es_trigger_2_desc_hdl = gs_elevation_1_es_trigger_2_desc_hdls[conn_idx];
    p_hdl->es_conf_desc_hdl = gs_elevation_1_es_conf_desc_hdls[conn_idx];
    p_hdl->char_user_desc_desc_hdl = gs_elevation_1_char_user_desc_desc_hdls[conn_idx];
    p_hdl->valid_range_desc_hdl = gs_elevation_1_valid_range_desc_hdls[conn_idx];
}


/*----------------------------------------------------------------------------------------------------------------------
    Environmental Sensing client
----------------------------------------------------------------------------------------------------------------------*/

/* Environmental Sensing client attribute handles */
static st_ble_gatt_hdl_range_t gs_esc_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

const st_ble_servc_char_info_t *gspp_esc_chars[] = {
    &gs_desc_value_changed_char,
    &gs_temperature_0_char,
    &gs_temperature_1_char,
    &gs_elevation_0_char,
    &gs_elevation_1_char,
};

static st_ble_servc_info_t gs_client_info = {
    .pp_chars     = gspp_esc_chars,
    .num_of_chars = ARRAY_SIZE(gspp_esc_chars),
    .p_attr_hdls  = gs_esc_ranges,
};

ble_status_t R_BLE_ESC_Init(ble_servc_app_cb_t cb) // @suppress("API function naming")
{
    if (NULL == cb)
    {
        return BLE_ERR_INVALID_PTR;
    }

    gs_client_info.cb = cb;

    return R_BLE_SERVC_RegisterClient(&gs_client_info);
}

void R_BLE_ESC_ServDiscCb(uint16_t conn_hdl, uint8_t serv_idx, uint16_t type, void *p_param) // @suppress("API function naming")
{
    R_BLE_SERVC_ServDiscCb(&gs_client_info, conn_hdl, serv_idx, type, p_param);
}

void R_BLE_ESC_GetServAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_gatt_hdl_range_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    *p_hdl = gs_esc_ranges[conn_idx];
}
