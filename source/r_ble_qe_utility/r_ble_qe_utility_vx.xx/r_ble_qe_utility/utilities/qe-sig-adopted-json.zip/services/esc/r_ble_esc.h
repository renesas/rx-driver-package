/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_esc.h
 * Version : 1.0
 * Description : The header file for Environmental Sensing client.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 24.05.2019 1.00 First Release
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @file
 * @defgroup esc Environmental Sensing Service Client
 * @{
 * @ingroup profile
 * @brief   This is the client for the Environmental Sensing Service.
 **********************************************************************************************************************/
#include "profile_cmn/r_ble_servc_if.h"

#ifndef R_BLE_ESC_H
#define R_BLE_ESC_H

/*----------------------------------------------------------------------------------------------------------------------
    Descriptor Value Changed Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_ESC_DESC_VALUE_CHANGED_UUID (0x2A7D)
#define BLE_ESC_DESC_VALUE_CHANGED_LEN (18)
#define BLE_ESC_DESC_VALUE_CHANGED_CLI_CNFG_UUID (0x2902)
#define BLE_ESC_DESC_VALUE_CHANGED_CLI_CNFG_LEN (2)

/***************************************************************************//**
 * @brief Descriptor Value Changed Flags value structure.
*******************************************************************************/
typedef struct {
    bool is_changed_by_client; /**< Source of Change */
    bool is_one_or_more_es_trigger_setting_descriptors_changed; /**< Change to one or more ES Trigger Setting Descriptors */
    bool is_es_configuration_descriptor_changed; /**< Change to ES Configuration Descriptor */
    bool is_es_measurement_descriptor_changed; /**< Change to ES Measurement Descriptor */
    bool is_characteristic_user_description_descriptor_changed; /**< Change to Characteristic User Description Descriptor */
} st_ble_desc_value_changed_flags_t;

/***************************************************************************//**
 * @brief Descriptor Value Changed value structure.
*******************************************************************************/
typedef struct {
    st_ble_desc_value_changed_flags_t flags; /**< Flags */
    uint8_t uuid[16]; /**< UUID */
} st_ble_esc_desc_value_changed_t;

/***************************************************************************//**
 * @brief Descriptor Value Changed attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
    uint16_t cli_cnfg_desc_hdl;
} st_ble_esc_desc_value_changed_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Descriptor Value Changed characteristic Client Characteristic Configuration descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_ReadDescValueChangedCliCnfg(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Descriptor Value Changed characteristic Client Characteristic Configuration descriptor value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value Descriptor Value Changed characteristic Client Characteristic Configuration descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_WriteDescValueChangedCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief      Get Descriptor Value Changed attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_ESC_GetDescValueChangedAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_esc_desc_value_changed_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Temperature 0 Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_ESC_TEMPERATURE_0_UUID (0x2A6E)
#define BLE_ESC_TEMPERATURE_0_LEN (2)
#define BLE_ESC_TEMPERATURE_0_CLI_CNFG_UUID (0x2902)
#define BLE_ESC_TEMPERATURE_0_CLI_CNFG_LEN (2)
#define BLE_ESC_TEMPERATURE_0_ES_MEAS_UUID (0x290C)
#define BLE_ESC_TEMPERATURE_0_ES_MEAS_LEN (11)
#define BLE_ESC_TEMPERATURE_0_CHAR_EXTENDED_PROPERTIES_UUID (0x2900)
#define BLE_ESC_TEMPERATURE_0_CHAR_EXTENDED_PROPERTIES_LEN (2)
#define BLE_ESC_TEMPERATURE_0_ES_TRIGGER_0_UUID (0x290D)
#define BLE_ESC_TEMPERATURE_0_ES_TRIGGER_0_LEN (4)
#define BLE_ESC_TEMPERATURE_0_ES_TRIGGER_1_UUID (0x290D)
#define BLE_ESC_TEMPERATURE_0_ES_TRIGGER_1_LEN (4)
#define BLE_ESC_TEMPERATURE_0_ES_TRIGGER_2_UUID (0x290D)
#define BLE_ESC_TEMPERATURE_0_ES_TRIGGER_2_LEN (4)
#define BLE_ESC_TEMPERATURE_0_ES_CONF_UUID (0x290B)
#define BLE_ESC_TEMPERATURE_0_ES_CONF_LEN (1)
#define BLE_ESC_TEMPERATURE_0_CHAR_USER_DESC_UUID (0x2901)
#define BLE_ESC_TEMPERATURE_0_CHAR_USER_DESC_LEN (100)
#define BLE_ESC_TEMPERATURE_0_VALID_RANGE_UUID (0x2906)
#define BLE_ESC_TEMPERATURE_0_VALID_RANGE_LEN (4)


/***************************************************************************//**
 * @brief Environmental Sensing Measurement Sampling Function enumeration.
*******************************************************************************/
typedef enum {
    BLE_ESC_TEMPERATURE_0_ES_MEAS_SAMPLING_FUNCTION_UNSPECIFIED = 0, /**< Unspecified */
    BLE_ESC_TEMPERATURE_0_ES_MEAS_SAMPLING_FUNCTION_INSTANTANEOUS = 1, /**< Instantaneous */
    BLE_ESC_TEMPERATURE_0_ES_MEAS_SAMPLING_FUNCTION_ARITHMETIC_MEAN = 2, /**< Arithmetic Mean */
    BLE_ESC_TEMPERATURE_0_ES_MEAS_SAMPLING_FUNCTION_RMS = 3, /**< RMS */
    BLE_ESC_TEMPERATURE_0_ES_MEAS_SAMPLING_FUNCTION_MAXIMUM = 4, /**< Maximum */
    BLE_ESC_TEMPERATURE_0_ES_MEAS_SAMPLING_FUNCTION_MINIMUM = 5, /**< Minimum */
    BLE_ESC_TEMPERATURE_0_ES_MEAS_SAMPLING_FUNCTION_ACCUMULATED = 6, /**< Accumulated */
    BLE_ESC_TEMPERATURE_0_ES_MEAS_SAMPLING_FUNCTION_COUNT = 7, /**< Count */
} e_ble_esc_tempeture_0_es_meas_sampling_function_t;

/***************************************************************************//**
 * @brief Environmental Sensing Measurement value structure.
*******************************************************************************/
typedef struct {
    uint16_t flags; /**< Flags */
    uint8_t sampling_function; /**< Sampling Function */
    uint32_t measurement_period; /**< Measurement Period */
    uint32_t update_interval; /**< Update Interval */
    uint8_t application; /**< Application */
    uint8_t measurement_uncertainty; /**< Measurement Uncertainty */
} st_ble_esc_temperature_0_es_meas_t;



/***************************************************************************//**
 * @brief Environmental Sensing Trigger Setting 0 Condition enumeration.
*******************************************************************************/
typedef enum {
    BLE_ESC_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_TRIGGER_INACTIVE = 0, /**< Trigger Inactive */
    BLE_ESC_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_USE_A_FIXED_TIME_INTERVAL_BETWEEN_TRANSMISSIONS = 1, /**< Use a fixed time interval between transmissions */
    BLE_ESC_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_NO_LESS_THAN_THE_SPECIFIED_TIME_BETWEEN_TRANSMISSIONS = 2, /**< No less than the specified time between transmissions */
    BLE_ESC_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_WHEN_VALUE_CHANGES_COMPARED_TO_PREVIOUS_VALUE = 3, /**< When value changes compared to previous value */
    BLE_ESC_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_WHILE_LESS_THAN_THE_SPECIFIED_VALUE = 4, /**< While less than the specified value */
    BLE_ESC_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_WHILE_LESS_THAN_OR_EQUAL_TO_THE_SPECIFIED_VALUE = 5, /**< While less than or equal to the specified value */
    BLE_ESC_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_WHILE_GREATER_THAN_THE_SPECIFIED_VALUE = 6, /**< While greater than the specified value */
    BLE_ESC_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_WHILE_GREATER_THAN_OR_EQUAL_TO_THE_SPECIFIED_VALUE = 7, /**< While greater than or equal to the specified value */
    BLE_ESC_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_WHILE_EQUAL_TO_THE_SPECIFIED_VALUE = 8, /**< While equal to the specified value */
    BLE_ESC_TEMPERATURE_0_ES_TRIGGER_0_CONDITION_WHILE_NOT_EQUAL_TO_THE_SPECIFIED_VALUE = 9, /**< While not equal to the specified value */
} e_ble_esc_tempeture_0_es_trigger_0_condition_t;

/***************************************************************************//**
 * @brief Environmental Sensing Trigger Setting 0 value structure.
*******************************************************************************/
typedef struct {
    uint8_t condition; /**< Condition */
    uint8_t operand[3]; /**< Operand */
} st_ble_esc_temperature_0_es_trigger_0_t;


/***************************************************************************//**
 * @brief Environmental Sensing Trigger Setting 1 value structure.
*******************************************************************************/
typedef struct {
    uint8_t condition; /**< Condition */
    uint8_t operand[3]; /**< Operand */
} st_ble_esc_temperature_0_es_trigger_1_t;


/***************************************************************************//**
 * @brief Environmental Sensing Trigger Setting 2 value structure.
*******************************************************************************/
typedef struct {
    uint8_t condition; /**< Condition */
    uint8_t operand[3]; /**< Operand */
} st_ble_esc_temperature_0_es_trigger_2_t;


/***************************************************************************//**
 * @brief Environmental Sensing Configuration Trigger Logic enumeration.
*******************************************************************************/
typedef enum {
    BLE_ESC_TEMPERATURE_0_ES_CONF_TRIGGER_LOGIC_BOOLEAN_AND = 0, /**< Boolean AND */
    BLE_ESC_TEMPERATURE_0_ES_CONF_TRIGGER_LOGIC_BOOLEAN_OR = 1, /**< Boolean OR */
} e_ble_esc_tempeture_0_es_conf_trigger_logic_t;


/***************************************************************************//**
 * @brief Characteristic User Description value structure.
*******************************************************************************/
typedef struct {
    uint8_t user_description[98]; /**< User Description */
    uint16_t length; /**< Length */
} st_ble_esc_temperature_0_char_user_desc_t;


/***************************************************************************//**
 * @brief Valid Range value structure.
*******************************************************************************/
typedef struct {
    int16_t lower_inclusive_value; /**< Lower inclusive value */
    int16_t upper_inclusive_value; /**< Upper inclusive value */
} st_ble_esc_temperature_0_valid_range_t;

/***************************************************************************//**
 * @brief Temperature 0 attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
    uint16_t cli_cnfg_desc_hdl;
    uint16_t es_meas_desc_hdl;
    uint16_t char_extended_properties_desc_hdl;
    uint16_t es_trigger_0_desc_hdl;
    uint16_t es_trigger_1_desc_hdl;
    uint16_t es_trigger_2_desc_hdl;
    uint16_t es_conf_desc_hdl;
    uint16_t char_user_desc_desc_hdl;
    uint16_t valid_range_desc_hdl;
} st_ble_esc_temperature_0_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Temperature 0 characteristic Client Characteristic Configuration descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_ReadTemperature0CliCnfg(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Temperature 0 characteristic Client Characteristic Configuration descriptor value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value Temperature 0 characteristic Client Characteristic Configuration descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_WriteTemperature0CliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Read Temperature 0 characteristic Environmental Sensing Measurement descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_ReadTemperature0EsMeas(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Read Temperature 0 characteristic Characteristic Extended Properties descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_ReadTemperature0CharExtendedProperties(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Read Temperature 0 characteristic Environmental Sensing Trigger Setting 0 descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_ReadTemperature0EsTrigger0(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Temperature 0 characteristic Environmental Sensing Trigger Setting 0 descriptor value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value Temperature 0 characteristic Environmental Sensing Trigger Setting 0 descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_WriteTemperature0EsTrigger0(uint16_t conn_hdl, const st_ble_esc_temperature_0_es_trigger_0_t *p_value);

/***************************************************************************//**
 * @brief     Read Temperature 0 characteristic Environmental Sensing Trigger Setting 1 descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_ReadTemperature0EsTrigger1(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Temperature 0 characteristic Environmental Sensing Trigger Setting 1 descriptor value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value Temperature 0 characteristic Environmental Sensing Trigger Setting 1 descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_WriteTemperature0EsTrigger1(uint16_t conn_hdl, const st_ble_esc_temperature_0_es_trigger_1_t *p_value);

/***************************************************************************//**
 * @brief     Read Temperature 0 characteristic Environmental Sensing Trigger Setting 2 descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_ReadTemperature0EsTrigger2(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Temperature 0 characteristic Environmental Sensing Trigger Setting 2 descriptor value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value Temperature 0 characteristic Environmental Sensing Trigger Setting 2 descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_WriteTemperature0EsTrigger2(uint16_t conn_hdl, const st_ble_esc_temperature_0_es_trigger_2_t *p_value);

/***************************************************************************//**
 * @brief     Read Temperature 0 characteristic Environmental Sensing Configuration descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_ReadTemperature0EsConf(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Temperature 0 characteristic Environmental Sensing Configuration descriptor value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value Temperature 0 characteristic Environmental Sensing Configuration descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_WriteTemperature0EsConf(uint16_t conn_hdl, const uint8_t *p_value);

/***************************************************************************//**
 * @brief     Read Temperature 0 characteristic Characteristic User Description descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_ReadTemperature0CharUserDesc(uint16_t conn_hdl, int32_t type);

/***************************************************************************//**
 * @brief     Write Temperature 0 characteristic Characteristic User Description descriptor value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value Temperature 0 characteristic Characteristic User Description descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_WriteTemperature0CharUserDesc(uint16_t conn_hdl, const st_ble_esc_temperature_0_char_user_desc_t *p_value);

/***************************************************************************//**
 * @brief     Read Temperature 0 characteristic Valid Range descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_ReadTemperature0ValidRange(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Read Temperature 0 characteristic value from the remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_ReadTemperature0(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief      Get Temperature 0 attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_ESC_GetTemperature0AttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_esc_temperature_0_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Temperature 1 Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_ESC_TEMPERATURE_1_UUID (0x2A6E)
#define BLE_ESC_TEMPERATURE_1_LEN (2)
#define BLE_ESC_TEMPERATURE_1_CLI_CNFG_UUID (0x2902)
#define BLE_ESC_TEMPERATURE_1_CLI_CNFG_LEN (2)
#define BLE_ESC_TEMPERATURE_1_ES_MEAS_UUID (0x290C)
#define BLE_ESC_TEMPERATURE_1_ES_MEAS_LEN (11)
#define BLE_ESC_TEMPERATURE_1_CHAR_EXTENDED_PROPERTIES_UUID (0x2900)
#define BLE_ESC_TEMPERATURE_1_CHAR_EXTENDED_PROPERTIES_LEN (2)
#define BLE_ESC_TEMPERATURE_1_ES_TRIGGER_0_UUID (0x290D)
#define BLE_ESC_TEMPERATURE_1_ES_TRIGGER_0_LEN (4)
#define BLE_ESC_TEMPERATURE_1_ES_TRIGGER_1_UUID (0x290D)
#define BLE_ESC_TEMPERATURE_1_ES_TRIGGER_1_LEN (4)
#define BLE_ESC_TEMPERATURE_1_ES_TRIGGER_2_UUID (0x290D)
#define BLE_ESC_TEMPERATURE_1_ES_TRIGGER_2_LEN (4)
#define BLE_ESC_TEMPERATURE_1_ES_CONF_UUID (0x290B)
#define BLE_ESC_TEMPERATURE_1_ES_CONF_LEN (1)
#define BLE_ESC_TEMPERATURE_1_CHAR_USER_DESC_UUID (0x2901)
#define BLE_ESC_TEMPERATURE_1_CHAR_USER_DESC_LEN (100)
#define BLE_ESC_TEMPERATURE_1_VALID_RANGE_UUID (0x2906)
#define BLE_ESC_TEMPERATURE_1_VALID_RANGE_LEN (4)


/***************************************************************************//**
 * @brief Environmental Sensing Measurement Sampling Function enumeration.
*******************************************************************************/
typedef enum {
    BLE_ESC_TEMPERATURE_1_ES_MEAS_SAMPLING_FUNCTION_UNSPECIFIED = 0, /**< Unspecified */
    BLE_ESC_TEMPERATURE_1_ES_MEAS_SAMPLING_FUNCTION_INSTANTANEOUS = 1, /**< Instantaneous */
    BLE_ESC_TEMPERATURE_1_ES_MEAS_SAMPLING_FUNCTION_ARITHMETIC_MEAN = 2, /**< Arithmetic Mean */
    BLE_ESC_TEMPERATURE_1_ES_MEAS_SAMPLING_FUNCTION_RMS = 3, /**< RMS */
    BLE_ESC_TEMPERATURE_1_ES_MEAS_SAMPLING_FUNCTION_MAXIMUM = 4, /**< Maximum */
    BLE_ESC_TEMPERATURE_1_ES_MEAS_SAMPLING_FUNCTION_MINIMUM = 5, /**< Minimum */
    BLE_ESC_TEMPERATURE_1_ES_MEAS_SAMPLING_FUNCTION_ACCUMULATED = 6, /**< Accumulated */
    BLE_ESC_TEMPERATURE_1_ES_MEAS_SAMPLING_FUNCTION_COUNT = 7, /**< Count */
} e_ble_esc_tempeture_1_es_meas_sampling_function_t;

/***************************************************************************//**
 * @brief Environmental Sensing Measurement value structure.
*******************************************************************************/
typedef struct {
    uint16_t flags; /**< Flags */
    uint8_t sampling_function; /**< Sampling Function */
    uint32_t measurement_period; /**< Measurement Period */
    uint32_t update_interval; /**< Update Interval */
    uint8_t application; /**< Application */
    uint8_t measurement_uncertainty; /**< Measurement Uncertainty */
} st_ble_esc_temperature_1_es_meas_t;



/***************************************************************************//**
 * @brief Environmental Sensing Trigger Setting 0 Condition enumeration.
*******************************************************************************/
typedef enum {
    BLE_ESC_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_TRIGGER_INACTIVE = 0, /**< Trigger Inactive */
    BLE_ESC_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_USE_A_FIXED_TIME_INTERVAL_BETWEEN_TRANSMISSIONS = 1, /**< Use a fixed time interval between transmissions */
    BLE_ESC_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_NO_LESS_THAN_THE_SPECIFIED_TIME_BETWEEN_TRANSMISSIONS = 2, /**< No less than the specified time between transmissions */
    BLE_ESC_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_WHEN_VALUE_CHANGES_COMPARED_TO_PREVIOUS_VALUE = 3, /**< When value chances compared to previous value */
    BLE_ESC_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_WHILE_LESS_THAN_THE_SPECIFIED_VALUE = 4, /**< While less than the specified value */
    BLE_ESC_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_WHILE_LESS_THAN_OR_EQUAL_TO_THE_SPECIFIED_VALUE = 5, /**< While less than or equal to the specified value */
    BLE_ESC_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_WHILE_GREATER_THAN_THE_SPECIFIED_VALUE = 6, /**< While greater than the specified value */
    BLE_ESC_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_WHILE_GREATER_THAN_OR_EQUAL_TO_THE_SPECIFIED_VALUE = 7, /**< While greater than or equal to the specified value */
    BLE_ESC_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_WHILE_EQUAL_TO_THE_SPECIFIED_VALUE = 8, /**< While equal to the specified value */
    BLE_ESC_TEMPERATURE_1_ES_TRIGGER_0_CONDITION_WHILE_NOT_EQUAL_TO_THE_SPECIFIED_VALUE = 9, /**< While not equal to the specified value */
} e_ble_esc_tempeture_1_es_trigger_0_condition_t;

/***************************************************************************//**
 * @brief Environmental Sensing Trigger Setting 0 value structure.
*******************************************************************************/
typedef struct {
    uint8_t condition; /**< Condition */
    uint8_t operand[3]; /**< Operand */
} st_ble_esc_temperature_1_es_trigger_0_t;


/***************************************************************************//**
 * @brief Environmental Sensing Trigger Setting 1 value structure.
*******************************************************************************/
typedef struct {
    uint8_t condition; /**< Condition */
    uint8_t operand[3]; /**< Operand */
} st_ble_esc_temperature_1_es_trigger_1_t;


/***************************************************************************//**
 * @brief Environmental Sensing Trigger Setting 2 value structure.
*******************************************************************************/
typedef struct {
    uint8_t condition; /**< Condition */
    uint8_t operand[3]; /**< Operand */
} st_ble_esc_temperature_1_es_trigger_2_t;


/***************************************************************************//**
 * @brief Environmental Sensing Configuration Trigger Logic enumeration.
*******************************************************************************/
typedef enum {
    BLE_ESC_TEMPERATURE_1_ES_CONF_TRIGGER_LOGIC_BOOLEAN_AND = 0, /**< Boolean AND */
    BLE_ESC_TEMPERATURE_1_ES_CONF_TRIGGER_LOGIC_BOOLEAN_OR = 1, /**< Boolean OR */
} e_ble_esc_tempeture_1_es_conf_trigger_logic_t;


/***************************************************************************//**
 * @brief Characteristic User Description value structure.
*******************************************************************************/
typedef struct {
    uint8_t user_description[98]; /**< User Description */
    uint16_t length; /**< Length */
} st_ble_esc_temperature_1_char_user_desc_t;


/***************************************************************************//**
 * @brief Valid Range value structure.
*******************************************************************************/
typedef struct {
    int16_t lower_inclusive_value; /**< Lower inclusive value */
    int16_t upper_inclusive_value; /**< Upper inclusive value */
} st_ble_esc_temperature_1_valid_range_t;

/***************************************************************************//**
 * @brief Temperature 1 attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
    uint16_t cli_cnfg_desc_hdl;
    uint16_t es_meas_desc_hdl;
    uint16_t char_extended_properties_desc_hdl;
    uint16_t es_trigger_0_desc_hdl;
    uint16_t es_trigger_1_desc_hdl;
    uint16_t es_trigger_2_desc_hdl;
    uint16_t es_conf_desc_hdl;
    uint16_t char_user_desc_desc_hdl;
    uint16_t valid_range_desc_hdl;
} st_ble_esc_temperature_1_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Temperature 1 characteristic Client Characteristic Configuration descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_ReadTemperature1CliCnfg(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Temperature 1 characteristic Client Characteristic Configuration descriptor value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value Temperature 1 characteristic Client Characteristic Configuration descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_WriteTemperature1CliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Read Temperature 1 characteristic Environmental Sensing Measurement descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_ReadTemperature1EsMeas(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Read Temperature 1 characteristic Characteristic Extended Properties descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_ReadTemperature1CharExtendedProperties(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Read Temperature 1 characteristic Environmental Sensing Trigger Setting 0 descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_ReadTemperature1EsTrigger0(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Temperature 1 characteristic Environmental Sensing Trigger Setting 0 descriptor value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value Temperature 1 characteristic Environmental Sensing Trigger Setting 0 descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_WriteTemperature1EsTrigger0(uint16_t conn_hdl, const st_ble_esc_temperature_1_es_trigger_0_t *p_value);

/***************************************************************************//**
 * @brief     Read Temperature 1 characteristic Environmental Sensing Trigger Setting 1 descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_ReadTemperature1EsTrigger1(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Temperature 1 characteristic Environmental Sensing Trigger Setting 1 descriptor value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value Temperature 1 characteristic Environmental Sensing Trigger Setting 1 descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_WriteTemperature1EsTrigger1(uint16_t conn_hdl, const st_ble_esc_temperature_1_es_trigger_1_t *p_value);

/***************************************************************************//**
 * @brief     Read Temperature 1 characteristic Environmental Sensing Trigger Setting 2 descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_ReadTemperature1EsTrigger2(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Temperature 1 characteristic Environmental Sensing Trigger Setting 2 descriptor value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value Temperature 1 characteristic Environmental Sensing Trigger Setting 2 descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_WriteTemperature1EsTrigger2(uint16_t conn_hdl, const st_ble_esc_temperature_1_es_trigger_2_t *p_value);

/***************************************************************************//**
 * @brief     Read Temperature 1 characteristic Environmental Sensing Configuration descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_ReadTemperature1EsConf(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Temperature 1 characteristic Environmental Sensing Configuration descriptor value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value Temperature 1 characteristic Environmental Sensing Configuration descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_WriteTemperature1EsConf(uint16_t conn_hdl, const uint8_t *p_value);

/***************************************************************************//**
 * @brief     Read Temperature 1 characteristic Characteristic User Description descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_ReadTemperature1CharUserDesc(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Temperature 1 characteristic Characteristic User Description descriptor value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value Temperature 1 characteristic Characteristic User Description descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_WriteTemperature1CharUserDesc(uint16_t conn_hdl, const st_ble_esc_temperature_1_char_user_desc_t *p_value);

/***************************************************************************//**
 * @brief     Read Temperature 1 characteristic Valid Range descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_ReadTemperature1ValidRange(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Read Temperature 1 characteristic value from the remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_ReadTemperature1(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief      Get Temperature 1 attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_ESC_GetTemperature1AttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_esc_temperature_1_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Elevation 0 Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_ESC_ELEVATION_0_UUID (0x2A6C)
#define BLE_ESC_ELEVATION_0_LEN (3)
#define BLE_ESC_ELEVATION_0_CLI_CNFG_UUID (0x2902)
#define BLE_ESC_ELEVATION_0_CLI_CNFG_LEN (2)
#define BLE_ESC_ELEVATION_0_ES_MEAS_UUID (0x290C)
#define BLE_ESC_ELEVATION_0_ES_MEAS_LEN (11)
#define BLE_ESC_ELEVATION_0_CHAR_EXTENDED_PROPERTIES_UUID (0x2900)
#define BLE_ESC_ELEVATION_0_CHAR_EXTENDED_PROPERTIES_LEN (2)
#define BLE_ESC_ELEVATION_0_ES_TRIGGER_0_UUID (0x290D)
#define BLE_ESC_ELEVATION_0_ES_TRIGGER_0_LEN (4)
#define BLE_ESC_ELEVATION_0_ES_TRIGGER_1_UUID (0x290D)
#define BLE_ESC_ELEVATION_0_ES_TRIGGER_1_LEN (4)
#define BLE_ESC_ELEVATION_0_ES_TRIGGER_2_UUID (0x290D)
#define BLE_ESC_ELEVATION_0_ES_TRIGGER_2_LEN (4)
#define BLE_ESC_ELEVATION_0_ES_CONF_UUID (0x290B)
#define BLE_ESC_ELEVATION_0_ES_CONF_LEN (1)
#define BLE_ESC_ELEVATION_0_CHAR_USER_DESC_UUID (0x2901)
#define BLE_ESC_ELEVATION_0_CHAR_USER_DESC_LEN (100)
#define BLE_ESC_ELEVATION_0_VALID_RANGE_UUID (0x2906)
#define BLE_ESC_ELEVATION_0_VALID_RANGE_LEN (6)


/***************************************************************************//**
 * @brief Environmental Sensing Measurement Sampling Function enumeration.
*******************************************************************************/
typedef enum {
    BLE_ESC_ELEVATION_0_ES_MEAS_SAMPLING_FUNCTION_UNSPECIFIED = 0, /**< Unspecified */
    BLE_ESC_ELEVATION_0_ES_MEAS_SAMPLING_FUNCTION_INSTANTANEOUS = 1, /**< Instantaneous */
    BLE_ESC_ELEVATION_0_ES_MEAS_SAMPLING_FUNCTION_ARITHMETIC_MEAN = 2, /**< Arithmetic Mean */
    BLE_ESC_ELEVATION_0_ES_MEAS_SAMPLING_FUNCTION_RMS = 3, /**< RMS */
    BLE_ESC_ELEVATION_0_ES_MEAS_SAMPLING_FUNCTION_MAXIMUM = 4, /**< Maximum */
    BLE_ESC_ELEVATION_0_ES_MEAS_SAMPLING_FUNCTION_MINIMUM = 5, /**< Minimum */
    BLE_ESC_ELEVATION_0_ES_MEAS_SAMPLING_FUNCTION_ACCUMULATED = 6, /**< Accumulated */
    BLE_ESC_ELEVATION_0_ES_MEAS_SAMPLING_FUNCTION_COUNT = 7, /**< Count */
} e_ble_esc_elevation_0_es_meas_sampling_function_t;

/***************************************************************************//**
 * @brief Environmental Sensing Measurement value structure.
*******************************************************************************/
typedef struct {
    uint16_t flags; /**< Flags */
    uint8_t sampling_function; /**< Sampling Function */
    uint32_t measurement_period; /**< Measurement Period */
    uint32_t update_interval; /**< Update Interval */
    uint8_t application; /**< Application */
    uint8_t measurement_uncertainty; /**< Measurement Uncertainty */
} st_ble_esc_elevation_0_es_meas_t;



/***************************************************************************//**
 * @brief Environmental Sensing Trigger Setting 0 Condition enumeration.
*******************************************************************************/
typedef enum {
    BLE_ESC_ELEVATION_0_ES_TRIGGER_0_CONDITION_TRIGGER_INACTIVE = 0, /**< Trigger Inactive */
    BLE_ESC_ELEVATION_0_ES_TRIGGER_0_CONDITION_USE_A_FIXED_TIME_INTERVAL_BETWEEN_TRANSMISSIONS = 1, /**< Use a fixed time interval between transmissions */
    BLE_ESC_ELEVATION_0_ES_TRIGGER_0_CONDITION_NO_LESS_THAN_THE_SPECIFIED_TIME_BETWEEN_TRANSMISSIONS = 2, /**< No less than the specified time between transmissions */
    BLE_ESC_ELEVATION_0_ES_TRIGGER_0_CONDITION_WHEN_VALUE_CHANGES_COMPARED_TO_PREVIOUS_VALUE = 3, /**< When value changes compared to previous value */
    BLE_ESC_ELEVATION_0_ES_TRIGGER_0_CONDITION_WHILE_LESS_THAN_THE_SPECIFIED_VALUE = 4, /**< While less than the specified value */
    BLE_ESC_ELEVATION_0_ES_TRIGGER_0_CONDITION_WHILE_LESS_THAN_OR_EQUAL_TO_THE_SPECIFIED_VALUE = 5, /**< While less than or equal to the specified value */
    BLE_ESC_ELEVATION_0_ES_TRIGGER_0_CONDITION_WHILE_GREATER_THAN_THE_SPECIFIED_VALUE = 6, /**< While greater than the specified value */
    BLE_ESC_ELEVATION_0_ES_TRIGGER_0_CONDITION_WHILE_GREATER_THAN_OR_EQUAL_TO_THE_SPECIFIED_VALUE = 7, /**< While greater than or equal to the specified value */
    BLE_ESC_ELEVATION_0_ES_TRIGGER_0_CONDITION_WHILE_EQUAL_TO_THE_SPECIFIED_VALUE = 8, /**< While equal to the specified value */
    BLE_ESC_ELEVATION_0_ES_TRIGGER_0_CONDITION_WHILE_NOT_EQUAL_TO_THE_SPECIFIED_VALUE = 9, /**< While not equal to the specified value */
} e_ble_esc_elevation_0_es_trigger_0_condition_t;

/***************************************************************************//**
 * @brief Environmental Sensing Trigger Setting 0 value structure.
*******************************************************************************/
typedef struct {
    uint8_t condition; /**< Condition */
    uint8_t operand[3]; /**< Operand */
} st_ble_esc_elevation_0_es_trigger_0_t;


/***************************************************************************//**
 * @brief Environmental Sensing Trigger Setting 1 value structure.
*******************************************************************************/
typedef struct {
    uint8_t condition; /**< Condition */
    uint8_t operand[3]; /**< Operand */
} st_ble_esc_elevation_0_es_trigger_1_t;


/***************************************************************************//**
 * @brief Environmental Sensing Trigger Setting 2 value structure.
*******************************************************************************/
typedef struct {
    uint8_t condition; /**< Condition */
    uint8_t operand[3]; /**< Operand */
} st_ble_esc_elevation_0_es_trigger_2_t;


/***************************************************************************//**
 * @brief Environmental Sensing Configuration Trigger Logic enumeration.
*******************************************************************************/
typedef enum {
    BLE_ESC_ELEVATION_0_ES_CONF_TRIGGER_LOGIC_BOOLEAN_AND = 0, /**< Boolean AND */
    BLE_ESC_ELEVATION_0_ES_CONF_TRIGGER_LOGIC_BOOLEAN_OR = 1, /**< Boolean OR */
} e_ble_esc_elevation_0_es_conf_trigger_logic_t;


/***************************************************************************//**
 * @brief Characteristic User Description value structure.
*******************************************************************************/
typedef struct {
    uint8_t user_description[98]; /**< User Description */
    uint16_t length; /**< Length */
} st_ble_esc_elevation_0_char_user_desc_t;


/***************************************************************************//**
 * @brief Valid Range value structure.
*******************************************************************************/
typedef struct {
    int32_t lower_inclusive_value; /**< Lower inclusive value */
    int32_t upper_inclusive_value; /**< Upper inclusive value */
} st_ble_esc_elevation_0_valid_range_t;

/***************************************************************************//**
 * @brief Elevation 0 attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
    uint16_t cli_cnfg_desc_hdl;
    uint16_t es_meas_desc_hdl;
    uint16_t char_extended_properties_desc_hdl;
    uint16_t es_trigger_0_desc_hdl;
    uint16_t es_trigger_1_desc_hdl;
    uint16_t es_trigger_2_desc_hdl;
    uint16_t es_conf_desc_hdl;
    uint16_t char_user_desc_desc_hdl;
    uint16_t valid_range_desc_hdl;
} st_ble_esc_elevation_0_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Elevation 0 characteristic Client Characteristic Configuration descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_ReadElevation0CliCnfg(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Elevation 0 characteristic Client Characteristic Configuration descriptor value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value Elevation 0 characteristic Client Characteristic Configuration descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_WriteElevation0CliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Read Elevation 0 characteristic Environmental Sensing Measurement descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_ReadElevation0EsMeas(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Read Elevation 0 characteristic Characteristic Extended Properties descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_ReadElevation0CharExtendedProperties(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Read Elevation 0 characteristic Environmental Sensing Trigger Setting 0 descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_ReadElevation0EsTrigger0(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Elevation 0 characteristic Environmental Sensing Trigger Setting 0 descriptor value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value Elevation 0 characteristic Environmental Sensing Trigger Setting 0 descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_WriteElevation0EsTrigger0(uint16_t conn_hdl, const st_ble_esc_elevation_0_es_trigger_0_t *p_value);

/***************************************************************************//**
 * @brief     Read Elevation 0 characteristic Environmental Sensing Trigger Setting 1 descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_ReadElevation0EsTrigger1(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Elevation 0 characteristic Environmental Sensing Trigger Setting 1 descriptor value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value Elevation 0 characteristic Environmental Sensing Trigger Setting 1 descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_WriteElevation0EsTrigger1(uint16_t conn_hdl, const st_ble_esc_elevation_0_es_trigger_1_t *p_value);

/***************************************************************************//**
 * @brief     Read Elevation 0 characteristic Environmental Sensing Trigger Setting 2 descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_ReadElevation0EsTrigger2(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Elevation 0 characteristic Environmental Sensing Trigger Setting 2 descriptor value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value Elevation 0 characteristic Environmental Sensing Trigger Setting 2 descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_WriteElevation0EsTrigger2(uint16_t conn_hdl, const st_ble_esc_elevation_0_es_trigger_2_t *p_value);

/***************************************************************************//**
 * @brief     Read Elevation 0 characteristic Environmental Sensing Configuration descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_ReadElevation0EsConf(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Elevation 0 characteristic Environmental Sensing Configuration descriptor value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value Elevation 0 characteristic Environmental Sensing Configuration descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_WriteElevation0EsConf(uint16_t conn_hdl, const uint8_t *p_value);

/***************************************************************************//**
 * @brief     Read Elevation 0 characteristic Characteristic User Description descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_ReadElevation0CharUserDesc(uint16_t conn_hdl, int32_t type);

/***************************************************************************//**
 * @brief     Write Elevation 0 characteristic Characteristic User Description descriptor value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value Elevation 0 characteristic Characteristic User Description descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_WriteElevation0CharUserDesc(uint16_t conn_hdl, const st_ble_esc_elevation_0_char_user_desc_t *p_value);

/***************************************************************************//**
 * @brief     Read Elevation 0 characteristic Valid Range descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_ReadElevation0ValidRange(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Read Elevation 0 characteristic value from the remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_ReadElevation0(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief      Get Elevation 0 attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_ESC_GetElevation0AttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_esc_elevation_0_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Elevation 1 Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_ESC_ELEVATION_1_UUID (0x2A6C)
#define BLE_ESC_ELEVATION_1_LEN (3)
#define BLE_ESC_ELEVATION_1_CLI_CNFG_UUID (0x2902)
#define BLE_ESC_ELEVATION_1_CLI_CNFG_LEN (2)
#define BLE_ESC_ELEVATION_1_ES_MEAS_UUID (0x290C)
#define BLE_ESC_ELEVATION_1_ES_MEAS_LEN (11)
#define BLE_ESC_ELEVATION_1_CHAR_EXTENDED_PROPERTIES_UUID (0x2900)
#define BLE_ESC_ELEVATION_1_CHAR_EXTENDED_PROPERTIES_LEN (2)
#define BLE_ESC_ELEVATION_1_ES_TRIGGER_0_UUID (0x290D)
#define BLE_ESC_ELEVATION_1_ES_TRIGGER_0_LEN (4)
#define BLE_ESC_ELEVATION_1_ES_TRIGGER_1_UUID (0x290D)
#define BLE_ESC_ELEVATION_1_ES_TRIGGER_1_LEN (4)
#define BLE_ESC_ELEVATION_1_ES_TRIGGER_2_UUID (0x290D)
#define BLE_ESC_ELEVATION_1_ES_TRIGGER_2_LEN (4)
#define BLE_ESC_ELEVATION_1_ES_CONF_UUID (0x290B)
#define BLE_ESC_ELEVATION_1_ES_CONF_LEN (1)
#define BLE_ESC_ELEVATION_1_CHAR_USER_DESC_UUID (0x2901)
#define BLE_ESC_ELEVATION_1_CHAR_USER_DESC_LEN (100)
#define BLE_ESC_ELEVATION_1_VALID_RANGE_UUID (0x2906)
#define BLE_ESC_ELEVATION_1_VALID_RANGE_LEN (6)


/***************************************************************************//**
 * @brief Environmental Sensing Measurement Sampling Function enumeration.
*******************************************************************************/
typedef enum {
    BLE_ESC_ELEVATION_1_ES_MEAS_SAMPLING_FUNCTION_UNSPECIFIED = 0, /**< Unspecified */
    BLE_ESC_ELEVATION_1_ES_MEAS_SAMPLING_FUNCTION_INSTANTANEOUS = 1, /**< Instantaneous */
    BLE_ESC_ELEVATION_1_ES_MEAS_SAMPLING_FUNCTION_ARITHMETIC_MEAN = 2, /**< Arithmetic Mean */
    BLE_ESC_ELEVATION_1_ES_MEAS_SAMPLING_FUNCTION_RMS = 3, /**< RMS */
    BLE_ESC_ELEVATION_1_ES_MEAS_SAMPLING_FUNCTION_MAXIMUM = 4, /**< Maximum */
    BLE_ESC_ELEVATION_1_ES_MEAS_SAMPLING_FUNCTION_MINIMUM = 5, /**< Minimum */
    BLE_ESC_ELEVATION_1_ES_MEAS_SAMPLING_FUNCTION_ACCUMULATED = 6, /**< Accumulated */
    BLE_ESC_ELEVATION_1_ES_MEAS_SAMPLING_FUNCTION_COUNT = 7, /**< Count */
} e_ble_esc_elevation_1_es_meas_sampling_function_t;

/***************************************************************************//**
 * @brief Environmental Sensing Measurement value structure.
*******************************************************************************/
typedef struct {
    uint16_t flags; /**< Flags */
    uint8_t sampling_function; /**< Sampling Function */
    uint32_t measurement_period; /**< Measurement Period */
    uint32_t update_interval; /**< Update Interval */
    uint8_t application; /**< Application */
    uint8_t measurement_uncertainty; /**< Measurement Uncertainty */
} st_ble_esc_elevation_1_es_meas_t;



/***************************************************************************//**
 * @brief Environmental Sensing Trigger Setting 0 Condition enumeration.
*******************************************************************************/
typedef enum {
    BLE_ESC_ELEVATION_1_ES_TRIGGER_0_CONDITION_TRIGGER_INACTIVE = 0, /**< Trigger Inactive */
    BLE_ESC_ELEVATION_1_ES_TRIGGER_0_CONDITION_USE_A_FIXED_TIME_INTERVAL_BETWEEN_TRANSMISSIONS = 1, /**< Use a fixed time interval between transmissions */
    BLE_ESC_ELEVATION_1_ES_TRIGGER_0_CONDITION_NO_LESS_THAN_THE_SPECIFIED_TIME_BETWEEN_TRANSMISSIONS = 2, /**< No less than the specified time between transmissions */
    BLE_ESC_ELEVATION_1_ES_TRIGGER_0_CONDITION_WHEN_VALUE_CHANGES_COMPARED_TO_PREVIOUS_VALUE = 3, /**< When value changes compared to previous value */
    BLE_ESC_ELEVATION_1_ES_TRIGGER_0_CONDITION_WHILE_LESS_THAN_THE_SPECIFIED_VALUE = 4, /**< While less than the specified value */
    BLE_ESC_ELEVATION_1_ES_TRIGGER_0_CONDITION_WHILE_LESS_THAN_OR_EQUAL_TO_THE_SPECIFIED_VALUE = 5, /**< While less than or equal to the specified value */
    BLE_ESC_ELEVATION_1_ES_TRIGGER_0_CONDITION_WHILE_GREATER_THAN_THE_SPECIFIED_VALUE = 6, /**< While greater than the specified value */
    BLE_ESC_ELEVATION_1_ES_TRIGGER_0_CONDITION_WHILE_GREATER_THAN_OR_EQUAL_TO_THE_SPECIFIED_VALUE = 7, /**< While greater than or equal to the specified value */
    BLE_ESC_ELEVATION_1_ES_TRIGGER_0_CONDITION_WHILE_EQUAL_TO_THE_SPECIFIED_VALUE = 8, /**< While equal to the specified value */
    BLE_ESC_ELEVATION_1_ES_TRIGGER_0_CONDITION_WHILE_NOT_EQUAL_TO_THE_SPECIFIED_VALUE = 9, /**< While not equal to the specified value */
} e_ble_esc_elevation_1_es_trigger_0_condition_t;

/***************************************************************************//**
 * @brief Environmental Sensing Trigger Setting 0 value structure.
*******************************************************************************/
typedef struct {
    uint8_t condition; /**< Condition */
    uint8_t operand[3]; /**< Operand */
} st_ble_esc_elevation_1_es_trigger_0_t;


/***************************************************************************//**
 * @brief Environmental Sensing Trigger Setting 1 value structure.
*******************************************************************************/
typedef struct {
    uint8_t condition; /**< Condition */
    uint8_t operand[3]; /**< Operand */
} st_ble_esc_elevation_1_es_trigger_1_t;


/***************************************************************************//**
 * @brief Environmental Sensing Trigger Setting 2 value structure.
*******************************************************************************/
typedef struct {
    uint8_t condition; /**< Condition */
    uint8_t operand[3]; /**< Operand */
} st_ble_esc_elevation_1_es_trigger_2_t;


/***************************************************************************//**
 * @brief Environmental Sensing Configuration Trigger Logic enumeration.
*******************************************************************************/
typedef enum {
    BLE_ESC_ELEVATION_1_ES_CONF_TRIGGER_LOGIC_BOOLEAN_AND = 0, /**< Boolean AND */
    BLE_ESC_ELEVATION_1_ES_CONF_TRIGGER_LOGIC_BOOLEAN_OR = 1, /**< Boolean OR */
} e_ble_esc_elevation_1_es_conf_trigger_logic_t;


/***************************************************************************//**
 * @brief Characteristic User Description value structure.
*******************************************************************************/
typedef struct {
    uint8_t user_description[98]; /**< User Description */
    uint16_t length; /**< Length */
} st_ble_esc_elevation_1_char_user_desc_t;


/***************************************************************************//**
 * @brief Valid Range value structure.
*******************************************************************************/
typedef struct {
    int32_t lower_inclusive_value; /**< Lower inclusive value */
    int32_t upper_inclusive_value; /**< Upper inclusive value */
} st_ble_esc_elevation_1_valid_range_t;

/***************************************************************************//**
 * @brief Elevation 1 attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
    uint16_t cli_cnfg_desc_hdl;
    uint16_t es_meas_desc_hdl;
    uint16_t char_extended_properties_desc_hdl;
    uint16_t es_trigger_0_desc_hdl;
    uint16_t es_trigger_1_desc_hdl;
    uint16_t es_trigger_2_desc_hdl;
    uint16_t es_conf_desc_hdl;
    uint16_t char_user_desc_desc_hdl;
    uint16_t valid_range_desc_hdl;
} st_ble_esc_elevation_1_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Elevation 1 characteristic Client Characteristic Configuration descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_ReadElevation1CliCnfg(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Elevation 1 characteristic Client Characteristic Configuration descriptor value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value Elevation 1 characteristic Client Characteristic Configuration descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_WriteElevation1CliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Read Elevation 1 characteristic Environmental Sensing Measurement descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_ReadElevation1EsMeas(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Read Elevation 1 characteristic Characteristic Extended Properties descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_ReadElevation1CharExtendedProperties(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Read Elevation 1 characteristic Environmental Sensing Trigger Setting 0 descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_ReadElevation1EsTrigger0(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Elevation 1 characteristic Environmental Sensing Trigger Setting 0 descriptor value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value Elevation 1 characteristic Environmental Sensing Trigger Setting 0 descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_WriteElevation1EsTrigger0(uint16_t conn_hdl, const st_ble_esc_elevation_1_es_trigger_0_t *p_value);

/***************************************************************************//**
 * @brief     Read Elevation 1 characteristic Environmental Sensing Trigger Setting 1 descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_ReadElevation1EsTrigger1(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Elevation 1 characteristic Environmental Sensing Trigger Setting 1 descriptor value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value Elevation 1 characteristic Environmental Sensing Trigger Setting 1 descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_WriteElevation1EsTrigger1(uint16_t conn_hdl, const st_ble_esc_elevation_1_es_trigger_1_t *p_value);

/***************************************************************************//**
 * @brief     Read Elevation 1 characteristic Environmental Sensing Trigger Setting 2 descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_ReadElevation1EsTrigger2(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Elevation 1 characteristic Environmental Sensing Trigger Setting 2 descriptor value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value Elevation 1 characteristic Environmental Sensing Trigger Setting 2 descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_WriteElevation1EsTrigger2(uint16_t conn_hdl, const st_ble_esc_elevation_1_es_trigger_2_t *p_value);

/***************************************************************************//**
 * @brief     Read Elevation 1 characteristic Environmental Sensing Configuration descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_ReadElevation1EsConf(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Elevation 1 characteristic Environmental Sensing Configuration descriptor value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value Elevation 1 characteristic Environmental Sensing Configuration descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_WriteElevation1EsConf(uint16_t conn_hdl, const uint8_t *p_value);

/***************************************************************************//**
 * @brief     Read Elevation 1 characteristic Characteristic User Description descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_ReadElevation1CharUserDesc(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Elevation 1 characteristic Characteristic User Description descriptor value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value Elevation 1 characteristic Characteristic User Description descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_WriteElevation1CharUserDesc(uint16_t conn_hdl, const st_ble_esc_elevation_1_char_user_desc_t *p_value);

/***************************************************************************//**
 * @brief     Read Elevation 1 characteristic Valid Range descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_ReadElevation1ValidRange(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Read Elevation 1 characteristic value from the remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_ReadElevation1(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief      Get Elevation 1 attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_ESC_GetElevation1AttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_esc_elevation_1_attr_hdl_t *p_hdl);


/*----------------------------------------------------------------------------------------------------------------------
    Environmental Sensing Client
----------------------------------------------------------------------------------------------------------------------*/

/***************************************************************************//**
 * @brief An attempt was made to write a value to the descriptor that is invalid or not supported by this Server.
*******************************************************************************/
#define BLE_ESC_WRITE_REQUEST_REJECTED_ERROR (BLE_ERR_GROUP_GATT | 0x80)

/***************************************************************************//**
 * @brief An attempt was made to write a value to the Condition field of the ES Trigger Setting descriptor that is invalid or not supported by this Server.
*******************************************************************************/
#define BLE_ESC_CONDITION_NOT_SUPPORTED_ERROR (BLE_ERR_GROUP_GATT | 0x81)

/***************************************************************************//**
 * @brief Environmental Sensing client event data.
*******************************************************************************/
typedef struct {
    uint16_t    conn_hdl;  /**< Connection handle */
    uint16_t    param_len; /**< Event parameter length */
    const void *p_param;   /**< Event parameter */
} st_ble_esc_evt_data_t;

/***************************************************************************//**
 * @brief Environmental Sensing characteristic ID.
*******************************************************************************/
typedef enum {
    BLE_ESC_DESC_VALUE_CHANGED_IDX,
    BLE_ESC_DESC_VALUE_CHANGED_CLI_CNFG_IDX,
    BLE_ESC_TEMPERATURE_0_IDX,
    BLE_ESC_TEMPERATURE_0_CLI_CNFG_IDX,
    BLE_ESC_TEMPERATURE_0_ES_MEAS_IDX,
    BLE_ESC_TEMPERATURE_0_CHAR_EXTENDED_PROPERTIES_IDX,
    BLE_ESC_TEMPERATURE_0_ES_TRIGGER_0_IDX,
    BLE_ESC_TEMPERATURE_0_ES_TRIGGER_1_IDX,
    BLE_ESC_TEMPERATURE_0_ES_TRIGGER_2_IDX,
    BLE_ESC_TEMPERATURE_0_ES_CONF_IDX,
    BLE_ESC_TEMPERATURE_0_CHAR_USER_DESC_IDX,
    BLE_ESC_TEMPERATURE_0_VALID_RANGE_IDX,
    BLE_ESC_TEMPERATURE_1_IDX,
    BLE_ESC_TEMPERATURE_1_CLI_CNFG_IDX,
    BLE_ESC_TEMPERATURE_1_ES_MEAS_IDX,
    BLE_ESC_TEMPERATURE_1_CHAR_EXTENDED_PROPERTIES_IDX,
    BLE_ESC_TEMPERATURE_1_ES_TRIGGER_0_IDX,
    BLE_ESC_TEMPERATURE_1_ES_TRIGGER_1_IDX,
    BLE_ESC_TEMPERATURE_1_ES_TRIGGER_2_IDX,
    BLE_ESC_TEMPERATURE_1_ES_CONF_IDX,
    BLE_ESC_TEMPERATURE_1_CHAR_USER_DESC_IDX,
    BLE_ESC_TEMPERATURE_1_VALID_RANGE_IDX,
    BLE_ESC_ELEVATION_0_IDX,
    BLE_ESC_ELEVATION_0_CLI_CNFG_IDX,
    BLE_ESC_ELEVATION_0_ES_MEAS_IDX,
    BLE_ESC_ELEVATION_0_CHAR_EXTENDED_PROPERTIES_IDX,
    BLE_ESC_ELEVATION_0_ES_TRIGGER_0_IDX,
    BLE_ESC_ELEVATION_0_ES_TRIGGER_1_IDX,
    BLE_ESC_ELEVATION_0_ES_TRIGGER_2_IDX,
    BLE_ESC_ELEVATION_0_ES_CONF_IDX,
    BLE_ESC_ELEVATION_0_CHAR_USER_DESC_IDX,
    BLE_ESC_ELEVATION_0_VALID_RANGE_IDX,
    BLE_ESC_ELEVATION_1_IDX,
    BLE_ESC_ELEVATION_1_CLI_CNFG_IDX,
    BLE_ESC_ELEVATION_1_ES_MEAS_IDX,
    BLE_ESC_ELEVATION_1_CHAR_EXTENDED_PROPERTIES_IDX,
    BLE_ESC_ELEVATION_1_ES_TRIGGER_0_IDX,
    BLE_ESC_ELEVATION_1_ES_TRIGGER_1_IDX,
    BLE_ESC_ELEVATION_1_ES_TRIGGER_2_IDX,
    BLE_ESC_ELEVATION_1_ES_CONF_IDX,
    BLE_ESC_ELEVATION_1_CHAR_USER_DESC_IDX,
    BLE_ESC_ELEVATION_1_VALID_RANGE_IDX,
} e_ble_esc_char_idx_t;

/***************************************************************************//**
 * @brief Environmental Sensing client event type.
*******************************************************************************/
typedef enum {
    /* Descriptor Value Changed */
    BLE_ESC_EVENT_DESC_VALUE_CHANGED_HDL_VAL_IND = BLE_SERVC_ATTR_EVENT(BLE_ESC_DESC_VALUE_CHANGED_IDX, BLE_SERVC_HDL_VAL_IND),
    BLE_ESC_EVENT_DESC_VALUE_CHANGED_CLI_CNFG_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_DESC_VALUE_CHANGED_CLI_CNFG_IDX, BLE_SERVC_READ_RSP),
    BLE_ESC_EVENT_DESC_VALUE_CHANGED_CLI_CNFG_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_DESC_VALUE_CHANGED_CLI_CNFG_IDX, BLE_SERVC_WRITE_RSP),
    /* Temperature 0 */
    BLE_ESC_EVENT_TEMPERATURE_0_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_TEMPERATURE_0_IDX, BLE_SERVC_READ_RSP),
    BLE_ESC_EVENT_TEMPERATURE_0_HDL_VAL_NTF = BLE_SERVC_ATTR_EVENT(BLE_ESC_TEMPERATURE_0_IDX, BLE_SERVC_HDL_VAL_NTF),
    BLE_ESC_EVENT_TEMPERATURE_0_CLI_CNFG_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_TEMPERATURE_0_CLI_CNFG_IDX, BLE_SERVC_READ_RSP),
    BLE_ESC_EVENT_TEMPERATURE_0_CLI_CNFG_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_TEMPERATURE_0_CLI_CNFG_IDX, BLE_SERVC_WRITE_RSP),
    BLE_ESC_EVENT_TEMPERATURE_0_ES_MEAS_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_TEMPERATURE_0_ES_MEAS_IDX, BLE_SERVC_READ_RSP),
    BLE_ESC_EVENT_TEMPERATURE_0_CHAR_EXTENDED_PROPERTIES_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_TEMPERATURE_0_CHAR_EXTENDED_PROPERTIES_IDX, BLE_SERVC_READ_RSP),
    BLE_ESC_EVENT_TEMPERATURE_0_ES_TRIGGER_0_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_TEMPERATURE_0_ES_TRIGGER_0_IDX, BLE_SERVC_READ_RSP),
    BLE_ESC_EVENT_TEMPERATURE_0_ES_TRIGGER_0_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_TEMPERATURE_0_ES_TRIGGER_0_IDX, BLE_SERVC_WRITE_RSP),
    BLE_ESC_EVENT_TEMPERATURE_0_ES_TRIGGER_1_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_TEMPERATURE_0_ES_TRIGGER_1_IDX, BLE_SERVC_READ_RSP),
    BLE_ESC_EVENT_TEMPERATURE_0_ES_TRIGGER_1_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_TEMPERATURE_0_ES_TRIGGER_1_IDX, BLE_SERVC_WRITE_RSP),
    BLE_ESC_EVENT_TEMPERATURE_0_ES_TRIGGER_2_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_TEMPERATURE_0_ES_TRIGGER_2_IDX, BLE_SERVC_READ_RSP),
    BLE_ESC_EVENT_TEMPERATURE_0_ES_TRIGGER_2_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_TEMPERATURE_0_ES_TRIGGER_2_IDX, BLE_SERVC_WRITE_RSP),
    BLE_ESC_EVENT_TEMPERATURE_0_ES_CONF_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_TEMPERATURE_0_ES_CONF_IDX, BLE_SERVC_READ_RSP),
    BLE_ESC_EVENT_TEMPERATURE_0_ES_CONF_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_TEMPERATURE_0_ES_CONF_IDX, BLE_SERVC_WRITE_RSP),
    BLE_ESC_EVENT_TEMPERATURE_0_CHAR_USER_DESC_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_TEMPERATURE_0_CHAR_USER_DESC_IDX, BLE_SERVC_READ_RSP),
    BLE_ESC_EVENT_TEMPERATURE_0_CHAR_USER_DESC_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_TEMPERATURE_0_CHAR_USER_DESC_IDX, BLE_SERVC_WRITE_RSP),
    BLE_ESC_EVENT_TEMPERATURE_0_VALID_RANGE_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_TEMPERATURE_0_VALID_RANGE_IDX, BLE_SERVC_READ_RSP),
    /* Temperature 1 */
    BLE_ESC_EVENT_TEMPERATURE_1_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_TEMPERATURE_1_IDX, BLE_SERVC_READ_RSP),
    BLE_ESC_EVENT_TEMPERATURE_1_HDL_VAL_NTF = BLE_SERVC_ATTR_EVENT(BLE_ESC_TEMPERATURE_1_IDX, BLE_SERVC_HDL_VAL_NTF),
    BLE_ESC_EVENT_TEMPERATURE_1_CLI_CNFG_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_TEMPERATURE_1_CLI_CNFG_IDX, BLE_SERVC_READ_RSP),
    BLE_ESC_EVENT_TEMPERATURE_1_CLI_CNFG_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_TEMPERATURE_1_CLI_CNFG_IDX, BLE_SERVC_WRITE_RSP),
    BLE_ESC_EVENT_TEMPERATURE_1_ES_MEAS_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_TEMPERATURE_1_ES_MEAS_IDX, BLE_SERVC_READ_RSP),
    BLE_ESC_EVENT_TEMPERATURE_1_CHAR_EXTENDED_PROPERTIES_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_TEMPERATURE_1_CHAR_EXTENDED_PROPERTIES_IDX, BLE_SERVC_READ_RSP),
    BLE_ESC_EVENT_TEMPERATURE_1_ES_TRIGGER_0_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_TEMPERATURE_1_ES_TRIGGER_0_IDX, BLE_SERVC_READ_RSP),
    BLE_ESC_EVENT_TEMPERATURE_1_ES_TRIGGER_0_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_TEMPERATURE_1_ES_TRIGGER_0_IDX, BLE_SERVC_WRITE_RSP),
    BLE_ESC_EVENT_TEMPERATURE_1_ES_TRIGGER_1_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_TEMPERATURE_1_ES_TRIGGER_1_IDX, BLE_SERVC_READ_RSP),
    BLE_ESC_EVENT_TEMPERATURE_1_ES_TRIGGER_1_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_TEMPERATURE_1_ES_TRIGGER_1_IDX, BLE_SERVC_WRITE_RSP),
    BLE_ESC_EVENT_TEMPERATURE_1_ES_TRIGGER_2_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_TEMPERATURE_1_ES_TRIGGER_2_IDX, BLE_SERVC_READ_RSP),
    BLE_ESC_EVENT_TEMPERATURE_1_ES_TRIGGER_2_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_TEMPERATURE_1_ES_TRIGGER_2_IDX, BLE_SERVC_WRITE_RSP),
    BLE_ESC_EVENT_TEMPERATURE_1_ES_CONF_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_TEMPERATURE_1_ES_CONF_IDX, BLE_SERVC_READ_RSP),
    BLE_ESC_EVENT_TEMPERATURE_1_ES_CONF_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_TEMPERATURE_1_ES_CONF_IDX, BLE_SERVC_WRITE_RSP),
    BLE_ESC_EVENT_TEMPERATURE_1_CHAR_USER_DESC_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_TEMPERATURE_1_CHAR_USER_DESC_IDX, BLE_SERVC_READ_RSP),
    BLE_ESC_EVENT_TEMPERATURE_1_CHAR_USER_DESC_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_TEMPERATURE_1_CHAR_USER_DESC_IDX, BLE_SERVC_WRITE_RSP),
    BLE_ESC_EVENT_TEMPERATURE_1_VALID_RANGE_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_TEMPERATURE_1_VALID_RANGE_IDX, BLE_SERVC_READ_RSP),
    /* Elevation 0 */
    BLE_ESC_EVENT_ELEVATION_0_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_ELEVATION_0_IDX, BLE_SERVC_READ_RSP),
    BLE_ESC_EVENT_ELEVATION_0_HDL_VAL_NTF = BLE_SERVC_ATTR_EVENT(BLE_ESC_ELEVATION_0_IDX, BLE_SERVC_HDL_VAL_NTF),
    BLE_ESC_EVENT_ELEVATION_0_CLI_CNFG_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_ELEVATION_0_CLI_CNFG_IDX, BLE_SERVC_READ_RSP),
    BLE_ESC_EVENT_ELEVATION_0_CLI_CNFG_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_ELEVATION_0_CLI_CNFG_IDX, BLE_SERVC_WRITE_RSP),
    BLE_ESC_EVENT_ELEVATION_0_ES_MEAS_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_ELEVATION_0_ES_MEAS_IDX, BLE_SERVC_READ_RSP),
    BLE_ESC_EVENT_ELEVATION_0_CHAR_EXTENDED_PROPERTIES_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_ELEVATION_0_CHAR_EXTENDED_PROPERTIES_IDX, BLE_SERVC_READ_RSP),
    BLE_ESC_EVENT_ELEVATION_0_ES_TRIGGER_0_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_ELEVATION_0_ES_TRIGGER_0_IDX, BLE_SERVC_READ_RSP),
    BLE_ESC_EVENT_ELEVATION_0_ES_TRIGGER_0_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_ELEVATION_0_ES_TRIGGER_0_IDX, BLE_SERVC_WRITE_RSP),
    BLE_ESC_EVENT_ELEVATION_0_ES_TRIGGER_1_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_ELEVATION_0_ES_TRIGGER_1_IDX, BLE_SERVC_READ_RSP),
    BLE_ESC_EVENT_ELEVATION_0_ES_TRIGGER_1_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_ELEVATION_0_ES_TRIGGER_1_IDX, BLE_SERVC_WRITE_RSP),
    BLE_ESC_EVENT_ELEVATION_0_ES_TRIGGER_2_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_ELEVATION_0_ES_TRIGGER_2_IDX, BLE_SERVC_READ_RSP),
    BLE_ESC_EVENT_ELEVATION_0_ES_TRIGGER_2_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_ELEVATION_0_ES_TRIGGER_2_IDX, BLE_SERVC_WRITE_RSP),
    BLE_ESC_EVENT_ELEVATION_0_ES_CONF_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_ELEVATION_0_ES_CONF_IDX, BLE_SERVC_READ_RSP),
    BLE_ESC_EVENT_ELEVATION_0_ES_CONF_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_ELEVATION_0_ES_CONF_IDX, BLE_SERVC_WRITE_RSP),
    BLE_ESC_EVENT_ELEVATION_0_CHAR_USER_DESC_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_ELEVATION_0_CHAR_USER_DESC_IDX, BLE_SERVC_READ_RSP),
    BLE_ESC_EVENT_ELEVATION_0_CHAR_USER_DESC_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_ELEVATION_0_CHAR_USER_DESC_IDX, BLE_SERVC_WRITE_RSP),
    BLE_ESC_EVENT_ELEVATION_0_VALID_RANGE_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_ELEVATION_0_VALID_RANGE_IDX, BLE_SERVC_READ_RSP),
    /* Elevation 1 */
    BLE_ESC_EVENT_ELEVATION_1_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_ELEVATION_1_IDX, BLE_SERVC_READ_RSP),
    BLE_ESC_EVENT_ELEVATION_1_HDL_VAL_NTF = BLE_SERVC_ATTR_EVENT(BLE_ESC_ELEVATION_1_IDX, BLE_SERVC_HDL_VAL_NTF),
    BLE_ESC_EVENT_ELEVATION_1_CLI_CNFG_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_ELEVATION_1_CLI_CNFG_IDX, BLE_SERVC_READ_RSP),
    BLE_ESC_EVENT_ELEVATION_1_CLI_CNFG_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_ELEVATION_1_CLI_CNFG_IDX, BLE_SERVC_WRITE_RSP),
    BLE_ESC_EVENT_ELEVATION_1_ES_MEAS_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_ELEVATION_1_ES_MEAS_IDX, BLE_SERVC_READ_RSP),
    BLE_ESC_EVENT_ELEVATION_1_CHAR_EXTENDED_PROPERTIES_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_ELEVATION_1_CHAR_EXTENDED_PROPERTIES_IDX, BLE_SERVC_READ_RSP),
    BLE_ESC_EVENT_ELEVATION_1_ES_TRIGGER_0_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_ELEVATION_1_ES_TRIGGER_0_IDX, BLE_SERVC_READ_RSP),
    BLE_ESC_EVENT_ELEVATION_1_ES_TRIGGER_0_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_ELEVATION_1_ES_TRIGGER_0_IDX, BLE_SERVC_WRITE_RSP),
    BLE_ESC_EVENT_ELEVATION_1_ES_TRIGGER_1_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_ELEVATION_1_ES_TRIGGER_1_IDX, BLE_SERVC_READ_RSP),
    BLE_ESC_EVENT_ELEVATION_1_ES_TRIGGER_1_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_ELEVATION_1_ES_TRIGGER_1_IDX, BLE_SERVC_WRITE_RSP),
    BLE_ESC_EVENT_ELEVATION_1_ES_TRIGGER_2_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_ELEVATION_1_ES_TRIGGER_2_IDX, BLE_SERVC_READ_RSP),
    BLE_ESC_EVENT_ELEVATION_1_ES_TRIGGER_2_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_ELEVATION_1_ES_TRIGGER_2_IDX, BLE_SERVC_WRITE_RSP),
    BLE_ESC_EVENT_ELEVATION_1_ES_CONF_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_ELEVATION_1_ES_CONF_IDX, BLE_SERVC_READ_RSP),
    BLE_ESC_EVENT_ELEVATION_1_ES_CONF_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_ELEVATION_1_ES_CONF_IDX, BLE_SERVC_WRITE_RSP),
    BLE_ESC_EVENT_ELEVATION_1_CHAR_USER_DESC_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_ELEVATION_1_CHAR_USER_DESC_IDX, BLE_SERVC_READ_RSP),
    BLE_ESC_EVENT_ELEVATION_1_CHAR_USER_DESC_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_ELEVATION_1_CHAR_USER_DESC_IDX, BLE_SERVC_WRITE_RSP),
    BLE_ESC_EVENT_ELEVATION_1_VALID_RANGE_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_ESC_ELEVATION_1_VALID_RANGE_IDX, BLE_SERVC_READ_RSP),
} e_ble_esc_event_t;

/***************************************************************************//**
 * @brief     Initialize Environmental Sensing client.
 * @param[in] cb Client callback.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ESC_Init(ble_servc_app_cb_t cb);

/***************************************************************************//**
 * @brief     Environmental Sensing client discovery callback.
 * @param[in] conn_hdl Connection handle
 * @param[in] serv_idx Service instance index.
 * @param[in] type     Service discovery event type.
 * @param[in] p_param  Service discovery event parameter.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_ESC_ServDiscCb(uint16_t conn_hdl, uint8_t serv_idx, uint16_t type, void *p_param);

/***************************************************************************//**
 * @brief     Get Environmental Sensing client attribute handle.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
*******************************************************************************/
void R_BLE_ESC_GetServAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_gatt_hdl_range_t *p_hdl);

#endif /* R_BLE_ESC_H */

/** @} */
