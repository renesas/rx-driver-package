/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_ndcc.h
 * Version : 1.0
 * Description : The header file for Next DST Change Service client.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 24.05.2019 1.00 First Release
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @file
 * @defgroup ndcc Next DST Change Service Client
 * @{
 * @ingroup profile
 * @brief   This is the client for the Next DST Change Service Service.
 **********************************************************************************************************************/
#include "r_ble_rx23w_if.h"
#include "profile_cmn/r_ble_servc_if.h"

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
#ifndef R_BLE_NDCC_H
#define R_BLE_NDCC_H

/*----------------------------------------------------------------------------------------------------------------------
    Time with DST Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_NDCC_TDST_UUID (0x2A11)
#define BLE_NDCC_TDST_LEN  (8)

/***************************************************************************//**
 * @brief Time with DST value structure.
*******************************************************************************/
typedef struct 
{
    st_ble_date_time_t date_time;  /**< Date Time */
    uint8_t            dst_offset; /**< DST Offset */
} st_ble_ndcc_tdst_t;

/***************************************************************************//**
 * @brief Time with DST attribute handle value.
*******************************************************************************/
typedef struct 
{
    st_ble_gatt_hdl_range_t range;
} st_ble_ndcc_tdst_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Time with DST characteristic value from the remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_NDCC_ReadTdst(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief      Get Time with DST attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_NDCC_GetTdstAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_ndcc_tdst_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Next DST Change Service Client
----------------------------------------------------------------------------------------------------------------------*/

/***************************************************************************//**
 * @brief Next DST Change Service client event data.
*******************************************************************************/
typedef struct 
{
    uint16_t    conn_hdl;  /**< Connection handle */
    uint16_t    param_len; /**< Event parameter length */
    const void *p_param;   /**< Event parameter */
} st_ble_ndcc_evt_data_t;

/***************************************************************************//**
 * @brief Next DST Change Service characteristic ID.
*******************************************************************************/
typedef enum 
{
    BLE_NDCC_TDST_IDX,
} e_ble_ndcc_char_idx_t;

/***************************************************************************//**
 * @brief Next DST Change Service client event type.
*******************************************************************************/
typedef enum
{
    /* Time with DST */
    BLE_NDCC_EVENT_TDST_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_NDCC_TDST_IDX, BLE_SERVC_READ_RSP),
} e_ble_ndcc_event_t;

/***************************************************************************//**
 * @brief     Initialize Next DST Change Service client.
 * @param[in] cb Client callback.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_NDCC_Init(ble_servc_app_cb_t cb);

/***************************************************************************//**
 * @brief     Next DST Change Service client discovery callback.
 * @param[in] conn_hdl Connection handle
 * @param[in] serv_idx Service instance index.
 * @param[in] type     Service discovery event type.
 * @param[in] p_param  Service discovery event parameter.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_NDCC_ServDiscCb(uint16_t conn_hdl, uint8_t serv_idx, uint16_t type, void *p_param);

/***************************************************************************//**
 * @brief     Get Next DST Change Service client attribute handle.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
*******************************************************************************/
void R_BLE_NDCC_GetServAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_gatt_hdl_range_t *p_hdl);

#endif /* R_BLE_NDCC_H */

/** @} */
