/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_bmc.h
 * Version : 1.0
 * Description : The header file for Bond Management Service client.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 31.12.2999 1.00 First Release
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @file
 * @defgroup bmc Bond Management Service Client
 * @{
 * @ingroup profile
 * @brief   This is the client for the Bond Management Service Service.
 **********************************************************************************************************************/
#include "r_ble_rx23w_if.h"
#include "profile_cmn/r_ble_servc_if.h"

#ifndef R_BLE_BMC_H
#define R_BLE_BMC_H

/*----------------------------------------------------------------------------------------------------------------------
    Bond Management Control Point Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_BMC_CP_UUID (0x2AA4)
#define BLE_BMC_CP_LEN (100)
/***************************************************************************//**
 * @brief Bond Management Control Point Op Code enumeration.
*******************************************************************************/
typedef enum {
    BLE_BMC_CP_OP_CODE_DELETE_BOND_OF_REQUESTING_DEVICE_LE_TRANSPORT_ONLY = 3, /**< Delete bond of requesting device (LE transport only) */
    BLE_BMC_CP_OP_CODE_DELETE_ALL_BONDS_ON_SERVER_LE_TRANSPORT_ONLY = 6, /**< Delete all bonds on server (LE transport only) */
    BLE_BMC_CP_OP_CODE_DELETE_ALL_BUT_THE_ACTIVE_BOND_ON_SERVER_LE_TRANSPORT_ONLY = 9, /**< Delete all but the active bond on server (LE transport only) */
} e_ble_bmc_cp_op_code_t;

/***************************************************************************//**
 * @brief Bond Management Control Point value structure.
*******************************************************************************/
typedef struct {
    uint8_t op_code; /**< Op Code */
    st_ble_seq_data_t operand; /**< Operand */
} st_ble_bmc_cp_t;

/***************************************************************************//**
 * @brief Bond Management Control Point attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
} st_ble_bmc_cp_attr_hdl_t;

/***************************************************************************//**
 * @brief     Write Bond Management Control Point characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] p_value Bond Management Control Point characteristic value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_BMC_WriteCp(uint16_t conn_hdl, const st_ble_bmc_cp_t *p_value);
;
/***************************************************************************//**
 * @brief      Get Bond Management Control Point attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_BMC_GetCpAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_bmc_cp_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Bond Management Features Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_BMC_FEAT_UUID (0x2AA5)
#define BLE_BMC_FEAT_LEN (3)
/***************************************************************************//**
 * @brief Bond Management Features value structure.
*******************************************************************************/
typedef struct {
    bool is_delete_bond_of_current_connection_le_transport_only_supported; /**< Delete bond of current connection (LE transport only) supported */
    bool is_authorization_code_required_to_delete_bond_of_current_connection; /**< Authorization Code required to delete bond of current connection */
    bool is_remove_all_bonds_on_server_le_transport_only_supported; /**< Remove all bonds on server (LE transport only) supported */
    bool is_authorization_code_required_to_remove_all_bonds_on_server; /**< Authorization Code required to remove all bonds on server */
    bool is_remove_all_but_the_active_bond_on_server_le_transport_only_supported; /**< Remove all but the active bond on server (LE transport only) supported */
    bool is_authorization_code_required_to_remove_all_but_the_active_bond_on_server; /**< Authorization Code required to remove all but the active bond on server */
    bool is_identify_yourself_supported; /**< Identify yourself supported */
    bool is_feature_extension; /**< Feature Extension */
} st_ble_bmc_feat_t;

/***************************************************************************//**
 * @brief Bond Management Features attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
} st_ble_bmc_feat_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Bond Management Features characteristic value from the remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_BMC_ReadFeat(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief      Get Bond Management Features attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_BMC_GetFeatAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_bmc_feat_attr_hdl_t *p_hdl);


/*----------------------------------------------------------------------------------------------------------------------
    Bond Management Service Client
----------------------------------------------------------------------------------------------------------------------*/

/***************************************************************************//**
 * @brief Response if unsupported Op Code is received
*******************************************************************************/
#define BLE_BMC_OP_CODE_NOT_SUPPORTED_ERROR (BLE_ERR_GROUP_GATT | 0x80)

/***************************************************************************//**
 * @brief Response if unable to complete a procedure for any reason
*******************************************************************************/
#define BLE_BMC_OPERATION_FAILED_ERROR (BLE_ERR_GROUP_GATT | 0x81)

/***************************************************************************//**
 * @brief Bond Management Service client event data.
*******************************************************************************/
typedef struct {
    uint16_t    conn_hdl;  /**< Connection handle */
    uint16_t    param_len; /**< Event parameter length */
    const void *p_param;   /**< Event parameter */
} st_ble_bmc_evt_data_t;

/***************************************************************************//**
 * @brief Bond Management Service characteristic ID.
*******************************************************************************/
typedef enum {
    BLE_BMC_CP_IDX,
    BLE_BMC_FEAT_IDX,
} e_ble_bmc_char_idx_t;

/***************************************************************************//**
 * @brief Bond Management Service client event type.
*******************************************************************************/
typedef enum {
    /* Bond Management Control Point */
    BLE_BMC_EVENT_CP_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_BMC_CP_IDX, BLE_SERVC_WRITE_RSP),
    /* Bond Management Features */
    BLE_BMC_EVENT_FEAT_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_BMC_FEAT_IDX, BLE_SERVC_READ_RSP),
} e_ble_bmc_event_t;

/***************************************************************************//**
 * @brief     Initialize Bond Management Service client.
 * @param[in] cb Client callback.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_BMC_Init(ble_servc_app_cb_t cb);

/***************************************************************************//**
 * @brief     Bond Management Service client discovery callback.
 * @param[in] conn_hdl Connection handle
 * @param[in] serv_idx Service instance index.
 * @param[in] type     Service discovery event type.
 * @param[in] p_param  Service discovery event parameter.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_BMC_ServDiscCb(uint16_t conn_hdl, uint8_t serv_idx, uint16_t type, void *p_param);

/***************************************************************************//**
 * @brief     Get Bond Management Service client attribute handle.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
*******************************************************************************/
void R_BLE_BMC_GetServAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_gatt_hdl_range_t *p_hdl);

#endif /* R_BLE_BMC_H */

/** @} */
