/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_bmc.c
 * Version : 1.0
 * Description : The source file for Bond Management Service client.
 **********************************************************************************************************************/
#include <string.h>
#include "r_ble_bmc.h"
#include "profile_cmn/r_ble_servc_if.h"

static st_ble_servc_info_t gs_client_info;

/*----------------------------------------------------------------------------------------------------------------------
    Bond Management Control Point Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Bond Management Control Point characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_cp_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

static ble_status_t decode_st_ble_bmc_cp_t(st_ble_bmc_cp_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    p_app_value->op_code      = p_gatt_value->p_value[0];
    p_app_value->operand.data = &p_gatt_value->p_value[1];
    p_app_value->operand.len  = (uint16_t)(p_gatt_value->value_len - 1);
    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_bmc_cp_t(const st_ble_bmc_cp_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;

    p_gatt_value->p_value[pos++] = p_app_value->op_code;
    memcpy(&p_gatt_value->p_value[pos], p_app_value->operand.data, p_app_value->operand.len);
    pos += p_app_value->operand.len;

    p_gatt_value->value_len = (uint16_t)pos;

    return BLE_SUCCESS;
}

/* Bond Management Control Point characteristic definition */
static const st_ble_servc_char_info_t gs_cp_char = {
    .uuid_16      = BLE_BMC_CP_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_bmc_cp_t),
    .db_size      = BLE_BMC_CP_LEN,
    .char_idx     = BLE_BMC_CP_IDX,
    .p_attr_hdls  = gs_cp_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_bmc_cp_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_bmc_cp_t,
};

ble_status_t R_BLE_BMC_WriteCp(uint16_t conn_hdl, const st_ble_bmc_cp_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteChar(&gs_cp_char, conn_hdl, p_value);
}

void R_BLE_BMC_GetCpAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_bmc_cp_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_cp_char_ranges[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Bond Management Features Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Bond Management Features characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_feat_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

static ble_status_t decode_st_ble_bmc_feat_t(st_ble_bmc_feat_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    p_app_value->is_delete_bond_of_current_connection_le_transport_only_supported    = !!(p_gatt_value->p_value[0] & 0x10);
    p_app_value->is_authorization_code_required_to_delete_bond_of_current_connection = !!(p_gatt_value->p_value[0] & 0x20);

    p_app_value->is_remove_all_bonds_on_server_le_transport_only_supported    = !!(p_gatt_value->p_value[1] & 0x04);
    p_app_value->is_authorization_code_required_to_remove_all_bonds_on_server = !!(p_gatt_value->p_value[1] & 0x08);

    p_app_value->is_remove_all_but_the_active_bond_on_server_le_transport_only_supported    = !!(p_gatt_value->p_value[2] & 0x01);
    p_app_value->is_authorization_code_required_to_remove_all_but_the_active_bond_on_server = !!(p_gatt_value->p_value[2] & 0x02);
    p_app_value->is_identify_yourself_supported                                             = !!(p_gatt_value->p_value[2] & 0x04);
    p_app_value->is_feature_extension                                                       = !!(p_gatt_value->p_value[2] & 0x80);

    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_bmc_feat_t(const st_ble_bmc_feat_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    memset(p_gatt_value->p_value, 0x00, BLE_BMC_FEAT_LEN);

    p_gatt_value->p_value[0] = (uint8_t)((p_app_value->is_delete_bond_of_current_connection_le_transport_only_supported ? 0x10 : 0x00)
                             | (p_app_value->is_authorization_code_required_to_delete_bond_of_current_connection ? 0x20 : 0x00));

    p_gatt_value->p_value[1] = (uint8_t)((p_app_value->is_remove_all_bonds_on_server_le_transport_only_supported ? 0x04 : 0x00)
                             | (p_app_value->is_authorization_code_required_to_remove_all_bonds_on_server ? 0x08 : 0x00));

    p_gatt_value->p_value[2] = (uint8_t)((p_app_value->is_remove_all_but_the_active_bond_on_server_le_transport_only_supported ? 0x01 : 0x00)
                             | (p_app_value->is_authorization_code_required_to_remove_all_but_the_active_bond_on_server ? 0x02 : 0x00)
                             | (p_app_value->is_identify_yourself_supported ? 0x04 : 0x00)
                             | (p_app_value->is_feature_extension ? 0x80 : 0x00));
    
    p_gatt_value->value_len = BLE_BMC_FEAT_LEN;

    return BLE_SUCCESS;
}

/* Bond Management Features characteristic definition */
static const st_ble_servc_char_info_t gs_feat_char = {
    .uuid_16      = BLE_BMC_FEAT_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_bmc_feat_t),
    .db_size      = BLE_BMC_FEAT_LEN,
    .char_idx     = BLE_BMC_FEAT_IDX,
    .p_attr_hdls  = gs_feat_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_bmc_feat_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_bmc_feat_t,
};

ble_status_t R_BLE_BMC_ReadFeat(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_feat_char, conn_hdl);
}

void R_BLE_BMC_GetFeatAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_bmc_feat_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_feat_char_ranges[conn_idx];
}


/*----------------------------------------------------------------------------------------------------------------------
    Bond Management Service client
----------------------------------------------------------------------------------------------------------------------*/

/* Bond Management Service client attribute handles */
static st_ble_gatt_hdl_range_t gs_bmc_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

const st_ble_servc_char_info_t *gspp_bmc_chars[] = {
    &gs_cp_char,
    &gs_feat_char,
};

static st_ble_servc_info_t gs_client_info = {
    .pp_chars     = gspp_bmc_chars,
    .num_of_chars = ARRAY_SIZE(gspp_bmc_chars),
    .p_attr_hdls  = gs_bmc_ranges,
};

ble_status_t R_BLE_BMC_Init(ble_servc_app_cb_t cb) // @suppress("API function naming")
{
    if (NULL == cb)
    {
        return BLE_ERR_INVALID_PTR;
    }

    gs_client_info.cb = cb;

    return R_BLE_SERVC_RegisterClient(&gs_client_info);
}

void R_BLE_BMC_ServDiscCb(uint16_t conn_hdl, uint8_t serv_idx, uint16_t type, void *p_param) // @suppress("API function naming")
{
    R_BLE_SERVC_ServDiscCb(&gs_client_info, conn_hdl, serv_idx, type, p_param);
}

void R_BLE_BMC_GetServAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_gatt_hdl_range_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    *p_hdl = gs_bmc_ranges[conn_idx];
}
