/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_rtus.h
 * Version : 1.0
 * Description : The header file for Reference Time Update Service service.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 24.05.2019 1.00 First Release
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @file
 * @defgroup rtus Reference Time Update Service Server
 * @{
 * @ingroup profile
 * @brief   This service defines how a client can request an update from a reference time source from a time server using the Generic Attribute Profile (GATT)
 **********************************************************************************************************************/
#include "profile_cmn/r_ble_servs_if.h"
#include "gatt_db.h"

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
#ifndef R_BLE_RTUS_H
#define R_BLE_RTUS_H

/*----------------------------------------------------------------------------------------------------------------------
    Time Update Control Point Characteristic
----------------------------------------------------------------------------------------------------------------------*/
/***************************************************************************//**
 * @brief Time Update Control Point Time Update Control Point enumeration.
*******************************************************************************/
typedef enum 
{
    BLE_RTUS_TUCP_TIME_UPDATE_CONTROL_POINT_GET_REFERENCE_UPDATE    = 1,       /**< Get Reference Update */
    BLE_RTUS_TUCP_TIME_UPDATE_CONTROL_POINT_CANCEL_REFERENCE_UPDATE = 2,       /**< Cancel Reference Update */
} e_ble_rtus_tucp_time_update_control_point_t;

/*----------------------------------------------------------------------------------------------------------------------
    Time Update State Characteristic
----------------------------------------------------------------------------------------------------------------------*/
/***************************************************************************//**
 * @brief Time Update State Current State enumeration.
*******************************************************************************/
typedef enum
{
    BLE_RTUS_TUS_CURRENT_STATE_IDLE            = 0,                     /**< Idle */
    BLE_RTUS_TUS_CURRENT_STATE_UPDATE_PENDING  = 1,                    /**< Update Pending */
} e_ble_rtus_tus_current_state_t;

/***************************************************************************//**
 * @brief Time Update State Result enumeration.
*******************************************************************************/
typedef enum
{
    BLE_RTUS_TUS_RESULT_SUCCESSFUL                         = 0,          /**< Successful */
    BLE_RTUS_TUS_RESULT_CANCELED                           = 1,          /**< Canceled */
    BLE_RTUS_TUS_RESULT_NO_CONNECTION_TO_REFERENCE         = 2,          /**< No Connection To Reference */
    BLE_RTUS_TUS_RESULT_REFERENCE_RESPONDED_WITH_AN_ERROR  = 3,          /**< Reference responded with an error */
    BLE_RTUS_TUS_RESULT_TIMEOUT                            = 4,          /**< Timeout */
    BLE_RTUS_TUS_RESULT_UPDATE_NOT_ATTEMPTED_AFTER_RESET   = 5,          /**< Update not attempted after reset */
} e_ble_rtus_tus_result_t;

/***************************************************************************//**
 * @brief Time Update State value structure.
*******************************************************************************/
typedef struct
{
    uint8_t current_state;     /**< Current State */
    uint8_t result;            /**< Result */
} st_ble_rtus_tus_t;

/***************************************************************************//**
 * @brief     Set Time Update State characteristic value to the local GATT database.
 * @param[in] p_value  Characteristic value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_RTUS_SetTus(const st_ble_rtus_tus_t *p_value);

/***************************************************************************//**
 * @brief     Get Time Update State characteristic value from the local GATT database.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_RTUS_GetTus(st_ble_rtus_tus_t *p_value);

/*----------------------------------------------------------------------------------------------------------------------
    Reference Time Update Service Service
----------------------------------------------------------------------------------------------------------------------*/

/***************************************************************************//**
 * @brief Reference Time Update Service characteristic Index.
*******************************************************************************/
typedef enum
{
    BLE_RTUS_TUCP_IDX,
    BLE_RTUS_TUS_IDX,
} e_ble_rtus_char_idx_t;

/***************************************************************************//**
 * @brief Reference Time Update Service event type.
*******************************************************************************/
typedef enum 
{
    /* Time Update Control Point */
    BLE_RTUS_EVENT_TUCP_WRITE_CMD = BLE_SERVS_ATTR_EVENT(BLE_RTUS_TUCP_IDX, BLE_SERVS_WRITE_CMD),
    /* Time Update State */
    BLE_RTUS_EVENT_TUS_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_RTUS_TUS_IDX, BLE_SERVS_READ_REQ),
} e_ble_rtus_event_t;

/***************************************************************************//**
 * @brief     Initialize Reference Time Update Service service.
 * @param[in] cb Service callback.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_RTUS_Init(ble_servs_app_cb_t cb);

#endif /* R_BLE_RTUS_H */

/** @} */
