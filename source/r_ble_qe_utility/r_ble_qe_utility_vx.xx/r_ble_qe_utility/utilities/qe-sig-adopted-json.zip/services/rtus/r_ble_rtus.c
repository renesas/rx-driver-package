/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_rtus.c
 * Version : 1.0
 * Description : The source file for Reference Time Update Service service.
 **********************************************************************************************************************/
 /***********************************************************************************************************************
    * History : DD.MM.YYYY Version Description
    *         : 24.05.2019 1.00 First Release
**********************************************************************************************************************/
#include <string.h>
#include "r_ble_rtus.h"
#include "profile_cmn/r_ble_servs_if.h"
#include "gatt_db.h"

static st_ble_servs_info_t gs_servs_info;

/*----------------------------------------------------------------------------------------------------------------------
    Time Update Control Point characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Time Update Control Point characteristic definition */
static const st_ble_servs_char_info_t gs_tucp_char =
{
    .start_hdl    = BLE_RTUS_TUCP_DECL_HDL,
    .end_hdl      = BLE_RTUS_TUCP_VAL_HDL,
    .char_idx     = BLE_RTUS_TUCP_IDX,
    .app_size     = sizeof(uint8_t),
    .db_size      = BLE_RTUS_TUCP_LEN,
    .decode       = (ble_servs_attr_decode_t)decode_uint8_t,
    .encode       = (ble_servs_attr_encode_t)encode_uint8_t,
};

/*----------------------------------------------------------------------------------------------------------------------
    Time Update State characteristic
----------------------------------------------------------------------------------------------------------------------*/

static ble_status_t decode_st_ble_rtus_tus_t(st_ble_rtus_tus_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    /* Check the length */
    if (BLE_RTUS_TUS_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    memset((uint8_t*)p_app_value, 0x00, sizeof(*p_app_value));

    /* Decode Presentation format fields */
    BT_UNPACK_LE_1_BYTE(&p_app_value->current_state, &p_gatt_value->p_value[pos]);
    pos += 1;

    BT_UNPACK_LE_1_BYTE(&p_app_value->result, &p_gatt_value->p_value[pos]);
    pos += 1;

    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_rtus_tus_t(const st_ble_rtus_tus_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    /* Encode Presentation format fields */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->current_state);
    pos += 1;

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->result);
    pos += 1;

    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

/* Time Update State characteristic definition */
static const st_ble_servs_char_info_t gs_tus_char =
{
    .start_hdl    = BLE_RTUS_TUS_DECL_HDL,
    .end_hdl      = BLE_RTUS_TUS_VAL_HDL,
    .char_idx     = BLE_RTUS_TUS_IDX,
    .app_size     = sizeof(st_ble_rtus_tus_t),
    .db_size      = BLE_RTUS_TUS_LEN,
    .decode       = (ble_servs_attr_decode_t)decode_st_ble_rtus_tus_t,
    .encode       = (ble_servs_attr_encode_t)encode_st_ble_rtus_tus_t,
};

ble_status_t R_BLE_RTUS_SetTus(const st_ble_rtus_tus_t *p_value)
{
    return R_BLE_SERVS_SetChar(&gs_tus_char, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_RTUS_GetTus(st_ble_rtus_tus_t *p_value)
{
    return R_BLE_SERVS_GetChar(&gs_tus_char, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Reference Time Update Service server
----------------------------------------------------------------------------------------------------------------------*/

/* Reference Time Update Service characteristics definition */
static const st_ble_servs_char_info_t *gspp_chars[] = 
{
    &gs_tucp_char,
    &gs_tus_char,
};

/* Reference Time Update Service service definition */
static st_ble_servs_info_t gs_servs_info = 
{
    .pp_chars     = gspp_chars,
    .num_of_chars = ARRAY_SIZE(gspp_chars),
};

ble_status_t R_BLE_RTUS_Init(ble_servs_app_cb_t cb)
{
    if (NULL == cb)
    {
        return BLE_ERR_INVALID_PTR;
    }

    gs_servs_info.cb = cb;

    return R_BLE_SERVS_RegisterServer(&gs_servs_info);
}
