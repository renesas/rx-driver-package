/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_idc.h
 * Version : 1.0
 * Description : This module implements Insulin Delivery Service Client.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 24.05.2019 1.00 First Release
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @file
 * @defgroup idc Insulin Delivery Service Client
 * @{
 * @ingroup profile
 * @brief This file provides APIs to interface Insulin Delivery Service Client.
 **********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_ble_rx23w_if.h"
#include "profile_cmn/r_ble_servc_if.h"

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
#ifndef R_BLE_IDC_H
#define R_BLE_IDC_H

/*******************************************************************************************************************//**
 * @brief IDD Status Changed characteristic value length.
***********************************************************************************************************************/
#define BLE_IDC_IDD_STATUS_CHANGED_LEN              (5)

/*******************************************************************************************************************//**
 * @brief IDD Status characteristic value length.
***********************************************************************************************************************/
#define BLE_IDC_IDD_STATUS_LEN                      (8)

/*******************************************************************************************************************//**
 * @brief IDD Annunciation Status characteristic value length.
***********************************************************************************************************************/
#define BLE_IDC_IDD_ANNUNCIATION_STATUS_LEN         (19)

/*******************************************************************************************************************//**
 * @brief IDD Features characteristic value length.
***********************************************************************************************************************/
#define BLE_IDC_IDD_FEATURES_LEN                    (8)

/*******************************************************************************************************************//**
 * @brief IDD Status Reader Control Point characteristic value length.
***********************************************************************************************************************/
#define BLE_IDC_IDD_STATUS_READER_CONTROL_POINT_LEN (20)

/*******************************************************************************************************************//**
 * @brief IDD Command Control Point characteristic value length.
***********************************************************************************************************************/
#define BLE_IDC_IDD_COMMAND_CONTROL_POINT_LEN       (20)

/*******************************************************************************************************************//**
 * @brief IDD Command Data characteristic value length.
***********************************************************************************************************************/
#define BLE_IDC_IDD_COMMAND_DATA_LEN                (20)

/*******************************************************************************************************************//**
 * @brief IDD Record Access Control Point characteristic value length.
***********************************************************************************************************************/
#define BLE_IDC_IDD_RECORD_ACCESS_CONTROL_POINT_LEN (20)

/*******************************************************************************************************************//**
 * @brief IDD History Data characteristic value length.
***********************************************************************************************************************/
#define BLE_IDC_IDD_HISTORY_DATA_LEN                (20)

/*******************************************************************************************************************//**
 * @brief Procedure Already in Progress error code.
***********************************************************************************************************************/
#define BLE_IDS_PROCEDURE_ALREADY_IN_PROGRESS                                      (BLE_ERR_GROUP_GATT | 0xFE)

/*******************************************************************************************************************//**
 * @brief Invalid CRC error code.
***********************************************************************************************************************/
#define BLE_IDS_INVALID_CRC                                                        (BLE_ERR_GROUP_GATT | 0x81)

/*******************************************************************************************************************//**
 * @brief Counter Error error code.
***********************************************************************************************************************/
#define BLE_IDS_COUNTER_ERROR                                                      (BLE_ERR_GROUP_GATT | 0x82)

/*******************************************************************************************************************//**
 * @brief Discriptor Improperly Configured error code.
***********************************************************************************************************************/
#define BLE_IDS_DISCRIPTOR_IMPROPERLY_CONFIGURED                                   (BLE_ERR_GROUP_GATT | 0xFD)

/*******************************************************************************************************************//**
 * @brief racp operand length
***********************************************************************************************************************/
#define BLE_IDC_RACP_OPERAND_LENGTH                 (15)

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @brief Insulin Delivery Service Client event data.
***********************************************************************************************************************/
typedef struct
{
    uint16_t  conn_hdl;  /**< Connection handle */
    uint16_t  param_len; /**< Event parameter length */
    void     *p_param;   /**< Event parameter */
} st_ble_idc_evt_data_t;

/*******************************************************************************************************************//**
 * @brief Insulin Delivery Service Client event callback.
***********************************************************************************************************************/
typedef void (*ble_idc_app_cb_t)(uint16_t type, ble_status_t result, st_ble_idc_evt_data_t *p_data);

/*******************************************************************************************************************//**
 * @brief Op Code enumeration.
 ***********************************************************************************************************************/
typedef enum
{
    BLE_IDC_OPCODE_RACP_RESPONSE_CODE                     = 0x0F, /**< Response to corresponding Op Code. */
    BLE_IDC_OPCODE_RACP_REPORT_STORED_RECORDS             = 0x33, /**< Gets the selected set of stored history records  
                                                                  based on the filter criteria specified in the 
                                                                  Operator and Operand. */
    BLE_IDC_OPCODE_RACP_DELETE_STORED_RECORDS             = 0x3C, /**< Deletes the specified history records based 
                                                                  on Operator and Operand values.*/
    BLE_IDC_OPCODE_RACP_ABORT_OPERATION                   = 0x55, /**< Stops any IDD RACP procedures currently in 
                                                                  progress. */
    BLE_IDC_OPCODE_RACP_REPORT_NUMBER_OF_STORED_RECORDS   = 0x5A, /**< Calculates and responds with a history record 
                                                                  count based on filter criteria and Operator and 
                                                                  Operand values.*/
    BLE_IDC_OPCODE_RACP_RESPONSE_NUMBER_OF_STORED_RECORDS = 0x66, /**< This is the normal response to Report Number Of 
                                                                  Stored Records.*/
} e_ble_idc_opcode_racp_t;

/*******************************************************************************************************************//**
 * @brief Operator enumeration.
 ***********************************************************************************************************************/
typedef enum
{
    BLE_IDC_OPERATOR_RACP_NULL                      = 0x0F, /**< Value used for Op Codes that do not have an Operator. */
    BLE_IDC_OPERATOR_RACP_ALL_RECORDS               = 0x33, /**< All stored history records.*/
    BLE_IDC_OPERATOR_RACP_LESS_THAN_OR_EQUAL_TO     = 0x3C, /**< History records less than or equal to specified Operand */
    BLE_IDC_OPERATOR_RACP_GREATER_THAN_OR_EQUAL_TO  = 0x55, /**< History records greater than or equal to specified Operand. */
    BLE_IDC_OPERATOR_RACP_WITHIN_RANGE_OF_INCLUSIVE = 0x5A, /**< Inclusive range of history records specified by Operand.*/
    BLE_IDC_OPERATOR_RACP_MOST_RECENT_RECORD        = 0x66, /**< Most recent history record. */
    BLE_IDC_OPERATOR_RACP_OLDEST_RECORD             = 0x69, /**< Oldest history record.*/
} e_ble_idc_operator_racp_t;

/*******************************************************************************************************************//**
 * @brief Filter Type enumeration.
 ***********************************************************************************************************************/
typedef enum
{
    BLE_IDC_FILTER_TYPE_RACP_SEQUENCE_NUMBER                            = 0x0F, /**< Sequence Number */
    BLE_IDC_FILTER_TYPE_RACP_SEQ_NUM_FILTER_BY_REFERENECE_TIME_EVENT    = 0x33, /**< The history records are filtered 
                                                                                based on their Sequence Number and on 
                                                                                both Event Types Reference Time Event 
                                                                                and Reference Time Base Offset Event*/
    BLE_IDC_FILTER_TYPE_RACP_SEQ_NUM_FILTER_BY_NON_REFERENCE_TIME_EVENT = 0x3C, /**< The history records are filtered 
                                                                                based on their Sequence Number and on 
                                                                                both Event Types Reference Time Event 
                                                                                and Reference Time Base Offset Event*/
} e_ble_idc_filter_type_racp_t;

/*******************************************************************************************************************//**
 * @brief Response Code enumeration.
 ***********************************************************************************************************************/
typedef enum
{
    BLE_IDC_RESPONSE_CODE_RACP_OPCODE_NOT_SUPPORTED     = 0x02, /**< Normal response if unsupported Op Code is received. */
    BLE_IDC_RESPONSE_CODE_RACP_INVALID_OPERATOR         = 0x03, /**< Normal response if Operator received does not meet 
                                                                the requirements of the service. */
    BLE_IDC_RESPONSE_CODE_RACP_OPERATOR_NOT_SUPPORTED   = 0x04, /**< Normal response if unsupported Operator is received.*/
    BLE_IDC_RESPONSE_CODE_RACP_INVALID_OPERAND          = 0x05, /**< Normal response if Operand received does not meet 
                                                                the requirements of the service. */
    BLE_IDC_RESPONSE_CODE_RACP_NO_RECORDS_FOUND         = 0x06, /**< Normal response if request to report stored records 
                                                                or request to delete stored records resulted in no records 
                                                                meeting criteria. */
    BLE_IDC_RESPONSE_CODE_RACP_ABORT_UNSUCCESSFUL       = 0x07, /**< Normal response if request for Abort cannot be completed. */
    BLE_IDC_RESPONSE_CODE_RACP_OPERAND_NOT_SUPPORTED    = 0x09, /**< Normal response if unsupported Operand is received. */
    BLE_IDC_RESPONSE_CODE_RACP_PROCEDURE_NOT_APPLICABLE = 0x0A, /**< Normal response if unable to complete a procedurefor 
                                                                any reason. */
    BLE_IDC_RESPONSE_CODE_RACP_SUCCESS                  = 0xF0, /**< Normal response for successful operation. */
} e_ble_idc_response_code_racp_t;

/*******************************************************************************************************************//**
 * @brief Insulin Delivery Service Client event type.
***********************************************************************************************************************/
typedef enum 
{
    BLE_IDC_EVENT_IDD_STATUS_CHANGED_HDL_VAL_IND,              /**< IDD Status Changed characteristic handle value 
                                                               indication event */
    BLE_IDC_EVENT_IDD_STATUS_CHANGED_READ_RSP,                 /**< IDD Status Changed characteristic read response 
                                                               event */
    BLE_IDC_EVENT_IDD_STATUS_HDL_VAL_IND,                      /**< IDD Status characteristic handle value indication 
                                                               event */
    BLE_IDC_EVENT_IDD_STATUS_READ_RSP,                         /**< IDD Status characteristic read response event */
    BLE_IDC_EVENT_IDD_ANNUNCIATION_STATUS_HDL_VAL_IND,         /**< IDD Annunciation Status characteristic handle value 
                                                               indication event */
    BLE_IDC_EVENT_IDD_ANNUNCIATION_STATUS_READ_RSP,            /**< IDD Annunciation Status characteristic read response 
                                                               event */
    BLE_IDC_EVENT_IDD_FEATURES_READ_RSP,                       /**< IDD Features characteristic read response event */
    BLE_IDC_EVENT_IDD_STATUS_READER_CONTROL_POINT_HDL_VAL_IND, /**< IDD Status Reader Control Point characteristic handle
                                                               value indication event */
    BLE_IDC_EVENT_IDD_STATUS_READER_CONTROL_POINT_WRITE_RSP,   /**< IDD Status Reader Control Point characteristic write 
                                                               response event */
    BLE_IDC_EVENT_IDD_COMMAND_CONTROL_POINT_HDL_VAL_IND,       /**< IDD Command Control Point characteristic handle value 
                                                               indication event */
    BLE_IDC_EVENT_IDD_COMMAND_CONTROL_POINT_WRITE_RSP,         /**< IDD Command Control Point characteristic write 
                                                               response event */
    BLE_IDC_EVENT_IDD_COMMAND_DATA_HDL_VAL_NTF,                /**< IDD Command Data characteristic handle value 
                                                               notification event */
    BLE_IDC_EVENT_IDD_RECORD_ACCESS_CONTROL_POINT_HDL_VAL_IND, /**< IDD Record Access Control Point characteristic handle 
                                                               value indication event */
    BLE_IDC_EVENT_IDD_RECORD_ACCESS_CONTROL_POINT_WRITE_RSP,   /**< IDD Record Access Control Point characteristic write 
                                                               response event */
    BLE_IDC_EVENT_IDD_HISTORY_DATA_HDL_VAL_NTF,                /**< IDD History Data characteristic handle value 
                                                               notification event */
    BLE_IDC_EVENT_CLI_CNFG_WRITE_RSP,                          /**< Cli Cnfig write response */
    BLE_IDC_EVENT_ERROR_RSP,                                   /**< error response */
} e_ble_idc_event_t;

/*******************************************************************************************************************//**
 * @brief Therapy Control State enumeration.
***********************************************************************************************************************/
typedef enum 
{
    BLE_IDC_IDD_STATUS_THERAPY_CONTROL_STATE_STOP         = 0x33, /**< The insulin infusion therapy is stopped but the 
                                                                  Insulin Delivery Device can still be configured 
                                                                  (e.g., priming). */
    BLE_IDC_IDD_STATUS_THERAPY_CONTROL_STATE_PAUSE        = 0x3c, /**< The insulin infusion therapy is paused.Typically 
                                                                  the Pause state is limited to several minutes and can 
                                                                  be used, for example, to bridge the time during a 
                                                                  reservoir change.  */
    BLE_IDC_IDD_STATUS_THERAPY_CONTROL_STATE_RUN          = 0x55, /**<  The insulin infusion therapy is running 
                                                                  (i.e., the device delivers insulin related to the 
                                                                  therapy). The Insulin Delivery Device cannot be 
                                                                  configured in the Run state (e.g., priming). */
    BLE_IDC_IDD_STATUS_THERAPY_CONTROL_STATE_UNDETERMINED = 0x0F, /**< The operational state is undetermined */
} e_ble_idc_idd_status_therapy_control_state_t;

/*******************************************************************************************************************//**
 * @brief Operational State enumeration.
***********************************************************************************************************************/
typedef enum 
{
    BLE_IDC_IDD_STATUS_OPERATIONAL_STATE_OFF          = 0x33, /**< The Insulin Delivery Device is switched off and no 
                                                              functionality is available (i.e., no delivery and no 
                                                              configuration is possible). */
    BLE_IDC_IDD_STATUS_OPERATIONAL_STATE_STANDBY      = 0x3c, /**< No insulin is delivered and resuming from this state 
                                                              is faster than from state Off (e.g., the device is being 
                                                              set to a state to save energy). */
    BLE_IDC_IDD_STATUS_OPERATIONAL_STATE_PREPARING    = 0x55, /**< The Insulin Delivery Device prepares the insulin 
                                                              infusion therapy */
    BLE_IDC_IDD_STATUS_OPERATIONAL_STATE_PRIMING      = 0x5A, /**< The Insulin Delivery Device fills the fluidic path 
                                                              from the reservoir to the body with insulin */
    BLE_IDC_IDD_STATUS_OPERATIONAL_STATE_WAITING      = 0x66, /**< The Insulin Delivery Device waits for an interaction */
    BLE_IDC_IDD_STATUS_OPERATIONAL_STATE_READY        = 0x96, /**< The Insulin Delivery Device is ready for the insulin 
                                                              infusion therapy. */
    BLE_IDC_IDD_STATUS_OPERATIONAL_STATE_UNDETERMINED = 0x0F, /**< The operational state is undetermined. */
} e_ble_idc_idd_status_t;

/*******************************************************************************************************************//**
 * @brief Annunciation Type enumeration.
***********************************************************************************************************************/
typedef enum 
{
    BLE_IDC_IDD_ANNUNCIATION_STATUS_ANNUNCIATION_TYPE_SYSTEM_ISSUE              = 0x000F, /**< A general device fault or 
                                                                                          system error occurred (e.g., 
                                                                                          electronical or software 
                                                                                          error).  */
    BLE_IDC_IDD_ANNUNCIATION_STATUS_ANNUNCIATION_TYPE_MECHANICAL_ISSUE          = 0x0033, /**< A mechanical error 
                                                                                          occurred */
    BLE_IDC_IDD_ANNUNCIATION_STATUS_ANNUNCIATION_TYPE_OCCLUSION_DETECTED        = 0x003C, /**< An occlusion occurred 
                                                                                          (e.g., clogging of infusion set) */
    BLE_IDC_IDD_ANNUNCIATION_STATUS_ANNUNCIATION_TYPE_RESERVOIR_ISSUE           = 0x0055, /**< An error related to the 
                                                                                          replacement or functioning of 
                                                                                          the reservoir occurred. */
    BLE_IDC_IDD_ANNUNCIATION_STATUS_ANNUNCIATION_TYPE_RESERVOIR_EMPTY           = 0x005A, /**< The reservoir is empty */
    BLE_IDC_IDD_ANNUNCIATION_STATUS_ANNUNCIATION_TYPE_RESERVOIR_LOW             = 0x0066, /**< The reservoir fill level 
                                                                                          reached a defined low threshold */
    BLE_IDC_IDD_ANNUNCIATION_STATUS_ANNUNCIATION_TYPE_PRIMING_ISSUE             = 0x0069, /**< There is a priming issue 
                                                                                          after replacement of reservoir 
                                                                                          and/or infusion set  */
    BLE_IDC_IDD_ANNUNCIATION_STATUS_ANNUNCIATION_TYPE_INFUSION_SET_INCOMPLETE   = 0x0096, /**< The physical connection 
                                                                                          between infusion set (including 
                                                                                          tubing and/or cannula) and the 
                                                                                          Insulin Delivery Device is 
                                                                                          incomplete */
    BLE_IDC_IDD_ANNUNCIATION_STATUS_ANNUNCIATION_TYPE_INFUSION_SET_DETACHED     = 0x0099, /**< The infusion set (including 
                                                                                          tubing and/or cannula) is not 
                                                                                          attached to the body. */
    BLE_IDC_IDD_ANNUNCIATION_STATUS_ANNUNCIATION_TYPE_POWER_SOURCE_INSUFFICIENT = 0x00A5, /**< The Insulin Delivery Device 
                                                                                          has insufficient power to charge 
                                                                                          the device (i.e., the device 
                                                                                          cannot properly function) */
    BLE_IDC_IDD_ANNUNCIATION_STATUS_ANNUNCIATION_TYPE_BATTERY_EMPTY             = 0x00AA, /**< The Insulin Delivery Device 
                                                                                          has no operational runtime left. 
                                                                                          The user shall be informed */
    BLE_IDC_IDD_ANNUNCIATION_STATUS_ANNUNCIATION_TYPE_BATTERY_LOW               = 0x00C3, /**< The Insulin Delivery Device 
                                                                                          has a low operational runtime */
    BLE_IDC_IDD_ANNUNCIATION_STATUS_ANNUNCIATION_TYPE_BATTERY_MEDIUM            = 0x00CC, /**< The Insulin Delivery Device 
                                                                                          has a medium operational runtime. 
                                                                                          This annunciation should be reported 
                                                                                          at half of the operational runtime. */
    BLE_IDC_IDD_ANNUNCIATION_STATUS_ANNUNCIATION_TYPE_BATTERY_FULL              = 0x00F0, /**< The Insulin Delivery Device 
                                                                                          has a full operational runtime. 
                                                                                          This annunciation should be 
                                                                                          reported at full operational
                                                                                          runtime. */
    BLE_IDC_IDD_ANNUNCIATION_STATUS_ANNUNCIATION_TYPE_TEMPERATURE_OUT_OF_RANGE  = 0x00FF, /**< The temperature is outside 
                                                                                          of the normal operating range. */
    BLE_IDC_IDD_ANNUNCIATION_STATUS_ANNUNCIATION_TYPE_AIR_PRESSURE_OUT_OF_RANGE = 0x0303, /**< The air pressure is outside 
                                                                                          of the normal operating range 
                                                                                          (e.g., altitude) */
    BLE_IDC_IDD_ANNUNCIATION_STATUS_ANNUNCIATION_TYPE_BOLUS_CANCELED            = 0x030C, /**< A running bolus was canceled 
                                                                                          (e.g., Insulin Delivery Device changed 
                                                                                          from run to standby mode) */
    BLE_IDC_IDD_ANNUNCIATION_STATUS_ANNUNCIATION_TYPE_TBR_OVER                  = 0x0330, /**< The temporary basal rate expired 
                                                                                          (i.e., the programmed duration is over) */
    BLE_IDC_IDD_ANNUNCIATION_STATUS_ANNUNCIATION_TYPE_TBR_CANCELED              = 0x033F, /**< The temporary basal rate canceled 
                                                                                          (e.g., device changed from run to 
                                                                                          standby mode). */
    BLE_IDC_IDD_ANNUNCIATION_STATUS_ANNUNCIATION_TYPE_MAX_DELIVERY              = 0x0356, /**< The delivery reached a defined 
                                                                                          high threshold based on maximum bolus 
                                                                                          and maximum basal rates. */
    BLE_IDC_IDD_ANNUNCIATION_STATUS_ANNUNCIATION_TYPE_DATE_TIME_ISSUE           = 0x0359, /**< The date time of the device was 
                                                                                          never set or has been lost (e.g., due 
                                                                                          to a battery replacement). */
    BLE_IDC_IDD_ANNUNCIATION_STATUS_ANNUNCIATION_TYPE_TEMPERATURE               = 0x0365, /**< The Insulin Delivery Device 
                                                                                          reports a temperature measurement. */
} e_ble_idc_idd_annunciation_status_type_t;

/*******************************************************************************************************************//**
 * @brief Annunciation Status enumeration.
***********************************************************************************************************************/
typedef enum 
{
    BLE_IDC_IDD_ANNUNCIATION_STATUS_ANNUNCIATION_STATUS_PENDING      = 0x33, /**< The status of the annunciation 
                                                                             is undetermined */
    BLE_IDC_IDD_ANNUNCIATION_STATUS_ANNUNCIATION_STATUS_SNOOZED      = 0x3c, /**< The annunciation is currently 
                                                                             pending and requires a user action 
                                                                             for snoozing or confirmation. */
    BLE_IDC_IDD_ANNUNCIATION_STATUS_ANNUNCIATION_STATUS_CONFIRMED    = 0x55, /**< The annunciation was noticed by the 
                                                                             user and is set to pop up again at a 
                                                                             short time later  */
    BLE_IDC_IDD_ANNUNCIATION_STATUS_ANNUNCIATION_STATUS_UNDETERMINED = 0x0F, /**< The annunciation was confirmed 
                                                                             by the user */
} e_ble_idc_idd_annunciation_status_status_t;

/*******************************************************************************************************************//**
 * @brief Op Code enumeration.
***********************************************************************************************************************/
typedef enum 
{
    BLE_IDC_IDD_STATUS_READER_CONTROL_POINT_OP_CODE_RESPONSE_CODE                           = 0x0303, /**< Response Code */
    BLE_IDC_IDD_STATUS_READER_CONTROL_POINT_OP_CODE_RESET_STATUS                            = 0x030C, /**< Resets the status 
                                                                                                      exposed by the IDD 
                                                                                                      Status Changed 
                                                                                                      characteristic. The 
                                                                                                      response to this control 
                                                                                                      point is Response Code */
    BLE_IDC_IDD_STATUS_READER_CONTROL_POINT_OP_CODE_GET_ACTIVE_BOLUS_IDC                    = 0x0330, /**< Gets the IDC of 
                                                                                                      all Active Boluses */
    BLE_IDC_IDD_STATUS_READER_CONTROL_POINT_OP_CODE_GET_ACTIVE_BOLUS_IDC_RESPONSE           = 0x033F, /**< This is the normal 
                                                                                                      response to Get Active 
                                                                                                      Bolus IDC  */
    BLE_IDC_IDD_STATUS_READER_CONTROL_POINT_OP_CODE_GET_ACTIVE_BOLUS_DELIVERY               = 0x0356, /**< Gets information 
                                                                                                      about an Active Bolus 
                                                                                                      identified by the given ID */
    BLE_IDC_IDD_STATUS_READER_CONTROL_POINT_OP_CODE_GET_ACTIVE_BOLUS_DELIVERY_RESPONSE      = 0x0359, /**< This is the normal 
                                                                                                      response to Get Active 
                                                                                                      Bolus Delivery */
    BLE_IDC_IDD_STATUS_READER_CONTROL_POINT_OP_CODE_GET_ACTIVE_BASAL_RATE_DELIVERY          = 0x0365, /**< Gets the current 
                                                                                                      active basal rate setting, 
                                                                                                      including the TBR */
    BLE_IDC_IDD_STATUS_READER_CONTROL_POINT_OP_CODE_GET_ACTIVE_BASAL_RATE_DELIVERY_RESPONSE = 0x036A, /**< This is the normal 
                                                                                                      response to Get Active
                                                                                                      Basal Rate Delivery. */
    BLE_IDC_IDD_STATUS_READER_CONTROL_POINT_OP_CODE_GET_TOTAL_DAILY_INSULIN_STATUS          = 0x0395, /**< Gets the total daily 
                                                                                                      delivered bolus and basal 
                                                                                                      insulin from midnight 
                                                                                                      until now. */
    BLE_IDC_IDD_STATUS_READER_CONTROL_POINT_OP_CODE_GET_TOTAL_DAILY_INSULIN_STATUS_RESPONSE = 0x039A, /**< This is the normal 
                                                                                                      response to Get Total 
                                                                                                      Daily Insulin Status */
    BLE_IDC_IDD_STATUS_READER_CONTROL_POINT_OP_CODE_GET_COUNTER                             = 0x03A6, /**< Gets the value about
                                                                                                      an internal counter of 
                                                                                                      the Insulin Delivery 
                                                                                                      Device */
    BLE_IDC_IDD_STATUS_READER_CONTROL_POINT_OP_CODE_GET_COUNTER_RESPONSE                    = 0x03A9, /**< This is the normal
                                                                                                      response to procedure 
                                                                                                      Get Counter */
    BLE_IDC_IDD_STATUS_READER_CONTROL_POINT_OP_CODE_GET_DELIVERED_INSULIN                   = 0x03C0, /**< Gets the delivered 
                                                                                                      amount of bolus and basal
                                                                                                      insulin since the last 
                                                                                                      rollover of these amounts. */
    BLE_IDC_IDD_STATUS_READER_CONTROL_POINT_OP_CODE_GET_DELIVERED_INSULIN_RESPONSE          = 0x03CF, /**< This is the normal 
                                                                                                      response to procedure 
                                                                                                      Get Delivered Insulin */
    BLE_IDC_IDD_STATUS_READER_CONTROL_POINT_OP_CODE_GET_INSULIN_ON_BOARD                    = 0x03F3, /**< Gets the insulin 
                                                                                                      on board, which has 
                                                                                                      been delivered by the 
                                                                                                      Insulin Delivery Device. 
                                                                                                      The normal response to 
                                                                                                      this control point is Get 
                                                                                                      Insulin On Board Response  */
    BLE_IDC_IDD_STATUS_READER_CONTROL_POINT_OP_CODE_GET_INSULIN_ON_BOARD_RESPONSE           = 0x03FC, /**< This is the normal 
                                                                                                      response to procedure 
                                                                                                      Get Insulin On Board. */
} e_ble_idc_idd_status_reader_control_point_t;

/*******************************************************************************************************************//**
 * @brief The Response Code Values associated with the IDD Status Reader CP.
 ***********************************************************************************************************************/
typedef enum
{
    BLE_IDC_RESPONSE_CODE_SRCP_SUCCESS                  = 0xF0, /**< Normal response for successful procedure. */
    BLE_IDC_RESPONSE_CODE_SRCP_OPCODE_NOT_SUPPORTED     = 0x70, /**< Normal response if unsupported Op Code is received. */
    BLE_IDC_RESPONSE_CODE_SRCP_INVALID_OPERAND          = 0x71, /**< Normal response if Operand received does not meet the 
                                                                requirements of the service. */
    BLE_IDC_RESPONSE_CODE_SRCP_PROCEDURE_NOT_COMPLETED  = 0x72, /**< Normal response if unable to complete a procedure 
                                                                for any reason. */
    BLE_IDC_RESPONSE_CODE_SRCP_PARAMETER_OUT_OF_RANGE   = 0x73, /**< Normal response if Operand received does not meet 
                                                                the range requirements of the service..*/
    BLE_IDC_RESPONSE_CODE_SRCP_PROCEDURE_NOT_APPLICABLE = 0x74, /**< Normal response if the procedure cannot be executed 
                                                                because it is not applicable in the current Server 
                                                                Application context. */
} e_ble_idc_response_code_srcp_t;

/*******************************************************************************************************************//**
 * @brief Op Code enumeration.
***********************************************************************************************************************/
typedef enum 
{
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_RESPONSE_CODE                                        = 0x0F55, /**< Response Code */
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_SET_THERAPY_CONTROL_STATE                            = 0x0F5A, /**< Set the therapy 
                                                                                                             control state of the 
                                                                                                             Insulin Delivery Device*/
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_SET_FLIGHT_MODE                                      = 0x0F66, /**< Activates the flight 
                                                                                                             mode of the Insulin 
                                                                                                             Delivery Device. */
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_SNOOZE_ANNUNCIATION                                  = 0x0F69, /**< Snoozes an 
                                                                                                             annunciation for a limited 
                                                                                                             amount of time. */
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_SNOOZE_ANNUNCIATION_RESPONSE                         = 0x0F96, /**< This is the normal 
                                                                                                             response to Snooze 
                                                                                                             Annunciation. */
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_CONFIRM_ANNUNCIATION                                 = 0x0F99, /**< Confirms an 
                                                                                                             annunciation on the 
                                                                                                             Server Application and 
                                                                                                             removes this specific 
                                                                                                             annunciation from the 
                                                                                                             list of currently active 
                                                                                                             annunciations on the 
                                                                                                             Server Application. */
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_CONFIRM_ANNUNCIATION_RESPONSE                        = 0x0FA5, /**< This is the normal 
                                                                                                             response to Confirm 
                                                                                                             Annunciation. */
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_READ_BASAL_RATE_PROFILE_TEMPLATE                     = 0x0FAA, /**< Reads a specific 
                                                                                                             Basal Rate Profile 
                                                                                                             Template. */
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_READ_BASAL_RATE_PROFILE_TEMPLATE_RESPONSE            = 0x0FC3, /**< This response is 
                                                                                                             used to report one or 
                                                                                                             more time blocks of a 
                                                                                                             Basal Rate Profile 
                                                                                                             Template. */
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_WRITE_BASAL_RATE_PROFILE_TEMPLATE                    = 0x0FCC, /**< Writes a specific 
                                                                                                             Basal Rate Profile 
                                                                                                             Template. */
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_WRITE_BASAL_RATE_PROFILE_TEMPLATE_RESPONSE           = 0x0FF0, /**< This is the normal 
                                                                                                             response to Write Basal 
                                                                                                             Rate Profile Template. */
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_SET_TBR_ADJUSTMENT                                   = 0x0FFF, /**< Sets a new or changes 
                                                                                                             a currently active TBR. The 
                                                                                                             response to this control point 
                                                                                                             is Response Code. */
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_CANCEL_TBR_ADJUSTMENT                                = 0x1111, /**< Cancels a currently active 
                                                                                                             TBR. The response to this control 
                                                                                                             point is Response Code. */
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_GET_TBR_TEMPLATE                                     = 0x111E, /**< Gets the parameters of a 
                                                                                                             specific TBR template. */
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_GET_TBR_TEMPLATE_RESPONSE                            = 0x1122, /**< This is the normal response 
                                                                                                             to Get TBR Template. */
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_SET_TBR_TEMPLATE                                     = 0x112D, /**< Sets the parameters of a 
                                                                                                             specific TBR template. */
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_SET_TBR_TEMPLATE_RESPONSE                            = 0x1144, /**< This is the normal 
                                                                                                             response to Set TBR Template. */
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_SET_BOLUS                                            = 0x114B, /**< Sets a bolus with the 
                                                                                                             specified parameters. The normal
                                                                                                             response to this control point 
                                                                                                             is Set Bolus Response. */
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_SET_BOLUS_RESPONSE                                   = 0x1177, /**< This is the normal response 
                                                                                                             to Set Bolus. */
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_CANCEL_BOLUS                                         = 0x1178, /**< Cancels a bolus with the 
                                                                                                             specified Bolus ID. The normal 
                                                                                                             response to this control point 
                                                                                                             is Cancel Bolus Response. */
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_CANCEL_BOLUS_RESPONSE                                = 0x1187, /**< This is the normal response
                                                                                                             to Cancel Bolus. */
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_GET_AVAILABLE_BOLUSES                                = 0x1188, /**< Gets the currently available
                                                                                                             bolus types. The normal response 
                                                                                                             to this control point is Get 
                                                                                                             Available Boluses Response. */
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_GET_AVAILABLE_BOLUSES_RESPONSE                       = 0x11B4, /**< This is the normal response
                                                                                                             to Get Available Boluses. */
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_GET_BOLUS_TEMPLATE                                   = 0x11BB, /**< Gets the parameters of a
                                                                                                             specific bolus template. */
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_GET_BOLUS_TEMPLATE_RESPONSE                          = 0x11D2, /**< This is the normal 
                                                                                                             response to Get Bolus 
                                                                                                             Template. */
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_SET_BOLUS_TEMPLATE                                   = 0x11DD, /**< Sets the parameters of a 
                                                                                                             specific bolus template. */
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_SET_BOLUS_TEMPLATE_RESPONSE                          = 0x11E1, /**< This is the normal response 
                                                                                                             to Set Bolus Template. */
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_GET_TEMPLATE_STATUS_AND_DETAILS                      = 0x11EE, /**< Gets the status and details 
                                                                                                             of all the supported template types */
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_GET_TEMPLATE_STATUS_AND_DETAILS_RESPONSE             = 0x1212, /**< This is the normal response 
                                                                                                             to Get Template Status and Details */
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_RESET_TEMPLATE_STATUS                                = 0x121D, /**< Resets the status of one or 
                                                                                                             many templates by marking them as 
                                                                                                             Not Configured. */
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_RESET_TEMPLATE_STATUS_RESPONSE                       = 0x1221, /**< This is the normal response 
                                                                                                             to Reset Template Status. */
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_ACTIVATE_PROFILE_TEMPLATES                           = 0x122E, /**< The normal response to 
                                                                                                             this control point is Activate 
                                                                                                             Profile Templates Response. */
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_ACTIVATE_PROFILE_TEMPLATES_RESPONSE                  = 0x1247, /**< This is the normal 
                                                                                                             response to Activate 
                                                                                                             Profile Templates. */
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_GET_ACTIVATED_PROFILE_TEMPLATES                      = 0x1248, /**< Gets all the 
                                                                                                             currently activated 
                                                                                                             profile templates */
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_GET_ACTIVATED_PROFILE_TEMPLATES_RESPONSE             = 0x1274, /**< This is the 
                                                                                                             normal response to 
                                                                                                             Get Activated Profile 
                                                                                                             Templates. */
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_START_PRIMING                                        = 0x127B, /**< Starts the 
                                                                                                             priming of the 
                                                                                                             fluidic path of 
                                                                                                             the Insulin Delivery 
                                                                                                             Device with the provided 
                                                                                                             amount of insulin. */
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_STOP_PRIMING                                         = 0x1284, /**< Stops the priming 
                                                                                                             of the fluidic path of 
                                                                                                             the Insulin Delivery 
                                                                                                             Device immediately. */
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_SET_INITIAL_RESERVOIR_FILL_LEVEL                     = 0x128B, /**< Sets the initial 
                                                                                                             fill level of the 
                                                                                                             reservoir after 
                                                                                                             refill or replacement. */
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_RESET_RESERVOIR_INSULIN_OPERATION_TIME               = 0x12B7, /**< Resets the counter 
                                                                                                             Reservoir Insulin 
                                                                                                             Operation Time */
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_READ_ISF_PROFILE_TEMPLATE                            = 0x12B8, /**< The response to 
                                                                                                             this control point is 
                                                                                                             Response Code. */
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_READ_ISF_PROFILE_TEMPLATE_RESPONSE                   = 0x12D1, /**< This response is 
                                                                                                             used to report one or 
                                                                                                             more time blocks of an 
                                                                                                             ISF Profile Template. */
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_WRITE_ISF_PROFILE_TEMPLATE                           = 0x12DE, /**< The normal response 
                                                                                                             to this control point is 
                                                                                                             Write ISF Profile Template 
                                                                                                             Response. */
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_WRITE_ISF_PROFILE_TEMPLATE_RESPONSE                  = 0x12E2, /**< This is the normal 
                                                                                                             response to Write ISF 
                                                                                                             Profile Template. */
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_READ_I2CHO_RATIO_PROFILE_TEMPLATE                    = 0x12ED, /**< The response to this 
                                                                                                             control point is Response 
                                                                                                             Code. */
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_READ_I2CHO_RATIO_PROFILE_TEMPLATE_RESPONSE           = 0x1414, /**< This response is used 
                                                                                                             to report one or more time 
                                                                                                             blocks of an I:CHO Ratio 
                                                                                                             Profile Template. */
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_WRITE_I2CHO_RATIO_PROFILE_TEMPLATE                   = 0x141B, /**< The normal response 
                                                                                                             to this control point is 
                                                                                                             Write I2CHO Ratio Profile 
                                                                                                             Template Response. */
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_WRITE_I2CHO_RATIO_PROFILE_TEMPLATE_RESPONSE          = 0x1427, /**< This is the normal 
                                                                                                             response to Write I2CHO 
                                                                                                             Ratio Profile Template. */
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_READ_TARGET_GLUCOSE_RANGE_PROFILE_TEMPLATE           = 0x1428, /**< Reads a specific Target 
                                                                                                             Glucose Range Profile Template.
                                                                                                             The response to this control 
                                                                                                             point is Response Code. */
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_READ_TARGET_GLUCOSE_RANGE_PROFILE_TEMPLATE_RESPONSE  = 0x1441, /**<This response is used to 
                                                                                                             report one or more time blocks 
                                                                                                             of a Target Glucose Range 
                                                                                                             Profile Template. */
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_WRITE_TARGET_GLUCOSE_RANGE_PROFILE_TEMPLATE          = 0x144E, /**< Writes a specific 
                                                                                                             Target Glucose Range Profile 
                                                                                                             Template. */
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_WRITE_TARGET_GLUCOSE_RANGE_PROFILE_TEMPLATE_RESPONSE = 0x1472, /**< This is the normal 
                                                                                                             response to Write Target
                                                                                                             Glucose Range Profile 
                                                                                                             Template. */
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_GET_MAX_BOLUS_AMOUNT                                 = 0x147D, /**< Gets the maximum 
                                                                                                             bolus amount that can be 
                                                                                                             delivered in a single bolus. */
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_GET_MAX_BOLUS_AMOUNT_RESPONSE                        = 0x1482, /**< This is the normal 
                                                                                                             response to Get Max 
                                                                                                             Bolus Amount. */
    BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_SET_MAX_BOLUS_AMOUNT                                 = 0x148D, /**< Sets the maximum 
                                                                                                             bolus amount that can be 
                                                                                                             delivered in a single bolus */
} e_ble_idc_idd_command_control_point_t;

/*******************************************************************************************************************//**
 * @brief The Response Code Values associated with the IDD Command CP.
 ***********************************************************************************************************************/
typedef enum
{
    BLE_IDC_RESPONSE_CODE_CCP_SUCCESS                      = 0xF0, /**< Normal response for successful procedure. */
    BLE_IDC_RESPONSE_CODE_CCP_OPCODE_NOT_SUPPORTED         = 0x70, /**< Normal response if unsupported Op Code is 
                                                                   received. */
    BLE_IDC_RESPONSE_CODE_CCP_INVALID_OPERAND              = 0x71, /**< Normal response if Operand received does not meet 
                                                                   the requirements of the service. */
    BLE_IDC_RESPONSE_CODE_CCP_PROCEDURE_NOT_COMPLETED      = 0x72, /**< Normal response if unable to complete a procedure 
                                                                   for any reason. */
    BLE_IDC_RESPONSE_CODE_CCP_PARAMETER_OUT_OF_RANGE       = 0x73, /**< Normal response if Operand received does not meet 
                                                                   the range requirements of the service..*/
    BLE_IDC_RESPONSE_CODE_CCP_PROCEDURE_NOT_APPLICABLE     = 0x74, /**< Normal response if the procedure cannot be executed 
                                                                   because it is not applicable in the current Server 
                                                                   Application context. */
    BLE_IDC_RESPONSE_CODE_CCP_PLAUSIBILITY_CHECK_FAILED    = 0x75, /**< Normal response if a transaction consisting of 
                                                                   several procedures was not completed by the Server 
                                                                   because the parameters provided by the Client to 
                                                                   perform this transaction has been invalid or 
                                                                   inconsistent. */
    BLE_IDC_RESPONSE_CODE_CCP_MAXIMUM_BOLUS_NUMBER_REACHED = 0x76, /**< Normal response if the maximum number of 
                                                                   boluses of a specific type is reached when executing 
                                                                   the Set Bolus procedure. */
} e_ble_idc_response_code_ccp_t;

/*******************************************************************************************************************//**
 * @brief Response Op Code enumeration.
***********************************************************************************************************************/
typedef enum 
{
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_RESPONSE_CODE                                        = 0x0F55, /**< Response Code */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_SET_THERAPY_CONTROL_STATE                            = 0x0F5A, /**< Set the therapy 
                                                                                                             control state of the 
                                                                                                             Insulin Delivery Device */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_SET_FLIGHT_MODE                                      = 0x0F66, /**< Activates the flight 
                                                                                                             mode of the Insulin 
                                                                                                             Delivery Device. */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_SNOOZE_ANNUNCIATION                                  = 0x0F69, /**< Snoozes an 
                                                                                                             annunciation for 
                                                                                                             a limited amount 
                                                                                                             of time. */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_SNOOZE_ANNUNCIATION_RESPONSE                         = 0x0F96, /**< This is the 
                                                                                                             normal response 
                                                                                                             to Snooze 
                                                                                                             Annunciation. */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_CONFIRM_ANNUNCIATION                                 = 0x0F99, /**< Confirms an 
                                                                                                             annunciation on 
                                                                                                             the Server 
                                                                                                             Application and 
                                                                                                             removes this 
                                                                                                             specific annunciation 
                                                                                                             from the list of 
                                                                                                             currently active 
                                                                                                             annunciations on the 
                                                                                                             Server Application. */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_CONFIRM_ANNUNCIATION_RESPONSE                        = 0x0FA5, /**< This is the normal 
                                                                                                             response to Confirm 
                                                                                                             Annunciation. */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_READ_BASAL_RATE_PROFILE_TEMPLATE                     = 0x0FAA, /**< Reads a specific 
                                                                                                             Basal Rate Profile 
                                                                                                             Template. */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_READ_BASAL_RATE_PROFILE_TEMPLATE_RESPONSE            = 0x0FC3, /**< This response is 
                                                                                                             used to report one or 
                                                                                                             more time blocks of a 
                                                                                                             Basal Rate Profile 
                                                                                                             Template. */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_WRITE_BASAL_RATE_PROFILE_TEMPLATE                    = 0x0FCC, /**< Writes a specific
                                                                                                             Basal Rate Profile 
                                                                                                             Template. */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_WRITE_BASAL_RATE_PROFILE_TEMPLATE_RESPONSE           = 0x0FF0, /**< This is the normal 
                                                                                                             response to Write Basal 
                                                                                                             Rate Profile Template. */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_SET_TBR_ADJUSTMENT                                   = 0x0FFF, /**< Sets a new or 
                                                                                                             changes a currently 
                                                                                                             active TBR. The response 
                                                                                                             to this control point is 
                                                                                                             Response Code. */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_CANCEL_TBR_ADJUSTMENT                                = 0x1111, /**< Cancels a currently 
                                                                                                             active TBR. The response 
                                                                                                             to this control point is
                                                                                                             Response Code. */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_GET_TBR_TEMPLATE                                     = 0x111E, /**< Gets the parameters 
                                                                                                             of a specific TBR template. */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_GET_TBR_TEMPLATE_RESPONSE                            = 0x1122, /**< This is the normal 
                                                                                                             response to Get Bolus 
                                                                                                             Template. */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_SET_TBR_TEMPLATE                                     = 0x112D, /**< Sets the parameters of 
                                                                                                             a specific TBR template. */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_SET_TBR_TEMPLATE_RESPONSE                            = 0x1144, /**< This is the normal 
                                                                                                             response to Set TBR Template. */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_SET_BOLUS                                            = 0x114B, /**< Sets a bolus with the 
                                                                                                             specified parameters. The 
                                                                                                             normal response to this 
                                                                                                             control point is Set Bolus 
                                                                                                             Response. */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_SET_BOLUS_RESPONSE                                   = 0x1177, /**< This is the normal 
                                                                                                             response to Set Bolus. */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_CANCEL_BOLUS                                         = 0x1178, /**< Cancels a bolus with 
                                                                                                             the specified Bolus ID. 
                                                                                                             The normal response to 
                                                                                                             this control point is 
                                                                                                             Cancel Bolus Response. */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_CANCEL_BOLUS_RESPONSE                                = 0x1187, /**< This is the normal 
                                                                                                             response to Cancel Bolus. */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_GET_AVAILABLE_BOLUSES                                = 0x1188, /**< Gets the currently 
                                                                                                             available bolus types. 
                                                                                                             The normal response to this 
                                                                                                             control point is Get Available 
                                                                                                             Boluses Response. */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_GET_AVAILABLE_BOLUSES_RESPONSE                       = 0x11B4, /**< This is the normal 
                                                                                                             response to Get Available
                                                                                                             Boluses. */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_GET_BOLUS_TEMPLATE                                   = 0x11BB, /**< Gets the parameters of 
                                                                                                             a specific bolus template. */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_GET_BOLUS_TEMPLATE_RESPONSE                          = 0x11D2, /**< This is the normal 
                                                                                                             response to Get Bolus 
                                                                                                             Template. */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_SET_BOLUS_TEMPLATE                                   = 0x11DD, /**< Sets the parameters 
                                                                                                             of a specific bolus 
                                                                                                             template. */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_SET_BOLUS_TEMPLATE_RESPONSE                          = 0x11E1, /**< This is the normal 
                                                                                                             response to Set Bolus 
                                                                                                             Template. */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_GET_TEMPLATE_STATUS_AND_DETAILS                      = 0x11EE, /**< Gets the status and 
                                                                                                             details of all the supported 
                                                                                                             template types */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_GET_TEMPLATE_STATUS_AND_DETAILS_RESPONSE             = 0x1212, /**< This is the normal 
                                                                                                             response to Get Template 
                                                                                                             Status and Details */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_RESET_TEMPLATE_STATUS                                = 0x121D, /**< Resets the status of 
                                                                                                             one or many templates by 
                                                                                                             marking them as Not 
                                                                                                             Configured. */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_RESET_TEMPLATE_STATUS_RESPONSE                       = 0x1221, /**< This is the normal 
                                                                                                             response to Reset Template 
                                                                                                             Status. */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_ACTIVATE_PROFILE_TEMPLATES                           = 0x122E, /**< The normal response to 
                                                                                                             this control point is Activate 
                                                                                                             Profile Templates Response. */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_ACTIVATE_PROFILE_TEMPLATES_RESPONSE                  = 0x1247, /**< This is the normal 
                                                                                                             response to Activate Profile 
                                                                                                             Templates. */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_GET_ACTIVATED_PROFILE_TEMPLATES                      = 0x1248, /**< Gets all the currently 
                                                                                                             activated profile templates */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_GET_ACTIVATED_PROFILE_TEMPLATES_RESPONSE             = 0x1274, /**< This is the normal response 
                                                                                                             to Get Activated Profile 
                                                                                                             Templates. */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_START_PRIMING                                        = 0x127B, /**< Starts the priming of the 
                                                                                                             fluidic path of the Insulin 
                                                                                                             Delivery Device with the 
                                                                                                             provided amount of insulin. */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_STOP_PRIMING                                         = 0x1284, /**< Stops the priming of the 
                                                                                                             fluidic path of the Insulin 
                                                                                                             Delivery Device immediately. */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_SET_INITIAL_RESERVOIR_FILL_LEVEL                     = 0x128B, /**< Sets the initial fill 
                                                                                                             level of the reservoir after 
                                                                                                             refill or replacement. */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_RESET_RESERVOIR_INSULIN_OPERATION_TIME               = 0x12B7, /**< Resets the counter 
                                                                                                             Reservoir Insulin Operation 
                                                                                                             Time */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_READ_ISF_PROFILE_TEMPLATE                            = 0x12B8, /**< The response to this 
                                                                                                             control point is Response 
                                                                                                             Code. */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_READ_ISF_PROFILE_TEMPLATE_RESPONSE                   = 0x12D1, /**< This response is used 
                                                                                                             to report one or more time 
                                                                                                             blocks of an ISF
                                                                                                             Profile Template. */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_WRITE_ISF_PROFILE_TEMPLATE                           = 0x12DE, /**< The normal response to 
                                                                                                             this control point is Write 
                                                                                                             ISF Profile Template Response. */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_WRITE_ISF_PROFILE_TEMPLATE_RESPONSE                  = 0x12E2, /**< This is the normal 
                                                                                                             response to Write ISF Profile
                                                                                                             Template. */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_READ_I2CHO_RATIO_PROFILE_TEMPLATE                    = 0x12ED, /**< The response to this 
                                                                                                             control point is Response 
                                                                                                             Code. */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_READ_I2CHO_RATIO_PROFILE_TEMPLATE_RESPONSE           = 0x1414, /**< This response is used 
                                                                                                             to report one or more time 
                                                                                                             blocks of an I:CHO Ratio 
                                                                                                             Profile Template. */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_WRITE_I2CHO_RATIO_PROFILE_TEMPLATE                   = 0x141B, /**< The normal response 
                                                                                                             to this control point is 
                                                                                                             Write I2CHO Ratio Profile 
                                                                                                             Template Response. */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_WRITE_I2CHO_RATIO_PROFILE_TEMPLATE_RESPONSE          = 0x1427, /**< This is the normal 
                                                                                                             response to Write I2CHO 
                                                                                                             Ratio Profile Template. */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_READ_TARGET_GLUCOSE_RANGE_PROFILE_TEMPLATE           = 0x1428, /**< Reads a specific 
                                                                                                             Target Glucose Range 
                                                                                                             Profile Template. The 
                                                                                                             response to this control
                                                                                                             point is Response Code. */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_READ_TARGET_GLUCOSE_RANGE_PROFILE_TEMPLATE_RESPONSE  = 0x1441, /**<This response is used
                                                                                                             to report one or more time 
                                                                                                             blocks of a Target Glucose 
                                                                                                             Range Profile Template. */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_WRITE_TARGET_GLUCOSE_RANGE_PROFILE_TEMPLATE          = 0x144E, /**< Writes a specific 
                                                                                                             Target Glucose Range 
                                                                                                             Profile Template. */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_WRITE_TARGET_GLUCOSE_RANGE_PROFILE_TEMPLATE_RESPONSE = 0x1472, /**< This is the normal 
                                                                                                             response to Write 
                                                                                                             Target Glucose Range 
                                                                                                             Profile Template. */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_GET_MAX_BOLUS_AMOUNT                                 = 0x147D, /**< Gets the maximum 
                                                                                                             bolus amount that can 
                                                                                                             be delivered in a 
                                                                                                             single bolus. */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_GET_MAX_BOLUS_AMOUNT_RESPONSE                        = 0x1482, /**< This is the 
                                                                                                             normal response to 
                                                                                                             Get Max Bolus Amount. */
    BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_SET_MAX_BOLUS_AMOUNT                                 = 0x148D, /**< Sets the maximum 
                                                                                                             bolus amount that can 
                                                                                                             be delivered in a 
                                                                                                             single bolus */
} e_ble_idc_idd_command_data_t;

/*******************************************************************************************************************//**
 * @brief Event Type enumeration.
***********************************************************************************************************************/
typedef enum 
{
    BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_REFERENCE_TIME                                           = 0x000F, /**< Reference 
                                                                                                           Time */
    BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_REFERENCE_TIME_BASE_OFFSET                               = 0x0033, /**< Reference 
                                                                                                           Time Base Offset */
    BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_BOLUS_CALCULATED_PART_1_OF_2                             = 0x003C, /**< Bolus 
                                                                                                           Calculated 
                                                                                                           Part 1 of 2 */
    BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_BOLUS_CALCULATED_PART_2_OF_2                             = 0x0055, /**< Bolus 
                                                                                                           Calculated 
                                                                                                           Part 2 of 2 */
    BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_BOLUS_PROGRAMMED_PART_1_OF_2                             = 0x005A, /**< Bolus 
                                                                                                           Programmed 
                                                                                                           Part 1 of 2*/
    BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_BOLUS_PROGRAMMED_PART_2_OF_2                             = 0x0066, /**< Bolus 
                                                                                                           Programmed
                                                                                                           Part 2 of 2 */
    BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_BOLUS_DELIVERED_PART_1_OF_2                              = 0x0069, /**< Bolus 
                                                                                                           Delivered 
                                                                                                           Part 1 of 2 */
    BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_BOLUS_DELIVERED_PART_2_OF_2                              = 0x0096, /**< Bolus 
                                                                                                           Delivered 
                                                                                                           Part 2 of 2 */
    BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_DELIVERED_BASAL_RATE_CHANGED                             = 0x0099, /**< Delivered 
                                                                                                           Basal Rate 
                                                                                                           Changed */
    BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_TBR_ADJUSTMENT_STARTED                                   = 0x00A5, /**< TBR 
                                                                                                           Adjustment 
                                                                                                           Started */
    BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_TBR_ADJUSTMENT_ENDED                                     = 0x00AA, /**< TBR 
                                                                                                           Adjustment 
                                                                                                           Ended */
    BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_TBR_ADJUSTMENT_CHANGED                                   = 0x00C3, /**< TBR 
                                                                                                           Adjustment 
                                                                                                           Changed2 */
    BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_PROFILE_TEMPLATE_ACTIVATED                               = 0x00CC, /**< Profile 
                                                                                                           Template 
                                                                                                           Activated */
    BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_BASAL_RATE_PROFILE_TEMPLATE_TIME_BLOCK_CHANGED           = 0x00F0, /**< Basal 
                                                                                                           Rate Profile 
                                                                                                           Template Time 
                                                                                                           Block Changed */
    BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_TOTAL_DAILY_INSULIN_DELIVERY                             = 0x00FF, /**< Total Daily 
                                                                                                           Insulin Delivery */
    BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_THERAPY_CONTROL_STATE_CHANGED                            = 0x0303, /**< Therapy 
                                                                                                           Control State
                                                                                                           Changed */
    BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_OPERATIONAL_STATE_CHANGED                                = 0x030C, /**< Operational 
                                                                                                           State Changed */
    BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_RESERVOIR_REMAINING_AMOUNT_CHANGED                       = 0x0330, /**< Reservoir R
                                                                                                           emaining Amount 
                                                                                                           Changed */
    BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_ANNUNCIATION_STATUS_CHANGED_PART_1_OF_2                  = 0x033F, /**< Annunciation 
                                                                                                           Status Changed 
                                                                                                           Part 1 of 2 */
    BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_ANNUNCIATION_STATUS_CHANGED_PART_2_OF_2                  = 0x0356, /**< Annunciation 
                                                                                                           Status Changed 
                                                                                                           Part 2 of 2 */
    BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_ISF_PROFILE_TEMPLATE_TIME_BLOCK_CHANGED                  = 0x0359, /**< ISF Profile 
                                                                                                           Template Time
                                                                                                           Block Changed */
    BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_I2CHO_RATIO_PROFILE_TEMPLATE_TIME_BLOCK_CHANGED          = 0x0365, /**< I2CHO Ratio 
                                                                                                           Profile Template 
                                                                                                           Time Block Changed */
    BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_TARGET_GLUCOSE_RANGE_PROFILE_TEMPLATE_TIME_BLOCK_CHANGED = 0x036A, /**< Target Glucose 
                                                                                                           Range Profile 
                                                                                                           Template Time 
                                                                                                           Block Changed */
    BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_PRIMING_STARTED                                          = 0x0395, /**< Priming 
                                                                                                           Started */
    BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_PRIMING_DONE                                             = 0x039A, /**< Priming 
                                                                                                           Done */
    BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_DATA_CORRUPTION                                          = 0x03A6, /**< Data 
                                                                                                           Corruption */
    BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_POINTER_EVENT                                            = 0x03A9, /**< Pointer 
                                                                                                           Event */
    BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_BOLUS_TEMPLATE_CHANGED_PART_1_OF_2                       = 0x03C0, /**< Bolus 
                                                                                                           Template 
                                                                                                           Changed Part 
                                                                                                           1 of 2 */
    BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_BOLUS_TEMPLATE_CHANGED_PART_2_OF_2                       = 0x03CF, /**< Bolus 
                                                                                                           Template 
                                                                                                           Changed
                                                                                                           Part 2 of 2 */
    BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_TBR_TEMPLATE_CHANGED                                     = 0x03F3, /**< TBR 
                                                                                                           Template 
                                                                                                           Changed */
    BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_MAX_BOLUS_AMOUNT_CHANGED                                 = 0x03FC, /**< Max Bolus 
                                                                                                           Amount Changed */
} e_ble_idc_idd_history_data_t;


/*******************************************************************************************************************//**
 * @brief Bolus Value Selection.
***********************************************************************************************************************/
typedef enum
{
    BLE_IDC_IDD_SRCP_OPRAND_BOLUS_VALUE_SEL_PROGRAMMED = 0x0F, /**< programmed */
    BLE_IDC_IDD_SRCP_OPRAND_BOLUS_VALUE_SEL_REMAINING  = 0x33, /**< remaining */
    BLE_IDC_IDD_SRCP_OPRAND_BOLUS_VALUE_SEL_DELIVERED  = 0x3C  /**< delivered */
}e_ble_idc_idd_srcp_operand_bolus_value_sel_t;

/*******************************************************************************************************************//**
 * @brief Bolus Type values
***********************************************************************************************************************/
typedef enum
{
    BLE_IDC_IDD_SRCP_OPRAND_BOLUS_TYPE_UNDETERMINED = 0x0F, /**< Undetermined */
    BLE_IDC_IDD_SRCP_OPRAND_BOLUS_TYPE_FAST         = 0x33, /**< Fast */
    BLE_IDC_IDD_SRCP_OPRAND_BOLUS_TYPE_EXTENDED     = 0x3C, /**< Extended */
    BLE_IDC_IDD_SRCP_OPRAND_BOLUS_TYPE_MULTIWAVE    = 0x55  /**< Multiwave */
}e_ble_idc_idd_srcp_operand_bolus_type_values_t;

/*******************************************************************************************************************//**
 * @brief Bolus Activation Type
***********************************************************************************************************************/
typedef enum
{
    BLE_IDC_IDD_SRCP_OPRAND_BOLUS_ACTIVATION_TYPE_UNDETERMINED                       = 0x0F, /**< The activation type 
                                                                                             is undetermined. */
    BLE_IDC_IDD_SRCP_OPRAND_BOLUS_ACTIVATION_TYPE_MANUAL_BOLUS                       = 0x33, /**< The bolus was defined 
                                                                                             by the user. */
    BLE_IDC_IDD_SRCP_OPRAND_BOLUS_ACTIVATION_TYPE_RECOMMENTED_BOLUS                  = 0x3C, /**< The bolus was recommended 
                                                                                             by a calculation algorithm */
    BLE_IDC_IDD_SRCP_OPRAND_BOLUS_ACTIVATION_TYPE_MANUALLY_CHANGED_RECOMMENTED_BOLUS = 0x55, /**< The user changed a 
                                                                                             recommended bolus. */
    BLE_IDC_IDD_SRCP_OPRAND_BOLUS_ACTIVATION_COMMANDED_BOLUS                         = 0x5A  /**< The bolus was activated 
                                                                                             without user interaction */
}e_ble_idc_idd_srcp_operand_bolus_activation_type_t;

/*******************************************************************************************************************//**
 * @brief TBR Type Values
***********************************************************************************************************************/
typedef enum
{
    BLE_IDC_IDD_SRCP_OPRAND_TBR_TYPE_UNDETERMINED = 0x0F, /**< The TBR type is undetermined. */
    BLE_IDC_IDD_SRCP_OPRAND_TBR_TYPE_ABSOLUTE     = 0x33, /**< The TBR type is absolute. */
    BLE_IDC_IDD_SRCP_OPRAND_TBR_TYPE_RELATIVE     = 0x3C, /**< The TBR type is relative */
}e_ble_idc_idd_srcp_operand_tbr_type_values_t;

/*******************************************************************************************************************//**
 * @brief Basal Delivery Context Values
***********************************************************************************************************************/
typedef enum
{
    BLE_IDC_IDD_SRCP_OPRAND_BASAL_DELIVERY_CONTEXT_UNDETERMINED   = 0x0F, /**< The Basal Delivery Context 
                                                                          is undetermined. */
    BLE_IDC_IDD_SRCP_OPRAND_BASAL_DELIVERY_CONTEXT_DEVICE_BASED   = 0x33, /**< The current basal rate was set 
                                                                          directly on the Insulin Delivery Device. */
    BLE_IDC_IDD_SRCP_OPRAND_BASAL_DELIVERY_CONTEXT_REMOTE_CONTROL = 0x3C, /**< The current basal rate was set 
                                                                          via a remote control */
    BLE_IDC_IDD_SRCP_OPRAND_BASAL_DELIVERY_CONTEXT_AP_CONTROL     = 0x55, /**< The Basal Delivery Context is 
                                                                          Artificial Pancreas (AP) Controller */
}e_ble_idc_idd_srcp_operand_basel_delivery_context_t;

/*******************************************************************************************************************//**
 * @brief Counter Type Values
***********************************************************************************************************************/
typedef enum
{
    BLE_IDC_IDD_SRCP_OPRAND_COUNTER_TYPE_LIFETIME               = 0x0F, /**< This counter provides the lifetime of the 
                                                                        Insulin Delivery Device. */
    BLE_IDC_IDD_SRCP_OPRAND_COUNTER_TYPE_WARRANTY_TIME          = 0x33, /**< This counter provides the warranty time of 
                                                                        the Insulin Delivery Device. */
    BLE_IDC_IDD_SRCP_OPRAND_COUNTER_TYPE_LOANER_TIME            = 0x3C, /**< This counter provides the loaner time of 
                                                                        the Insulin Delivery Device. */
    BLE_IDC_IDD_SRCP_OPRAND_COUNTER_TYPE_INSULIN_OPERATION_TIME = 0x55, /**< This counter provides the operation time 
                                                                        of the insulin in the reservoir. */
}e_ble_idc_idd_srcp_operand_counter_type_values_t;

/*******************************************************************************************************************//**
 * @brief Counter Value Selection value
***********************************************************************************************************************/
typedef enum
{
    BLE_IDC_IDD_SRCP_OPRAND_COUNTER_VALUE_REMAINING = 0x0F, /**< Remaining. */
    BLE_IDC_IDD_SRCP_OPRAND_COUNTER_VALUE_ELAPSED   = 0x33, /**< Elapsed. */
}e_ble_idc_idd_srcp_operand_counter_value_sel_t;

/*******************************************************************************************************************//**
 * @brief IDD Command CP Response Code values
***********************************************************************************************************************/
typedef enum
{
    BLE_IDC_IDD_CCP_OPRAND_RESPONSE_CODE_SUCCESS        = 0x0F, /**< Normal response for successful procedure. */
    BLE_IDC_IDD_CCP_OPRAND_OP_CODE_NOT_SUPPORTED        = 0x70, /**< Normal response if unsupported Op Code is 
                                                                received. */
    BLE_IDC_IDD_CCP_OPRAND_INVALID_OPERAND              = 0x71,/**< Normal response if Operand received does not meet 
                                                               the requirements of the service. */
    BLE_IDC_IDD_CCP_OPRAND_PROCEDURE_NOT_COMPLETED      = 0x72,/**< Normal response if unable to complete a procedure 
                                                               for any reason. */
    BLE_IDC_IDD_CCP_OPRAND_PARAMETER_OUT_OF_RANGE       = 0x73,/**< Normal response if Operand received does not meet 
                                                               the range requirements of the service. */
    BLE_IDC_IDD_CCP_OPRAND_PROCEDURE_NOT_APPLICABLE     = 0x74,/**< Normal response if the procedure cannot be executed 
                                                               because it is not applicable in the current Server 
                                                               Application context. */
    BLE_IDC_IDD_CCP_OPRAND_PLAUSIBILITY_CHECK_FAILED    = 0x75,/**< Normal response if a transaction consisting of several 
                                                               procedures was not completed by the Server because the 
                                                               parameters provided by the Client to perform this 
                                                               transaction has been invalid or inconsistent. */
    BLE_IDC_IDD_CCP_OPRAND_MAXIMUM_BOLUS_NUMBER_REACHED = 0x76,/**< Normal response if the maximum number of 
                                                               boluses of a specific type is reached when 
                                                               executing the Set Bolus procedure. */
}e_ble_idc_idd_ccp_operand_response_code_t;



/*******************************************************************************************************************//**
 * @brief IDD Command CP Bolus Activation Type values
***********************************************************************************************************************/
typedef enum
{
    BLE_IDC_IDD_CCP_OPRAND_UNDETERMINED                       = 0x0F, /**< The activation type is undetermined. */
    BLE_IDC_IDD_CCP_OPRAND_MANUAL_BOLUS                       = 0x33, /**< The bolus was defined by the user. */
    BLE_IDC_IDD_CCP_OPRAND_RECOMMENDED_BOLUS                  = 0x3C,/**< The bolus was recommended by a calculation 
                                                                     algorithm (e.g., a bolus calculator) 
                                                                     and confirmed by the user. */
    BLE_IDC_IDD_CCP_OPRAND_MANUALLY_CHANGED_RECOMMENDED_BOLUS = 0x55,/**< The user changed a recommended bolus. */
    BLE_IDC_IDD_CCP_OPRAND_COMMANDED_BOLUS                    = 0x5A,/**< The bolus was activated without user 
                                                                     interaction */
}e_ble_idc_idd_ccp_operand_bolus_activation_type_t;

/*******************************************************************************************************************//**
 * @brief Insulin Delivery Service attribute handles.
***********************************************************************************************************************/
typedef struct 
{
    st_ble_gatt_hdl_range_t service_range;                                /**< Insulin Delivery Service range */
    uint16_t                idd_status_changed_char_val_hdl;              /**< IDD Status Changed characteristic value 
                                                                          handle */
    uint16_t                idd_status_changed_cli_cnfg_hdl;              /**< IDD Status Changed characteristic Client
                                                                          Characteristic Configuration descriptor 
                                                                          handle */
    uint16_t                idd_status_char_val_hdl;                      /**< IDD Status characteristic value handle */
    uint16_t                idd_status_cli_cnfg_hdl;                      /**< IDD Status characteristic Client 
                                                                          Characteristic Configuration descriptor 
                                                                          handle */
    uint16_t                idd_annunciation_status_char_val_hdl;         /**< IDD Annunciation Status characteristic 
                                                                          value handle */
    uint16_t                idd_annunciation_status_cli_cnfg_hdl;         /**< IDD Annunciation Status characteristic 
                                                                          Client Characteristic Configuration 
                                                                          descriptor handle */
    uint16_t                idd_features_char_val_hdl;                    /**< IDD Features characteristic value handle */
    uint16_t                idd_status_reader_control_point_char_val_hdl; /**< IDD Status Reader Control Point 
                                                                          characteristic value handle */
    uint16_t                idd_status_reader_control_point_cli_cnfg_hdl; /**< IDD Status Reader Control Point 
                                                                          characteristic Client Characteristic 
                                                                          Configuration descriptor handle */
    uint16_t                idd_command_control_point_char_val_hdl;       /**< IDD Command Control Point 
                                                                          characteristic value handle */
    uint16_t                idd_command_control_point_cli_cnfg_hdl;       /**< IDD Command Control Point 
                                                                          characteristic Client Characteristic 
                                                                          Configuration descriptor handle */
    uint16_t                idd_command_data_char_val_hdl;                /**< IDD Command Data characteristic 
                                                                          value handle */
    uint16_t                idd_command_data_cli_cnfg_hdl;                /**< IDD Command Data characteristic 
                                                                          Client Characteristic Configuration 
                                                                          descriptor handle */
    uint16_t                idd_record_access_control_point_char_val_hdl; /**< IDD Record Access Control Point 
                                                                          characteristic value handle */
    uint16_t                idd_record_access_control_point_cli_cnfg_hdl; /**< IDD Record Access Control Point 
                                                                          characteristic Client Characteristic 
                                                                          Configuration descriptor handle */
    uint16_t                idd_history_data_char_val_hdl;                /**< IDD History Data characteristic 
                                                                          value handle */
    uint16_t                idd_history_data_cli_cnfg_hdl;                /**< IDD History Data characteristic 
                                                                          Client Characteristic Configuration 
                                                                          descriptor handle */
} st_ble_idc_hdls_t;

/*******************************************************************************************************************//**
 * @brief Insulin Delivery Service initialization parameters.
***********************************************************************************************************************/
typedef struct 
{
    ble_idc_app_cb_t cb; /**< Insulin Delivery Service Client event handler */
} st_ble_idc_init_param_t;

/*******************************************************************************************************************//**
 * @brief Insulin Delivery Service Client connection parameters.
***********************************************************************************************************************/
typedef struct 
{
    st_ble_idc_hdls_t *p_hdls; /**< Insulin Delivery Service handles */
} st_ble_idc_connect_param_t;

/*******************************************************************************************************************//**
 * @brief Insulin Delivery Service disconnection parameters.
***********************************************************************************************************************/
typedef struct 
{
    st_ble_idc_hdls_t *p_hdls; /**< Insulin Delivery Service handles */
} st_ble_idc_disconnect_param_t;

/*******************************************************************************************************************//**
 * @brief IDD Status Reader Control Point Response code operand.
***********************************************************************************************************************/
typedef struct
{
    uint16_t request_opcode;/**< Request Op Code */
    uint8_t  response_code; /**< Response Code Value*/
}st_ble_idc_idd_srcp_response_code_operand_t;

/*******************************************************************************************************************//**
 * @brief IDD Status Reader Control Point Reset status operand.
***********************************************************************************************************************/
typedef struct
{
    bool is_therapy_control_state_changed;      /**< If this bit is set, the therapy control state of the 
                                                Insulin Delivery Device changed. */
    bool is_optional_state_changed;             /**< If this bit is set, the operational state of the 
                                                Insulin Delivery Device changed. */
    bool is_reservoir_status_changed;           /**< If this bit is set, the status of the insulin 
                                                reservoir changed (caused by a reservoir change or the 
                                                delivery of insulin). */
    bool is_annunciation_status_changed;        /**< If this bit is set, a new annunciation was created
                                                by the Server application. */
    bool is_total_daily_insulin_status_changed; /**< If this bit is set, the total daily insulin amount 
                                                changed due to a bolus or basal delivery. The bit shall be
                                                set at the end of an effective delivery. */
    bool is_active_basal_rate_status_changed;   /**< If this bit is set, the current basal rate changed due 
                                                to a new basal rate value (e.g., caused by a changed basal 
                                                rate profile, reaching of a time block with another basal 
                                                rate value or by a TBR). */
    bool is_active_bolus_status_changed;        /**< If this bit is set, a new bolus was initiated or the 
                                                status of current Active Bolus changed. */
    bool is_history_event_recorded;             /**< If this bit is set, a new event has been recorded in 
                                                the history. */
}st_ble_idc_idd_srcp_reset_status_operand_t;

/*******************************************************************************************************************//**
 * @brief IDD Status Reader Control Point Get Active Blus ID Response.
***********************************************************************************************************************/
typedef struct
{
    uint8_t  no_of_active_boluses;/**< Number of Active Boluses */
    uint16_t bolus_id[7];         /**< Bolus ID */
}st_ble_idc_idd_srcp_get_active_bolusids_response_operand_t;

/*******************************************************************************************************************//**
 * @brief IDD Status Reader Control Point Get Active Blus Delivery.
***********************************************************************************************************************/
typedef struct
{
    uint16_t bolus_id;       /**< Bolus ID */
    uint8_t  bolus_value_sel;/**< Bolus Value Selection */
}st_ble_idc_idd_srcp_get_active_bolus_delivery_operand_t;

/*******************************************************************************************************************//**
 * @brief IDD Status Reader Control Point Get Active Blus Delivery.Response
***********************************************************************************************************************/
typedef struct
{
    bool                      is_bolus_delay_time_present;        /**< If this bit is set, the Bolus Delay Time 
                                                                  field is present. */
    bool                      is_bolus_template_number_present;   /**< If this bit is set, the Bolus Template Number 
                                                                  field is present. */
    bool                      is_bolus_activation_type_present;   /**< If this bit is set, the Bolus Activation Type 
                                                                  field is present. */
    bool                      is_bolus_delivery_reason_correction;/**< If this bit is set, the reason for the bolus is 
                                                                  the correction of a high blood glucose level. */
    bool                      is_bolus_delivery_reason_meal;      /**< If this bit is set, the reason for the bolus is 
                                                                  to cover the intake of food. */
    uint16_t                  bolus_id;                           /**< The Bolus ID field represents a unique 
                                                                  identifier as a uint16 data type created by 
                                                                  the Server application for a programmed bolus. */
    uint8_t                   bolus_type;                         /**< Bolus Type values */
    st_ble_ieee11073_sfloat_t bolus_fast_amount;                  /**< The Bolus Fast Amount field represents 
                                                                  the fast amount of the bolus. */
    st_ble_ieee11073_sfloat_t bolus_extended_amount;              /**< The Bolus Extended Amount field represents 
                                                                  the extended amount of the bolus.*/
    uint16_t                  bolus_duration;                     /**< Bolus Duration field */
    uint16_t                  bolus_delay_time;                   /**< Bolus Delay Time */
    uint8_t                   bolus_template_no;                  /**< Bolus Template Number */
    uint8_t                   bolus_activation_type;              /**< Bolus Activation Type */
}st_ble_idc_idd_srcp_get_active_bolus_delivery_response_operand_t;

/*******************************************************************************************************************//**
 * @brief IDD Status Reader Control Point Get Active Basal Rate Delivery Response
***********************************************************************************************************************/
typedef struct
{
    bool                      is_tbr_present;                   /**< If this bit is set, there is an active TBR. */
    bool                      is_tbr_template_number_present;   /**< If this bit and the TBR Present bit are set, 
                                                                the TBR Template Number field is present. */
    bool                      is_basal_delivery_context_present;/**< If this bit is set, the Basal Delivery Context 
                                                                field is present.. */
    uint8_t                   abr_profile_template_number;      /**< Active Basal Rate Profile Template Number. */
    st_ble_ieee11073_sfloat_t abr_current_config_value;         /**< Active Basal Rate Current Config Value. */
    uint8_t                   tbr_type;                         /**< TBR Type. */
    st_ble_ieee11073_sfloat_t tbr_adjustment_value;             /**< TBR Adjustment Value. */
    uint16_t                  tbr_duration_programmed;          /**< TBR Duration Programmed. */
    uint16_t                  tbr_duration_remaining;           /**< TBR Duration Remaining. */
    uint8_t                   tbr_template_number;              /**< TBR Template Number. */
    uint8_t                   basel_delivery_context;           /**< Basal Delivery Context. */
}st_ble_idc_idd_srcp_get_active_basel_rate_delivery_response_operand_t;

/*******************************************************************************************************************//**
 * @brief IDD Status Reader Control Point Get Total Daily Insulin Status Response
***********************************************************************************************************************/
typedef struct
{
    st_ble_ieee11073_sfloat_t sum_of_bolus_delivered;           /**< Total Daily Insulin Sum of Bolus Delivered. */
    st_ble_ieee11073_sfloat_t sum_of_basel_delivered;           /**< Total Daily Insulin Sum of Basal Delivered. */
    st_ble_ieee11073_sfloat_t sum_of_bolus_and_basal_delivered; /**< Total Daily Insulin Sum of Bolus and 
                                                                Basal Delivered. */
}st_ble_idc_idd_srcp_get_total_daily_insulin_status_response_operand_t;

/*******************************************************************************************************************//**
 * @brief IDD Status Reader Control Point Get Counter
***********************************************************************************************************************/
typedef struct
{
    uint8_t counter_type;           /**< Counter Type. */
    uint8_t counter_value_selection;/**< Counter Value Selection. */
}st_ble_idc_idd_srcp_get_counter_operand_t;

/*******************************************************************************************************************//**
 * @brief IDD Status Reader Control Point Get Counter Response
***********************************************************************************************************************/
typedef struct
{
    uint8_t counter_type;           /**< Counter Type. */
    uint8_t counter_value_selection;/**< Counter Value Selection. */
    uint32_t counter_value;         /**< Counter Value. */
}st_ble_idc_idd_srcp_get_counter_response_operand_t;

/*******************************************************************************************************************//**
 * @brief IDD Status Reader Control Point Get Delivered Insulin Response
***********************************************************************************************************************/
typedef struct
{
    st_ble_ieee11073_float_t bolus_amount_delivered;/**< Bolus Amount Delivered. */
    st_ble_ieee11073_float_t basel_amount_delivered;/**< Basal Amount Delivered. */
}st_ble_idc_idd_srcp_get_delivered_insulin_response_operand_t;

/*******************************************************************************************************************//**
 * @brief IDD Status Reader Control Point Get Insulin On Board Response Response
***********************************************************************************************************************/
typedef struct
{
    bool                      is_remaining_duration_present;/**< If this bit is set, the Remaining Duration 
                                                            field is present. */
    st_ble_ieee11073_sfloat_t insulin_onboard;              /**< Insulin On Board. */
    uint16_t                  remaining_duration;           /**< Remaining Duration. */
}st_ble_idc_idd_srcp_get_insulin_onbord_response_operand_t;

/*******************************************************************************************************************//**
 * @brief IDD Command CP Response Code Operand
***********************************************************************************************************************/
typedef struct
{
    uint16_t request_op_code;    /**< Request Op Code. */
    uint8_t  response_code_value;/**< Response Code Value. */
}st_ble_idc_idd_ccp_response_code_operand_t;

/*******************************************************************************************************************//**
 * @brief IDD Command CP Write Basal Rate Profile Template Operand
***********************************************************************************************************************/
typedef struct
{
    bool                      is_end_transaction;             /**< If this bit is set, it signals the Server that 
                                                              all time blocks of the basal rate profile have 
                                                              been sent */
    bool                      is_second_time_block_present;   /**< If this bit is set, the fields Second Duration 
                                                              and Second Rate are present. */
    bool                      is_third_time_block_present;    /**< If this bit is set, the fields Third Duration 
                                                              and Third Rate are present. */
    uint8_t                   basal_rate_profile_template_num;/**< Basal Rate Profile Template Number */
    uint8_t                   first_time_block_number_index;  /**< First Time Block Number Index */
    uint16_t                  first_duration;                 /**< First Duration */
    st_ble_ieee11073_sfloat_t first_rate;                     /**< First Rate */
    uint16_t                  second_duration;                /**< Second Duration  */
    st_ble_ieee11073_sfloat_t second_rate;                    /**< Second Rate */
    uint16_t                  third_duration;                 /**< Third Duration */
    st_ble_ieee11073_sfloat_t third_rate;                     /**< Third Rate */
}st_ble_idc_idd_ccp_write_brp_template_operand_t;

/*******************************************************************************************************************//**
 * @brief IDD Command CP Write Basal Rate Profile Template Response Operand
***********************************************************************************************************************/
typedef struct
{
    bool    is_trans_comp;                     /**< If this bit is set, the basal rate profile passed the 
                                               plausibility checks of the Server and was written successfully */
    uint8_t basal_rate_profile_template_number;/**< Basal Rate Profile Template Number */
    uint8_t first_time_block_number_index;     /**< First Time Block Number Index */
}st_ble_idc_idd_ccp_write_brp_template_response_operand_t;

/*******************************************************************************************************************//**
 * @brief DD Command CP Set TBR Adjustment Operand
***********************************************************************************************************************/
typedef struct
{
    bool                      is_tbr_template_number_present; /**< If this bit is set, the TBR Template Number 
                                                              field is present. */
    bool                      is_tbr_delivery_context_present;/**< If this bit is set, the TBR Delivery Context 
                                                              field is present. */
    bool                      is_change_tbr;                  /**< If this bit is set, a currently active TBR shall 
                                                              be completely overwritten with the changed settings; */
    uint8_t                   tbr_type;                       /**< TBR Type */
    st_ble_ieee11073_sfloat_t tbr_adj_val;                    /**< TBR Adjustment Value */
    uint16_t                  tbr_duration;                   /**< TBR Duration */
    uint8_t                   tbr_template_num;               /**< TBR Template Number */
    uint8_t                   tbr_delivery_context;           /**< TBR Delivery Context */
}st_ble_idc_idd_ccp_set_tbr_adjustment_operand_t;

/*******************************************************************************************************************//**
 * @brief IDD Command CP Get TBR Template Response Operand
***********************************************************************************************************************/
typedef struct
{
    uint8_t                   tbr_template_number; /**< TBR Template Number */
    uint8_t                   tbr_type;            /**< TBR Type */
    st_ble_ieee11073_sfloat_t tbr_adjustment_value;/**< TBR Adjustment Value */
    uint16_t                  tbr_duration;        /**< TBR Duration */
}st_ble_idc_idd_ccp_get_tbr_template_response_operand_t;

/*******************************************************************************************************************//**
 * @brief IDD Command CP Set TBR Template Operand
***********************************************************************************************************************/
typedef struct
{
    uint8_t                   tbr_template_number; /**< TBR Template Number */
    uint8_t                   tbr_type;            /**< TBR Type */
    st_ble_ieee11073_sfloat_t tbr_adjustment_value;/**< TBR Adjustment Value */
    uint16_t                  tbr_duration;        /**< TBR Duration */
}st_ble_idc_idd_ccp_set_tbr_template_operand_t;

/*******************************************************************************************************************//**
 * @brief IDD Command CP Set Bolus Operand
***********************************************************************************************************************/
typedef struct
{
    bool                      is_bolus_delay_time_present;        /**< If this bit is set, the Bolus Delay Time field 
                                                                  is present. */
    bool                      is_bolus_template_number_present;   /**< If this bit is set, the Bolus Template Number 
                                                                  field is present. */
    bool                      is_bolus_activation_type_present;   /**< If this bit is set, the Bolus Activation Type 
                                                                  field is present. */
    bool                      is_bolus_delivery_reason_correction;/**< If this bit is set, the reason for the bolus is 
                                                                  the correction of a high blood glucose level */
    bool                      is_bolus_delivery_reason_meal;      /**< If this bit is set, the reason for the bolus is 
                                                                  to cover the intake of food. */
    uint8_t                   bolus_type;                         /**< Bolus Type */
    st_ble_ieee11073_sfloat_t bolus_fast_amount;                  /**< Bolus Fast Amount */
    st_ble_ieee11073_sfloat_t bolus_extended_amount;              /**< Bolus Extended Amount */
    uint16_t                  bolus_duration;                     /**< Bolus Duration */
    uint16_t                  bolus_delay_time;                   /**< Bolus Delay Time */
    uint8_t                   bolus_template_number;              /**< Bolus Template Number */
    uint8_t                   bolus_activation_type;              /**< Bolus Activation Type */
}st_ble_idc_idd_ccp_set_bolus_operand_t;

/*******************************************************************************************************************//**
 * @brief IDD Command CP get available boluses
***********************************************************************************************************************/
typedef struct
{
    bool is_fast_bolus_available;     /**< If this bit is set, a fast bolus is currently available to be set */
    bool is_extended_bolus_available; /**< If this bit is set, an extended bolus is currently available to be set. */
    bool is_multiwave_bolus_available;/**< If this bit is set, a multiwave bolus is currently available to be set.*/
}st_ble_idc_idd_ccp_get_available_boluses_res_t;

/*******************************************************************************************************************//**
 * @brief IDD Command CP Set Bolus Operand
***********************************************************************************************************************/
typedef struct
{
    uint8_t                   bolus_template_num;                 /**< Bolus Template Number */
    bool                      is_bolus_delay_time_present;        /**< If this bit is set, the Bolus Delay Time field 
                                                                  is present. */
    bool                      is_bolus_delivery_reason_correction;/**< If this bit is set, the Bolus Template Number 
                                                                  field is present. */
    bool                      is_bolus_delivery_reason_meal;      /**< If this bit is set, the Bolus Activation Type 
                                                                  field is present. */
    uint8_t                   bolus_type;                         /**< Bolus Type */
    st_ble_ieee11073_sfloat_t bolus_fast_amount;                  /**< Bolus Fast Amount */
    st_ble_ieee11073_sfloat_t bolus_extended_amount;              /**< Bolus Extended Amount */
    uint16_t                  bolus_duration;                     /**< Bolus Duration */
    uint16_t                  bolus_delay_time;                   /**< Bolus Delay Time */
}st_ble_idc_idd_ccp_get_bolus_template_response_operand_t;

/*******************************************************************************************************************//**
 * @brief IDD Command CP Reset Template Status Operand
***********************************************************************************************************************/
typedef struct
{
    uint8_t number_of_templates_to_reset; /**< The Number of Templates to Reset field value is the total number of 
                                          templates included in the request to be reset */
    uint8_t template_number[14];          /**< The Template Numbers field value is an array of template numbers to
                                          be reset. */
}st_ble_idc_idd_ccp_reset_template_status_operand_t;

/*******************************************************************************************************************//**
 * @brief IDD Command CP Reset Template Status Response Operand
***********************************************************************************************************************/
typedef struct
{
    uint8_t number_of_templates_to_activate; /**< The Number of Profile Templates to Activate field value is the 
                                             total number of profile templates to be activated. */
    uint8_t profile_template_numbers[14];    /**< The Profile Template Numbers field value is an array of profile
                                             template numbers to be activated. */
}st_ble_idc_idd_ccp_active_prof_template_operand_t;

/*******************************************************************************************************************//**
 * @brief IDD Command CP write isf profile template
***********************************************************************************************************************/
typedef struct
{
    bool                      is_end_transaction;           /**< If this bit is set, it indicates to the Server that
                                                            all time blocks of the ISF profile have been sent*/
    bool                      is_second_time_block_present; /**< If this bit is set, the fields Second Duration 
                                                            and Second ISF are present. */
    bool                      is_third_time_block_present;  /**< If this bit is set, the fields Third Duration 
                                                            and Third ISF are present. */
    uint8_t                   isf_prof_template_num;        /**< ISF Profile Template Number */
    uint8_t                   first_time_block_num_index;   /**< First Time Block Number Index */
    uint16_t                  first_duration;               /**< First Duration */
    st_ble_ieee11073_sfloat_t first_isf;                    /**< First ISF */
    uint16_t                  second_duration;              /**< Second Duration */
    st_ble_ieee11073_sfloat_t second_isf;                   /**< Second ISF */
    uint16_t                  third_duration;               /**< Third Duration */
    st_ble_ieee11073_sfloat_t third_isf;                    /**< Third ISF */
}st_ble_idc_idd_ccp_write_ipt_operand_t;

/*******************************************************************************************************************//**
 * @brief IDD Command CP Write ISF Profile Template Response
***********************************************************************************************************************/
typedef struct
{
    bool    is_transaction_completed;     /**< Flags */
    uint8_t isf_profile_template_num;     /**< ISF Profile Template Number */
    uint8_t first_time_block_number_index;/**< First Time Block Number Index */
}st_ble_idc_idd_ccp_write_ipt_res_operand_t;

/*******************************************************************************************************************//**
 * @brief IDD Command CP Write I2CHO Ratio Profile Template
***********************************************************************************************************************/
typedef struct
{
    bool                     is_end_transaction;           /**< If this bit is set, it indicates to the Server that 
                                                           all time blocks of the I:CHO ratio profile have been sent */
    bool                      is_second_time_block_present;/**< If this bit is set, the fields Second Duration and 
                                                           Second I2CHO Ratio are present. */
    bool                      is_third_time_block_present; /**< If this bit is set, the fields Third Duration and 
                                                           Third I2CHO Ratio are present. */
    uint8_t                   icho_ratio_prof_template_num;/**< I2CHO Ratio Profile Template Number */
    uint8_t                   first_time_block_num_index;  /**< First Time Block Number Index */
    uint16_t                  first_duration;              /**< First Duration */
    st_ble_ieee11073_sfloat_t first_i2cho_ratio;           /**< First I2CHO Ratio */
    uint16_t                  second_duration;             /**< Second Duration */
    st_ble_ieee11073_sfloat_t second_i2cho_ratio;          /**< Second I2CHO Ratio */
    uint16_t                  third_duration;              /**< Third Duration */
    st_ble_ieee11073_sfloat_t third_i2cho_ratio;           /**< Third I2CHO Ratio */
}st_ble_idc_idd_ccp_write_irpt_operand_t;

/*******************************************************************************************************************//**
 * @brief IDD Command CP Write I2CHO Ratio Profile Template Response
***********************************************************************************************************************/
typedef struct
{
    bool    is_trans_completed;             /**< If this bit is set, the I:CHO ratio profile passed the plausibility 
                                            checks of the Server and was written successfully */
    uint8_t icho_ratio_profile_template_num;/**< I2CHO Ratio Profile Template Number */
    uint8_t first_time_block_number_index;  /**< First Time Block Number Index */
}st_ble_idc_idd_ccp_write_irpt_res_operand_t;

/*******************************************************************************************************************//**
 * @brief IDD Command CP Write Target Glucose Range Profile Template
***********************************************************************************************************************/
typedef struct
{
    bool                      is_end_transaction;               /**< If this bit is set, it indicates to the Server 
                                                                that all time blocks of the target glucose range 
                                                                profile have been sent */
    bool                      is_second_time_block_pres;        /**< If this bit is set, the fields Second Duration,
                                                                Second Lower Target Glucose Limit, and Second Upper 
                                                                Target Glucose Limit are present. */
    uint8_t                   tgrp_template_number;             /**< Target Glucose Range Profile Template Number */
    uint8_t                   first_time_block_num_index;       /**< First Time Block Number Index */
    uint16_t                  first_duration;                   /**< First Duration */
    st_ble_ieee11073_sfloat_t first_lower_target_glucose_limit; /**< First Lower Target Glucose Limit */
    st_ble_ieee11073_sfloat_t first_upper_target_glucose_limit; /**< First Upper Target Glucose Limit */
    uint16_t                  second_duration;                  /**< Second Duration */
    st_ble_ieee11073_sfloat_t second_lower_target_glucose_limit;/**< Second Lower Target Glucose Limit */
    st_ble_ieee11073_sfloat_t second_upper_target_glucose_limit;/**< Second Upper Target Glucose Limit */
}st_ble_idc_idd_ccp_write_tgrp_operand_t;

/*******************************************************************************************************************//**
 * @brief IDD Command CP Write Target Glucose Range Profile Template
***********************************************************************************************************************/
typedef struct
{
    bool    is_transaction_completed;     /**< If this bit is set, the target glucose range profile passed the 
                                          plausibility checks of the Server and was written successfully */
    uint8_t tgrp_template_number;         /**< Target Glucose Range Profile Template Number */
    uint8_t first_time_block_number_index;/**< First Time Block Number Index */
}st_ble_idc_idd_ccp_write_tgrp_response_operand_t;

/*******************************************************************************************************************//**
 * @brief IDD Command Data Read Basal Rate Profile Template Response Operand
***********************************************************************************************************************/
typedef struct
{
    bool                      is_second_time_block_present;      /**< If this bit is set, the fields Second Duration 
                                                                 and Second Rate are present.If this bit is set, the 
                                                                 fields Second Duration and Second Rate are present. */
    bool                      is_third_time_block_present;       /**< If this bit is set, the fields Third Duration 
                                                                 and Third Rate are present. */
    uint8_t                   basal_rate_profile_template_number;/**< Basal Rate Profile Template Number */
    uint8_t                   first_time_block_number_index;     /**< First Time Block Number Index */
    uint16_t                  first_duration;                    /**< First Duration. */
    st_ble_ieee11073_sfloat_t first_rate;                        /**< First Rate. */
    uint16_t                  second_duration;                   /**< Second Duration. */
    st_ble_ieee11073_sfloat_t second_rate;                       /**< Second Rate. */
    uint16_t                  third_duration;                    /**< Third Duration. */
    st_ble_ieee11073_sfloat_t third_rate;                        /**< Third Rate */
}st_ble_idc_idd_cd_read_brpt_response_operand_t;

/*******************************************************************************************************************//**
 * @brief IDD Command Data Get Supported Template Details and Status Response Operand
***********************************************************************************************************************/
typedef struct
{
    uint8_t template_type;               /**< Template Type. */
    uint8_t starting_template_number;    /**< Starting Template Number. */
    uint8_t num_of_template;             /**< Number of Templates. */
    uint8_t max_num_of_supported_blocks; /**< Max Number of Supported Time Blocks. */
    uint8_t configurable_flag[11];       /**< Configurable and Configured Flags. */
}st_ble_idc_idd_cd_get_temstatus_details_response_t;

/*******************************************************************************************************************//**
 * @brief IDD Command Data Operand of Read ISF Profile Template Response
***********************************************************************************************************************/
typedef struct
{
    bool                      is_second_time_block_present;      /**< If this bit is set, the fields Second 
                                                                 Duration and Second Rate are present.If this bit 
                                                                 is set, the fields Second Duration and Second Rate 
                                                                 are present. */
    bool                      is_third_time_block_present;       /**< If this bit is set, the fields Third Duration 
                                                                 and Third Rate are present. */
    uint8_t                   isf_profile_template_number;       /**< isf Profile Template Number */
    uint8_t                   first_time_block_number_index;     /**< First Time Block Number Index */
    uint16_t                  first_duration;                    /**< First Duration. */
    st_ble_ieee11073_sfloat_t first_isf;                         /**< First isf. */
    uint16_t                  second_duration;                   /**< Second Duration. */
    st_ble_ieee11073_sfloat_t second_isf;                        /**< Second isf. */
    uint16_t                  third_duration;                    /**< Third Duration. */
    st_ble_ieee11073_sfloat_t third_isf;                         /**< Third isf */
}st_ble_idc_idd_cd_read_isfpt_response_t;

/*******************************************************************************************************************//**
 * @brief IDD Command Data Operand of Read I2CHO Ratio Profile Template Response
***********************************************************************************************************************/
typedef struct
{
    bool                      is_second_time_block_present;        /**< If this bit is set, the fields Second 
                                                                   Duration and Second Rate are present.If this 
                                                                   bit is set, the fields Second Duration and 
                                                                   Second Rate are present. */
    bool                      is_third_time_block_present;         /**< If this bit is set, the fields Third 
                                                                   Duration and Third Rate are present. */
    uint8_t                   i2cho_ratio_profile_template_number; /**< isf Profile Template Number */
    uint8_t                   first_time_block_number_index;       /**< First Time Block Number Index */
    uint16_t                  first_duration;                      /**< First Duration. */
    st_ble_ieee11073_sfloat_t first_i2cho_ratio;                   /**< First i2cho ratio */
    uint16_t                  second_duration;                     /**< Second Duration. */
    st_ble_ieee11073_sfloat_t second_i2cho_ratio;                  /**< Second  i2cho ratio. */
    uint16_t                  third_duration;                      /**< Third Duration. */
    st_ble_ieee11073_sfloat_t third_i2cho_ratio;                   /**< Third i2cho ratio */
}st_ble_idc_idd_cd_i2chorpt_response_t;

/*******************************************************************************************************************//**
 * @brief IDD Command Data Operand of Read Target Glucose Range Profile Template Response
***********************************************************************************************************************/
typedef struct
{
    bool                      is_second_time_block_present;    /**< If this bit is set, the fields Second Duration 
                                                               and Second Rate are present.If this bit is set, the 
                                                               fields Second Duration and Second Rate are present. */
    bool                      is_third_time_block_present;     /**< If this bit is set, the fields Third Duration 
                                                               and Third Rate are present. */
    uint8_t                   tg_range_profile_template_number;/**< taget glucose range Profile Template Number */
    uint8_t                   first_time_block_number_index;   /**< First Time Block Number Index */
    uint16_t                  first_duration;                  /**< First Duration. */
    st_ble_ieee11073_sfloat_t first_lower_tg_lmt;              /**< First Lower Target Glucose Limit */
    st_ble_ieee11073_sfloat_t first_upper_tg_lmt;              /**< First Upper Target Glucose Limit */
    uint16_t                  second_duration;                 /**< Second Duration. */
    st_ble_ieee11073_sfloat_t second_lower_tg_lmt;             /**< Second Lower Target Glucose Limit */
    st_ble_ieee11073_sfloat_t second_upper_tg_lmt;             /**< Second Upper Target Glucose Limit*/
}st_ble_idc_idd_cd_target_glucose_range_response_t;

/*******************************************************************************************************************//**
 * @brief IDD History Data Reference Time Event
***********************************************************************************************************************/
typedef struct
{
    uint8_t recording_reason;    /**< the reason why the Reference Time event was recorded */
    st_ble_date_time_t date_time;/**< Date and time */
    uint8_t time_zone;           /**< time zone */
    uint8_t dst_offset;          /**< dst offset */
}st_ble_idc_idd_history_data_ref_time_event_t;

/*******************************************************************************************************************//**
 * @brief IDD History Data Reference Time Base Offset Event
***********************************************************************************************************************/
typedef struct
{
    uint8_t recording_reason;    /**< the reason why the Reference Time event was recorded */
    st_ble_date_time_t date_time;/**< Date and time */
    int16_t time_zone;           /**< time offset */
}st_ble_idc_idd_history_data_ref_time_baseoffset_event_t;

/*******************************************************************************************************************//**
 * @brief IDD History Data Bolus Calculated Part 1 of 2 Event
***********************************************************************************************************************/
typedef struct
{
    st_ble_ieee11073_sfloat_t fast_amount_meal;          /**< Recommended Fast Amount Meal */
    st_ble_ieee11073_sfloat_t fast_amount_correction;    /**< Recommended Fast Amount Correction */
    st_ble_ieee11073_sfloat_t extended_amount_meal;      /**< Recommended Extended Amount Meal */
    st_ble_ieee11073_sfloat_t extended_amount_correction;/**< Recommended Extended Amount Correction */
}st_ble_idc_idd_history_data_bolus_calculated_part_1_of_2_event_t;

/*******************************************************************************************************************//**
 * @brief IDD History Data Bolus Calculated Part 2 of 2 Event
***********************************************************************************************************************/
typedef struct
{
    st_ble_ieee11073_sfloat_t fast_amount_meal;          /**< Confirmed Fast Amount Meal */
    st_ble_ieee11073_sfloat_t fast_amount_correction;    /**< Confirmed Fast Amount Correction */
    st_ble_ieee11073_sfloat_t extended_amount_meal;      /**< Confirmed Extended Amount Meal */
    st_ble_ieee11073_sfloat_t extended_amount_correction;/**< time offset */
}st_ble_idc_idd_history_data_bolus_calculated_part_2_of_2_event_t;

/*******************************************************************************************************************//**
 * @brief IDD History Data Bolus Programmed Part 1 of 2 Event
***********************************************************************************************************************/
typedef struct
{
    uint16_t                  bolus_id;                        /**< The Bolus ID field represents a unique identifier
                                                               as a uint16 data type created by the Server Application 
                                                               for a programmed bolus. */
    uint8_t                   bolus_type;                      /**< Bolus Typet */
    st_ble_ieee11073_sfloat_t programmed_bolus_fast_amount;    /**< Programmed Bolus Fast Amount */
    st_ble_ieee11073_sfloat_t programmed_bolus_extended_amount;/**< Programmed Bolus Extended Amount2 */
    uint16_t                  programmed_bolus_duration;       /**< Programmed Bolus Duration3 */
}st_ble_idc_idd_history_data_bolus_programmed_part_1_of_2_event_t;

/*******************************************************************************************************************//**
 * @brief IDD History Data Bolus Programmed Part 2 of 2 Event
***********************************************************************************************************************/
typedef struct
{
    bool                      is_bolus_delay_time_present;        /**< If this bit is set, the Bolus Delay Time 
                                                                  field is present. */
    bool                      is_bolus_template_number_present;   /**< If this bit is set, the Bolus Template Number 
                                                                  field is present. */
    bool                      is_bolus_activation_type_present;   /**< If this bit is set, the Bolus Activation Type 
                                                                  field is present. */
    bool                      is_bolus_delivery_reason_correction;/**< If this bit is set, the reason for the bolus is 
                                                                  the correction of a high blood glucose level */
    bool                      is_bolus_delivery_reason_meal;      /**< If this bit is set, the reason for the bolus is 
                                                                  to cover the intake of food. */
    uint16_t                  bolus_delay_time;                   /**< Bolus Delay Time. */
    uint8_t                   bolus_template_num;                 /**< bolus template number */
    uint8_t                   bolus_activation_type;              /**< bolus activation type */
}st_ble_idc_idd_history_data_bolus_programmed_part_2_of_2_event_t;

/*******************************************************************************************************************//**
 * @brief IDD History Data Bolus Delivered Part 1 of 2 Event
***********************************************************************************************************************/
typedef struct
{
    uint16_t                  bolus_id;                       /**< The Bolus ID field represents a unique identifier 
                                                              as a uint16 data type created by the Server Application 
                                                              for a programmed bolus.. */
    uint8_t                   bolus_type;                     /**< bolus type. */
    st_ble_ieee11073_sfloat_t delivered_bolus_fast_amount;    /**< The Delivered Bolus Fast Amount field contains the
                                                              effective delivered fast amount after termination of 
                                                              the bolus delivery. */
    st_ble_ieee11073_sfloat_t delivered_bolus_extended_amount;/**< The Delivered Bolus Extended Amount field contains 
                                                              the effective delivered extended amount after termination 
                                                              of the bolus delivery. */
    uint16_t                  effective_bolus_duration;       /**< The Effective Bolus Duration field contains the 
                                                              effective duration of an extended or multiwave bolus 
                                                              from the start of the bolus to the termination. */
}st_ble_idc_idd_history_data_bolus_delivered_part_1_of_2_event_t;

/*******************************************************************************************************************//**
 * @brief IDD History Data Bolus Delivered Part 2 of 2 Event
***********************************************************************************************************************/
typedef struct
{
    bool     is_bolus_activation_type_present;   /**< If this bit is set, the Bolus Activation Type field is present.*/
    bool     is_bolus_end_reason_present;        /**< If this bit is set, the Bolus End Reason field is present. */
    bool     is_annunciation_instance_id_present;/**< If this bit is set, the Annunciation Instance ID field is present. */
    uint32_t bolus_start_time_offset;            /**< Bolus Start Time Offset */
    uint8_t  bolus_activation_type;              /**< Bolus Activation Type */
    uint8_t  bolus_end_reason;                   /**< Bolus End Reason */
    uint16_t annunciation_instance_id;           /**< Annunciation Instance ID */
}st_ble_idc_idd_history_data_bolus_delivered_part_2_of_2_event_t;

/*******************************************************************************************************************//**
 * @brief IDD History Data Bolus Delivered Basal Rate Changed Event
***********************************************************************************************************************/
typedef struct
{
    bool                      is_basal_delivery_context_present;/**< If this bit is set, the Basal Delivery Context 
                                                                field is present. */
    st_ble_ieee11073_sfloat_t old_basel_rate_val;               /**< Old Basal Rate Value */
    st_ble_ieee11073_sfloat_t new_basel_rate_val;               /**< New Basal Rate Value */
    uint8_t                   basal_delivery_context;           /**< Basal Delivery Context */
}st_ble_idc_idd_history_delivered_basal_rate_changed_event_t;

/*******************************************************************************************************************//**
 * @brief IDD History Data TBR Adjustment Started Event
***********************************************************************************************************************/
typedef struct
{
    bool                      is_tbr_template_number_present;/**< If this bit is set, the TBR Template Number 
                                                             field is present. */
    uint8_t                   tbr_type;                      /**< bolus type. */
    st_ble_ieee11073_sfloat_t tbr_adjustment_value;          /**< TBR Adjustment Value. */
    uint16_t                  tbr_duration_programmed;       /**< TBR Duration Programmed */
    uint8_t                   tbr_template_num;              /**< TBR Template Number. */
}st_ble_idc_idd_history_tbr_adjustment_started_event_t;

/*******************************************************************************************************************//**
 * @brief IDD History Data TBR Adjustment ended Event
***********************************************************************************************************************/
typedef struct
{
    bool     is_last_set_tbr_template_number_present;/**< If this bit is set, the Last Set TBR Template Number 
                                                     field is present.. */
    bool     is_annunciation_instance_id_present;    /**< If this bit is set, the Annunciation Instance ID field 
                                                     is present. */
    uint8_t  last_set_tbr_type;                      /**< Last Set TBR Type */
    uint16_t effective_tbr_duration;                 /**< Effective TBR Duration. */
    uint8_t  tbr_end_reason;                         /**< TBR End Reason. */
    uint8_t  last_set_tbr_template_num;              /**< Last Set TBR Template Number. */
    uint16_t annunciation_instance_id;               /**< Annunciation Instance ID. */
}st_ble_idc_idd_history_tbr_adjustment_ended_event_t;

/*******************************************************************************************************************//**
 * @brief IDD History Data TBR Adjustment Changed Event
***********************************************************************************************************************/
typedef struct
{
    bool                      is_tbr_template_number_present;/**< If this bit is set, the Basal Delivery Context 
                                                             field is present. */
    uint8_t                   tbr_type;                      /**< TBR Type */
    st_ble_ieee11073_sfloat_t tbr_adjustment_value;          /**< TBR Adjustment Value1. */
    uint16_t                  tbr_duration_programmed;       /**< TBR Duration Programmed. */
    uint16_t                  elapsed_tbr_duration;          /**< Elapsed TBR Duration Since Last Change or Start. */
    uint8_t                   tbr_template_num;              /**< TBR Template Number */
}st_ble_idc_idd_history_tbr_adjustment_changed_event_t;

/*******************************************************************************************************************//**
 * @brief IDD History Profile Template Activated
***********************************************************************************************************************/
typedef struct
{
    uint8_t prof_template_type;   /**< Profile Template Type */
    uint8_t old_prof_template_num;/**< Old Profile Template Number */
    uint8_t new_prof_template_num;/**< New Profile Template Number */
}st_ble_idc_idd_history_pro_template_activated_event_t;

/*******************************************************************************************************************//**
 * @brief IDD History Basal Rate Profile Template Time Block Changed
***********************************************************************************************************************/
typedef struct
{
    uint8_t                   brpt_Number;      /**< Basal Rate Profile Template Number */
    uint8_t                   time_block_number;/**< Time Block Number*/
    uint16_t                  duration;         /**< Duration*/
    st_ble_ieee11073_sfloat_t rate;             /**< Rate */
}st_ble_idc_idd_history_brpt_time_block_changed_event_t;

/*******************************************************************************************************************//**
 * @brief IDD History Total Daily Insulin Delivery
***********************************************************************************************************************/
typedef struct
{
    bool                      is_date_time_changed_warning;              /**< If this bit is set, the date time of 
                                                                         the Insulin Delivery Device will have 
                                                                         changed since the last recorded Total 
                                                                         Daily Insulin Delivery Event. */
    st_ble_ieee11073_sfloat_t total_daily_insulin_sum_of_bolus_delivered;/**< Total Daily Insulin Sum of Bolus 
                                                                         Delivered */
    st_ble_ieee11073_sfloat_t total_daily_insulin_sum_of_basel_delivered;/**< Total Daily Insulin Sum of Basal 
                                                                         Delivered */
    uint16_t                  year;                                      /**< Year */
    uint8_t                   month;                                     /**< month */
    uint8_t                   day;                                       /**< day */
}st_ble_idc_idd_history_total_daily_insulin_delivery_event_t;

/*******************************************************************************************************************//**
 * @brief IDD History Therapy Control State Changed
***********************************************************************************************************************/
typedef struct
{
    uint8_t old_therapy_control_state;/**< Old Therapy Control State */
    uint8_t new_therapy_control_state;/**< New Therapy Control State */
}st_ble_idc_idd_history_therapy_control_state_event_t;

/*******************************************************************************************************************//**
 * @brief IDD History Therapy Control State Changed
***********************************************************************************************************************/
typedef struct
{
    uint8_t old_operational_state;/**< Old Operational State */
    uint8_t new_operational_state;/**< New Operational State */
}st_ble_idc_idd_history_operational_state_changed_event_t;

/*******************************************************************************************************************//**
 * @brief IDD History Annunciation Status Changed Part 1 of 2
***********************************************************************************************************************/
typedef struct
{
    bool     is_auxinfo1_present;     /**< If this bit is set, the AuxInfo1 field is present. */
    bool     is_auxinfo2_present;     /**< If this bit is set, the AuxInfo2 field is present. */
    uint16_t annunciation_instance_id;/**< Annunciation Instance ID */
    uint16_t annunciation_type;       /**< Annunciation Type */
    uint8_t  annunciation_status;     /**< Annunciation Status */
    uint16_t auxInfo1;                /**< AuxInfo1 */
    uint16_t auxInfo2;                /**< AuxInfo2 */
}st_ble_idc_idd_history_annunciation_status_changed_part_1_of_2_event_t;

/*******************************************************************************************************************//**
 * @brief IDD History Annunciation Status Changed Part 2 of 2
***********************************************************************************************************************/
typedef struct
{
    bool     is_auxinfo3_present;/**< If this bit is set, the AuxInfo3 field is present. */
    bool     is_auxinfo4_present;/**< If this bit is set, the AuxInfo4 field is present. */
    bool     is_auxinfo5_present;/**< If this bit is set, the AuxInfo5 field is present. */
    uint16_t auxinfo3;           /**< AuxInfo3 */
    uint16_t auxinfo4;           /**< AuxInfo4 */
    uint16_t auxinfo5;           /**< AuxInfo5 */
}st_ble_idc_idd_history_annunciation_status_changed_part_2_of_2_event_t;

/*******************************************************************************************************************//**
 * @brief IDD History ISF Profile Template Time Block Changed
***********************************************************************************************************************/
typedef struct
{
    uint8_t                   isf_profile_template_number;/**< ISF Profile Template Number */
    uint8_t                   time_block_number;          /**< Time Block Number */
    uint16_t                  duration;                   /**< Duration */
    st_ble_ieee11073_sfloat_t isf;                        /**< ISF */
}st_ble_idc_idd_history_isfpt_time_block_changed_event_t;

/*******************************************************************************************************************//**
 * @brief IDD History I2CHO Ratio Profile Template Time Block Changed
***********************************************************************************************************************/
typedef struct
{
    uint8_t                   i2cho_ratio_profile_template_number;/**< I2CHO Ratio Profile Template Number */
    uint8_t                   time_block_number;                  /**< Time Block Number */
    uint16_t                  duration;                           /**< Duration */
    st_ble_ieee11073_sfloat_t i2cho_ratio;                        /**< I2CHO Ratio */
}st_ble_idc_idd_history_i2chorpt_time_block_changed_event_t;

/*******************************************************************************************************************//**
 * @brief IDD History Target Glucose Range Profile Template Time Block Changed
***********************************************************************************************************************/
typedef struct
{
    uint8_t                   tgr_profile_template_number;/**< Target Glucose Range Profile Template Number */
    uint8_t                   time_block_number;          /**< Time Block Number */
    uint16_t                  duration;                   /**< Duration */
    st_ble_ieee11073_sfloat_t lower_target_glucose_limit; /**< Lower Target Glucose Limit */
    st_ble_ieee11073_sfloat_t upper_Target_Glucose_Limit; /**< Upper Target Glucose Limit */
}st_ble_idc_idd_history_tgrpt_time_block_changed_event_t;

/*******************************************************************************************************************//**
 * @brief IDD History Priming Done
***********************************************************************************************************************/
typedef struct
{
    bool                      is_annunciation_instance_id_present;/**< If this bit is set, the Annunciation Instance 
                                                                  ID field is present. */
    st_ble_ieee11073_sfloat_t delivered_amount;                   /**< Delivered Amount */
    uint8_t                   reason_of_termination;              /**< Reason of Termination */
    uint16_t                  annunciation_instance_id;           /**< Annunciation Instance ID */
}st_ble_idc_idd_history_priming_done_event_t;

/*******************************************************************************************************************//**
 * @brief IDD History Bolus Template Changed Part 1 of 2
***********************************************************************************************************************/
typedef struct
{
    uint16_t                  bolus_Template_Num;   /**< Bolus Template Number */
    uint8_t                   bolus_type;           /**< Bolus Type */
    st_ble_ieee11073_sfloat_t bolus_fast_amount;    /**< Bolus Fast Amount */
    st_ble_ieee11073_sfloat_t bolus_extended_amount;/**< Bolus Extended Amount */
    uint16_t                  bolus_duration;       /**< Bolus Duration */
}st_ble_idc_idd_history_bolus_template_changed_part_1_of_2_event_t;

/*******************************************************************************************************************//**
 * @brief IDD History Bolus Template Changed Part 2 of 2
***********************************************************************************************************************/
typedef struct
{
    bool     is_bolus_delay_time_present;        /**< If this bit is set, the Bolus Delay Time field is present. */
    bool     is_bolus_delivery_reason_correction;/**< If this bit is set, the Bolus Template Number field is present. */
    bool     is_bolus_delivery_reason_meal;      /**< If this bit is set, the Bolus Activation Type field is present. */
    uint16_t bolus_delay_time;                   /**< Bolus Delay Time */
}st_ble_idc_idd_history_bolus_template_changed_part_2_of_2_event_t;

/*******************************************************************************************************************//**
 * @brief IDD History TBR Template Changed
***********************************************************************************************************************/
typedef struct
{
    uint8_t                   tbr_template_number; /**< TBR Template Number */
    uint8_t                   tbr_type;            /**< TBR Type */
    st_ble_ieee11073_sfloat_t tbr_adjustment_value;/**< TBR Adjustment Value */
    uint16_t                  tbr_duration;        /**< TBR Duration */
}st_ble_idc_idd_history_tbr_template_changed_event_t;

/*******************************************************************************************************************//**
 * @brief IDD History Max Bolus Amount Changed
***********************************************************************************************************************/
typedef struct
{
    st_ble_ieee11073_sfloat_t old_max_bolus_amount;/**< Old Max Bolus Amount */
    st_ble_ieee11073_sfloat_t new_max_bolus_amount;/**< New Max Bolus Amount */
}st_ble_idc_idd_history_max_bolus_amount_changed_event_t;

/*******************************************************************************************************************//**
 * @brief IDD Status Changed characteristic parameters.
***********************************************************************************************************************/
typedef struct 
{
    bool     is_therapy_control_state_changed;      /**< If this bit is set, the therapy control state of the Insulin
                                                    Delivery Device changed. */
    bool     is_optional_state_changed;             /**< If this bit is set, the operational state of the Insulin 
                                                    Delivery Device changed. */
    bool     is_reservoir_status_changed;           /**< If this bit is set, the status of the insulin reservoir 
                                                    changed (caused by a reservoir change or the delivery of insulin). */
    bool     is_annunciation_status_changed;        /**< If this bit is set, a new annunciation was created by the
                                                    Server application. */
    bool     is_total_daily_insulin_status_changed; /**< If this bit is set, the total daily insulin amount changed 
                                                    due to a bolus or basal delivery. The bit shall be set at the 
                                                    end of an effective delivery. */
    bool     is_active_basal_rate_status_changed;   /**< If this bit is set, the current basal rate changed due
                                                    to a new basal rate value (e.g., caused by a changed basal 
                                                    rate profile, reaching of a time block with another basal 
                                                    rate value or by a TBR). */
    bool     is_active_bolus_status_changed;        /**< If this bit is set, a new bolus was initiated or the 
                                                    status of current Active Bolus changed. */
    bool     is_history_event_recorded;             /**< If this bit is set, a new event has been recorded in 
                                                    the history. */
    uint8_t  e2e_counter;                           /**< E2E Counter value */
    uint16_t e2e_crc;
} st_ble_idc_idd_status_changed_t;

/*******************************************************************************************************************//**
 * @brief IDD Status characteristic parameters.
***********************************************************************************************************************/
typedef struct {
    uint8_t                   therapy_control_state;       /**< Therapy Control State value */
    uint8_t                   operational_state;          /**< Operational State value */
    st_ble_ieee11073_sfloat_t reservoir_remaining_amount; /**< Reservoir Remaining Amount value */
    uint8_t                   flag;                       /*flag*/
    bool                      is_reservoir_attached;      /**< If this bit is set, the reservoir is attached to the 
                                                          Insulin Delivery Device. */
    uint8_t                   e2e_counter;                /**< E2E Counter value */
    uint16_t                  e2e_crc;                    /**< E2E CRC value */
} st_ble_idc_idd_status_t;

/*******************************************************************************************************************//**
 * @brief IDD Annunciation Status characteristic parameters.
***********************************************************************************************************************/
typedef struct 
{
    bool     is_annunciation_present;  /**< If this bit is set, the fields Annunciation Instance ID, Annunciation 
                                       Type, and Annunciation Status are present (i.e., there is a currently active
                                       or already confirmed annunciation). This bit shall not be set if there has not 
                                       been an annunciation yet. */
    bool     is_auxinfo1_present;      /**< If this bit is set, the AuxInfo1 field is present. */
    bool     is_auxinfo2_present;      /**< If this bit is set, the AuxInfo2 field is present. */
    bool     is_auxinfo3_present;      /**< If this bit is set, the AuxInfo3 field is present. */
    bool     is_auxinfo4_present;      /**< If this bit is set, the AuxInfo4 field is present. */
    bool     is_auxinfo5_present;      /**< If this bit is set, the AuxInfo5 field is present. */
    uint16_t annunciation_instance_id; /**< Annunciation Instance ID value */
    uint16_t annunciation_type;        /**< Annunciation Type value */
    uint8_t  annunciation_status;      /**< Annunciation Status value */
    uint16_t auxinfo1;                 /**< AuxInfo1 value */
    uint16_t auxinfo2;                 /**< AuxInfo2 value */
    uint16_t auxinfo3;                 /**< AuxInfo3 value */
    uint16_t auxinfo4;                 /**< AuxInfo4 value */
    uint16_t auxinfo5;                 /**< AuxInfo5 value */
    uint8_t  e2e_counter;              /**< E2E Counter value */
    uint16_t e2e_crc;                  /**< E2E CRC value */
} st_ble_idc_idd_annunciation_status_t;

/*******************************************************************************************************************//**
 * @brief IDD Features characteristic parameters.
***********************************************************************************************************************/
typedef struct 
{
    uint16_t e2e_crc;                                       /**< E2E CRC value */
    uint8_t e2e_counter;                                    /**< E2E Counter value */
    st_ble_ieee11073_sfloat_t insulin_concentration;        /**< Insulin Concentration value */
    bool is_e2e_protection_supported;                       /**< If this bit is set, an E2E-Protection is attached to 
                                                            all characteristics. */
    bool is_basel_rate_supported;                           /**< If this bit is set, the Insulin Delivery Device supports
                                                            the delivery of a basal rate including support for profile 
                                                            templates to define different basal rate profiles. */
    bool is_tbr_absolute_supported;                         /**< If this bit is set, the Insulin Delivery Device supports 
                                                            an absolute temporary basal rate in IU/h.*/
    bool is_tbr_relative_supported;                         /**< If this bit is set, the Insulin Delivery Device supports
                                                            a relative temporary basal rate expressed by a dimensionless
                                                            scaling factor. */
    bool is_tbr_template_supported;                         /**< f this bit is set, the Insulin Delivery Device supports 
                                                            templates to define different TBRs with preset values. */
    bool is_fast_bolus_supported;                           /**< If this bit is set, the Insulin Delivery Device has the 
                                                            capability to deliver fast boluses. */
    bool is_extented_bolus_supported;                       /**< If this bit is set, the Insulin Delivery Device has the 
                                                            capability to deliver extended boluses. */
    bool is_multiwave_bolus_supported;                      /**< If this bit is set, the Insulin Delivery Device has the
                                                            capability to deliver multiwave boluses. */
    bool is_bolus_delay_time_supported;                     /**< If this bit is set, the Insulin Delivery Device supports 
                                                            a bolus delay time in minutes. */
    bool is_bolus_template_supported;                       /**< If this bit is set, the Insulin Delivery Device supports
                                                            templates to define boluses (of same or different type) 
                                                            with preset values. */
    bool is_bolus_activation_type_supported;                /**< If this bit is set, the Insulin Delivery Device supports 
                                                            a bolus activation type, which provides additional information 
                                                            about the source, and if possible, the determination of the 
                                                            bolus amount. */
    bool is_multiple_bond_supported;                        /**< If this bit is set, the Insulin Delivery Device supports
                                                            multiple bonded devices. */
    bool is_isf_profile_template_supported;                 /**< If this bit is set, the Insulin Delivery Device supports
                                                            profile templates to define different ISF profiles. */
    bool is_I2CHO_ratio_profile_template_supported;         /**< If this bit is set, the Insulin Delivery Device supports
                                                            profile templates to define different I:CHO Ratio profiles. */
    bool is_target_glucose_range_profile_template_supported;/**< If this bit is set, the Insulin Delivery Device supports
                                                            target glucose range profile templates to define different 
                                                            target glucose range profiles. */
    bool is_insulin_on_board_supported;                     /**< If this bit is set, the Insulin Delivery Device enables
                                                            Clients to get the current insulin on board. */
    bool is_feature_extension_set;                          /**< If the Feature Extension bit is set, an additional octet 
                                                            is attached (bits 24 �31), where bit 31 shall be used as Feature
                                                            Extension bit in the same way. If this bit is set, then another 
                                                            octet is attached (bits 32 �39) and so on. */
} st_ble_idc_idd_features_t;

/*******************************************************************************************************************//**
 * @brief IDD Status Reader Control Point characteristic parameters.
***********************************************************************************************************************/
typedef struct 
{
    uint16_t                                                              op_code;                                /**< Op Code 
                                                                                                                  value */
    st_ble_idc_idd_srcp_response_code_operand_t                           response_code;                          /**< Response
                                                                                                                  Code */
    st_ble_idc_idd_srcp_reset_status_operand_t                            reset_status;                           /**< Reset 
                                                                                                                  Status */
    st_ble_idc_idd_srcp_get_active_bolusids_response_operand_t            get_active_bolusids_response;           /**< This is 
                                                                                                                  the normal 
                                                                                                                  response to 
                                                                                                                  Get Active 
                                                                                                                  Bolus IDC. */
    st_ble_idc_idd_srcp_get_active_bolus_delivery_operand_t               get_active_bolus_delivery;              /**< Gets 
                                                                                                                  information 
                                                                                                                  about an 
                                                                                                                  Active Bolus 
                                                                                                                  identified by 
                                                                                                                  the given ID. */
    st_ble_idc_idd_srcp_get_active_bolus_delivery_response_operand_t      get_active_bolus_delivery_response;     /**< This is the 
                                                                                                                  normal response 
                                                                                                                  to Get Active 
                                                                                                                  Bolus Delivery. */
    st_ble_idc_idd_srcp_get_active_basel_rate_delivery_response_operand_t get_active_basel_rate_delivery_response;/**< This is the 
                                                                                                                  normal response 
                                                                                                                  to Get Active 
                                                                                                                  Basal Rate 
                                                                                                                  Delivery. */
    st_ble_idc_idd_srcp_get_total_daily_insulin_status_response_operand_t get_total_daily_insulin_status;         /**< This is the 
                                                                                                                  normal response 
                                                                                                                  to Get Total Daily 
                                                                                                                  Insulin Status. */
    st_ble_idc_idd_srcp_get_counter_operand_t                             get_counter;                            /**< Gets the 
                                                                                                                  value about an
                                                                                                                  internal counter
                                                                                                                  of the Insulin
                                                                                                                  Delivery Device. */
    st_ble_idc_idd_srcp_get_counter_response_operand_t                    get_counter_response;                   /**< This is the 
                                                                                                                  normal response 
                                                                                                                  to procedure 
                                                                                                                  Get Counter. */
    st_ble_idc_idd_srcp_get_delivered_insulin_response_operand_t          get_delivered_insulin_response;         /**< This is 
                                                                                                                  the normal 
                                                                                                                  response to 
                                                                                                                  procedure Get 
                                                                                                                  Delivered 
                                                                                                                  Insulin. */
    st_ble_idc_idd_srcp_get_insulin_onbord_response_operand_t             get_insulin_onbord_response;            /**< This is 
                                                                                                                  the normal 
                                                                                                                  response to 
                                                                                                                  procedure Get 
                                                                                                                  Insulin On 
                                                                                                                  Board.*/
    uint8_t                                                               e2e_counter;                            /**< E2E 
                                                                                                                  Counter value */
    uint16_t                                                              e2e_crc;                                /**< E2E 
                                                                                                                  CRC value */
} st_ble_idc_idd_status_reader_control_point_t;

/*******************************************************************************************************************//**
 * @brief IDD Command Control Point characteristic parameters.
***********************************************************************************************************************/
typedef struct 
{
    uint16_t                                                  op_code;                                   /**< Op Code 
                                                                                                         value */
    st_ble_idc_idd_ccp_response_code_operand_t                ccp_resp_code;                             /**< Response 
                                                                                                         Code */
    uint8_t                                                   set_therapy_control_state;                 /**< Set Therapy 
                                                                                                         Control State.*/
    uint16_t                                                  snooze_annunciation_instance_id;           /**< Snoozes an 
                                                                                                         annunciation for 
                                                                                                         a limited amount
                                                                                                         of time.*/
    uint16_t                                                  snooze_annunciation_instance_id_response;  /**< This is the
                                                                                                         normal response 
                                                                                                         to Snooze 
                                                                                                         Annunciation.*/
    uint16_t                                                  confirm_annunciation_instance_id;          /**<Confirms an 
                                                                                                         annunciation on 
                                                                                                         the Server 
                                                                                                         Application and 
                                                                                                         removes this 
                                                                                                         specific annunciation
                                                                                                         from the list of 
                                                                                                         currently active 
                                                                                                         annunciations on 
                                                                                                         the Server Application. */
    uint16_t                                                  confirm_annunciation_instance_id_response; /**<This is the 
                                                                                                         normal response 
                                                                                                         to Confirm 
                                                                                                         Annunciation. */
    uint8_t                                                   basel_rate_profile_template_number;        /**<Reads a 
                                                                                                         specific Basal 
                                                                                                         Rate Profile 
                                                                                                         Template. */
    st_ble_idc_idd_ccp_write_brp_template_operand_t           write_basal_rate_profile_template;         /**< Writes a 
                                                                                                         specific Basal 
                                                                                                         Rate Profile 
                                                                                                         Template.*/
    st_ble_idc_idd_ccp_write_brp_template_response_operand_t  write_basal_rate_profile_template_response;/**<This is the 
                                                                                                         normal response 
                                                                                                         to Write Basal 
                                                                                                         Rate Profile 
                                                                                                         Template.. */
    st_ble_idc_idd_ccp_set_tbr_adjustment_operand_t           set_tbr_adjustment;                        /**< Sets a new or 
                                                                                                         changes a 
                                                                                                         currently active TBR.*/
    uint8_t                                                   get_tbr_template_number;                   /**< Gets the 
                                                                                                         parameters of a 
                                                                                                         specific TBR template.*/
    st_ble_idc_idd_ccp_get_tbr_template_response_operand_t    get_tbr_template_response;                 /**<This is the 
                                                                                                         normal response 
                                                                                                         to Get TBR Template. */
    st_ble_idc_idd_ccp_set_tbr_template_operand_t             set_tbr_template;                          /**<Sets the parameters 
                                                                                                         of a specific TBR 
                                                                                                         template. */
    uint8_t                                                   set_tbr_template_number_response;          /**<This is the normal 
                                                                                                         response to Set TBR 
                                                                                                         Template. */
    st_ble_idc_idd_ccp_set_bolus_operand_t                    set_bolus;                                 /**<Sets a bolus with 
                                                                                                         the specified parameters.
                                                                                                         The normal response 
                                                                                                         to this control point 
                                                                                                         is Set Bolus Response. */
    uint16_t                                                  bolus_response;                            /**<This is the normal 
                                                                                                         response to Set Bolus. */
    uint16_t                                                  cancel_bolus_id;                           /**<Cancels a bolus 
                                                                                                         with the specified
                                                                                                         Bolus ID. */
    uint16_t                                                  cancel_bolus_id_response;                  /**<This is the normal 
                                                                                                         response to Cancel 
                                                                                                         Bolus. */
    st_ble_idc_idd_ccp_get_available_boluses_res_t            get_available_boluses_response;            /**<Gets the currently 
                                                                                                         available bolus types. */
    uint8_t                                                   bouls_template_number;                     /**< Gets the parameters
                                                                                                         of a specific bolus 
                                                                                                         template.*/
    st_ble_idc_idd_ccp_get_bolus_template_response_operand_t  get_bolus_template_response;               /**<This is the normal 
                                                                                                         response to Get Bolus 
                                                                                                         Template. */
    st_ble_idc_idd_ccp_get_bolus_template_response_operand_t  set_bolus_template;                        /**<Sets the parameters 
                                                                                                         of a specific bolus 
                                                                                                         template. */
    uint8_t                                                   set_bolus_template_res;                    /**<This is the normal 
                                                                                                         response to Set Bolus
                                                                                                         Template. */
    st_ble_idc_idd_ccp_reset_template_status_operand_t        reset_template_status;                     /**<Resets the status 
                                                                                                         of one or many templates 
                                                                                                         by marking them as Not
                                                                                                         Configured. */
    st_ble_idc_idd_ccp_reset_template_status_operand_t        status_response;                           /**<This is the normal
                                                                                                         response to Reset 
                                                                                                         Template Status. */
    st_ble_idc_idd_ccp_active_prof_template_operand_t         active_prof_template;                      /**<Activates profile 
                                                                                                         templates. The normal
                                                                                                         response to this control 
                                                                                                         point is Activate Profile 
                                                                                                         Templates Response. */
    st_ble_idc_idd_ccp_active_prof_template_operand_t         active_prof_template_response;             /**<This is the normal 
                                                                                                         response to Activate 
                                                                                                         Profile Templates. */
    st_ble_idc_idd_ccp_active_prof_template_operand_t         get_active_prof_template_response;         /**< This is the 
                                                                                                         normal response to 
                                                                                                         Get Activated 
                                                                                                         Profile Templates.*/
    st_ble_ieee11073_sfloat_t                                 statr_priming_amount;                      /**<Starts the 
                                                                                                         priming of the fluidic 
                                                                                                         path of the Insulin 
                                                                                                         Delivery Device with 
                                                                                                         the provided amount of 
                                                                                                         insulin. */
    st_ble_ieee11073_sfloat_t                                 reservoir_fill_level;                      /**<Sets the initial 
                                                                                                         fill level of the
                                                                                                         reservoir after 
                                                                                                         refill or replacement. */
    uint8_t                                                   read_isf_prof_template_num;                /**<Reads a specific 
                                                                                                         ISF Profile Template. */
    st_ble_idc_idd_ccp_write_ipt_operand_t                    write_isf_prof_template;                   /**<Writes a specific 
                                                                                                         ISF Profile Template. */
    st_ble_idc_idd_ccp_write_ipt_res_operand_t                write_isf_prof_template_response;          /**<This is the normal 
                                                                                                         response to Write ISF 
                                                                                                         Profile Template. */
    uint8_t                                                   i2cho_ratio_prof_template_number;          /**<Reads a specific
                                                                                                         I:CHO Ratio Profile 
                                                                                                         Template. */
    st_ble_idc_idd_ccp_write_irpt_operand_t                   write_icho_ratio_profile;                  /**<Writes a specific 
                                                                                                         I:CHO Ratio Profile 
                                                                                                         Template.. */
    st_ble_idc_idd_ccp_write_irpt_res_operand_t               write_icho_ratio_prof_tempate_response;    /**<This is the normal 
                                                                                                         response to Write I2CHO
                                                                                                         Ratio Profile Template. */
    uint8_t                                                   target_glucose_range_prof_template_number; /**<Reads a specific 
                                                                                                         Target Glucose Range 
                                                                                                         Profile Template. */
    st_ble_idc_idd_ccp_write_tgrp_operand_t                   write_target_glucose_range_profile;        /**<Writes a specific
                                                                                                         Target Glucose Range 
                                                                                                         Profile Template. */
    st_ble_idc_idd_ccp_write_tgrp_response_operand_t          glucose_range_profile_response;            /**<This is the normal 
                                                                                                         response to Write Target 
                                                                                                         Glucose Range Profile Template. */
    st_ble_ieee11073_sfloat_t                                 get_max_bolus_amout_resp;                  /**< This is the normal 
                                                                                                         response to Get Max Bolus Amount. */
    st_ble_ieee11073_sfloat_t                                 set_max_bolus_amout;                       /**< Sets the maximum 
                                                                                                         bolus amount that can be 
                                                                                                         delivered in a single bolus */
    uint8_t                                                   e2e_counter;                               /**< E2E Counter value */
    uint16_t                                                  e2e_crc;                                   /**< E2E CRC value */
} st_ble_idc_idd_command_control_point_t;

/*******************************************************************************************************************//**
 * @brief IDD Command Data characteristic parameters.
***********************************************************************************************************************/
typedef struct 
{
    uint16_t                                                 response_op_code;                         /**< Response Op Code 
                                                                                                       value */
    st_ble_idc_idd_ccp_response_code_operand_t               ccp_resp_code;                            /**< Response Code */
    uint8_t                                                  set_therapy_control_state;                /**< Set Therapy 
                                                                                                       Control State.*/
    uint16_t                                                 snooze_annunciation_instance_id;          /**< Snoozes an 
                                                                                                       annunciation for a 
                                                                                                       limited amount of time.*/
    uint16_t                                                 snooze_annunciation_instance_id_response; /**< This is the normal 
                                                                                                       response to Snooze 
                                                                                                       Annunciation.*/
    uint16_t                                                 confirm_annunciation_instance_id;         /**<Confirms an annunciation 
                                                                                                       on the Server Application 
                                                                                                       and removes this specific 
                                                                                                       annunciation from the list 
                                                                                                       of currently active 
                                                                                                       annunciations on the 
                                                                                                       Server Application. */
    uint16_t                                                 confirm_annunciation_instance_id_res;     /**<This is the normal 
                                                                                                       response to Confirm 
                                                                                                       Annunciation. */
    uint8_t                                                  basel_rate_profile_template_number;       /**<Reads a specific 
                                                                                                       Basal Rate Profile 
                                                                                                       Template. */
    st_ble_idc_idd_cd_read_brpt_response_operand_t           read_basel_rate_profile_template_response;/**< Read Basal Rate 
                                                                                                       Profile Template 
                                                                                                       Response*/
    st_ble_idc_idd_ccp_write_brp_template_operand_t          write_brp_template;                       /**< Writes a specific 
                                                                                                       Basal Rate Profile 
                                                                                                       Template.*/
    st_ble_idc_idd_ccp_write_brp_template_response_operand_t write_brp_template_response;              /**<This is the normal
                                                                                                       response to Write Basal 
                                                                                                       Rate Profile Template.. */
    st_ble_idc_idd_ccp_set_tbr_adjustment_operand_t          set_tbr_adjustment;                       /**< Sets a new or 
                                                                                                       changes a currently 
                                                                                                       active TBR.*/
    uint8_t                                                  get_tbr_template_number;                  /**< Gets the parameters 
                                                                                                       of a specific TBR 
                                                                                                       template.*/
    st_ble_idc_idd_ccp_get_tbr_template_response_operand_t   get_tbr_template_response;                /**<This is the normal 
                                                                                                       response to Get 
                                                                                                       TBR Template. */
    st_ble_idc_idd_ccp_set_tbr_template_operand_t            set_tbr_template;                         /**<Sets the parameters 
                                                                                                       of a specific TBR 
                                                                                                       template. */
    uint8_t                                                  set_tbr_template_number_response;         /**<This is the normal 
                                                                                                       response to Set TBR 
                                                                                                       Template. */
    st_ble_idc_idd_ccp_set_bolus_operand_t                   set_bolus;                                /**<Sets a bolus with 
                                                                                                       the specified parameters.
                                                                                                       The normal response to 
                                                                                                       this control point is 
                                                                                                       Set Bolus Response. */
    uint16_t                                                 bolus_response;                           /**<This is the normal 
                                                                                                       response to Set Bolus. */
    uint16_t                                                 cancel_bolus_id;                         /**<Cancels a bolus with 
                                                                                                      the specified Bolus ID. */
    uint16_t                                                 cancel_bolus_id_response;                 /**<This is the normal 
                                                                                                       response to Cancel Bolus. */
    st_ble_idc_idd_ccp_get_available_boluses_res_t           get_available_boluses_res;                /**<Gets the currently
                                                                                                       available bolus types. */
    uint8_t                                                  bouls_template_number;                    /**< Gets the parameters of 
                                                                                                       a specific bolus template.*/
    st_ble_idc_idd_ccp_get_bolus_template_response_operand_t get_bolus_template_res;                   /**<This is the normal 
                                                                                                       response to Get Bolus 
                                                                                                       Template. */
    st_ble_idc_idd_ccp_get_bolus_template_response_operand_t set_bolus_temp;                           /**<Sets the parameters of a 
                                                                                                       specific bolus template. */
    uint8_t                                                  set_bolus_template_res;                   /**<This is the normal response 
                                                                                                       to Set Bolus Template. */
    st_ble_idc_idd_cd_get_temstatus_details_response_t       get_temstatus_details_response;           /**<Operand of Get Template 
                                                                                                       Status and Details Response. */
    st_ble_idc_idd_ccp_reset_template_status_operand_t       reset_template_status;                    /**<Resets the status of 
                                                                                                       one or many templates by 
                                                                                                       marking them as Not 
                                                                                                       Configured. */
    st_ble_idc_idd_ccp_reset_template_status_operand_t       status_response;                          /**<This is the normal 
                                                                                                       response to Reset 
                                                                                                       Template Status. */
    st_ble_idc_idd_ccp_active_prof_template_operand_t        active_prof_template;                     /**<Activates profile 
                                                                                                       templates. The normal 
                                                                                                       response to this 
                                                                                                       control point is 
                                                                                                       Activate Profile 
                                                                                                       Templates Response. */
    st_ble_idc_idd_ccp_active_prof_template_operand_t        active_prof_template_response;            /**<This is the normal 
                                                                                                       response to Activate 
                                                                                                       Profile Templates. */
    st_ble_idc_idd_ccp_active_prof_template_operand_t        get_active_prof_template_res;             /**< This is the normal 
                                                                                                       response to Get Activated 
                                                                                                       Profile Templates.*/
    st_ble_ieee11073_sfloat_t                                statr_priming_amount;                     /**<Starts the priming 
                                                                                                       of the fluidic path of 
                                                                                                       the Insulin Delivery 
                                                                                                       Device with the provided 
                                                                                                       amount of insulin. */
    st_ble_ieee11073_sfloat_t                                reservoir_fill_level;                     /**<Sets the initial 
                                                                                                       fill level of the 
                                                                                                       reservoir after 
                                                                                                       refill or replacement. */
    uint8_t                                                  read_isf_prof_template_num;               /**<Reads a specific 
                                                                                                       ISF Profile Template. */
    st_ble_idc_idd_cd_read_isfpt_response_t                  read_isfpt_reasponse;                     /**< Read ISF Profile 
                                                                                                       Template Response.*/
    st_ble_idc_idd_ccp_write_ipt_operand_t                   write_isf_prof_template;                  /**<Writes a specific 
                                                                                                       ISF Profile Template. */
    st_ble_idc_idd_ccp_write_ipt_res_operand_t               write_isf_prof_template_res;              /**<This is the normal 
                                                                                                       response to Write ISF
                                                                                                       Profile Template. */
    uint8_t                                                  i2cho_ratio_prof_template_num;            /**<Reads a specific 
                                                                                                       I:CHO Ratio Profile 
                                                                                                       Template. */
    st_ble_idc_idd_cd_i2chorpt_response_t                    i2chorpt_response;                        /**<Read I2CHO Ratio 
                                                                                                       Profile Template
                                                                                                       Response. */
    st_ble_idc_idd_ccp_write_irpt_operand_t                  write_icho_ratio_prof;                    /**<Writes a specific 
                                                                                                       I2CHO Ratio Profile 
                                                                                                       Template.. */
    st_ble_idc_idd_ccp_write_irpt_res_operand_t              write_icho_ratio_prof_tempate_res;        /**<This is the normal 
                                                                                                       response to Write I2CHO 
                                                                                                       Ratio Profile Template. */
    uint8_t                                                  tgrp_template_number;                     /**<Reads a specific 
                                                                                                       Target Glucose Range 
                                                                                                       Profile Template. */
    st_ble_idc_idd_cd_target_glucose_range_response_t        target_glucose_range_response;            /**<Read Target Glucose
                                                                                                       Range Profile Template 
                                                                                                       Response */
    st_ble_idc_idd_ccp_write_tgrp_operand_t                  write_target_glucose_range_profile;       /**<Writes a specific 
                                                                                                       Target Glucose Range 
                                                                                                       Profile Template. */
    st_ble_idc_idd_ccp_write_tgrp_response_operand_t         glucose_range_profile_response;           /**<This is the normal 
                                                                                                       response to Write Target 
                                                                                                       Glucose Range Profile 
                                                                                                       Template. */
    st_ble_ieee11073_sfloat_t                                get_max_bolus_amout_resp;                 /**< This is the normal 
                                                                                                       response to Get Max 
                                                                                                       Bolus Amount. */
    st_ble_ieee11073_sfloat_t                                set_max_bolus_amout;                      /**< Sets the maximum 
                                                                                                       bolus amount that can 
                                                                                                       be delivered in a 
                                                                                                       single bolus */
    uint8_t                                                  e2e_counter;                              /**< E2E Counter value */
    uint16_t                                                 e2e_crc;                                  /**< E2E CRC value */
} st_ble_idc_idd_command_data_t;

/*******************************************************************************************************************//**
 * @brief IDD Record Access Control Point characteristic parameters.
***********************************************************************************************************************/
typedef struct 
{
    uint8_t  racp_op_code;                              /**< Op Code value */
    uint8_t  racp_operator;                             /**< Operator value */
    uint8_t  operand_length;                            /**< operand length */
    uint8_t  racp_operand[BLE_IDC_RACP_OPERAND_LENGTH]; /**< Operand value */
    uint8_t  e2e_counter;                               /**< E2E Counter value */
    uint16_t e2e_crc;                                   /**< E2E CRC value */
} st_ble_idc_idd_record_access_control_point_t;

/*******************************************************************************************************************//**
 * @brief IDD History Data characteristic parameters.
***********************************************************************************************************************/
typedef struct
{
    uint16_t                                                               event_type;                             /**< Event 
                                                                                                                   Type value */
    uint32_t                                                               seq_num;                                /**< Sequence
                                                                                                                   Number value */
    uint16_t                                                               relative_offset;                        /**< Relative 
                                                                                                                   Offset value */
    st_ble_idc_idd_history_data_ref_time_event_t                           ref_time;                               /**< Reference 
                                                                                                                   Time */
    st_ble_idc_idd_history_data_ref_time_baseoffset_event_t                ref_time_baseoffset;                    /**< Reference 
                                                                                                                   Time Base Offset */
    st_ble_idc_idd_history_data_bolus_calculated_part_1_of_2_event_t       bolus_calculated_part_1_of_2;           /**< Bolus 
                                                                                                                   Calculated 
                                                                                                                   Part 1 of 2 */
    st_ble_idc_idd_history_data_bolus_calculated_part_2_of_2_event_t       bolus_calculated_part_2_of_2;           /**< Bolus 
                                                                                                                   Calculated 
                                                                                                                   Part 2 of 2 */
    st_ble_idc_idd_history_data_bolus_programmed_part_1_of_2_event_t       bolus_programmed_part_1_of_2;           /**< Bolus 
                                                                                                                   Programmed 
                                                                                                                   Part 1 of 2 */
    st_ble_idc_idd_history_data_bolus_programmed_part_2_of_2_event_t       bolus_programmed_part_2_of_2;           /**< Bolus 
                                                                                                                   Programmed 
                                                                                                                   Part 2 of 2 */
    st_ble_idc_idd_history_data_bolus_delivered_part_1_of_2_event_t        bolus_delivered_part_1_of_2;            /**< Bolus 
                                                                                                                   Delivered 
                                                                                                                   Part 1 of 2 */
    st_ble_idc_idd_history_data_bolus_delivered_part_2_of_2_event_t        bolus_delivered_part_2_of_2;            /**< Bolus 
                                                                                                                   Delivered 
                                                                                                                   Part 2 of 2 */
    st_ble_idc_idd_history_delivered_basal_rate_changed_event_t            delivered_basal_rate_changed;           /**< Delivered
                                                                                                                   Basal Rate 
                                                                                                                   Changed */
    st_ble_idc_idd_history_tbr_adjustment_started_event_t                  tbr_adjustment_started;                 /**< TBR 
                                                                                                                   Adjustment 
                                                                                                                   Started */
    st_ble_idc_idd_history_tbr_adjustment_ended_event_t                    tbr_adjustment_ended;                   /**< TBR 
                                                                                                                   Adjustment 
                                                                                                                   Ended */
    st_ble_idc_idd_history_tbr_adjustment_changed_event_t                  tbr_adjustment_changed;                 /**< TBR 
                                                                                                                   Adjustment 
                                                                                                                   Changed */
    st_ble_idc_idd_history_pro_template_activated_event_t                  pro_template_activated;                 /**< Profile 
                                                                                                                   Template 
                                                                                                                   Activated */
    st_ble_idc_idd_history_brpt_time_block_changed_event_t                 brpt_time_block_changed;                /**< Basal 
                                                                                                                   Rate Profile 
                                                                                                                   Template Time 
                                                                                                                   Block Changed */
    st_ble_idc_idd_history_total_daily_insulin_delivery_event_t            total_daily_insulin_delivery;           /**< Total Daily 
                                                                                                                   Insulin Delivery */
    st_ble_idc_idd_history_therapy_control_state_event_t                   therapy_control_state;                  /**< Therapy 
                                                                                                                   Control State 
                                                                                                                   Changed */
    st_ble_idc_idd_history_operational_state_changed_event_t               operational_state_changed;              /**< Operational 
                                                                                                                   State Changed */
    st_ble_ieee11073_sfloat_t                                              reservoir_remaining_amount;             /**< Reservoir 
                                                                                                                   Remaining Amount 
                                                                                                                   Changed */
    st_ble_idc_idd_history_annunciation_status_changed_part_1_of_2_event_t annunciation_status_changed_part_1_of_2;/**< Annunciation 
                                                                                                                   Status Changed 
                                                                                                                   Part 1 of 2 */
    st_ble_idc_idd_history_annunciation_status_changed_part_2_of_2_event_t annunciation_status_changed_part_2_of_2;/**< Annunciation 
                                                                                                                   Status Changed 
                                                                                                                   Part 2 of 2 */
    st_ble_idc_idd_history_isfpt_time_block_changed_event_t                isfpt_time_block_changed;               /**< ISF Profile 
                                                                                                                   Template Time 
                                                                                                                   Block Changed */
    st_ble_idc_idd_history_i2chorpt_time_block_changed_event_t             i2chorpt_time_block_changed;            /**< I2CHO Ratio 
                                                                                                                   Profile Template 
                                                                                                                   Time Block Changed */
    st_ble_idc_idd_history_tgrpt_time_block_changed_event_t                tgrpt_time_block_changed;               /**< Target 
                                                                                                                   Glucose Range 
                                                                                                                   Profile Template 
                                                                                                                   Time Block Changed */
    st_ble_ieee11073_sfloat_t                                              priming_started;                        /**< Priming 
                                                                                                                   Started */
    st_ble_idc_idd_history_priming_done_event_t                            priming_done;                           /**< Priming 
                                                                                                                   Done */
    st_ble_idc_idd_history_bolus_template_changed_part_1_of_2_event_t      bolus_template_changed_part_1_of_2;     /**< Bolus Template 
                                                                                                                   Changed Part 1 of 2 */
    st_ble_idc_idd_history_bolus_template_changed_part_2_of_2_event_t      bolus_template_changed_part_2_of_2;     /**< Bolus Template 
                                                                                                                   Changed Part 2 of 2 */
    st_ble_idc_idd_history_tbr_template_changed_event_t                    tbr_template_changed;                   /**< TBR Template 
                                                                                                                   Changed */
    st_ble_idc_idd_history_max_bolus_amount_changed_event_t                max_bolus_amount_changed;               /**< Max Bolus Amount 
                                                                                                                   Changed */
    uint16_t                                                               e2e_crc;                                /**< E2E CRC value */
} st_ble_idc_idd_history_data_t;

/***********************************************************************************************************************
Exported global variables (to be accessed by other files)
***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @brief Insulin Delivery Service UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_IDC_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief IDD Status Changed characteristic UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_IDC_IDD_STATUS_CHANGED_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief IDD Status characteristic UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_IDC_IDD_STATUS_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief IDD Annunciation Status characteristic UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_IDC_IDD_ANNUNCIATION_STATUS_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief IDD Features characteristic UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_IDC_IDD_FEATURES_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief IDD Status Reader Control Point characteristic UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_IDC_IDD_STATUS_READER_CONTROL_POINT_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief IDD Command Control Point characteristic UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_IDC_IDD_COMMAND_CONTROL_POINT_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief IDD Command Data characteristic UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_IDC_IDD_COMMAND_DATA_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief IDD Record Access Control Point characteristic UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_IDC_IDD_RECORD_ACCESS_CONTROL_POINT_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief IDD History Data characteristic UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_IDC_IDD_HISTORY_DATA_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/***********************************************************************************************************************
Exported global functions (to be accessed by other files)
***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @brief     Initialize Insulin Delivery Service  Client.
 * @details   This function shall be called once at startup.
 * @param[in] p_param Pointer to Insulin Delivery Service Client initialization parameters.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_IDC_Init(const st_ble_idc_init_param_t *p_param);

/*******************************************************************************************************************//**
 * @brief     Perform Insulin Delivery Service Client connection settings.
 * @details   This function shall be called on each connection establishment.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_param Pointer to Connection parameters.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_IDC_Connect(uint16_t conn_hdl, const st_ble_idc_connect_param_t *p_param);

/*******************************************************************************************************************//**
 * @brief     Retrieve Insulin Delivery Service Client connection specific settings before disconnection.
 * @details   This function shall be called on each disconnection.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_param Pointer to Disconnection parameters.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_IDC_Disconnect(uint16_t conn_hdl, st_ble_idc_disconnect_param_t *p_param);

/*******************************************************************************************************************//**
 * @brief      Read IDD Status Changed characteristic value from remote GATT database.
 * @param[in]  conn_hdl Connection handle.
 * @return     @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_IDC_ReadIddStatusChanged(uint16_t conn_hdl);

/*******************************************************************************************************************//**
 * @brief     Set IDD Status Changed characteristic cli cnfg.
 * @param[in] conn_hdl Connection handle.
 * @param[in] cli_cnfg IDD Status Changed characteristic cli cnfg to set.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_IDC_SetIddStatusChangedCliCnfg(uint16_t conn_hdl, uint16_t cli_cnfg);

/*******************************************************************************************************************//**
 * @brief      Read IDD Status characteristic value from remote GATT database.
 * @param[in]  conn_hdl Connection handle.
 * @return     @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_IDC_ReadIddStatus(uint16_t conn_hdl);

/*******************************************************************************************************************//**
 * @brief     Set IDD Status characteristic cli cnfg.
 * @param[in] conn_hdl Connection handle.
 * @param[in] cli_cnfg IDD Status characteristic cli cnfg to set.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_IDC_SetIddStatusCliCnfg(uint16_t conn_hdl, uint16_t cli_cnfg);

/*******************************************************************************************************************//**
 * @brief      Read IDD Annunciation Status characteristic value from remote GATT database.
 * @param[in]  conn_hdl Connection handle.
 * @return     @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_IDC_ReadIddAnnunciationStatus(uint16_t conn_hdl);

/*******************************************************************************************************************//**
 * @brief     Set IDD Annunciation Status characteristic cli cnfg.
 * @param[in] conn_hdl Connection handle.
 * @param[in] cli_cnfg IDD Annunciation Status characteristic cli cnfg to set.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_IDC_SetIddAnnunciationStatusCliCnfg(uint16_t conn_hdl, uint16_t cli_cnfg);

/*******************************************************************************************************************//**
 * @brief      Read IDD Features characteristic value from remote GATT database.
 * @param[in]  conn_hdl  Connection handle.
 * @return     @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_IDC_ReadIddFeatures(uint16_t conn_hdl);

/*******************************************************************************************************************//**
 * @brief     Write IDD Status Reader Control Point characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] p_app_value Pointer to IDD Status Reader Control Point characteristic value to write.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_IDC_WriteIddStatusReaderControlPoint(uint16_t conn_hdl, const st_ble_idc_idd_status_reader_control_point_t *p_app_value);

/*******************************************************************************************************************//**
 * @brief     Set IDD Status Reader Control Point characteristic cli cnfg.
 * @param[in] conn_hdl Connection handle.
 * @param[in] cli_cnfg IDD Status Reader Control Point characteristic cli cnfg to set.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_IDC_SetIddStatusReaderControlPointCliCnfg(uint16_t conn_hdl, uint16_t cli_cnfg);

/*******************************************************************************************************************//**
 * @brief     Write IDD Command Control Point characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] p_app_value Pointer to IDD Command Control Point characteristic value to write.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_IDC_WriteIddCommandControlPoint(uint16_t conn_hdl, const st_ble_idc_idd_command_control_point_t *p_app_value);

/*******************************************************************************************************************//**
 * @brief     Set IDD Command Control Point characteristic cli cnfg.
 * @param[in] conn_hdl Connection handle.
 * @param[in] cli_cnfg IDD Command Control Point characteristic cli cnfg to set.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_IDC_SetIddCommandControlPointCliCnfg(uint16_t conn_hdl, uint16_t cli_cnfg);

/*******************************************************************************************************************//**
 * @brief     Set IDD Command Data characteristic cli cnfg.
 * @param[in] conn_hdl Connection handle.
 * @param[in] cli_cnfg IDD Command Data characteristic cli cnfg to set.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_IDC_SetIddCommandDataCliCnfg(uint16_t conn_hdl, uint16_t cli_cnfg);

/*******************************************************************************************************************//**
 * @brief     Write IDD Record Access Control Point characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] p_app_value Pointer to IDD Record Access Control Point characteristic value to write.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_IDC_WriteIddRecordAccessControlPoint(uint16_t conn_hdl, const st_ble_idc_idd_record_access_control_point_t *p_app_value);

/*******************************************************************************************************************//**
 * @brief     Set IDD Record Access Control Point characteristic cli cnfg.
 * @param[in] conn_hdl Connection handle.
 * @param[in] cli_cnfg IDD Record Access Control Point characteristic cli cnfg to set.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_IDC_SetIddRecordAccessControlPointCliCnfg(uint16_t conn_hdl, uint16_t cli_cnfg);

/*******************************************************************************************************************//**
 * @brief     Set IDD History Data characteristic cli cnfg.
 * @param[in] conn_hdl Connection handle.
 * @param[in] cli_cnfg IDD History Data characteristic cli cnfg to set.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_IDC_SetIddHistoryDataCliCnfg(uint16_t conn_hdl, uint16_t cli_cnfg);

/***********************************************************************************************************************
 * @brief      Callback function for the Insulin Delivery Discovery events.
 * @param[in]  conn_hdl Connection handle.
 * @param[in]  idx      Service index used to distiguish the multiple same UUID service.
 * @param[in]  type     Discovery event type
 * @param[out] p_param  Pointer to GATTC event data.
***********************************************************************************************************************/
void R_BLE_IDC_ServDiscCb(uint16_t conn_hdl, uint8_t idx, uint16_t type, void *p_param);

/*******************************************************************************************************************//**
 * @brief     Return version of the IDC service client.
 * @return    version
***********************************************************************************************************************/
uint32_t R_BLE_IDC_GetVersion(void);

#endif /* R_BLE_IDC_H */

/** @} */
