/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_idc.c
 * Version : 1.0
 * Description : This module implements Insulin Delivery Service Client.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 24.05.2019 1.00 First Release
 ***********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <string.h>
#include "profile_cmn/r_ble_serv_common.h"
#include "r_ble_idc.h"
#include "discovery/r_ble_disc.h"

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
#ifndef UNUSED_ARG
#define UNUSED_ARG(arg)         (void)(arg)
#endif /* UNUSED_ARG */

/* Version number */
#define BLE_IDC_PRV_VERSION_MAJOR                                                                    (1)
#define BLE_IDC_PRV_VERSION_MINOR                                                                    (0)

/*status changed flags*/
#define BLE_IDC_PRV_IDD_STATUS_CHANGED_FLAGS_THERAPY_CONTROL_STATE_CHANGED                           (1 << 0)
#define BLE_IDC_PRV_IDD_STATUS_CHANGED_FLAGS_OPERATIONAL_STATE_CHANGED                               (1 << 1)
#define BLE_IDC_PRV_IDD_STATUS_CHANGED_FLAGS_RESERVOIR_STATUS_CHANGED                                (1 << 2)
#define BLE_IDC_PRV_IDD_STATUS_CHANGED_FLAGS_ANNUNCIATION_STATUS_CHANGED                             (1 << 3)
#define BLE_IDC_PRV_IDD_STATUS_CHANGED_FLAGS_TOTAL_DAILY_INSULIN_STATUS_CHANGED                      (1 << 4)
#define BLE_IDC_PRV_IDD_STATUS_CHANGED_FLAGS_ACTIVE_BASAL_RATE_STATUS_CHANGED                        (1 << 5)
#define BLE_IDC_PRV_IDD_STATUS_CHANGED_FLAGS_ACTIVE_BOLUS_STATUS_CHANGED                             (1 << 6)
#define BLE_IDC_PRV_IDD_STATUS_CHANGED_FLAGS_HISTORY_EVENT_RECORDED                                  (1 << 7)

/*Reservoir Attached bit.*/
#define BLE_IDC_PRV_IDD_STATUS_FLAGS_RESERVOIR_ATTACHED                                              (1 << 0)

/*annunciation status flags*/
#define BLE_IDC_PRV_IDD_ANNUNCIATION_STATUS_FLAGS_ANNUNCIATION_PRESENT                               (1 << 0)
#define BLE_IDC_PRV_IDD_ANNUNCIATION_STATUS_FLAGS_AUXINFO1_PRESENT                                   (1 << 1)
#define BLE_IDC_PRV_IDD_ANNUNCIATION_STATUS_FLAGS_AUXINFO2_PRESENT                                   (1 << 2)
#define BLE_IDC_PRV_IDD_ANNUNCIATION_STATUS_FLAGS_AUXINFO3_PRESENT                                   (1 << 3)
#define BLE_IDC_PRV_IDD_ANNUNCIATION_STATUS_FLAGS_AUXINFO4_PRESENT                                   (1 << 4)
#define BLE_IDC_PRV_IDD_ANNUNCIATION_STATUS_FLAGS_AUXINFO5_PRESENT                                   (1 << 5)

/*feature flags*/
#define BLE_IDC_PRV_IDD_FEATURES_FLAGS_E2E_PROTECTION_SUPPORTED                                      (1 << 0)
#define BLE_IDC_PRV_IDD_FEATURES_FLAGS_BASAL_RATE_SUPPORTED                                          (1 << 1)
#define BLE_IDC_PRV_IDD_FEATURES_FLAGS_TBR_ABSOLUTE_SUPPORTED                                        (1 << 2)
#define BLE_IDC_PRV_IDD_FEATURES_FLAGS_TBR_RELATIVE_SUPPORTED                                        (1 << 3)
#define BLE_IDC_PRV_IDD_FEATURES_FLAGS_TBR_TEMPLATE_SUPPORTED                                        (1 << 4)
#define BLE_IDC_PRV_IDD_FEATURES_FLAGS_FAST_BOLUS_SUPPORTED                                          (1 << 5)
#define BLE_IDC_PRV_IDD_FEATURES_FLAGS_EXTENDED_BOLUS_SUPPORTED                                      (1 << 6)
#define BLE_IDC_PRV_IDD_FEATURES_FLAGS_MULTIWAVE_BOLUS_SUPPORTED                                     (1 << 7)
#define BLE_IDC_PRV_IDD_FEATURES_FLAGS_BOLUS_DELAY_TIME_SUPPORTED                                    (1 << 8)
#define BLE_IDC_PRV_IDD_FEATURES_FLAGS_BOLUS_TEMPLATE_SUPPORTED                                      (1 << 9)
#define BLE_IDC_PRV_IDD_FEATURES_FLAGS_BOLUS_ACTIVATION_TYPE_SUPPORTED                               (1 << 10)
#define BLE_IDC_PRV_IDD_FEATURES_FLAGS_MULTIPLE_BOND_SUPPORTED                                       (1 << 11)
#define BLE_IDC_PRV_IDD_FEATURES_FLAGS_ISF_PROFILE_TEMPLATE_SUPPORTED                                (1 << 12)
#define BLE_IDC_PRV_IDD_FEATURES_FLAGS_I2CHO_RATIO_PROFILE_TEMPLATE_SUPPORTED                        (1 << 13)
#define BLE_IDC_PRV_IDD_FEATURES_FLAGS_TARGET_GLUCOSE_RANGE_PROFILE_TEMPLATE_SUPPORTED               (1 << 14)
#define BLE_IDC_PRV_IDD_FEATURES_FLAGS_INSULIN_ON_BOARD_SUPPORTED                                    (1 << 15)
#define BLE_IDC_PRV_IDD_FEATURES_FLAGS_FEATURE_EXTENSION                                             (1 << 23)

/*Bolus flags*/
#define BLE_IDC_PRV_IDD_BOLUS_DELAY_TIME_PRESENT                                                     (1 << 0)
#define BLE_IDC_PRV_IDD_BOLUS_TEMPLATE_NUMBER_PRESENT                                                (1 << 1)
#define BLE_IDC_PRV_IDD_BOLUS_ACTIVATION_TYPE_PRESENT                                                (1 << 2)
#define BLE_IDC_PRV_IDD_BOLUS_DELIVERY_REASON_CORRECTION                                             (1 << 3)
#define BLE_IDC_PRV_IDD_BOLUS_DELIVERY_REASON_MEAL                                                   (1 << 4)

/* Get Active Basal Rate Delivery Response flags */
#define BLE_IDC_PRV_IDD_SRCP_GET_ACTIVE_BASAL_RATE_DELIVERY_RESPONSE_TBR_PRESENT                     (1 << 0)
#define BLE_IDC_PRV_IDD_SRCP_GET_ACTIVE_BASAL_RATE_DELIVERY_RESPONSE_TBR_TEMPLATE_NUMBER_PRESENT     (1 << 1)
#define BLE_IDC_PRV_IDD_SRCP_GET_ACTIVE_BASAL_RATE_DELIVERY_RESPONSE_BASAL_DELIVERY_CONTEXT_PRESENT  (1 << 2)

/*Get insulin on board response flag*/
#define BLE_IDC_PRV_IDD_SRCP_GET_INSULIN_ON_BOARD_RESPONSE                                           (1 << 0)

/*Write Basal Rate Profile Template flag*/
#define BLE_IDC_PRV_IDD_CCP_BRPT_END_TRANSACTION                                                     (1 << 0)
#define BLE_IDC_PRV_IDD_CCP_BRPT_SECOND_TIME_BLOCK_PRESENT                                           (1 << 1)
#define BLE_IDC_PRV_IDD_CCP_BRPT_THIRD_TIME_BLOCK_PRESENT                                            (1 << 2)

/*Write Basal Rate Profile Template response flag*/
#define BLE_IDC_PRV_IDD_CCP_BRPTR_TRANSACTION_COMPLETED                                              (1 << 0)

/*Write Set TBR Adjustment flag*/
#define BLE_IDC_PRV_IDD_CCP_TBR_ADJUSTMENT_TBR_TEMPLATE_NUMBER_PRESENT                               (1 << 0)
#define BLE_IDC_PRV_IDD_CCP_TBR_ADJUSTMENT_TBR_DELIVERY_CONTEXT_PRESENT                              (1 << 1)
#define BLE_IDC_PRV_IDD_CCP_TBR_ADJUSTMENT_CHANGE_TBR                                                (1 << 2)

/*Set Bolus flag*/
#define BLE_IDC_PRV_IDD_BOLUS_DELAY_TIME_PRESENT                                                     (1 << 0)
#define BLE_IDC_PRV_IDD_BOLUS_TEMPLATE_NUMBER_PRESENT                                                (1 << 1)
#define BLE_IDC_PRV_IDD_BOLUS_ACTIVATION_TYPE_PRESENT                                                (1 << 2)
#define BLE_IDC_PRV_IDD_BOLUS_DELIVERY_REASON_CORRECTION                                             (1 << 3)
#define BLE_IDC_PRV_IDD_BOLUS_DELIVERY_REASON_MEAL                                                   (1 << 4)

/*Get available bolus flag*/
#define BLE_IDC_PRV_IDD_GET_AVAILABLE_BOLUSES_RES_FAST_BOLUS_AVAILABLE                               (1 << 0)
#define BLE_IDC_PRV_IDD_GET_AVAILABLE_BOLUSES_RES_EXTENDED_BOLUS_AVAILABLE                           (1 << 1)
#define BLE_IDC_PRV_IDD_GET_AVAILABLE_BOLUSES_RES_MULTIWAVE_BOLUS_AVAILABLE                          (1 << 2)

/*Get Bolus template res flag*/
#define BLE_IDC_PRV_IDD_GET_BOLUS_TEMPLATE_DELAY_TIME_PRESENT                                        (1 << 0)
#define BLE_IDC_PRV_IDD_GET_BOLUS_TEMPLATE_DELIVERY_REASON_CORRECTION                                (1 << 1)
#define BLE_IDC_PRV_IDD_GET_BOLUS_TEMPLATE_DELIVERY_REASON_MEAL                                      (1 << 2)

/*Write ISF Profile Template Operand Flags*/
#define BLE_IDC_PRV_IDD_CCP_ISFPT_END_TRANSACTION                                                    (1 << 0)
#define BLE_IDC_PRV_IDD_CCP_ISFPT_SECOND_TIME_BLOCK_PRESENT                                          (1 << 1)
#define BLE_IDC_PRV_IDD_CCP_ISFPT_THIRD_TIME_BLOCK_PRESENT                                           (1 << 2)

/*Write ISF Profile Template Response operand Flags*/
#define BLE_IDC_PRV_IDD_CCP_ISFPT_RES_TRANSACTION_COMP                                               (1 << 0)

/*Write I2CHO Ratio Profile Template Operand Flags*/
#define BLE_IDC_PRV_IDD_CCP_I2CHORPT_END_TRANSACTION                                                 (1 << 0)
#define BLE_IDC_PRV_IDD_CCP_I2CHORPT_SECOND_TIME_BLOCK_PRESENT                                       (1 << 1)
#define BLE_IDC_PRV_IDD_CCP_I2CHORPT_THIRD_TIME_BLOCK_PRESENT                                        (1 << 2)

/*Write I2CHO Ratio Profile Template Response operand Flags*/
#define BLE_IDC_PRV_IDD_CCP_I2CHORPT_RES_TRANSACTION_COMP                                            (1 << 0)

/*Write Target Glucose Range Profile Template Operand Flags*/
#define BLE_IDC_PRV_IDD_CCP_TGRPT_END_TRANSACTION                                                    (1 << 0)
#define BLE_IDC_PRV_IDD_CCP_TGRPT_SECOND_TIME_BLOCK_PRESENT                                          (1 << 1)

/*Write Target Glucose Range Profile Template Response operand Flags*/
#define BLE_IDC_PRV_IDD_CCP_TGRPT_RES_TRANSACTION_COMP                                               (1 << 0)

/*Read Profile Template Response Operand Flags*/
#define BLE_IDC_PRV_IDD_CD_SECOND_TIME_BLOCK_PRESENT                                                 (1 << 0)
#define BLE_IDC_PRV_IDD_CD_THIRD_TIME_BLOCK_PRESENT                                                  (1 << 1)

/*Bolus Delivered Part 2 of 2 event Flags */
#define BLE_IDC_PRV_IDD_HISTORY_DATA_BOLUS_DELIVERED_BOLUS_ACTIVATION_TYPE_PRESENT                   (1 << 0)
#define BLE_IDC_PRV_IDD_HISTORY_DATA_BOLUS_DELIVERED_BOLUS_END_REASON_PRESENT                        (1 << 1)
#define BLE_IDC_PRV_IDD_HISTORY_DATA_BOLUS_DELIVERED_ANNUNCIATION_INSTANCE_ID_PRESENT                (1 << 1)

/*Delivered Basal Rate Changed Event Flags*/
#define BLE_IDC_PRV_IDD_HISTORY_DATA_BASAL_DELIVERY_CONTEXT_PRESENT                                  (1 << 0)

/*TBR Adjustment Started Event Flags field*/
#define BLE_IDC_PRV_IDD_HISTORY_DATA_TBR_TEMPLATE_NUMBER_PRESENT                                     (1 << 0)

/*TBR Adjustment Ended Event Flags*/
#define BLE_IDC_PRV_IDD_HISTORY_DATA_LAST_SET_TBR_TEMPLATE_NUMBER_PRESENT                            (1 << 0)
#define BLE_IDC_PRV_IDD_HISTORY_DATA_ANNUNCIATION_INSTANCE_ID_PRESENT                                (1 << 1)

/*Total Daily Insulin Delivery Event Flags */
#define BLE_IDC_PRV_IDD_HISTORY_DATA_DATE_TIME_CHANGED_WARNING                                       (1 << 0)

/*IDD History Data Annunciation Status Changed Part 1 of 2 event Flags*/
#define BLE_IDC_PRV_IDD_HISTORY_DATA_AUXINFO1_PRESENT                                                (1 << 0)
#define BLE_IDC_PRV_IDD_HISTORY_DATA_AUXINFO2_PRESENT                                                (1 << 1)

/*IDD History Data Annunciation Status Changed Part 2 of 2 event*/
#define BLE_IDC_PRV_IDD_HISTORY_DATA_AUXINFO3_PRESENT                                                (1 << 0)
#define BLE_IDC_PRV_IDD_HISTORY_DATA_AUXINFO4_PRESENT                                                (1 << 1)
#define BLE_IDC_PRV_IDD_HISTORY_DATA_AUXINFO5_PRESENT                                                (1 << 2)

/*Priming Done Event Flags field*/
#define BLE_IDC_PRV_IDD_HISTORY_DATA_PRIMING_DONE_ANNUNCIATION_INSTANCE_ID_PRESENT                   (1 << 0)

/*e2e maximum counter*/
#define BLE_IDC_PRV_IDD_E2E_COUNTER_MAXIMUM_VALUE                                                    (255)


/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/
typedef struct
{
    uint16_t conn_hdl;
    st_ble_idc_hdls_t hdls;
} st_idc_peer_param_t;

/***********************************************************************************************************************
Exported global variables (to be accessed by other files)
***********************************************************************************************************************/
const uint8_t BLE_IDC_UUID[BLE_GATT_16_BIT_UUID_SIZE]                                                                     = { 0x3A, 0x18 };
const uint8_t BLE_IDC_IDD_STATUS_CHANGED_UUID[BLE_GATT_16_BIT_UUID_SIZE]                                                  = { 0x20, 0x2B };
const uint8_t BLE_IDC_IDD_STATUS_CHANGED_CLIENT_CHARACTERISTIC_CONFIGURATION_UUID[BLE_GATT_16_BIT_UUID_SIZE]              = { 0x02, 0x29 };
const uint8_t BLE_IDC_IDD_STATUS_UUID[BLE_GATT_16_BIT_UUID_SIZE]                                                          = { 0x21, 0x2B };
const uint8_t BLE_IDC_IDD_STATUS_CLIENT_CHARACTERISTIC_CONFIGURATION_UUID[BLE_GATT_16_BIT_UUID_SIZE]                      = { 0x02, 0x29 };
const uint8_t BLE_IDC_IDD_ANNUNCIATION_STATUS_UUID[BLE_GATT_16_BIT_UUID_SIZE]                                             = { 0x22, 0x2B };
const uint8_t BLE_IDC_IDD_ANNUNCIATION_STATUS_CLIENT_CHARACTERISTIC_CONFIGURATION_UUID[BLE_GATT_16_BIT_UUID_SIZE]         = { 0x02, 0x29 };
const uint8_t BLE_IDC_IDD_FEATURES_UUID[BLE_GATT_16_BIT_UUID_SIZE]                                                        = { 0x23, 0x2B };
const uint8_t BLE_IDC_IDD_STATUS_READER_CONTROL_POINT_UUID[BLE_GATT_16_BIT_UUID_SIZE]                                     = { 0x24, 0x2B };
const uint8_t BLE_IDC_IDD_STATUS_READER_CONTROL_POINT_CLIENT_CHARACTERISTIC_CONFIGURATION_UUID[BLE_GATT_16_BIT_UUID_SIZE] = { 0x02, 0x29 };
const uint8_t BLE_IDC_IDD_COMMAND_CONTROL_POINT_UUID[BLE_GATT_16_BIT_UUID_SIZE]                                           = { 0x25, 0x2B };
const uint8_t BLE_IDC_IDD_COMMAND_CONTROL_POINT_CLIENT_CHARACTERISTIC_CONFIGURATION_UUID[BLE_GATT_16_BIT_UUID_SIZE]       = { 0x02, 0x29 };
const uint8_t BLE_IDC_IDD_COMMAND_DATA_UUID[BLE_GATT_16_BIT_UUID_SIZE]                                                    = { 0x26, 0x2B };
const uint8_t BLE_IDC_IDD_COMMAND_DATA_CLIENT_CHARACTERISTIC_CONFIGURATION_UUID[BLE_GATT_16_BIT_UUID_SIZE]                = { 0x02, 0x29 };
const uint8_t BLE_IDC_IDD_RECORD_ACCESS_CONTROL_POINT_UUID[BLE_GATT_16_BIT_UUID_SIZE]                                     = { 0x27, 0x2B };
const uint8_t BLE_IDC_IDD_RECORD_ACCESS_CONTROL_POINT_CLIENT_CHARACTERISTIC_CONFIGURATION_UUID[BLE_GATT_16_BIT_UUID_SIZE] = { 0x02, 0x29 };
const uint8_t BLE_IDC_IDD_HISTORY_DATA_UUID[BLE_GATT_16_BIT_UUID_SIZE]                                                    = { 0x28, 0x2B };
const uint8_t BLE_IDC_IDD_HISTORY_DATA_CLIENT_CHARACTERISTIC_CONFIGURATION_UUID[BLE_GATT_16_BIT_UUID_SIZE]                = { 0x02, 0x29 };

bool e2e_protection_enable                                                                                                = false;
bool e2e_add_manual                                                                                                       = false;

typedef struct
{
    uint8_t  e2e_counter;
    uint8_t  trn_e2e_counter_val;
    uint8_t  rec_e2e_counter_val;
}idc_e2e_counter;

/***********************************************************************************************************************
Private global variables and functions
***********************************************************************************************************************/
static st_idc_peer_param_t gs_peer_params[7];
static ble_idc_app_cb_t gs_idc_cb;
/*static idc_e2e_counter                              gs_idd_status_changed_e2e_counter;*/
/*static idc_e2e_counter                              gs_idd_status_e2e_counter;*/
/*static idc_e2e_counter                              gs_idd_annunciation_status_e2e_counter;*/
/*static idc_e2e_counter                              gs_idd_features_e2e_counter;*/
static idc_e2e_counter                              gs_idd_srcp_e2e_counter;
static idc_e2e_counter                              gs_idd_command_control_point_e2e_counter;
/*static idc_e2e_counter                              gs_idd_command_data_e2e_counter;*/
static idc_e2e_counter                              gs_idd_record_access_e2e_counter;

/***********************************************************************************************************************
 * Function Name: find_peer_param
 * Description  : This function finds the attribute handles for the given connection handle.
 * Arguments    : conn_hdl - handle to connection
 * Return Value : pointer to the attribute handles structure
 **********************************************************************************************************************/
static st_idc_peer_param_t *find_peer_param(uint16_t conn_hdl)
{
    for (uint8_t i = 0; i < 7; i++)
    {
        if ((BLE_GAP_INVALID_CONN_HDL != gs_peer_params[i].conn_hdl) &&
            (gs_peer_params[i].conn_hdl == conn_hdl))
        {
            return &gs_peer_params[i];
        }
    }
    return NULL;
}

/***********************************************************************************************************************
 * Function Name: get_new_peer_param
 * Description  : This function finds the free attribute handle.
 * Arguments    : conn_hdl - handle to connection.
 * Return Value : pointer to the free attribute handles structure
 **********************************************************************************************************************/
static st_idc_peer_param_t *get_new_peer_param(uint16_t conn_hdl)
{
    for (uint8_t i = 0; i < 7; i++)
    {
        if (BLE_GAP_INVALID_CONN_HDL == gs_peer_params[i].conn_hdl)
        {
            gs_peer_params[i].conn_hdl = conn_hdl;
            return &gs_peer_params[i];
        }
    }
    return NULL;
}

/***********************************************************************************************************************
 * Function Name: clear_peer_param
 * Description  : This function frees all the attribute handles.
 * Arguments    : p_peer - pointer to the attribute handle structure to be freed
 * Return Value : none
***********************************************************************************************************************/
static void clear_peer_param(st_idc_peer_param_t *p_peer)
{
    if (NULL != p_peer)
    {
        p_peer->conn_hdl = BLE_GAP_INVALID_CONN_HDL;
        memset(&p_peer->hdls, 0x00, sizeof(p_peer->hdls));
    }
}

/***********************************************************************************************************************
 * Function Name: e2e_counter_value_check
 * Description  : Check the e2e counter value.
 * Arguments    : e2ecounter_val - e2e counter value.
 *                rec_e2e_val - current received e2e counter value
 *                last_rec_e2e_val - last received e2e counter value
 * Return Value : ble_status_t
 **********************************************************************************************************************/
#if 0 /* unused function */
static ble_status_t e2e_counter_value_check(uint8_t e2ecounter_val, uint8_t rec_e2e_val, uint8_t last_rec_e2e_val)
{
    ble_status_t ret;
    if (e2e_protection_enable)
    {
        if (1 == ((rec_e2e_val - e2ecounter_val) - (last_rec_e2e_val - e2ecounter_val)))
        {
            ret = BLE_SUCCESS;
        }
        else
        {
            ret = BLE_ERR_INVALID_DATA;
        }
    }
    else
    {
        ret = BLE_ERR_UNSUPPORTED;
    }
    return ret;
}
#endif /* unused function */

/***********************************************************************************************************************
 * Function Name: e2e_crc_calculation
 * Description  : to calculate e2e crc.
 * Arguments    : message - message data.
 *                length - message length
 * Return Value : uint16_t
 **********************************************************************************************************************/
static uint16_t e2e_crc_calculation(uint8_t* meassage, uint16_t length)
{
    uint16_t crc = 0xFFFF;
    while (length--)
    {
        crc = (uint16_t)(crc ^ *meassage++);
        for (int k = 0; k < 8; k++)
            crc = crc & 1 ? (crc >> 1) ^ 0x8408 : crc >> 1;
    }
    return crc;
}

/***********************************************************************************************************************
 * Function Name: decode_idd_status_changed
 * Description  : This function converts IDD Status Changed characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the IDD Status Changed value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_idd_status_changed(st_ble_idc_idd_status_changed_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    /* byte sequence to app data. */
    uint32_t pos = 0;
    memset((uint8_t*)p_app_value, 0x00, sizeof(*p_app_value));

    /*check p_gatt_value->value_len has sufficient length*/
    if (BLE_IDC_IDD_STATUS_CHANGED_LEN < p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    if (BLE_IDC_PRV_IDD_STATUS_CHANGED_FLAGS_THERAPY_CONTROL_STATE_CHANGED & p_gatt_value->p_value[pos])
    {
        p_app_value->is_therapy_control_state_changed = true;
    }
    else
    {
        p_app_value->is_therapy_control_state_changed = false;
    }

    if (BLE_IDC_PRV_IDD_STATUS_CHANGED_FLAGS_OPERATIONAL_STATE_CHANGED & p_gatt_value->p_value[pos])
    {
        p_app_value->is_optional_state_changed = true;
    }
    else
    {
        p_app_value->is_optional_state_changed = false;
    }

    if (BLE_IDC_PRV_IDD_STATUS_CHANGED_FLAGS_RESERVOIR_STATUS_CHANGED & p_gatt_value->p_value[pos])
    {
        p_app_value->is_reservoir_status_changed = true;
    }
    else
    {
        p_app_value->is_reservoir_status_changed = false;
    }
    if (BLE_IDC_PRV_IDD_STATUS_CHANGED_FLAGS_ANNUNCIATION_STATUS_CHANGED & p_gatt_value->p_value[pos])
    {
        p_app_value->is_annunciation_status_changed = true;
    }
    else
    {
        p_app_value->is_annunciation_status_changed = false;
    }

    if (BLE_IDC_PRV_IDD_STATUS_CHANGED_FLAGS_TOTAL_DAILY_INSULIN_STATUS_CHANGED & p_gatt_value->p_value[pos])
    {
        p_app_value->is_total_daily_insulin_status_changed = true;
    }
    else
    {
        p_app_value->is_total_daily_insulin_status_changed = false;
    }

    if (BLE_IDC_PRV_IDD_STATUS_CHANGED_FLAGS_ACTIVE_BASAL_RATE_STATUS_CHANGED & p_gatt_value->p_value[pos])
    {
        p_app_value->is_active_basal_rate_status_changed = true;
    }
    else
    {
        p_app_value->is_active_basal_rate_status_changed = false;
    }

    if (BLE_IDC_PRV_IDD_STATUS_CHANGED_FLAGS_ACTIVE_BOLUS_STATUS_CHANGED & p_gatt_value->p_value[pos])
    {
        p_app_value->is_active_bolus_status_changed = true;
    }
    else
    {
        p_app_value->is_active_bolus_status_changed = false;
    }

    if (BLE_IDC_PRV_IDD_STATUS_CHANGED_FLAGS_HISTORY_EVENT_RECORDED & p_gatt_value->p_value[pos])
    {
        p_app_value->is_history_event_recorded = true;
    }
    else
    {
        p_app_value->is_history_event_recorded = false;
    }

    pos += 2;

    BT_UNPACK_LE_1_BYTE(&p_app_value->e2e_counter, &p_gatt_value->p_value[pos]);
    pos += 1;
    BT_UNPACK_LE_2_BYTE(&p_app_value->e2e_crc, &p_gatt_value->p_value[pos]);
    pos += 2;

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: decode_idd_status
 * Description  : This function converts IDD Status characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the IDD Status value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_idd_status(st_ble_idc_idd_status_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    /* byte sequence to app data. */
    uint32_t pos = 0;
    /*check p_gatt_value->value_len has sufficient length*/
    if (BLE_IDC_IDD_STATUS_LEN < p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }
    memset((uint8_t*)p_app_value, 0x00, sizeof(*p_app_value));

    BT_UNPACK_LE_1_BYTE(&p_app_value->therapy_control_state, &p_gatt_value->p_value[pos]);
    pos += 1;
    BT_UNPACK_LE_1_BYTE(&p_app_value->operational_state, &p_gatt_value->p_value[pos]);
    pos += 1;
    BT_UNPACK_LE_2_BYTE(&p_app_value->reservoir_remaining_amount.mantissa, &p_gatt_value->p_value[pos]);
    p_app_value->reservoir_remaining_amount.exponent 
        = (int8_t)(((int16_t)p_app_value->reservoir_remaining_amount.mantissa) >> 12);
    p_app_value->reservoir_remaining_amount.mantissa 
        = (int16_t)(p_app_value->reservoir_remaining_amount.mantissa & 0x0FFF);
    pos += 2;
    p_app_value->flag = p_gatt_value->p_value[pos];

    if (BLE_IDC_PRV_IDD_STATUS_FLAGS_RESERVOIR_ATTACHED & p_gatt_value->p_value[pos])
    {
        p_app_value->is_reservoir_attached = true;
    }
    else
    {
        p_app_value->is_reservoir_attached = false;
    }

    pos += 1;
    BT_UNPACK_LE_1_BYTE(&p_app_value->e2e_counter, &p_gatt_value->p_value[pos]);
    pos += 1;
    BT_UNPACK_LE_2_BYTE(&p_app_value->e2e_crc, &p_gatt_value->p_value[pos]);
    pos += 2;

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: decode_idd_annunciation_status
 * Description  : This function converts IDD Annunciation Status characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the IDD Annunciation Status value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_idd_annunciation_status(st_ble_idc_idd_annunciation_status_t *p_app_value, 
    const st_ble_gatt_value_t *p_gatt_value)
{
    /* byte sequence to app data. */
    uint32_t pos = 0;

    /*check p_gatt_value->value_len has sufficient length*/
    if (BLE_IDC_IDD_ANNUNCIATION_STATUS_LEN < p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    memset((uint8_t*)p_app_value, 0x00, sizeof(*p_app_value));

    if (BLE_IDC_PRV_IDD_ANNUNCIATION_STATUS_FLAGS_ANNUNCIATION_PRESENT & p_gatt_value->p_value[pos])
    {
        p_app_value->is_annunciation_present = true;
    }
    else
    {
        p_app_value->is_annunciation_present = false;
    }

    if (BLE_IDC_PRV_IDD_ANNUNCIATION_STATUS_FLAGS_AUXINFO1_PRESENT & p_gatt_value->p_value[pos])
    {
        p_app_value->is_auxinfo1_present = true;
    }
    else
    {
        p_app_value->is_auxinfo1_present = false;
    }

    if (BLE_IDC_PRV_IDD_ANNUNCIATION_STATUS_FLAGS_AUXINFO2_PRESENT & p_gatt_value->p_value[pos])
    {
        p_app_value->is_auxinfo2_present = true;
    }
    else
    {
        p_app_value->is_auxinfo2_present = false;
    }

    if (BLE_IDC_PRV_IDD_ANNUNCIATION_STATUS_FLAGS_AUXINFO3_PRESENT & p_gatt_value->p_value[pos])
    {
        p_app_value->is_auxinfo3_present = true;
    }
    else
    {
        p_app_value->is_auxinfo3_present = false;
    }

    if (BLE_IDC_PRV_IDD_ANNUNCIATION_STATUS_FLAGS_AUXINFO4_PRESENT & p_gatt_value->p_value[pos])
    {
        p_app_value->is_auxinfo4_present = true;
    }
    else
    {
        p_app_value->is_auxinfo4_present = false;
    }

    if (BLE_IDC_PRV_IDD_ANNUNCIATION_STATUS_FLAGS_AUXINFO5_PRESENT & p_gatt_value->p_value[pos])
    {
        p_app_value->is_auxinfo5_present = true;
    }
    else
    {
        p_app_value->is_auxinfo5_present = false;
    }

    pos += 1;
    if (p_app_value->is_annunciation_present)
    {
        BT_UNPACK_LE_2_BYTE(&p_app_value->annunciation_instance_id, &p_gatt_value->p_value[pos]);
        pos += 2;
        BT_UNPACK_LE_2_BYTE(&p_app_value->annunciation_type, &p_gatt_value->p_value[pos]);
        pos += 2;
        BT_UNPACK_LE_1_BYTE(&p_app_value->annunciation_status, &p_gatt_value->p_value[pos]);
        pos += 1;
    }

    if (p_app_value->is_auxinfo1_present)
    {
        BT_UNPACK_LE_2_BYTE(&p_app_value->auxinfo1, &p_gatt_value->p_value[pos]);
        pos += 2;
    }

    if (p_app_value->is_auxinfo2_present)
    {
        BT_UNPACK_LE_2_BYTE(&p_app_value->auxinfo2, &p_gatt_value->p_value[pos]);
        pos += 2;
    }

    if (p_app_value->is_auxinfo3_present)
    {
        BT_UNPACK_LE_2_BYTE(&p_app_value->auxinfo3, &p_gatt_value->p_value[pos]);
        pos += 2;
    }

    if (p_app_value->is_auxinfo4_present)
    {
        BT_UNPACK_LE_2_BYTE(&p_app_value->auxinfo4, &p_gatt_value->p_value[pos]);
        pos += 2;
    }

    if (p_app_value->is_auxinfo5_present)
    {
        BT_UNPACK_LE_2_BYTE(&p_app_value->auxinfo5, &p_gatt_value->p_value[pos]);
        pos += 2;
    }

    BT_UNPACK_LE_1_BYTE(&p_app_value->e2e_counter, &p_gatt_value->p_value[pos]);
    pos += 1;
    BT_UNPACK_LE_2_BYTE(&p_app_value->e2e_crc, &p_gatt_value->p_value[pos]);
    pos += 2;

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: decode_idd_features
 * Description  : This function converts IDD Features characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the IDD Features value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_idd_features(st_ble_idc_idd_features_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    /* byte sequence to app data. */
    uint32_t pos = 0;

    /*check p_gatt_value->value_len has sufficient length*/
    if (BLE_IDC_IDD_FEATURES_LEN < p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    memset((uint8_t*)p_app_value, 0x00, sizeof(*p_app_value));

    BT_UNPACK_LE_2_BYTE(&p_app_value->e2e_crc, &p_gatt_value->p_value[pos]);
    pos += 2;
    BT_UNPACK_LE_1_BYTE(&p_app_value->e2e_counter, &p_gatt_value->p_value[pos]);
    pos += 1;
    BT_UNPACK_LE_2_BYTE(&p_app_value->insulin_concentration.mantissa, &p_gatt_value->p_value[pos]);
    p_app_value->insulin_concentration.exponent = (int8_t)(((int16_t)p_app_value->insulin_concentration.mantissa) >> 12);
    p_app_value->insulin_concentration.mantissa = (int16_t)(p_app_value->insulin_concentration.mantissa & 0x0FFF);
    pos += 2;

    if (BLE_IDC_PRV_IDD_FEATURES_FLAGS_E2E_PROTECTION_SUPPORTED & p_gatt_value->p_value[pos])
    {
        p_app_value->is_e2e_protection_supported = true;
    }
    else
    {
        p_app_value->is_e2e_protection_supported = false;
    }

    if (BLE_IDC_PRV_IDD_FEATURES_FLAGS_BASAL_RATE_SUPPORTED & p_gatt_value->p_value[pos])
    {
        p_app_value->is_basel_rate_supported = true;
    }
    else
    {
        p_app_value->is_basel_rate_supported = false;
    }

    if (BLE_IDC_PRV_IDD_FEATURES_FLAGS_TBR_ABSOLUTE_SUPPORTED & p_gatt_value->p_value[pos])
    {
        p_app_value->is_tbr_absolute_supported = true;
    }
    else
    {
        p_app_value->is_tbr_absolute_supported = false;
    }

    if (BLE_IDC_PRV_IDD_FEATURES_FLAGS_TBR_RELATIVE_SUPPORTED & p_gatt_value->p_value[pos])
    {
        p_app_value->is_tbr_relative_supported = true;
    }
    else
    {
        p_app_value->is_tbr_relative_supported = false;
    }

    if (BLE_IDC_PRV_IDD_FEATURES_FLAGS_TBR_TEMPLATE_SUPPORTED & p_gatt_value->p_value[pos])
    {
        p_app_value->is_tbr_template_supported = true;
    }
    else
    {
        p_app_value->is_tbr_template_supported = false;
    }

    if (BLE_IDC_PRV_IDD_FEATURES_FLAGS_FAST_BOLUS_SUPPORTED & p_gatt_value->p_value[pos])
    {
        p_app_value->is_fast_bolus_supported = true;
    }
    else
    {
        p_app_value->is_fast_bolus_supported = false;
    }

    if (BLE_IDC_PRV_IDD_FEATURES_FLAGS_EXTENDED_BOLUS_SUPPORTED & p_gatt_value->p_value[pos])
    {
        p_app_value->is_extented_bolus_supported = true;
    }
    else
    {
        p_app_value->is_extented_bolus_supported = false;
    }

    if (BLE_IDC_PRV_IDD_FEATURES_FLAGS_MULTIWAVE_BOLUS_SUPPORTED & p_gatt_value->p_value[pos])
    {
        p_app_value->is_multiwave_bolus_supported = true;
    }
    else
    {
        p_app_value->is_multiwave_bolus_supported = false;
    }
    pos += 1;

    if ((BLE_IDC_PRV_IDD_FEATURES_FLAGS_BOLUS_DELAY_TIME_SUPPORTED - 8) & p_gatt_value->p_value[pos])
    {
        p_app_value->is_bolus_delay_time_supported = true;
    }
    else
    {
        p_app_value->is_bolus_delay_time_supported = false;
    }

    if ((BLE_IDC_PRV_IDD_FEATURES_FLAGS_BOLUS_DELAY_TIME_SUPPORTED - 8) & p_gatt_value->p_value[pos])
    {
        p_app_value->is_bolus_delay_time_supported = true;
    }
    else
    {
        p_app_value->is_bolus_delay_time_supported = false;
    }

    if ((BLE_IDC_PRV_IDD_FEATURES_FLAGS_BOLUS_TEMPLATE_SUPPORTED - 8) & p_gatt_value->p_value[pos])
    {
        p_app_value->is_bolus_template_supported = true;
    }
    else
    {
        p_app_value->is_bolus_template_supported = false;
    }

    if ((BLE_IDC_PRV_IDD_FEATURES_FLAGS_BOLUS_ACTIVATION_TYPE_SUPPORTED - 8) & p_gatt_value->p_value[pos])
    {
        p_app_value->is_bolus_activation_type_supported = true;
    }
    else
    {
        p_app_value->is_bolus_activation_type_supported = false;
    }

    if ((BLE_IDC_PRV_IDD_FEATURES_FLAGS_MULTIPLE_BOND_SUPPORTED - 8) & p_gatt_value->p_value[pos])
    {
        p_app_value->is_multiple_bond_supported = true;
    }
    else
    {
        p_app_value->is_multiple_bond_supported = false;
    }

    if ((BLE_IDC_PRV_IDD_FEATURES_FLAGS_ISF_PROFILE_TEMPLATE_SUPPORTED - 8) & p_gatt_value->p_value[pos])
    {
        p_app_value->is_isf_profile_template_supported = true;
    }
    else
    {
        p_app_value->is_isf_profile_template_supported = false;
    }

    if ((BLE_IDC_PRV_IDD_FEATURES_FLAGS_I2CHO_RATIO_PROFILE_TEMPLATE_SUPPORTED - 8) & p_gatt_value->p_value[pos])
    {
        p_app_value->is_I2CHO_ratio_profile_template_supported = true;
    }
    else
    {
        p_app_value->is_I2CHO_ratio_profile_template_supported = false;
    }

    if ((BLE_IDC_PRV_IDD_FEATURES_FLAGS_TARGET_GLUCOSE_RANGE_PROFILE_TEMPLATE_SUPPORTED - 8) & p_gatt_value->p_value[pos])
    {
        p_app_value->is_target_glucose_range_profile_template_supported = true;
    }
    else
    {
        p_app_value->is_target_glucose_range_profile_template_supported = false;
    }

    if ((BLE_IDC_PRV_IDD_FEATURES_FLAGS_INSULIN_ON_BOARD_SUPPORTED - 8) & p_gatt_value->p_value[pos])
    {
        p_app_value->is_insulin_on_board_supported = true;
    }
    else
    {
        p_app_value->is_insulin_on_board_supported = false;
    }

    pos += 1;
    if ((BLE_IDC_PRV_IDD_FEATURES_FLAGS_FEATURE_EXTENSION - 16) & p_gatt_value->p_value[pos])
    {
        p_app_value->is_feature_extension_set = true;
    }
    else
    {
        p_app_value->is_feature_extension_set = false;
    }

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_idd_status_reader_control_point
 * Description  : This function converts IDD Status Reader Control Point characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the IDD Status Reader Control Point  value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_idd_status_reader_control_point(const st_ble_idc_idd_status_reader_control_point_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    /* App data to byte sequence. */
    uint32_t pos = 0;
    uint16_t e2e_crc = 0xFFFF;
    uint8_t e2e_counter = 0;

    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->op_code);
    pos += 2;
    switch (p_app_value->op_code)
    {
        case BLE_IDC_IDD_STATUS_READER_CONTROL_POINT_OP_CODE_RESPONSE_CODE:
        {
            BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->response_code.request_opcode);
            pos += 2;
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->response_code.response_code);
            pos += 1;
        }
        break;

        case BLE_IDC_IDD_STATUS_READER_CONTROL_POINT_OP_CODE_RESET_STATUS:
        {
            if (p_app_value->reset_status.is_therapy_control_state_changed)
            {
                p_gatt_value->p_value[pos] |= BLE_IDC_PRV_IDD_STATUS_CHANGED_FLAGS_THERAPY_CONTROL_STATE_CHANGED;
            }

            if (p_app_value->reset_status.is_optional_state_changed)
            {
                p_gatt_value->p_value[pos] |= BLE_IDC_PRV_IDD_STATUS_CHANGED_FLAGS_OPERATIONAL_STATE_CHANGED;
            }

            if (p_app_value->reset_status.is_reservoir_status_changed)
            {
                p_gatt_value->p_value[pos] |= BLE_IDC_PRV_IDD_STATUS_CHANGED_FLAGS_RESERVOIR_STATUS_CHANGED;
            }

            if (p_app_value->reset_status.is_annunciation_status_changed)
            {
                p_gatt_value->p_value[pos] |= BLE_IDC_PRV_IDD_STATUS_CHANGED_FLAGS_ANNUNCIATION_STATUS_CHANGED;
            }

            if (p_app_value->reset_status.is_total_daily_insulin_status_changed)
            {
                p_gatt_value->p_value[pos] |= BLE_IDC_PRV_IDD_STATUS_CHANGED_FLAGS_TOTAL_DAILY_INSULIN_STATUS_CHANGED;
            }

            if (p_app_value->reset_status.is_active_basal_rate_status_changed)
            {
                p_gatt_value->p_value[pos] |= BLE_IDC_PRV_IDD_STATUS_CHANGED_FLAGS_ACTIVE_BASAL_RATE_STATUS_CHANGED;
            }

            if (p_app_value->reset_status.is_active_bolus_status_changed)
            {
                p_gatt_value->p_value[pos] |= BLE_IDC_PRV_IDD_STATUS_CHANGED_FLAGS_ACTIVE_BOLUS_STATUS_CHANGED;
            }

            if (p_app_value->reset_status.is_history_event_recorded)
            {
                p_gatt_value->p_value[pos] |= BLE_IDC_PRV_IDD_STATUS_CHANGED_FLAGS_HISTORY_EVENT_RECORDED;
            }

            pos += 2;
        }
        break;
        case BLE_IDC_IDD_STATUS_READER_CONTROL_POINT_OP_CODE_GET_ACTIVE_BOLUS_IDC_RESPONSE:
        {
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->get_active_bolusids_response.no_of_active_boluses);
            pos += 1;
            if (0 < p_app_value->get_active_bolusids_response.no_of_active_boluses)
            {
                for (uint8_t i = 0; i < p_app_value->get_active_bolusids_response.no_of_active_boluses; i++)
                {
                    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->get_active_bolusids_response.bolus_id[i]);
                    pos += 2;
                }
            }
        }
        break;

        case BLE_IDC_IDD_STATUS_READER_CONTROL_POINT_OP_CODE_GET_ACTIVE_BOLUS_DELIVERY:
        {
            BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->get_active_bolus_delivery.bolus_id);
            pos += 2;
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->get_active_bolus_delivery.bolus_value_sel);
            pos += 1;
        }
        break;
        case BLE_IDC_IDD_STATUS_READER_CONTROL_POINT_OP_CODE_GET_ACTIVE_BOLUS_DELIVERY_RESPONSE:
        {
            if (p_app_value->get_active_bolus_delivery_response.is_bolus_delay_time_present)
            {
                p_gatt_value->p_value[pos] |= BLE_IDC_PRV_IDD_BOLUS_DELAY_TIME_PRESENT;
            }

            if (p_app_value->get_active_bolus_delivery_response.is_bolus_template_number_present)
            {
                p_gatt_value->p_value[pos] |= BLE_IDC_PRV_IDD_BOLUS_TEMPLATE_NUMBER_PRESENT;
            }

            if (p_app_value->get_active_bolus_delivery_response.is_bolus_activation_type_present)
            {
                p_gatt_value->p_value[pos] |= BLE_IDC_PRV_IDD_BOLUS_ACTIVATION_TYPE_PRESENT;
            }

            if (p_app_value->get_active_bolus_delivery_response.is_bolus_delivery_reason_correction)
            {
                p_gatt_value->p_value[pos] |= BLE_IDC_PRV_IDD_BOLUS_DELIVERY_REASON_CORRECTION;
            }

            if (p_app_value->get_active_bolus_delivery_response.is_bolus_delivery_reason_meal)
            {
                p_gatt_value->p_value[pos] |= BLE_IDC_PRV_IDD_BOLUS_DELIVERY_REASON_MEAL;
            }

            pos += 1;
            BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->get_active_bolus_delivery_response.bolus_id);
            pos += 2;
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->get_active_bolus_delivery_response.bolus_type);
            pos += 1;
            BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->get_active_bolus_delivery_response.bolus_fast_amount.mantissa);
            pos += 1;
            p_gatt_value->p_value[pos] = (uint8_t)(((p_app_value->get_active_bolus_delivery_response.bolus_fast_amount.exponent << 4) & 0xF0)
                | (uint8_t)((p_app_value->get_active_bolus_delivery_response.bolus_fast_amount.mantissa >> 8) & 0x000F));
            pos += 1;
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->get_active_bolus_delivery_response.bolus_extended_amount.mantissa);
            pos += 1;
            p_gatt_value->p_value[pos] = (uint8_t)(((p_app_value->get_active_bolus_delivery_response.bolus_extended_amount.exponent << 4) & 0xF0)
                | (uint8_t)((p_app_value->get_active_bolus_delivery_response.bolus_extended_amount.mantissa >> 8) & 0x000F));
            pos += 1;
            BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->get_active_bolus_delivery_response.bolus_duration);
            pos += 2;
            if (p_app_value->get_active_bolus_delivery_response.is_bolus_delay_time_present)
            {
                BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->get_active_bolus_delivery_response.bolus_delay_time);
                pos += 2;
            }

            if (p_app_value->get_active_bolus_delivery_response.is_bolus_template_number_present)
            {
                BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->get_active_bolus_delivery_response.bolus_template_no);
                pos += 1;
            }

            if (p_app_value->get_active_bolus_delivery_response.is_bolus_activation_type_present)
            {
                BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->get_active_bolus_delivery_response.bolus_activation_type);
                pos += 1;
            }

        }
        break;

        case BLE_IDC_IDD_STATUS_READER_CONTROL_POINT_OP_CODE_GET_ACTIVE_BASAL_RATE_DELIVERY_RESPONSE:
        {
            if (p_app_value->get_active_basel_rate_delivery_response.is_tbr_present)
            {
                p_gatt_value->p_value[pos] |= BLE_IDC_PRV_IDD_SRCP_GET_ACTIVE_BASAL_RATE_DELIVERY_RESPONSE_TBR_PRESENT;
            }

            if (p_app_value->get_active_basel_rate_delivery_response.is_tbr_template_number_present)
            {
                p_gatt_value->p_value[pos] |= BLE_IDC_PRV_IDD_SRCP_GET_ACTIVE_BASAL_RATE_DELIVERY_RESPONSE_TBR_TEMPLATE_NUMBER_PRESENT;
            }

            if (p_app_value->get_active_basel_rate_delivery_response.is_basal_delivery_context_present)
            {
                p_gatt_value->p_value[pos] |= BLE_IDC_PRV_IDD_SRCP_GET_ACTIVE_BASAL_RATE_DELIVERY_RESPONSE_BASAL_DELIVERY_CONTEXT_PRESENT;
            }

            pos += 1;
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->get_active_basel_rate_delivery_response.abr_profile_template_number);
            pos += 1;
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->get_active_basel_rate_delivery_response.abr_current_config_value.mantissa);
            pos += 1;
            p_gatt_value->p_value[pos] = (uint8_t)(((p_app_value->get_active_basel_rate_delivery_response.abr_current_config_value.exponent << 4) & 0xF0)
                | (uint8_t)((p_app_value->get_active_basel_rate_delivery_response.abr_current_config_value.mantissa >> 8) >> 0x000F));
            pos += 1;

            if (p_app_value->get_active_basel_rate_delivery_response.is_tbr_present)
            {
                BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->get_active_basel_rate_delivery_response.tbr_type);
                pos += 1;
                BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->get_active_basel_rate_delivery_response.tbr_adjustment_value.mantissa);
                pos += 1;
                p_gatt_value->p_value[pos] = (uint8_t)(((p_app_value->get_active_basel_rate_delivery_response.tbr_adjustment_value.exponent << 4) & 0xF0)
                    | (uint8_t)((p_app_value->get_active_basel_rate_delivery_response.tbr_adjustment_value.mantissa >> 8) >> 0x000F));
                pos += 1;
                BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->get_active_basel_rate_delivery_response.tbr_duration_programmed);
                pos += 2;
                BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->get_active_basel_rate_delivery_response.tbr_duration_remaining);
                pos += 2;
            }

            if (p_app_value->get_active_basel_rate_delivery_response.is_tbr_template_number_present)
            {
                BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->get_active_basel_rate_delivery_response.tbr_template_number);
                pos += 1;
            }

            if (p_app_value->get_active_basel_rate_delivery_response.is_basal_delivery_context_present)
            {
                BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->get_active_basel_rate_delivery_response.basel_delivery_context);
                pos += 1;
            }
        }
        break;

        case BLE_IDC_IDD_STATUS_READER_CONTROL_POINT_OP_CODE_GET_TOTAL_DAILY_INSULIN_STATUS_RESPONSE:
        {
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->get_total_daily_insulin_status.sum_of_bolus_delivered.mantissa);
            pos += 1;
            p_gatt_value->p_value[pos] = (uint8_t)(((p_app_value->get_total_daily_insulin_status.sum_of_bolus_delivered.exponent << 4) & 0xF0) 
                | (uint8_t)((p_app_value->get_total_daily_insulin_status.sum_of_bolus_delivered.mantissa >> 8) >> 0x000F));
            pos += 1;
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->get_total_daily_insulin_status.sum_of_basel_delivered.mantissa);
            pos += 1;
            p_gatt_value->p_value[pos] = (uint8_t)(((p_app_value->get_total_daily_insulin_status.sum_of_basel_delivered.exponent << 4) & 0xF0) 
                | (uint8_t)((p_app_value->get_total_daily_insulin_status.sum_of_basel_delivered.mantissa >> 8) >> 0x000F));
            pos += 1;
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->get_total_daily_insulin_status.sum_of_bolus_and_basal_delivered.mantissa);
            pos += 1;
            p_gatt_value->p_value[pos] = (uint8_t)(((p_app_value->get_total_daily_insulin_status.sum_of_bolus_and_basal_delivered.exponent << 4) & 0xF0) 
                | (uint8_t)((p_app_value->get_total_daily_insulin_status.sum_of_bolus_and_basal_delivered.mantissa >> 8) >> 0x000F));
            pos += 1;
        }
        break;

        case BLE_IDC_IDD_STATUS_READER_CONTROL_POINT_OP_CODE_GET_COUNTER:
        {
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->get_counter.counter_type);
            pos += 1;
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->get_counter.counter_value_selection);
            pos += 1;
        }
        break;

        case BLE_IDC_IDD_STATUS_READER_CONTROL_POINT_OP_CODE_GET_COUNTER_RESPONSE:
        {
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->get_counter_response.counter_type);
            pos += 1;
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->get_counter_response.counter_value_selection);
            pos += 1;
            BT_PACK_LE_4_BYTE(&p_gatt_value->p_value[pos], &p_app_value->get_counter_response.counter_value);
            pos += 4;
        }
        break;

        case BLE_IDC_IDD_STATUS_READER_CONTROL_POINT_OP_CODE_GET_DELIVERED_INSULIN_RESPONSE:
        {
            BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], &p_app_value->get_delivered_insulin_response.bolus_amount_delivered.mantissa);
            pos += 3;
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->get_delivered_insulin_response.bolus_amount_delivered.exponent);
            pos += 1;
            BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], &p_app_value->get_delivered_insulin_response.basel_amount_delivered.mantissa);
            pos += 3;
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->get_delivered_insulin_response.basel_amount_delivered.exponent);
            pos += 1;
        }
        break;

        case BLE_IDC_IDD_STATUS_READER_CONTROL_POINT_OP_CODE_GET_INSULIN_ON_BOARD_RESPONSE:
        {
            if (p_app_value->get_insulin_onbord_response.is_remaining_duration_present)
            {
                p_gatt_value->p_value[pos] |= BLE_IDC_PRV_IDD_SRCP_GET_INSULIN_ON_BOARD_RESPONSE;
            }

            pos += 1;
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->get_insulin_onbord_response.insulin_onboard.mantissa);
            pos += 1;
            p_gatt_value->p_value[pos] = (uint8_t)(((p_app_value->get_insulin_onbord_response.insulin_onboard.exponent << 4) & 0xF0) 
                | (uint8_t)((p_app_value->get_insulin_onbord_response.insulin_onboard.mantissa >> 8) & 0x000F));
            pos += 1;
            if (p_app_value->get_insulin_onbord_response.is_remaining_duration_present)
            {
                BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->get_insulin_onbord_response.remaining_duration);
                pos += 2;
            }

        }
        break;

        default:
        {
            /*Do nothing*/
        }
        break;

    }

    if (e2e_protection_enable)
    {
        if (BLE_IDC_PRV_IDD_E2E_COUNTER_MAXIMUM_VALUE == gs_idd_srcp_e2e_counter.e2e_counter)
        {
            gs_idd_srcp_e2e_counter.e2e_counter = 0;
        }

        e2e_counter = gs_idd_srcp_e2e_counter.e2e_counter++;
        BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &e2e_counter);
        pos += 1;
        e2e_crc = e2e_crc_calculation(p_gatt_value->p_value, (uint16_t)pos);
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &e2e_crc);
        pos += 2;

    }
    else if (e2e_add_manual)
    {
        BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->e2e_counter);
        pos += 1;
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->e2e_crc);
        pos += 2;
    }

    p_gatt_value->value_len = (uint16_t)pos;

    return BLE_SUCCESS;
 }
    /***********************************************************************************************************************
     * Function Name: decode_idd_status_reader_control_point
     * Description  : This function converts IDD Status Reader Control Point characteristic value representation in
     *                GATT (uint8_t[]) to representation in application layer (struct).
     * Arguments    : p_app_value - pointer to the IDD Status Reader Control Point value in the application layer
     *                p_gatt_value - pointer to the characteristic value in the GATT database
     * Return Value : ble_status_t
     **********************************************************************************************************************/
    static ble_status_t decode_idd_status_reader_control_point(st_ble_idc_idd_status_reader_control_point_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
    {
        /* byte sequence to app data. */
        uint32_t pos = 0;

        /*check p_gatt_value->value_len has sufficient length*/
        if ((BLE_IDC_IDD_STATUS_READER_CONTROL_POINT_LEN < p_gatt_value->value_len) || (0 == p_gatt_value->value_len))
        {
            return BLE_ERR_INVALID_DATA;
        }

        memset((uint8_t*)p_app_value, 0x00, sizeof(*p_app_value));

        BT_UNPACK_LE_2_BYTE(&p_app_value->op_code, &p_gatt_value->p_value[pos]);
        pos += 2;
        switch (p_app_value->op_code)
        {
            case BLE_IDC_IDD_STATUS_READER_CONTROL_POINT_OP_CODE_RESPONSE_CODE:
            {
                BT_UNPACK_LE_2_BYTE(&p_app_value->response_code.request_opcode, &p_gatt_value->p_value[pos]);
                pos += 2;
                BT_UNPACK_LE_1_BYTE(&p_app_value->response_code.response_code, &p_gatt_value->p_value[pos]);
                pos += 1;
            }
            break;

            case BLE_IDC_IDD_STATUS_READER_CONTROL_POINT_OP_CODE_RESET_STATUS:
            {
                if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_STATUS_CHANGED_FLAGS_THERAPY_CONTROL_STATE_CHANGED)
                {
                    p_app_value->reset_status.is_therapy_control_state_changed = true;
                }
                else
                {
                    p_app_value->reset_status.is_therapy_control_state_changed = false;
                }

                if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_STATUS_CHANGED_FLAGS_OPERATIONAL_STATE_CHANGED)
                {
                    p_app_value->reset_status.is_optional_state_changed = true;
                }
                else
                {
                    p_app_value->reset_status.is_optional_state_changed = false;
                }

                if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_STATUS_CHANGED_FLAGS_RESERVOIR_STATUS_CHANGED)
                {
                    p_app_value->reset_status.is_reservoir_status_changed = true;
                }
                else
                {
                    p_app_value->reset_status.is_reservoir_status_changed = false;
                }

                if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_STATUS_CHANGED_FLAGS_ANNUNCIATION_STATUS_CHANGED)
                {
                    p_app_value->reset_status.is_annunciation_status_changed = true;
                }
                else
                {
                    p_app_value->reset_status.is_annunciation_status_changed = false;
                }

                if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_STATUS_CHANGED_FLAGS_TOTAL_DAILY_INSULIN_STATUS_CHANGED)
                {
                    p_app_value->reset_status.is_total_daily_insulin_status_changed = true;
                }
                else
                {
                    p_app_value->reset_status.is_total_daily_insulin_status_changed = false;
                }

                if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_STATUS_CHANGED_FLAGS_ACTIVE_BASAL_RATE_STATUS_CHANGED)
                {
                    p_app_value->reset_status.is_active_basal_rate_status_changed = true;
                }
                else
                {
                    p_app_value->reset_status.is_active_basal_rate_status_changed = false;
                }

                if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_STATUS_CHANGED_FLAGS_ACTIVE_BOLUS_STATUS_CHANGED)
                {
                    p_app_value->reset_status.is_active_bolus_status_changed = true;
                }
                else
                {
                    p_app_value->reset_status.is_active_bolus_status_changed = false;
                }

                if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_STATUS_CHANGED_FLAGS_HISTORY_EVENT_RECORDED)
                {
                    p_app_value->reset_status.is_history_event_recorded = true;
                }
                else
                {
                    p_app_value->reset_status.is_history_event_recorded = false;
                }

                pos += 2;
            }
            break;

            case BLE_IDC_IDD_STATUS_READER_CONTROL_POINT_OP_CODE_GET_ACTIVE_BOLUS_IDC_RESPONSE:
            {
                BT_UNPACK_LE_1_BYTE(&p_app_value->get_active_bolusids_response.no_of_active_boluses, &p_gatt_value->p_value[pos]);
                pos += 1;
                if (0 < p_app_value->get_active_bolusids_response.no_of_active_boluses)
                {
                    for (uint8_t i = 0; i < p_app_value->get_active_bolusids_response.no_of_active_boluses; i++)
                    {
                        BT_UNPACK_LE_2_BYTE(&p_app_value->get_active_bolusids_response.bolus_id[i], &p_gatt_value->p_value[pos]);
                        pos += 2;
                    }
                }
            }
            break;

            case BLE_IDC_IDD_STATUS_READER_CONTROL_POINT_OP_CODE_GET_ACTIVE_BOLUS_DELIVERY:
            {
                BT_UNPACK_LE_2_BYTE(&p_app_value->get_active_bolus_delivery.bolus_id, &p_gatt_value->p_value[pos]);
                pos += 2;
                BT_UNPACK_LE_1_BYTE(&p_app_value->get_active_bolus_delivery.bolus_value_sel, &p_gatt_value->p_value[pos]);
                pos += 1;
            }
            break;

            case BLE_IDC_IDD_STATUS_READER_CONTROL_POINT_OP_CODE_GET_ACTIVE_BOLUS_DELIVERY_RESPONSE:
            {
                if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_BOLUS_DELAY_TIME_PRESENT)
                {
                    p_app_value->get_active_bolus_delivery_response.is_bolus_delay_time_present = true;
                }
                else
                {
                    p_app_value->get_active_bolus_delivery_response.is_bolus_delay_time_present = false;
                }

                if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_BOLUS_TEMPLATE_NUMBER_PRESENT)
                {
                    p_app_value->get_active_bolus_delivery_response.is_bolus_template_number_present = true;
                }
                else
                {
                    p_app_value->get_active_bolus_delivery_response.is_bolus_template_number_present = false;
                }
                if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_BOLUS_ACTIVATION_TYPE_PRESENT)
                {
                    p_app_value->get_active_bolus_delivery_response.is_bolus_activation_type_present = true;
                }
                else
                {
                    p_app_value->get_active_bolus_delivery_response.is_bolus_activation_type_present = false;
                }

                if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_BOLUS_DELIVERY_REASON_CORRECTION)
                {
                    p_app_value->get_active_bolus_delivery_response.is_bolus_delivery_reason_correction = true;
                }
                else
                {
                    p_app_value->get_active_bolus_delivery_response.is_bolus_delivery_reason_correction = false;
                }

                if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_BOLUS_DELIVERY_REASON_MEAL)
                {
                    p_app_value->get_active_bolus_delivery_response.is_bolus_delivery_reason_meal = true;
                }
                else
                {
                    p_app_value->get_active_bolus_delivery_response.is_bolus_delivery_reason_meal = false;
                }

                pos += 1;
                BT_UNPACK_LE_2_BYTE(&p_app_value->get_active_bolus_delivery_response.bolus_id, &p_gatt_value->p_value[pos]);
                pos += 2;
                BT_UNPACK_LE_1_BYTE(&p_app_value->get_active_bolus_delivery_response.bolus_type, &p_gatt_value->p_value[pos]);
                pos += 1;
                BT_UNPACK_LE_2_BYTE(&p_app_value->get_active_bolus_delivery_response.bolus_fast_amount.mantissa, &p_gatt_value->p_value[pos]);
                p_app_value->get_active_bolus_delivery_response.bolus_fast_amount.exponent = 
                    (int8_t)(((int16_t)p_app_value->get_active_bolus_delivery_response.bolus_fast_amount.mantissa) >> 12);
                p_app_value->get_active_bolus_delivery_response.bolus_fast_amount.mantissa = 
                    (int16_t)(p_app_value->get_active_bolus_delivery_response.bolus_fast_amount.mantissa & 0x0FFF);
                pos += 2;
                BT_UNPACK_LE_2_BYTE(&p_app_value->get_active_bolus_delivery_response.bolus_extended_amount.mantissa, &p_gatt_value->p_value[pos]);
                p_app_value->get_active_bolus_delivery_response.bolus_extended_amount.exponent = 
                    (int8_t)(((int16_t)p_app_value->get_active_bolus_delivery_response.bolus_extended_amount.mantissa) >> 12);
                p_app_value->get_active_bolus_delivery_response.bolus_extended_amount.mantissa = 
                    (int16_t)(p_app_value->get_active_bolus_delivery_response.bolus_extended_amount.mantissa & 0x0FFF);
                pos += 2;
                BT_UNPACK_LE_2_BYTE(&p_app_value->get_active_bolus_delivery_response.bolus_duration, &p_gatt_value->p_value[pos]);
                pos += 2;
                if (p_app_value->get_active_bolus_delivery_response.is_bolus_delay_time_present)
                {
                    BT_UNPACK_LE_2_BYTE(&p_app_value->get_active_bolus_delivery_response.bolus_delay_time, &p_gatt_value->p_value[pos]);
                    pos += 2;
                }

                if (p_app_value->get_active_bolus_delivery_response.is_bolus_template_number_present)
                {
                    BT_UNPACK_LE_1_BYTE(&p_app_value->get_active_bolus_delivery_response.bolus_template_no, &p_gatt_value->p_value[pos]);
                    pos += 1;
                }

                if (p_app_value->get_active_bolus_delivery_response.is_bolus_activation_type_present)
                {
                    BT_UNPACK_LE_1_BYTE(&p_app_value->get_active_bolus_delivery_response.bolus_activation_type, &p_gatt_value->p_value[pos]);
                    pos += 1;
                }
            }
            break;

            case BLE_IDC_IDD_STATUS_READER_CONTROL_POINT_OP_CODE_GET_ACTIVE_BASAL_RATE_DELIVERY_RESPONSE:
            {
                if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_SRCP_GET_ACTIVE_BASAL_RATE_DELIVERY_RESPONSE_TBR_PRESENT)
                {
                    p_app_value->get_active_basel_rate_delivery_response.is_tbr_present = true;
                }
                else
                {
                    p_app_value->get_active_basel_rate_delivery_response.is_tbr_present = false;
                }

                if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_SRCP_GET_ACTIVE_BASAL_RATE_DELIVERY_RESPONSE_TBR_TEMPLATE_NUMBER_PRESENT)
                {
                    p_app_value->get_active_basel_rate_delivery_response.is_tbr_template_number_present = true;
                }
                else
                {
                    p_app_value->get_active_basel_rate_delivery_response.is_tbr_template_number_present = false;
                }

                if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_SRCP_GET_ACTIVE_BASAL_RATE_DELIVERY_RESPONSE_BASAL_DELIVERY_CONTEXT_PRESENT)
                {
                    p_app_value->get_active_basel_rate_delivery_response.is_basal_delivery_context_present = true;
                }
                else
                {
                    p_app_value->get_active_basel_rate_delivery_response.is_basal_delivery_context_present = false;
                }

                pos += 1;
                BT_UNPACK_LE_1_BYTE(&p_app_value->get_active_basel_rate_delivery_response.abr_profile_template_number, &p_gatt_value->p_value[pos]);
                pos += 1;
                BT_UNPACK_LE_2_BYTE(&p_app_value->get_active_basel_rate_delivery_response.abr_current_config_value.mantissa, &p_gatt_value->p_value[pos]);
                p_app_value->get_active_basel_rate_delivery_response.abr_current_config_value.exponent
                    = (int8_t)(((int16_t)p_app_value->get_active_basel_rate_delivery_response.abr_current_config_value.mantissa) >> 12);
                p_app_value->get_active_basel_rate_delivery_response.abr_current_config_value.mantissa
                    = (int16_t)(p_app_value->get_active_basel_rate_delivery_response.abr_current_config_value.mantissa & 0x0FFF);
                pos += 2;
                if (p_app_value->get_active_basel_rate_delivery_response.is_tbr_present)
                {
                    BT_UNPACK_LE_1_BYTE(&p_app_value->get_active_basel_rate_delivery_response.tbr_type, &p_gatt_value->p_value[pos]);
                    pos += 1;
                    BT_UNPACK_LE_2_BYTE(&p_app_value->get_active_basel_rate_delivery_response.tbr_adjustment_value.mantissa, &p_gatt_value->p_value[pos]);
                    p_app_value->get_active_basel_rate_delivery_response.tbr_adjustment_value.exponent
                        = (int8_t)(((int16_t)p_app_value->get_active_basel_rate_delivery_response.tbr_adjustment_value.mantissa) >> 12);
                    p_app_value->get_active_basel_rate_delivery_response.tbr_adjustment_value.mantissa
                        = (int16_t)(p_app_value->get_active_basel_rate_delivery_response.tbr_adjustment_value.mantissa & 0x0FFF);
                    pos += 2;
                    BT_UNPACK_LE_2_BYTE(&p_app_value->get_active_basel_rate_delivery_response.tbr_duration_programmed, &p_gatt_value->p_value[pos]);
                    pos += 2;
                    BT_UNPACK_LE_2_BYTE(&p_app_value->get_active_basel_rate_delivery_response.tbr_duration_remaining, &p_gatt_value->p_value[pos]);
                    pos += 2;
                }

                if (p_app_value->get_active_basel_rate_delivery_response.is_tbr_template_number_present)
                {
                    BT_UNPACK_LE_1_BYTE(&p_app_value->get_active_basel_rate_delivery_response.tbr_template_number, &p_gatt_value->p_value[pos]);
                    pos += 1;
                }

                if (p_app_value->get_active_basel_rate_delivery_response.is_basal_delivery_context_present)
                {
                    BT_UNPACK_LE_1_BYTE(&p_app_value->get_active_basel_rate_delivery_response.basel_delivery_context, &p_gatt_value->p_value[pos]);
                    pos += 1;
                }
            }
            break;

            case BLE_IDC_IDD_STATUS_READER_CONTROL_POINT_OP_CODE_GET_TOTAL_DAILY_INSULIN_STATUS_RESPONSE:
            {
                BT_UNPACK_LE_2_BYTE(&p_app_value->get_total_daily_insulin_status.sum_of_bolus_delivered.mantissa, &p_gatt_value->p_value[pos]);
                p_app_value->get_total_daily_insulin_status.sum_of_bolus_delivered.exponent 
                    = (int8_t)(((int16_t)p_app_value->get_total_daily_insulin_status.sum_of_bolus_delivered.mantissa) >> 12);
                p_app_value->get_total_daily_insulin_status.sum_of_bolus_delivered.mantissa 
                    = (int16_t)(p_app_value->get_total_daily_insulin_status.sum_of_bolus_delivered.mantissa & 0x0FFF);
                pos += 2;
                BT_UNPACK_LE_2_BYTE(&p_app_value->get_total_daily_insulin_status.sum_of_basel_delivered.mantissa, &p_gatt_value->p_value[pos]);
                p_app_value->get_total_daily_insulin_status.sum_of_basel_delivered.exponent 
                    = (int8_t)(((int16_t)p_app_value->get_total_daily_insulin_status.sum_of_basel_delivered.mantissa) >> 12);
                p_app_value->get_total_daily_insulin_status.sum_of_basel_delivered.mantissa 
                    = (int16_t)(p_app_value->get_total_daily_insulin_status.sum_of_basel_delivered.mantissa & 0x0FFF);
                pos += 2;
                BT_UNPACK_LE_2_BYTE(&p_app_value->get_total_daily_insulin_status.sum_of_bolus_and_basal_delivered.mantissa, &p_gatt_value->p_value[pos]);
                p_app_value->get_total_daily_insulin_status.sum_of_bolus_and_basal_delivered.exponent 
                    = (int8_t)(((int16_t)p_app_value->get_total_daily_insulin_status.sum_of_bolus_and_basal_delivered.mantissa) >> 12);
                p_app_value->get_total_daily_insulin_status.sum_of_bolus_and_basal_delivered.mantissa 
                    = (int16_t)(p_app_value->get_total_daily_insulin_status.sum_of_bolus_and_basal_delivered.mantissa & 0x0FFF);
                pos += 2;
            }
            break;

            case BLE_IDC_IDD_STATUS_READER_CONTROL_POINT_OP_CODE_GET_COUNTER:
            {
                BT_UNPACK_LE_1_BYTE(&p_app_value->get_counter.counter_type, &p_gatt_value->p_value[pos]);
                pos += 1;
                BT_UNPACK_LE_1_BYTE(&p_app_value->get_counter.counter_value_selection, &p_gatt_value->p_value[pos]);
                pos += 1;
            }
            break;

            case BLE_IDC_IDD_STATUS_READER_CONTROL_POINT_OP_CODE_GET_COUNTER_RESPONSE:
            {
                BT_UNPACK_LE_1_BYTE(&p_app_value->get_counter_response.counter_type, &p_gatt_value->p_value[pos]);
                pos += 1;
                BT_UNPACK_LE_1_BYTE(&p_app_value->get_counter_response.counter_value_selection, &p_gatt_value->p_value[pos]);
                pos += 1;
                BT_UNPACK_LE_4_BYTE(&p_app_value->get_counter_response.counter_value, &p_gatt_value->p_value[pos]);
                pos += 4;
            }
            break;

            case BLE_IDC_IDD_STATUS_READER_CONTROL_POINT_OP_CODE_GET_DELIVERED_INSULIN_RESPONSE:
            {
                BT_UNPACK_LE_3_BYTE(&p_app_value->get_delivered_insulin_response.bolus_amount_delivered.mantissa, &p_gatt_value->p_value[pos]);
                pos += 3;
                BT_UNPACK_LE_1_BYTE(&p_app_value->get_delivered_insulin_response.bolus_amount_delivered.exponent, &p_gatt_value->p_value[pos]);
                pos += 1;
                BT_UNPACK_LE_3_BYTE(&p_app_value->get_delivered_insulin_response.basel_amount_delivered.mantissa, &p_gatt_value->p_value[pos]);
                pos += 3;
                BT_UNPACK_LE_1_BYTE(&p_app_value->get_delivered_insulin_response.basel_amount_delivered.exponent, &p_gatt_value->p_value[pos]);
                pos += 1;
            }
            break;

            case BLE_IDC_IDD_STATUS_READER_CONTROL_POINT_OP_CODE_GET_INSULIN_ON_BOARD_RESPONSE:
            {
                if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_SRCP_GET_INSULIN_ON_BOARD_RESPONSE)
                {
                    p_app_value->get_insulin_onbord_response.is_remaining_duration_present = true;
                }

                pos += 1;
                BT_UNPACK_LE_2_BYTE(&p_app_value->get_insulin_onbord_response.insulin_onboard.mantissa, &p_gatt_value->p_value[pos]);
                p_app_value->get_insulin_onbord_response.insulin_onboard.exponent 
                    = (int8_t)(((int16_t)p_app_value->get_insulin_onbord_response.insulin_onboard.mantissa) >> 12);
                p_app_value->get_insulin_onbord_response.insulin_onboard.mantissa 
                    = (int16_t)(p_app_value->get_insulin_onbord_response.insulin_onboard.mantissa & 0x0FFF);
                pos += 2;
                if (p_app_value->get_insulin_onbord_response.is_remaining_duration_present)
                {
                    BT_UNPACK_LE_2_BYTE(&p_app_value->get_insulin_onbord_response.remaining_duration, &p_gatt_value->p_value[pos]);
                    pos += 2;
                }
            }
            break;

            default:
            {
                /*Do nothing*/
            }
            break;
    }
    BT_UNPACK_LE_1_BYTE(&p_app_value->e2e_counter,&p_gatt_value->p_value[pos]);
    pos += 1;
    BT_UNPACK_LE_2_BYTE(&p_app_value->e2e_crc,&p_gatt_value->p_value[pos]);
    pos += 2;

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_idd_command_control_point
 * Description  : This function converts IDD Command Control Point characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the IDD Command Control Point  value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_idd_command_control_point(const st_ble_idc_idd_command_control_point_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    /* app data to byte sequence. */
    uint32_t pos = 0;
    uint16_t e2e_crc = 0xFFFF;
    /*uint8_t e2e_counter = 0;*/

    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->op_code);
    pos += 2;
    switch (p_app_value->op_code)
    {
        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_RESPONSE_CODE:
        {
            BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->ccp_resp_code.request_op_code);
            pos += 2;
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->ccp_resp_code.response_code_value);
            pos += 1;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_SET_THERAPY_CONTROL_STATE:
        {
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->set_therapy_control_state);
            pos += 1;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_SNOOZE_ANNUNCIATION:
        {
            BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->snooze_annunciation_instance_id);
            pos += 2;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_SNOOZE_ANNUNCIATION_RESPONSE:
        {
            BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->snooze_annunciation_instance_id_response);
            pos += 2;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_CONFIRM_ANNUNCIATION:
        {
            BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->confirm_annunciation_instance_id);
            pos += 2;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_CONFIRM_ANNUNCIATION_RESPONSE:
        {
            BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->confirm_annunciation_instance_id_response);
            pos += 2;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_READ_BASAL_RATE_PROFILE_TEMPLATE:
        {
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->basel_rate_profile_template_number);
            pos += 1;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_WRITE_BASAL_RATE_PROFILE_TEMPLATE:
        {
            if (p_app_value->write_basal_rate_profile_template.is_end_transaction)
            {
                p_gatt_value->p_value[pos] |= BLE_IDC_PRV_IDD_CCP_BRPT_END_TRANSACTION;
            }

            if (p_app_value->write_basal_rate_profile_template.is_second_time_block_present)
            {
                p_gatt_value->p_value[pos] |= BLE_IDC_PRV_IDD_CCP_BRPT_SECOND_TIME_BLOCK_PRESENT;
            }

            if (p_app_value->write_basal_rate_profile_template.is_third_time_block_present)
            {
                p_gatt_value->p_value[pos] |= BLE_IDC_PRV_IDD_CCP_BRPT_THIRD_TIME_BLOCK_PRESENT;
            }

            pos += 1;
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->write_basal_rate_profile_template.basal_rate_profile_template_num);
            pos += 1;
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->write_basal_rate_profile_template.first_time_block_number_index);
            pos += 1;
            BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->write_basal_rate_profile_template.first_duration);
            pos += 2;
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->write_basal_rate_profile_template.first_rate.mantissa);
            pos += 1;
            p_gatt_value->p_value[pos] = (uint8_t)(((p_app_value->write_basal_rate_profile_template.first_rate.exponent << 4) & 0xF0) 
                | (uint8_t)((p_app_value->write_basal_rate_profile_template.first_rate.mantissa >> 8) & 0x000F));
            pos += 1;
            if (p_app_value->write_basal_rate_profile_template.is_second_time_block_present)
            {
                BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->write_basal_rate_profile_template.second_duration);
                pos += 2;
                BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->write_basal_rate_profile_template.second_rate.mantissa);
                pos += 1;
                p_gatt_value->p_value[pos] = (uint8_t)(((p_app_value->write_basal_rate_profile_template.second_rate.exponent << 4) & 0xF0)
                    | (uint8_t)((p_app_value->write_basal_rate_profile_template.second_rate.mantissa >> 8) & 0x000F));
                pos += 1;
            }

            if (p_app_value->write_basal_rate_profile_template.is_third_time_block_present)
            {
                BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->write_basal_rate_profile_template.third_duration);
                pos += 2;
                BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->write_basal_rate_profile_template.third_rate.mantissa);
                pos += 1;
                p_gatt_value->p_value[pos] = (uint8_t)(((p_app_value->write_basal_rate_profile_template.third_rate.exponent << 4) & 0xF0)
                    | (uint8_t)((p_app_value->write_basal_rate_profile_template.third_rate.mantissa >> 8) & 0x000F));
                pos += 1;
            }
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_WRITE_BASAL_RATE_PROFILE_TEMPLATE_RESPONSE:
        {
            if (p_app_value->write_basal_rate_profile_template_response.is_trans_comp)
            {
                p_gatt_value->p_value[pos] |= BLE_IDC_PRV_IDD_CCP_BRPTR_TRANSACTION_COMPLETED;
            }

            pos += 1;
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->write_basal_rate_profile_template_response.basal_rate_profile_template_number);
            pos += 1;
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->write_basal_rate_profile_template_response.first_time_block_number_index);
            pos += 1;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_SET_TBR_ADJUSTMENT:
        {
            if (p_app_value->set_tbr_adjustment.is_tbr_template_number_present)
            {
                p_gatt_value->p_value[pos] |= BLE_IDC_PRV_IDD_CCP_TBR_ADJUSTMENT_TBR_TEMPLATE_NUMBER_PRESENT;
            }

            if (p_app_value->set_tbr_adjustment.is_tbr_delivery_context_present)
            {
                p_gatt_value->p_value[pos] |= BLE_IDC_PRV_IDD_CCP_TBR_ADJUSTMENT_TBR_DELIVERY_CONTEXT_PRESENT;
            }

            if (p_app_value->set_tbr_adjustment.is_change_tbr)
            {
                p_gatt_value->p_value[pos] |= BLE_IDC_PRV_IDD_CCP_TBR_ADJUSTMENT_CHANGE_TBR;
            }

            pos += 1;
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->set_tbr_adjustment.tbr_type);
            pos += 1;
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->set_tbr_adjustment.tbr_adj_val.mantissa);
            pos += 1;
            p_gatt_value->p_value[pos] = (uint8_t)(((p_app_value->set_tbr_adjustment.tbr_adj_val.exponent << 4) & 0xF0) 
                | (uint8_t)((p_app_value->set_tbr_adjustment.tbr_adj_val.mantissa >> 8) & 0x000F));
            pos += 1;
            BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->set_tbr_adjustment.tbr_duration);
            pos += 2;
            if (p_app_value->set_tbr_adjustment.is_tbr_template_number_present)
            {
                BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->set_tbr_adjustment.tbr_template_num);
                pos += 1;
            }

            if (p_app_value->set_tbr_adjustment.is_tbr_delivery_context_present)
            {
                BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->set_tbr_adjustment.tbr_delivery_context);
                pos += 1;
            }
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_GET_TBR_TEMPLATE:
        {
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->get_tbr_template_number);
            pos += 1;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_GET_TBR_TEMPLATE_RESPONSE:
        {
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->get_tbr_template_response.tbr_template_number);
            pos += 1;
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->get_tbr_template_response.tbr_type);
            pos += 1;
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->get_tbr_template_response.tbr_adjustment_value.mantissa);
            pos += 1;
            p_gatt_value->p_value[pos] = (uint8_t)(((p_app_value->get_tbr_template_response.tbr_adjustment_value.exponent << 4) & 0xF0) 
                | (uint8_t)((p_app_value->get_tbr_template_response.tbr_adjustment_value.mantissa >> 8) & 0x000F));
            pos += 1;
            BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->get_tbr_template_response.tbr_duration);
            pos += 2;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_SET_TBR_TEMPLATE:
        {
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->set_tbr_template.tbr_template_number);
            pos += 1;
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->set_tbr_template.tbr_type);
            pos += 1;
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->set_tbr_template.tbr_adjustment_value.mantissa);
            pos += 1;
            p_gatt_value->p_value[pos] = (uint8_t)(((p_app_value->set_tbr_template.tbr_adjustment_value.exponent << 4) & 0xF0) 
                | (uint8_t)((p_app_value->set_tbr_template.tbr_adjustment_value.mantissa >> 8) >> 0x000F));
            pos += 1;
            BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->set_tbr_template.tbr_duration);
            pos += 2;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_SET_TBR_TEMPLATE_RESPONSE:
        {
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->set_tbr_template_number_response);
            pos += 1;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_SET_BOLUS:
        {
            if (p_app_value->set_bolus.is_bolus_delay_time_present)
            {
                p_gatt_value->p_value[pos] |= BLE_IDC_PRV_IDD_BOLUS_DELAY_TIME_PRESENT;
            }

            if (p_app_value->set_bolus.is_bolus_template_number_present)
            {
                p_gatt_value->p_value[pos] |= BLE_IDC_PRV_IDD_BOLUS_TEMPLATE_NUMBER_PRESENT;
            }

            if (p_app_value->set_bolus.is_bolus_activation_type_present)
            {
                p_gatt_value->p_value[pos] |= BLE_IDC_PRV_IDD_BOLUS_ACTIVATION_TYPE_PRESENT;
            }

            if (p_app_value->set_bolus.is_bolus_delivery_reason_correction)
            {
                p_gatt_value->p_value[pos] |= BLE_IDC_PRV_IDD_BOLUS_DELIVERY_REASON_CORRECTION;
            }

            if (p_app_value->set_bolus.is_bolus_delivery_reason_meal)
            {
                p_gatt_value->p_value[pos] |= BLE_IDC_PRV_IDD_BOLUS_DELIVERY_REASON_MEAL;
            }

            pos += 1;
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->set_bolus.bolus_type);
            pos += 1;
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->set_bolus.bolus_fast_amount.mantissa);
            pos += 1;
            p_gatt_value->p_value[pos] = (uint8_t)(((p_app_value->set_bolus.bolus_fast_amount.exponent << 4) & 0xF0) | 
                (uint8_t)((p_app_value->set_bolus.bolus_fast_amount.mantissa >> 8) >> 0x000F));
            pos += 1;
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->set_bolus.bolus_extended_amount.mantissa);
            pos += 1;
            p_gatt_value->p_value[pos] = (uint8_t)(((p_app_value->set_bolus.bolus_extended_amount.exponent << 4) & 0xF0) | 
                (uint8_t)((p_app_value->set_bolus.bolus_extended_amount.mantissa >> 8) >> 0x000F));
            pos += 1;
            BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->set_bolus.bolus_duration);
            pos += 2;
            BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->set_bolus.bolus_delay_time);
            pos += 2;
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->set_bolus.bolus_template_number);
            pos += 1;
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->set_bolus.bolus_activation_type);
            pos += 1;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_SET_BOLUS_RESPONSE:
        {
            BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->bolus_response);
            pos += 2;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_CANCEL_BOLUS:
        {
            BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->cancel_bolus_id);
            pos += 2;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_CANCEL_BOLUS_RESPONSE:
        {
            BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->cancel_bolus_id_response);
            pos += 2;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_GET_AVAILABLE_BOLUSES_RESPONSE:
        {
            if (p_app_value->get_available_boluses_response.is_fast_bolus_available)
            {
                p_gatt_value->p_value[pos] |= BLE_IDC_PRV_IDD_GET_AVAILABLE_BOLUSES_RES_FAST_BOLUS_AVAILABLE;
            }

            if (p_app_value->get_available_boluses_response.is_extended_bolus_available)
            {
                p_gatt_value->p_value[pos] |= BLE_IDC_PRV_IDD_GET_AVAILABLE_BOLUSES_RES_EXTENDED_BOLUS_AVAILABLE;
            }

            if (p_app_value->get_available_boluses_response.is_multiwave_bolus_available)
            {
                p_gatt_value->p_value[pos] |= BLE_IDC_PRV_IDD_GET_AVAILABLE_BOLUSES_RES_MULTIWAVE_BOLUS_AVAILABLE;
            }

            pos += 1;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_GET_BOLUS_TEMPLATE:
        {
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->bouls_template_number);
            pos += 1;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_GET_BOLUS_TEMPLATE_RESPONSE:
        {
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->get_bolus_template_response.bolus_template_num);
            pos += 1;
            if (p_app_value->get_bolus_template_response.is_bolus_delay_time_present)
            {
                p_gatt_value->p_value[pos] |= BLE_IDC_PRV_IDD_GET_BOLUS_TEMPLATE_DELAY_TIME_PRESENT;
            }

            if (p_app_value->get_bolus_template_response.is_bolus_delivery_reason_correction)
            {
                p_gatt_value->p_value[pos] |= BLE_IDC_PRV_IDD_GET_BOLUS_TEMPLATE_DELIVERY_REASON_CORRECTION;
            }

            if (p_app_value->get_bolus_template_response.is_bolus_delivery_reason_meal)
            {
                p_gatt_value->p_value[pos] |= BLE_IDC_PRV_IDD_GET_BOLUS_TEMPLATE_DELIVERY_REASON_MEAL;
            }

            pos += 1;
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->get_bolus_template_response.bolus_type);
            pos += 1;
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->get_bolus_template_response.bolus_fast_amount.mantissa);
            pos += 1;
            p_gatt_value->p_value[pos] = (uint8_t)(((p_app_value->get_bolus_template_response.bolus_fast_amount.exponent << 4) & 0xF0) 
                | (uint8_t)((p_app_value->get_bolus_template_response.bolus_fast_amount.mantissa >> 8) >> 0x000F));
            pos += 1;
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->get_bolus_template_response.bolus_extended_amount.mantissa);
            pos += 1;
            p_gatt_value->p_value[pos] = (uint8_t)(((p_app_value->get_bolus_template_response.bolus_extended_amount.exponent << 4) & 0xF0) 
                | (uint8_t)((p_app_value->get_bolus_template_response.bolus_extended_amount.mantissa >> 8) >> 0x000F));
            pos += 1;
            BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->get_bolus_template_response.bolus_duration);
            pos += 2;
            if (p_app_value->get_bolus_template_response.is_bolus_delay_time_present)
            {
                BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->get_bolus_template_response.bolus_delay_time);
                pos += 2;
            }
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_SET_BOLUS_TEMPLATE:
        {
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->set_bolus_template.bolus_template_num);
            pos += 1;
            if (p_app_value->set_bolus_template.is_bolus_delay_time_present)
            {
                p_gatt_value->p_value[pos] |= BLE_IDC_PRV_IDD_GET_BOLUS_TEMPLATE_DELAY_TIME_PRESENT;
            }

            if (p_app_value->set_bolus_template.is_bolus_delivery_reason_correction)
            {
                p_gatt_value->p_value[pos] |= BLE_IDC_PRV_IDD_GET_BOLUS_TEMPLATE_DELIVERY_REASON_CORRECTION;
            }

            if (p_app_value->set_bolus_template.is_bolus_delivery_reason_meal)
            {
                p_gatt_value->p_value[pos] |= BLE_IDC_PRV_IDD_GET_BOLUS_TEMPLATE_DELIVERY_REASON_MEAL;
            }

            pos += 1;
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->set_bolus_template.bolus_type);
            pos += 1;
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->set_bolus_template.bolus_fast_amount.mantissa);
            pos += 1;
            p_gatt_value->p_value[pos] = (uint8_t)(((p_app_value->set_bolus_template.bolus_fast_amount.exponent << 4) & 0xF0) 
                | (uint8_t)((p_app_value->set_bolus_template.bolus_fast_amount.mantissa >> 8) >> 0x000F));
            pos += 1;
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->set_bolus_template.bolus_extended_amount.mantissa);
            pos += 1;
            p_gatt_value->p_value[pos] = (uint8_t)(((p_app_value->set_bolus_template.bolus_extended_amount.exponent << 4) & 0xF0)
                | (uint8_t)((p_app_value->set_bolus_template.bolus_extended_amount.mantissa >> 8) >> 0x000F));
            pos += 1;
            BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->set_bolus_template.bolus_duration);
            pos += 2;
            if (p_app_value->set_bolus_template.is_bolus_delay_time_present)
            {
                BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->set_bolus_template.bolus_delay_time);
                pos += 2;
            }
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_SET_BOLUS_TEMPLATE_RESPONSE:
        {
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->set_bolus_template_res);
            pos += 1;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_RESET_TEMPLATE_STATUS:
        {
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->reset_template_status.number_of_templates_to_reset);
            pos += 1;
            for (int i = 0; i < p_app_value->reset_template_status.number_of_templates_to_reset; i++)
            {
                BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->reset_template_status.template_number[i]);
                pos += 1;
            }
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_RESET_TEMPLATE_STATUS_RESPONSE:
        {
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->status_response.number_of_templates_to_reset);
            pos += 1;
            for (int i = 0; i < p_app_value->status_response.number_of_templates_to_reset; i++)
            {
                BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->status_response.template_number[i]);
                pos += 1;
            }
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_ACTIVATE_PROFILE_TEMPLATES:
        {
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->active_prof_template.number_of_templates_to_activate);
            pos += 1;
            for (int i = 0; i < p_app_value->active_prof_template.number_of_templates_to_activate; i++)
            {
                BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->active_prof_template.profile_template_numbers[i]);
                pos += 1;
            }
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_ACTIVATE_PROFILE_TEMPLATES_RESPONSE:
        {
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->active_prof_template_response.number_of_templates_to_activate);
            pos += 1;
            for (int i = 0; i < p_app_value->active_prof_template_response.number_of_templates_to_activate; i++)
            {
                BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->active_prof_template_response.profile_template_numbers[i]);
                pos += 1;
            }
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_GET_ACTIVATED_PROFILE_TEMPLATES_RESPONSE:
        {
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->get_active_prof_template_response.number_of_templates_to_activate);
            pos += 1;
            for (int i = 0; i < p_app_value->get_active_prof_template_response.number_of_templates_to_activate; i++)
            {
                BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->get_active_prof_template_response.profile_template_numbers[i]);
                pos += 1;
            }
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_START_PRIMING:
        {
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->statr_priming_amount.mantissa);
            pos += 1;
            p_gatt_value->p_value[pos] = (uint8_t)(((p_app_value->statr_priming_amount.exponent << 4) & 0xF0) 
                | (uint8_t)((p_app_value->statr_priming_amount.mantissa >> 8) >> 0x000F));
            pos += 1;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_SET_INITIAL_RESERVOIR_FILL_LEVEL:
        {
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->reservoir_fill_level.mantissa);
            pos += 1;
            p_gatt_value->p_value[pos] = (uint8_t)(((p_app_value->reservoir_fill_level.exponent << 4) & 0xF0) 
                | (uint8_t)((p_app_value->reservoir_fill_level.mantissa >> 8) >> 0x000F));
            pos += 1;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_READ_ISF_PROFILE_TEMPLATE:
        {
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->read_isf_prof_template_num);
            pos += 1;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_WRITE_ISF_PROFILE_TEMPLATE:
        {
            if (p_app_value->write_isf_prof_template.is_end_transaction)
            {
                p_gatt_value->p_value[pos] |= BLE_IDC_PRV_IDD_CCP_ISFPT_END_TRANSACTION;
            }
            if (p_app_value->write_isf_prof_template.is_second_time_block_present)
            {
                p_gatt_value->p_value[pos] |= BLE_IDC_PRV_IDD_CCP_ISFPT_SECOND_TIME_BLOCK_PRESENT;
            }
            if (p_app_value->write_isf_prof_template.is_third_time_block_present)
            {
                p_gatt_value->p_value[pos] |= BLE_IDC_PRV_IDD_CCP_ISFPT_THIRD_TIME_BLOCK_PRESENT;
            }
            pos += 1;
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->write_isf_prof_template.isf_prof_template_num);
            pos += 1;
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->write_isf_prof_template.first_time_block_num_index);
            pos += 1;
            BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->write_isf_prof_template.first_duration);
            pos += 2;
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->write_isf_prof_template.first_isf.mantissa);
            pos += 1;
            p_gatt_value->p_value[pos] = (uint8_t)(((p_app_value->write_isf_prof_template.first_isf.exponent << 4) & 0xF0) 
                | (uint8_t)((p_app_value->write_isf_prof_template.first_isf.mantissa >> 8) >> 0x000F));
            pos += 1;
            if (p_app_value->write_isf_prof_template.is_second_time_block_present)
            {
                BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->write_isf_prof_template.second_duration);
                pos += 2;
                BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->write_isf_prof_template.second_isf.mantissa);
                pos += 1;
                p_gatt_value->p_value[pos] = (uint8_t)(((p_app_value->write_isf_prof_template.second_isf.exponent << 4) & 0xF0)
                    | (uint8_t)((p_app_value->write_isf_prof_template.second_isf.mantissa >> 8) & 0x000F));
                pos += 1;
            }

            if (p_app_value->write_isf_prof_template.is_third_time_block_present)
            {
                BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->write_isf_prof_template.third_duration);
                pos += 2;
                BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->write_isf_prof_template.third_isf.mantissa);
                pos += 1;
                p_gatt_value->p_value[pos] = (uint8_t)(((p_app_value->write_isf_prof_template.third_isf.exponent << 4) & 0xF0)
                    | (uint8_t)((p_app_value->write_isf_prof_template.third_isf.mantissa >> 8) & 0x000F));
                pos += 1;
            }
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_WRITE_ISF_PROFILE_TEMPLATE_RESPONSE:
        {
            if (p_app_value->write_isf_prof_template_response.is_transaction_completed)
            {
                p_gatt_value->p_value[pos] |= BLE_IDC_PRV_IDD_CCP_ISFPT_RES_TRANSACTION_COMP;
            }
            pos += 1;
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->write_isf_prof_template_response.isf_profile_template_num);
            pos += 1;
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->write_isf_prof_template_response.first_time_block_number_index);
            pos += 1;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_READ_I2CHO_RATIO_PROFILE_TEMPLATE:
        {
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->i2cho_ratio_prof_template_number);
            pos += 1;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_WRITE_I2CHO_RATIO_PROFILE_TEMPLATE:
        {
            if (p_app_value->write_icho_ratio_profile.is_end_transaction)
            {
                p_gatt_value->p_value[pos] |= BLE_IDC_PRV_IDD_CCP_I2CHORPT_END_TRANSACTION;
            }

            if (p_app_value->write_icho_ratio_profile.is_second_time_block_present)
            {
                p_gatt_value->p_value[pos] |= BLE_IDC_PRV_IDD_CCP_I2CHORPT_SECOND_TIME_BLOCK_PRESENT;
            }

            if (p_app_value->write_icho_ratio_profile.is_third_time_block_present)
            {
                p_gatt_value->p_value[pos] |= BLE_IDC_PRV_IDD_CCP_I2CHORPT_THIRD_TIME_BLOCK_PRESENT;
            }

            pos += 1;
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->write_icho_ratio_profile.icho_ratio_prof_template_num);
            pos += 1;
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->write_icho_ratio_profile.first_time_block_num_index);
            pos += 1;
            BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->write_icho_ratio_profile.first_duration);
            pos += 2;
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->write_icho_ratio_profile.first_i2cho_ratio.mantissa);
            pos += 1;
            p_gatt_value->p_value[pos] = (uint8_t)(((p_app_value->write_icho_ratio_profile.first_i2cho_ratio.exponent << 4) & 0xF0) 
                | (uint8_t)((p_app_value->write_icho_ratio_profile.first_i2cho_ratio.mantissa >> 8) & 0x000F));
            pos += 1;
            if (p_app_value->write_icho_ratio_profile.is_second_time_block_present)
            {
                BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->write_icho_ratio_profile.second_duration);
                pos += 2;
                BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->write_icho_ratio_profile.second_i2cho_ratio.mantissa);
                pos += 1;
                p_gatt_value->p_value[pos] = (uint8_t)(((p_app_value->write_icho_ratio_profile.second_i2cho_ratio.exponent << 4) & 0xF0)
                    | (uint8_t)((p_app_value->write_icho_ratio_profile.second_i2cho_ratio.mantissa >> 8) & 0x000F));
                pos += 1;
            }

            if (p_app_value->write_icho_ratio_profile.is_third_time_block_present)
            {
                BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->write_icho_ratio_profile.third_duration);
                pos += 2;
                BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->write_icho_ratio_profile.third_i2cho_ratio.mantissa);
                pos += 1;
                p_gatt_value->p_value[pos] = (uint8_t)(((p_app_value->write_icho_ratio_profile.third_i2cho_ratio.exponent << 4) & 0xF0)
                    | (uint8_t)((p_app_value->write_icho_ratio_profile.third_i2cho_ratio.mantissa >> 8) & 0x000F));
                pos += 1;
            }
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_WRITE_I2CHO_RATIO_PROFILE_TEMPLATE_RESPONSE:
        {
            if (p_app_value->write_icho_ratio_prof_tempate_response.is_trans_completed)
            {
                p_gatt_value->p_value[pos] |= BLE_IDC_PRV_IDD_CCP_I2CHORPT_RES_TRANSACTION_COMP;
            }

            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->write_icho_ratio_prof_tempate_response.icho_ratio_profile_template_num);
            pos += 1;
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->write_icho_ratio_prof_tempate_response.first_time_block_number_index);
            pos += 1;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_READ_TARGET_GLUCOSE_RANGE_PROFILE_TEMPLATE:
        {
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->target_glucose_range_prof_template_number);
            pos += 1;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_WRITE_TARGET_GLUCOSE_RANGE_PROFILE_TEMPLATE:
        {
            if (p_app_value->write_target_glucose_range_profile.is_end_transaction)
            {
                p_gatt_value->p_value[pos] |= BLE_IDC_PRV_IDD_CCP_TGRPT_END_TRANSACTION;
            }

            if (p_app_value->write_target_glucose_range_profile.is_second_time_block_pres)
            {
                p_gatt_value->p_value[pos] |= BLE_IDC_PRV_IDD_CCP_TGRPT_SECOND_TIME_BLOCK_PRESENT;
            }

            pos += 1;
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->write_target_glucose_range_profile.tgrp_template_number);
            pos += 1;
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->write_target_glucose_range_profile.first_time_block_num_index);
            pos += 1;
            BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->write_target_glucose_range_profile.first_duration);
            pos += 2;
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->write_target_glucose_range_profile.first_lower_target_glucose_limit.mantissa);
            pos += 1;
            p_gatt_value->p_value[pos] = (uint8_t)(((p_app_value->write_target_glucose_range_profile.first_lower_target_glucose_limit.exponent << 4) & 0xF0) 
                | (uint8_t)((p_app_value->write_target_glucose_range_profile.first_lower_target_glucose_limit.mantissa >> 8) & 0x000F));
            pos += 1;
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->write_target_glucose_range_profile.first_upper_target_glucose_limit.mantissa);
            pos += 1;
            p_gatt_value->p_value[pos] = (uint8_t)(((p_app_value->write_target_glucose_range_profile.first_upper_target_glucose_limit.exponent << 4) & 0xF0) 
                | (uint8_t)((p_app_value->write_target_glucose_range_profile.first_upper_target_glucose_limit.mantissa >> 8) & 0x000F));
            pos += 1;
            if (p_app_value->write_target_glucose_range_profile.is_second_time_block_pres)
            {
                BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->write_target_glucose_range_profile.second_duration);
                pos += 2;
                BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->write_target_glucose_range_profile.second_lower_target_glucose_limit.mantissa);
                pos += 1;
                p_gatt_value->p_value[pos] = (uint8_t)(((p_app_value->write_target_glucose_range_profile.second_lower_target_glucose_limit.exponent << 4) & 0xF0)
                    | (uint8_t)((p_app_value->write_target_glucose_range_profile.second_lower_target_glucose_limit.mantissa >> 8) & 0x000F));
                pos += 1;
                BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->write_target_glucose_range_profile.second_upper_target_glucose_limit.mantissa);
                pos += 1;
                p_gatt_value->p_value[pos] = (uint8_t)(((p_app_value->write_target_glucose_range_profile.second_upper_target_glucose_limit.exponent << 4) & 0xF0)
                    | (uint8_t)((p_app_value->write_target_glucose_range_profile.second_upper_target_glucose_limit.mantissa >> 8) & 0x000F));
                pos += 1;
            }
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_WRITE_TARGET_GLUCOSE_RANGE_PROFILE_TEMPLATE_RESPONSE:
        {
            if (p_app_value->glucose_range_profile_response.is_transaction_completed)
            {
                p_gatt_value->p_value[pos] |= BLE_IDC_PRV_IDD_CCP_TGRPT_RES_TRANSACTION_COMP;
            }

            pos += 1;
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->glucose_range_profile_response.tgrp_template_number);
            pos += 1;
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->glucose_range_profile_response.first_time_block_number_index);
            pos += 1;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_GET_MAX_BOLUS_AMOUNT_RESPONSE:
        {
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->get_max_bolus_amout_resp.mantissa);
            pos += 1;
            p_gatt_value->p_value[pos] = (uint8_t)(((p_app_value->get_max_bolus_amout_resp.exponent << 4) & 0xF0) 
                | (uint8_t)((p_app_value->get_max_bolus_amout_resp.mantissa >> 8) & 0x000F));
            pos += 1;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_SET_MAX_BOLUS_AMOUNT:
        {
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->set_max_bolus_amout.mantissa);
            pos += 1;
            p_gatt_value->p_value[pos] = (uint8_t)(((p_app_value->set_max_bolus_amout.exponent << 4) & 0xF0) 
                | (uint8_t)((p_app_value->set_max_bolus_amout.mantissa >> 8) & 0x000F));
            pos += 1;
        }
        break;

        default:
        {
            /*Do nothing*/
        }
        break;
    }
    
    if (e2e_protection_enable)
    {
        if (BLE_IDC_PRV_IDD_E2E_COUNTER_MAXIMUM_VALUE == gs_idd_command_control_point_e2e_counter.e2e_counter)
        {
            gs_idd_command_control_point_e2e_counter.e2e_counter = 0;
        }
        gs_idd_command_control_point_e2e_counter.e2e_counter++;
        BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &gs_idd_command_control_point_e2e_counter.e2e_counter);
        pos += 1;
        e2e_crc = e2e_crc_calculation(p_gatt_value->p_value, (uint16_t)pos);
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &e2e_crc);
        pos += 2;

    }
    else if (e2e_add_manual)
    {
        BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->e2e_counter);
        pos += 1;
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->e2e_crc);
        pos += 2;
    }

    p_gatt_value->value_len = (uint16_t)pos;

    return BLE_SUCCESS;
}
/***********************************************************************************************************************
 * Function Name: decode_idd_command_control_point
 * Description  : This function converts IDD Command Control Point characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the IDD Command Control Point value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_idd_command_control_point(st_ble_idc_idd_command_control_point_t *p_app_value, 
    const st_ble_gatt_value_t *p_gatt_value)
{
    /* byte sequence to app data. */
    uint32_t pos = 0;

    /*check p_gatt_value->value_len has sufficient length*/
    if ((BLE_IDC_IDD_COMMAND_CONTROL_POINT_LEN < p_gatt_value->value_len) || (0 == p_gatt_value->value_len))
    {
        return BLE_ERR_INVALID_DATA;
    }

    memset((uint8_t*)p_app_value, 0x00, sizeof(*p_app_value));

    BT_UNPACK_LE_2_BYTE(&p_app_value->op_code, &p_gatt_value->p_value[pos]);
    pos += 2;
    switch (p_app_value->op_code)
    {
        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_RESPONSE_CODE:
        {
            BT_UNPACK_LE_2_BYTE(&p_app_value->ccp_resp_code.request_op_code, &p_gatt_value->p_value[pos]);
            pos += 2;
            BT_UNPACK_LE_1_BYTE(&p_app_value->ccp_resp_code.response_code_value, &p_gatt_value->p_value[pos]);
            pos += 1;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_SET_THERAPY_CONTROL_STATE:
        {
            BT_UNPACK_LE_1_BYTE(&p_app_value->set_therapy_control_state, &p_gatt_value->p_value[pos]);
            pos += 1;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_SNOOZE_ANNUNCIATION:
        {
            BT_UNPACK_LE_2_BYTE(&p_app_value->snooze_annunciation_instance_id, &p_gatt_value->p_value[pos]);
            pos += 2;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_SNOOZE_ANNUNCIATION_RESPONSE:
        {
            BT_UNPACK_LE_2_BYTE(&p_app_value->snooze_annunciation_instance_id_response, &p_gatt_value->p_value[pos]);
            pos += 2;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_CONFIRM_ANNUNCIATION:
        {
            BT_UNPACK_LE_2_BYTE(&p_app_value->confirm_annunciation_instance_id, &p_gatt_value->p_value[pos]);
            pos += 2;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_CONFIRM_ANNUNCIATION_RESPONSE:
        {
            BT_UNPACK_LE_2_BYTE(&p_app_value->confirm_annunciation_instance_id_response, &p_gatt_value->p_value[pos]);
            pos += 2;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_READ_BASAL_RATE_PROFILE_TEMPLATE:
        {
            BT_UNPACK_LE_1_BYTE(&p_app_value->basel_rate_profile_template_number, &p_gatt_value->p_value[pos]);
            pos += 1;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_WRITE_BASAL_RATE_PROFILE_TEMPLATE:
        {
            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_CCP_BRPT_END_TRANSACTION)
            {
                p_app_value->write_basal_rate_profile_template.is_end_transaction = true;
            }
            else
            {
                p_app_value->write_basal_rate_profile_template.is_end_transaction = false;
            }

            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_CCP_BRPT_SECOND_TIME_BLOCK_PRESENT)
            {
                p_app_value->write_basal_rate_profile_template.is_second_time_block_present = true;
            }
            else
            {
                p_app_value->write_basal_rate_profile_template.is_second_time_block_present = false;
            }

            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_CCP_BRPT_THIRD_TIME_BLOCK_PRESENT)
            {
                p_app_value->write_basal_rate_profile_template.is_third_time_block_present = true;
            }
            else
            {
                p_app_value->write_basal_rate_profile_template.is_third_time_block_present = false;
            }

            BT_UNPACK_LE_1_BYTE(&p_app_value->write_basal_rate_profile_template.basal_rate_profile_template_num, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->write_basal_rate_profile_template.first_time_block_number_index, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_2_BYTE(&p_app_value->write_basal_rate_profile_template.first_duration, &p_gatt_value->p_value[pos]);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->write_basal_rate_profile_template.first_rate.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->write_basal_rate_profile_template.first_rate.exponent 
                = (int8_t)(((int16_t)p_app_value->write_basal_rate_profile_template.first_rate.mantissa) >> 12);
            p_app_value->write_basal_rate_profile_template.first_rate.mantissa 
                = (int16_t)(p_app_value->write_basal_rate_profile_template.first_rate.mantissa & 0x0FFF);
            pos += 2;
            if (p_app_value->write_basal_rate_profile_template.is_second_time_block_present)
            {
                BT_UNPACK_LE_2_BYTE(&p_app_value->write_basal_rate_profile_template.second_duration, &p_gatt_value->p_value[pos]);
                pos += 2;
                BT_UNPACK_LE_2_BYTE(&p_app_value->write_basal_rate_profile_template.second_rate.mantissa, &p_gatt_value->p_value[pos]);
                p_app_value->write_basal_rate_profile_template.second_rate.exponent
                    = (int8_t)(((int16_t)p_app_value->write_basal_rate_profile_template.second_rate.mantissa) >> 12);
                p_app_value->write_basal_rate_profile_template.second_rate.mantissa
                    = (int16_t)(p_app_value->write_basal_rate_profile_template.second_rate.mantissa & 0x0FFF);
                pos += 2;
            }

            if (p_app_value->write_basal_rate_profile_template.is_third_time_block_present)
            {
                BT_UNPACK_LE_2_BYTE(&p_app_value->write_basal_rate_profile_template.third_duration, &p_gatt_value->p_value[pos]);
                pos += 2;
                BT_UNPACK_LE_2_BYTE(&p_app_value->write_basal_rate_profile_template.third_rate.mantissa, &p_gatt_value->p_value[pos]);
                p_app_value->write_basal_rate_profile_template.third_rate.exponent 
                    = (int8_t)(((int16_t)p_app_value->write_basal_rate_profile_template.third_rate.mantissa) >> 12);
                p_app_value->write_basal_rate_profile_template.third_rate.mantissa 
                    = (int16_t)(p_app_value->write_basal_rate_profile_template.third_rate.mantissa & 0x0FFF);
                pos += 2;
            }
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_WRITE_BASAL_RATE_PROFILE_TEMPLATE_RESPONSE:
        {
            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_CCP_BRPTR_TRANSACTION_COMPLETED)
            {
                p_app_value->write_basal_rate_profile_template_response.is_trans_comp = true;
            }
            else
            {
                p_app_value->write_basal_rate_profile_template_response.is_trans_comp = false;
            }

            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->write_basal_rate_profile_template_response.basal_rate_profile_template_number, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->write_basal_rate_profile_template_response.first_time_block_number_index, &p_gatt_value->p_value[pos]);
            pos += 1;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_SET_TBR_ADJUSTMENT:
        {
            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_CCP_TBR_ADJUSTMENT_TBR_TEMPLATE_NUMBER_PRESENT)
            {
                p_app_value->set_tbr_adjustment.is_tbr_template_number_present = true;
            }
            else
            {
                p_app_value->set_tbr_adjustment.is_tbr_template_number_present = false;
            }

            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_CCP_TBR_ADJUSTMENT_TBR_DELIVERY_CONTEXT_PRESENT)
            {
                p_app_value->set_tbr_adjustment.is_tbr_delivery_context_present = true;
            }
            else
            {
                p_app_value->set_tbr_adjustment.is_tbr_delivery_context_present = false;
            }

            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_CCP_TBR_ADJUSTMENT_CHANGE_TBR)
            {
                p_app_value->set_tbr_adjustment.is_change_tbr = true;
            }
            else
            {
                p_app_value->set_tbr_adjustment.is_change_tbr = false;
            }

            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->set_tbr_adjustment.tbr_type, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_2_BYTE(&p_app_value->set_tbr_adjustment.tbr_adj_val.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->set_tbr_adjustment.tbr_adj_val.exponent 
                = (int8_t)(((int16_t)p_app_value->set_tbr_adjustment.tbr_adj_val.mantissa) >> 12);
            p_app_value->set_tbr_adjustment.tbr_adj_val.mantissa 
                = (int16_t)(p_app_value->set_tbr_adjustment.tbr_adj_val.mantissa & 0x0FFF);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->set_tbr_adjustment.tbr_duration, &p_gatt_value->p_value[pos]);
            pos += 2;
            if (p_app_value->set_tbr_adjustment.is_tbr_template_number_present)
            {
                BT_UNPACK_LE_1_BYTE(&p_app_value->set_tbr_adjustment.tbr_template_num, &p_gatt_value->p_value[pos]);
                pos += 1;
            }

            if (p_app_value->set_tbr_adjustment.is_tbr_delivery_context_present)
            {
                BT_UNPACK_LE_1_BYTE(&p_app_value->set_tbr_adjustment.tbr_delivery_context, &p_gatt_value->p_value[pos]);
                pos += 1;
            }
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_GET_TBR_TEMPLATE:
        {
            BT_UNPACK_LE_1_BYTE(&p_app_value->get_tbr_template_number, &p_gatt_value->p_value[pos]);
            pos += 1;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_GET_TBR_TEMPLATE_RESPONSE:
        {
            BT_UNPACK_LE_1_BYTE(&p_app_value->get_tbr_template_response.tbr_template_number, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->get_tbr_template_response.tbr_type, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_2_BYTE(&p_app_value->get_tbr_template_response.tbr_adjustment_value.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->get_tbr_template_response.tbr_adjustment_value.exponent 
                = (int8_t)(((int16_t)p_app_value->get_tbr_template_response.tbr_adjustment_value.mantissa) >> 12);
            p_app_value->get_tbr_template_response.tbr_adjustment_value.mantissa 
                = (int16_t)(p_app_value->get_tbr_template_response.tbr_adjustment_value.mantissa & 0x0FFF);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->get_tbr_template_response.tbr_duration, &p_gatt_value->p_value[pos]);
            pos += 2;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_SET_TBR_TEMPLATE:
        {
            BT_UNPACK_LE_1_BYTE(&p_app_value->set_tbr_template.tbr_template_number, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->set_tbr_template.tbr_type, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_2_BYTE(&p_app_value->set_tbr_template.tbr_adjustment_value.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->set_tbr_template.tbr_adjustment_value.exponent 
                = (int8_t)(((int16_t)p_app_value->set_tbr_template.tbr_adjustment_value.mantissa) >> 12);
            p_app_value->set_tbr_template.tbr_adjustment_value.mantissa 
                = (int16_t)(p_app_value->set_tbr_template.tbr_adjustment_value.mantissa & 0x0FFF);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->set_tbr_template.tbr_duration, &p_gatt_value->p_value[pos]);
            pos += 2;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_SET_TBR_TEMPLATE_RESPONSE:
        {
            BT_UNPACK_LE_1_BYTE(&p_app_value->set_tbr_template_number_response, &p_gatt_value->p_value[pos]);
            pos += 1;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_SET_BOLUS:
        {
            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_BOLUS_DELAY_TIME_PRESENT)
            {
                p_app_value->set_bolus.is_bolus_delay_time_present = true;
            }
            else
            {
                p_app_value->set_bolus.is_bolus_delay_time_present = false;
            }

            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_BOLUS_TEMPLATE_NUMBER_PRESENT)
            {
                p_app_value->set_bolus.is_bolus_template_number_present = true;
            }
            else
            {
                p_app_value->set_bolus.is_bolus_template_number_present = false;
            }

            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_BOLUS_ACTIVATION_TYPE_PRESENT)
            {
                p_app_value->set_bolus.is_bolus_activation_type_present = true;
            }
            else
            {
                p_app_value->set_bolus.is_bolus_activation_type_present = false;
            }

            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_BOLUS_DELIVERY_REASON_CORRECTION)
            {
                p_app_value->set_bolus.is_bolus_delivery_reason_correction = true;
            }
            else
            {
                p_app_value->set_bolus.is_bolus_delivery_reason_correction = false;
            }

            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_BOLUS_DELIVERY_REASON_MEAL)
            {
                p_app_value->set_bolus.is_bolus_delivery_reason_meal = true;
            }
            else
            {
                p_app_value->set_bolus.is_bolus_delivery_reason_meal = false;
            }

            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->set_bolus.bolus_type, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_2_BYTE(&p_app_value->set_bolus.bolus_fast_amount.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->set_bolus.bolus_fast_amount.exponent 
                = (int8_t)(((int16_t)p_app_value->set_bolus.bolus_fast_amount.mantissa) >> 12);
            p_app_value->set_bolus.bolus_fast_amount.mantissa 
                = (int16_t)(p_app_value->set_bolus.bolus_fast_amount.mantissa & 0x0FFF);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->set_bolus.bolus_extended_amount.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->set_bolus.bolus_extended_amount.exponent 
                = (int8_t)(((int16_t)p_app_value->set_bolus.bolus_extended_amount.mantissa) >> 12);
            p_app_value->set_bolus.bolus_extended_amount.mantissa 
                = (int16_t)(p_app_value->set_bolus.bolus_extended_amount.mantissa & 0x0FFF);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->set_bolus.bolus_duration, &p_gatt_value->p_value[pos]);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->set_bolus.bolus_delay_time, &p_gatt_value->p_value[pos]);
            pos += 2;
            BT_UNPACK_LE_1_BYTE(&p_app_value->set_bolus.bolus_template_number, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->set_bolus.bolus_activation_type, &p_gatt_value->p_value[pos]);
            pos += 1;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_SET_BOLUS_RESPONSE:
        {
            BT_UNPACK_LE_2_BYTE(&p_app_value->bolus_response, &p_gatt_value->p_value[pos]);
            pos += 2;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_CANCEL_BOLUS:
        {
            BT_UNPACK_LE_2_BYTE(&p_app_value->cancel_bolus_id, &p_gatt_value->p_value[pos]);
            pos += 2;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_CANCEL_BOLUS_RESPONSE:
        {
            BT_UNPACK_LE_2_BYTE(&p_app_value->cancel_bolus_id_response, &p_gatt_value->p_value[pos]);
            pos += 2;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_GET_AVAILABLE_BOLUSES_RESPONSE:
        {
            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_GET_AVAILABLE_BOLUSES_RES_FAST_BOLUS_AVAILABLE)
            {
                p_app_value->get_available_boluses_response.is_fast_bolus_available = true;

            }
            else
            {
                p_app_value->get_available_boluses_response.is_fast_bolus_available = false;
            }

            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_GET_AVAILABLE_BOLUSES_RES_EXTENDED_BOLUS_AVAILABLE)
            {
                p_app_value->get_available_boluses_response.is_extended_bolus_available = true;
            }
            else
            {
                p_app_value->get_available_boluses_response.is_extended_bolus_available = false;
            }

            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_GET_AVAILABLE_BOLUSES_RES_MULTIWAVE_BOLUS_AVAILABLE)
            {
                p_app_value->get_available_boluses_response.is_multiwave_bolus_available = true;
            }
            else
            {
                p_app_value->get_available_boluses_response.is_multiwave_bolus_available = false;
            }

            pos += 1;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_GET_BOLUS_TEMPLATE:
        {
            BT_UNPACK_LE_1_BYTE(&p_app_value->bouls_template_number, &p_gatt_value->p_value[pos]);
            pos += 1;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_GET_BOLUS_TEMPLATE_RESPONSE:
        {
            BT_UNPACK_LE_1_BYTE(&p_app_value->get_bolus_template_response.bolus_template_num, &p_gatt_value->p_value[pos]);
            pos += 1;
            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_GET_BOLUS_TEMPLATE_DELAY_TIME_PRESENT)
            {
                p_app_value->get_bolus_template_response.is_bolus_delay_time_present = true;
            }

            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_GET_BOLUS_TEMPLATE_DELIVERY_REASON_CORRECTION)
            {
                p_app_value->get_bolus_template_response.is_bolus_delivery_reason_correction = true;
            }

            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_GET_BOLUS_TEMPLATE_DELIVERY_REASON_MEAL)
            {
                p_app_value->get_bolus_template_response.is_bolus_delivery_reason_meal = true;
            }

            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->get_bolus_template_response.bolus_type, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_2_BYTE(&p_app_value->get_bolus_template_response.bolus_fast_amount.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->get_bolus_template_response.bolus_fast_amount.exponent 
                = (int8_t)(((int16_t)p_app_value->get_bolus_template_response.bolus_fast_amount.mantissa) >> 12);
            p_app_value->get_bolus_template_response.bolus_fast_amount.mantissa 
                = (int16_t)(p_app_value->get_bolus_template_response.bolus_fast_amount.mantissa & 0x0FFF);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->get_bolus_template_response.bolus_extended_amount.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->get_bolus_template_response.bolus_extended_amount.exponent 
                = (int8_t)(((int16_t)p_app_value->get_bolus_template_response.bolus_extended_amount.mantissa) >> 12);
            p_app_value->get_bolus_template_response.bolus_extended_amount.mantissa 
                = (int16_t)(p_app_value->get_bolus_template_response.bolus_extended_amount.mantissa & 0x0FFF);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->get_bolus_template_response.bolus_duration, &p_gatt_value->p_value[pos]);
            pos += 2;
            if (p_app_value->get_bolus_template_response.is_bolus_delay_time_present)
            {
                BT_UNPACK_LE_2_BYTE(&p_app_value->get_bolus_template_response.bolus_delay_time, &p_gatt_value->p_value[pos]);
                pos += 2;
            }
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_SET_BOLUS_TEMPLATE:
        {
            BT_UNPACK_LE_1_BYTE(&p_app_value->set_bolus_template.bolus_template_num, &p_gatt_value->p_value[pos]);
            pos += 1;
            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_GET_BOLUS_TEMPLATE_DELAY_TIME_PRESENT)
            {
                p_app_value->set_bolus_template.is_bolus_delay_time_present = true;
            }

            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_GET_BOLUS_TEMPLATE_DELIVERY_REASON_CORRECTION)
            {
                p_app_value->set_bolus_template.is_bolus_delivery_reason_correction = true;
            }

            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_GET_BOLUS_TEMPLATE_DELIVERY_REASON_MEAL)
            {
                p_app_value->set_bolus_template.is_bolus_delivery_reason_meal = true;
            }

            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->set_bolus_template.bolus_type, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_2_BYTE(&p_app_value->set_bolus_template.bolus_fast_amount.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->set_bolus_template.bolus_fast_amount.exponent = (int8_t)(((int16_t)p_app_value->set_bolus_template.bolus_fast_amount.mantissa) >> 12);
            p_app_value->set_bolus_template.bolus_fast_amount.mantissa = (int16_t)(p_app_value->set_bolus_template.bolus_fast_amount.mantissa & 0x0FFF);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->set_bolus_template.bolus_extended_amount.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->set_bolus_template.bolus_extended_amount.exponent = (int8_t)(((int16_t)p_app_value->set_bolus_template.bolus_extended_amount.mantissa) >> 12);
            p_app_value->set_bolus_template.bolus_extended_amount.mantissa = (int16_t)(p_app_value->set_bolus_template.bolus_extended_amount.mantissa & 0x0FFF);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->set_bolus_template.bolus_duration, &p_gatt_value->p_value[pos]);
            pos += 2;

            if (p_app_value->set_bolus_template.is_bolus_delay_time_present)
            {
                BT_UNPACK_LE_2_BYTE(&p_app_value->set_bolus_template.bolus_delay_time, &p_gatt_value->p_value[pos]);
                pos += 2;
            }
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_SET_BOLUS_TEMPLATE_RESPONSE:
        {
            BT_UNPACK_LE_1_BYTE(&p_app_value->set_bolus_template_res, &p_gatt_value->p_value[pos]);
            pos += 1;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_RESET_TEMPLATE_STATUS:
        {
            BT_UNPACK_LE_1_BYTE(&p_app_value->reset_template_status.number_of_templates_to_reset, &p_gatt_value->p_value[pos]);
            pos += 1;
            for (int i = 0; i < p_app_value->reset_template_status.number_of_templates_to_reset; i++)
            {
                BT_UNPACK_LE_1_BYTE(&p_app_value->reset_template_status.template_number[i], &p_gatt_value->p_value[pos]);
                pos += 1;
            }
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_RESET_TEMPLATE_STATUS_RESPONSE:
        {
            BT_UNPACK_LE_1_BYTE(&p_app_value->status_response.number_of_templates_to_reset, &p_gatt_value->p_value[pos]);
            pos += 1;
            for (int i = 0; i < p_app_value->status_response.number_of_templates_to_reset; i++)
            {
                BT_UNPACK_LE_1_BYTE(&p_app_value->status_response.template_number[i], &p_gatt_value->p_value[pos]);
                pos += 1;
            }
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_ACTIVATE_PROFILE_TEMPLATES:
        {
            BT_UNPACK_LE_1_BYTE(&p_app_value->active_prof_template.number_of_templates_to_activate, &p_gatt_value->p_value[pos]);
            pos += 1;
            for (int i = 0; i < p_app_value->active_prof_template.number_of_templates_to_activate; i++)
            {
                BT_UNPACK_LE_1_BYTE(&p_app_value->active_prof_template.profile_template_numbers[i], &p_gatt_value->p_value[pos]);
                pos += 1;
            }
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_ACTIVATE_PROFILE_TEMPLATES_RESPONSE:
        {
            BT_UNPACK_LE_1_BYTE(&p_app_value->active_prof_template_response.number_of_templates_to_activate, &p_gatt_value->p_value[pos]);
            pos += 1;
            for (int i = 0; i < p_app_value->active_prof_template_response.number_of_templates_to_activate; i++)
            {
                BT_UNPACK_LE_1_BYTE(&p_app_value->active_prof_template_response.profile_template_numbers[i], &p_gatt_value->p_value[pos]);
                pos += 1;
            }
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_GET_ACTIVATED_PROFILE_TEMPLATES_RESPONSE:
        {
            BT_UNPACK_LE_1_BYTE(&p_app_value->get_active_prof_template_response.number_of_templates_to_activate, &p_gatt_value->p_value[pos]);
            pos += 1;
            for (int i = 0; i < p_app_value->get_active_prof_template_response.number_of_templates_to_activate; i++)
            {
                BT_UNPACK_LE_1_BYTE(&p_app_value->get_active_prof_template_response.profile_template_numbers[i], &p_gatt_value->p_value[pos]);
                pos += 1;
            }
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_START_PRIMING:
        {
            BT_UNPACK_LE_2_BYTE(&p_app_value->statr_priming_amount.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->statr_priming_amount.exponent = (int8_t)(((int16_t)p_app_value->statr_priming_amount.mantissa) >> 12);
            p_app_value->statr_priming_amount.mantissa = (int16_t)(p_app_value->statr_priming_amount.mantissa & 0x0FFF);
            pos += 2;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_SET_INITIAL_RESERVOIR_FILL_LEVEL:
        {
            BT_UNPACK_LE_2_BYTE(&p_app_value->reservoir_fill_level.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->reservoir_fill_level.exponent = (int8_t)(((int16_t)p_app_value->reservoir_fill_level.mantissa) >> 12);
            p_app_value->reservoir_fill_level.mantissa = (int16_t)(p_app_value->reservoir_fill_level.mantissa & 0x0FFF);
            pos += 2;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_READ_ISF_PROFILE_TEMPLATE:
        {
            BT_UNPACK_LE_1_BYTE(&p_app_value->read_isf_prof_template_num, &p_gatt_value->p_value[pos]);
            pos += 1;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_WRITE_ISF_PROFILE_TEMPLATE:
        {
            BT_UNPACK_LE_2_BYTE(&p_app_value->write_isf_prof_template.third_isf.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->write_isf_prof_template.third_isf.exponent = (int8_t)(((int16_t)p_app_value->write_isf_prof_template.third_isf.mantissa) >> 12);
            p_app_value->write_isf_prof_template.third_isf.mantissa = (int16_t)(p_app_value->write_isf_prof_template.third_isf.mantissa & 0x0FFF);
            pos += 2;

            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_CCP_ISFPT_END_TRANSACTION)
            {
                p_app_value->write_isf_prof_template.is_end_transaction = true;
            }
            else
            {
                p_app_value->write_isf_prof_template.is_end_transaction = false;
            }

            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_CCP_ISFPT_SECOND_TIME_BLOCK_PRESENT)
            {
                p_app_value->write_isf_prof_template.is_second_time_block_present = true;
            }
            else
            {
                p_app_value->write_isf_prof_template.is_second_time_block_present = false;
            }

            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_CCP_ISFPT_THIRD_TIME_BLOCK_PRESENT)
            {
                p_app_value->write_isf_prof_template.is_third_time_block_present = true;
            }
            else
            {
                p_app_value->write_isf_prof_template.is_third_time_block_present = false;
            }

            pos += 1;;
            BT_UNPACK_LE_1_BYTE(&p_app_value->write_isf_prof_template.isf_prof_template_num, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->write_isf_prof_template.first_time_block_num_index, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_2_BYTE(&p_app_value->write_isf_prof_template.first_isf.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->write_isf_prof_template.first_isf.exponent = (int8_t)(((int16_t)p_app_value->write_isf_prof_template.first_isf.mantissa) >> 12);
            p_app_value->write_isf_prof_template.first_isf.mantissa = (int16_t)(p_app_value->write_isf_prof_template.first_isf.mantissa & 0x0FFF);
            pos += 2;
            if (p_app_value->write_isf_prof_template.is_second_time_block_present)
            {
                BT_UNPACK_LE_2_BYTE(&p_app_value->write_isf_prof_template.second_duration, &p_gatt_value->p_value[pos]);
                pos += 2;
                BT_UNPACK_LE_2_BYTE(&p_app_value->write_isf_prof_template.second_isf.mantissa, &p_gatt_value->p_value[pos]);
                p_app_value->write_isf_prof_template.second_isf.exponent
                    = (int8_t)(((int16_t)p_app_value->write_isf_prof_template.second_isf.mantissa) >> 12);
                p_app_value->write_isf_prof_template.second_isf.mantissa
                    = (int16_t)(p_app_value->write_isf_prof_template.second_isf.mantissa & 0x0FFF);
                pos += 2;
            }

            if (p_app_value->write_isf_prof_template.is_third_time_block_present)
            {
                BT_UNPACK_LE_2_BYTE(&p_app_value->write_isf_prof_template.third_duration, &p_gatt_value->p_value[pos]);
                pos += 2;
                BT_UNPACK_LE_2_BYTE(&p_app_value->write_isf_prof_template.third_isf.mantissa, &p_gatt_value->p_value[pos]);
                p_app_value->write_isf_prof_template.third_isf.exponent
                    = (int8_t)(((int16_t)p_app_value->write_isf_prof_template.third_isf.mantissa) >> 12);
                p_app_value->write_isf_prof_template.third_isf.mantissa
                    = (int16_t)(p_app_value->write_isf_prof_template.third_isf.mantissa & 0x0FFF);
                pos += 2;
            }
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_WRITE_ISF_PROFILE_TEMPLATE_RESPONSE:
        {
            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_CCP_ISFPT_RES_TRANSACTION_COMP)
            {
                p_app_value->write_isf_prof_template_response.is_transaction_completed = true;
            }

            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->write_isf_prof_template_response.isf_profile_template_num, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->write_isf_prof_template_response.first_time_block_number_index, &p_gatt_value->p_value[pos]);
            pos += 1;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_READ_I2CHO_RATIO_PROFILE_TEMPLATE:
        {
            BT_UNPACK_LE_1_BYTE(&p_app_value->i2cho_ratio_prof_template_number, &p_gatt_value->p_value[pos]);
            pos += 1;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_WRITE_I2CHO_RATIO_PROFILE_TEMPLATE:
        {
            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_CCP_I2CHORPT_END_TRANSACTION)
            {
                p_app_value->write_icho_ratio_profile.is_end_transaction = true;
            }

            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_CCP_I2CHORPT_SECOND_TIME_BLOCK_PRESENT)
            {
                p_app_value->write_icho_ratio_profile.is_second_time_block_present = true;
            }

            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_CCP_I2CHORPT_THIRD_TIME_BLOCK_PRESENT)
            {
                p_app_value->write_icho_ratio_profile.is_third_time_block_present = true;
            }

            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->write_icho_ratio_profile.icho_ratio_prof_template_num, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->write_icho_ratio_profile.first_time_block_num_index, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_2_BYTE(&p_app_value->write_icho_ratio_profile.first_duration, &p_gatt_value->p_value[pos]);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->write_icho_ratio_profile.first_i2cho_ratio.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->write_icho_ratio_profile.first_i2cho_ratio.exponent 
                = (int8_t)(((int16_t)p_app_value->write_icho_ratio_profile.first_i2cho_ratio.mantissa) >> 12);
            p_app_value->write_icho_ratio_profile.first_i2cho_ratio.mantissa 
                = (int16_t)(p_app_value->write_icho_ratio_profile.first_i2cho_ratio.mantissa & 0x0FFF);
            pos += 2;
            if (p_app_value->write_icho_ratio_profile.is_second_time_block_present)
            {
                BT_UNPACK_LE_2_BYTE(&p_app_value->write_icho_ratio_profile.second_duration, &p_gatt_value->p_value[pos]);
                pos += 2;
                BT_UNPACK_LE_2_BYTE(&p_app_value->write_icho_ratio_profile.second_i2cho_ratio.mantissa, &p_gatt_value->p_value[pos]);
                p_app_value->write_icho_ratio_profile.second_i2cho_ratio.exponent
                    = (int8_t)(((int16_t)p_app_value->write_icho_ratio_profile.second_i2cho_ratio.mantissa) >> 12);
                p_app_value->write_icho_ratio_profile.second_i2cho_ratio.mantissa
                    = (int16_t)(p_app_value->write_icho_ratio_profile.second_i2cho_ratio.mantissa & 0x0FFF);
                pos += 2;
            }

            if (p_app_value->write_icho_ratio_profile.is_third_time_block_present)
            {
                BT_UNPACK_LE_2_BYTE(&p_app_value->write_icho_ratio_profile.third_duration, &p_gatt_value->p_value[pos]);
                pos += 2;
                BT_UNPACK_LE_2_BYTE(&p_app_value->write_icho_ratio_profile.third_i2cho_ratio.mantissa, &p_gatt_value->p_value[pos]);
                p_app_value->write_icho_ratio_profile.third_i2cho_ratio.exponent
                    = (int8_t)(((int16_t)p_app_value->write_icho_ratio_profile.third_i2cho_ratio.mantissa) >> 12);
                p_app_value->write_icho_ratio_profile.third_i2cho_ratio.mantissa
                    = (int16_t)(p_app_value->write_icho_ratio_profile.third_i2cho_ratio.mantissa & 0x0FFF);
                pos += 2;
            }
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_WRITE_I2CHO_RATIO_PROFILE_TEMPLATE_RESPONSE:
        {
            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_CCP_I2CHORPT_RES_TRANSACTION_COMP)
            {
                p_app_value->write_icho_ratio_prof_tempate_response.is_trans_completed = true;
            }

            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->write_icho_ratio_prof_tempate_response.icho_ratio_profile_template_num, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->write_icho_ratio_prof_tempate_response.first_time_block_number_index, &p_gatt_value->p_value[pos]);
            pos += 1;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_READ_TARGET_GLUCOSE_RANGE_PROFILE_TEMPLATE:
        {
            BT_UNPACK_LE_1_BYTE(&p_app_value->target_glucose_range_prof_template_number, &p_gatt_value->p_value[pos]);
            pos += 1;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_WRITE_TARGET_GLUCOSE_RANGE_PROFILE_TEMPLATE:
        {
            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_CCP_TGRPT_END_TRANSACTION)
            {
                p_app_value->write_target_glucose_range_profile.is_end_transaction = true;
            }

            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_CCP_TGRPT_SECOND_TIME_BLOCK_PRESENT)
            {
                p_app_value->write_target_glucose_range_profile.is_second_time_block_pres = true;
            }

            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->write_target_glucose_range_profile.tgrp_template_number, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->write_target_glucose_range_profile.first_time_block_num_index, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_2_BYTE(&p_app_value->write_target_glucose_range_profile.first_duration, &p_gatt_value->p_value[pos]);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->write_target_glucose_range_profile.first_lower_target_glucose_limit.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->write_target_glucose_range_profile.first_lower_target_glucose_limit.exponent 
                = (int8_t)(((int16_t)p_app_value->write_target_glucose_range_profile.first_lower_target_glucose_limit.mantissa) >> 12);
            p_app_value->write_target_glucose_range_profile.first_lower_target_glucose_limit.mantissa 
                = (int16_t)(p_app_value->write_target_glucose_range_profile.first_lower_target_glucose_limit.mantissa & 0x0FFF);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->write_target_glucose_range_profile.first_upper_target_glucose_limit.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->write_target_glucose_range_profile.first_upper_target_glucose_limit.exponent 
                = (int8_t)(((int16_t)p_app_value->write_target_glucose_range_profile.first_upper_target_glucose_limit.mantissa) >> 12);
            p_app_value->write_target_glucose_range_profile.first_upper_target_glucose_limit.mantissa 
                = (int16_t)(p_app_value->write_target_glucose_range_profile.first_upper_target_glucose_limit.mantissa & 0x0FFF);
            pos += 2;
            if (p_app_value->write_target_glucose_range_profile.is_second_time_block_pres)
            {
                BT_UNPACK_LE_2_BYTE(&p_app_value->write_target_glucose_range_profile.second_duration, &p_gatt_value->p_value[pos]);
                pos += 2;
                BT_UNPACK_LE_2_BYTE(&p_app_value->write_target_glucose_range_profile.second_lower_target_glucose_limit.mantissa, &p_gatt_value->p_value[pos]);
                p_app_value->write_target_glucose_range_profile.second_lower_target_glucose_limit.exponent
                    = (int8_t)(((int16_t)p_app_value->write_target_glucose_range_profile.second_lower_target_glucose_limit.mantissa) >> 12);
                p_app_value->write_target_glucose_range_profile.second_lower_target_glucose_limit.mantissa
                    = (int16_t)(p_app_value->write_target_glucose_range_profile.second_lower_target_glucose_limit.mantissa & 0x0FFF);
                pos += 2;
                BT_UNPACK_LE_2_BYTE(&p_app_value->write_target_glucose_range_profile.second_upper_target_glucose_limit.mantissa, &p_gatt_value->p_value[pos]);
                p_app_value->write_target_glucose_range_profile.second_upper_target_glucose_limit.exponent
                    = (int8_t)(((int16_t)p_app_value->write_target_glucose_range_profile.second_lower_target_glucose_limit.mantissa) >> 12);
                p_app_value->write_target_glucose_range_profile.second_upper_target_glucose_limit.mantissa
                    = (int16_t)(p_app_value->write_target_glucose_range_profile.second_upper_target_glucose_limit.mantissa & 0x0FFF);
                pos += 2;
            }
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_WRITE_TARGET_GLUCOSE_RANGE_PROFILE_TEMPLATE_RESPONSE:
        {
            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_CCP_TGRPT_RES_TRANSACTION_COMP)
            {
                p_app_value->glucose_range_profile_response.is_transaction_completed = true;
            }

            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->glucose_range_profile_response.tgrp_template_number, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->glucose_range_profile_response.first_time_block_number_index, &p_gatt_value->p_value[pos]);
            pos += 1;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_GET_MAX_BOLUS_AMOUNT_RESPONSE:
        {
            BT_UNPACK_LE_2_BYTE(&p_app_value->get_max_bolus_amout_resp.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->get_max_bolus_amout_resp.exponent = (int8_t)(((int16_t)p_app_value->get_max_bolus_amout_resp.mantissa) >> 12);
            p_app_value->get_max_bolus_amout_resp.mantissa = (int16_t)(p_app_value->get_max_bolus_amout_resp.mantissa & 0x0FFF);
            pos += 2;
        }
        break;

        case BLE_IDC_IDD_COMMAND_CONTROL_POINT_OP_CODE_SET_MAX_BOLUS_AMOUNT:
        {
            BT_UNPACK_LE_2_BYTE(&p_app_value->set_max_bolus_amout.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->set_max_bolus_amout.exponent = (int8_t)(((int16_t)p_app_value->set_max_bolus_amout.mantissa) >> 12);
            p_app_value->set_max_bolus_amout.mantissa = (int16_t)(p_app_value->set_max_bolus_amout.mantissa & 0x0FFF);
            pos += 2;
        }
        break;

        default:
        {
            /*Do nothing*/
        }
        break;
    }
    BT_UNPACK_LE_1_BYTE(&p_app_value->e2e_counter, &p_gatt_value->p_value[pos]);
    pos += 1;
    BT_UNPACK_LE_2_BYTE(&p_app_value->e2e_crc, &p_gatt_value->p_value[pos]);
    pos += 2;

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: decode_idd_command_data
 * Description  : This function converts IDD Command Data characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the IDD Command Data value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_idd_command_data(st_ble_idc_idd_command_data_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    /* app data to byte sequence. */
    uint32_t pos = 0;

    /*check p_gatt_value->value_len has sufficient length*/
    if ((BLE_IDC_IDD_COMMAND_DATA_LEN < p_gatt_value->value_len) || (0 == p_gatt_value->value_len))
    {
        return BLE_ERR_INVALID_DATA;
    }

    memset((uint8_t*)p_app_value, 0x00, sizeof(*p_app_value));

    BT_UNPACK_LE_2_BYTE(&p_app_value->response_op_code,&p_gatt_value->p_value[pos]);
    pos += 2;
    switch (p_app_value->response_op_code)
    {
        case BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_RESPONSE_CODE:
        {
            BT_UNPACK_LE_2_BYTE(&p_app_value->ccp_resp_code.request_op_code,&p_gatt_value->p_value[pos]);
            pos += 2;
            BT_UNPACK_LE_1_BYTE(&p_app_value->ccp_resp_code.response_code_value,&p_gatt_value->p_value[pos]);
            pos += 1;
        }
        break;

        case BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_SET_THERAPY_CONTROL_STATE:
        {
            BT_UNPACK_LE_1_BYTE(&p_app_value->set_therapy_control_state,&p_gatt_value->p_value[pos]);
            pos += 1;
        }
        break;

        case BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_SNOOZE_ANNUNCIATION:
        {
            BT_UNPACK_LE_2_BYTE(&p_app_value->snooze_annunciation_instance_id,&p_gatt_value->p_value[pos]);
            pos += 2;
        }
        break;
    
        case BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_SNOOZE_ANNUNCIATION_RESPONSE:
        {
            BT_UNPACK_LE_2_BYTE(&p_app_value->snooze_annunciation_instance_id_response,&p_gatt_value->p_value[pos]);
            pos += 2;
        }
        break;

        case BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_CONFIRM_ANNUNCIATION:
        {
            BT_UNPACK_LE_2_BYTE(&p_app_value->confirm_annunciation_instance_id,&p_gatt_value->p_value[pos]);
            pos += 2;
        }
        break;

        case BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_CONFIRM_ANNUNCIATION_RESPONSE:
        {
            BT_UNPACK_LE_2_BYTE(&p_app_value->confirm_annunciation_instance_id_res,&p_gatt_value->p_value[pos]);
            pos += 2;
        }
        break;

        case BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_READ_BASAL_RATE_PROFILE_TEMPLATE:
        {
            BT_UNPACK_LE_1_BYTE( &p_app_value->basel_rate_profile_template_number, &p_gatt_value->p_value[pos]);
            pos += 1;
        }
        break;

        case BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_READ_BASAL_RATE_PROFILE_TEMPLATE_RESPONSE:
        {
            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_CD_SECOND_TIME_BLOCK_PRESENT)
            {
                p_app_value->read_basel_rate_profile_template_response.is_second_time_block_present = true;
            }
            else
            {
                p_app_value->read_basel_rate_profile_template_response.is_second_time_block_present = false;
            }

            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_CD_THIRD_TIME_BLOCK_PRESENT)
            {
                p_app_value->read_basel_rate_profile_template_response.is_third_time_block_present = true;
            }
            else
            {
                p_app_value->read_basel_rate_profile_template_response.is_third_time_block_present = false;
            }

            BT_UNPACK_LE_1_BYTE(&p_app_value->read_basel_rate_profile_template_response.basal_rate_profile_template_number,&p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->read_basel_rate_profile_template_response.first_time_block_number_index, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_2_BYTE(&p_app_value->read_basel_rate_profile_template_response.first_duration, &p_gatt_value->p_value[pos]);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->read_basel_rate_profile_template_response.first_rate.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->read_basel_rate_profile_template_response.first_rate.exponent 
                = (int8_t)(((int16_t)p_app_value->read_basel_rate_profile_template_response.first_rate.mantissa) >> 12);
            p_app_value->read_basel_rate_profile_template_response.first_rate.mantissa 
                = (int16_t)(p_app_value->read_basel_rate_profile_template_response.first_rate.mantissa & 0x0FFF);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->read_basel_rate_profile_template_response.second_duration,&p_gatt_value->p_value[pos]);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->read_basel_rate_profile_template_response.second_rate.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->read_basel_rate_profile_template_response.second_rate.exponent 
                = (int8_t)(((int16_t)p_app_value->read_basel_rate_profile_template_response.second_rate.mantissa) >> 12);
            p_app_value->read_basel_rate_profile_template_response.second_rate.mantissa 
                = (int16_t)(p_app_value->read_basel_rate_profile_template_response.second_rate.mantissa & 0x0FFF);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->read_basel_rate_profile_template_response.third_duration,&p_gatt_value->p_value[pos]);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->read_basel_rate_profile_template_response.third_rate.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->read_basel_rate_profile_template_response.third_rate.exponent 
                = (int8_t)(((int16_t)p_app_value->read_basel_rate_profile_template_response.third_rate.mantissa) >> 12);
            p_app_value->read_basel_rate_profile_template_response.third_rate.mantissa 
                = (int16_t)(p_app_value->read_basel_rate_profile_template_response.third_rate.mantissa & 0x0FFF);
            pos += 2;
        }
        break;

        case BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_WRITE_BASAL_RATE_PROFILE_TEMPLATE:
        {
            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_CCP_BRPT_END_TRANSACTION)
            {
                p_app_value->write_brp_template.is_end_transaction = true;
            }
            else
            {
                p_app_value->write_brp_template.is_end_transaction = false;
            }

            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_CCP_BRPT_SECOND_TIME_BLOCK_PRESENT)
            {
                p_app_value->write_brp_template.is_second_time_block_present = true;
            }
            else
            {
                p_app_value->write_brp_template.is_second_time_block_present = false;
            }

            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_CCP_BRPT_THIRD_TIME_BLOCK_PRESENT)
            {
                p_app_value->write_brp_template.is_third_time_block_present = true;
            }
            else
            {
                p_app_value->write_brp_template.is_third_time_block_present = false;
            }

            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->write_brp_template.basal_rate_profile_template_num,&p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->write_brp_template.first_time_block_number_index,&p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_2_BYTE(&p_app_value->write_brp_template.first_duration, &p_gatt_value->p_value[pos]);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->write_brp_template.first_rate.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->write_brp_template.first_rate.exponent = (int8_t)(((int16_t)p_app_value->write_brp_template.first_rate.mantissa) >> 12);
            p_app_value->write_brp_template.first_rate.mantissa = (int16_t)(p_app_value->write_brp_template.first_rate.mantissa & 0x0FFF);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->write_brp_template.second_duration,&p_gatt_value->p_value[pos]);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->write_brp_template.second_rate.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->write_brp_template.second_rate.exponent = (int8_t)(((int16_t)p_app_value->write_brp_template.second_rate.mantissa) >> 12);
            p_app_value->write_brp_template.second_rate.mantissa = (int16_t)(p_app_value->write_brp_template.second_rate.mantissa & 0x0FFF);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->write_brp_template.third_duration, &p_gatt_value->p_value[pos]);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->write_brp_template.third_rate.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->write_brp_template.third_rate.exponent = (int8_t)(((int16_t)p_app_value->write_brp_template.third_rate.mantissa) >> 12);
            p_app_value->write_brp_template.third_rate.mantissa = (int16_t)(p_app_value->write_brp_template.third_rate.mantissa & 0x0FFF);
            pos += 2;
        }
        break;

        case BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_WRITE_BASAL_RATE_PROFILE_TEMPLATE_RESPONSE:
        {
            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_CCP_BRPTR_TRANSACTION_COMPLETED)
            {
                p_app_value->write_brp_template_response.is_trans_comp = true;
            }

            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->write_brp_template_response.basal_rate_profile_template_number,&p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->write_brp_template_response.first_time_block_number_index,&p_gatt_value->p_value[pos]);
            pos += 1;
        }
        break;

       case BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_SET_TBR_ADJUSTMENT:
       {
            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_CCP_TBR_ADJUSTMENT_TBR_TEMPLATE_NUMBER_PRESENT)
            {
                p_app_value->set_tbr_adjustment.is_tbr_template_number_present = true;
            }

            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_CCP_TBR_ADJUSTMENT_TBR_DELIVERY_CONTEXT_PRESENT)
            {
                p_app_value->set_tbr_adjustment.is_tbr_delivery_context_present = true;
            }

            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_CCP_TBR_ADJUSTMENT_CHANGE_TBR)
            {
                p_app_value->set_tbr_adjustment.is_change_tbr = true;
            }

            BT_UNPACK_LE_1_BYTE(&p_app_value->set_tbr_adjustment.tbr_type,&p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_2_BYTE(&p_app_value->set_tbr_adjustment.tbr_adj_val.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->set_tbr_adjustment.tbr_adj_val.exponent = (int8_t)(((int16_t)p_app_value->set_tbr_adjustment.tbr_adj_val.mantissa) >> 12);
            p_app_value->set_tbr_adjustment.tbr_adj_val.mantissa = (int16_t)(p_app_value->set_tbr_adjustment.tbr_adj_val.mantissa & 0x0FFF);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->set_tbr_adjustment.tbr_duration, &p_gatt_value->p_value[pos]);
            pos += 2;
            BT_UNPACK_LE_1_BYTE(&p_app_value->set_tbr_adjustment.tbr_template_num,&p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->set_tbr_adjustment.tbr_delivery_context,&p_gatt_value->p_value[pos]);
            pos += 1;
       }
       break;

       case BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_GET_TBR_TEMPLATE:
       {
            BT_UNPACK_LE_1_BYTE(&p_app_value->get_tbr_template_number,&p_gatt_value->p_value[pos]);
            pos += 1;
       }
       break;

       case BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_GET_TBR_TEMPLATE_RESPONSE:
       {
            BT_PACK_LE_1_BYTE(&p_app_value->get_tbr_template_response.tbr_template_number, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_PACK_LE_1_BYTE(&p_app_value->get_tbr_template_response.tbr_type, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_2_BYTE(&p_app_value->get_tbr_template_response.tbr_adjustment_value.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->get_tbr_template_response.tbr_adjustment_value.exponent 
                = (int8_t)(((int16_t)p_app_value->get_tbr_template_response.tbr_adjustment_value.mantissa) >> 12);
            p_app_value->get_tbr_template_response.tbr_adjustment_value.mantissa 
                = (int16_t)(p_app_value->get_tbr_template_response.tbr_adjustment_value.mantissa & 0x0FFF);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->get_tbr_template_response.tbr_duration, &p_gatt_value->p_value[pos]);
            pos += 2;
       }
       break;

       case BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_SET_TBR_TEMPLATE:
       {
            BT_UNPACK_LE_1_BYTE(&p_app_value->set_tbr_template.tbr_template_number,&p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->set_tbr_template.tbr_type,&p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_2_BYTE(&p_app_value->set_tbr_template.tbr_adjustment_value.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->set_tbr_template.tbr_adjustment_value.exponent 
                = (int8_t)(((int16_t)p_app_value->set_tbr_template.tbr_adjustment_value.mantissa) >> 12);
            p_app_value->set_tbr_template.tbr_adjustment_value.mantissa 
                = (int16_t)(p_app_value->set_tbr_template.tbr_adjustment_value.mantissa & 0x0FFF);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->set_tbr_template.tbr_duration, &p_gatt_value->p_value[pos]);
            pos += 2;
       }
       break;

       case BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_SET_TBR_TEMPLATE_RESPONSE:
       {
            BT_UNPACK_LE_1_BYTE(&p_app_value->set_tbr_template_number_response, &p_gatt_value->p_value[pos]);
            pos += 1;
       }
       break;

       case BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_SET_BOLUS:
       {
           if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_BOLUS_DELAY_TIME_PRESENT)
           {
               p_app_value->set_bolus.is_bolus_delay_time_present = true;
           }
           else
           {
               p_app_value->set_bolus.is_bolus_delay_time_present = false;
           }

           if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_BOLUS_TEMPLATE_NUMBER_PRESENT)
           {
               p_app_value->set_bolus.is_bolus_template_number_present = true;
           }
           else
           {
               p_app_value->set_bolus.is_bolus_template_number_present = false;
           }

           if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_BOLUS_ACTIVATION_TYPE_PRESENT)
           {
               p_app_value->set_bolus.is_bolus_activation_type_present = true;
           }
           else
           {
               p_app_value->set_bolus.is_bolus_activation_type_present = false;
           }

           if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_BOLUS_DELIVERY_REASON_CORRECTION)
           {
               p_app_value->set_bolus.is_bolus_delivery_reason_correction = true;
           }
           else
           {
               p_app_value->set_bolus.is_bolus_delivery_reason_correction = false;
           }

           if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_BOLUS_DELIVERY_REASON_MEAL)
           {
               p_app_value->set_bolus.is_bolus_delivery_reason_meal = true;
           }
           else
           {
               p_app_value->set_bolus.is_bolus_delivery_reason_meal = false;
           }

           pos += 1;
           BT_UNPACK_LE_1_BYTE(&p_app_value->set_bolus.bolus_type, &p_gatt_value->p_value[pos]);
           pos += 1;
           BT_UNPACK_LE_2_BYTE(&p_app_value->set_bolus.bolus_fast_amount.mantissa, &p_gatt_value->p_value[pos]);
           p_app_value->set_bolus.bolus_fast_amount.exponent = (int8_t)(((int16_t)p_app_value->set_bolus.bolus_fast_amount.mantissa) >> 12);
           p_app_value->set_bolus.bolus_fast_amount.mantissa = (int16_t)(p_app_value->set_bolus.bolus_fast_amount.mantissa & 0x0FFF);
           pos += 2;
           BT_UNPACK_LE_2_BYTE(&p_app_value->set_bolus.bolus_extended_amount.mantissa, &p_gatt_value->p_value[pos]);
           p_app_value->set_bolus.bolus_extended_amount.exponent = (int8_t)(((int16_t)p_app_value->set_bolus.bolus_extended_amount.mantissa) >> 12);
           p_app_value->set_bolus.bolus_extended_amount.mantissa = (int16_t)(p_app_value->set_bolus.bolus_extended_amount.mantissa & 0x0FFF);
           pos += 2;
           BT_UNPACK_LE_2_BYTE( &p_app_value->set_bolus.bolus_duration, &p_gatt_value->p_value[pos]);
           pos += 2;
           BT_UNPACK_LE_2_BYTE(&p_app_value->set_bolus.bolus_delay_time, &p_gatt_value->p_value[pos]);
           pos += 2;
           BT_UNPACK_LE_1_BYTE(&p_app_value->set_bolus.bolus_template_number,&p_gatt_value->p_value[pos]);
           pos += 1;
           BT_UNPACK_LE_1_BYTE(&p_app_value->set_bolus.bolus_activation_type, &p_gatt_value->p_value[pos]);
           pos += 1;
       }
       break;

       case BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_SET_BOLUS_RESPONSE:
       {
           BT_UNPACK_LE_1_BYTE(&p_app_value->bolus_response, &p_gatt_value->p_value[pos]);
           pos += 1;
       }
       break;

       case BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_CANCEL_BOLUS:
       {
           BT_UNPACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->cancel_bolus_id);
           pos += 2;
       }
       break;

       case BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_CANCEL_BOLUS_RESPONSE:
       {
           BT_UNPACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->cancel_bolus_id_response);
           pos += 2;
       }
       break;

       case BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_GET_AVAILABLE_BOLUSES_RESPONSE:
       {
           if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_GET_AVAILABLE_BOLUSES_RES_FAST_BOLUS_AVAILABLE)
           {
               p_app_value->get_available_boluses_res.is_fast_bolus_available = true;
           }
           else
           {
               p_app_value->get_available_boluses_res.is_fast_bolus_available = false;
           }

           if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_GET_AVAILABLE_BOLUSES_RES_EXTENDED_BOLUS_AVAILABLE)
           {
               p_app_value->get_available_boluses_res.is_extended_bolus_available = true;
           }
           else
           {
               p_app_value->get_available_boluses_res.is_extended_bolus_available = false;
           }

           if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_GET_AVAILABLE_BOLUSES_RES_MULTIWAVE_BOLUS_AVAILABLE)
           {
               p_app_value->get_available_boluses_res.is_multiwave_bolus_available = true;
           }
           else
           {
               p_app_value->get_available_boluses_res.is_multiwave_bolus_available = false;
           }

           pos += 1;
       }
       break;

       case BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_GET_BOLUS_TEMPLATE:
       {
           BT_UNPACK_LE_1_BYTE(&p_app_value->bouls_template_number, &p_gatt_value->p_value[pos]);
           pos += 1;
       }
       break;

       case BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_GET_BOLUS_TEMPLATE_RESPONSE:
       {
           BT_UNPACK_LE_1_BYTE(&p_app_value->get_bolus_template_res.bolus_template_num,&p_gatt_value->p_value[pos]);
           pos += 1;
           if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_GET_BOLUS_TEMPLATE_DELAY_TIME_PRESENT)
           {
                p_app_value->get_bolus_template_res.is_bolus_delay_time_present = true;
           }
           else
           {
               p_app_value->get_bolus_template_res.is_bolus_delay_time_present = false;
           }

           if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_GET_BOLUS_TEMPLATE_DELIVERY_REASON_CORRECTION)
           {
               p_app_value->get_bolus_template_res.is_bolus_delivery_reason_correction = true;
           }
           else
           {
               p_app_value->get_bolus_template_res.is_bolus_delivery_reason_correction = false;
           }

           if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_GET_BOLUS_TEMPLATE_DELIVERY_REASON_MEAL)
           {
               p_app_value->get_bolus_template_res.is_bolus_delivery_reason_meal = true;
           }
           else
           {
               p_app_value->get_bolus_template_res.is_bolus_delivery_reason_meal = false;
           }

           pos += 1;
           BT_UNPACK_LE_1_BYTE(&p_app_value->get_bolus_template_res.bolus_type, &p_gatt_value->p_value[pos]);
           pos += 1;
           BT_UNPACK_LE_2_BYTE(&p_app_value->get_bolus_template_res.bolus_fast_amount.mantissa, &p_gatt_value->p_value[pos]);
           p_app_value->get_bolus_template_res.bolus_fast_amount.exponent = (int8_t)(((int16_t)p_app_value->get_bolus_template_res.bolus_fast_amount.mantissa) >> 12);
           p_app_value->get_bolus_template_res.bolus_fast_amount.mantissa = (int16_t)(p_app_value->get_bolus_template_res.bolus_fast_amount.mantissa & 0x0FFF);
           pos += 2;
           BT_UNPACK_LE_2_BYTE(&p_app_value->get_bolus_template_res.bolus_extended_amount.mantissa, &p_gatt_value->p_value[pos]);
           p_app_value->get_bolus_template_res.bolus_extended_amount.exponent = (int8_t)(((int16_t)p_app_value->get_bolus_template_res.bolus_extended_amount.mantissa) >> 12);
           p_app_value->get_bolus_template_res.bolus_extended_amount.mantissa = (int16_t)(p_app_value->get_bolus_template_res.bolus_extended_amount.mantissa & 0x0FFF);
           pos += 2;
           BT_UNPACK_LE_2_BYTE(&p_app_value->get_bolus_template_res.bolus_duration, &p_gatt_value->p_value[pos]);
           pos += 2;
           BT_UNPACK_LE_2_BYTE(&p_app_value->get_bolus_template_res.bolus_delay_time, &p_gatt_value->p_value[pos]);
           pos += 2;
       }
       break;

       case BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_SET_BOLUS_TEMPLATE:
       {
           BT_UNPACK_LE_1_BYTE(&p_app_value->set_bolus_temp.bolus_template_num, &p_gatt_value->p_value[pos]);
           pos += 1;
           if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_GET_BOLUS_TEMPLATE_DELAY_TIME_PRESENT)
           {
                p_app_value->set_bolus_temp.is_bolus_delay_time_present = true;
           }
           else
           {
               p_app_value->set_bolus_temp.is_bolus_delay_time_present = false;
           }

           if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_GET_BOLUS_TEMPLATE_DELIVERY_REASON_CORRECTION)
           {
                p_app_value->set_bolus_temp.is_bolus_delivery_reason_correction = true;
           }
           else
           {
               p_app_value->set_bolus_temp.is_bolus_delivery_reason_correction = false;
           }

           if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_GET_BOLUS_TEMPLATE_DELIVERY_REASON_MEAL)
           {
                p_app_value->set_bolus_temp.is_bolus_delivery_reason_meal = true;
           }
           else
           {
               p_app_value->set_bolus_temp.is_bolus_delivery_reason_meal = false;
           }

           pos += 1;
           BT_UNPACK_LE_1_BYTE( & p_app_value->set_bolus_temp.bolus_type, &p_gatt_value->p_value[pos]);
           pos += 1;
           BT_UNPACK_LE_2_BYTE(&p_app_value->set_bolus_temp.bolus_fast_amount.mantissa, &p_gatt_value->p_value[pos]);
           p_app_value->set_bolus_temp.bolus_fast_amount.exponent = (int8_t)(((int16_t)p_app_value->set_bolus_temp.bolus_fast_amount.mantissa) >> 12);
           p_app_value->set_bolus_temp.bolus_fast_amount.mantissa = (int16_t)(p_app_value->set_bolus_temp.bolus_fast_amount.mantissa & 0x0FFF);
           pos += 2;
           BT_UNPACK_LE_2_BYTE(&p_app_value->set_bolus_temp.bolus_extended_amount.mantissa, &p_gatt_value->p_value[pos]);
           p_app_value->set_bolus_temp.bolus_extended_amount.exponent = (int8_t)(((int16_t)p_app_value->set_bolus_temp.bolus_extended_amount.mantissa) >> 12);
           p_app_value->set_bolus_temp.bolus_extended_amount.mantissa = (int16_t)(p_app_value->set_bolus_temp.bolus_extended_amount.mantissa & 0x0FFF);
           pos += 2;
           BT_UNPACK_LE_2_BYTE(&p_app_value->set_bolus_temp.bolus_duration, &p_gatt_value->p_value[pos]);
           pos += 2;
           BT_UNPACK_LE_2_BYTE(&p_app_value->set_bolus_temp.bolus_delay_time, &p_gatt_value->p_value[pos]);
           pos += 2;
       }
       break;

       case BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_SET_BOLUS_TEMPLATE_RESPONSE:
       {
           BT_UNPACK_LE_1_BYTE(&p_app_value->set_bolus_template_res, &p_gatt_value->p_value[pos]);
           pos += 1;
       }
       break;

       case BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_GET_TEMPLATE_STATUS_AND_DETAILS_RESPONSE:
       {
           uint16_t array_size = 0;
           BT_UNPACK_LE_1_BYTE(&p_app_value->get_temstatus_details_response.template_type,&p_gatt_value->p_value[pos]);
           pos += 1;
           BT_UNPACK_LE_1_BYTE(&p_app_value->get_temstatus_details_response.starting_template_number,&p_gatt_value->p_value[pos]);
           pos += 1;
           BT_UNPACK_LE_1_BYTE( &p_app_value->get_temstatus_details_response.num_of_template,&p_gatt_value->p_value[pos]);
           pos += 1;
           BT_UNPACK_LE_1_BYTE(&p_app_value->get_temstatus_details_response.max_num_of_supported_blocks,&p_gatt_value->p_value[pos]);
           pos += 1;
           array_size = (uint16_t)((p_app_value->get_temstatus_details_response.num_of_template / 8) + 1);
           for (int count = 0; count < array_size; count++)
           {
               BT_UNPACK_LE_1_BYTE(&p_app_value->get_temstatus_details_response.configurable_flag[count] , &p_gatt_value->p_value[pos]);
               pos += 1;
           }
       }
       break;

       case BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_RESET_TEMPLATE_STATUS:
       {
           BT_UNPACK_LE_1_BYTE(&p_app_value->reset_template_status.number_of_templates_to_reset, &p_gatt_value->p_value[pos]);
           pos += 1;
           for (int i = 1; i <= p_app_value->reset_template_status.number_of_templates_to_reset; i++)
           {
               BT_UNPACK_LE_1_BYTE(&p_app_value->reset_template_status.template_number[i], &p_gatt_value->p_value[pos]);
               pos += 1;
           }
       }
       break;

       case BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_RESET_TEMPLATE_STATUS_RESPONSE:
       {
            BT_UNPACK_LE_1_BYTE(&p_app_value->status_response.number_of_templates_to_reset,&p_gatt_value->p_value[pos]);
            pos += 1;
            for (int i = 1; i <= p_app_value->status_response.number_of_templates_to_reset; i++)
            {
                BT_UNPACK_LE_1_BYTE(&p_app_value->status_response.template_number[i] , &p_gatt_value->p_value[pos]);
                pos += 1;
            }
       }
       break;

       case BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_ACTIVATE_PROFILE_TEMPLATES:
       {
           BT_UNPACK_LE_1_BYTE( &p_app_value->active_prof_template.number_of_templates_to_activate, &p_gatt_value->p_value[pos]);
           pos += 1;
           for (int i = 1; i <= p_app_value->active_prof_template.number_of_templates_to_activate; i++)
           {
               BT_UNPACK_LE_1_BYTE(&p_app_value->active_prof_template.profile_template_numbers[i] , &p_gatt_value->p_value[pos]);
               pos += 1;
           }
       }
       break;

       case BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_ACTIVATE_PROFILE_TEMPLATES_RESPONSE:
       {
           BT_UNPACK_LE_1_BYTE(&p_app_value->active_prof_template_response.number_of_templates_to_activate,&p_gatt_value->p_value[pos]);
           pos += 1;
           for (int i = 1; i <= p_app_value->active_prof_template_response.number_of_templates_to_activate; i++)
           {
               BT_UNPACK_LE_1_BYTE(&p_app_value->active_prof_template_response.profile_template_numbers[i] , &p_gatt_value->p_value[pos]);
               pos += 1;
           }
       }
       break;

       case BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_GET_ACTIVATED_PROFILE_TEMPLATES_RESPONSE:
       {
           BT_UNPACK_LE_1_BYTE(&p_app_value->get_active_prof_template_res.number_of_templates_to_activate,&p_gatt_value->p_value[pos]);
           pos += 1;
           for (int i = 1; i <= p_app_value->get_active_prof_template_res.number_of_templates_to_activate; i++)
           {
               BT_UNPACK_LE_1_BYTE(&p_app_value->get_active_prof_template_res.profile_template_numbers[i] ,&p_gatt_value->p_value[pos]);
               pos += 1;
           }
       }
       break;

       case BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_START_PRIMING:
       {
           BT_UNPACK_LE_2_BYTE(&p_app_value->statr_priming_amount.mantissa, &p_gatt_value->p_value[pos]);
           p_app_value->statr_priming_amount.exponent = (int8_t)(((int16_t)p_app_value->statr_priming_amount.mantissa) >> 12);
           p_app_value->statr_priming_amount.mantissa = (int16_t)(p_app_value->statr_priming_amount.mantissa & 0x0FFF);
           pos += 2;
       }
       break;

       case BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_SET_INITIAL_RESERVOIR_FILL_LEVEL:
       {
           BT_UNPACK_LE_2_BYTE(&p_app_value->reservoir_fill_level.mantissa, &p_gatt_value->p_value[pos]);
           p_app_value->reservoir_fill_level.exponent = (int8_t)(((int16_t)p_app_value->reservoir_fill_level.mantissa) >> 12);
           p_app_value->reservoir_fill_level.mantissa = (int16_t)(p_app_value->reservoir_fill_level.mantissa & 0x0FFF);
           pos += 2;
       }
       break;

       case BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_READ_ISF_PROFILE_TEMPLATE:
       {
           BT_UNPACK_LE_1_BYTE(&p_app_value->read_isf_prof_template_num,&p_gatt_value->p_value[pos]);
           pos += 1;
       }
       break;

       case BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_READ_ISF_PROFILE_TEMPLATE_RESPONSE:
       {
           if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_CD_SECOND_TIME_BLOCK_PRESENT)
           {
               p_app_value->read_isfpt_reasponse.is_second_time_block_present = true;
           }
           else
           {
               p_app_value->read_isfpt_reasponse.is_second_time_block_present = false;
           }

           if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_CD_THIRD_TIME_BLOCK_PRESENT)
           {
               p_app_value->read_isfpt_reasponse.is_third_time_block_present = true;
           }
           else
           {
               p_app_value->read_isfpt_reasponse.is_third_time_block_present = false;
           }

           BT_UNPACK_LE_1_BYTE(&p_app_value->read_isfpt_reasponse.isf_profile_template_number, &p_gatt_value->p_value[pos]);
           pos += 1;
           BT_UNPACK_LE_1_BYTE(&p_app_value->read_isfpt_reasponse.first_time_block_number_index,&p_gatt_value->p_value[pos]);
           pos += 1;
           BT_UNPACK_LE_2_BYTE(&p_app_value->read_isfpt_reasponse.first_duration, &p_gatt_value->p_value[pos]);
           pos += 2;
           BT_UNPACK_LE_2_BYTE(&p_app_value->read_isfpt_reasponse.first_isf.mantissa, &p_gatt_value->p_value[pos]);
           p_app_value->read_isfpt_reasponse.first_isf.exponent = (int8_t)(((int16_t)p_app_value->read_isfpt_reasponse.first_isf.mantissa) >> 12);
           p_app_value->read_isfpt_reasponse.first_isf.mantissa = (int16_t)(p_app_value->read_isfpt_reasponse.first_isf.mantissa & 0x0FFF);
           pos += 2;
           BT_UNPACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->read_isfpt_reasponse.second_duration);
           pos += 2;
           BT_UNPACK_LE_2_BYTE(&p_app_value->read_isfpt_reasponse.second_isf.mantissa, &p_gatt_value->p_value[pos]);
           p_app_value->read_isfpt_reasponse.second_isf.exponent = (int8_t)(((int16_t)p_app_value->read_isfpt_reasponse.second_isf.mantissa) >> 12);
           p_app_value->read_isfpt_reasponse.second_isf.mantissa = (int16_t)(p_app_value->read_isfpt_reasponse.second_isf.mantissa & 0x0FFF);
           pos += 2;
           BT_PACK_LE_2_BYTE(&p_app_value->read_isfpt_reasponse.third_duration,&p_gatt_value->p_value[pos]);
           pos += 2;
           BT_UNPACK_LE_2_BYTE(&p_app_value->read_isfpt_reasponse.second_isf.mantissa, &p_gatt_value->p_value[pos]);
           p_app_value->read_isfpt_reasponse.second_isf.exponent = (int8_t)(((int16_t)p_app_value->read_isfpt_reasponse.second_isf.mantissa) >> 12);
           p_app_value->read_isfpt_reasponse.second_isf.mantissa = (int16_t)(p_app_value->read_isfpt_reasponse.second_isf.mantissa & 0x0FFF);
           pos += 2;
       }
       break;

       case BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_WRITE_ISF_PROFILE_TEMPLATE:
       {
           if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_CCP_ISFPT_END_TRANSACTION)
           {
               p_app_value->write_isf_prof_template.is_end_transaction = true;
           }
           else
           {
               p_app_value->write_isf_prof_template.is_end_transaction = false;
           }

           if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_CCP_ISFPT_SECOND_TIME_BLOCK_PRESENT)
           {
               p_app_value->write_isf_prof_template.is_second_time_block_present = true;
           }
           else
           {
               p_app_value->write_isf_prof_template.is_second_time_block_present = false;
           }

           if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_CCP_ISFPT_THIRD_TIME_BLOCK_PRESENT)
           {
               p_app_value->write_isf_prof_template.is_third_time_block_present = true;
           }
           else
           {
               p_app_value->write_isf_prof_template.is_third_time_block_present = false;
           }

           pos += 1;
           BT_UNPACK_LE_1_BYTE(&p_app_value->write_isf_prof_template.isf_prof_template_num, &p_gatt_value->p_value[pos]);
           pos += 1;
           BT_UNPACK_LE_1_BYTE(&p_app_value->write_isf_prof_template.first_time_block_num_index, &p_gatt_value->p_value[pos]);
           pos += 1;
           BT_UNPACK_LE_2_BYTE(&p_app_value->write_isf_prof_template.first_duration, &p_gatt_value->p_value[pos]);
           pos += 2;
           BT_UNPACK_LE_2_BYTE(&p_app_value->write_isf_prof_template.first_isf.mantissa, &p_gatt_value->p_value[pos]);
           p_app_value->write_isf_prof_template.first_isf.exponent = (int8_t)(((int16_t)p_app_value->write_isf_prof_template.first_isf.mantissa) >> 12);
           p_app_value->write_isf_prof_template.first_isf.mantissa = (int16_t)(p_app_value->write_isf_prof_template.first_isf.mantissa & 0x0FFF);
           pos += 2;
           BT_UNPACK_LE_2_BYTE(&p_app_value->write_isf_prof_template.second_duration, &p_gatt_value->p_value[pos]);
           pos += 2;
           BT_UNPACK_LE_2_BYTE(&p_app_value->write_isf_prof_template.second_isf.mantissa, &p_gatt_value->p_value[pos]);
           p_app_value->write_isf_prof_template.second_isf.exponent = (int8_t)(((int16_t)p_app_value->write_isf_prof_template.second_isf.mantissa) >> 12);
           p_app_value->write_isf_prof_template.second_isf.mantissa = (int16_t)(p_app_value->write_isf_prof_template.second_isf.mantissa & 0x0FFF);
           pos += 2;
           BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->write_isf_prof_template.third_duration);
           pos += 2;
           BT_UNPACK_LE_2_BYTE(&p_app_value->write_isf_prof_template.third_isf.mantissa, &p_gatt_value->p_value[pos]);
           p_app_value->write_isf_prof_template.third_isf.exponent = (int8_t)(((int16_t)p_app_value->write_isf_prof_template.third_isf.mantissa) >> 12);
           p_app_value->write_isf_prof_template.third_isf.mantissa = (int16_t)(p_app_value->write_isf_prof_template.third_isf.mantissa & 0x0FFF);
           pos += 2;
       }
       break;

       case BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_WRITE_ISF_PROFILE_TEMPLATE_RESPONSE:
       {
           if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_CCP_ISFPT_RES_TRANSACTION_COMP)
           {
               p_app_value->write_isf_prof_template_res.is_transaction_completed = true;
           }
           pos += 1;
           BT_UNPACK_LE_1_BYTE(&p_app_value->write_isf_prof_template_res.isf_profile_template_num,&p_gatt_value->p_value[pos]);
           pos += 1;
           BT_UNPACK_LE_1_BYTE(&p_app_value->write_isf_prof_template_res.first_time_block_number_index, &p_gatt_value->p_value[pos]);
           pos += 1;
       }
       break;

       case BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_READ_I2CHO_RATIO_PROFILE_TEMPLATE:
       {
           BT_UNPACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->i2cho_ratio_prof_template_num);
           pos += 1;
       }
       break;

       case BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_READ_I2CHO_RATIO_PROFILE_TEMPLATE_RESPONSE:
       {
           if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_CD_SECOND_TIME_BLOCK_PRESENT)
           {
               p_app_value->i2chorpt_response.is_second_time_block_present = true;
           }

           if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_CD_THIRD_TIME_BLOCK_PRESENT)
           {
               p_app_value->i2chorpt_response.is_third_time_block_present = true;
           }

           BT_UNPACK_LE_1_BYTE(&p_app_value->i2chorpt_response.i2cho_ratio_profile_template_number,&p_gatt_value->p_value[pos]);
           pos += 1;
           BT_UNPACK_LE_1_BYTE(&p_app_value->i2chorpt_response.first_time_block_number_index,&p_gatt_value->p_value[pos]);
           pos += 1;
           BT_UNPACK_LE_2_BYTE(&p_app_value->i2chorpt_response.first_duration,&p_gatt_value->p_value[pos]);
           pos += 2;
           BT_UNPACK_LE_2_BYTE(&p_app_value->i2chorpt_response.first_i2cho_ratio.mantissa, &p_gatt_value->p_value[pos]);
           p_app_value->i2chorpt_response.first_i2cho_ratio.exponent 
               = (int8_t)(((int16_t)p_app_value->i2chorpt_response.first_i2cho_ratio.mantissa) >> 12);
           p_app_value->i2chorpt_response.first_i2cho_ratio.mantissa = (int16_t)(p_app_value->i2chorpt_response.first_i2cho_ratio.mantissa & 0x0FFF);
           pos += 2;
           BT_UNPACK_LE_2_BYTE(&p_app_value->i2chorpt_response.second_duration, &p_gatt_value->p_value[pos]);
           pos += 2;
           BT_UNPACK_LE_2_BYTE(&p_app_value->i2chorpt_response.second_i2cho_ratio.mantissa, &p_gatt_value->p_value[pos]);
           p_app_value->i2chorpt_response.second_i2cho_ratio.exponent 
               = (int8_t)(((int16_t)p_app_value->i2chorpt_response.second_i2cho_ratio.mantissa) >> 12);
           p_app_value->i2chorpt_response.second_i2cho_ratio.mantissa = (int16_t)(p_app_value->i2chorpt_response.second_i2cho_ratio.mantissa & 0x0FFF);
           pos += 2;
           BT_UNPACK_LE_2_BYTE(&p_app_value->i2chorpt_response.third_duration, &p_gatt_value->p_value[pos]);
           pos += 2;
           BT_UNPACK_LE_2_BYTE(&p_app_value->i2chorpt_response.third_i2cho_ratio.mantissa, &p_gatt_value->p_value[pos]);
           p_app_value->i2chorpt_response.third_i2cho_ratio.exponent 
               = (int8_t)(((int16_t)p_app_value->i2chorpt_response.third_i2cho_ratio.mantissa) >> 12);
           p_app_value->i2chorpt_response.third_i2cho_ratio.mantissa = (int16_t)(p_app_value->i2chorpt_response.third_i2cho_ratio.mantissa & 0x0FFF);
           pos += 2;
       }
       break;

       case BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_WRITE_I2CHO_RATIO_PROFILE_TEMPLATE:
       {
          if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_CCP_I2CHORPT_END_TRANSACTION)
          {
              p_app_value->write_icho_ratio_prof.is_end_transaction = true;
          }

          if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_CCP_I2CHORPT_SECOND_TIME_BLOCK_PRESENT)
          {
              p_app_value->write_icho_ratio_prof.is_second_time_block_present = true;
          }

          if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_CCP_I2CHORPT_THIRD_TIME_BLOCK_PRESENT)
          {
              p_app_value->write_icho_ratio_prof.is_third_time_block_present = true;
          }

          pos += 1;
          BT_UNPACK_LE_1_BYTE(&p_app_value->write_icho_ratio_prof.icho_ratio_prof_template_num, &p_gatt_value->p_value[pos]);
          pos += 1;
          BT_UNPACK_LE_1_BYTE(&p_app_value->write_icho_ratio_prof.first_time_block_num_index, &p_gatt_value->p_value[pos]);
          pos += 1;
          BT_UNPACK_LE_2_BYTE(&p_app_value->write_icho_ratio_prof.first_duration, &p_gatt_value->p_value[pos]);
          pos += 2;
          BT_UNPACK_LE_2_BYTE(&p_app_value->write_icho_ratio_prof.first_i2cho_ratio.mantissa, &p_gatt_value->p_value[pos]);
          p_app_value->write_icho_ratio_prof.first_i2cho_ratio.exponent 
              = (int8_t)(((int16_t)p_app_value->write_icho_ratio_prof.first_i2cho_ratio.mantissa) >> 12);
          p_app_value->write_icho_ratio_prof.first_i2cho_ratio.mantissa 
              = (int16_t)(p_app_value->write_icho_ratio_prof.first_i2cho_ratio.mantissa & 0x0FFF);
          pos += 2;
          BT_UNPACK_LE_2_BYTE(&p_app_value->write_icho_ratio_prof.second_duration, &p_gatt_value->p_value[pos]);
          pos += 2;
          BT_UNPACK_LE_2_BYTE(&p_app_value->write_icho_ratio_prof.second_i2cho_ratio.mantissa, &p_gatt_value->p_value[pos]);
          p_app_value->write_icho_ratio_prof.second_i2cho_ratio.exponent 
              = (int8_t)(((int16_t)p_app_value->write_icho_ratio_prof.second_i2cho_ratio.mantissa) >> 12);
          p_app_value->write_icho_ratio_prof.second_i2cho_ratio.mantissa 
              = (int16_t)(p_app_value->write_icho_ratio_prof.second_i2cho_ratio.mantissa & 0x0FFF);
          pos += 2;
          BT_UNPACK_LE_2_BYTE(&p_app_value->write_icho_ratio_prof.third_duration, &p_gatt_value->p_value[pos]);
          pos += 2;
          BT_UNPACK_LE_2_BYTE(&p_app_value->write_icho_ratio_prof.third_i2cho_ratio.mantissa, &p_gatt_value->p_value[pos]);
          p_app_value->write_icho_ratio_prof.third_i2cho_ratio.exponent 
              = (int8_t)(((int16_t)p_app_value->write_icho_ratio_prof.third_i2cho_ratio.mantissa) >> 12);
          p_app_value->write_icho_ratio_prof.third_i2cho_ratio.mantissa 
              = (int16_t)(p_app_value->write_icho_ratio_prof.third_i2cho_ratio.mantissa & 0x0FFF);
          pos += 2;
       }
       break;

       case BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_WRITE_I2CHO_RATIO_PROFILE_TEMPLATE_RESPONSE:
       {
           if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_CCP_I2CHORPT_RES_TRANSACTION_COMP)
           {
               p_app_value->write_icho_ratio_prof_tempate_res.is_trans_completed = true;
           }
           BT_UNPACK_LE_1_BYTE(&p_app_value->write_icho_ratio_prof_tempate_res.icho_ratio_profile_template_num,&p_gatt_value->p_value[pos]);
           pos += 1;
           BT_UNPACK_LE_1_BYTE(&p_app_value->write_icho_ratio_prof_tempate_res.first_time_block_number_index,&p_gatt_value->p_value[pos]);
           pos += 1;
       }
       break;

       case BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_READ_TARGET_GLUCOSE_RANGE_PROFILE_TEMPLATE:
       { 
           BT_UNPACK_LE_1_BYTE(&p_app_value->tgrp_template_number,&p_gatt_value->p_value[pos]);
           pos += 1;
       }
       break;

       case BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_READ_TARGET_GLUCOSE_RANGE_PROFILE_TEMPLATE_RESPONSE:
       {
           if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_CD_SECOND_TIME_BLOCK_PRESENT)
           {
               p_app_value->target_glucose_range_response.is_second_time_block_present = true;
           }
           else
           {
               p_app_value->target_glucose_range_response.is_second_time_block_present = false;
           }

           if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_CD_THIRD_TIME_BLOCK_PRESENT)
           {
               p_app_value->target_glucose_range_response.is_third_time_block_present = true;
           }
           else
           {
               p_app_value->target_glucose_range_response.is_third_time_block_present = false;
           }

           BT_UNPACK_LE_1_BYTE(&p_app_value->target_glucose_range_response.tg_range_profile_template_number, &p_gatt_value->p_value[pos]);
           pos += 1;
           BT_UNPACK_LE_1_BYTE(&p_app_value->target_glucose_range_response.first_time_block_number_index, &p_gatt_value->p_value[pos]);
           pos += 1;
           BT_UNPACK_LE_2_BYTE(&p_app_value->target_glucose_range_response.first_duration, &p_gatt_value->p_value[pos]);
           pos += 2;
           BT_UNPACK_LE_2_BYTE(&p_app_value->target_glucose_range_response.first_lower_tg_lmt.mantissa, &p_gatt_value->p_value[pos]);
           p_app_value->target_glucose_range_response.first_lower_tg_lmt.exponent 
               = (int8_t)(((int16_t)p_app_value->target_glucose_range_response.first_lower_tg_lmt.mantissa) >> 12);
           p_app_value->target_glucose_range_response.first_lower_tg_lmt.mantissa 
               = (int16_t)(p_app_value->target_glucose_range_response.first_lower_tg_lmt.mantissa & 0x0FFF);
           pos += 2;
           BT_UNPACK_LE_2_BYTE(&p_app_value->target_glucose_range_response.first_upper_tg_lmt.mantissa, &p_gatt_value->p_value[pos]);
           p_app_value->target_glucose_range_response.first_upper_tg_lmt.exponent 
               = (int8_t)(((int16_t)p_app_value->target_glucose_range_response.first_upper_tg_lmt.mantissa) >> 12);
           p_app_value->target_glucose_range_response.first_upper_tg_lmt.mantissa 
               = (int16_t)(p_app_value->target_glucose_range_response.first_upper_tg_lmt.mantissa & 0x0FFF);
           pos += 2;
           BT_UNPACK_LE_2_BYTE(&p_app_value->target_glucose_range_response.second_duration, &p_gatt_value->p_value[pos]);
           pos += 2;
           BT_UNPACK_LE_2_BYTE(&p_app_value->target_glucose_range_response.second_lower_tg_lmt.mantissa, &p_gatt_value->p_value[pos]);
           p_app_value->target_glucose_range_response.second_lower_tg_lmt.exponent 
               = (int8_t)(((int16_t)p_app_value->target_glucose_range_response.second_lower_tg_lmt.mantissa) >> 12);
           p_app_value->target_glucose_range_response.second_lower_tg_lmt.mantissa 
               = (int16_t)(p_app_value->target_glucose_range_response.second_lower_tg_lmt.mantissa & 0x0FFF);
           pos += 2;
           BT_UNPACK_LE_2_BYTE(&p_app_value->target_glucose_range_response.second_upper_tg_lmt.mantissa, &p_gatt_value->p_value[pos]);
           p_app_value->target_glucose_range_response.second_upper_tg_lmt.exponent 
               = (int8_t)(((int16_t)p_app_value->target_glucose_range_response.second_upper_tg_lmt.mantissa) >> 12);
           p_app_value->target_glucose_range_response.second_upper_tg_lmt.mantissa 
               = (int16_t)(p_app_value->target_glucose_range_response.second_upper_tg_lmt.mantissa & 0x0FFF);
           pos += 2;
       }
       break;

        case BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_WRITE_TARGET_GLUCOSE_RANGE_PROFILE_TEMPLATE:
        {
            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_CCP_TGRPT_END_TRANSACTION)
            {
                p_app_value->write_target_glucose_range_profile.is_end_transaction = true;
            }
            else
            {
                p_app_value->write_target_glucose_range_profile.is_end_transaction = false;
            }

            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_CCP_TGRPT_SECOND_TIME_BLOCK_PRESENT)
            {
                p_app_value->write_target_glucose_range_profile.is_second_time_block_pres = true;
            }
            else
            {
                p_app_value->write_target_glucose_range_profile.is_second_time_block_pres = false;
            }

            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->write_target_glucose_range_profile.tgrp_template_number, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->write_target_glucose_range_profile.first_time_block_num_index, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_2_BYTE(&p_app_value->write_target_glucose_range_profile.first_duration, &p_gatt_value->p_value[pos]);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->write_target_glucose_range_profile.first_lower_target_glucose_limit.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->write_target_glucose_range_profile.first_lower_target_glucose_limit.exponent 
                = (int8_t)(((int16_t)p_app_value->write_target_glucose_range_profile.first_lower_target_glucose_limit.mantissa) >> 12);
            p_app_value->write_target_glucose_range_profile.first_lower_target_glucose_limit.mantissa 
                = (int16_t)(p_app_value->write_target_glucose_range_profile.first_lower_target_glucose_limit.mantissa & 0x0FFF);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->write_target_glucose_range_profile.first_upper_target_glucose_limit.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->write_target_glucose_range_profile.first_upper_target_glucose_limit.exponent 
                = (int8_t)(((int16_t)p_app_value->write_target_glucose_range_profile.first_upper_target_glucose_limit.mantissa) >> 12);
            p_app_value->write_target_glucose_range_profile.first_upper_target_glucose_limit.mantissa 
                = (int16_t)(p_app_value->write_target_glucose_range_profile.first_upper_target_glucose_limit.mantissa & 0x0FFF);
            pos += 2;
            BT_PACK_LE_2_BYTE(&p_app_value->write_target_glucose_range_profile.second_duration, &p_gatt_value->p_value[pos]);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->write_target_glucose_range_profile.second_lower_target_glucose_limit.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->write_target_glucose_range_profile.second_lower_target_glucose_limit.exponent
                = (int8_t)(((int16_t)p_app_value->write_target_glucose_range_profile.second_lower_target_glucose_limit.mantissa) >> 12);
            p_app_value->write_target_glucose_range_profile.second_lower_target_glucose_limit.mantissa 
                = (int16_t)(p_app_value->write_target_glucose_range_profile.second_lower_target_glucose_limit.mantissa & 0x0FFF);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->write_target_glucose_range_profile.second_upper_target_glucose_limit.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->write_target_glucose_range_profile.second_upper_target_glucose_limit.exponent 
                = (int8_t)(((int16_t)p_app_value->write_target_glucose_range_profile.second_upper_target_glucose_limit.mantissa) >> 12);
            p_app_value->write_target_glucose_range_profile.second_upper_target_glucose_limit.mantissa 
                = (int16_t)(p_app_value->write_target_glucose_range_profile.second_upper_target_glucose_limit.mantissa & 0x0FFF);
            pos += 2;
        }
        break;

        case BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_WRITE_TARGET_GLUCOSE_RANGE_PROFILE_TEMPLATE_RESPONSE:
        {
            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_CCP_TGRPT_RES_TRANSACTION_COMP)
            {
                p_app_value->glucose_range_profile_response.is_transaction_completed = true;
            }
            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->glucose_range_profile_response.tgrp_template_number,&p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->glucose_range_profile_response.first_time_block_number_index, &p_gatt_value->p_value[pos]);
            pos += 1;
        }
        break;

        case BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_GET_MAX_BOLUS_AMOUNT_RESPONSE:
        {
            BT_UNPACK_LE_2_BYTE(&p_app_value->get_max_bolus_amout_resp.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->get_max_bolus_amout_resp.exponent = (int8_t)(((int16_t)p_app_value->get_max_bolus_amout_resp.mantissa) >> 12);
            p_app_value->get_max_bolus_amout_resp.mantissa = (int16_t)(p_app_value->get_max_bolus_amout_resp.mantissa & 0x0FFF);
            pos += 2;
        }
        break;

        case BLE_IDC_IDD_COMMAND_DATA_RESPONSE_OP_CODE_SET_MAX_BOLUS_AMOUNT:
        {
            BT_UNPACK_LE_2_BYTE(&p_app_value->set_max_bolus_amout.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->set_max_bolus_amout.exponent = (int8_t)(((int16_t)p_app_value->set_max_bolus_amout.mantissa) >> 12);
            p_app_value->set_max_bolus_amout.mantissa = (int16_t)(p_app_value->set_max_bolus_amout.mantissa & 0x0FFF);
            pos += 2;
        }
        break;

        default:
        {
            /*Do nothing*/
        }
        break;
    }
    
    BT_UNPACK_LE_1_BYTE(&p_app_value->e2e_counter, &p_gatt_value->p_value[pos]);
    pos += 1;
    BT_UNPACK_LE_2_BYTE(&p_app_value->e2e_crc, &p_gatt_value->p_value[pos]);
    pos += 2;

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_idd_record_access_control_point
 * Description  : This function converts IDD Record Access Control Point characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the IDD Record Access Control Point  value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_idd_record_access_control_point(const st_ble_idc_idd_record_access_control_point_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    /* app data to byte sequence. */
    uint32_t pos = 0;
    uint16_t e2e_crc = 0xFFFF;

    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);
    
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->racp_op_code);
    pos += 1;
    
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->racp_operator);
    pos += 1;
    
    for (uint8_t i = 0; i < p_app_value->operand_length; i++)
    {
        BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->racp_operand[i]);
        pos += 1;
    }
    
    if (e2e_protection_enable)
    {
        if (BLE_IDC_PRV_IDD_E2E_COUNTER_MAXIMUM_VALUE == gs_idd_record_access_e2e_counter.e2e_counter)
        {
            gs_idd_record_access_e2e_counter.e2e_counter = 0;
        }
        gs_idd_record_access_e2e_counter.e2e_counter++;
        BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &gs_idd_record_access_e2e_counter.e2e_counter);
        pos += 1;
        e2e_crc = e2e_crc_calculation(p_gatt_value->p_value, (uint16_t)pos);
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &e2e_crc);
        pos += 2;

    }

    p_gatt_value->value_len = (uint16_t)pos;

    return BLE_SUCCESS;
}
/***********************************************************************************************************************
 * Function Name: decode_idd_record_access_control_point
 * Description  : This function converts IDD Record Access Control Point characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the IDD Record Access Control Point value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_idd_record_access_control_point(st_ble_idc_idd_record_access_control_point_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    /*byte sequence to app data. */
    uint32_t pos = 0;

    /*check p_gatt_value->value_len has sufficient length*/
    if ((BLE_IDC_IDD_RECORD_ACCESS_CONTROL_POINT_LEN < p_gatt_value->value_len) || (0 == p_gatt_value->value_len))
    {
        return BLE_ERR_INVALID_DATA;
    }

    memset((uint8_t*)p_app_value, 0x00, sizeof(*p_app_value));

    BT_UNPACK_LE_1_BYTE(&p_app_value->racp_op_code, &p_gatt_value->p_value[pos]);
    pos += 1;

    BT_UNPACK_LE_1_BYTE(&p_app_value->racp_operator, &p_gatt_value->p_value[pos]);
    pos += 1;

    p_app_value->operand_length = (uint8_t)(p_gatt_value->value_len - 5);

    for (uint8_t i = 0; i < p_app_value->operand_length; i++)
    {
        BT_UNPACK_LE_1_BYTE(&p_app_value->racp_operand[i],&p_gatt_value->p_value[pos]);
        pos += 1;
    }

    BT_UNPACK_LE_1_BYTE(&p_app_value->e2e_counter, &p_gatt_value->p_value[pos]);
    pos += 1;
    BT_UNPACK_LE_2_BYTE(&p_app_value->e2e_crc, &p_gatt_value->p_value[pos]);
    pos += 2;

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: decode_idd_history_data
 * Description  : This function converts IDD History Data characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the IDD History Data value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_idd_history_data(st_ble_idc_idd_history_data_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    /* app data to byte sequence. */
    uint32_t pos = 0;

    /*check p_gatt_value->value_len has sufficient length*/
    if ((BLE_IDC_IDD_HISTORY_DATA_LEN < p_gatt_value->value_len) || (0 == p_gatt_value->value_len))
    {
        return BLE_ERR_INVALID_DATA;
    }

    memset((uint8_t*)p_app_value, 0x00, sizeof(*p_app_value));

    BT_UNPACK_LE_2_BYTE(&p_app_value->event_type,&p_gatt_value->p_value[pos]);
    pos += 2;
    BT_UNPACK_LE_4_BYTE(&p_app_value->seq_num, &p_gatt_value->p_value[pos]);
    pos += 4;
    BT_UNPACK_LE_2_BYTE(&p_app_value->relative_offset, &p_gatt_value->p_value[pos]);
    pos += 2;
    switch (p_app_value->event_type)
    {
        case BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_REFERENCE_TIME:
        {
            BT_UNPACK_LE_1_BYTE(&p_app_value->ref_time.recording_reason, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_2_BYTE(&p_app_value->ref_time.date_time.year, &p_gatt_value->p_value[pos]);
            pos += 2;
            BT_UNPACK_LE_1_BYTE(&p_app_value->ref_time.date_time.month, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->ref_time.date_time.day, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->ref_time.date_time.hours, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->ref_time.date_time.minutes, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->ref_time.date_time.seconds, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->ref_time.time_zone, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->ref_time.dst_offset, &p_gatt_value->p_value[pos]);
            pos += 1;
        }
        break;

        case BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_REFERENCE_TIME_BASE_OFFSET:
        {
            BT_UNPACK_LE_1_BYTE(&p_app_value->ref_time_baseoffset.recording_reason, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_2_BYTE(&p_app_value->ref_time_baseoffset.date_time.year, &p_gatt_value->p_value[pos]);
            pos += 2;
            BT_UNPACK_LE_1_BYTE(&p_app_value->ref_time_baseoffset.date_time.month, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->ref_time_baseoffset.date_time.day, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->ref_time_baseoffset.date_time.hours,&p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->ref_time_baseoffset.date_time.minutes, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->ref_time_baseoffset.date_time.seconds, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_2_BYTE(&p_app_value->ref_time_baseoffset.time_zone, &p_gatt_value->p_value[pos]);
            pos += 2;
        }
        break;

        case BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_BOLUS_CALCULATED_PART_1_OF_2:
        {
            BT_UNPACK_LE_2_BYTE(&p_app_value->bolus_calculated_part_1_of_2.fast_amount_meal.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->bolus_calculated_part_1_of_2.fast_amount_meal.exponent = 
                (int8_t)(((int16_t)p_app_value->bolus_calculated_part_1_of_2.fast_amount_meal.mantissa) >> 12);
            p_app_value->bolus_calculated_part_1_of_2.fast_amount_meal.mantissa = 
                (int16_t)(p_app_value->bolus_calculated_part_1_of_2.fast_amount_meal.mantissa & 0x0FFF);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->bolus_calculated_part_1_of_2.fast_amount_correction.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->bolus_calculated_part_1_of_2.fast_amount_correction.exponent = 
                (int8_t)(((int16_t)p_app_value->bolus_calculated_part_1_of_2.fast_amount_correction.mantissa) >> 12);
            p_app_value->bolus_calculated_part_1_of_2.fast_amount_correction.mantissa = (int16_t)(p_app_value->bolus_calculated_part_1_of_2.fast_amount_correction.mantissa & 0x0FFF);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->bolus_calculated_part_1_of_2.extended_amount_meal.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->bolus_calculated_part_1_of_2.extended_amount_meal.exponent = 
                (int8_t)(((int16_t)p_app_value->bolus_calculated_part_1_of_2.extended_amount_meal.mantissa) >> 12);
            p_app_value->bolus_calculated_part_1_of_2.extended_amount_meal.mantissa = 
                (int16_t)(p_app_value->bolus_calculated_part_1_of_2.extended_amount_meal.mantissa & 0x0FFF);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->bolus_calculated_part_1_of_2.extended_amount_correction.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->bolus_calculated_part_1_of_2.extended_amount_correction.exponent = 
                (int8_t)(((int16_t)p_app_value->bolus_calculated_part_1_of_2.extended_amount_correction.mantissa) >> 12);
            p_app_value->bolus_calculated_part_1_of_2.extended_amount_correction.mantissa = 
                (int16_t)(p_app_value->bolus_calculated_part_1_of_2.extended_amount_correction.mantissa & 0x0FFF);
            pos += 2;
        }
        break;

        case BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_BOLUS_CALCULATED_PART_2_OF_2:
        {
            BT_UNPACK_LE_2_BYTE(&p_app_value->bolus_calculated_part_2_of_2.fast_amount_meal.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->bolus_calculated_part_2_of_2.fast_amount_meal.exponent = 
                (int8_t)(((int16_t)p_app_value->bolus_calculated_part_2_of_2.fast_amount_meal.mantissa) >> 12);
            p_app_value->bolus_calculated_part_2_of_2.fast_amount_meal.mantissa = 
                (int16_t)(p_app_value->bolus_calculated_part_2_of_2.fast_amount_meal.mantissa & 0x0FFF);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->bolus_calculated_part_2_of_2.fast_amount_correction.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->bolus_calculated_part_2_of_2.fast_amount_correction.exponent = 
                (int8_t)(((int16_t)p_app_value->bolus_calculated_part_2_of_2.fast_amount_correction.mantissa) >> 12);
            p_app_value->bolus_calculated_part_2_of_2.fast_amount_correction.mantissa = 
                (int16_t)(p_app_value->bolus_calculated_part_2_of_2.fast_amount_correction.mantissa & 0x0FFF);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->bolus_calculated_part_2_of_2.extended_amount_meal.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->bolus_calculated_part_2_of_2.extended_amount_meal.exponent = 
                (int8_t)(((int16_t)p_app_value->bolus_calculated_part_2_of_2.extended_amount_meal.mantissa) >> 12);
            p_app_value->bolus_calculated_part_2_of_2.extended_amount_meal.mantissa = 
                (int16_t)(p_app_value->bolus_calculated_part_2_of_2.extended_amount_meal.mantissa & 0x0FFF);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->bolus_calculated_part_2_of_2.extended_amount_correction.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->bolus_calculated_part_2_of_2.extended_amount_correction.exponent = 
                (int8_t)(((int16_t)p_app_value->bolus_calculated_part_2_of_2.extended_amount_correction.mantissa) >> 12);
            p_app_value->bolus_calculated_part_2_of_2.extended_amount_correction.mantissa = 
                (int16_t)(p_app_value->bolus_calculated_part_2_of_2.extended_amount_correction.mantissa & 0x0FFF);
            pos += 2;
        }
        break;

        case BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_BOLUS_PROGRAMMED_PART_1_OF_2:
        {
            BT_UNPACK_LE_2_BYTE(&p_app_value->bolus_programmed_part_1_of_2.bolus_id, &p_gatt_value->p_value[pos]);
            pos += 2;
            BT_UNPACK_LE_1_BYTE(&p_app_value->bolus_programmed_part_1_of_2.bolus_type, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_2_BYTE(&p_app_value->bolus_programmed_part_1_of_2.programmed_bolus_fast_amount.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->bolus_programmed_part_1_of_2.programmed_bolus_fast_amount.exponent = 
                (int8_t)(((int16_t)p_app_value->bolus_programmed_part_1_of_2.programmed_bolus_fast_amount.mantissa) >> 12);
            p_app_value->bolus_programmed_part_1_of_2.programmed_bolus_fast_amount.mantissa = 
                (int16_t)(p_app_value->bolus_programmed_part_1_of_2.programmed_bolus_fast_amount.mantissa & 0x0FFF);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->bolus_programmed_part_1_of_2.programmed_bolus_extended_amount.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->bolus_programmed_part_1_of_2.programmed_bolus_extended_amount.exponent = 
                (int8_t)(((int16_t)p_app_value->bolus_programmed_part_1_of_2.programmed_bolus_extended_amount.mantissa) >> 12);
            p_app_value->bolus_programmed_part_1_of_2.programmed_bolus_extended_amount.mantissa = 
                (int16_t)(p_app_value->bolus_programmed_part_1_of_2.programmed_bolus_extended_amount.mantissa & 0x0FFF);
            pos += 2;
            BT_UNPACK_LE_2_BYTE( &p_app_value->bolus_programmed_part_1_of_2.programmed_bolus_duration, &p_gatt_value->p_value[pos]);
            pos += 2;
        }
        break;

        case BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_BOLUS_PROGRAMMED_PART_2_OF_2:
        {
            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_BOLUS_DELAY_TIME_PRESENT)
            {
                p_app_value->bolus_programmed_part_2_of_2.is_bolus_delay_time_present = true;
            }
            else
            {
                p_app_value->bolus_programmed_part_2_of_2.is_bolus_delay_time_present = false;
            }
            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_BOLUS_TEMPLATE_NUMBER_PRESENT)
            {
                p_app_value->bolus_programmed_part_2_of_2.is_bolus_template_number_present = true;
            }
            else
            {
                p_app_value->bolus_programmed_part_2_of_2.is_bolus_template_number_present = false;
            }

            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_BOLUS_ACTIVATION_TYPE_PRESENT)
            {
                p_app_value->bolus_programmed_part_2_of_2.is_bolus_activation_type_present = true;
            }
            else
            {
                p_app_value->bolus_programmed_part_2_of_2.is_bolus_activation_type_present = false;
            }

            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_BOLUS_DELIVERY_REASON_CORRECTION)
            {
                p_app_value->bolus_programmed_part_2_of_2.is_bolus_delivery_reason_correction = true;
            }
            else
            {
                p_app_value->bolus_programmed_part_2_of_2.is_bolus_delivery_reason_correction = false;
            }

            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_BOLUS_DELIVERY_REASON_MEAL)
            {
                p_app_value->bolus_programmed_part_2_of_2.is_bolus_delivery_reason_meal = true;
            }
            else
            {
                p_app_value->bolus_programmed_part_2_of_2.is_bolus_delivery_reason_meal = false;
            }

            pos += 1;
            BT_UNPACK_LE_2_BYTE(&p_app_value->bolus_programmed_part_2_of_2.bolus_delay_time, &p_gatt_value->p_value[pos]);
            pos += 2;
            BT_UNPACK_LE_1_BYTE(&p_app_value->bolus_programmed_part_2_of_2.bolus_template_num, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->bolus_programmed_part_2_of_2.bolus_activation_type, &p_gatt_value->p_value[pos]);
            pos += 1;
        }
        break;

        case BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_BOLUS_DELIVERED_PART_1_OF_2:
        {
            BT_UNPACK_LE_2_BYTE(&p_app_value->bolus_delivered_part_1_of_2.bolus_id,&p_gatt_value->p_value[pos]);
            pos += 2;
            BT_UNPACK_LE_1_BYTE(&p_app_value->bolus_delivered_part_1_of_2.bolus_type, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_2_BYTE(&p_app_value->bolus_delivered_part_1_of_2.delivered_bolus_fast_amount.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->bolus_delivered_part_1_of_2.delivered_bolus_fast_amount.exponent = (int8_t)(((int16_t)p_app_value->bolus_delivered_part_1_of_2.delivered_bolus_fast_amount.mantissa) >> 12);
            p_app_value->bolus_delivered_part_1_of_2.delivered_bolus_fast_amount.mantissa = (int16_t)(p_app_value->bolus_delivered_part_1_of_2.delivered_bolus_fast_amount.mantissa & 0x0FFF);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->bolus_delivered_part_1_of_2.delivered_bolus_extended_amount.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->bolus_delivered_part_1_of_2.delivered_bolus_extended_amount.exponent = (int8_t)(((int16_t)p_app_value->bolus_delivered_part_1_of_2.delivered_bolus_extended_amount.mantissa) >> 12);
            p_app_value->bolus_delivered_part_1_of_2.delivered_bolus_extended_amount.mantissa = (int16_t)(p_app_value->bolus_delivered_part_1_of_2.delivered_bolus_extended_amount.mantissa & 0x0FFF);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->bolus_delivered_part_1_of_2.effective_bolus_duration, &p_gatt_value->p_value[pos]);
            pos += 2;
        }
        break;

        case BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_BOLUS_DELIVERED_PART_2_OF_2:
        {
            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_HISTORY_DATA_BOLUS_DELIVERED_BOLUS_ACTIVATION_TYPE_PRESENT)
            {
                p_app_value->bolus_delivered_part_2_of_2.is_bolus_activation_type_present = true;
            }
            else
            {
                p_app_value->bolus_delivered_part_2_of_2.is_bolus_activation_type_present = false;
            }

            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_HISTORY_DATA_BOLUS_DELIVERED_BOLUS_END_REASON_PRESENT)
            {
                p_app_value->bolus_delivered_part_2_of_2.is_bolus_end_reason_present = true;
            }
            else
            {
                p_app_value->bolus_delivered_part_2_of_2.is_bolus_end_reason_present = false;
            }

            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_HISTORY_DATA_BOLUS_DELIVERED_ANNUNCIATION_INSTANCE_ID_PRESENT)
            {
                p_app_value->bolus_delivered_part_2_of_2.is_annunciation_instance_id_present = true;
            }
            else
            {
                p_app_value->bolus_delivered_part_2_of_2.is_annunciation_instance_id_present = false;
            }

            pos += 1;
            BT_UNPACK_LE_4_BYTE(&p_app_value->bolus_delivered_part_2_of_2.bolus_start_time_offset, &p_gatt_value->p_value[pos]);
            pos += 4;
            BT_UNPACK_LE_1_BYTE(&p_app_value->bolus_delivered_part_2_of_2.bolus_activation_type, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->bolus_delivered_part_2_of_2.bolus_end_reason, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_2_BYTE(&p_app_value->bolus_delivered_part_2_of_2.annunciation_instance_id, &p_gatt_value->p_value[pos]);
            pos += 2;
        }
        break;

        case BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_DELIVERED_BASAL_RATE_CHANGED:
        {
            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_HISTORY_DATA_TBR_TEMPLATE_NUMBER_PRESENT)
            {
                p_app_value->delivered_basal_rate_changed.is_basal_delivery_context_present = true;
            }
            else
            {
                p_app_value->delivered_basal_rate_changed.is_basal_delivery_context_present = false;
            }

            pos += 1;
            BT_UNPACK_LE_2_BYTE(&p_app_value->delivered_basal_rate_changed.old_basel_rate_val.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->delivered_basal_rate_changed.old_basel_rate_val.exponent = 
                (int8_t)(((int16_t)p_app_value->delivered_basal_rate_changed.old_basel_rate_val.mantissa) >> 12);
            p_app_value->delivered_basal_rate_changed.old_basel_rate_val.mantissa = 
                (int16_t)(p_app_value->delivered_basal_rate_changed.old_basel_rate_val.mantissa & 0x0FFF);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->delivered_basal_rate_changed.new_basel_rate_val.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->delivered_basal_rate_changed.new_basel_rate_val.exponent = 
                (int8_t)(((int16_t)p_app_value->delivered_basal_rate_changed.new_basel_rate_val.mantissa) >> 12);
            p_app_value->delivered_basal_rate_changed.new_basel_rate_val.mantissa = 
                (int16_t)(p_app_value->delivered_basal_rate_changed.new_basel_rate_val.mantissa & 0x0FFF);
            pos += 2;
            BT_UNPACK_LE_1_BYTE(&p_app_value->delivered_basal_rate_changed.basal_delivery_context, &p_gatt_value->p_value[pos]);
            pos += 1;
        }
        break;

        case BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_TBR_ADJUSTMENT_STARTED:
        {
            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_HISTORY_DATA_BASAL_DELIVERY_CONTEXT_PRESENT)
            {
                p_app_value->tbr_adjustment_started.is_tbr_template_number_present = true;
            }
            else
            {
                p_app_value->tbr_adjustment_started.is_tbr_template_number_present = false;
            }

            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->tbr_adjustment_started.tbr_type, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_2_BYTE(&p_app_value->tbr_adjustment_started.tbr_adjustment_value.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->tbr_adjustment_started.tbr_adjustment_value.exponent = 
                (int8_t)(((int16_t)p_app_value->tbr_adjustment_started.tbr_adjustment_value.mantissa) >> 12);
            p_app_value->tbr_adjustment_started.tbr_adjustment_value.mantissa = 
                (int16_t)(p_app_value->tbr_adjustment_started.tbr_adjustment_value.mantissa & 0x0FFF);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->tbr_adjustment_started.tbr_duration_programmed, &p_gatt_value->p_value[pos]);
            pos += 2;
            BT_UNPACK_LE_1_BYTE(&p_app_value->tbr_adjustment_started.tbr_template_num, &p_gatt_value->p_value[pos]);
            pos += 1;
        }
        break;

        case BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_TBR_ADJUSTMENT_ENDED:
        {
            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_HISTORY_DATA_LAST_SET_TBR_TEMPLATE_NUMBER_PRESENT)
            {
                p_app_value->tbr_adjustment_ended.is_last_set_tbr_template_number_present = true;
            }
            else
            {
                p_app_value->tbr_adjustment_ended.is_last_set_tbr_template_number_present = false;
            }

            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_HISTORY_DATA_ANNUNCIATION_INSTANCE_ID_PRESENT)
            {
                p_app_value->tbr_adjustment_ended.is_annunciation_instance_id_present = true;
            }
            else
            {
                p_app_value->tbr_adjustment_ended.is_annunciation_instance_id_present = false;
            }

            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->tbr_adjustment_ended.last_set_tbr_type, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_2_BYTE(&p_app_value->tbr_adjustment_ended.effective_tbr_duration, &p_gatt_value->p_value[pos]);
            pos += 2;
            BT_UNPACK_LE_1_BYTE(&p_app_value->tbr_adjustment_ended.tbr_end_reason, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->tbr_adjustment_ended.last_set_tbr_template_num, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_2_BYTE(&p_app_value->tbr_adjustment_ended.annunciation_instance_id, &p_gatt_value->p_value[pos]);
            pos += 2;
        }
        break;

        case BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_TBR_ADJUSTMENT_CHANGED:
        {
            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_HISTORY_DATA_BASAL_DELIVERY_CONTEXT_PRESENT)
            {
                p_app_value->tbr_adjustment_changed.is_tbr_template_number_present = true;
            }
            else
            {
                p_app_value->tbr_adjustment_changed.is_tbr_template_number_present = false;
            }

            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->tbr_adjustment_changed.tbr_type, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_2_BYTE(&p_app_value->tbr_adjustment_changed.tbr_adjustment_value.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->tbr_adjustment_changed.tbr_adjustment_value.exponent = (int8_t)(((int16_t)p_app_value->tbr_adjustment_changed.tbr_adjustment_value.mantissa) >> 12);
            p_app_value->tbr_adjustment_changed.tbr_adjustment_value.mantissa = (int16_t)(p_app_value->tbr_adjustment_changed.tbr_adjustment_value.mantissa & 0x0FFF);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->tbr_adjustment_changed.tbr_duration_programmed, &p_gatt_value->p_value[pos]);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->tbr_adjustment_changed.elapsed_tbr_duration, &p_gatt_value->p_value[pos]);
            pos += 2;
            BT_UNPACK_LE_1_BYTE(&p_app_value->tbr_adjustment_changed.tbr_template_num, &p_gatt_value->p_value[pos]);
            pos += 1;
        }
        break;

        case BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_PROFILE_TEMPLATE_ACTIVATED:
        {
            BT_UNPACK_LE_1_BYTE(&p_app_value->pro_template_activated.prof_template_type, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->pro_template_activated.old_prof_template_num, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->pro_template_activated.new_prof_template_num, &p_gatt_value->p_value[pos]);
            pos += 1;
        }
        break;

        case BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_BASAL_RATE_PROFILE_TEMPLATE_TIME_BLOCK_CHANGED:
        {
            BT_UNPACK_LE_1_BYTE(&p_app_value->brpt_time_block_changed.brpt_Number, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->brpt_time_block_changed.time_block_number, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_PACK_LE_2_BYTE(&p_app_value->brpt_time_block_changed.duration, &p_gatt_value->p_value[pos]);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->brpt_time_block_changed.rate.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->brpt_time_block_changed.rate.exponent = 
                (int8_t)(((int16_t)p_app_value->brpt_time_block_changed.rate.mantissa) >> 12);
            p_app_value->brpt_time_block_changed.rate.mantissa = 
                (int16_t)(p_app_value->brpt_time_block_changed.rate.mantissa & 0x0FFF);
            pos += 2;
        }
        break;

        case BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_TOTAL_DAILY_INSULIN_DELIVERY:
        {
            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_HISTORY_DATA_DATE_TIME_CHANGED_WARNING)
            {
                p_app_value->total_daily_insulin_delivery.is_date_time_changed_warning = true;
            }
            else
            {
                p_app_value->total_daily_insulin_delivery.is_date_time_changed_warning = false;
            }

            pos += 1;
            BT_UNPACK_LE_2_BYTE(&p_app_value->total_daily_insulin_delivery.total_daily_insulin_sum_of_bolus_delivered.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->total_daily_insulin_delivery.total_daily_insulin_sum_of_bolus_delivered.exponent = (int8_t)(((int16_t)p_app_value->total_daily_insulin_delivery.total_daily_insulin_sum_of_bolus_delivered.mantissa) >> 12);
            p_app_value->total_daily_insulin_delivery.total_daily_insulin_sum_of_bolus_delivered.mantissa = (int16_t)(p_app_value->total_daily_insulin_delivery.total_daily_insulin_sum_of_bolus_delivered.mantissa & 0x0FFF);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->total_daily_insulin_delivery.total_daily_insulin_sum_of_basel_delivered.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->total_daily_insulin_delivery.total_daily_insulin_sum_of_basel_delivered.exponent = (int8_t)(((int16_t)p_app_value->total_daily_insulin_delivery.total_daily_insulin_sum_of_basel_delivered.mantissa) >> 12);
            p_app_value->total_daily_insulin_delivery.total_daily_insulin_sum_of_basel_delivered.mantissa = (int16_t)(p_app_value->total_daily_insulin_delivery.total_daily_insulin_sum_of_basel_delivered.mantissa & 0x0FFF);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->total_daily_insulin_delivery.year, &p_gatt_value->p_value[pos]);
            pos += 2;
            BT_UNPACK_LE_1_BYTE(&p_app_value->total_daily_insulin_delivery.month, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->total_daily_insulin_delivery.day, &p_gatt_value->p_value[pos]);
            pos += 1;
        }
        break;

        case BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_THERAPY_CONTROL_STATE_CHANGED:
        {
            BT_UNPACK_LE_1_BYTE(&p_app_value->therapy_control_state.old_therapy_control_state, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->therapy_control_state.new_therapy_control_state, &p_gatt_value->p_value[pos]);
            pos += 1;
        }
        break;

        case BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_OPERATIONAL_STATE_CHANGED:
        {
            BT_UNPACK_LE_1_BYTE(&p_app_value->operational_state_changed.old_operational_state, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_PACK_LE_1_BYTE(&p_app_value->operational_state_changed.new_operational_state, &p_gatt_value->p_value[pos]);
            pos += 1;
        }
        break;

        case BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_RESERVOIR_REMAINING_AMOUNT_CHANGED:
        {
            BT_UNPACK_LE_2_BYTE(&p_app_value->reservoir_remaining_amount.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->reservoir_remaining_amount.exponent = (int8_t)(((int16_t)p_app_value->reservoir_remaining_amount.mantissa) >> 12);
            p_app_value->reservoir_remaining_amount.mantissa = (int16_t)(p_app_value->reservoir_remaining_amount.mantissa & 0x0FFF);
            pos += 2;
        }
        break;

        case BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_ANNUNCIATION_STATUS_CHANGED_PART_1_OF_2:
        {
            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_HISTORY_DATA_AUXINFO1_PRESENT)
            {
                p_app_value->annunciation_status_changed_part_1_of_2.is_auxinfo1_present = true;
            }
            else
            {
                p_app_value->annunciation_status_changed_part_1_of_2.is_auxinfo1_present = false;
            }

            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_HISTORY_DATA_AUXINFO2_PRESENT)
            {
                p_app_value->annunciation_status_changed_part_1_of_2.is_auxinfo2_present = true;
            }
            else
            {
                p_app_value->annunciation_status_changed_part_1_of_2.is_auxinfo2_present = false;
            }

            pos += 1;
            BT_UNPACK_LE_2_BYTE(&p_app_value->annunciation_status_changed_part_1_of_2.annunciation_instance_id, &p_gatt_value->p_value[pos]);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->annunciation_status_changed_part_1_of_2.annunciation_type, &p_gatt_value->p_value[pos]);
            pos += 2;
            BT_UNPACK_LE_1_BYTE(&p_app_value->annunciation_status_changed_part_1_of_2.annunciation_status, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_2_BYTE(&p_app_value->annunciation_status_changed_part_1_of_2.auxInfo1, &p_gatt_value->p_value[pos]);
            pos += 2;
            BT_UNPACK_LE_2_BYTE( &p_app_value->annunciation_status_changed_part_1_of_2.auxInfo2, &p_gatt_value->p_value[pos]);
            pos += 2;
        }
        break;

        case BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_ANNUNCIATION_STATUS_CHANGED_PART_2_OF_2:
        {
            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_HISTORY_DATA_AUXINFO3_PRESENT)
            {
                p_app_value->annunciation_status_changed_part_2_of_2.is_auxinfo3_present = true;
            }
            else
            {
                p_app_value->annunciation_status_changed_part_2_of_2.is_auxinfo3_present = false;
            }

            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_HISTORY_DATA_AUXINFO4_PRESENT)
            {
                p_app_value->annunciation_status_changed_part_2_of_2.is_auxinfo4_present = true;
            }
            else
            {
                p_app_value->annunciation_status_changed_part_2_of_2.is_auxinfo4_present = false;
            }

            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_HISTORY_DATA_AUXINFO5_PRESENT)
            {
                p_app_value->annunciation_status_changed_part_2_of_2.is_auxinfo5_present = true;
            }
            else
            {
                p_app_value->annunciation_status_changed_part_2_of_2.is_auxinfo5_present = false;
            }

            pos += 1;
            BT_UNPACK_LE_2_BYTE(&p_app_value->annunciation_status_changed_part_2_of_2.auxinfo3, &p_gatt_value->p_value[pos]);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->annunciation_status_changed_part_2_of_2.auxinfo4, &p_gatt_value->p_value[pos]);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->annunciation_status_changed_part_2_of_2.auxinfo5, &p_gatt_value->p_value[pos]);
            pos += 2;
        }
        break;

        case BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_ISF_PROFILE_TEMPLATE_TIME_BLOCK_CHANGED:
        {
            BT_UNPACK_LE_1_BYTE(&p_app_value->isfpt_time_block_changed.isf_profile_template_number, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->isfpt_time_block_changed.time_block_number, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_2_BYTE(&p_app_value->isfpt_time_block_changed.duration, &p_gatt_value->p_value[pos]);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->isfpt_time_block_changed.isf.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->isfpt_time_block_changed.isf.exponent = (int8_t)(((int16_t)p_app_value->isfpt_time_block_changed.isf.mantissa) >> 12);
            p_app_value->isfpt_time_block_changed.isf.mantissa = (int16_t)(p_app_value->isfpt_time_block_changed.isf.mantissa & 0x0FFF);
            pos += 2;
        }
        break;

        case BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_I2CHO_RATIO_PROFILE_TEMPLATE_TIME_BLOCK_CHANGED:
        {
            BT_UNPACK_LE_1_BYTE(&p_app_value->i2chorpt_time_block_changed.i2cho_ratio_profile_template_number, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->i2chorpt_time_block_changed.time_block_number, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_2_BYTE(&p_app_value->i2chorpt_time_block_changed.duration, &p_gatt_value->p_value[pos]);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->i2chorpt_time_block_changed.i2cho_ratio.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->i2chorpt_time_block_changed.i2cho_ratio.exponent = 
                (int8_t)(((int16_t)p_app_value->i2chorpt_time_block_changed.i2cho_ratio.mantissa) >> 12);
            p_app_value->i2chorpt_time_block_changed.i2cho_ratio.mantissa = 
                (int16_t)(p_app_value->i2chorpt_time_block_changed.i2cho_ratio.mantissa & 0x0FFF);
            pos += 2;
        }
        break;

        case BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_TARGET_GLUCOSE_RANGE_PROFILE_TEMPLATE_TIME_BLOCK_CHANGED:
        {
            BT_UNPACK_LE_1_BYTE(&p_app_value->tgrpt_time_block_changed.tgr_profile_template_number, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->tgrpt_time_block_changed.time_block_number, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_2_BYTE(&p_app_value->tgrpt_time_block_changed.duration, &p_gatt_value->p_value[pos]);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->tgrpt_time_block_changed.lower_target_glucose_limit.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->tgrpt_time_block_changed.lower_target_glucose_limit.exponent = 
                (int8_t)(((int16_t)p_app_value->tgrpt_time_block_changed.lower_target_glucose_limit.mantissa) >> 12);
            p_app_value->tgrpt_time_block_changed.lower_target_glucose_limit.mantissa = 
                (int16_t)(p_app_value->tgrpt_time_block_changed.lower_target_glucose_limit.mantissa & 0x0FFF);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->tgrpt_time_block_changed.upper_Target_Glucose_Limit.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->tgrpt_time_block_changed.upper_Target_Glucose_Limit.exponent = 
                (int8_t)(((int16_t)p_app_value->tgrpt_time_block_changed.upper_Target_Glucose_Limit.mantissa) >> 12);
            p_app_value->tgrpt_time_block_changed.upper_Target_Glucose_Limit.mantissa = 
                (int16_t)(p_app_value->tgrpt_time_block_changed.upper_Target_Glucose_Limit.mantissa & 0x0FFF);
            pos += 2;
        }
        break;

        case BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_PRIMING_STARTED:
        {
            BT_UNPACK_LE_2_BYTE(&p_app_value->priming_started.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->priming_started.exponent = (int8_t)(((int16_t)p_app_value->priming_started.mantissa) >> 12);
            p_app_value->priming_started.mantissa = (int16_t)(p_app_value->priming_started.mantissa & 0x0FFF);
            pos += 2;
        }
        break;

        case BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_PRIMING_DONE:
        {
            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_HISTORY_DATA_PRIMING_DONE_ANNUNCIATION_INSTANCE_ID_PRESENT)
            {
                p_app_value->priming_done.is_annunciation_instance_id_present = true;
            }
            else
            {
                p_app_value->priming_done.is_annunciation_instance_id_present = false;
            }

            pos += 1;
            BT_UNPACK_LE_2_BYTE(&p_app_value->priming_done.delivered_amount.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->priming_done.delivered_amount.exponent = 
                (int8_t)(((int16_t)p_app_value->priming_done.delivered_amount.mantissa) >> 12);
            p_app_value->priming_done.delivered_amount.mantissa = 
                (int16_t)(p_app_value->priming_done.delivered_amount.mantissa & 0x0FFF);
            pos += 2;
            BT_UNPACK_LE_1_BYTE(&p_app_value->priming_done.reason_of_termination,&p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_2_BYTE(&p_app_value->priming_done.annunciation_instance_id, &p_gatt_value->p_value[pos]);
            pos += 2;
        }
        break;

        case BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_BOLUS_TEMPLATE_CHANGED_PART_1_OF_2:
        {
            BT_UNPACK_LE_2_BYTE(&p_app_value->bolus_template_changed_part_1_of_2.bolus_Template_Num, &p_gatt_value->p_value[pos]);
            pos += 2;
            BT_UNPACK_LE_1_BYTE(&p_app_value->bolus_template_changed_part_1_of_2.bolus_type, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_2_BYTE(&p_app_value->bolus_template_changed_part_1_of_2.bolus_fast_amount.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->bolus_template_changed_part_1_of_2.bolus_fast_amount.exponent = 
                (int8_t)(((int16_t)p_app_value->bolus_template_changed_part_1_of_2.bolus_fast_amount.mantissa) >> 12);
            p_app_value->bolus_template_changed_part_1_of_2.bolus_fast_amount.mantissa = 
                (int16_t)(p_app_value->bolus_template_changed_part_1_of_2.bolus_fast_amount.mantissa & 0x0FFF);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->bolus_template_changed_part_1_of_2.bolus_extended_amount.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->bolus_template_changed_part_1_of_2.bolus_extended_amount.exponent = 
                (int8_t)(((int16_t)p_app_value->bolus_template_changed_part_1_of_2.bolus_extended_amount.mantissa) >> 12);
            p_app_value->bolus_template_changed_part_1_of_2.bolus_extended_amount.mantissa = 
                (int16_t)(p_app_value->bolus_template_changed_part_1_of_2.bolus_extended_amount.mantissa & 0x0FFF);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->bolus_template_changed_part_1_of_2.bolus_duration, &p_gatt_value->p_value[pos]);
            pos += 2;
        }
        break;

        case BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_BOLUS_TEMPLATE_CHANGED_PART_2_OF_2:
        {
            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_GET_BOLUS_TEMPLATE_DELAY_TIME_PRESENT)
            {
                p_app_value->bolus_template_changed_part_2_of_2.is_bolus_delay_time_present = true;
            }
            else
            {
                p_app_value->bolus_template_changed_part_2_of_2.is_bolus_delay_time_present = false;
            }

            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_GET_BOLUS_TEMPLATE_DELIVERY_REASON_CORRECTION)
            {
                p_app_value->bolus_template_changed_part_2_of_2.is_bolus_delivery_reason_correction = true;
            }
            else
            {
                p_app_value->bolus_template_changed_part_2_of_2.is_bolus_delivery_reason_correction = false;
            }

            if (p_gatt_value->p_value[pos] & BLE_IDC_PRV_IDD_GET_BOLUS_TEMPLATE_DELIVERY_REASON_MEAL)
            {
                p_app_value->bolus_template_changed_part_2_of_2.is_bolus_delivery_reason_meal = true;
            }
            else
            {
                p_app_value->bolus_template_changed_part_2_of_2.is_bolus_delivery_reason_meal = false;
            }

            pos += 1;
            BT_UNPACK_LE_2_BYTE(&p_app_value->bolus_template_changed_part_2_of_2.bolus_delay_time, &p_gatt_value->p_value[pos]);
            pos += 2;
        }
        break;

        case BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_TBR_TEMPLATE_CHANGED:
        {
            BT_UNPACK_LE_1_BYTE(&p_app_value->tbr_template_changed.tbr_template_number, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_1_BYTE(&p_app_value->tbr_template_changed.tbr_type, &p_gatt_value->p_value[pos]);
            pos += 1;
            BT_UNPACK_LE_2_BYTE(&p_app_value->tbr_template_changed.tbr_adjustment_value.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->tbr_template_changed.tbr_adjustment_value.exponent = (int8_t)(((int16_t)p_app_value->tbr_template_changed.tbr_adjustment_value.mantissa) >> 12);
            p_app_value->tbr_template_changed.tbr_adjustment_value.mantissa = (int16_t)(p_app_value->tbr_template_changed.tbr_adjustment_value.mantissa & 0x0FFF);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->tbr_template_changed.tbr_duration, &p_gatt_value->p_value[pos]);
            pos += 2;
        }
        break;

        case BLE_IDC_IDD_HISTORY_DATA_EVENT_TYPE_MAX_BOLUS_AMOUNT_CHANGED:
        {
            BT_UNPACK_LE_2_BYTE(&p_app_value->max_bolus_amount_changed.old_max_bolus_amount.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->max_bolus_amount_changed.old_max_bolus_amount.exponent = 
                (int8_t)(((int16_t)p_app_value->max_bolus_amount_changed.old_max_bolus_amount.mantissa) >> 12);
            p_app_value->max_bolus_amount_changed.old_max_bolus_amount.mantissa = 
                (int16_t)(p_app_value->max_bolus_amount_changed.old_max_bolus_amount.mantissa & 0x0FFF);
            pos += 2;
            BT_UNPACK_LE_2_BYTE(&p_app_value->max_bolus_amount_changed.new_max_bolus_amount.mantissa, &p_gatt_value->p_value[pos]);
            p_app_value->max_bolus_amount_changed.new_max_bolus_amount.exponent = 
                (int8_t)(((int16_t)p_app_value->max_bolus_amount_changed.new_max_bolus_amount.mantissa) >> 12);
            p_app_value->max_bolus_amount_changed.new_max_bolus_amount.mantissa = 
                (int16_t)(p_app_value->max_bolus_amount_changed.new_max_bolus_amount.mantissa & 0x0FFF);
            pos += 2;
        }
        break;

        default:
        {
            /*Do nothing*/
        }
        break;
    }
    BT_UNPACK_LE_2_BYTE(&p_app_value->e2e_crc, &p_gatt_value->p_value[pos]);

    return BLE_SUCCESS;
}


/***********************************************************************************************************************
 * Function Name: idc_gattc_cb
 * Description  : Callback function for the Insulin Delivery GATTC events.
 * Arguments    : conn_hdl - handle to the connection
 *                result - ble status
 *              : p_data - pointer to GATTC event data
 * Return Value : none
***********************************************************************************************************************/
static void idc_gattc_cb(uint16_t type, ble_status_t result, st_ble_gattc_evt_data_t *p_data) // @suppress("Function length")
{
    st_idc_peer_param_t *p_peer = find_peer_param(p_data->conn_hdl);

    switch (type)
    {
        case BLE_GATTC_EVENT_CHAR_READ_RSP:
        {
            st_ble_gattc_rd_char_evt_t *p_rd_char_evt_param =
                (st_ble_gattc_rd_char_evt_t *)p_data->p_param;

            if (p_rd_char_evt_param->read_data.attr_hdl == p_peer->hdls.idd_status_changed_char_val_hdl)
            {
                ble_status_t ret;
                st_ble_idc_idd_status_changed_t app_value;
                ret = decode_idd_status_changed(&app_value, &p_rd_char_evt_param->read_data.value);

                st_ble_idc_evt_data_t evt_data = 
                {
                    .conn_hdl  = p_data->conn_hdl,
                    .param_len = sizeof(app_value),
                    .p_param   = &app_value,
                };
                gs_idc_cb(BLE_IDC_EVENT_IDD_STATUS_CHANGED_READ_RSP, ret, &evt_data);
            }
            else if (p_rd_char_evt_param->read_data.attr_hdl == p_peer->hdls.idd_status_char_val_hdl)
            {
                ble_status_t ret;
                st_ble_idc_idd_status_t app_value;
                ret = decode_idd_status(&app_value, &p_rd_char_evt_param->read_data.value);

                st_ble_idc_evt_data_t evt_data = {
                    .conn_hdl  = p_data->conn_hdl,
                    .param_len = sizeof(app_value),
                    .p_param   = &app_value,
                };
                gs_idc_cb(BLE_IDC_EVENT_IDD_STATUS_READ_RSP, ret, &evt_data);
            }
            else if (p_rd_char_evt_param->read_data.attr_hdl == p_peer->hdls.idd_annunciation_status_char_val_hdl)
            {
                ble_status_t ret;
                st_ble_idc_idd_annunciation_status_t app_value;
                ret = decode_idd_annunciation_status(&app_value, &p_rd_char_evt_param->read_data.value);

                st_ble_idc_evt_data_t evt_data =
                {
                    .conn_hdl  = p_data->conn_hdl,
                    .param_len = sizeof(app_value),
                    .p_param   = &app_value,
                };
                gs_idc_cb(BLE_IDC_EVENT_IDD_ANNUNCIATION_STATUS_READ_RSP, ret, &evt_data);
            }
            else if (p_rd_char_evt_param->read_data.attr_hdl == p_peer->hdls.idd_features_char_val_hdl)
            {
                ble_status_t ret;
                st_ble_idc_idd_features_t app_value;
                ret = decode_idd_features(&app_value, &p_rd_char_evt_param->read_data.value);

                st_ble_idc_evt_data_t evt_data = 
                {
                    .conn_hdl  = p_data->conn_hdl,
                    .param_len = sizeof(app_value),
                    .p_param   = &app_value,
                };
                gs_idc_cb(BLE_IDC_EVENT_IDD_FEATURES_READ_RSP, ret, &evt_data);
            }
        } 
        break;

        case BLE_GATTC_EVENT_CHAR_WRITE_RSP:
        {
            st_ble_gattc_wr_char_evt_t *p_wr_char_evt_param =
                (st_ble_gattc_wr_char_evt_t *)p_data->p_param;

            st_ble_idc_evt_data_t evt_data =
            {
                .conn_hdl  = p_data->conn_hdl,
                .param_len = 0,
                .p_param   = NULL,
            };

            if (p_wr_char_evt_param->value_hdl == p_peer->hdls.idd_status_reader_control_point_char_val_hdl)
            {
                gs_idc_cb(BLE_IDC_EVENT_IDD_STATUS_READER_CONTROL_POINT_WRITE_RSP, result, &evt_data);
            }
            else if (p_wr_char_evt_param->value_hdl == p_peer->hdls.idd_command_control_point_char_val_hdl)
            {
                gs_idc_cb(BLE_IDC_EVENT_IDD_COMMAND_CONTROL_POINT_WRITE_RSP, result, &evt_data);
            }
            else if (p_wr_char_evt_param->value_hdl == p_peer->hdls.idd_record_access_control_point_char_val_hdl)
            {
                gs_idc_cb(BLE_IDC_EVENT_IDD_RECORD_ACCESS_CONTROL_POINT_WRITE_RSP, result, &evt_data);
            }
            else if ((p_wr_char_evt_param->value_hdl == p_peer->hdls.idd_status_changed_cli_cnfg_hdl) ||
                     (p_wr_char_evt_param->value_hdl == p_peer->hdls.idd_status_cli_cnfg_hdl) ||
                     (p_wr_char_evt_param->value_hdl == p_peer->hdls.idd_annunciation_status_cli_cnfg_hdl) ||
                     (p_wr_char_evt_param->value_hdl == p_peer->hdls.idd_status_reader_control_point_cli_cnfg_hdl) ||
                     (p_wr_char_evt_param->value_hdl == p_peer->hdls.idd_command_control_point_cli_cnfg_hdl) ||
                     (p_wr_char_evt_param->value_hdl == p_peer->hdls.idd_command_data_cli_cnfg_hdl) ||
                     (p_wr_char_evt_param->value_hdl == p_peer->hdls.idd_record_access_control_point_cli_cnfg_hdl) ||
                     (p_wr_char_evt_param->value_hdl == p_peer->hdls.idd_history_data_cli_cnfg_hdl))
            {
                gs_idc_cb(BLE_IDC_EVENT_CLI_CNFG_WRITE_RSP, result, &evt_data);
            }

        } 
        break;

        case BLE_GATTC_EVENT_HDL_VAL_IND:
        {
            st_ble_gattc_ind_evt_t *p_ind_evt_param =
                (st_ble_gattc_ind_evt_t *)p_data->p_param;

            if (p_ind_evt_param->data.attr_hdl == p_peer->hdls.idd_status_changed_char_val_hdl)
            {
                ble_status_t ret;
                st_ble_idc_idd_status_changed_t app_value;
                ret = decode_idd_status_changed(&app_value, &p_ind_evt_param->data.value);

                st_ble_idc_evt_data_t evt_data = 
                {
                    .conn_hdl  = p_data->conn_hdl,
                    .param_len = sizeof(app_value),
                    .p_param   = &app_value,
                };
                gs_idc_cb(BLE_IDC_EVENT_IDD_STATUS_CHANGED_HDL_VAL_IND, ret, &evt_data);
            }
            else if (p_ind_evt_param->data.attr_hdl == p_peer->hdls.idd_status_char_val_hdl)
            {
                ble_status_t ret;
                st_ble_idc_idd_status_t app_value;
                ret = decode_idd_status(&app_value, &p_ind_evt_param->data.value);

                st_ble_idc_evt_data_t evt_data = 
                {
                    .conn_hdl  = p_data->conn_hdl,
                    .param_len = sizeof(app_value),
                    .p_param   = &app_value,
                };
                gs_idc_cb(BLE_IDC_EVENT_IDD_STATUS_HDL_VAL_IND, ret, &evt_data);
            }
            else if (p_ind_evt_param->data.attr_hdl == p_peer->hdls.idd_annunciation_status_char_val_hdl)
            {
                ble_status_t ret;
                st_ble_idc_idd_annunciation_status_t app_value;
                ret = decode_idd_annunciation_status(&app_value, &p_ind_evt_param->data.value);

                st_ble_idc_evt_data_t evt_data = {
                    .conn_hdl  = p_data->conn_hdl,
                    .param_len = sizeof(app_value),
                    .p_param   = &app_value,
                };
                gs_idc_cb(BLE_IDC_EVENT_IDD_ANNUNCIATION_STATUS_HDL_VAL_IND, ret, &evt_data);
            }
            else if (p_ind_evt_param->data.attr_hdl == p_peer->hdls.idd_status_reader_control_point_char_val_hdl)
            {
                ble_status_t ret;
                st_ble_idc_idd_status_reader_control_point_t app_value;
                ret = decode_idd_status_reader_control_point(&app_value, &p_ind_evt_param->data.value);

                st_ble_idc_evt_data_t evt_data = 
                {
                    .conn_hdl  = p_data->conn_hdl,
                    .param_len = sizeof(app_value),
                    .p_param   = &app_value,
                };
                gs_idc_cb(BLE_IDC_EVENT_IDD_STATUS_READER_CONTROL_POINT_HDL_VAL_IND, ret, &evt_data);
            }
            else if (p_ind_evt_param->data.attr_hdl == p_peer->hdls.idd_command_control_point_char_val_hdl)
            {
                ble_status_t ret;
                st_ble_idc_idd_command_control_point_t app_value;
                ret = decode_idd_command_control_point(&app_value, &p_ind_evt_param->data.value);

                st_ble_idc_evt_data_t evt_data = 
                {
                    .conn_hdl  = p_data->conn_hdl,
                    .param_len = sizeof(app_value),
                    .p_param   = &app_value,
                };
                gs_idc_cb(BLE_IDC_EVENT_IDD_COMMAND_CONTROL_POINT_HDL_VAL_IND, ret, &evt_data);
            }
            else if (p_ind_evt_param->data.attr_hdl == p_peer->hdls.idd_record_access_control_point_char_val_hdl)
            {
                ble_status_t ret;
                st_ble_idc_idd_record_access_control_point_t app_value;
                ret = decode_idd_record_access_control_point(&app_value, &p_ind_evt_param->data.value);

                st_ble_idc_evt_data_t evt_data = 
                {
                    .conn_hdl  = p_data->conn_hdl,
                    .param_len = sizeof(app_value),
                    .p_param   = &app_value,
                };
                gs_idc_cb(BLE_IDC_EVENT_IDD_RECORD_ACCESS_CONTROL_POINT_HDL_VAL_IND, ret, &evt_data);
            }
        } 
        break;

        case BLE_GATTC_EVENT_HDL_VAL_NTF:
        {
            st_ble_gattc_ntf_evt_t *p_ntf_evt_param =
                (st_ble_gattc_ntf_evt_t *)p_data->p_param;
            if (p_ntf_evt_param->data.attr_hdl == p_peer->hdls.idd_command_data_char_val_hdl)
            {
                ble_status_t ret;
                st_ble_idc_idd_command_data_t app_value;
                ret = decode_idd_command_data(&app_value, &p_ntf_evt_param->data.value);

                st_ble_idc_evt_data_t evt_data = 
                {
                    .conn_hdl  = p_data->conn_hdl,
                    .param_len = sizeof(app_value),
                    .p_param   = &app_value,
                };
                gs_idc_cb(BLE_IDC_EVENT_IDD_COMMAND_DATA_HDL_VAL_NTF, ret, &evt_data);
            }
            else if (p_ntf_evt_param->data.attr_hdl == p_peer->hdls.idd_history_data_char_val_hdl)
            {
                ble_status_t ret;
                st_ble_idc_idd_history_data_t app_value;
                ret = decode_idd_history_data(&app_value, &p_ntf_evt_param->data.value);

                st_ble_idc_evt_data_t evt_data = 
                {
                    .conn_hdl  = p_data->conn_hdl,
                    .param_len = sizeof(app_value),
                    .p_param   = &app_value,
                };
                gs_idc_cb(BLE_IDC_EVENT_IDD_HISTORY_DATA_HDL_VAL_NTF, ret, &evt_data);
            }
        } 
        break;

        case BLE_GATTC_EVENT_ERROR_RSP:
        {
            st_ble_gattc_err_rsp_evt_t *p_err_rsp_evt_param =
                (st_ble_gattc_err_rsp_evt_t *)p_data->p_param;

            st_ble_idc_evt_data_t evt_data = 
            {
                .conn_hdl  = p_data->conn_hdl,
                .param_len = sizeof(st_ble_gattc_err_rsp_evt_t),
                .p_param   = p_err_rsp_evt_param,
            };

            if ((p_err_rsp_evt_param->attr_hdl == p_peer->hdls.idd_status_changed_char_val_hdl) ||
                (p_err_rsp_evt_param->attr_hdl == p_peer->hdls.idd_status_char_val_hdl) ||
                (p_err_rsp_evt_param->attr_hdl == p_peer->hdls.idd_annunciation_status_char_val_hdl) ||
                (p_err_rsp_evt_param->attr_hdl == p_peer->hdls.idd_features_char_val_hdl) ||
                (p_err_rsp_evt_param->attr_hdl == p_peer->hdls.idd_status_reader_control_point_char_val_hdl) ||
                (p_err_rsp_evt_param->attr_hdl == p_peer->hdls.idd_command_control_point_char_val_hdl) ||
                (p_err_rsp_evt_param->attr_hdl == p_peer->hdls.idd_record_access_control_point_char_val_hdl))
            {
                gs_idc_cb(BLE_IDC_EVENT_ERROR_RSP, result, &evt_data);
            }
        } 
        break;

        default:
        {
            /* Do nothing. */
        } 
        break;
    }
}

ble_status_t R_BLE_IDC_Init(const st_ble_idc_init_param_t *p_param) // @suppress("API function naming")
{
    if (NULL == p_param)
    {
        return BLE_ERR_INVALID_PTR;
    }

    if (NULL == p_param->cb)
    {
        return BLE_ERR_INVALID_ARG;
    }

    for (uint8_t i = 0; i < 7; i++)
    {
        clear_peer_param(&gs_peer_params[i]);
    }

    R_BLE_GATTC_RegisterCb(idc_gattc_cb, 2);

    gs_idc_cb = p_param->cb;

    return BLE_SUCCESS;
}

ble_status_t R_BLE_IDC_Connect(uint16_t conn_hdl, const st_ble_idc_connect_param_t *p_param) // @suppress("API function naming")
{
    st_idc_peer_param_t *p_peer = get_new_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if ((NULL != p_param) && (NULL != p_param->p_hdls))
    {
        memcpy(&p_peer->hdls, p_param->p_hdls, sizeof(p_peer->hdls));
    }

    return BLE_SUCCESS;
}

ble_status_t R_BLE_IDC_Disconnect(uint16_t conn_hdl, st_ble_idc_disconnect_param_t *p_param) // @suppress("API function naming")
{
    st_idc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if ((NULL != p_param) && (NULL != p_param->p_hdls))
    {
        memcpy(p_param->p_hdls, &p_peer->hdls, sizeof(*p_param->p_hdls));
    }

    clear_peer_param(p_peer);

    return BLE_SUCCESS;
}

ble_status_t R_BLE_IDC_ReadIddStatusChanged(uint16_t conn_hdl) // @suppress("API function naming")
{
    st_idc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.idd_status_changed_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    return R_BLE_GATTC_ReadChar(conn_hdl, p_peer->hdls.idd_status_changed_char_val_hdl);
}


ble_status_t R_BLE_IDC_SetIddStatusChangedCliCnfg(uint16_t conn_hdl, uint16_t cli_cnfg) // @suppress("API function naming")
{
    st_idc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.idd_status_changed_cli_cnfg_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    if (0 != (cli_cnfg & 0xFFFC))
    {
        return BLE_ERR_INVALID_ARG;
    }

    uint8_t byte_value[2] = { 0 };
    BT_PACK_LE_2_BYTE(byte_value, &cli_cnfg);

    st_ble_gatt_hdl_value_pair_t gatt_value = 
    {
        .attr_hdl = p_peer->hdls.idd_status_changed_cli_cnfg_hdl,
        .value = {
            .p_value   = byte_value,
            .value_len = 2,
        }
    };

    return R_BLE_GATTC_WriteChar(conn_hdl, &gatt_value);
}


ble_status_t R_BLE_IDC_ReadIddStatus(uint16_t conn_hdl) // @suppress("API function naming")
{
    st_idc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.idd_status_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    return R_BLE_GATTC_ReadChar(conn_hdl, p_peer->hdls.idd_status_char_val_hdl);
}


ble_status_t R_BLE_IDC_SetIddStatusCliCnfg(uint16_t conn_hdl, uint16_t cli_cnfg) // @suppress("API function naming")
{
    st_idc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.idd_status_cli_cnfg_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    if (0 != (cli_cnfg & 0xFFFC))
    {
        return BLE_ERR_INVALID_ARG;
    }

    uint8_t byte_value[2] = { 0 };
    BT_PACK_LE_2_BYTE(byte_value, &cli_cnfg);

    st_ble_gatt_hdl_value_pair_t gatt_value = 
    {
        .attr_hdl = p_peer->hdls.idd_status_cli_cnfg_hdl,
        .value = {
            .p_value   = byte_value,
            .value_len = 2,
        }
    };

    return R_BLE_GATTC_WriteChar(conn_hdl, &gatt_value);
}


ble_status_t R_BLE_IDC_ReadIddAnnunciationStatus(uint16_t conn_hdl) // @suppress("API function naming")
{
    st_idc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.idd_annunciation_status_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    return R_BLE_GATTC_ReadChar(conn_hdl, p_peer->hdls.idd_annunciation_status_char_val_hdl);
}


ble_status_t R_BLE_IDC_SetIddAnnunciationStatusCliCnfg(uint16_t conn_hdl, uint16_t cli_cnfg) // @suppress("API function naming")
{
    st_idc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.idd_annunciation_status_cli_cnfg_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    if (0 != (cli_cnfg & 0xFFFC))
    {
        return BLE_ERR_INVALID_ARG;
    }

    uint8_t byte_value[2] = { 0 };
    BT_PACK_LE_2_BYTE(byte_value, &cli_cnfg);

    st_ble_gatt_hdl_value_pair_t gatt_value = {
        .attr_hdl = p_peer->hdls.idd_annunciation_status_cli_cnfg_hdl,
        .value = {
            .p_value   = byte_value,
            .value_len = 2,
        }
    };

    return R_BLE_GATTC_WriteChar(conn_hdl, &gatt_value);
}


ble_status_t R_BLE_IDC_ReadIddFeatures(uint16_t conn_hdl) // @suppress("API function naming")
{
    st_idc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.idd_features_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    return R_BLE_GATTC_ReadChar(conn_hdl, p_peer->hdls.idd_features_char_val_hdl);
}


ble_status_t R_BLE_IDC_WriteIddStatusReaderControlPoint(uint16_t conn_hdl, const st_ble_idc_idd_status_reader_control_point_t *p_app_value) // @suppress("API function naming")
{
    ble_status_t ret;
    st_idc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (NULL == p_app_value)
    {
        return BLE_ERR_INVALID_PTR;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.idd_status_reader_control_point_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    uint8_t byte_value[BLE_IDC_IDD_STATUS_READER_CONTROL_POINT_LEN];

    st_ble_gatt_hdl_value_pair_t write_value = 
    {
        .attr_hdl  = p_peer->hdls.idd_status_reader_control_point_char_val_hdl,
        .value = {
            .p_value   = byte_value,
            .value_len = BLE_IDC_IDD_STATUS_READER_CONTROL_POINT_LEN,
        }
    };
    ret = encode_idd_status_reader_control_point(p_app_value, &write_value.value);
    if (BLE_SUCCESS != ret)
    {
        return BLE_ERR_INVALID_DATA;
    }

    return R_BLE_GATTC_WriteChar(conn_hdl, &write_value);
}


ble_status_t R_BLE_IDC_SetIddStatusReaderControlPointCliCnfg(uint16_t conn_hdl, uint16_t cli_cnfg) // @suppress("API function naming")
{
    st_idc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.idd_status_reader_control_point_cli_cnfg_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    if (0 != (cli_cnfg & 0xFFFC))
    {
        return BLE_ERR_INVALID_ARG;
    }

    uint8_t byte_value[2] = { 0 };
    BT_PACK_LE_2_BYTE(byte_value, &cli_cnfg);

    st_ble_gatt_hdl_value_pair_t gatt_value = 
    {
        .attr_hdl = p_peer->hdls.idd_status_reader_control_point_cli_cnfg_hdl,
        .value = {
            .p_value   = byte_value,
            .value_len = 2,
        }
    };

    return R_BLE_GATTC_WriteChar(conn_hdl, &gatt_value);
}

ble_status_t R_BLE_IDC_WriteIddCommandControlPoint(uint16_t conn_hdl, const st_ble_idc_idd_command_control_point_t *p_app_value) // @suppress("API function naming")
{
    ble_status_t ret;
    st_idc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (NULL == p_app_value)
    {
        return BLE_ERR_INVALID_PTR;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.idd_command_control_point_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    uint8_t byte_value[BLE_IDC_IDD_COMMAND_CONTROL_POINT_LEN];

    st_ble_gatt_hdl_value_pair_t write_value = 
    {
        .attr_hdl  = p_peer->hdls.idd_command_control_point_char_val_hdl,
        .value = {
            .p_value   = byte_value,
            .value_len = BLE_IDC_IDD_COMMAND_CONTROL_POINT_LEN,
        }
    };
    ret = encode_idd_command_control_point(p_app_value, &write_value.value);
    if (BLE_SUCCESS != ret)
    {
        return BLE_ERR_INVALID_DATA;
    }

    return R_BLE_GATTC_WriteChar(conn_hdl, &write_value);
}


ble_status_t R_BLE_IDC_SetIddCommandControlPointCliCnfg(uint16_t conn_hdl, uint16_t cli_cnfg) // @suppress("API function naming")
{
    st_idc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.idd_command_control_point_cli_cnfg_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    if (0 != (cli_cnfg & 0xFFFC))
    {
        return BLE_ERR_INVALID_ARG;
    }

    uint8_t byte_value[2] = { 0 };
    BT_PACK_LE_2_BYTE(byte_value, &cli_cnfg);

    st_ble_gatt_hdl_value_pair_t gatt_value = 
    {
        .attr_hdl = p_peer->hdls.idd_command_control_point_cli_cnfg_hdl,
        .value = {
            .p_value   = byte_value,
            .value_len = 2,
        }
    };

    return R_BLE_GATTC_WriteChar(conn_hdl, &gatt_value);
}


ble_status_t R_BLE_IDC_SetIddCommandDataCliCnfg(uint16_t conn_hdl, uint16_t cli_cnfg) // @suppress("API function naming")
{
    st_idc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.idd_command_data_cli_cnfg_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    if (0 != (cli_cnfg & 0xFFFC))
    {
        return BLE_ERR_INVALID_ARG;
    }

    uint8_t byte_value[2] = { 0 };
    BT_PACK_LE_2_BYTE(byte_value, &cli_cnfg);

    st_ble_gatt_hdl_value_pair_t gatt_value =
    {
        .attr_hdl = p_peer->hdls.idd_command_data_cli_cnfg_hdl,
        .value = {
            .p_value   = byte_value,
            .value_len = 2,
        }
    };

    return R_BLE_GATTC_WriteChar(conn_hdl, &gatt_value);
}

ble_status_t R_BLE_IDC_WriteIddRecordAccessControlPoint(uint16_t conn_hdl, const st_ble_idc_idd_record_access_control_point_t *p_app_value) // @suppress("API function naming")
{
    ble_status_t ret;
    st_idc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (NULL == p_app_value)
    {
        return BLE_ERR_INVALID_PTR;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.idd_record_access_control_point_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    uint8_t byte_value[BLE_IDC_IDD_RECORD_ACCESS_CONTROL_POINT_LEN];

    st_ble_gatt_hdl_value_pair_t write_value =
    {
        .attr_hdl  = p_peer->hdls.idd_record_access_control_point_char_val_hdl,
        .value = 
        {
            .p_value   = byte_value,
            .value_len = BLE_IDC_IDD_RECORD_ACCESS_CONTROL_POINT_LEN,
        }
    };
    ret = encode_idd_record_access_control_point(p_app_value, &write_value.value);
    if (BLE_SUCCESS != ret)
    {
        return BLE_ERR_INVALID_DATA;
    }

    return R_BLE_GATTC_WriteChar(conn_hdl, &write_value);
}


ble_status_t R_BLE_IDC_SetIddRecordAccessControlPointCliCnfg(uint16_t conn_hdl, uint16_t cli_cnfg) // @suppress("API function naming")
{
    st_idc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.idd_record_access_control_point_cli_cnfg_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    if (0 != (cli_cnfg & 0xFFFC))
    {
        return BLE_ERR_INVALID_ARG;
    }

    uint8_t byte_value[2] = { 0 };
    BT_PACK_LE_2_BYTE(byte_value, &cli_cnfg);

    st_ble_gatt_hdl_value_pair_t gatt_value = 
    {
        .attr_hdl = p_peer->hdls.idd_record_access_control_point_cli_cnfg_hdl,
        .value = {
            .p_value   = byte_value,
            .value_len = 2,
        }
    };

    return R_BLE_GATTC_WriteChar(conn_hdl, &gatt_value);
}


ble_status_t R_BLE_IDC_SetIddHistoryDataCliCnfg(uint16_t conn_hdl, uint16_t cli_cnfg) // @suppress("API function naming")
{
    st_idc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.idd_history_data_cli_cnfg_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    if (0 != (cli_cnfg & 0xFFFC))
    {
        return BLE_ERR_INVALID_ARG;
    }

    uint8_t byte_value[2] = { 0 };
    BT_PACK_LE_2_BYTE(byte_value, &cli_cnfg);

    st_ble_gatt_hdl_value_pair_t gatt_value = 
    {
        .attr_hdl = p_peer->hdls.idd_history_data_cli_cnfg_hdl,
        .value = {
            .p_value   = byte_value,
            .value_len = 2,
        }
    };

    return R_BLE_GATTC_WriteChar(conn_hdl, &gatt_value);
}


void R_BLE_IDC_ServDiscCb(uint16_t conn_hdl, uint8_t idx, uint16_t type, void *p_param) // @suppress("API function naming")
{
    UNUSED_ARG(idx);

    st_idc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    switch (type)
    {
        case BLE_DISC_PRIM_SERV_FOUND:
        {
            st_disc_serv_param_t *p_serv_param = (st_disc_serv_param_t *)p_param;
            memcpy(&p_peer->hdls.service_range, &p_serv_param->value.serv_16.range, sizeof(p_peer->hdls.service_range));
        } 
        break;

        case BLE_DISC_CHAR_FOUND:
        {
            st_disc_char_param_t *p_char_param = (st_disc_char_param_t *)p_param;

            if (BLE_GATT_16_BIT_UUID_FORMAT == p_char_param->uuid_type)
            {
                uint8_t uuid_16[BLE_GATT_16_BIT_UUID_SIZE];
                BT_PACK_LE_2_BYTE(uuid_16, &p_char_param->value.char_16.uuid_16);

                if (0 == memcmp(uuid_16, BLE_IDC_IDD_STATUS_CHANGED_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.idd_status_changed_char_val_hdl = p_char_param->value.char_16.value_hdl;

                    for (uint8_t i = 0; i < p_char_param->num_of_descs; i++)
                    {
                        BT_PACK_LE_2_BYTE(uuid_16, &p_char_param->descs[i].value.desc_16.uuid_16);

                        if (0 == memcmp(uuid_16, BLE_IDC_IDD_STATUS_CHANGED_CLIENT_CHARACTERISTIC_CONFIGURATION_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                        {
                            p_peer->hdls.idd_status_changed_cli_cnfg_hdl = p_char_param->descs[i].value.desc_16.desc_hdl;
                        }
                    }
                }
                else if (0 == memcmp(uuid_16, BLE_IDC_IDD_STATUS_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.idd_status_char_val_hdl = p_char_param->value.char_16.value_hdl;

                    for (uint8_t i = 0; i < p_char_param->num_of_descs; i++)
                    {
                        BT_PACK_LE_2_BYTE(uuid_16, &p_char_param->descs[i].value.desc_16.uuid_16);

                        if (0 == memcmp(uuid_16, BLE_IDC_IDD_STATUS_CLIENT_CHARACTERISTIC_CONFIGURATION_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                        {
                            p_peer->hdls.idd_status_cli_cnfg_hdl = p_char_param->descs[i].value.desc_16.desc_hdl;
                        }
                    }
                }
                else if (0 == memcmp(uuid_16, BLE_IDC_IDD_ANNUNCIATION_STATUS_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.idd_annunciation_status_char_val_hdl = p_char_param->value.char_16.value_hdl;

                    for (uint8_t i = 0; i < p_char_param->num_of_descs; i++)
                    {
                        BT_PACK_LE_2_BYTE(uuid_16, &p_char_param->descs[i].value.desc_16.uuid_16);

                        if (0 == memcmp(uuid_16, BLE_IDC_IDD_ANNUNCIATION_STATUS_CLIENT_CHARACTERISTIC_CONFIGURATION_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                        {
                            p_peer->hdls.idd_annunciation_status_cli_cnfg_hdl = p_char_param->descs[i].value.desc_16.desc_hdl;
                        }
                    }
                }
                else if (0 == memcmp(uuid_16, BLE_IDC_IDD_FEATURES_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.idd_features_char_val_hdl = p_char_param->value.char_16.value_hdl;

                }
                else if (0 == memcmp(uuid_16, BLE_IDC_IDD_STATUS_READER_CONTROL_POINT_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.idd_status_reader_control_point_char_val_hdl = p_char_param->value.char_16.value_hdl;

                    for (uint8_t i = 0; i < p_char_param->num_of_descs; i++)
                    {
                        BT_PACK_LE_2_BYTE(uuid_16, &p_char_param->descs[i].value.desc_16.uuid_16);

                        if (0 == memcmp(uuid_16, BLE_IDC_IDD_STATUS_READER_CONTROL_POINT_CLIENT_CHARACTERISTIC_CONFIGURATION_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                        {
                            p_peer->hdls.idd_status_reader_control_point_cli_cnfg_hdl = p_char_param->descs[i].value.desc_16.desc_hdl;
                        }
                    }
                }
                else if (0 == memcmp(uuid_16, BLE_IDC_IDD_COMMAND_CONTROL_POINT_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.idd_command_control_point_char_val_hdl = p_char_param->value.char_16.value_hdl;

                    for (uint8_t i = 0; i < p_char_param->num_of_descs; i++)
                    {
                        BT_PACK_LE_2_BYTE(uuid_16, &p_char_param->descs[i].value.desc_16.uuid_16);

                        if (0 == memcmp(uuid_16, BLE_IDC_IDD_COMMAND_CONTROL_POINT_CLIENT_CHARACTERISTIC_CONFIGURATION_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                        {
                            p_peer->hdls.idd_command_control_point_cli_cnfg_hdl = p_char_param->descs[i].value.desc_16.desc_hdl;
                        }
                    }
                }
                else if (0 == memcmp(uuid_16, BLE_IDC_IDD_COMMAND_DATA_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.idd_command_data_char_val_hdl = p_char_param->value.char_16.value_hdl;

                    for (uint8_t i = 0; i < p_char_param->num_of_descs; i++)
                    {
                        BT_PACK_LE_2_BYTE(uuid_16, &p_char_param->descs[i].value.desc_16.uuid_16);

                        if (0 == memcmp(uuid_16, BLE_IDC_IDD_COMMAND_DATA_CLIENT_CHARACTERISTIC_CONFIGURATION_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                        {
                            p_peer->hdls.idd_command_data_cli_cnfg_hdl = p_char_param->descs[i].value.desc_16.desc_hdl;
                        }
                    }
                }
                else if (0 == memcmp(uuid_16, BLE_IDC_IDD_RECORD_ACCESS_CONTROL_POINT_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.idd_record_access_control_point_char_val_hdl = p_char_param->value.char_16.value_hdl;

                    for (uint8_t i = 0; i < p_char_param->num_of_descs; i++)
                    {
                        BT_PACK_LE_2_BYTE(uuid_16, &p_char_param->descs[i].value.desc_16.uuid_16);

                        if (0 == memcmp(uuid_16, BLE_IDC_IDD_RECORD_ACCESS_CONTROL_POINT_CLIENT_CHARACTERISTIC_CONFIGURATION_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                        {
                            p_peer->hdls.idd_record_access_control_point_cli_cnfg_hdl = p_char_param->descs[i].value.desc_16.desc_hdl;
                        }
                    }
                }
                else if (0 == memcmp(uuid_16, BLE_IDC_IDD_HISTORY_DATA_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.idd_history_data_char_val_hdl = p_char_param->value.char_16.value_hdl;

                    for (uint8_t i = 0; i < p_char_param->num_of_descs; i++)
                    {
                        BT_PACK_LE_2_BYTE(uuid_16, &p_char_param->descs[i].value.desc_16.uuid_16);

                        if (0 == memcmp(uuid_16, BLE_IDC_IDD_HISTORY_DATA_CLIENT_CHARACTERISTIC_CONFIGURATION_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                        {
                            p_peer->hdls.idd_history_data_cli_cnfg_hdl = p_char_param->descs[i].value.desc_16.desc_hdl;
                        }
                    }
                }
            }
        } 
        break;

        default:
        {
            /* Do nothing. */
        } 
        break;
    }
}

uint32_t R_BLE_IDC_GetVersion(void) // @suppress("API function naming")
{
    uint32_t version;

    version = ((BLE_IDC_PRV_VERSION_MAJOR << 16) | (BLE_IDC_PRV_VERSION_MINOR << 8));

    return version;
}

