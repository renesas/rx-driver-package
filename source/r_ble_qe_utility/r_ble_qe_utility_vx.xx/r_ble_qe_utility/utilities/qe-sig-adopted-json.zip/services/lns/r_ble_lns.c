/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_lns.c
 * Version : 1.0
 * Description : The source file for Location and Navigation service.
 **********************************************************************************************************************/

#include <stdlib.h>
#include <string.h>
#include "r_ble_lns.h"
#include "profile_cmn/r_ble_servs_if.h"
#include "gatt_db.h"

#ifndef UNUSED_ARG
#define UNUSED_ARG(arg)         (void)(arg)
#endif /* UNUSED_ARG */

static st_ble_servs_info_t gs_servs_info;
static uint16_t gs_mtu_size = BLE_GATT_DEFAULT_MTU;

/*----------------------------------------------------------------------------------------------------------------------
    LN Feature characteristic
----------------------------------------------------------------------------------------------------------------------*/

static ble_status_t decode_st_ble_lns_feat_t(st_ble_lns_feat_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    if(BLE_LNS_FEAT_LEN == p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    p_app_value->is_instantaneous_speed_supported = (p_gatt_value->p_value[0]) & 0x01;
    p_app_value->is_total_distance_supported = (p_gatt_value->p_value[0] >> 1) & 0x01;
    p_app_value->is_location_supported = (p_gatt_value->p_value[0] >> 2) & 0x01;
    p_app_value->is_elevation_supported = (p_gatt_value->p_value[0] >> 3) & 0x01;
    p_app_value->is_heading_supported = (p_gatt_value->p_value[0] >> 4) & 0x01;
    p_app_value->is_rolling_time_supported = (p_gatt_value->p_value[0] >> 5) & 0x01;
    p_app_value->is_utc_time_supported = (p_gatt_value->p_value[0] >> 6) & 0x01;
    p_app_value->is_remaining_distance_supported = (p_gatt_value->p_value[0] >> 7) & 0x01;
    p_app_value->is_remaining_vertical_distance_supported = (p_gatt_value->p_value[1]) & 0x01;
    p_app_value->is_estimated_time_of_arrival_supported = (p_gatt_value->p_value[1] >> 1) & 0x01;
    p_app_value->is_number_of_beacons_in_solution_supported = (p_gatt_value->p_value[1] >> 2) & 0x01;
    p_app_value->is_number_of_beacons_in_view_supported = (p_gatt_value->p_value[1] >> 3) & 0x01;
    p_app_value->is_time_to_first_fix_supported = (p_gatt_value->p_value[1] >> 4) & 0x01;
    p_app_value->is_estimated_horizontal_position_error_supported = (p_gatt_value->p_value[1] >> 5) & 0x01;
    p_app_value->is_estimated_vertical_position_error_supported = (p_gatt_value->p_value[1] >> 6) & 0x01;
    p_app_value->is_horizontal_dilution_of_precision_supported = (p_gatt_value->p_value[1] >> 7) & 0x01;
    p_app_value->is_vertical_dilution_of_precision_supported = (p_gatt_value->p_value[2]) & 0x01;
    p_app_value->is_location_and_speed_characteristic_content_masking_supported = (p_gatt_value->p_value[2] >> 1) & 0x01;
    p_app_value->is_fix_rate_setting_supported = (p_gatt_value->p_value[2] >> 2) & 0x01;
    p_app_value->is_elevation_setting_supported = (p_gatt_value->p_value[2] >> 3) & 0x01;
    p_app_value->is_position_status_supported = (p_gatt_value->p_value[2] >> 4) & 0x01;

    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_lns_feat_t(const st_ble_lns_feat_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    p_gatt_value->p_value[0] = (uint8_t)((p_app_value->is_instantaneous_speed_supported & 0x01) |
                               ((p_app_value->is_total_distance_supported & 0x01) << 1) |
                               ((p_app_value->is_location_supported & 0x01) << 2) |
                               ((p_app_value->is_elevation_supported & 0x01) << 3) |
                               ((p_app_value->is_heading_supported & 0x01) << 4) |
                               ((p_app_value->is_rolling_time_supported & 0x01) << 5) |
                               ((p_app_value->is_utc_time_supported & 0x01) << 6) |
                               ((p_app_value->is_remaining_distance_supported & 0x01) << 7));
    p_gatt_value->p_value[1] = (uint8_t)((p_app_value->is_remaining_vertical_distance_supported & 0x01) |
                               ((p_app_value->is_estimated_time_of_arrival_supported & 0x01) << 1) |
                               ((p_app_value->is_number_of_beacons_in_solution_supported & 0x01) << 2) |
                               ((p_app_value->is_number_of_beacons_in_view_supported & 0x01) << 3) |
                               ((p_app_value->is_time_to_first_fix_supported & 0x01) << 4) |
                               ((p_app_value->is_estimated_horizontal_position_error_supported & 0x01) << 5) |
                               ((p_app_value->is_estimated_vertical_position_error_supported & 0x01) << 6) |
                               ((p_app_value->is_horizontal_dilution_of_precision_supported & 0x01) << 7));
    p_gatt_value->p_value[2] = (uint8_t)((p_app_value->is_vertical_dilution_of_precision_supported & 0x01) |
                               ((p_app_value->is_location_and_speed_characteristic_content_masking_supported & 0x01)  << 1) |
                               ((p_app_value->is_fix_rate_setting_supported & 0x01) << 2) |
                               ((p_app_value->is_elevation_setting_supported & 0x01) << 3) |
                               ((p_app_value->is_position_status_supported & 0x01) << 4));
    return BLE_SUCCESS;
}

/* LN Feature characteristic definition */
static const st_ble_servs_char_info_t gs_feat_char = {
    .start_hdl    = BLE_LNS_FEAT_DECL_HDL,
    .end_hdl      = BLE_LNS_FEAT_VAL_HDL,
    .char_idx     = BLE_LNS_FEAT_IDX,
    .app_size     = sizeof(st_ble_lns_feat_t),
    .db_size      = BLE_LNS_FEAT_LEN,
    .decode       = (ble_servs_attr_decode_t)decode_st_ble_lns_feat_t,
    .encode       = (ble_servs_attr_encode_t)encode_st_ble_lns_feat_t,
};

ble_status_t R_BLE_LNS_SetFeat(const st_ble_lns_feat_t *p_value)
{
    return R_BLE_SERVS_SetChar(&gs_feat_char, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_LNS_GetFeat(st_ble_lns_feat_t *p_value)
{
    return R_BLE_SERVS_GetChar(&gs_feat_char, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Location and Speed Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

static const st_ble_servs_desc_info_t gs_location_and_speed_cli_cnfg = {
    .attr_hdl = BLE_LNS_LOCATION_AND_SPEED_CLI_CNFG_DESC_HDL,
    .app_size = sizeof(uint16_t),
    .desc_idx = BLE_LNS_LOCATION_AND_SPEED_CLI_CNFG_IDX,
    .db_size  = BLE_LNS_LOCATION_AND_SPEED_CLI_CNFG_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_uint16_t,
    .encode   = (ble_servs_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_LNS_SetLocationAndSpeedCliCnfg(uint16_t conn_hdl, const uint16_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_location_and_speed_cli_cnfg, conn_hdl, (const void *)p_value);
}

ble_status_t R_BLE_LNS_GetLocationAndSpeedCliCnfg(uint16_t conn_hdl, uint16_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_location_and_speed_cli_cnfg, conn_hdl, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Location and Speed characteristic
----------------------------------------------------------------------------------------------------------------------*/

static ble_status_t encode_st_ble_lns_location_and_speed_t(const st_ble_lns_location_and_speed_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint16_t pos = 2;
    p_gatt_value->p_value[0] = (uint8_t)((p_app_value->flags.is_instantaneous_speed_present & 0x01) |
        ((p_app_value->flags.is_total_distance_present & 0x01) << 1) |
        ((p_app_value->flags.is_location_present & 0x01) << 2) |
        ((p_app_value->flags.is_elevation_present & 0x01) << 3) |
        ((p_app_value->flags.is_heading_present & 0x01) << 4) |
        ((p_app_value->flags.is_rolling_time_present & 0x01) << 5) |
        ((p_app_value->flags.is_utc_time_present & 0x01) << 6) |
        ((p_app_value->flags.position_status & 0x01) << 7));
    p_gatt_value->p_value[1] = (uint8_t)(((p_app_value->flags.position_status & 0x02) >> 1) |
        ((p_app_value->flags.is_speed_and_distance_format & 0x01) << 1) |
        ((p_app_value->flags.elevation_source & 0x03) << 2) |
        ((p_app_value->flags.is_heading_source & 0x01) << 4));

    if (p_app_value->flags.is_instantaneous_speed_present)
    {
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->instantaneous_speed) & 0xFF);
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->instantaneous_speed >> 8) & 0xFF);
    }
    if (p_app_value->flags.is_total_distance_present)
    {
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->total_distance) & 0xFF);
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->total_distance >> 8) & 0xFF);
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->total_distance >> 16) & 0xFF);
    }
    if (p_app_value->flags.is_location_present)
    {
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->latitude) & 0xFF);
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->latitude >> 8) & 0xFF);
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->latitude >> 16) & 0xFF);
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->latitude >> 24) & 0xFF);
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->longitude) & 0xFF);
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->longitude >> 8) & 0xFF);
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->longitude >> 16) & 0xFF);
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->longitude >> 24) & 0xFF);
    }
    if (p_app_value->flags.is_elevation_present)
    {
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->elevation) & 0xFF);
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->elevation >> 8) & 0xFF);
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->elevation >> 16) & 0xFF);
    }
    if (p_app_value->flags.is_heading_present)
    {
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->heading) & 0xFF);
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->heading >> 8) & 0xFF);
    }
    if (p_app_value->flags.is_rolling_time_present)
    {
        p_gatt_value->p_value[pos++] = p_app_value->rolling_time;
    }
    if (p_app_value->flags.is_utc_time_present)
    {
        p_gatt_value->p_value[pos++] = (uint8_t)(p_app_value->utc_time.year & 0xFF);
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->utc_time.year >> 8) & 0xFF);
        p_gatt_value->p_value[pos++] = p_app_value->utc_time.month;
        p_gatt_value->p_value[pos++] = p_app_value->utc_time.day;
        p_gatt_value->p_value[pos++] = p_app_value->utc_time.hours;
        p_gatt_value->p_value[pos++] = p_app_value->utc_time.minutes;
        p_gatt_value->p_value[pos++] = p_app_value->utc_time.seconds;
    }

    return BLE_SUCCESS;
}

/* Location and Speed characteristic descriptor definition */
static const st_ble_servs_desc_info_t *gspp_location_and_speed_descs[] = {
    &gs_location_and_speed_cli_cnfg,
};

/* Location and Speed characteristic definition */
static const st_ble_servs_char_info_t gs_location_and_speed_char = {
    .start_hdl    = BLE_LNS_LOCATION_AND_SPEED_DECL_HDL,
    .end_hdl      = BLE_LNS_LOCATION_AND_SPEED_CLI_CNFG_DESC_HDL,
    .char_idx     = BLE_LNS_LOCATION_AND_SPEED_IDX,
    .app_size     = sizeof(st_ble_lns_location_and_speed_t),
    .db_size      = BLE_LNS_LOCATION_AND_SPEED_LEN,
    .encode       = (ble_servs_attr_encode_t)encode_st_ble_lns_location_and_speed_t,
    .pp_descs     = gspp_location_and_speed_descs,
    .num_of_descs = ARRAY_SIZE(gspp_location_and_speed_descs),
};

ble_status_t R_BLE_LNS_NotifyLocationAndSpeed(uint16_t conn_hdl, const st_ble_lns_location_and_speed_t *p_value)
{
    ble_status_t ret;
    int16_t ntf_size = (int16_t)((p_value->flags.is_instantaneous_speed_present * 2) +
        (p_value->flags.is_total_distance_present * 3) +
        (p_value->flags.is_location_present * 8) +
        (p_value->flags.is_elevation_present * 3) +
        (p_value->flags.is_heading_present * 2) +
        (p_value->flags.is_rolling_time_present * 1) +
        (p_value->flags.is_utc_time_present * 7) + 2);
    int16_t ntf_size2 = (int16_t)(ntf_size - (gs_mtu_size - 3));
    uint8_t *p_gatt_value = malloc((size_t)ntf_size);

    if (NULL == p_gatt_value)
    {
        return BLE_ERR_MEM_ALLOC_FAILED;
    }

    st_ble_gatt_value_t gatt_value = {
        .value_len = gs_location_and_speed_char.db_size,
        .p_value = p_gatt_value
    };

    if (NULL == p_value)
    {
        return BLE_ERR_INVALID_ARG;
    }
    if (BLE_GAP_INVALID_CONN_HDL == conn_hdl)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (ntf_size2 > 0) 
    {
        st_ble_lns_location_and_speed_t las_value1 = *p_value;
        st_ble_lns_location_and_speed_t las_value2 = { 0 };
        memset(&las_value2, 0x00, sizeof(st_ble_lns_location_and_speed_t));

        las_value2.flags.position_status = las_value1.flags.position_status;
        las_value2.flags.is_speed_and_distance_format = las_value1.flags.is_speed_and_distance_format;
        las_value2.flags.elevation_source = las_value1.flags.elevation_source;
        las_value2.flags.is_heading_source = las_value1.flags.is_heading_source;

        if((1 == ntf_size2) && (las_value1.flags.is_rolling_time_present))
        {
            las_value2.flags.is_rolling_time_present = true;
            las_value2.rolling_time = p_value->rolling_time;

            las_value1.flags.is_rolling_time_present = false;
            memset(&las_value1.utc_time, 0x00, sizeof(uint8_t));

            ntf_size = (int16_t)(ntf_size - 1);
            ntf_size2 = 1 + 2;
        }
        else if((7 >= ntf_size2) && (las_value1.flags.is_utc_time_present))
        {
            las_value2.flags.is_utc_time_present = true;
            las_value2.utc_time = p_value->utc_time;

            las_value1.flags.is_utc_time_present = false;
            memset(&las_value1.utc_time, 0x00, sizeof(st_ble_date_time_t));

            ntf_size = (int16_t)(ntf_size - 7);
            ntf_size2 = 7 + 2;
        }
        else if(8 == ntf_size2)
        {
            las_value2.flags.is_rolling_time_present = true;
            las_value2.flags.is_utc_time_present = true;
            las_value2.rolling_time = p_value->rolling_time;
            las_value2.utc_time = p_value->utc_time;

            las_value1.flags.is_rolling_time_present = false;
            las_value1.flags.is_utc_time_present = false;
            las_value1.rolling_time = 0x00;
            memset(&las_value1.utc_time, 0x00, sizeof(st_ble_date_time_t));

            ntf_size = (int16_t)(ntf_size - 8);
            ntf_size2 = 8 + 2;
        }
        
        gs_location_and_speed_char.encode(&las_value1, &gatt_value);
        st_ble_gatt_hdl_value_pair_t hdl_val_data1 = {
            .attr_hdl = (uint16_t)(gs_location_and_speed_char.start_hdl + 1),
            .value.value_len = (uint16_t)ntf_size,
            .value.p_value = gatt_value.p_value,
        };
        ret = R_BLE_GATTS_Notification(conn_hdl, &hdl_val_data1);

        if(BLE_SUCCESS == ret)
        {
            gs_location_and_speed_char.encode(&las_value2, &gatt_value);
            st_ble_gatt_hdl_value_pair_t hdl_val_data2 = {
                .attr_hdl = (uint16_t)(gs_location_and_speed_char.start_hdl + 1),
                .value.value_len = (uint16_t)ntf_size2,
                .value.p_value = gatt_value.p_value,
            };
            ret = R_BLE_GATTS_Notification(conn_hdl, &hdl_val_data2);           
        }
    }
    else
    {
        ret = gs_location_and_speed_char.encode(p_value, &gatt_value);

        st_ble_gatt_hdl_value_pair_t hdl_val_data = {
            .attr_hdl = (uint16_t)(gs_location_and_speed_char.start_hdl + 1),
            .value.value_len = (uint16_t)ntf_size,
            .value.p_value = gatt_value.p_value,
        };
        
        if (BLE_SUCCESS == ret)
        {
            ret = R_BLE_GATTS_Notification(conn_hdl, &hdl_val_data);
        }
    }

    free(p_gatt_value);
    return ret;
}

/*----------------------------------------------------------------------------------------------------------------------
    Position Quality characteristic
----------------------------------------------------------------------------------------------------------------------*/

static ble_status_t decode_st_ble_lns_position_quality_t(st_ble_lns_position_quality_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 2;
    if(BLE_LNS_POSITION_QUALITY_LEN == p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    p_app_value->flags.is_number_of_beacons_in_solution_present = (p_gatt_value->p_value[0]) & 0x01;
    p_app_value->flags.is_number_of_beacons_in_view_present = (p_gatt_value->p_value[0] >> 1) & 0x01;
    p_app_value->flags.is_time_to_first_fix_present = (p_gatt_value->p_value[0] >> 2) & 0x01;
    p_app_value->flags.is_ehpe_present = (p_gatt_value->p_value[0] >> 3) & 0x01;
    p_app_value->flags.is_evpe_present = (p_gatt_value->p_value[0] >> 4) & 0x01;
    p_app_value->flags.is_hdop_present= (p_gatt_value->p_value[0] >> 5) & 0x01;
    p_app_value->flags.is_vdop_present = (p_gatt_value->p_value[0] >> 6) & 0x01;
    p_app_value->flags.position_status = (uint8_t)(((p_gatt_value->p_value[0] >> 7) & 0x01) |
                                         ((p_gatt_value->p_value[1] & 0x01) << 1));

    if (p_app_value->flags.is_number_of_beacons_in_solution_present)
    {
        p_app_value->number_of_beacons_in_solution = p_gatt_value->p_value[pos++];
    }
    if (p_app_value->flags.is_number_of_beacons_in_view_present)
    {
        p_app_value->number_of_beacons_in_view = p_gatt_value->p_value[pos++];
    }
    if (p_app_value->flags.is_time_to_first_fix_present)
    {
        p_app_value->time_to_first_fix = (uint16_t)(((uint16_t)p_gatt_value->p_value[pos]) |
            (((uint16_t)p_gatt_value->p_value[pos + 1]) << 8));
        pos += 2;
    }
    if (p_app_value->flags.is_ehpe_present)
    {
        p_app_value->ehpe = (uint32_t)(p_gatt_value->p_value[pos] |
            (p_gatt_value->p_value[pos + 1] << 8) |
            (p_gatt_value->p_value[pos + 2] << 16) |
            (p_gatt_value->p_value[pos + 3] << 24));
        pos += 4;
    }
    if(p_app_value->flags.is_evpe_present)
    {
        p_app_value->evpe = (uint32_t)(p_gatt_value->p_value[pos] |
            (p_gatt_value->p_value[pos + 1] << 8) |
            (p_gatt_value->p_value[pos + 2] << 16) |
            (p_gatt_value->p_value[pos + 3] << 24));
        pos += 4;
    }
    if (p_app_value->flags.is_hdop_present)
    {
        p_app_value->hdop = p_gatt_value->p_value[pos++];
    }
    if (p_app_value->flags.is_vdop_present)
    {
        p_app_value->vdop = p_gatt_value->p_value[pos++];
    }

    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_lns_position_quality_t(const st_ble_lns_position_quality_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 2;
    p_gatt_value->p_value[0] = (uint8_t)((p_app_value->flags.is_number_of_beacons_in_solution_present & 0x01) |
                               ((p_app_value->flags.is_number_of_beacons_in_view_present & 0x01) << 1) |
                               ((p_app_value->flags.is_time_to_first_fix_present & 0x01) << 2) |
                               ((p_app_value->flags.is_ehpe_present & 0x01) << 3) |
                               ((p_app_value->flags.is_evpe_present & 0x01) << 4) |
                               ((p_app_value->flags.is_hdop_present & 0x01) << 5) |
                               ((p_app_value->flags.is_vdop_present & 0x01) << 6) |
                               ((p_app_value->flags.position_status & 0x01) << 7));
    p_gatt_value->p_value[1] = ((p_app_value->flags.position_status & 0x02) >> 1);
    
    if (p_app_value->flags.is_number_of_beacons_in_solution_present)
    {
        p_gatt_value->p_value[pos++] = p_app_value->number_of_beacons_in_solution;
    }
    if (p_app_value->flags.is_number_of_beacons_in_view_present)
    {
        p_gatt_value->p_value[pos++] = p_app_value->number_of_beacons_in_view;
    }
    if (p_app_value->flags.is_time_to_first_fix_present)
    {
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->time_to_first_fix) & 0xFF);
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->time_to_first_fix >> 8) & 0xFF);
    }
    if (p_app_value->flags.is_ehpe_present)
    {
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->ehpe) & 0xFF);
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->ehpe >> 8) & 0xFF);
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->ehpe >> 16) & 0xFF);
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->ehpe >> 24) & 0xFF);
    }
    if (p_app_value->flags.is_evpe_present)
    {
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->evpe) & 0xFF);
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->evpe >> 8) & 0xFF);
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->evpe >> 16) & 0xFF);
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->evpe >> 24) & 0xFF);
    }
    if (p_app_value->flags.is_hdop_present)
    {
        p_gatt_value->p_value[pos++] = p_app_value->hdop;
    }
    if (p_app_value->flags.is_vdop_present)
    {
        p_gatt_value->p_value[pos++] = p_app_value->vdop;
    }

    return BLE_SUCCESS;
}

/* Position Quality characteristic definition */
static const st_ble_servs_char_info_t gs_position_quality_char = {
    .start_hdl    = BLE_LNS_POSITION_QUALITY_DECL_HDL,
    .end_hdl      = BLE_LNS_POSITION_QUALITY_VAL_HDL,
    .char_idx     = BLE_LNS_POSITION_QUALITY_IDX,
    .app_size     = sizeof(st_ble_lns_position_quality_t),
    .db_size      = BLE_LNS_POSITION_QUALITY_LEN,
    .decode       = (ble_servs_attr_decode_t)decode_st_ble_lns_position_quality_t,
    .encode       = (ble_servs_attr_encode_t)encode_st_ble_lns_position_quality_t,
};

ble_status_t R_BLE_LNS_SetPositionQuality(const st_ble_lns_position_quality_t *p_value)
{
    return R_BLE_SERVS_SetChar(&gs_position_quality_char, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_LNS_GetPositionQuality(st_ble_lns_position_quality_t *p_value)
{
    return R_BLE_SERVS_GetChar(&gs_position_quality_char, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    LN Control Point Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

static const st_ble_servs_desc_info_t gs_cp_cli_cnfg = {
    .attr_hdl = BLE_LNS_CP_CLI_CNFG_DESC_HDL,
    .app_size = sizeof(uint16_t),
    .desc_idx = BLE_LNS_CP_CLI_CNFG_IDX,
    .db_size  = BLE_LNS_CP_CLI_CNFG_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_uint16_t,
    .encode   = (ble_servs_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_LNS_SetCpCliCnfg(uint16_t conn_hdl, const uint16_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_cp_cli_cnfg, conn_hdl, (const void *)p_value);
}

ble_status_t R_BLE_LNS_GetCpCliCnfg(uint16_t conn_hdl, uint16_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_cp_cli_cnfg, conn_hdl, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    LN Control Point characteristic
----------------------------------------------------------------------------------------------------------------------*/
static bool gs_cp_in_progress = false;
static bool gs_length_invalid = false;

static ble_status_t decode_st_ble_lns_cp_t(st_ble_lns_cp_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint16_t pv_len = 0;
    
    p_app_value->op_codes = p_gatt_value->p_value[0];

    switch(p_app_value->op_codes)
    {
        case BLE_LNS_CP_OP_CODES_SET_CUMULATIVE_VALUE:
        case BLE_LNS_CP_OP_CODES_SET_ELEVATION:
        {
            pv_len = 3;
        } break;

        case BLE_LNS_CP_OP_CODES_MASK_LOCATION_AND_SPEED_CHARACTERISTIC_CONTENT:
        case BLE_LNS_CP_OP_CODES_SELECT_ROUTE:
        case BLE_LNS_CP_OP_CODES_REQUEST_NAME_OF_ROUTE:
        {
            pv_len = 2;
        } break;

        case BLE_LNS_CP_OP_CODES_NAVIGATION_CONTROL:
        case BLE_LNS_CP_OP_CODES_SET_FIX_RATE:
        {
            pv_len = 1;
        } break;

        case BLE_LNS_CP_OP_CODES_REQUEST_NUMBER_OF_ROUTES:
        {
            pv_len = 0;
        } break;

        default:
        {
            /* do_nothing */
        } break;
    }

    st_ble_gatt_value_t pv_val = {
            .value_len = pv_len,
            .p_value = &p_gatt_value->p_value[1],
    };
    decode_st_ble_seq_data_t(&p_app_value->parameter_value, &pv_val);

    if((p_gatt_value->value_len - 1) != pv_len)
    {
        p_app_value->response_value = BLE_LNS_CP_RESPONSE_VALUE_INVALID_PARAMETER;
    }

    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_lns_cp_t(const st_ble_lns_cp_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;
    p_gatt_value->p_value[pos++] = p_app_value->op_codes;

    if (0 != p_app_value->parameter_value.len)
    {
        st_ble_gatt_value_t pv_val = {
            .value_len = p_app_value->parameter_value.len,
            .p_value = &p_gatt_value->p_value[pos]
        };
        encode_st_ble_seq_data_t(&p_app_value->parameter_value, &pv_val);
        pos += p_app_value->parameter_value.len;
    }

    if (BLE_LNS_CP_OP_CODES_RESPONSE_CODE == p_app_value->op_codes)
    {
        p_gatt_value->p_value[pos++] = p_app_value->request_op_code;
        p_gatt_value->p_value[pos++] = p_app_value->response_value;
    }

    if (0 != p_app_value->response_parameter.len)
    {
        st_ble_gatt_value_t rp_val = {
            .value_len = p_app_value->response_parameter.len,
            .p_value = &p_gatt_value->p_value[pos]
        };
        encode_st_ble_seq_data_t(&p_app_value->response_parameter, &rp_val);
    }

    return BLE_SUCCESS;
}

static void cp_write_req_cb(const void *vp_attr, uint16_t conn_hdl, ble_status_t result, const void *vp_app_value)
{
    UNUSED_ARG(vp_attr);
    UNUSED_ARG(result);

    const st_ble_lns_cp_t *p_app_value = (const st_ble_lns_cp_t *)vp_app_value;
    uint16_t cp_clicfg = 0;

    st_ble_servs_evt_data_t evt_data = {
        .conn_hdl = conn_hdl,
        .param_len = sizeof(st_ble_lns_cp_t),
        .p_param = p_app_value,
    };

    if(gs_cp_in_progress)
    {
        R_BLE_GATTS_SendErrRsp(BLE_ERR_GATT_PROC_ALREADY_IN_PROGRESS);
        return;
    }

    R_BLE_LNS_GetCpCliCnfg(conn_hdl, &cp_clicfg);
    if(0 == (cp_clicfg & BLE_GATTS_CLI_CNFG_INDICATION))
    {
        R_BLE_GATTS_SendErrRsp(BLE_ERR_GATT_CCCD_IMPROPERLY_CFG);
        return;
    }

    R_BLE_LNS_GetNavigationCliCnfg(conn_hdl, &cp_clicfg);
    if((0 == (cp_clicfg & BLE_GATTS_CLI_CNFG_NOTIFICATION)) &&
       (BLE_LNS_CP_OP_CODES_NAVIGATION_CONTROL == p_app_value->op_codes))
    {
        R_BLE_GATTS_SendErrRsp(BLE_ERR_GATT_CCCD_IMPROPERLY_CFG);
        return;
    }

    if(BLE_LNS_CP_RESPONSE_VALUE_INVALID_PARAMETER == p_app_value->response_value)
    {
        gs_length_invalid = true;
    }

    gs_cp_in_progress = true;
    gs_servs_info.cb(BLE_LNS_EVENT_CP_WRITE_REQ, BLE_SUCCESS, &evt_data);
}

static void cp_write_comp_cb(const void *vp_attr, uint16_t conn_hdl, ble_status_t result, const void *vp_app_value) // @suppress("Function length")
{
    UNUSED_ARG(vp_attr);
    UNUSED_ARG(result);

    const st_ble_lns_cp_t *p_app_value = (const st_ble_lns_cp_t *)vp_app_value;

    st_ble_lns_cp_t ind_cp_data = {
        .op_codes = BLE_LNS_CP_OP_CODES_RESPONSE_CODE,
        .response_value = BLE_LNS_CP_RESPONSE_VALUE_SUCCESS,
        .request_op_code = p_app_value->op_codes,
        .parameter_value.len = 0,
        .response_parameter.len = 0,
    };

    st_ble_servs_evt_data_t evt_data = {
        .conn_hdl = conn_hdl,
        .param_len = sizeof(st_ble_lns_cp_t),
        .p_param = p_app_value,
    };

    st_ble_lns_feat_t feat_data;
    R_BLE_LNS_GetFeat(&feat_data);

    if(gs_length_invalid)
    {
        ind_cp_data.response_value = BLE_LNS_CP_RESPONSE_VALUE_INVALID_PARAMETER;
        R_BLE_LNS_IndicateCp(conn_hdl, &ind_cp_data);
        gs_length_invalid = false;
        return;
    }

    switch(p_app_value->op_codes)
    {
        case BLE_LNS_CP_OP_CODES_SET_CUMULATIVE_VALUE:
        {
            if (feat_data.is_total_distance_supported)
            {
                gs_servs_info.cb(BLE_LNS_EVENT_CP_WRITE_COMP, BLE_SUCCESS, &evt_data);
                R_BLE_LNS_IndicateCp(conn_hdl, &ind_cp_data);
            }
            else
            {
                ind_cp_data.response_value = BLE_LNS_CP_RESPONSE_VALUE_OP_CODE_NOT_SUPPORTED;
                R_BLE_LNS_IndicateCp(conn_hdl, &ind_cp_data);
            }
        } break;

        case BLE_LNS_CP_OP_CODES_MASK_LOCATION_AND_SPEED_CHARACTERISTIC_CONTENT:
        {
            if (LOCATION_AND_SPEED_SUPPORTED)
            {
                if ((0x80 <= p_app_value->parameter_value.data[0]) ||
                    (0x01 <= p_app_value->parameter_value.data[1]))
                {
                    ind_cp_data.response_value = BLE_LNS_CP_RESPONSE_VALUE_INVALID_PARAMETER;
                    R_BLE_LNS_IndicateCp(conn_hdl, &ind_cp_data);
                }
                else
                {
                    gs_servs_info.cb(BLE_LNS_EVENT_CP_WRITE_COMP, BLE_SUCCESS, &evt_data);
                    R_BLE_LNS_IndicateCp(conn_hdl, &ind_cp_data);
                }
            }
            else
            {
                ind_cp_data.response_value = BLE_LNS_CP_RESPONSE_VALUE_OP_CODE_NOT_SUPPORTED;
                R_BLE_LNS_IndicateCp(conn_hdl, &ind_cp_data);
            }
        } break;

        case BLE_LNS_CP_OP_CODES_NAVIGATION_CONTROL:
        {
            if (NAVIGATION_SUPPORTED)
            {
                if (0x06 <= p_app_value->parameter_value.data[0])
                {
                    ind_cp_data.response_value = BLE_LNS_CP_RESPONSE_VALUE_INVALID_PARAMETER;
                    R_BLE_LNS_IndicateCp(conn_hdl, &ind_cp_data);
                }
                else
                {
                    gs_servs_info.cb(BLE_LNS_EVENT_CP_WRITE_COMP, BLE_SUCCESS, &evt_data);
                    R_BLE_LNS_IndicateCp(conn_hdl, &ind_cp_data);
                }
            }
            else
            {
                ind_cp_data.response_value = BLE_LNS_CP_RESPONSE_VALUE_OP_CODE_NOT_SUPPORTED;
                R_BLE_LNS_IndicateCp(conn_hdl, &ind_cp_data);
            }
        } break;

        case BLE_LNS_CP_OP_CODES_REQUEST_NUMBER_OF_ROUTES:
        {
            if(NAVIGATION_SUPPORTED)
            {
                gs_servs_info.cb(BLE_LNS_EVENT_CP_WRITE_COMP, BLE_SUCCESS, &evt_data);
            }
            else
            {
                ind_cp_data.response_value = BLE_LNS_CP_RESPONSE_VALUE_OP_CODE_NOT_SUPPORTED;
                R_BLE_LNS_IndicateCp(conn_hdl, &ind_cp_data);
            }
        } break;

        case BLE_LNS_CP_OP_CODES_REQUEST_NAME_OF_ROUTE:
        {
            if (NAVIGATION_SUPPORTED)
            {
                gs_servs_info.cb(BLE_LNS_EVENT_CP_WRITE_COMP, BLE_SUCCESS, &evt_data);
            }
            else
            {
                ind_cp_data.response_value = BLE_LNS_CP_RESPONSE_VALUE_OP_CODE_NOT_SUPPORTED;
                R_BLE_LNS_IndicateCp(conn_hdl, &ind_cp_data);
            }
        } break;

        case BLE_LNS_CP_OP_CODES_SELECT_ROUTE:
        {
            if (NAVIGATION_SUPPORTED)
            {
                gs_servs_info.cb(BLE_LNS_EVENT_CP_WRITE_COMP, BLE_SUCCESS, &evt_data);
                R_BLE_LNS_IndicateCp(conn_hdl, &ind_cp_data);
            }
            else
            {
                ind_cp_data.response_value = BLE_LNS_CP_RESPONSE_VALUE_OP_CODE_NOT_SUPPORTED;
                R_BLE_LNS_IndicateCp(conn_hdl, &ind_cp_data);
            }
        } break;

        case BLE_LNS_CP_OP_CODES_SET_FIX_RATE:
        {
            if (feat_data.is_fix_rate_setting_supported)
            {
                gs_servs_info.cb(BLE_LNS_EVENT_CP_WRITE_COMP, BLE_SUCCESS, &evt_data);
                R_BLE_LNS_IndicateCp(conn_hdl, &ind_cp_data);
            }
            else
            {
                ind_cp_data.response_value = BLE_LNS_CP_RESPONSE_VALUE_OP_CODE_NOT_SUPPORTED;
                R_BLE_LNS_IndicateCp(conn_hdl, &ind_cp_data);
            }
        } break;

        case BLE_LNS_CP_OP_CODES_SET_ELEVATION:
        {
            if (feat_data.is_elevation_setting_supported)
            {
                gs_servs_info.cb(BLE_LNS_EVENT_CP_WRITE_COMP, BLE_SUCCESS, &evt_data);
                R_BLE_LNS_IndicateCp(conn_hdl, &ind_cp_data);
            }
            else
            {
                ind_cp_data.response_value = BLE_LNS_CP_RESPONSE_VALUE_OP_CODE_NOT_SUPPORTED;
                R_BLE_LNS_IndicateCp(conn_hdl, &ind_cp_data);
            }
        } break;

        default:
        {
            ind_cp_data.response_value = BLE_LNS_CP_RESPONSE_VALUE_OP_CODE_NOT_SUPPORTED;
            R_BLE_LNS_IndicateCp(conn_hdl, &ind_cp_data);
        }
    }
}

static void cp_hdl_val_cnf_cb(const void *vp_attr, uint16_t conn_hdl)
{
    UNUSED_ARG(vp_attr);
    UNUSED_ARG(conn_hdl);

    gs_cp_in_progress = false;
}

/* LN Control Point characteristic descriptor definition */
static const st_ble_servs_desc_info_t *gspp_cp_descs[] = {
    &gs_cp_cli_cnfg,
};

/* LN Control Point characteristic definition */
static const st_ble_servs_char_info_t gs_cp_char = {
    .start_hdl      = BLE_LNS_CP_DECL_HDL,
    .end_hdl        = BLE_LNS_CP_CLI_CNFG_DESC_HDL,
    .char_idx       = BLE_LNS_CP_IDX,
    .app_size       = sizeof(st_ble_lns_cp_t),
    .db_size        = BLE_LNS_CP_LEN,
    .write_req_cb   = cp_write_req_cb,
    .write_comp_cb  = cp_write_comp_cb,
    .hdl_val_cnf_cb = cp_hdl_val_cnf_cb,
    .decode         = (ble_servs_attr_decode_t)decode_st_ble_lns_cp_t,
    .encode         = (ble_servs_attr_encode_t)encode_st_ble_lns_cp_t,
    .pp_descs       = gspp_cp_descs,
    .num_of_descs   = ARRAY_SIZE(gspp_cp_descs),
};

ble_status_t R_BLE_LNS_IndicateCp(uint16_t conn_hdl, const st_ble_lns_cp_t *p_value)
{
    ble_status_t ret;
    uint16_t ind_size;

    if (NULL == p_value)
    {
        return BLE_ERR_INVALID_ARG;
    }

    if (BLE_GAP_INVALID_CONN_HDL == conn_hdl)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_LNS_CP_OP_CODES_RESPONSE_CODE == p_value->op_codes)
    {
        ind_size = (uint16_t)(3 + p_value->parameter_value.len + p_value->response_parameter.len);
    }
    else
    {
        ind_size = (uint16_t)(1 + p_value->parameter_value.len);
    }

    void *p_gatt_value = malloc(ind_size);
    if (NULL == p_gatt_value)
    {
        return BLE_ERR_MEM_ALLOC_FAILED;
    }

    st_ble_gatt_hdl_value_pair_t hdl_val_data = {
        .attr_hdl        = (uint16_t)(gs_cp_char.start_hdl + 1),
        .value.value_len = ind_size,
        .value.p_value   = (uint8_t *)p_gatt_value,
    };

    ret = gs_cp_char.encode(p_value, &hdl_val_data.value);

    if (BLE_SUCCESS == ret)
    {
        ret = R_BLE_GATTS_Indication(conn_hdl, &hdl_val_data);
    }

    free(p_gatt_value);
    return ret;
}

/*----------------------------------------------------------------------------------------------------------------------
    Navigation Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

static const st_ble_servs_desc_info_t gs_navigation_cli_cnfg = {
    .attr_hdl = BLE_LNS_NAVIGATION_CLI_CNFG_DESC_HDL,
    .app_size = sizeof(uint16_t),
    .desc_idx = BLE_LNS_NAVIGATION_CLI_CNFG_IDX,
    .db_size  = BLE_LNS_NAVIGATION_CLI_CNFG_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_uint16_t,
    .encode   = (ble_servs_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_LNS_SetNavigationCliCnfg(uint16_t conn_hdl, const uint16_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_navigation_cli_cnfg, conn_hdl, (const void *)p_value);
}

ble_status_t R_BLE_LNS_GetNavigationCliCnfg(uint16_t conn_hdl, uint16_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_navigation_cli_cnfg, conn_hdl, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Navigation characteristic
----------------------------------------------------------------------------------------------------------------------*/

static ble_status_t encode_st_ble_lns_navigation_t(const st_ble_lns_navigation_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 6;
    p_gatt_value->p_value[0] = (uint8_t)((p_app_value->flags.is_remaining_distance_present & 0x01) |
                               ((p_app_value->flags.is_remaining_vertical_distance_present & 0x01) << 1) |
                               ((p_app_value->flags.is_estimated_time_of_arrival_present & 0x01) << 2) |
                               ((p_app_value->flags.position_status & 0x03) << 3) |
                               ((p_app_value->flags.is_heading_source & 0x01) << 5) |
                               ((p_app_value->flags.is_navigation_indicator_type & 0x01) << 6) |
                               ((p_app_value->flags.is_waypoint_reached & 0x01) << 7));
    p_gatt_value->p_value[1] = (uint8_t)(p_app_value->flags.is_destination_reached & 0x01);
    p_gatt_value->p_value[2] = (uint8_t)(p_app_value->bearing & 0xFF);
    p_gatt_value->p_value[3] = (uint8_t)((p_app_value->bearing >> 8) & 0xFF);
    p_gatt_value->p_value[4] = (uint8_t)(p_app_value->heading & 0xFF);
    p_gatt_value->p_value[5] = (uint8_t)((p_app_value->heading >> 8) & 0xFF);
    
    if (p_app_value->flags.is_remaining_distance_present)
    {
        p_gatt_value->p_value[pos++] = (uint8_t)(p_app_value->remaining_distance & 0xFF);
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->remaining_distance >> 8) & 0xFF);
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->remaining_distance >> 16) & 0xFF);
    }
    if (p_app_value->flags.is_remaining_vertical_distance_present)
    {
        p_gatt_value->p_value[pos++] = (uint8_t)(p_app_value->remaining_vertical_distance & 0xFF);
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->remaining_vertical_distance >> 8) & 0xFF);
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->remaining_vertical_distance >> 16) & 0xFF);
    }
    if (p_app_value->flags.is_estimated_time_of_arrival_present)
    {
        p_gatt_value->p_value[pos++] = (uint8_t)(p_app_value->estimated_time_of_arrival.year & 0xFF);
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->estimated_time_of_arrival.year >> 8) & 0xFF);
        p_gatt_value->p_value[pos++] = p_app_value->estimated_time_of_arrival.month;
        p_gatt_value->p_value[pos++] = p_app_value->estimated_time_of_arrival.day;
        p_gatt_value->p_value[pos++] = p_app_value->estimated_time_of_arrival.hours;
        p_gatt_value->p_value[pos++] = p_app_value->estimated_time_of_arrival.minutes;
        p_gatt_value->p_value[pos++] = p_app_value->estimated_time_of_arrival.seconds;
    }

    return BLE_SUCCESS;
}

/* Navigation characteristic descriptor definition */
static const st_ble_servs_desc_info_t *gspp_navigation_descs[] = {
    &gs_navigation_cli_cnfg,
};

/* Navigation characteristic definition */
static const st_ble_servs_char_info_t gs_navigation_char = {
    .start_hdl    = BLE_LNS_NAVIGATION_DECL_HDL,
    .end_hdl      = BLE_LNS_NAVIGATION_CLI_CNFG_DESC_HDL,
    .char_idx     = BLE_LNS_NAVIGATION_IDX,
    .app_size     = sizeof(st_ble_lns_navigation_t),
    .db_size      = BLE_LNS_NAVIGATION_LEN,
    .encode       = (ble_servs_attr_encode_t)encode_st_ble_lns_navigation_t,
    .pp_descs     = gspp_navigation_descs,
    .num_of_descs = ARRAY_SIZE(gspp_navigation_descs),
};

ble_status_t R_BLE_LNS_NotifyNavigation(uint16_t conn_hdl, const st_ble_lns_navigation_t *p_value)
{
    ble_status_t ret;
    uint16_t ntf_size = (uint16_t)((p_value->flags.is_remaining_distance_present * 3) +
        (p_value->flags.is_remaining_vertical_distance_present * 3) +
        (p_value->flags.is_estimated_time_of_arrival_present * 7) + 6);

    if (NULL == p_value)
    {
        return BLE_ERR_INVALID_ARG;
    }

    if (BLE_GAP_INVALID_CONN_HDL == conn_hdl)
    {
        return BLE_ERR_INVALID_HDL;
    }

    void *p_gatt_value = malloc((size_t)ntf_size);

    if (NULL == p_gatt_value)
    {
        return BLE_ERR_MEM_ALLOC_FAILED;
    }

    st_ble_gatt_hdl_value_pair_t hdl_val_data = {
        .attr_hdl        = (uint16_t)(gs_navigation_char.start_hdl + 1),
        .value.value_len = ntf_size,
        .value.p_value   = (uint8_t *)p_gatt_value,
    };

    ret = gs_navigation_char.encode(p_value, &hdl_val_data.value);

    if (BLE_SUCCESS == ret)
    {
        ret = R_BLE_GATTS_Notification(conn_hdl, &hdl_val_data);
    }

    free(p_gatt_value);
    return ret;
}

/*----------------------------------------------------------------------------------------------------------------------
    Location and Navigation server
----------------------------------------------------------------------------------------------------------------------*/

/* Location and Navigation characteristics definition */
static const st_ble_servs_char_info_t *gspp_chars[] = {
    &gs_feat_char,
    &gs_location_and_speed_char,
    &gs_position_quality_char,
    &gs_cp_char,
    &gs_navigation_char,
};

/* Location and Navigation service definition */
static st_ble_servs_info_t gs_servs_info = {
    .pp_chars     = gspp_chars,
    .num_of_chars = ARRAY_SIZE(gspp_chars),
};

ble_status_t R_BLE_LNS_Init(ble_servs_app_cb_t cb)
{
    if (NULL == cb)
    {
        return BLE_ERR_INVALID_PTR;
    }

    gs_servs_info.cb = cb;

    return R_BLE_SERVS_RegisterServer(&gs_servs_info);
}

ble_status_t R_BLE_LNS_SetMtu(uint16_t *mtu)
{
    gs_mtu_size = *mtu;
    return BLE_SUCCESS;
}

