/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_lns.h
 * Version : 1.0
 * Description : The header file for Location and Navigation service.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 31.12.2999 1.00 First Release
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @file
 * @defgroup lns Location and Navigation Service Server
 * @{
 * @ingroup profile
 * @brief   This service exposes location and navigation-related data from a Location and Navigation sensor intended for outdoor activity applications.
 **********************************************************************************************************************/
#include "profile_cmn/r_ble_servs_if.h"
#include "gatt_db.h"

#ifndef R_BLE_LNS_H
#define R_BLE_LNS_H

#define LOCATION_AND_SPEED_SUPPORTED (1)
#define NAVIGATION_SUPPORTED (1)

/*----------------------------------------------------------------------------------------------------------------------
    LN Feature Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/***************************************************************************//**
 * @brief LN Feature value structure.
*******************************************************************************/
typedef struct {
    bool is_instantaneous_speed_supported; /**< Instantaneous Speed Supported */
    bool is_total_distance_supported; /**< Total Distance Supported */
    bool is_location_supported; /**< Location Supported */
    bool is_elevation_supported; /**< Elevation Supported */
    bool is_heading_supported; /**< Heading Supported */
    bool is_rolling_time_supported; /**< Rolling Time Supported */
    bool is_utc_time_supported; /**< UTC Time Supported */
    bool is_remaining_distance_supported; /**< Remaining Distance Supported */
    bool is_remaining_vertical_distance_supported; /**< Remaining Vertical Distance Supported */
    bool is_estimated_time_of_arrival_supported; /**< Estimated Time of Arrival Supported */
    bool is_number_of_beacons_in_solution_supported; /**< Number of Beacons in Solution Supported */
    bool is_number_of_beacons_in_view_supported; /**< Number of Beacons in View Supported */
    bool is_time_to_first_fix_supported; /**< Time to First Fix Supported */
    bool is_estimated_horizontal_position_error_supported; /**< Estimated Horizontal Position Error Supported */
    bool is_estimated_vertical_position_error_supported; /**< Estimated Vertical Position Error Supported */
    bool is_horizontal_dilution_of_precision_supported; /**< Horizontal Dilution of Precision Supported */
    bool is_vertical_dilution_of_precision_supported; /**< Vertical Dilution of Precision Supported */
    bool is_location_and_speed_characteristic_content_masking_supported; /**< Location and Speed Characteristic Content Masking Supported */
    bool is_fix_rate_setting_supported; /**< Fix Rate Setting Supported */
    bool is_elevation_setting_supported; /**< Elevation Setting Supported */
    bool is_position_status_supported; /**< Position Status Supported */
} st_ble_lns_feat_t;

/***************************************************************************//**
 * @brief     Set LN Feature characteristic value to the local GATT database.
 * @param[in] p_value  Characteristic value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_LNS_SetFeat(const st_ble_lns_feat_t *p_value);

/***************************************************************************//**
 * @brief     Get LN Feature characteristic value from the local GATT database.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_LNS_GetFeat(st_ble_lns_feat_t *p_value);

/*----------------------------------------------------------------------------------------------------------------------
    Location and Speed Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/***************************************************************************//**
 * @brief Location and Speed Flags value structure.
*******************************************************************************/
typedef struct {
    bool is_instantaneous_speed_present; /**< Instantaneous Speed Present */
    bool is_total_distance_present; /**< Total Distance Present */
    bool is_location_present; /**< Location Present */
    bool is_elevation_present; /**< Elevation Present */
    bool is_heading_present; /**< Heading Present */
    bool is_rolling_time_present; /**< Rolling Time Present */
    bool is_utc_time_present; /**< UTC Time Present */
    uint8_t position_status; /**< Position Status */
    bool is_speed_and_distance_format; /**< Speed and Distance format */
    uint8_t elevation_source; /**< Elevation Source */
    bool is_heading_source; /**< Heading Source */
} st_ble_lns_location_and_speed_flags_t;

/***************************************************************************//**
 * @brief Location and Speed value structure.
*******************************************************************************/
typedef struct {
    st_ble_lns_location_and_speed_flags_t flags; /**< Flags */
    uint16_t instantaneous_speed; /**< Instantaneous Speed */
    uint32_t total_distance; /**< Total Distance */
    int32_t latitude; /**< Location - Latitude */
    int32_t longitude; /**< Location - Longitude */
    int32_t elevation; /**< Elevation */
    uint16_t heading; /**< Heading */
    uint8_t rolling_time; /**< Rolling Time */
    st_ble_date_time_t utc_time; /**< UTC Time */
} st_ble_lns_location_and_speed_t;

/***************************************************************************//**
 * @brief     Send notification of  Location and Speed characteristic value to the remote device.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value  Characteristic value to send.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_LNS_NotifyLocationAndSpeed(uint16_t conn_hdl, const st_ble_lns_location_and_speed_t *p_value);

/***************************************************************************//**
 * @brief     Set Location and Speed cli cnfg descriptor value to the local GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_LNS_SetLocationAndSpeedCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Get Location and Speed cli cnfg descriptor value from the local GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_LNS_GetLocationAndSpeedCliCnfg(uint16_t conn_hdl, uint16_t *p_value);

/*----------------------------------------------------------------------------------------------------------------------
    Position Quality Characteristic
----------------------------------------------------------------------------------------------------------------------*/
      
/***************************************************************************//**
 * @brief Position Quality Flags value structure.
*******************************************************************************/
typedef struct {
    bool is_number_of_beacons_in_solution_present; /**< Number of Beacons in Solution Present */
    bool is_number_of_beacons_in_view_present; /**< Number of Beacons in View Present */
    bool is_time_to_first_fix_present; /**< Time to First Fix Present */
    bool is_ehpe_present; /**< EHPE Present */
    bool is_evpe_present; /**< EVPE Present */
    bool is_hdop_present; /**< HDOP Present */
    bool is_vdop_present; /**< VDOP Present */
    uint8_t position_status; /**< Position Status */
} st_ble_lns_position_quality_flags_t;

/***************************************************************************//**
 * @brief Position Quality value structure.
*******************************************************************************/
typedef struct {
    st_ble_lns_position_quality_flags_t flags; /**< Flags */
    uint8_t number_of_beacons_in_solution; /**< Number of Beacons in Solution */
    uint8_t number_of_beacons_in_view; /**< Number of Beacons in View */
    uint16_t time_to_first_fix; /**< Time to First Fix */
    uint32_t ehpe; /**< EHPE */
    uint32_t evpe; /**< EVPE */
    uint8_t hdop; /**< HDOP */
    uint8_t vdop; /**< VDOP */
} st_ble_lns_position_quality_t;

/***************************************************************************//**
 * @brief     Set Position Quality characteristic value to the local GATT database.
 * @param[in] p_value  Characteristic value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_LNS_SetPositionQuality(const st_ble_lns_position_quality_t *p_value);

/***************************************************************************//**
 * @brief     Get Position Quality characteristic value from the local GATT database.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_LNS_GetPositionQuality(st_ble_lns_position_quality_t *p_value);

/*----------------------------------------------------------------------------------------------------------------------
    LN Control Point Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/***************************************************************************//**
 * @brief LN Control Point Op Codes enumeration.
*******************************************************************************/
typedef enum {
    BLE_LNS_CP_OP_CODES_SET_CUMULATIVE_VALUE = 1, /**< Set Cumulative Value */
    BLE_LNS_CP_OP_CODES_MASK_LOCATION_AND_SPEED_CHARACTERISTIC_CONTENT = 2, /**< Mask Location and Speed Characteristic Content */
    BLE_LNS_CP_OP_CODES_NAVIGATION_CONTROL = 3, /**< Navigation Control */
    BLE_LNS_CP_OP_CODES_REQUEST_NUMBER_OF_ROUTES = 4, /**< Request Number of Routes */
    BLE_LNS_CP_OP_CODES_REQUEST_NAME_OF_ROUTE = 5, /**< Request Name of Route */
    BLE_LNS_CP_OP_CODES_SELECT_ROUTE = 6, /**< Select Route */
    BLE_LNS_CP_OP_CODES_SET_FIX_RATE = 7, /**< Set Fix Rate */
    BLE_LNS_CP_OP_CODES_SET_ELEVATION = 8, /**< Set Elevation */
    BLE_LNS_CP_OP_CODES_RESPONSE_CODE = 32, /**< Response Code */
} e_ble_lns_cp_op_codes_t;

/***************************************************************************//**
 * @brief LN Control Point Response Value enumeration.
*******************************************************************************/
typedef enum {
    BLE_LNS_CP_RESPONSE_VALUE_SUCCESS = 1, /**< Success */
    BLE_LNS_CP_RESPONSE_VALUE_OP_CODE_NOT_SUPPORTED = 2, /**< Op Code not Supported */
    BLE_LNS_CP_RESPONSE_VALUE_INVALID_PARAMETER = 3, /**< Invalid Parameter */
    BLE_LNS_CP_RESPONSE_VALUE_OPERATION_FAILED = 4, /**< Operation Failed */
} e_ble_lns_cp_response_value_t;

/***************************************************************************//**
 * @brief LN Control Point Navigation Control Value enumeration.
*******************************************************************************/
typedef enum {
    BLE_LNS_CP_NAVIGATION_CONTROL_VALUE_STOP_NAVIGATION = 0,
    BLE_LNS_CP_NAVIGATION_CONTROL_VALUE_START_NAVIGATION = 1,
    BLE_LNS_CP_NAVIGATION_CONTROL_VALUE_PAUSE_NAVIGATION = 2,
    BLE_LNS_CP_NAVIGATION_CONTROL_VALUE_CONTINUE_NAVIGATION = 3,
    BLE_LNS_CP_NAVIGATION_CONTROL_VALUE_SKIP_WAYPOINT = 4,
    BLE_LNS_CP_NAVIGATION_CONTROL_VALUE_SELECT_NEAREST_WAYPOINT_ON_A_ROUTE = 5
} e_ble_lns_cp_navigation_control_value_t;

/***************************************************************************//**
 * @brief LN Control Point value structure.
*******************************************************************************/
typedef struct {
    uint8_t op_codes; /**< Op Codes */
    st_ble_seq_data_t parameter_value; /**< Parameter Value */
    uint8_t request_op_code; /**< Request Op Code */
    uint8_t response_value; /**< Response Value */
    st_ble_seq_data_t response_parameter; /**< Response Parameter */
} st_ble_lns_cp_t;

/***************************************************************************//**
 * @brief     Send indication of  LN Control Point characteristic value to the remote device.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value  Characteristic value to send.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_LNS_IndicateCp(uint16_t conn_hdl, const st_ble_lns_cp_t *p_value);

/***************************************************************************//**
 * @brief     Set LN Control Point cli cnfg descriptor value to the local GATT database.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_LNS_SetCpCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Get LN Control Point cli cnfg descriptor value from the local GATT database.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_LNS_GetCpCliCnfg(uint16_t conn_hdl, uint16_t *p_value);

/*----------------------------------------------------------------------------------------------------------------------
    Navigation Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/***************************************************************************//**
 * @brief Navigation Flags value structure.
*******************************************************************************/
typedef struct {
    bool is_remaining_distance_present; /**< Remaining Distance Present */
    bool is_remaining_vertical_distance_present; /**< Remaining Vertical Distance Present */
    bool is_estimated_time_of_arrival_present; /**< Estimated Time of Arrival Present */
    uint8_t position_status; /**< Position Status */
    bool is_heading_source; /**< Heading Source */
    bool is_navigation_indicator_type; /**< Navigation Indicator Type */
    bool is_waypoint_reached; /**< Waypoint Reached */
    bool is_destination_reached; /**< Destination Reached */
} st_ble_lns_navigation_flags_t;

/***************************************************************************//**
 * @brief Navigation value structure.
*******************************************************************************/
typedef struct {
    st_ble_lns_navigation_flags_t flags; /**< Flags */
    uint16_t bearing; /**< Bearing */
    uint16_t heading; /**< Heading */
    uint32_t remaining_distance; /**< Remaining Distance */
    int32_t remaining_vertical_distance; /**< Remaining Vertical Distance */
    st_ble_date_time_t estimated_time_of_arrival; /**< Estimated Time of Arrival */
} st_ble_lns_navigation_t;

/***************************************************************************//**
 * @brief     Send notification of  Navigation characteristic value to the remote device.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value  Characteristic value to send.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_LNS_NotifyNavigation(uint16_t conn_hdl, const st_ble_lns_navigation_t *p_value);

/***************************************************************************//**
 * @brief     Set Navigation cli cnfg descriptor value to the local GATT database.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_LNS_SetNavigationCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Get Navigation cli cnfg descriptor value from the local GATT database.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_LNS_GetNavigationCliCnfg(uint16_t conn_hdl, uint16_t *p_value);

/*----------------------------------------------------------------------------------------------------------------------
    Location and Navigation Service
----------------------------------------------------------------------------------------------------------------------*/

/***************************************************************************//**
 * @brief Location and Navigation characteristic Index.
*******************************************************************************/
typedef enum {
    BLE_LNS_FEAT_IDX,
    BLE_LNS_LOCATION_AND_SPEED_IDX,
    BLE_LNS_LOCATION_AND_SPEED_CLI_CNFG_IDX,
    BLE_LNS_POSITION_QUALITY_IDX,
    BLE_LNS_CP_IDX,
    BLE_LNS_CP_CLI_CNFG_IDX,
    BLE_LNS_NAVIGATION_IDX,
    BLE_LNS_NAVIGATION_CLI_CNFG_IDX,
} e_ble_lns_char_idx_t;

/***************************************************************************//**
 * @brief Location and Navigation event type.
*******************************************************************************/
typedef enum {
    /* LN Feature */
    BLE_LNS_EVENT_FEAT_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_LNS_FEAT_IDX, BLE_SERVS_READ_REQ),

    /* Location and Speed */
    BLE_LNS_EVENT_LOCATION_AND_SPEED_CLI_CNFG_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_LNS_LOCATION_AND_SPEED_CLI_CNFG_IDX, BLE_SERVS_WRITE_REQ),
    BLE_LNS_EVENT_LOCATION_AND_SPEED_CLI_CNFG_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_LNS_LOCATION_AND_SPEED_CLI_CNFG_IDX, BLE_SERVS_WRITE_COMP),
    BLE_LNS_EVENT_LOCATION_AND_SPEED_CLI_CNFG_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_LNS_LOCATION_AND_SPEED_CLI_CNFG_IDX, BLE_SERVS_READ_REQ),

    /* Position Quality */
    BLE_LNS_EVENT_POSITION_QUALITY_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_LNS_POSITION_QUALITY_IDX, BLE_SERVS_READ_REQ),

    /* LN Control Point */
    BLE_LNS_EVENT_CP_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_LNS_CP_IDX, BLE_SERVS_WRITE_REQ),
    BLE_LNS_EVENT_CP_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_LNS_CP_IDX, BLE_SERVS_WRITE_COMP),
    BLE_LNS_EVENT_CP_HDL_VAL_CNF = BLE_SERVS_ATTR_EVENT(BLE_LNS_CP_IDX, BLE_SERVS_HDL_VAL_CNF),
    BLE_LNS_EVENT_CP_CLI_CNFG_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_LNS_CP_CLI_CNFG_IDX, BLE_SERVS_WRITE_REQ),
    BLE_LNS_EVENT_CP_CLI_CNFG_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_LNS_CP_CLI_CNFG_IDX, BLE_SERVS_WRITE_COMP),
    BLE_LNS_EVENT_CP_CLI_CNFG_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_LNS_CP_CLI_CNFG_IDX, BLE_SERVS_READ_REQ),

    /* Navigation */
    BLE_LNS_EVENT_NAVIGATION_CLI_CNFG_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_LNS_NAVIGATION_CLI_CNFG_IDX, BLE_SERVS_WRITE_REQ),
    BLE_LNS_EVENT_NAVIGATION_CLI_CNFG_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_LNS_NAVIGATION_CLI_CNFG_IDX, BLE_SERVS_WRITE_COMP),
    BLE_LNS_EVENT_NAVIGATION_CLI_CNFG_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_LNS_NAVIGATION_CLI_CNFG_IDX, BLE_SERVS_READ_REQ),
} e_ble_lns_event_t;

/***************************************************************************//**
 * @brief     Initialize Location and Navigation service.
 * @param[in] cb Service callback.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_LNS_Init(ble_servs_app_cb_t cb);

/***************************************************************************//**
 * @brief     Set current MTU to check Notification.
 * @param[in] mtu  MTU value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_LNS_SetMtu(uint16_t *mtu);

#endif /* R_BLE_LNS_H */

/** @} */
