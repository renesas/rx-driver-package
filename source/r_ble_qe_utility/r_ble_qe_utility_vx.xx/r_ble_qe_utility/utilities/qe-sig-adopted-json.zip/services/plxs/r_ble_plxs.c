/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************//**
* File Name: r_ble_plxs.c
* Version : 1.0
* Description : This module implements Pulse Oximeter Service Server.
**********************************************************************************************************************/
/***********************************************************************************************************************//**
* History : DD.MM.YYYY Version Description
*         : 22.03.2019 1.00 First Release
***********************************************************************************************************************/

/***********************************************************************************************************************//**
* Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <string.h>
#include "r_ble_rx23w_if.h"
#include "r_ble_plxs.h"
#include "r_ble_plxs_record.h"
#include "gatt_db.h"

/***********************************************************************************************************************//**
* Macro definitions
***********************************************************************************************************************/

/* Version number */
#define BLE_PLXS_PRV_VERSION_MAJOR        (1)
#define BLE_PLXS_PRV_VERSION_MINOR        (0)
#define BLE_PLXS_PRV_OPEREND_VALUE        (4)
#define BLE_PLXS_PRV_OPEREND_ABORT_VALUE  (3)

/*******************************************************************************************************************//**
* PLX Spot Check Measurement - Measurement Status Flags Bits Definition.
***********************************************************************************************************************/
#define BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_FLAGS_TIMESTAMP_FIELD_IS_PRESENT                              (1 << 0)
#define BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_FLAGS_MEASUREMENT_STATUS_FIELD_PRESENT                        (1 << 1)
#define BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_FLAGS_DEVICE_AND_SENSOR_STATUS_FIELD_PRESENT                  (1 << 2)
#define BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_FLAGS_PULSE_AMPLITUDE_INDEX_FIELD_IS_PRESENT                  (1 << 3)
#define BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_FLAGS_DEVICE_CLOCK_IS_NOT_SET                                 (1 << 4)

/***********************************************************************************************************************//**
* PLX Spot Check Measurement - Measurement Status Fields Bits Definition.
***********************************************************************************************************************/
#define BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_MEASUREMENT_STATUS_MEASUREMENT_ONGOING                        (1 << 5)
#define BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_MEASUREMENT_STATUS_EARLY_ESTIMATED_DATA                       (1 << 6)
#define BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_MEASUREMENT_STATUS_VALIDATED_DATA                             (1 << 7)
#define BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_MEASUREMENT_STATUS_FULLY_QUALIFIED_DATA                       (1 << 8)
#define BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_MEASUREMENT_STATUS_DATA_FROM_MEASUREMENT_STORAGE              (1 << 9)
#define BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_MEASUREMENT_STATUS_DATA_FOR_DEMONSTRATION                     (1 << 10)
#define BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_MEASUREMENT_STATUS_DATA_FOR_TESTING                           (1 << 11)
#define BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_MEASUREMENT_STATUS_CALIBRATION_ONGOING                        (1 << 12)
#define BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_MEASUREMENT_STATUS_MEASUREMENT_UNAVAILABLE                    (1 << 13)
#define BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_MEASUREMENT_STATUS_QUESTIONABLE_MEASUREMENT_DETECTED          (1 << 14)
#define BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_MEASUREMENT_STATUS_INVALID_MEASUREMENT_DETECTED               (1 << 15)

/**********************************************************************************************************************//**
* PLX Spot Check Measurement - Device and Sensor Status Fields Bits Definition.
***********************************************************************************************************************/
#define BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_EXTENDED_DISPLAY_UPDATE_ONGOING         (1 << 0)
#define BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_EQUIPMENT_MALFUNCTION_DETECTED          (1 << 1)
#define BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SIGNAL_PROCESSING_IRREGULARITY_DETECTED (1 << 2)
#define BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_INADEQUITE_SIGNAL_DETECTED              (1 << 3)
#define BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_POOR_SIGNAL_DETECTED                    (1 << 4)
#define BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_LOW_PERFUSION_DETECTED                  (1 << 5)
#define BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_ERRATIC_SIGNAL_DETECTED                 (1 << 6)
#define BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_NONPULSATILE_SIGNAL_DETECTED            (1 << 7)
#define BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_QUESTIONABLE_PULSE_DETECTED             (1 << 8)
#define BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SIGNAL_ANALYSIS_ONGOING                 (1 << 9)
#define BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SENSOR_INTERFACE_DETECTED               (1 << 10)
#define BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SENSOR_UNCONNECTED_TO_USER              (1 << 11)
#define BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_UNKNOWN_SENSOR_CONNECTED                (1 << 12)
#define BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SENSOR_DISPLACED                        (1 << 13)
#define BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SENSOR_MALFUNCTIONING                   (1 << 14)
#define BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SENSOR_DISCONNECTED                     (1 << 15)

/*******************************************************************************************************************//**
* PLX Continuous Measurement Flags Bits Definition.
***********************************************************************************************************************/
#define BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_FLAGS_SPO2PR_FAST_FIELD_IS_PRESENT                           (1 << 0)
#define BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_FLAGS_SPO2PR_SLOW_FIELD_IS_PRESENT                           (1 << 1)
#define BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_FLAGS_MEASUREMENT_STATUS_FIELD_IS_PRESENT                    (1 << 2)
#define BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_FLAGS_DEVICE_AND_SENSOR_STATUS_FIELD_IS_PRESENT              (1 << 3)
#define BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_FLAGS_PULSE_AMPLITUDE_INDEX_FIELD_IS_PRESENT                 (1 << 4)

/*******************************************************************************************************************//**
* PLX Continuous Measurement - Measurement Status Fields Bits Definition.
***********************************************************************************************************************/
#define BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_MEASUREMENT_STATUS_MEASUREMENT_ONGOING                       (1 << 5)
#define BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_MEASUREMENT_STATUS_EARLY_ESTIMATED_DATA                      (1 << 6)
#define BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_MEASUREMENT_STATUS_VALIDATED_DATA                            (1 << 7)
#define BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_MEASUREMENT_STATUS_FULLY_QUALIFIED_DATA                      (1 << 8)
#define BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_MEASUREMENT_STATUS_DATA_FROM_MEASUREMENT_STORAGE             (1 << 9)
#define BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_MEASUREMENT_STATUS_DATA_FOR_DEMONSTRATION                    (1 << 10)
#define BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_MEASUREMENT_STATUS_DATA_FOR_TESTING                          (1 << 11)
#define BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_MEASUREMENT_STATUS_CALIBRATION_ONGOING                       (1 << 12)
#define BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_MEASUREMENT_STATUS_MEASUREMENT_UNAVAILABLE                   (1 << 13)
#define BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_MEASUREMENT_STATUS_QUESTIONABLE_MEASUREMENT_DETECTED         (1 << 14)
#define BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_MEASUREMENT_STATUS_INVALID_MEASUREMENT_DETECTED              (1 << 15)

/*******************************************************************************************************************//**
* PLX Continuous Measurement - Device and Sensor Status Fields Bits Definition.
***********************************************************************************************************************/
#define BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_EXTENDED_DISPLAY_UPDATE_ONGOING_BIT_SUPPORTED         (1 << 0)
#define BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_EQUIPMENT_MALFUNCTION_DETECTED_BIT_SUPPORTED          (1 << 1)
#define BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SIGNAL_PROCESSING_IRREGULARITY_DETECTED_BIT_SUPPORTED (1 << 2)
#define BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_INADEQUITE_SIGNAL_DETECTED_BIT_SUPPORTED              (1 << 3)
#define BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_POOR_SIGNAL_DETECTED_BIT_SUPPORTED                    (1 << 4)
#define BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_LOW_PERFUSION_DETECTED_BIT_SUPPORTED                  (1 << 5)
#define BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_ERRATIC_SIGNAL_DETECTED_BIT_SUPPORTED                 (1 << 6)
#define BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_NONPULSATILE_SIGNAL_DETECTED_BIT_SUPPORTED            (1 << 7)
#define BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_QUESTIONABLE_PULSE_DETECTED_BIT_SUPPORTED             (1 << 8)
#define BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SIGNAL_ANALYSIS_ONGOING_BIT_SUPPORTED                 (1 << 9)
#define BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SENSOR_INTERFERENCE_DETECTED_BIT_SUPPORTED            (1 << 10)
#define BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SENSOR_UNCONNECTED_TO_USER_BIT_SUPPORTED              (1 << 11)
#define BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_UNKNOWN_SENSOR_CONNECTED_BIT_SUPPORTED                (1 << 12)
#define BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SENSOR_DISPLACED_BIT_SUPPORTED                        (1 << 13)
#define BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SENSOR_MALFUNCTIONING_BIT_SUPPORTED                   (1 << 14)
#define BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SENSOR_DISCONNECTED_BIT_SUPPORTED                     (1 << 15)

/*******************************************************************************************************************//**
* PLX Features Supported Features Fields Bits Definition.
***********************************************************************************************************************/
#define BLE_PLXS_PRV_PLX_FEATURES_SUPPORTED_FEATURES_MEASUREMENT_STATUS_SUPPORT_IS_PRESENT                          (1 << 0)
#define BLE_PLXS_PRV_PLX_FEATURES_SUPPORTED_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_IS_PRESENT                    (1 << 1)
#define BLE_PLXS_PRV_PLX_FEATURES_SUPPORTED_FEATURES_MEASUREMENT_STORAGE_FOR_SPOT_CHECK_MEASUREMENTS_IS_SUPPORTED   (1 << 2)
#define BLE_PLXS_PRV_PLX_FEATURES_SUPPORTED_FEATURES_TIMESTAMP_FOR_SPOT_CHECK_MEASUREMENTS_IS_SUPPORTED             (1 << 3)
#define BLE_PLXS_PRV_PLX_FEATURES_SUPPORTED_FEATURES_SPO2PR_FAST_METRIC_IS_SUPPORTED                                (1 << 4)
#define BLE_PLXS_PRV_PLX_FEATURES_SUPPORTED_FEATURES_SPO2PR_SLOW_METRIC_IS_SUPPORTED                                (1 << 5)
#define BLE_PLXS_PRV_PLX_FEATURES_SUPPORTED_FEATURES_PULSE_AMPLITUDE_INDEX_FIELD_IS_SUPPORTED                       (1 << 6)
#define BLE_PLXS_PRV_PLX_FEATURES_SUPPORTED_FEATURES_MULTIPLE_BONDS_SUPPORTED                                       (1 << 7)

/*******************************************************************************************************************//**
* PLX Features Measurement Status Supported Fields Bits Definition.
***********************************************************************************************************************/
#define BLE_PLXS_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_MEASUREMENT_ONGOING_BIT_SUPPORTED                      (1 << 5)
#define BLE_PLXS_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_EARLY_ESTIMATED_DATA_BIT_SUPPORTED                     (1 << 6)
#define BLE_PLXS_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_VALIDATED_DATA_BIT_SUPPORTED                           (1 << 7)
#define BLE_PLXS_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_FULLY_QUALIFIED_DATA_BIT_SUPPORTED                     (1 << 8)
#define BLE_PLXS_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_DATA_FROM_MEASUREMENT_STORAGE_BIT_SUPPORTED            (1 << 9)
#define BLE_PLXS_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_DATA_FOR_DEMONSTRATION_BIT_SUPPORTED                   (1 << 10)
#define BLE_PLXS_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_DATA_FOR_TESTING_BIT_SUPPORTED                         (1 << 11)
#define BLE_PLXS_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_CALIBRATION_ONGOING_BIT_SUPPORTED                      (1 << 12)
#define BLE_PLXS_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_MEASUREMENT_UNAVAILABLE_BIT_SUPPORTED                  (1 << 13)
#define BLE_PLXS_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_QUESTIONABLE_MEASUREMENT_DETECTED_BIT_SUPPORTED        (1 << 14)
#define BLE_PLXS_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_INVALID_MEASUREMENT_DETECTED_BIT_SUPPORTED             (1 << 15)

/*******************************************************************************************************************//**
* PLX Features Device and Sensor Status Supported Fields Bits Definition.
***********************************************************************************************************************/
#define BLE_PLXS_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_EXTENDED_DISPLAY_UPDATE_ONGOING_BIT_SUPPORTED         (1 << 0)
#define BLE_PLXS_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_EQUIPMENT_MALFUNCTION_DETECTED_BIT_SUPPORTED          (1 << 1)
#define BLE_PLXS_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_SIGNAL_PROCESSING_IRREGULARITY_DETECTED_BIT_SUPPORTED (1 << 2)
#define BLE_PLXS_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_INADEQUITE_SIGNAL_DETECTED_BIT_SUPPORTED              (1 << 3)
#define BLE_PLXS_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_POOR_SIGNAL_DETECTED_BIT_SUPPORTED                    (1 << 4)
#define BLE_PLXS_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_LOW_PERFUSION_DETECTED_BIT_SUPPORTED                  (1 << 5)
#define BLE_PLXS_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_ERRATIC_SIGNAL_DETECTED_BIT_SUPPORTED                 (1 << 6)
#define BLE_PLXS_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_NONPULSATILE_SIGNAL_DETECTED_BIT_SUPPORTED            (1 << 7)
#define BLE_PLXS_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_QUESTIONABLE_PULSE_DETECTED_BIT_SUPPORTED             (1 << 8)
#define BLE_PLXS_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_SIGNAL_ANALYSIS_ONGOING_BIT_SUPPORTED                 (1 << 9)
#define BLE_PLXS_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_SENSOR_INTERFACE_DETECTED_BIT_SUPPORTED               (1 << 10)
#define BLE_PLXS_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_SENSOR_UNCONNECTED_TO_USER_BIT_SUPPORTED              (1 << 11)
#define BLE_PLXS_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_UNKNOWN_SENSOR_CONNECTED_BIT_SUPPORTED                (1 << 12)
#define BLE_PLXS_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_SENSOR_DISPLACED_BIT_SUPPORTED                        (1 << 13)
#define BLE_PLXS_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_SENSOR_MALFUNCTIONING_BIT_SUPPORTED                   (1 << 14)
#define BLE_PLXS_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_SENSOR_DISCONNECTED_BIT_SUPPORTED                     (1 << 15)

#define BLE_PLXS_PRV_RACP_EVENT_ID                                                                                       (11)

/***********************************************************************************************************************//**
* Typedefs
***********************************************************************************************************************/
typedef struct
{
    bool               in_progress;
    bool               is_req_abort;
    uint16_t           current_index;
    uint16_t           num_of_reports;
    uint8_t            racp_opcode;
    uint8_t            racp_operator;
    uint8_t            racp_operand;
    uint8_t            racp_response_code_value;
} st_plxs_info_in_progress_t;


static uint16_t gs_num_of_reports = 1;
static bool gs_indicate_flag      = 0;
static uint16_t num_of_deleted = 0;

static st_ble_plxs_record_t gs_default_record_value =
{
    .valid                  = true,
    .next_index             = 0x0000,
    .prev_index             = 0xFFFF,
    .spot_check_measurement =
    {

        .is_timestamp_present                = true,
        .is_measurement_status_present       = true,
        .is_device_and_sensor_status_present = true,
        .is_pulse_amplitude_index_present    = true,
        .is_device_clock_present             = true,

        .spo2pr_spot_check___spo2 =
        {

            .exponent = 0,
            .mantissa = 10,

        },

        .spo2pr_spot_check___pr =
        {

            .exponent = 0,
            .mantissa = 10,
        },

        .timestamp.year    = 2018,
        .timestamp.month   = 12,
        .timestamp.day     = 5,
        .timestamp.hours   = 3,
        .timestamp.minutes = 19,
        .timestamp.seconds = 34,

        .is_measurement_ongoing                     = true,  /**< Measurement Ongoing */
        .is_early_estimated_data                    = true,  /**< Early Estimated Data */
        .is_validated_data                          = true,  /**< Validated Data */
        .is_fully_qualified_data                    = true,  /**< Fully Qualified Data */
        .is_data_from_measurement_storage           = true,  /**< Data from Measurement Storage */
        .is_data_for_demonstration                  = true,  /**< Data for Demonstration */
        .is_data_for_testing                        = true,  /**< Data for Testing */
        .is_calibration_ongoing                     = true,  /**< Calibration Ongoing */
        .is_measurement_unavailable                 = true,  /**< Measurement Unavailable */
        .is_questionable_measurement_detected       = true,  /**< Questionable Measurement Detected */
        .is_invalid_measurement_detected            = true,  /**< Invalid Measurement Detected */

        .is_extended_display_update_ongoing         = true,  /**< Extended Display Update Ongoing */
        .is_equipment_malfunction_detected          = true,  /**< Equipment Malfunction Detected */
        .is_signal_processing_irregularity_detected = true,  /**< Signal Processing Irregularity Detected */
        .is_inadequate_signal_detected              = true,  /**< Inadequate Signal Detected */
        .is_poor_signal_detected                    = true,  /**< Poor Signal Detected */
        .is_low_perfusion_detected                  = true,  /**< Low Perfusion Detected */
        .is_erratic_perfusion_detected              = true,  /**< Erratic Signal Detected */
        .is_non_pulsatile_signal_detected           = true,  /**< Non-Pulsatile Signal Detected */
        .is_questionable_pulse_detected             = true,  /**< Questionable Pulse Detected */
        .is_signal_analysis_ongoing                 = true,  /**< Signal Analysis Ongoing */
        .is_sensor_interference_detected            = true,  /**< Sensor Interference Detected */
        .is_sensor_unconnected_to_user              = true,  /**< Sensor Unconnected to User */
        .is_unknown_sensor_connected                = true,  /**< Unknown Sensor Connected */
        .is_sensor_displaced                        = true,  /**< Sensor Displaced */
        .is_sensor_malfunctioning                   = true,  /**< Sensor Malfunctioning */
        .is_sensor_disconnected                     = true,  /**< Sensor Disconnected */

        .pulse_amplitude_index =
        {

            .exponent = 0,
            .mantissa = 10,
        },

    },

    .continuous_measurement =
    {

        .is_spo2pr_fast_pr_present           = true,
        .is_spo2pr_slow_pr_present           = true,
        .is_measurement_status_present       = true,
        .is_device_and_sensor_status_present = true,
        .is_pulse_amplitude_index_present    = true,

        .spo2pr_normal___spo2 = 0x01,
        .spo2pr_normal___pr   = 0x10,
        .spo2pr_fast___spo2   = 0x11,
        .spo2pr_fast___pr     = 0x10,
        .spo2pr_slow___spo2   = 0x01,
        .spo2pr_slow___pr     = 0x10,

        .is_measurement_ongoing                     = true,  /**< Measurement Ongoing */
        .is_early_estimated_data                    = true,  /**< Early Estimated Data */
        .is_validated_data                          = true,  /**< Validated Data */
        .is_fully_qualified_data                    = true,  /**< Fully Qualified Data */
        .is_data_from_measurement_storage           = true,  /**< Data from Measurement Storage */
        .is_data_for_demonstration                  = true,  /**< Data for Demonstration */
        .is_data_for_testing                        = true,  /**< Data for Testing */
        .is_calibration_ongoing                     = true,  /**< Calibration Ongoing */
        .is_measurement_unavailable                 = true,  /**< Measurement Unavailable */
        .is_questionable_measurement_detected       = true,  /**< Questionable Measurement Detected */
        .is_invalid_measurement_detected            = true,  /**< Invalid Measurement Detected */

        .is_extended_display_update_ongoing         = true,  /**< Extended Display Update Ongoing */
        .is_equipment_malfunction_detected          = true,  /**< Equipment Malfunction Detected */
        .is_signal_processing_irregularity_detected = true,  /**< Signal Processing Irregularity Detected */
        .is_inadequate_signal_detected              = true,  /**< Inadequate Signal Detected */
        .is_poor_signal_detected                    = true,  /**< Poor Signal Detected */
        .is_low_perfusion_detected                  = true,  /**< Low Perfusion Detected */
        .is_erratic_perfusion_detected              = true,  /**< Erratic Signal Detected */
        .is_non_pulsatile_signal_detected           = true,  /**< Non-Pulsatile Signal Detected */
        .is_questionable_pulse_detected             = true,  /**< Questionable Pulse Detected */
        .is_signal_analysis_ongoing                 = true,  /**< Signal Analysis Ongoing */
        .is_sensor_interference_detected            = true,  /**< Sensor Interference Detected */
        .is_sensor_unconnected_to_user              = true,  /**< Sensor Unconnected to User */
        .is_unknown_sensor_connected                = true,  /**< Unknown Sensor Connected */
        .is_sensor_displaced                        = true,  /**< Sensor Displaced */
        .is_sensor_malfunctioning                   = true,  /**< Sensor Malfunctioning */
        .is_sensor_disconnected                     = true,  /**< Sensor Disconnected */

        .pulse_amplitude_index =
        {
            .exponent = 0,
            .mantissa = 10,
        },
    },
};

/***********************************************************************************************************************//**
* Private global variables and functions
***********************************************************************************************************************/
static uint16_t                     gs_conn_hdl;
static st_plxs_info_in_progress_t   gs_racp_info;
static ble_plxs_app_cb_t            gs_plxs_cb;

static void plxs_racp_event_cb(void);
static void unpack_date_time(st_ble_date_time_t *p_date_time, uint8_t *p_value);

/***********************************************************************************************************************//**
* Function Name: set_cli_cnfg
* Description  : Set Characteristic value notification configuration in local GATT database.
* Arguments    : conn_hdl - handle to connection.
*                attr_hadl - handle to the attribute
*                cli_cnfg - configuration value
* Return Value : ble_status_t
**********************************************************************************************************************/
static ble_status_t set_cli_cnfg(uint16_t conn_hdl, uint16_t attr_hdl, uint16_t cli_cnfg)
{
    uint8_t data[2];

    BT_PACK_LE_2_BYTE(data, &cli_cnfg);

    st_ble_gatt_value_t gatt_value =
    {
        .p_value   = data,
        .value_len = 2,
    };

    return R_BLE_GATTS_SetAttr(conn_hdl, attr_hdl, &gatt_value);
}

/***********************************************************************************************************************//**
* Function Name: get_cli_cnfg
* Description  : Get Characteristic value notification configuration from local GATT database.
* Arguments    : conn_hdl - handle to connection.
*                attr_hadl - handle to the attribute
*                p_cli_cnfg - pointer to variable to store configuration value
* Return Value : ble_status_t
**********************************************************************************************************************/
static ble_status_t get_cli_cnfg(uint16_t conn_hdl, uint16_t attr_hdl, uint16_t *p_cli_cnfg)
{
    ble_status_t ret;
    st_ble_gatt_value_t gatt_value;

    ret = R_BLE_GATTS_GetAttr(conn_hdl, attr_hdl, &gatt_value);

    if (BLE_SUCCESS == ret)
    {
        BT_UNPACK_LE_2_BYTE(p_cli_cnfg, gatt_value.p_value);
    }

    return ret;
}

/***********************************************************************************************************************//**
* Function Name: encode_plx_spot_check_measurement
* Description  : This function converts PLX Spot-Check Measurement characteristic value representation in
*                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
* Arguments    : p_app_value - pointer to the PLX Spot-Check Measurement  value in the application layer
*                p_gatt_value - pointer to the characteristic value in the GATT database
* Return Value : ble_status_t
**********************************************************************************************************************/
static ble_status_t encode_plx_spot_check_measurement(const st_ble_plxs_plx_spot_check_measurement_t *p_app_value,
    st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos     = 1;
    uint16_t flag_1 = 0;

    /* Clear the bytes array */
    memset(p_gatt_value->p_value, 0x0, p_gatt_value->value_len);

    st_ble_plxs_plx_features_t plx_features;

    R_BLE_PLXS_GetPlxFeatures(&plx_features);

    /*Copy the Spot_Check_Measurement_SP02_Value*/
    /*variable to copy the exponent and mantisa values of SP02_SPOT_CHECK_MEASUREMENT_VALUE*/
    uint16_t value_to_copy_sp02_spot_check = 0;

    value_to_copy_sp02_spot_check = (uint16_t)((((((int16_t)(p_app_value->spo2pr_spot_check___spo2.exponent)) << 12) & 0xF000)
        | (p_app_value->spo2pr_spot_check___spo2.mantissa & 0x0FFF)));

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], (uint8_t*)&value_to_copy_sp02_spot_check);
    pos += 2;

    /*Copy the Spot_Check_Measurement_SP02_PR_Value*/
    /*variable to copy the exponent and mantisa values of SP02_PR_SPOT_CHECK_MEASUREMENT_VALUE*/
    uint16_t value_to_copy_sp02_spot_check_pr = 0;

    value_to_copy_sp02_spot_check_pr = (uint16_t)((((((int16_t)(p_app_value->spo2pr_spot_check___pr.exponent)) << 12) & 0xF000)
        | (p_app_value->spo2pr_spot_check___pr.mantissa & 0x0FFF)));

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], (uint8_t*)&value_to_copy_sp02_spot_check_pr);
    pos += 2;

    /* Copy the time stamp Value of Spot Check Measurement  */
    if (p_app_value->is_timestamp_present & plx_features.is_timestamp_spot_check_measurement_supported)
    {

        /* Set the Time Stamp Present flag */
        p_gatt_value->p_value[0] |= BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_FLAGS_TIMESTAMP_FIELD_IS_PRESENT;

        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->timestamp.year);
        pos += (sizeof(p_app_value->timestamp.year));

        p_gatt_value->p_value[pos++] = p_app_value->timestamp.month;
        p_gatt_value->p_value[pos++] = p_app_value->timestamp.day;
        p_gatt_value->p_value[pos++] = p_app_value->timestamp.hours;
        p_gatt_value->p_value[pos++] = p_app_value->timestamp.minutes;
        p_gatt_value->p_value[pos++] = p_app_value->timestamp.seconds;
    }

    /* Copy the Measurement Status Value of Spot Check Measurement  */
    /* Copy the measurement_status_supported__features Value of spot check measurement  */
    if (p_app_value->is_measurement_status_present & plx_features.is_measurement_status_support_present)
    {

        /* Set the Measurement Status Present flag */
        p_gatt_value->p_value[0] |= BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_FLAGS_MEASUREMENT_STATUS_FIELD_PRESENT;

        if (p_app_value->is_measurement_ongoing)
        {
            flag_1 |= BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_MEASUREMENT_STATUS_MEASUREMENT_ONGOING;
        }

        if (p_app_value->is_early_estimated_data)
        {
            flag_1 |= BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_MEASUREMENT_STATUS_EARLY_ESTIMATED_DATA;
        }

        if (p_app_value->is_validated_data)
        {
            flag_1 |= BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_MEASUREMENT_STATUS_VALIDATED_DATA;
        }

        if (p_app_value->is_fully_qualified_data)
        {
            flag_1 |= BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_MEASUREMENT_STATUS_FULLY_QUALIFIED_DATA;
        }

        if (p_app_value->is_data_from_measurement_storage)
        {
            flag_1 |= BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_MEASUREMENT_STATUS_DATA_FROM_MEASUREMENT_STORAGE;
        }

        if (p_app_value->is_data_for_demonstration)
        {
            flag_1 |= BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_MEASUREMENT_STATUS_DATA_FOR_DEMONSTRATION;
        }

        if (p_app_value->is_data_for_testing)
        {
            flag_1 |= BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_MEASUREMENT_STATUS_DATA_FOR_TESTING;
        }

        if (p_app_value->is_calibration_ongoing)
        {
            flag_1 |= BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_MEASUREMENT_STATUS_CALIBRATION_ONGOING;
        }

        if (p_app_value->is_measurement_unavailable)
        {
            flag_1 |= BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_MEASUREMENT_STATUS_MEASUREMENT_UNAVAILABLE;
        }

        if (p_app_value->is_questionable_measurement_detected)
        {
            flag_1 |= BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_MEASUREMENT_STATUS_QUESTIONABLE_MEASUREMENT_DETECTED;
        }

        if (p_app_value->is_invalid_measurement_detected)
        {
            flag_1 |= BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_MEASUREMENT_STATUS_INVALID_MEASUREMENT_DETECTED;
        }

        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &flag_1);
    }

    pos += 2;

    uint32_t flag_2 = 0;

    /* Copy the Device and Sensor Status Value of Spot Check Measurement  */
    if (p_app_value->is_device_and_sensor_status_present & plx_features.is_device_sensor_status_support_present)
    {

        /* Set the Measurement Status Present flag */
        p_gatt_value->p_value[0] |= BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_FLAGS_DEVICE_AND_SENSOR_STATUS_FIELD_PRESENT;

        /* Copy the device and sensor status_supported__features Value of spot check measurement  */
        if (p_app_value->is_extended_display_update_ongoing)
        {
            flag_2 |= BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_EXTENDED_DISPLAY_UPDATE_ONGOING;
        }

        if (p_app_value->is_equipment_malfunction_detected)
        {
            flag_2 |= BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_EQUIPMENT_MALFUNCTION_DETECTED;
        }

        if (p_app_value->is_signal_processing_irregularity_detected)
        {
            flag_2 |= BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SIGNAL_PROCESSING_IRREGULARITY_DETECTED;
        }

        if (p_app_value->is_inadequate_signal_detected)
        {
            flag_2 |= BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_INADEQUITE_SIGNAL_DETECTED;
        }

        if (p_app_value->is_poor_signal_detected)
        {
            flag_2 |= BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_POOR_SIGNAL_DETECTED;
        }

        if (p_app_value->is_low_perfusion_detected)
        {
            flag_2 |= BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_LOW_PERFUSION_DETECTED;
        }

        if (p_app_value->is_erratic_perfusion_detected)
        {
            flag_2 |= BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_ERRATIC_SIGNAL_DETECTED;
        }

        if (p_app_value->is_non_pulsatile_signal_detected)
        {
            flag_2 |= BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_NONPULSATILE_SIGNAL_DETECTED;
        }

        if (p_app_value->is_questionable_pulse_detected)
        {
            flag_2 |= BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_QUESTIONABLE_PULSE_DETECTED;
        }

        if (p_app_value->is_signal_analysis_ongoing)
        {
            flag_2 |= BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SIGNAL_ANALYSIS_ONGOING;
        }

        if (p_app_value->is_sensor_interference_detected)
        {
            flag_2 |= BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SENSOR_INTERFACE_DETECTED;
        }

        if (p_app_value->is_sensor_unconnected_to_user)
        {
            flag_2 |= BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SENSOR_UNCONNECTED_TO_USER;
        }

        if (p_app_value->is_unknown_sensor_connected)
        {
            flag_2 |= BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_UNKNOWN_SENSOR_CONNECTED;
        }

        if (p_app_value->is_sensor_displaced)
        {
            flag_2 |= BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SENSOR_DISPLACED;
        }

        if (p_app_value->is_sensor_malfunctioning)
        {
            flag_2 |= BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SENSOR_MALFUNCTIONING;
        }

        if (p_app_value->is_sensor_disconnected)
        {
            flag_2 |= BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SENSOR_DISCONNECTED;
        }

        BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], &flag_2);
        pos += 3;
    }

    /* Copy the Pulse Amplitude Index Value of Spot Check Measurement  */
    if (p_app_value->is_pulse_amplitude_index_present & plx_features.is_pulse_amplitude_index_field_supported)
    {

        /* Set the Measurement Status Present flag */
        p_gatt_value->p_value[0] |= (BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_FLAGS_PULSE_AMPLITUDE_INDEX_FIELD_IS_PRESENT);

        uint16_t value_to_copy_pulse = 0;

        value_to_copy_pulse = (uint16_t)(((((int16_t)(p_app_value->pulse_amplitude_index.exponent)) << 12) & 0xF000)
            | (p_app_value->pulse_amplitude_index.mantissa & 0x0FFF));

        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], (uint8_t*)&value_to_copy_pulse);
        pos += 2;
    }

    /* Device Clock Status  bit */
    if (p_app_value->is_device_clock_present)
    {
        p_gatt_value->p_value[0] |= BLE_PLXS_PRV_PLX_SPOT_CHECK_MEASUREMENT_FLAGS_DEVICE_CLOCK_IS_NOT_SET;
    }

    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

/***********************************************************************************************************************//**
 * Function Name: encode_plx_continuous_measurement
 * Description  : This function converts PLX Continuous Measurement characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the PLX Continuous Measurement  value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_plx_continuous_measurement(const st_ble_plxs_plx_continuous_measurement_t *p_app_value,
    st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos     = 1;
    uint16_t flag_1 = 0;
    uint32_t flag_2 = 0;

    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    st_ble_plxs_plx_features_t plx_features;

    R_BLE_PLXS_GetPlxFeatures(&plx_features);

    /* Copy the SP02_Normal Value of Countinuous Measurement  */
    /*variable to copy the exponent and mantisa values of SP02_NORMAL_COUNTINUOUS_MEASUREMENT_VALUE*/
    uint16_t value_to_copy_sp02_nor = 0;

    value_to_copy_sp02_nor = (uint16_t)((((((int16_t)(p_app_value->spo2pr_normal___spo2.exponent)) << 12) & 0xF000)
        | (p_app_value->spo2pr_normal___spo2.mantissa & 0x0FFF)));

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], (uint8_t*)&value_to_copy_sp02_nor);
    pos += 2;

    /* Copy the SP02_Normal_PR Value of Continuous Measurement  */
    /*variable to copy the exponent and mantissa values of SP02_NORMAL_PR_COUNTINUOUS_MEASUREMENT_VALUE*/
    uint16_t value_to_copy_sp02_nor_pr = 0;

    value_to_copy_sp02_nor_pr = (uint16_t)((((((int16_t)(p_app_value->spo2pr_normal___pr.exponent)) << 12) & 0xF000)
        | (p_app_value->spo2pr_normal___pr.mantissa & 0x0FFF)));

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], (uint8_t*)&value_to_copy_sp02_nor_pr);
    pos += 2;

    /* Copy the SP02_FAST and SP02_FAST_PR Values of Continuous Measurement  */
    if ((p_app_value->is_spo2pr_fast_pr_present & plx_features.is_spO2pr_fast_metric_supported))
    {
        /* Set the Measurement Status Present flag */
        p_gatt_value->p_value[0] |= BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_FLAGS_SPO2PR_FAST_FIELD_IS_PRESENT;

        /*variable to copy the exponent and mantissa values of SP02_FAST and SP02_FAST_PR COUNTINUOUS MEASUREMENT VALUES*/
        uint16_t value_to_copy_fast;
        uint16_t value_to_copy_fast_pr;

        value_to_copy_fast = (uint16_t)((((((int16_t)(p_app_value->spo2pr_fast___spo2.exponent)) << 12) & 0xF000)
            | (p_app_value->spo2pr_fast___spo2.mantissa & 0x0FFF)));

        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], (uint8_t*)&value_to_copy_fast);
        pos += 2;

        value_to_copy_fast_pr = (uint16_t)((((((int16_t)(p_app_value->spo2pr_fast___pr.exponent)) << 12) & 0xF000)
            | (p_app_value->spo2pr_fast___pr.mantissa & 0x0FFF)));

        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], (uint8_t*)&value_to_copy_fast_pr);
        pos += 2;
    }

    /* Copy the SP02_SLOW and SP02_SLOW_PR Values of Continuous Measurement  */
    if ((p_app_value->is_spo2pr_slow_pr_present & plx_features.is_spO2pr_slow_metric_supported))
    {

        /* Set the Measurement Status Present flag */
        (p_gatt_value->p_value[0]) |= BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_FLAGS_SPO2PR_SLOW_FIELD_IS_PRESENT;

        /*variable to copy the exponent and mantissa values of SP02_SLOW and SP02_SLOW_PR COUNTINUOUS MEASUREMENT VALUES*/

        uint16_t value_to_copy_slow;

        uint16_t value_to_copy_slow_pr;

        value_to_copy_slow = (uint16_t)((((((int16_t)(p_app_value->spo2pr_slow___spo2.exponent)) << 12) & 0xF000)
            | (p_app_value->spo2pr_slow___spo2.mantissa & 0x0FFF)));

        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], (uint8_t*)&value_to_copy_slow);
        pos += 2;

        value_to_copy_slow_pr = (uint16_t)((((((int16_t)(p_app_value->spo2pr_slow___pr.exponent)) << 12) & 0xF000)
            | (p_app_value->spo2pr_slow___pr.mantissa & 0x0FFF)));

        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], (uint8_t*)&value_to_copy_slow_pr);
        pos += 2;

    }

    /* Copy the Measurement Status PR Value of Continuous Measurement  */
    if (p_app_value->is_measurement_status_present & plx_features.is_measurement_status_support_present)
    {

        /* Set the Measurement Status Present flag */
        p_gatt_value->p_value[0] |= BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_FLAGS_MEASUREMENT_STATUS_FIELD_IS_PRESENT;

        /* Copy the measurement_status_supported__features Value of PLXS Features  */
        if (p_app_value->is_measurement_ongoing)
        {
            flag_1 |= BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_MEASUREMENT_STATUS_MEASUREMENT_ONGOING;
        }

        if (p_app_value->is_early_estimated_data)
        {
            flag_1 |= BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_MEASUREMENT_STATUS_EARLY_ESTIMATED_DATA;
        }

        if (p_app_value->is_validated_data)
        {
            flag_1 |= BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_MEASUREMENT_STATUS_VALIDATED_DATA;
        }

        if (p_app_value->is_fully_qualified_data)
        {
            flag_1 |= BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_MEASUREMENT_STATUS_FULLY_QUALIFIED_DATA;
        }

        if (p_app_value->is_data_from_measurement_storage)
        {
            flag_1 |= BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_MEASUREMENT_STATUS_DATA_FROM_MEASUREMENT_STORAGE;
        }

        if (p_app_value->is_data_for_demonstration)
        {
            flag_1 |= BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_MEASUREMENT_STATUS_DATA_FOR_DEMONSTRATION;
        }

        if (p_app_value->is_data_for_testing)
        {
            flag_1 |= BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_MEASUREMENT_STATUS_DATA_FOR_TESTING;
        }

        if (p_app_value->is_calibration_ongoing)
        {
            flag_1 |= BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_MEASUREMENT_STATUS_CALIBRATION_ONGOING;
        }

        if (p_app_value->is_measurement_unavailable)
        {
            flag_1 |= BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_MEASUREMENT_STATUS_MEASUREMENT_UNAVAILABLE;
        }

        if (p_app_value->is_questionable_measurement_detected)
        {
            flag_1 |= BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_MEASUREMENT_STATUS_QUESTIONABLE_MEASUREMENT_DETECTED;
        }

        if (p_app_value->is_invalid_measurement_detected)
        {
            flag_1 |= BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_MEASUREMENT_STATUS_INVALID_MEASUREMENT_DETECTED;
        }

    }

    pos += 2;

    /* Copy the Device Sensor and Status PR Value of Continuous Measurement  */
    if (p_app_value->is_device_and_sensor_status_present & plx_features.is_device_sensor_status_support_present)
    {

        /* Set the Measurement Status Present flag */
        p_gatt_value->p_value[0] |= BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_FLAGS_DEVICE_AND_SENSOR_STATUS_FIELD_IS_PRESENT;

        /* Copy the device and sensor status_supported__features Value of PLXS Features  */
        if (p_app_value->is_extended_display_update_ongoing)
        {
            flag_2 |= BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_EXTENDED_DISPLAY_UPDATE_ONGOING_BIT_SUPPORTED;
        }

        if (p_app_value->is_equipment_malfunction_detected)
        {
            flag_2 |= BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_EQUIPMENT_MALFUNCTION_DETECTED_BIT_SUPPORTED;
        }

        if (p_app_value->is_signal_processing_irregularity_detected)
        {
            flag_2 |= BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SIGNAL_PROCESSING_IRREGULARITY_DETECTED_BIT_SUPPORTED;
        }

        if (p_app_value->is_inadequate_signal_detected)
        {
            flag_2 |= BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_INADEQUITE_SIGNAL_DETECTED_BIT_SUPPORTED;
        }

        if (p_app_value->is_poor_signal_detected)
        {
            flag_2 |= BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_POOR_SIGNAL_DETECTED_BIT_SUPPORTED;
        }

        if (p_app_value->is_low_perfusion_detected)
        {
            flag_2 |= BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_LOW_PERFUSION_DETECTED_BIT_SUPPORTED;
        }

        if (p_app_value->is_erratic_perfusion_detected)
        {
            flag_2 |= BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_ERRATIC_SIGNAL_DETECTED_BIT_SUPPORTED;
        }

        if (p_app_value->is_non_pulsatile_signal_detected)
        {
            flag_2 |= BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_NONPULSATILE_SIGNAL_DETECTED_BIT_SUPPORTED;
        }

        if (p_app_value->is_questionable_pulse_detected)
        {
            flag_2 |= BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_QUESTIONABLE_PULSE_DETECTED_BIT_SUPPORTED;
        }

        if (p_app_value->is_signal_analysis_ongoing)
        {
            flag_2 |= BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SIGNAL_ANALYSIS_ONGOING_BIT_SUPPORTED;
        }

        if (p_app_value->is_sensor_interference_detected)
        {
            flag_2 |= BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SENSOR_INTERFERENCE_DETECTED_BIT_SUPPORTED;
        }

        if (p_app_value->is_sensor_unconnected_to_user)
        {
            flag_2 |= BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SENSOR_UNCONNECTED_TO_USER_BIT_SUPPORTED;
        }

        if (p_app_value->is_unknown_sensor_connected)
        {
            flag_2 |= BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_UNKNOWN_SENSOR_CONNECTED_BIT_SUPPORTED;
        }

        if (p_app_value->is_sensor_displaced)
        {
            flag_2 |= BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SENSOR_DISPLACED_BIT_SUPPORTED;
        }

        if (p_app_value->is_sensor_malfunctioning)
        {
            flag_2 |= BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SENSOR_MALFUNCTIONING_BIT_SUPPORTED;
        }

        if (p_app_value->is_sensor_disconnected)
        {
            flag_2 |= BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SENSOR_DISCONNECTED_BIT_SUPPORTED;
        }

        BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], &flag_2);
        pos += 3;
    }

    /* Copy the Pulse Amplitude Index PR Value of Continuous Measurement  */
    if (p_app_value->is_pulse_amplitude_index_present & plx_features.is_pulse_amplitude_index_field_supported)
    {
        /* Set the Measurement Status Present flag */
        p_gatt_value->p_value[0] |= BLE_PLXS_PRV_PLX_CONTINUOUS_MEASUREMENT_FLAGS_PULSE_AMPLITUDE_INDEX_FIELD_IS_PRESENT;

        uint16_t value_to_copy;

        value_to_copy = (uint16_t)((((((int16_t)(p_app_value->pulse_amplitude_index.exponent)) << 12) & 0xF000)
            | (p_app_value->pulse_amplitude_index.mantissa & 0x0FFF)));

        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], (uint8_t*)&value_to_copy);
        pos += 2;
    }

    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;

}

/***********************************************************************************************************************//**
 * Function Name: encode_plx_features
 * Description  : This function converts PLX Features characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the PLX Features  value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_plx_features(const st_ble_plxs_plx_features_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos     = 0;
    uint16_t flag_1 = 0;
    uint16_t flag_2 = 0;
    uint32_t flag_3 = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_PLXS_PLX_FEATURES_LEN);

    /* Copy the supported_features Value of PLXS Features  */
    if (p_app_value->is_measurement_status_support_present)
    {
        flag_1 |= BLE_PLXS_PRV_PLX_FEATURES_SUPPORTED_FEATURES_MEASUREMENT_STATUS_SUPPORT_IS_PRESENT;
    }

    if (p_app_value->is_device_sensor_status_support_present)
    {
        flag_1 |= BLE_PLXS_PRV_PLX_FEATURES_SUPPORTED_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_IS_PRESENT;
    }

    if (p_app_value->is_measurement_storage_spot_check_measurement_supported)
    {
        flag_1 |= BLE_PLXS_PRV_PLX_FEATURES_SUPPORTED_FEATURES_MEASUREMENT_STORAGE_FOR_SPOT_CHECK_MEASUREMENTS_IS_SUPPORTED;
    }

    if (p_app_value->is_timestamp_spot_check_measurement_supported)
    {
        flag_1 |= BLE_PLXS_PRV_PLX_FEATURES_SUPPORTED_FEATURES_TIMESTAMP_FOR_SPOT_CHECK_MEASUREMENTS_IS_SUPPORTED;
    }

    if (p_app_value->is_spO2pr_fast_metric_supported)
    {
        flag_1 |= BLE_PLXS_PRV_PLX_FEATURES_SUPPORTED_FEATURES_SPO2PR_FAST_METRIC_IS_SUPPORTED;
    }

    if (p_app_value->is_spO2pr_slow_metric_supported)
    {
        flag_1 |= BLE_PLXS_PRV_PLX_FEATURES_SUPPORTED_FEATURES_SPO2PR_SLOW_METRIC_IS_SUPPORTED;
    }

    if (p_app_value->is_pulse_amplitude_index_field_supported)
    {
        flag_1 |= BLE_PLXS_PRV_PLX_FEATURES_SUPPORTED_FEATURES_PULSE_AMPLITUDE_INDEX_FIELD_IS_SUPPORTED;
    }

    if (p_app_value->is_multiple_bonds_supported)
    {
        flag_1 |= BLE_PLXS_PRV_PLX_FEATURES_SUPPORTED_FEATURES_MULTIPLE_BONDS_SUPPORTED;
    }

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &flag_1);
    pos += 2;

    /* Copy the measurement_status_supported__features Value of PLXS Features  */
    if (p_app_value->is_measurement_ongoing)
    {
        flag_2 |= BLE_PLXS_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_MEASUREMENT_ONGOING_BIT_SUPPORTED;
    }

    if (p_app_value->is_early_estimated_data)
    {
        flag_2 |= BLE_PLXS_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_EARLY_ESTIMATED_DATA_BIT_SUPPORTED;
    }

    if (p_app_value->is_validated_data)
    {
        flag_2 |= BLE_PLXS_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_VALIDATED_DATA_BIT_SUPPORTED;
    }

    if (p_app_value->is_fully_qualified_data)
    {
        flag_2 |= BLE_PLXS_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_FULLY_QUALIFIED_DATA_BIT_SUPPORTED;
    }

    if (p_app_value->is_data_from_measurement_storage)
    {
        flag_2 |= BLE_PLXS_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_DATA_FROM_MEASUREMENT_STORAGE_BIT_SUPPORTED;
    }

    if (p_app_value->is_data_for_demonstration)
    {
        flag_2 |= BLE_PLXS_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_DATA_FOR_DEMONSTRATION_BIT_SUPPORTED;
    }

    if (p_app_value->is_data_for_testing)
    {
        flag_2 |= BLE_PLXS_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_DATA_FOR_TESTING_BIT_SUPPORTED;
    }

    if (p_app_value->is_calibration_ongoing)
    {
        flag_2 |= BLE_PLXS_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_CALIBRATION_ONGOING_BIT_SUPPORTED;
    }

    if (p_app_value->is_measurement_unavailable)
    {
        flag_2 |= BLE_PLXS_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_MEASUREMENT_UNAVAILABLE_BIT_SUPPORTED;
    }

    if (p_app_value->is_questionable_measurement_detected)
    {
        flag_2 |= BLE_PLXS_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_QUESTIONABLE_MEASUREMENT_DETECTED_BIT_SUPPORTED;
    }

    if (p_app_value->is_invalid_measurement_detected)
    {
        flag_2 |= BLE_PLXS_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_INVALID_MEASUREMENT_DETECTED_BIT_SUPPORTED;
    }

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &flag_2);
    pos += 2;

    /* Copy the device and sensor status_supported__features Value of PLXS Features  */
    if (p_app_value->is_extended_display_update_ongoing)
    {
        flag_3 |= BLE_PLXS_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_EXTENDED_DISPLAY_UPDATE_ONGOING_BIT_SUPPORTED;
    }

    if (p_app_value->is_equipment_malfunction_detected)
    {
        flag_3 |= BLE_PLXS_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_EQUIPMENT_MALFUNCTION_DETECTED_BIT_SUPPORTED;
    }

    if (p_app_value->is_signal_processing_irregularity_detected)
    {
        flag_3 |= BLE_PLXS_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_SIGNAL_PROCESSING_IRREGULARITY_DETECTED_BIT_SUPPORTED;
    }

    if (p_app_value->is_inadequate_signal_detected)
    {
        flag_3 |= BLE_PLXS_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_INADEQUITE_SIGNAL_DETECTED_BIT_SUPPORTED;
    }

    if (p_app_value->is_poor_signal_detected)
    {
        flag_3 |= BLE_PLXS_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_POOR_SIGNAL_DETECTED_BIT_SUPPORTED;
    }

    if (p_app_value->is_low_perfusion_detected)
    {
        flag_3 |= BLE_PLXS_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_LOW_PERFUSION_DETECTED_BIT_SUPPORTED;
    }

    if (p_app_value->is_erratic_perfusion_detected)
    {
        flag_3 |= BLE_PLXS_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_ERRATIC_SIGNAL_DETECTED_BIT_SUPPORTED;
    }

    if (p_app_value->is_non_pulsatile_signal_detected)
    {
        flag_3 |= BLE_PLXS_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_NONPULSATILE_SIGNAL_DETECTED_BIT_SUPPORTED;
    }

    if (p_app_value->is_questionable_pulse_detected)
    {
        flag_3 |= BLE_PLXS_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_QUESTIONABLE_PULSE_DETECTED_BIT_SUPPORTED;
    }

    if (p_app_value->is_signal_analysis_ongoing)
    {
        flag_3 |= BLE_PLXS_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_SIGNAL_ANALYSIS_ONGOING_BIT_SUPPORTED;
    }

    if (p_app_value->is_sensor_interference_detected)
    {
        flag_3 |= BLE_PLXS_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_SENSOR_INTERFACE_DETECTED_BIT_SUPPORTED;
    }

    if (p_app_value->is_sensor_unconnected_to_user)
    {
        flag_3 |= BLE_PLXS_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_SENSOR_UNCONNECTED_TO_USER_BIT_SUPPORTED;
    }

    if (p_app_value->is_unknown_sensor_connected)
    {
        flag_3 |= BLE_PLXS_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_UNKNOWN_SENSOR_CONNECTED_BIT_SUPPORTED;
    }

    if (p_app_value->is_sensor_displaced)
    {
        flag_3 |= BLE_PLXS_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_SENSOR_DISPLACED_BIT_SUPPORTED;
    }

    if (p_app_value->is_sensor_malfunctioning)
    {
        flag_3 |= BLE_PLXS_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_SENSOR_MALFUNCTIONING_BIT_SUPPORTED;
    }

    if (p_app_value->is_sensor_disconnected)
    {
        flag_3 |= BLE_PLXS_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_SENSOR_DISCONNECTED_BIT_SUPPORTED;
    }

    BT_PACK_LE_3_BYTE(&p_gatt_value->p_value[pos], &flag_3);
    pos += 3;

    p_gatt_value->value_len = BLE_PLXS_PLX_FEATURES_LEN;

    return BLE_SUCCESS;
}

/***********************************************************************************************************************//**
 * Function Name: decode_plx_features
 * Description  : This function converts PLX Features characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the PLX Features value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_plx_features(st_ble_plxs_plx_features_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos            = 0;
    uint16_t feature_byte0 = 0;

    BT_UNPACK_LE_2_BYTE(&feature_byte0, &p_gatt_value->p_value[0]);

    if (BLE_PLXS_PLX_FEATURES_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    memset((uint8_t*)p_app_value, 0x00, sizeof(*p_app_value));

    /* PLXS SUPPORTED FEATURES SUPPORTED BITS */
    /* Measurement Status Supported bit */
    if (feature_byte0 & BLE_PLXS_PRV_PLX_FEATURES_SUPPORTED_FEATURES_MEASUREMENT_STATUS_SUPPORT_IS_PRESENT)
    {
        p_app_value->is_measurement_status_support_present = true;
    }
    else
    {
        p_app_value->is_measurement_status_support_present = false;
    }

    /* Device Sensor Status Supported bit */
    if (feature_byte0 & BLE_PLXS_PRV_PLX_FEATURES_SUPPORTED_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_IS_PRESENT)
    {
        p_app_value->is_device_sensor_status_support_present = true;
    }
    else
    {
        p_app_value->is_device_sensor_status_support_present = false;
    }

    /* Measurement Storage for Spot Check Measurement Status Supported bit */
    if (feature_byte0 & BLE_PLXS_PRV_PLX_FEATURES_SUPPORTED_FEATURES_MEASUREMENT_STORAGE_FOR_SPOT_CHECK_MEASUREMENTS_IS_SUPPORTED)
    {
        p_app_value->is_measurement_storage_spot_check_measurement_supported = true;
    }
    else
    {
        p_app_value->is_measurement_storage_spot_check_measurement_supported = false;
    }

    /* Time Stamp for Spot Check Measurement Status Supported bit */
    if (feature_byte0 & BLE_PLXS_PRV_PLX_FEATURES_SUPPORTED_FEATURES_TIMESTAMP_FOR_SPOT_CHECK_MEASUREMENTS_IS_SUPPORTED)
    {
        p_app_value->is_timestamp_spot_check_measurement_supported = true;
    }
    else
    {
        p_app_value->is_timestamp_spot_check_measurement_supported = false;
    }

    /* SPO2PR_FAST_METRIC Status Supported bit */
    if (feature_byte0 & BLE_PLXS_PRV_PLX_FEATURES_SUPPORTED_FEATURES_SPO2PR_FAST_METRIC_IS_SUPPORTED)
    {
        p_app_value->is_spO2pr_fast_metric_supported = true;
    }
    else
    {
        p_app_value->is_spO2pr_fast_metric_supported = false;
    }

    /* SPO2PR_SLOW_METRIC Status Supported bit */
    if (feature_byte0 & BLE_PLXS_PRV_PLX_FEATURES_SUPPORTED_FEATURES_SPO2PR_SLOW_METRIC_IS_SUPPORTED)
    {
        p_app_value->is_spO2pr_slow_metric_supported = true;
    }
    else
    {
        p_app_value->is_spO2pr_slow_metric_supported = false;
    }

    /* Pulse Amplitude Index field is supported bit */
    if (feature_byte0 & BLE_PLXS_PRV_PLX_FEATURES_SUPPORTED_FEATURES_PULSE_AMPLITUDE_INDEX_FIELD_IS_SUPPORTED)
    {
        p_app_value->is_pulse_amplitude_index_field_supported = true;
    }
    else
    {
        p_app_value->is_pulse_amplitude_index_field_supported = false;
    }

    /*  Multiple Bonds Index field is supported bit */
    if (feature_byte0 & BLE_PLXS_PRV_PLX_FEATURES_SUPPORTED_FEATURES_MULTIPLE_BONDS_SUPPORTED)
    {
        p_app_value->is_multiple_bonds_supported = true;
    }
    else
    {
        p_app_value->is_multiple_bonds_supported = false;
    }

    pos += 2;

    uint16_t feature_byte1 = 0;

    BT_UNPACK_LE_2_BYTE(&feature_byte1, &p_gatt_value->p_value[pos]);

    /* PLXS FEATURES MEASUREMENT STATUS SUPPORTED BITS */
    /*  Measurement Ongoing supported bit */
    if (feature_byte1 & BLE_PLXS_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_MEASUREMENT_ONGOING_BIT_SUPPORTED)
    {
        p_app_value->is_measurement_ongoing = true;
    }
    else
    {
        p_app_value->is_measurement_ongoing = false;
    }

    /* Early Estimated Data supported bit */
    if (feature_byte1 & BLE_PLXS_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_EARLY_ESTIMATED_DATA_BIT_SUPPORTED)
    {
        p_app_value->is_early_estimated_data = true;
    }
    else
    {
        p_app_value->is_early_estimated_data = false;
    }

    /* Validated Data supported bit */
    if (feature_byte1 & BLE_PLXS_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_VALIDATED_DATA_BIT_SUPPORTED)
    {
        p_app_value->is_validated_data = true;
    }
    else
    {
        p_app_value->is_validated_data = false;
    }

    /* Fully Qualified Data  supported bit */
    if (feature_byte1 & BLE_PLXS_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_FULLY_QUALIFIED_DATA_BIT_SUPPORTED)
    {
        p_app_value->is_fully_qualified_data = true;
    }
    else
    {
        p_app_value->is_fully_qualified_data = false;
    }

    /* Data from Measurement Storage supported bit */
    if (feature_byte1 & BLE_PLXS_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_DATA_FROM_MEASUREMENT_STORAGE_BIT_SUPPORTED)
    {
        p_app_value->is_data_from_measurement_storage = true;
    }
    else
    {
        p_app_value->is_data_from_measurement_storage = false;
    }

    /*  Data for Demonstration supported bit */
    if (feature_byte1 & BLE_PLXS_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_DATA_FOR_DEMONSTRATION_BIT_SUPPORTED)
    {
        p_app_value->is_data_for_demonstration = true;
    }
    else
    {
        p_app_value->is_data_for_demonstration = false;
    }

    /*   Data for Testing supported bit */
    if (feature_byte1 & BLE_PLXS_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_DATA_FOR_TESTING_BIT_SUPPORTED)
    {
        p_app_value->is_data_for_testing = true;
    }
    else
    {
        p_app_value->is_data_for_testing = false;
    }

    /*   Calibration Ongoing supported bit */
    if (feature_byte1 & BLE_PLXS_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_CALIBRATION_ONGOING_BIT_SUPPORTED)
    {
        p_app_value->is_calibration_ongoing = true;
    }
    else
    {
        p_app_value->is_calibration_ongoing = false;
    }

    /*   Measurement Unavailable supported bit */
    if (feature_byte1 & BLE_PLXS_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_MEASUREMENT_UNAVAILABLE_BIT_SUPPORTED)
    {
        p_app_value->is_measurement_unavailable = true;
    }
    else
    {
        p_app_value->is_measurement_unavailable = false;
    }

    /*    Questionable Measurement Detected supported bit */
    if (feature_byte1 & BLE_PLXS_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_QUESTIONABLE_MEASUREMENT_DETECTED_BIT_SUPPORTED)
    {
        p_app_value->is_questionable_measurement_detected = true;
    }
    else
    {
        p_app_value->is_questionable_measurement_detected = false;
    }

    /* Invalid Measurement Detected supported bit */
    if (feature_byte1 & BLE_PLXS_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_INVALID_MEASUREMENT_DETECTED_BIT_SUPPORTED)
    {
        p_app_value->is_invalid_measurement_detected = true;
    }
    else
    {
        p_app_value->is_invalid_measurement_detected = false;
    }

    pos += 2;

    uint32_t feature_byte2 = 0;

    BT_UNPACK_LE_3_BYTE(&feature_byte2, &p_gatt_value->p_value[pos]);

    /*PLXS Features Device and Sensor status bit fields*/
    /* Extended Display Update Ongoing supported bit */
    if (feature_byte2 & BLE_PLXS_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_EXTENDED_DISPLAY_UPDATE_ONGOING_BIT_SUPPORTED)
    {
        p_app_value->is_extended_display_update_ongoing = true;
    }
    else
    {
        p_app_value->is_extended_display_update_ongoing = false;
    }

    /* Equipment Malfunction Detected supported bit */
    if (feature_byte2 & BLE_PLXS_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_EQUIPMENT_MALFUNCTION_DETECTED_BIT_SUPPORTED)
    {
        p_app_value->is_equipment_malfunction_detected = true;
    }
    else
    {
        p_app_value->is_equipment_malfunction_detected = false;
    }

    /* Signal Processing Irregularity Detected supported bit */
    if (feature_byte2 & BLE_PLXS_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_SIGNAL_PROCESSING_IRREGULARITY_DETECTED_BIT_SUPPORTED)
    {
        p_app_value->is_signal_processing_irregularity_detected = true;
    }
    else
    {
        p_app_value->is_signal_processing_irregularity_detected = false;
    }

    /* Inadequate Signal Detected supported bit */
    if (feature_byte2 & BLE_PLXS_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_INADEQUITE_SIGNAL_DETECTED_BIT_SUPPORTED)
    {
        p_app_value->is_inadequate_signal_detected = true;
    }
    else
    {
        p_app_value->is_inadequate_signal_detected = false;
    }

    /* Poor Signal Detected supported bit */
    if (feature_byte2 & BLE_PLXS_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_POOR_SIGNAL_DETECTED_BIT_SUPPORTED)
    {
        p_app_value->is_poor_signal_detected = true;
    }
    else
    {
        p_app_value->is_poor_signal_detected = false;
    }

    /*  Low Perfusion Detected supported bit */
    if (feature_byte2 & BLE_PLXS_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_LOW_PERFUSION_DETECTED_BIT_SUPPORTED)
    {
        p_app_value->is_low_perfusion_detected = true;
    }
    else
    {
        p_app_value->is_low_perfusion_detected = false;
    }

    /*  Erratic Signal Detected supported bit */
    if (feature_byte2 & BLE_PLXS_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_ERRATIC_SIGNAL_DETECTED_BIT_SUPPORTED)
    {
        p_app_value->is_erratic_perfusion_detected = true;
    }
    else
    {
        p_app_value->is_erratic_perfusion_detected = false;
    }

    /*  Non-Pulsatile Signal Detected supported bit */
    if (feature_byte2 & BLE_PLXS_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_NONPULSATILE_SIGNAL_DETECTED_BIT_SUPPORTED)
    {
        p_app_value->is_non_pulsatile_signal_detected = true;
    }
    else
    {
        p_app_value->is_non_pulsatile_signal_detected = false;
    }

    /* Questionable Pulse Detected supported bit */
    if (feature_byte2 & BLE_PLXS_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_QUESTIONABLE_PULSE_DETECTED_BIT_SUPPORTED)
    {
        p_app_value->is_questionable_pulse_detected = true;
    }
    else
    {
        p_app_value->is_questionable_pulse_detected = false;
    }

    /* Signal Analysis Ongoing supported bit */
    if (feature_byte2 & BLE_PLXS_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_SIGNAL_ANALYSIS_ONGOING_BIT_SUPPORTED)
    {
        p_app_value->is_signal_analysis_ongoing = true;
    }
    else
    {
        p_app_value->is_signal_analysis_ongoing = false;
    }

    /* Sensor Interference Detected supported bit */
    if (feature_byte2 & BLE_PLXS_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_SENSOR_INTERFACE_DETECTED_BIT_SUPPORTED)
    {
        p_app_value->is_sensor_interference_detected = true;
    }
    else
    {
        p_app_value->is_sensor_interference_detected = false;
    }

    /* Sensor Unconnected to User supported bit */
    if (feature_byte2 & BLE_PLXS_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_SENSOR_UNCONNECTED_TO_USER_BIT_SUPPORTED)
    {
        p_app_value->is_sensor_unconnected_to_user = true;
    }
    else
    {
        p_app_value->is_sensor_unconnected_to_user = false;
    }

    /* Unknown Sensor Connected supported bit */
    if (feature_byte2 & BLE_PLXS_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_UNKNOWN_SENSOR_CONNECTED_BIT_SUPPORTED)
    {
        p_app_value->is_unknown_sensor_connected = true;
    }
    else
    {
        p_app_value->is_unknown_sensor_connected = false;
    }

    /* Sensor Displaced  supported bit */
    if (feature_byte2 & BLE_PLXS_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_SENSOR_DISPLACED_BIT_SUPPORTED)
    {
        p_app_value->is_sensor_displaced = true;
    }
    else
    {
        p_app_value->is_sensor_displaced = false;
    }

    /* Sensor Malfunctioning supported bit */
    if (feature_byte2 & BLE_PLXS_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_SENSOR_MALFUNCTIONING_BIT_SUPPORTED)
    {
        p_app_value->is_sensor_malfunctioning = true;
    }
    else
    {
        p_app_value->is_sensor_malfunctioning = false;
    }

    /* Sensor Disconnected supported bit */
    if (feature_byte2 & BLE_PLXS_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_SENSOR_DISCONNECTED_BIT_SUPPORTED)
    {
        p_app_value->is_sensor_disconnected = true;
    }
    else
    {
        p_app_value->is_sensor_disconnected = false;
    }

    pos += 3;

    return BLE_SUCCESS;
}

/***********************************************************************************************************************//**
 * Function Name: encode_record_access_control_point
 * Description  : This function converts Record Access Control Point characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the Record Access Control Point  value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_record_access_control_point(const st_ble_plxs_record_access_control_point_t *p_app_value,
    st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    p_gatt_value->p_value[pos++] = (uint8_t)(p_app_value->op_code & 0xFF);
    p_gatt_value->p_value[pos++] = (uint8_t)(p_app_value->racp_operator & 0xFF);

    for (int32_t i = 0; (i < p_gatt_value->value_len) && (i < (8 - 1)); i++)
    {
        p_gatt_value->p_value[pos] = p_app_value->operand_values[i];
    }

    pos += 1;

    for (int32_t i = 0; (i < p_gatt_value->value_len) && (i < (10 - 1)); i++)
    {
        p_gatt_value->p_value[pos] = p_app_value->operand_reponse_code_values[i];
    }

    pos += 1;
    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

/***********************************************************************************************************************//**
 * Function Name: decode_record_access_control_point
 * Description  : This function converts Record Access Control Point characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value  - pointer to the Record Access Control Point value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_record_access_control_point(st_ble_plxs_record_access_control_point_t *p_app_value,
    const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;
    if (BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    memset((uint8_t*)p_app_value, 0x00, sizeof(*p_app_value));

    p_app_value->op_code = p_gatt_value->p_value[pos++];
    p_app_value->racp_operator = p_gatt_value->p_value[pos++];

    for (int32_t i = 0; (i < 8); i++)
    {
        p_app_value->operand_values[i] = p_gatt_value->p_value[pos];
    }

    pos += 1;

    for (int32_t i = 0; (i < 10); i++)
    {
        p_app_value->operand_reponse_code_values[i] = p_gatt_value->p_value[pos];
    }

    pos += 1;

    return BLE_SUCCESS;
}

/***********************************************************************************************************************//**
 * Function Name: plxs_indicate_record
 * Description  : This function sends Pluse Oximeter Measurement characteristic indications.
 * Arguments    : p_record      - plxs spot check measurement records
 * Return Value : BLE_SUCCESS   - if successful
 *                BLE_ERR_INVALID_DATA - if failure
 **********************************************************************************************************************/
static ble_status_t plxs_indicate_record(st_ble_plxs_record_t *p_record)
{
    ble_status_t ret = BLE_SUCCESS;

    ret = R_BLE_PLXS_IndicatePlxSpotcheckMeasurement(gs_conn_hdl, &gs_default_record_value.spot_check_measurement);

    if (BLE_SUCCESS != ret)
    {
        return BLE_ERR_INVALID_DATA;
    }

    return ret;
}

/***********************************************************************************************************************//**
 * Function Name: plxs_operator_racp_all_records
 * Description  : This function gets ALL records and sends notification.
 * Arguments    : none
 * Return Value : BLE_SUCCESS   - successful
 **********************************************************************************************************************/
static ble_status_t plxs_operator_racp_all_records(void)
{
    ble_status_t ret               = BLE_SUCCESS;
    st_ble_plxs_record_t *p_record = NULL;
    p_record = plxs_db_get_record(gs_racp_info.current_index);

    if (0 == gs_num_of_reports)
    {
        gs_racp_info.current_index  = BLE_PLXS_DB_INVALID_INDEX;
        gs_racp_info.num_of_reports = 0;
        ret                         = BLE_SUCCESS;
        gs_num_of_reports           = 1;
    }
    else if (NULL != p_record)
    {
        ret = plxs_indicate_record(p_record);
        if (BLE_SUCCESS == ret)
        {
            gs_racp_info.num_of_reports++;
            gs_racp_info.current_index = p_record->next_index;
        }
    }
    else
    {
        /* Do Nothing */
    }

    return ret;
}

/***********************************************************************************************************************//**
 * Function Name: plxs_indicate_report_num_of_stored_recoreds_null
 * Description  : This function sends Record Access Control Point characteristic Indication if Indication is enabled.
 * Arguments    : conn_hdl - connection handle
 *                opcode   - RACP opcode
 *                operand  - RACP operand
 * Return Value : BLE_SUCCESS - if successful
 *                BLE_ERR_INVALID_STATE - if failure
 **********************************************************************************************************************/
static ble_status_t plxs_indicate_report_num_of_stored_recoreds_null(uint16_t conn_hdl, uint8_t opcode, uint16_t operand)
{
    ble_status_t    ret;
    uint16_t        cli_cnfg;
    uint8_t         byte_value[4] = { 0 };

    get_cli_cnfg(conn_hdl, BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_CLI_CNFG_DESC_HDL, &cli_cnfg);

    if ((cli_cnfg & BLE_GATTS_CLI_CNFG_INDICATION) != 0)
    {
        st_ble_gatt_hdl_value_pair_t ind_data =
        {
                .attr_hdl        = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_VAL_HDL,
                .value.p_value   = byte_value,
                .value.value_len = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_LEN,
        };

        /* Report Number of Stored Records(All-Records) */
        if (opcode == BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_NUMBER_OF_STORED_RECORDS_RESPONSE__OPERATOR__NULL__VALUE_OF_0X00_FROM_OPERATOR_TABLE__)
        {
            byte_value[0] = opcode;
            byte_value[1] = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERATOR_NULL;
            byte_value[2] = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_VALUES_N_A;
        }

        ret = R_BLE_GATTS_Indication(conn_hdl, &ind_data);
    }
    else
    {
        ret = BLE_ERR_INVALID_STATE;
    }

    return ret;
}

/***********************************************************************************************************************//**
 * Function Name: plxs_indicate_report_num_of_stored_recoreds
 * Description  : This function sends Record Access Control Point characteristic Indication if Indication is enabled.
 * Arguments    : conn_hdl - connection handle
 *                opcode   - RACP opcode
 *                operand  - RACP operand
 * Return Value : BLE_SUCCESS - if successful
 *                BLE_ERR_INVALID_STATE - if failure
 **********************************************************************************************************************/
static ble_status_t plxs_indicate_report_num_of_stored_recoreds(uint16_t conn_hdl, uint8_t opcode, uint16_t operand)
{
    ble_status_t    ret;
    uint16_t        cli_cnfg;
    uint8_t         byte_value[4] = { 0 };

    get_cli_cnfg(conn_hdl, BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_CLI_CNFG_DESC_HDL, &cli_cnfg);

    if ((cli_cnfg & BLE_GATTS_CLI_CNFG_INDICATION) != 0)
    {
        st_ble_gatt_hdl_value_pair_t ind_data =
        {
                .attr_hdl        = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_VAL_HDL,
                .value.p_value   = byte_value,
                .value.value_len = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_LEN,
        };

        /* Report Number of Stored Records(All-Records) */
        if (BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_NUMBER_OF_STORED_RECORDS_RESPONSE__OPERATOR__NULL__VALUE_OF_0X00_FROM_OPERATOR_TABLE__ == opcode)
        {
            byte_value[0] = opcode;
            byte_value[1] = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERATOR_NULL;
            BT_PACK_LE_2_BYTE(&byte_value[2], &operand);
        }

        ret = R_BLE_GATTS_Indication(conn_hdl, &ind_data);
    }
    else
    {
        ret = BLE_ERR_INVALID_STATE;
    }

    return ret;
}

/***********************************************************************************************************************//**
 * Function Name: plxs_indicate_report_stored_no_records_found
 * Description  : This function sends Record Access Control Point characteristic Indication if Indication is enabled.
 * Arguments    : conn_hdl - connection handle
 *                opcode   - RACP opcode
 *                operand  - RACP operand
 * Return Value : BLE_SUCCESS - if successful
 *                BLE_ERR_INVALID_STATE - if failure
 **********************************************************************************************************************/
static ble_status_t plxs_indicate_report_stored_no_records_found(uint16_t conn_hdl, uint8_t opcode, uint16_t operand)
{
    ble_status_t    ret;
    uint16_t        cli_cnfg;
    uint8_t         byte_value[4] = { 0 };

    get_cli_cnfg(conn_hdl, BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_CLI_CNFG_DESC_HDL, &cli_cnfg);

    if ((cli_cnfg & BLE_GATTS_CLI_CNFG_INDICATION) != 0)
    {
        st_ble_gatt_hdl_value_pair_t ind_data =
        {
                .attr_hdl        = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_VAL_HDL,
                .value.p_value   = byte_value,
                .value.value_len = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_LEN,
        };

        /* for Report Stored Records(all records) */
        if (BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_RESPONSE_CODE__OPERATOR__NULL__VALUE_OF_0X00_FROM_OPERATOR_TABLE__ == opcode)
        {
            byte_value[0] = opcode;
            byte_value[1] = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERATOR_NULL;
            byte_value[2] = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_VALUES_FILTER_PARAMETERS__AS_APPROPRIATE_TO_OPERATOR_AND_SERVICE_1;
            byte_value[3] = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_REPONSE_CODE_VALUES_NO_RECORDS_FOUND;
        }

        ret = R_BLE_GATTS_Indication(conn_hdl, &ind_data);
    }
    else
    {
        ret = BLE_ERR_INVALID_STATE;
    }

    return ret;
}

/***********************************************************************************************************************//**
 * Function Name: plxs_indicate_report_stored_all_records
 * Description  : This function sends Record Access Control Point characteristic Indication if Indication is enabled.
 * Arguments    : conn_hdl - connection handle
 *                opcode   - RACP opcode
 *                operand  - RACP operand
 * Return Value : BLE_SUCCESS - if successful
 *                BLE_ERR_INVALID_STATE - if failure
 **********************************************************************************************************************/
ble_status_t plxs_indicate_report_stored_all_records(uint16_t conn_hdl, uint8_t opcode, uint16_t operand)
{
    ble_status_t    ret;
    uint16_t        cli_cnfg;
    uint8_t         byte_value[4] = { 0 };

    get_cli_cnfg(conn_hdl, BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_CLI_CNFG_DESC_HDL, &cli_cnfg);

    if ((cli_cnfg & BLE_GATTS_CLI_CNFG_INDICATION) != 0)
    {
        st_ble_gatt_hdl_value_pair_t ind_data =
        {
                .attr_hdl        = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_VAL_HDL,
                .value.p_value   = byte_value,
                .value.value_len = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_LEN,
        };

        /* for Report Stored Records(all records) */
        if (BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_RESPONSE_CODE__OPERATOR__NULL__VALUE_OF_0X00_FROM_OPERATOR_TABLE__ == opcode)
        {
            byte_value[0] = opcode;
            byte_value[1] = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERATOR_NULL;
            byte_value[2] =
                    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_VALUES_FILTER_PARAMETERS__AS_APPROPRIATE_TO_OPERATOR_AND_SERVICE_1;
            byte_value[3] = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_REPONSE_CODE_VALUES_SUCCESS;
        }

        ret = R_BLE_GATTS_Indication(conn_hdl, &ind_data);
    }
    else
    {
        ret = BLE_ERR_INVALID_STATE;
    }

    return ret;
}

/***********************************************************************************************************************//**
 * Function Name: plxs_indicate_delete_stored_records
 * Description  : This function sends Record Access Control Point characteristic Indication if Indication is enabled.
 * Arguments    : conn_hdl - connection handle
 *                opcode   - RACP opcode
 *                operand  - RACP operand
 * Return Value : BLE_SUCCESS - if successful
 *                BLE_ERR_INVALID_STATE - if failure
 **********************************************************************************************************************/
static ble_status_t plxs_indicate_delete_stored_records(uint16_t conn_hdl, uint8_t opcode, uint16_t operand)
{
    ble_status_t    ret;
    uint16_t        cli_cnfg;
    uint8_t         byte_value[4] = { 0 };

    get_cli_cnfg(conn_hdl, BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_CLI_CNFG_DESC_HDL, &cli_cnfg);

    if ((cli_cnfg & BLE_GATTS_CLI_CNFG_INDICATION) != 0)
    {
        st_ble_gatt_hdl_value_pair_t ind_data =
        {
                .attr_hdl        = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_VAL_HDL,
                .value.p_value   = byte_value,
                .value.value_len = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_LEN,
        };

        /* Delete Stored Records (All Records) */
        if (BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_RESPONSE_CODE__OPERATOR__NULL__VALUE_OF_0X00_FROM_OPERATOR_TABLE__ == opcode)
        {
            byte_value[0] = opcode;
            byte_value[1] = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERATOR_NULL;
            byte_value[2] =
                    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_VALUES_FILTER_PARAMETERS__AS_APPROPRIATE_TO_OPERATOR_AND_SERVICE_2;
            byte_value[3] = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_REPONSE_CODE_VALUES_SUCCESS;
        }

        ret = R_BLE_GATTS_Indication(conn_hdl, &ind_data);
    }
    else
    {
        ret = BLE_ERR_INVALID_STATE;
    }

    return ret;
}

/***********************************************************************************************************************//**
 * Function Name: plxs_indicate_opcode_not_supported
 * Description  : This function sends Record Access Control Point characteristic Indication if Indication is enabled.
 * Arguments    : conn_hdl - connection handle
 *                opcode   - RACP opcode
 *                operand  - RACP operand
 * Return Value : BLE_SUCCESS - if successful
 *                BLE_ERR_INVALID_STATE - if failure
 **********************************************************************************************************************/
static ble_status_t plxs_indicate_opcode_not_supported(uint16_t conn_hdl, uint8_t opcode, uint16_t operand)
{
    ble_status_t    ret;
    uint16_t        cli_cnfg;
    uint8_t         byte_value[4] = { 0 };

    get_cli_cnfg(conn_hdl, BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_CLI_CNFG_DESC_HDL, &cli_cnfg);

    if ((cli_cnfg & BLE_GATTS_CLI_CNFG_INDICATION) != 0)
    {
        st_ble_gatt_hdl_value_pair_t ind_data =
        {
                .attr_hdl        = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_VAL_HDL,
                .value.p_value   = byte_value,
                .value.value_len = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_LEN,
        };

        /* for opcode not supported */
        if (BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_RESPONSE_CODE__OPERATOR__NULL__VALUE_OF_0X00_FROM_OPERATOR_TABLE__ == opcode)
        {
            byte_value[0] = opcode;
            byte_value[1] = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERATOR_NULL;
            byte_value[2] = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_VALUES_N_A;
            byte_value[3] = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_REPONSE_CODE_VALUES_OP_CODE_NOT_SUPPORTED;
        }

        ret = R_BLE_GATTS_Indication(conn_hdl, &ind_data);
    }
    else
    {
        ret = BLE_ERR_INVALID_STATE;
    }

    return ret;
}

/***********************************************************************************************************************//**
 * Function Name: plxs_indicate_racp_response
 * Description  : This function sends Record Access Control Point characteristic Indication if Indication is enabled.
 * Arguments    : conn_hdl - connection handle
 *                opcode   - RACP opcode
 *                operand  - RACP operand
 * Return Value : BLE_SUCCESS - if successful
 *                BLE_ERR_INVALID_STATE - if failure
 **********************************************************************************************************************/
static ble_status_t plxs_indicate_operator_not_supported(uint16_t conn_hdl, uint8_t opcode, uint16_t operand)
{
    ble_status_t    ret;
    uint16_t        cli_cnfg;
    uint8_t         byte_value[4] = { 0 };

    get_cli_cnfg(conn_hdl, BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_CLI_CNFG_DESC_HDL, &cli_cnfg);

    if ((cli_cnfg & BLE_GATTS_CLI_CNFG_INDICATION) != 0)
    {
        st_ble_gatt_hdl_value_pair_t ind_data =
        {
                .attr_hdl = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_VAL_HDL,
                .value.p_value = byte_value,
                .value.value_len = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_LEN,
        };

        /* for operator not found */
        if (BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_RESPONSE_CODE__OPERATOR__NULL__VALUE_OF_0X00_FROM_OPERATOR_TABLE__ == opcode)
        {
            byte_value[0] = opcode;
            byte_value[1] = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERATOR_NULL;
            byte_value[2] = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_VALUES_FILTER_PARAMETERS__AS_APPROPRIATE_TO_OPERATOR_AND_SERVICE_1;
            byte_value[3] = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_REPONSE_CODE_VALUES_OPERATOR_NOT_SUPPORTED;
        }

        ret = R_BLE_GATTS_Indication(conn_hdl, &ind_data);
    }
    else
    {
        ret = BLE_ERR_INVALID_STATE;
    }

    return ret;
}

/***********************************************************************************************************************//**
 * Function Name: plxs_indicate_abort_operation
 * Description  : This function sends Record Access Control Point characteristic Indication if Indication is enabled.
 * Arguments    : conn_hdl - connection handle
 *                opcode   - RACP opcode
 *                operand  - RACP operand
 * Return Value : BLE_SUCCESS - if successful
 *                BLE_ERR_INVALID_STATE - if failure
 **********************************************************************************************************************/
static ble_status_t plxs_indicate_abort_operation(uint16_t conn_hdl, uint8_t opcode, uint16_t operand)
{
    ble_status_t    ret;
    uint16_t        cli_cnfg;
    uint8_t         byte_value[4] = { 0 };

    get_cli_cnfg(conn_hdl, BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_CLI_CNFG_DESC_HDL, &cli_cnfg);

    if ((cli_cnfg & BLE_GATTS_CLI_CNFG_INDICATION) != 0)
    {
        st_ble_gatt_hdl_value_pair_t ind_data =
        {
                .attr_hdl        = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_VAL_HDL,
                .value.p_value   = byte_value,
                .value.value_len = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_LEN,
        };

        /* Abort_operation */
        if (BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_RESPONSE_CODE__OPERATOR__NULL__VALUE_OF_0X00_FROM_OPERATOR_TABLE__ == opcode)
        {
            byte_value[0] = opcode;
            byte_value[1] = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERATOR_NULL;
            byte_value[2] = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_VALUES_NOT_INCLUDED;
            byte_value[3] = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_REPONSE_CODE_VALUES_SUCCESS;
        }

        ret = R_BLE_GATTS_Indication(conn_hdl, &ind_data);
    }
    else
    {
        ret = BLE_ERR_INVALID_STATE;
    }

    return ret;
}

/***********************************************************************************************************************//**
 * Function Name: plxs_indicate_racp_response
 * Description  : This function sends Record Access Control Point characteristic Indication if Indication is enabled.
 * Arguments    : conn_hdl - connection handle
 *                opcode   - RACP opcode
 *                operand  - RACP operand
 * Return Value : BLE_SUCCESS - if successful
 *                BLE_ERR_INVALID_STATE - if failure
 **********************************************************************************************************************/
static ble_status_t plxs_indicate_racp_response(uint16_t conn_hdl, uint8_t opcode, uint16_t operand)
{
    ble_status_t    ret;
    uint16_t        cli_cnfg;
    uint8_t         byte_value[4] = { 0 };

    get_cli_cnfg(conn_hdl, BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_CLI_CNFG_DESC_HDL, &cli_cnfg);

    if ((cli_cnfg & BLE_GATTS_CLI_CNFG_INDICATION) != 0)
    {
        st_ble_gatt_hdl_value_pair_t ind_data =
        {
                .attr_hdl        = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_VAL_HDL,
                .value.p_value   = byte_value,
                .value.value_len = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_LEN,
        };

        if (BLE_PLXS_PRV_OPEREND_VALUE == gs_racp_info.racp_opcode)
        {
            /* Report Number of Stored Records */
            if (BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_NUMBER_OF_STORED_RECORDS_RESPONSE__OPERATOR__NULL__VALUE_OF_0X00_FROM_OPERATOR_TABLE__ == opcode)
            {
                byte_value[0] = opcode;
                byte_value[1] = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERATOR_NULL;
                BT_PACK_LE_2_BYTE(&byte_value[2], &operand);
            }
        }
        if (false == gs_racp_info.racp_operator)
        {
            /* for invalid operator */
            if (BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_RESPONSE_CODE__OPERATOR__NULL__VALUE_OF_0X00_FROM_OPERATOR_TABLE__ == opcode)
            {
                byte_value[0] = opcode;
                byte_value[1] = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERATOR_NULL;
                byte_value[2] = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_VALUES_FILTER_PARAMETERS__AS_APPROPRIATE_TO_OPERATOR_AND_SERVICE_1;
                byte_value[3] = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_REPONSE_CODE_VALUES_INVALID_OPERATOR;
            }
        }
        else if (false == gs_racp_info.racp_operand)
        {
            /* for unsupported operand */
            if (BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_RESPONSE_CODE__OPERATOR__NULL__VALUE_OF_0X00_FROM_OPERATOR_TABLE__ == opcode)
            {
                byte_value[0] = opcode;
                byte_value[1] = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERATOR_NULL;
                byte_value[2] =
                        BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_VALUES_FILTER_PARAMETERS__AS_APPROPRIATE_TO_OPERATOR_AND_SERVICE_1;
                byte_value[3] = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_REPONSE_CODE_VALUES_OPERAND_NOT_SUPPORTED;
            }
        }
        else
        {
            /* Do Nothing */
        }

        ret = R_BLE_GATTS_Indication(conn_hdl, &ind_data);
    }
    else
    {
        ret = BLE_ERR_INVALID_STATE;
    }

    return ret;
}

/***********************************************************************************************************************//**
 * Function Name: plxs_report_record
 * Description  : This function gets the record and notifies it.
 * Arguments    : none
 * Return Value : BLE_SUCCESS   - successful
 **********************************************************************************************************************/
static ble_status_t plxs_report_record(void)
{
    ble_status_t ret                      = BLE_SUCCESS;
    uint16_t result                       = 0;
    static st_ble_plxs_record_t *p_record = NULL;

    switch (gs_racp_info.racp_operator)
    {
        case BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERATOR_ALL_RECORDS:
        {
            if (false == gs_racp_info.racp_operand)
            {
                /* for unsuppoerted operand */
                plxs_indicate_racp_response(gs_conn_hdl,
                    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_RESPONSE_CODE__OPERATOR__NULL__VALUE_OF_0X00_FROM_OPERATOR_TABLE__,
                    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_VALUES_FILTER_PARAMETERS__AS_APPROPRIATE_TO_OPERATOR_AND_SERVICE_1);

                gs_racp_info.in_progress = false;
                gs_indicate_flag         = 1;
            }
            else
            {
                ret = plxs_operator_racp_all_records();
                gs_racp_info.in_progress = true;
            }
        }
        break;

        case BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERATOR_NULL:
        {
            if (false == gs_racp_info.is_req_abort)
            {
                /* for invalid operator */
                plxs_indicate_racp_response(gs_conn_hdl,
                    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_RESPONSE_CODE__OPERATOR__NULL__VALUE_OF_0X00_FROM_OPERATOR_TABLE__,
                    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_VALUES_FILTER_PARAMETERS__AS_APPROPRIATE_TO_OPERATOR_AND_SERVICE_1);

                gs_racp_info.in_progress = false;
                gs_indicate_flag         = 1;
            }
        }
        break;

        case 7:
        {
            /* for operator not found */
            plxs_indicate_operator_not_supported(gs_conn_hdl,
                BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_RESPONSE_CODE__OPERATOR__NULL__VALUE_OF_0X00_FROM_OPERATOR_TABLE__,
                BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_VALUES_FILTER_PARAMETERS__AS_APPROPRIATE_TO_OPERATOR_AND_SERVICE_1);

            gs_racp_info.in_progress = false;
            gs_indicate_flag         = 1;
        }
        break;

        default:
        {
            /* Do Nothing */
        }
        break;
    }

    if (1 != gs_indicate_flag)
    {
        if (false == gs_racp_info.is_req_abort)
        {
            if ((BLE_PLXS_DB_INVALID_INDEX == gs_racp_info.current_index) )//&& (0 != gs_racp_info.num_of_reports))
            {
                if (0 != gs_racp_info.num_of_reports)
                {
                    /* Finished to report all stored records. */
                    /* for report stored records (all records found) */
                    static uint16_t gs_all_records = 0;
                    if (0 == gs_all_records)
                    {
                        result = plxs_indicate_report_stored_all_records(gs_conn_hdl,
                            BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_RESPONSE_CODE__OPERATOR__NULL__VALUE_OF_0X00_FROM_OPERATOR_TABLE__,
                            BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_VALUES_FILTER_PARAMETERS__AS_APPROPRIATE_TO_OPERATOR_AND_SERVICE_1);

                        if (BLE_SUCCESS != result)
                        {
                            gs_racp_info.in_progress = true;
                        }
                        else
                        {
                            gs_racp_info.in_progress = false;
                        }
                        gs_all_records++;
                    }
                    else //if (1 == gs_all_records)
                    {
                        plxs_indicate_report_stored_no_records_found(gs_conn_hdl,
                            BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_RESPONSE_CODE__OPERATOR__NULL__VALUE_OF_0X00_FROM_OPERATOR_TABLE__,
                            BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_VALUES_FILTER_PARAMETERS__AS_APPROPRIATE_TO_OPERATOR_AND_SERVICE_1);

                        gs_racp_info.in_progress = false;
                        gs_all_records = 0;
                    }
                }
                else //0
                {
                    /* No record to report. */
                    plxs_indicate_report_stored_no_records_found(gs_conn_hdl,
                        BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_RESPONSE_CODE__OPERATOR__NULL__VALUE_OF_0X00_FROM_OPERATOR_TABLE__,
                        BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_VALUES_FILTER_PARAMETERS__AS_APPROPRIATE_TO_OPERATOR_AND_SERVICE_1);

                    gs_racp_info.in_progress = false;
                }
            }
            else
            {
                plxs_indicate_racp_response(gs_conn_hdl,
                    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_RESPONSE_CODE__OPERATOR__NULL__VALUE_OF_0X00_FROM_OPERATOR_TABLE__,
                    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_REPONSE_CODE_VALUES_SUCCESS);

                gs_racp_info.in_progress = false;
            }
        }
        else
        {
            if (BLE_PLXS_PRV_OPEREND_ABORT_VALUE == gs_racp_info.racp_operand)
            {
                /* for Abort_operation */
                plxs_indicate_abort_operation(gs_conn_hdl,
                    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_RESPONSE_CODE__OPERATOR__NULL__VALUE_OF_0X00_FROM_OPERATOR_TABLE__,
                    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_VALUES_NOT_INCLUDED);

                gs_racp_info.in_progress = false;
            }
        }
    }

    return ret;
}

/***********************************************************************************************************************//**
 * Function Name: plxs_delete_operator_racp_allrecords
 * Description  : This function deletes all the records.
 * Arguments    : none
 * Return Value : deleted   - no of records deleted
 **********************************************************************************************************************/
static uint16_t plxs_delete_operator_racp_allrecords(void)
{
    uint16_t num_of_records = 0;
    uint16_t deleted        = 0;
    uint16_t current_index  = gs_racp_info.current_index;
    uint16_t next_index     = BLE_PLXS_DB_INVALID_INDEX;

    if (0 == gs_num_of_reports)
    {
        num_of_records    = 0;
        deleted           = 0;
        gs_num_of_reports = 1;
    }
    else
    {
        while (BLE_PLXS_DB_INVALID_INDEX != current_index)
        {
            st_ble_plxs_record_t *p_record = plxs_db_get_record(current_index);

            next_index = p_record->next_index;

            /* delete the given record for the database */
            plxs_db_delete_record(current_index);

            current_index              = next_index;
            gs_racp_info.current_index = BLE_PLXS_DB_INVALID_INDEX;

            deleted++;
        }

        gs_num_of_reports = 0;
    }
    return deleted;
}

/***********************************************************************************************************************//**
 * Function Name: plxs_delete_record
 * Description  : This function deletes specific/all records based on the RACP operator.
 * Arguments    : none
 * Return Value : BLE_SUCCESS   - successful
 **********************************************************************************************************************/
static ble_status_t plxs_delete_record(void)
{
    switch (gs_racp_info.racp_operator)
    {
        case BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERATOR_ALL_RECORDS:
        {
            num_of_deleted = plxs_delete_operator_racp_allrecords();
        }
        break;

        default:
        {
            /* Not a valid delete operation. Do nothing. */
        }
        break;
    }
    printf("no deleted %d\n", num_of_deleted);
    /* Send appropriate response */
    if (0 != num_of_deleted)
    {
        plxs_indicate_delete_stored_records(gs_conn_hdl,
            BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_RESPONSE_CODE__OPERATOR__NULL__VALUE_OF_0X00_FROM_OPERATOR_TABLE__,
            BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_VALUES_FILTER_PARAMETERS__AS_APPROPRIATE_TO_OPERATOR_AND_SERVICE_2);
    }
    else
    {
        plxs_indicate_report_stored_no_records_found(gs_conn_hdl,
            BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_RESPONSE_CODE__OPERATOR__NULL__VALUE_OF_0X00_FROM_OPERATOR_TABLE__,
            BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_REPONSE_CODE_VALUES_NO_RECORDS_FOUND);
    }

    gs_racp_info.in_progress = false;

    return BLE_SUCCESS;
}

/***********************************************************************************************************************//**
 * Function Name: plxs_report_num_of_records
 * Description  : This function calculates number of records in the database and send RACP response.
 * Arguments    : none
 * Return Value : BLE_SUCCESS   - successful
 **********************************************************************************************************************/

static ble_status_t plxs_report_num_of_records(void)
{
    uint16_t num_of_records = 0;

    switch (gs_racp_info.racp_operator)
    {
        case BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERATOR_ALL_RECORDS:
        {
            uint16_t current_index = gs_racp_info.current_index;

            if (0 == gs_num_of_reports)
            {
                num_of_records    = 0;
                gs_num_of_reports = 1;
            }
            else
            {
                
                while (BLE_PLXS_DB_INVALID_INDEX != current_index)
                {
                    st_ble_plxs_record_t *p_record = plxs_db_get_record(current_index);
                    if (NULL != p_record)
                    {
                        current_index = p_record->next_index;
                        num_of_records++;
                    }
                    else
                    {
                        break; //break the loop
                    }
                }
            }
        }
        break;

        default:
        {
            /* Do nothing. */
        }
        break;
    }

    if (0 != num_of_records)
    {
        plxs_indicate_report_num_of_stored_recoreds(gs_conn_hdl,
            BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_NUMBER_OF_STORED_RECORDS_RESPONSE__OPERATOR__NULL__VALUE_OF_0X00_FROM_OPERATOR_TABLE__,
            num_of_records);
    }
    else
    {
        plxs_indicate_report_num_of_stored_recoreds_null(gs_conn_hdl,
            BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_NUMBER_OF_STORED_RECORDS_RESPONSE__OPERATOR__NULL__VALUE_OF_0X00_FROM_OPERATOR_TABLE__,
            BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_VALUES_N_A);
    }

    gs_racp_info.in_progress = false;

    return BLE_SUCCESS;
}

/***********************************************************************************************************************//**
 * Function Name: plxs_racp_event_cb
 * Description  : This function is callback to the RACP events.
 * Arguments    : none
 * Return Value : none
 **********************************************************************************************************************/
static void plxs_racp_event_cb(void)
{
    switch (gs_racp_info.racp_opcode)
    {
        case BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_RESERVED_FOR_FUTURE_USE__OPERATOR_N_A_:
        {
            plxs_indicate_opcode_not_supported(gs_conn_hdl,
                BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_RESPONSE_CODE__OPERATOR__NULL__VALUE_OF_0X00_FROM_OPERATOR_TABLE__,
                BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_VALUES_FILTER_PARAMETERS__AS_APPROPRIATE_TO_OPERATOR_AND_SERVICE_1);

            gs_racp_info.in_progress = false;
        }
        break;

        case BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_REPORT_STORED_RECORDS__OPERATOR__VALUE_FROM_OPERATOR_TABLE_:
        {
            plxs_report_record();
        }
        break;

        case BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_DELETE_STORED_RECORDS__OPERATOR__VALUE_FROM_OPERATOR_TABLE_:
        {
            plxs_delete_record();
        }
        break;

        case BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_REPORT_NUMBER_OF_STORED_RECORDS__OPERATOR__VALUE_FROM_OPERATOR_TABLE_:
        {
            plxs_report_num_of_records();
        }
        break;

        case BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_RESPONSE_CODE__OPERATOR__NULL__VALUE_OF_0X00_FROM_OPERATOR_TABLE__:
        {
            plxs_indicate_racp_response(gs_conn_hdl, gs_racp_info.racp_opcode, gs_racp_info.racp_operand);
        }
        break;

        default:
        {
            /* Do nothing. */
        }
        break;
    }
}

/***********************************************************************************************************************//**
 * Function Name: evt_write_req_record_access_control_point
 * Description  : This function handles the Record Access Control Point characteristic write request event.
 * Arguments    : conn_hdl - connection handle
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : none
 **********************************************************************************************************************/
static void evt_write_req_record_access_control_point(uint16_t conn_hdl, st_ble_gatt_value_t *p_gatt_value)
{
    ble_status_t ret  = 0;
    uint16_t cli_cnfg = 0;
    st_ble_plxs_record_access_control_point_t app_value;

    uint8_t racp_opcode                     = 0;
    uint8_t racp_operator                   = 0;
    uint8_t racp_operand                    = 0;
    uint8_t racp_response_code_value        = 0;
    racp_opcode                             = p_gatt_value->p_value[0];
    gs_racp_info.racp_opcode                = racp_opcode;
    racp_operator                           = p_gatt_value->p_value[1];
    gs_racp_info.racp_operator              = racp_operator;
    racp_operand                            = p_gatt_value->p_value[2];
    gs_racp_info.racp_operand               = racp_operand;
    racp_response_code_value                = p_gatt_value->p_value[3];
    gs_racp_info.racp_response_code_value   = racp_response_code_value;
    gs_conn_hdl                             = conn_hdl;

    /* for BLE_PLXS_PROCEDURE_ALREADY_IN_PROGRESS */
    if (gs_racp_info.in_progress)
    {
        if (BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_ABORT_OPERATION__OPERATOR__NULL__VALUE_OF_0X00_FROM_OPERATOR_TABLE__ == racp_opcode)
        {
            gs_racp_info.is_req_abort = true;

            gs_racp_info.racp_response_code_value = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_REPONSE_CODE_VALUES_SUCCESS;

            gs_racp_info.racp_opcode = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_REPORT_STORED_RECORDS__OPERATOR__VALUE_FROM_OPERATOR_TABLE_;

            R_BLE_SetEvent( plxs_racp_event_cb);

            return;
        }
        else
        {
            R_BLE_GATTS_SendErrRsp(BLE_PLXS_PROCEDURE_ALREADY_IN_PROGRESS);
            return;
        }
    }

    /* for BLE_PLXS_CLIENT_CHARACTERISTIC_CONFIGURATION_DESCRIPTOR_IMPROPERLY_CONFIGURED */
    get_cli_cnfg(conn_hdl, BLE_PLXS_PLX_SPOT_CHECK_MEASUREMENT_CLI_CNFG_DESC_HDL, &cli_cnfg);

    if ((cli_cnfg & BLE_GATTS_CLI_CNFG_INDICATION) == 0)
    {
        R_BLE_GATTS_SendErrRsp(BLE_PLXS_CLIENT_CHARACTERISTIC_CONFIGURATION_DESCRIPTOR_IMPROPERLY_CONFIGURED);
        return;
    }
    
    /* for Opcode Not Suppoerted */
    if (BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_RESERVED_FOR_FUTURE_USE__OPERATOR_N_A_ == racp_opcode)
    {
        gs_racp_info.racp_response_code_value = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_REPONSE_CODE_VALUES_SUCCESS;

        gs_racp_info.racp_opcode = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_RESERVED_FOR_FUTURE_USE__OPERATOR_N_A_;

        R_BLE_SetEvent( plxs_racp_event_cb);

        gs_racp_info.in_progress = true;

        return;

    }

    /* Report Stored Records */
    if ((BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_REPORT_STORED_RECORDS__OPERATOR__VALUE_FROM_OPERATOR_TABLE_ == racp_opcode))
    {
        gs_racp_info.racp_response_code_value = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_REPONSE_CODE_VALUES_SUCCESS;

        gs_racp_info.racp_opcode = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_REPORT_STORED_RECORDS__OPERATOR__VALUE_FROM_OPERATOR_TABLE_;

        R_BLE_SetEvent( plxs_racp_event_cb);

        gs_racp_info.in_progress = true;

        return;
    }

    /* Report Stored Number of Recoreds (All Records) */
    if ((BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_REPORT_NUMBER_OF_STORED_RECORDS__OPERATOR__VALUE_FROM_OPERATOR_TABLE_ == racp_opcode))
    {
        gs_racp_info.racp_response_code_value = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_REPONSE_CODE_VALUES_SUCCESS;

        gs_racp_info.racp_opcode = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_REPORT_NUMBER_OF_STORED_RECORDS__OPERATOR__VALUE_FROM_OPERATOR_TABLE_;

        R_BLE_SetEvent( plxs_racp_event_cb);

        return;
    }

    /* Delete Stored Records (All Records) */
    if ((BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_DELETE_STORED_RECORDS__OPERATOR__VALUE_FROM_OPERATOR_TABLE_ == racp_opcode))
    {
        gs_racp_info.racp_response_code_value = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_REPONSE_CODE_VALUES_SUCCESS;

        gs_racp_info.racp_opcode = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_DELETE_STORED_RECORDS__OPERATOR__VALUE_FROM_OPERATOR_TABLE_;

        R_BLE_SetEvent( plxs_racp_event_cb);

        return;
    }

    memset(&gs_racp_info, 0x00, sizeof(gs_racp_info));

    gs_racp_info.in_progress = true;
    gs_racp_info.current_index = plxs_db_get_oldest_index();

    /* Execute the procedure on next schedule. */
    R_BLE_SetEvent( plxs_racp_event_cb);
}

/***********************************************************************************************************************//**
 * Function Name: plxs_gatt_db_cb
 * Description  : Callback function for Pulse Oximeter Service GATT Server events.
 * Arguments    : conn_hdl - handle to the connection
 *                p_params - pointer to GATTS db parameter
 * Return Value : none
 **********************************************************************************************************************/
static void plxs_gatts_db_cb(uint16_t conn_hdl, st_ble_gatts_db_params_t *p_params) // @suppress("Function length")
{
    switch (p_params->db_op)
    {
        case BLE_GATTS_OP_CHAR_PEER_READ_REQ:
        {
            if (BLE_PLXS_PLX_FEATURES_VAL_HDL == p_params->attr_hdl)
            {
                st_ble_plxs_evt_data_t evt_data =
                {
                    .conn_hdl  = conn_hdl,
                    .param_len = 0,
                    .p_param   = NULL,
                };
                gs_plxs_cb(BLE_PLXS_EVENT_PLX_FEATURES_READ_REQ, BLE_SUCCESS, &evt_data);
            }
        }
        break;

        case BLE_GATTS_OP_CHAR_PEER_WRITE_REQ:
        {
            if (BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_VAL_HDL == p_params->attr_hdl)
            {
                evt_write_req_record_access_control_point(conn_hdl, &p_params->value);
            }
        }
        break;

        case BLE_GATTS_OP_CHAR_PEER_CLI_CNFG_WRITE_REQ:
        {
            uint16_t cli_cnfg;

            st_ble_plxs_evt_data_t evt_data =
            {
                .conn_hdl  = conn_hdl,
                .param_len = 0,
                .p_param   = NULL,
            };

            BT_UNPACK_LE_2_BYTE(&cli_cnfg, p_params->value.p_value);

            if (BLE_PLXS_PLX_SPOT_CHECK_MEASUREMENT_CLI_CNFG_DESC_HDL == p_params->attr_hdl)
            {
                if (BLE_GATTS_CLI_CNFG_INDICATION == cli_cnfg)
                {
                    gs_plxs_cb(BLE_PLXS_EVENT_PLX_SPOT_CHECK_MEASUREMENT_CLI_CNFG_ENABLED, BLE_SUCCESS, &evt_data);
                }
                else
                {
                    gs_plxs_cb(BLE_PLXS_EVENT_PLX_SPOT_CHECK_MEASUREMENT_CLI_CNFG_DISABLED, BLE_SUCCESS, &evt_data);
                }
            }
            else if (BLE_PLXS_PLX_CONTINUOUS_MEASUREMENT_CLI_CNFG_DESC_HDL == p_params->attr_hdl)
            {
                if (BLE_GATTS_CLI_CNFG_NOTIFICATION == cli_cnfg)
                {
                    gs_plxs_cb(BLE_PLXS_EVENT_PLX_CONTINUOUS_MEASUREMENT_CLI_CNFG_ENABLED, BLE_SUCCESS, &evt_data);
                }
                else
                {
                    gs_plxs_cb(BLE_PLXS_EVENT_PLX_CONTINUOUS_MEASUREMENT_CLI_CNFG_DISABLED, BLE_SUCCESS, &evt_data);
                }
            }
            else if (BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_CLI_CNFG_DESC_HDL == p_params->attr_hdl)
            {
                if (BLE_GATTS_CLI_CNFG_INDICATION == cli_cnfg)
                {
                    gs_plxs_cb(BLE_PLXS_EVENT_RECORD_ACCESS_CONTROL_POINT_CLI_CNFG_ENABLED, BLE_SUCCESS, &evt_data);
                }
                else
                {
                    gs_plxs_cb(BLE_PLXS_EVENT_RECORD_ACCESS_CONTROL_POINT_CLI_CNFG_DISABLED, BLE_SUCCESS, &evt_data);
                }
            }
            else
            {
                /* Do nothing. */
            }
        }
        break;

        default:
        {
            /* Do nothing. */
        }
        break;
    }
}

/***********************************************************************************************************************//**
 * Function Name: plx_gatts_cb
 * Description  : Callback function for the GATT Server events.
 * Arguments    : type - event id
 *                result - ble status
 *                p_data - pointer to the event data
 * Return Value : none
 **********************************************************************************************************************/
static void plxs_gatts_cb(uint16_t type, ble_status_t result, st_ble_gatts_evt_data_t *p_data)
{
    switch (type)
    {
        case BLE_GATTS_EVENT_DB_ACCESS_IND:
        {
            st_ble_gatts_db_access_evt_t *p_db_access_evt_param =
                (st_ble_gatts_db_access_evt_t *)p_data->p_param;

            plxs_gatts_db_cb(p_data->conn_hdl, p_db_access_evt_param->p_params);
        }
        break;

        case BLE_GATTS_EVENT_HDL_VAL_CNF:
        {
            st_ble_gatts_cfm_evt_t *p_cfm_evt_param =
                (st_ble_gatts_cfm_evt_t *)p_data->p_param;

            if (BLE_PLXS_PLX_SPOT_CHECK_MEASUREMENT_VAL_HDL == p_cfm_evt_param->attr_hdl)
            {
                st_ble_plxs_evt_data_t evt_data =
                {
                    .conn_hdl  = p_data->conn_hdl,
                    .param_len = 0,
                    .p_param   = NULL,
                };

                gs_plxs_cb(BLE_PLXS_EVENT_PLX_SPOT_CHECK_MEASUREMENT_HDL_VAL_CNF, result, &evt_data);
            }

            if (BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_VAL_HDL == p_cfm_evt_param->attr_hdl)
            {
                st_ble_plxs_evt_data_t evt_data =
                {
                    .conn_hdl  = p_data->conn_hdl,
                    .param_len = 0,
                    .p_param   = NULL,
                };

                gs_racp_info.in_progress = false;
                gs_plxs_cb(BLE_PLXS_EVENT_RECORD_ACCESS_CONTROL_POINT_HDL_VAL_CNF, result, &evt_data);
            }
        }
        break;

        default:
        {
            /* Do Nothing. */
        }
        break;
    }
}

/***********************************************************************************************************************//**
 * Function Name: R_BLE_PLXS_Init
 * Description  : This function initializes the GATTS Server and Pulse Oximeter Service, registers the callback function for
 *                GATTS.
 * Arguments    : p_param - pointer to the init parameters data
 * Return Value : BLE_SUCCESS               - Success
 *                BLE_ERR_INVALID_PTR       - The p_ntf_data parameter or the value field in the value field in
 *                                            the p_ntf_data parameter is NULL.
 *                BLE_ERR_INVALID_ARG       - The value_len field in the value field in the p_ntf_data parameter is 0
 *                                            or the attr_hdl field in the p_ntf_data parameters is 0.
 **********************************************************************************************************************/
ble_status_t R_BLE_PLXS_Init(const st_ble_plxs_init_param_t *p_param) // @suppress("API function naming")
{
    ble_status_t ret;
    if (NULL == p_param)
    {
        return BLE_ERR_INVALID_PTR;
    }
    else
    {
        /* DO NOTHING */
    }

    if (NULL == p_param->cb)
    {
        return BLE_ERR_INVALID_ARG;
    }
    else
    {
        /* DO NOTHING */
    }

    ret = R_BLE_GATTS_RegisterCb(plxs_gatts_cb, 1);
    gs_plxs_cb = p_param->cb;

    return BLE_SUCCESS;
}

/***********************************************************************************************************************//**
 * Function Name: R_BLE_PLXS_Connect
 * Description  : This function Connects the GATTS Server and Pulse Oximeter Service.
 * Arguments    : conn_hdl - Connection Handler
 *                p_param  - pointer to the Connecting parameters data
 * Return Value : BLE_SUCCESS         - Success
 *                BLE_ERR_INVALID_HDL - The remote device specified by conn_hdl was not found.
 **********************************************************************************************************************/
ble_status_t R_BLE_PLXS_Connect(uint16_t conn_hdl, const st_ble_plxs_connect_param_t *p_param) // @suppress("API function naming")
{
    if (BLE_GAP_INVALID_CONN_HDL == conn_hdl)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (NULL != p_param)
    {
        set_cli_cnfg(conn_hdl, BLE_PLXS_PLX_SPOT_CHECK_MEASUREMENT_CLI_CNFG_DESC_HDL, p_param->plx_spot_check_measurement_cli_cnfg);
        set_cli_cnfg(conn_hdl, BLE_PLXS_PLX_CONTINUOUS_MEASUREMENT_CLI_CNFG_DESC_HDL, p_param->plx_continuous_measurement_cli_cnfg);
        set_cli_cnfg(conn_hdl, BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_CLI_CNFG_DESC_HDL, p_param->record_access_control_point_cli_cnfg);
    }

    return BLE_SUCCESS;
}

/***********************************************************************************************************************//**
 * Function Name: R_BLE_PLXS_Disconnect
 * Description  : This function Dis_Connects the GATTS Server and Pulse Oximeter Service.
 * Arguments    : conn_hdl - Connection Handler
 *                p_param  - pointer to the Connecting parameters data
 * Return Value : BLE_SUCCESS         - Success
 *                BLE_ERR_INVALID_HDL - The remote device specified by conn_hdl was not found.
 **********************************************************************************************************************/
ble_status_t R_BLE_PLXS_Disconnect(uint16_t conn_hdl, st_ble_plxs_disconnect_param_t *p_param) // @suppress("API function naming")
{
    if (BLE_GAP_INVALID_CONN_HDL == conn_hdl)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (NULL != p_param)
    {
        get_cli_cnfg(conn_hdl, BLE_PLXS_PLX_SPOT_CHECK_MEASUREMENT_CLI_CNFG_DESC_HDL, &p_param->plx_spot_check_measurement_cli_cnfg);
        get_cli_cnfg(conn_hdl, BLE_PLXS_PLX_CONTINUOUS_MEASUREMENT_CLI_CNFG_DESC_HDL, &p_param->plx_continuous_measurement_cli_cnfg);
        get_cli_cnfg(conn_hdl, BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_CLI_CNFG_DESC_HDL, &p_param->record_access_control_point_cli_cnfg);
    }

    return BLE_SUCCESS;
}

/***********************************************************************************************************************//**
 * Function Name: R_BLE_PLXS_IndicatePlxSpotcheckMeasurement
 * Description  : This function Indicates Pulse Oximeter Service Spot Check Measurement
 * Arguments    : conn_hdl     - Connection handle identifying the remote device to be sent the indication.
 *                p_app_value  - pointer to the Connecting parameters data(The attribute value to send)
 * Return Value : BLE_SUCCESS           - Success
 *                BLE_ERR_INVALID_PTR   - The p_ntf_data parameter or the value field in the value field in
 *                                        the p_ntf_data parameter is NULL.
 *                BLE_ERR_INVALID_HDL   - The remote device specified by conn_hdl was not found.
 *                BLE_ERR_INVALID_STATE - The attribute is not in a state to be written.
 **********************************************************************************************************************/
ble_status_t R_BLE_PLXS_IndicatePlxSpotcheckMeasurement(uint16_t conn_hdl,
    const st_ble_plxs_plx_spot_check_measurement_t *p_app_value) // @suppress("API function naming")
{
    ble_status_t ret;
    uint16_t cli_cnfg;

    if (NULL == p_app_value)
    {
        return BLE_ERR_INVALID_PTR;
    }

    ret = get_cli_cnfg(conn_hdl, BLE_PLXS_PLX_SPOT_CHECK_MEASUREMENT_CLI_CNFG_DESC_HDL, &cli_cnfg);

    if (BLE_SUCCESS != ret)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if ((cli_cnfg & BLE_GATTS_CLI_CNFG_INDICATION) == 0x0000)
    {
        return BLE_ERR_INVALID_STATE;
    }

    uint8_t byte_value[BLE_PLXS_PLX_SPOT_CHECK_MEASUREMENT_LEN] = { 0 };

    st_ble_gatt_hdl_value_pair_t ind_data =
    {
        .attr_hdl        = BLE_PLXS_PLX_SPOT_CHECK_MEASUREMENT_VAL_HDL,
        .value.p_value   = byte_value,
        .value.value_len = BLE_PLXS_PLX_SPOT_CHECK_MEASUREMENT_LEN,
    };

    ret = encode_plx_spot_check_measurement(p_app_value, &ind_data.value);

    return R_BLE_GATTS_Indication(conn_hdl, &ind_data);
}

/***********************************************************************************************************************//**
 * Function Name: R_BLE_PLXS_NotifyPlxContinuousMeasurement
 * Description  : This function Notifies Pulse Oximeter Service Spot Check Measurement
 * Arguments    : conn_hdl     - Connection Handler
 *                p_app_value  - pointer to the Connecting parameters data
 * Return Value : BLE_SUCCESS           - Success
 *                BLE_ERR_INVALID_PTR   - The p_ntf_data parameter or the value field in the value field in
 *                                        the p_ntf_data parameter is NULL.
 *                BLE_ERR_INVALID_HDL   - The remote device specified by conn_hdl was not found.
 *                BLE_ERR_INVALID_STATE - The attribute is not in a state to be written.
 **********************************************************************************************************************/
ble_status_t R_BLE_PLXS_NotifyPlxContinuousMeasurement(uint16_t conn_hdl,
    const st_ble_plxs_plx_continuous_measurement_t *p_app_value) // @suppress("API function naming")
{
    ble_status_t ret;
    uint16_t cli_cnfg;

    if (NULL == p_app_value)
    {
        return BLE_ERR_INVALID_PTR;
    }

    ret = get_cli_cnfg(conn_hdl, BLE_PLXS_PLX_CONTINUOUS_MEASUREMENT_CLI_CNFG_DESC_HDL, &cli_cnfg);

    if (BLE_SUCCESS != ret)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if ((cli_cnfg & BLE_GATTS_CLI_CNFG_NOTIFICATION) == 0x0000)
    {
        return BLE_ERR_INVALID_STATE;
    }

    uint8_t byte_value[BLE_PLXS_PLX_CONTINUOUS_MEASUREMENT_LEN] = { 0 };

    st_ble_gatt_hdl_value_pair_t ntf_data =
    {
        .attr_hdl        = BLE_PLXS_PLX_CONTINUOUS_MEASUREMENT_VAL_HDL,
        .value.p_value   = byte_value,
        .value.value_len = BLE_PLXS_PLX_CONTINUOUS_MEASUREMENT_LEN,
    };

    ret = encode_plx_continuous_measurement(p_app_value, &ntf_data.value);

    return R_BLE_GATTS_Notification(conn_hdl, &ntf_data);
}

/***********************************************************************************************************************//**
 * Function Name: R_BLE_PLXS_GetPlxFeatures
 * Description  : This function gets the Pulse Oximeter Service Features data
 * Arguments    : p_app_value  - pointer to the Plx Features parameter data
 * Return Value : BLE_SUCCESS           - Success
 *                BLE_ERR_INVALID_PTR   - The p_ntf_data parameter or the value field in the value field in
 *                                        the p_ntf_data parameter is NULL.
 *                BLE_ERR_INVALID_HDL   - The remote device specified by conn_hdl was not found.
 *                BLE_ERR_INVALID_STATE - The attribute is not in a state to be written.
 **********************************************************************************************************************/
ble_status_t R_BLE_PLXS_GetPlxFeatures(st_ble_plxs_plx_features_t *p_app_value) // @suppress("API function naming")
{
    st_ble_gatt_value_t gatt_value;
    ble_status_t ret;

    if (NULL == p_app_value)
    {
        return BLE_ERR_INVALID_DATA;
    }

    ret = R_BLE_GATTS_GetAttr(BLE_GAP_INVALID_CONN_HDL, BLE_PLXS_PLX_FEATURES_VAL_HDL, &gatt_value);

    if (BLE_SUCCESS == ret)
    {
        ret = decode_plx_features(p_app_value, &gatt_value);
    }

    return ret;
}

/***********************************************************************************************************************//**
 * Function Name: R_BLE_PLXS_SetPlxFeatures
 * Description  : This function sets the Pulse Oximeter Service Features data
 * Arguments    : p_app_value  - pointer to the Plx Features parameter data
 * Return Value : BLE_SUCCESS           - Success
 *                BLE_ERR_INVALID_PTR   - The p_ntf_data parameter or the value field in the value field in
 *                                        the p_ntf_data parameter is NULL.
 *                BLE_ERR_INVALID_HDL   - The remote device specified by conn_hdl was not found.
 *                BLE_ERR_INVALID_STATE - The attribute is not in a state to be written.
 **********************************************************************************************************************/
ble_status_t R_BLE_PLXS_SetPlxFeatures(const st_ble_plxs_plx_features_t *p_app_value) // @suppress("API function naming")
{
    ble_status_t ret;
    uint8_t byte_value[BLE_PLXS_PLX_FEATURES_LEN] = { 0 };

    st_ble_gatt_value_t gatt_value =
    {
        .p_value   = byte_value,
        .value_len = BLE_PLXS_PLX_FEATURES_LEN,
    };

    ret = encode_plx_features(p_app_value, &gatt_value);

    return R_BLE_GATTS_SetAttr(BLE_GAP_INVALID_CONN_HDL, BLE_PLXS_PLX_FEATURES_VAL_HDL, &gatt_value);
}

/***********************************************************************************************************************//**
 * Function Name: R_BLE_PLXS_IndicateRecordAccessControlPoint
 * Description  : This function Indicates the Pulse Oximeter Service Record Access Control Point data
 * Arguments    : conn_hdl     - handle to connection.
 *                p_app_value  - pointer to the Record Access Control Point parameter data
 * Return Value : BLE_SUCCESS           - Success
 *                BLE_ERR_INVALID_PTR   - The p_ntf_data parameter or the value field in the value field in
 *                                        the p_ntf_data parameter is NULL.
 *                BLE_ERR_INVALID_HDL	- The remote device specified by conn_hdl was not found.
 *                BLE_ERR_INVALID_STATE - The attribute is not in a state to be written.
 **********************************************************************************************************************/
ble_status_t R_BLE_PLXS_IndicateRecordAccessControlPoint(uint16_t conn_hdl,
    const st_ble_plxs_record_access_control_point_t *p_app_value) // @suppress("API function naming")
{
    ble_status_t ret;
    uint16_t cli_cnfg;

    if (NULL == p_app_value)
    {
        return BLE_ERR_INVALID_PTR;
    }

    ret = get_cli_cnfg(conn_hdl, BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_CLI_CNFG_DESC_HDL, &cli_cnfg);

    if (BLE_SUCCESS != ret)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if ((cli_cnfg & BLE_GATTS_CLI_CNFG_INDICATION) == 0x0000)
    {
        return BLE_ERR_INVALID_STATE;
    }

    uint8_t byte_value[BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_LEN] = { 0 };

    st_ble_gatt_hdl_value_pair_t ind_data =
    {
        .attr_hdl        = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_VAL_HDL,
        .value.p_value   = byte_value,
        .value.value_len = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_LEN,
    };

    ret = encode_record_access_control_point(p_app_value, &ind_data.value);

    return R_BLE_GATTS_Indication(conn_hdl, &ind_data);
}

/***********************************************************************************************************************//**
 * Function Name: R_BLE_PLXS_GetVersion
 * Description  : This function gets the Pulse Oximeter Service Version
 * Arguments    : none
 * Return Value : version - version of the device
 **********************************************************************************************************************/
uint32_t R_BLE_PLXS_GetVersion(void) // @suppress("API function naming")
{
    uint32_t version;

    version = ((BLE_PLXS_PRV_VERSION_MAJOR << 16) | (BLE_PLXS_PRV_VERSION_MINOR << 8));

    return version;
}
