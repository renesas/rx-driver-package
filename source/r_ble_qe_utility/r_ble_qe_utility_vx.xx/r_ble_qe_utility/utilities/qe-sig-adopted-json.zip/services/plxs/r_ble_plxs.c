/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_plxs.c
 * Version : 1.0
 * Description : The source file for Pulse Oximeter Service service.
 **********************************************************************************************************************/

#include "r_ble_plxs.h"
#include "profile_cmn/r_ble_servs_if.h"
#include "gatt_db.h"

#ifndef UNUSED_ARG
#define UNUSED_ARG(arg)         (void)(arg)
#endif /* UNUSED_ARG */

static st_ble_servs_info_t gs_servs_info;
static bool gs_in_progress = false;
static bool gs_abort = false;

/*----------------------------------------------------------------------------------------------------------------------
    static function for common field structure.
----------------------------------------------------------------------------------------------------------------------*/
static uint8_t pack_st_ble_plxs_measurement_status_t(uint8_t *p_dst, const st_ble_plxs_measurement_status_t *p_src)
{
    uint32_t pos = 0;
    uint16_t temp_data;

    temp_data = (uint8_t)(((p_src->is_measurement_ongoing & 0x01) << 5)
              | ((p_src->is_early_estimated_data & 0x01) << 6)
              | ((p_src->is_validated_data & 0x01) << 7)
              | ((p_src->is_fully_qualified_data & 0x01) << 8)
              | ((p_src->is_data_from_measurement_storage & 0x01) << 9)
              | ((p_src->is_data_for_demonstration & 0x01) << 10)
              | ((p_src->is_data_for_testing & 0x01) << 11)
              | ((p_src->is_calibration_ongoing & 0x01) << 12)
              | ((p_src->is_measurement_unavailable & 0x01) << 13)
              | ((p_src->is_questionable_measurement_detected & 0x01) << 14)
              | ((p_src->is_invalid_measurement_detected & 0x01) << 15));
    
    BT_PACK_LE_2_BYTE(p_dst, &temp_data);
    pos += 2;

    return (uint8_t)pos;
}

static uint8_t pack_st_ble_plxs_device_and_sensor_status_t(uint8_t *p_dst, const st_ble_plxs_device_and_sensor_status_t *p_src)
{
    uint32_t pos = 0;
    uint32_t temp_data;

    temp_data = (uint8_t)(((p_src->is_extended_display_update_ongoing & 0x01) << 0)
              | ((p_src->is_equipment_malfunction_detected & 0x01) << 1)
              | ((p_src->is_signal_processing_irregularity_detected & 0x01) << 2)
              | ((p_src->is_inadequite_signal_detected & 0x01) << 3)
              | ((p_src->is_poor_signal_detected & 0x01) << 4)
              | ((p_src->is_low_perfusion_detected & 0x01) << 5)
              | ((p_src->is_erratic_signal_detected & 0x01) << 6)
              | ((p_src->is_nonpulsatile_signal_detected & 0x01) << 7)
              | ((p_src->is_questionable_pulse_detected & 0x01) << 8)
              | ((p_src->is_signal_analysis_ongoing & 0x01) << 9)
              | ((p_src->is_sensor_interface_detected & 0x01) << 10)
              | ((p_src->is_sensor_unconnected_to_user & 0x01) << 11)
              | ((p_src->is_unknown_sensor_connected & 0x01) << 12)
              | ((p_src->is_sensor_displaced & 0x01) << 13)
              | ((p_src->is_sensor_malfunctioning & 0x01) << 14)
              | ((p_src->is_sensor_disconnected & 0x01) << 15));


    BT_PACK_LE_3_BYTE(p_dst, &temp_data);
    pos += 3;
    
    return (uint8_t)pos;
}

static uint8_t unpack_st_ble_plxs_measurement_status_t(st_ble_plxs_measurement_status_t *p_dst, const uint8_t *p_src)
{
    uint32_t pos = 0;
    uint16_t temp_data = 0;

    BT_UNPACK_LE_2_BYTE(&temp_data, p_src)
    pos += 2;

    p_dst->is_measurement_ongoing = (temp_data >> 5) & 0x01;
    p_dst->is_early_estimated_data = (temp_data >> 6) & 0x01;
    p_dst->is_validated_data = (temp_data >> 7) & 0x01;
    p_dst->is_fully_qualified_data = (temp_data >> 8) & 0x01;
    p_dst->is_data_from_measurement_storage = (temp_data >> 9) & 0x01;
    p_dst->is_data_for_demonstration = (temp_data >> 10) & 0x01;
    p_dst->is_data_for_testing = (temp_data >> 11) & 0x01;
    p_dst->is_calibration_ongoing = (temp_data >> 12) & 0x01;
    p_dst->is_measurement_unavailable = (temp_data >> 13) & 0x01;
    p_dst->is_questionable_measurement_detected = (temp_data >> 14) & 0x01;
    p_dst->is_invalid_measurement_detected = (temp_data >> 15) & 0x01;

    return (uint8_t)pos;
}

static uint8_t unpack_st_ble_plxs_device_and_sensor_status_t(st_ble_plxs_device_and_sensor_status_t *p_dst, const uint8_t *p_src)
{
    uint32_t pos = 0;
    uint32_t temp_data = 0;

    BT_UNPACK_LE_3_BYTE(&temp_data, p_src)
    pos += 3;

    p_dst->is_extended_display_update_ongoing = (temp_data >> 0) & 0x01;
    p_dst->is_equipment_malfunction_detected = (temp_data >> 1) & 0x01;
    p_dst->is_signal_processing_irregularity_detected = (temp_data >> 2) & 0x01;
    p_dst->is_inadequite_signal_detected = (temp_data >> 3) & 0x01;
    p_dst->is_poor_signal_detected = (temp_data >> 4) & 0x01;
    p_dst->is_low_perfusion_detected = (temp_data >> 5) & 0x01;
    p_dst->is_erratic_signal_detected = (temp_data >> 6) & 0x01;
    p_dst->is_nonpulsatile_signal_detected = (temp_data >> 7) & 0x01;
    p_dst->is_questionable_pulse_detected = (temp_data >> 8) & 0x01;
    p_dst->is_signal_analysis_ongoing = (temp_data >> 9) & 0x01;
    p_dst->is_sensor_interface_detected = (temp_data >> 10) & 0x01;
    p_dst->is_sensor_unconnected_to_user = (temp_data >> 11) & 0x01;
    p_dst->is_unknown_sensor_connected = (temp_data >> 12) & 0x01;
    p_dst->is_sensor_displaced = (temp_data >> 13) & 0x01;
    p_dst->is_sensor_malfunctioning = (temp_data >> 14) & 0x01;
    p_dst->is_sensor_disconnected = (temp_data >> 15) & 0x01;

    return (uint8_t)pos;
}


/*----------------------------------------------------------------------------------------------------------------------
    PLX Spot-Check Measurement Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

static const st_ble_servs_desc_info_t gs_plx_spot_check_measurement_cli_cnfg = {
    .attr_hdl = BLE_PLXS_PLX_SPOT_CHECK_MEASUREMENT_CLI_CNFG_DESC_HDL,
    .app_size = sizeof(uint16_t),
    .desc_idx = BLE_PLXS_PLX_SPOT_CHECK_MEASUREMENT_CLI_CNFG_IDX,
    .db_size  = BLE_PLXS_PLX_SPOT_CHECK_MEASUREMENT_CLI_CNFG_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_uint16_t,
    .encode   = (ble_servs_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_PLXS_SetPlxSpotCheckMeasurementCliCnfg(uint16_t conn_hdl, const uint16_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_plx_spot_check_measurement_cli_cnfg, conn_hdl, (const void *)p_value);
}

ble_status_t R_BLE_PLXS_GetPlxSpotCheckMeasurementCliCnfg(uint16_t conn_hdl, uint16_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_plx_spot_check_measurement_cli_cnfg, conn_hdl, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    PLX Spot-Check Measurement characteristic
----------------------------------------------------------------------------------------------------------------------*/

static ble_status_t decode_st_ble_plxs_plx_spot_check_measurement_t(st_ble_plxs_plx_spot_check_measurement_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    UNUSED_ARG(p_app_value);
    UNUSED_ARG(p_gatt_value);

    /* Do nothing. */
    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_plxs_plx_spot_check_measurement_t(const st_ble_plxs_plx_spot_check_measurement_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;
    uint8_t flags;

    flags = (uint8_t)(((p_app_value->flags.is_timestamp_field_is_present & 0x01) << 0)
          | ((p_app_value->flags.is_measurement_status_field_present & 0x01) << 1)
          | ((p_app_value->flags.is_device_and_sensor_status_field_present & 0x01) << 2)
          | ((p_app_value->flags.is_pulse_amplitude_index_field_is_present & 0x01) << 3)
          | ((p_app_value->flags.is_device_clock_is_not_set & 0x01) << 4));
    
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &flags);
    pos++;
    
    pos += pack_st_ble_ieee11073_sfloat_t(&p_gatt_value->p_value[pos], &p_app_value->spo2pr_spot_check_spo2);
    pos += pack_st_ble_ieee11073_sfloat_t(&p_gatt_value->p_value[pos], &p_app_value->spo2pr_spot_check_pr);

    if(p_app_value->flags.is_timestamp_field_is_present)
    {
        pos += pack_st_ble_date_time_t(&p_gatt_value->p_value[pos], &p_app_value->timestamp);
    }

    if(p_app_value->flags.is_measurement_status_field_present)
    {
        pos += pack_st_ble_plxs_measurement_status_t(&p_gatt_value->p_value[pos], &p_app_value->measurement_status);
    }

    if(p_app_value->flags.is_device_and_sensor_status_field_present)
    {
        pos += pack_st_ble_plxs_device_and_sensor_status_t(&p_gatt_value->p_value[pos], &p_app_value->device_and_sensor_status);
    }

    if(p_app_value->flags.is_pulse_amplitude_index_field_is_present)
    {
        pos += pack_st_ble_ieee11073_sfloat_t(&p_gatt_value->p_value[pos], &p_app_value->pulse_amplitude_index);
    }

    p_gatt_value->value_len = (uint16_t)pos;

    return BLE_SUCCESS;
}

/* PLX Spot-Check Measurement characteristic descriptor definition */
static const st_ble_servs_desc_info_t *gspp_plx_spot_check_measurement_descs[] = {
    &gs_plx_spot_check_measurement_cli_cnfg,
};

static void plxs_pscmeas_hdlvalcnf_cb(const void *p_attr, uint16_t conn_hdl)
{
    UNUSED_ARG(p_attr);

    if(true == gs_abort)
    {
        gs_in_progress = false;
        gs_abort = false;
        st_ble_plxs_record_access_control_point_t racp_rsp_value = {
            .op_code = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_RESPONSE_CODE,
            .operator = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERATOR_NULL,
            .operand.rsp_value.req_op_code = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_ABORT_OPERATION,
            .operand.rsp_value.rsp_code = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_RESPONSE_VALUE_SUCCESS,
        };
        R_BLE_PLXS_IndicateRecordAccessControlPoint(conn_hdl, &racp_rsp_value);
    }

    if(true == gs_in_progress)
    {
        e_ble_plxs_db_result_t ret = BLE_PLXS_DB_SUCCESS;
        st_ble_plxs_plx_spot_check_measurement_t psc_meas;
        R_BLE_PLXS_DB_DeleteRecordOldest();
        ret = R_BLE_PLXS_DB_GetRecordOldest(&psc_meas);
        
        if(BLE_PLXS_DB_ERR_DB_EMPTY == ret)
        {
            gs_in_progress = false;
            st_ble_plxs_record_access_control_point_t racp_rsp_value = {
                .op_code = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_RESPONSE_CODE,
                .operator = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERATOR_NULL,
                .operand.rsp_value.req_op_code = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_REPORT_STORED_RECORDS,
                .operand.rsp_value.rsp_code = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_RESPONSE_VALUE_SUCCESS,
            };
            R_BLE_PLXS_IndicateRecordAccessControlPoint(conn_hdl, &racp_rsp_value);
        }
        else
        {
            R_BLE_PLXS_IndicatePlxSpotCheckMeasurement(conn_hdl, &psc_meas);
        }
    }

    st_ble_servs_evt_data_t evt_data = {
        .conn_hdl = conn_hdl,
        .param_len = 0,
        .p_param = NULL,
    };

    gs_servs_info.cb(BLE_PLXS_EVENT_PLX_SPOT_CHECK_MEASUREMENT_HDL_VAL_CNF, BLE_SUCCESS, &evt_data);
    return;
}

/* PLX Spot-Check Measurement characteristic definition */
static const st_ble_servs_char_info_t gs_plx_spot_check_measurement_char = {
    .start_hdl    = BLE_PLXS_PLX_SPOT_CHECK_MEASUREMENT_DECL_HDL,
    .end_hdl      = BLE_PLXS_PLX_SPOT_CHECK_MEASUREMENT_CLI_CNFG_DESC_HDL,
    .char_idx     = BLE_PLXS_PLX_SPOT_CHECK_MEASUREMENT_IDX,
    .app_size     = sizeof(st_ble_plxs_plx_spot_check_measurement_t),
    .db_size      = BLE_PLXS_PLX_SPOT_CHECK_MEASUREMENT_LEN,
    .decode       = (ble_servs_attr_decode_t)decode_st_ble_plxs_plx_spot_check_measurement_t,
    .encode       = (ble_servs_attr_encode_t)encode_st_ble_plxs_plx_spot_check_measurement_t,
    .pp_descs     = gspp_plx_spot_check_measurement_descs,
    .num_of_descs = ARRAY_SIZE(gspp_plx_spot_check_measurement_descs),
    .hdl_val_cnf_cb = (ble_servs_attr_hdl_val_cnf_t)plxs_pscmeas_hdlvalcnf_cb,
};

ble_status_t R_BLE_PLXS_IndicatePlxSpotCheckMeasurement(uint16_t conn_hdl, const st_ble_plxs_plx_spot_check_measurement_t *p_value)
{
    return R_BLE_SERVS_SendHdlVal(&gs_plx_spot_check_measurement_char, conn_hdl, (const void *)p_value, false);
}

/*----------------------------------------------------------------------------------------------------------------------
    PLX Continuous Measurement Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

static const st_ble_servs_desc_info_t gs_plx_continuous_measurement_cli_cnfg = {
    .attr_hdl = BLE_PLXS_PLX_CONTINUOUS_MEASUREMENT_CLI_CNFG_DESC_HDL,
    .app_size = sizeof(uint16_t),
    .desc_idx = BLE_PLXS_PLX_CONTINUOUS_MEASUREMENT_CLI_CNFG_IDX,
    .db_size  = BLE_PLXS_PLX_CONTINUOUS_MEASUREMENT_CLI_CNFG_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_uint16_t,
    .encode   = (ble_servs_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_PLXS_SetPlxContinuousMeasurementCliCnfg(uint16_t conn_hdl, const uint16_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_plx_continuous_measurement_cli_cnfg, conn_hdl, (const void *)p_value);
}

ble_status_t R_BLE_PLXS_GetPlxContinuousMeasurementCliCnfg(uint16_t conn_hdl, uint16_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_plx_continuous_measurement_cli_cnfg, conn_hdl, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    PLX Continuous Measurement characteristic
----------------------------------------------------------------------------------------------------------------------*/

static ble_status_t decode_st_ble_plxs_plx_continuous_measurement_t(st_ble_plxs_plx_continuous_measurement_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    UNUSED_ARG(p_app_value);
    UNUSED_ARG(p_gatt_value);

    /* Do nothing. */
    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_plxs_plx_continuous_measurement_t(const st_ble_plxs_plx_continuous_measurement_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;
    uint8_t flags;

    flags = (uint8_t)(((p_app_value->flags.is_spo2pr_fast_field_is_present & 0x01) << 0)
          | ((p_app_value->flags.is_spo2pr_slow_field_is_present & 0x01) << 1)
          | ((p_app_value->flags.is_measurement_status_field_is_present & 0x01) << 2)
          | ((p_app_value->flags.is_device_and_sensor_status_field_is_present & 0x01) << 3)
          | ((p_app_value->flags.is_pulse_amplitude_index_field_is_present & 0x01) << 4));

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &flags);
    pos++;
    
    pos += pack_st_ble_ieee11073_sfloat_t(&p_gatt_value->p_value[pos], &p_app_value->spo2pr_normal_spo2);
    pos += pack_st_ble_ieee11073_sfloat_t(&p_gatt_value->p_value[pos], &p_app_value->spo2pr_normal_pr);

    if(p_app_value->flags.is_spo2pr_fast_field_is_present)
    {
        pos += pack_st_ble_ieee11073_sfloat_t(&p_gatt_value->p_value[pos], &p_app_value->spo2pr_fast_spo2);
        pos += pack_st_ble_ieee11073_sfloat_t(&p_gatt_value->p_value[pos], &p_app_value->spo2pr_fast_pr);
    }

    if(p_app_value->flags.is_spo2pr_slow_field_is_present)
    {
        pos += pack_st_ble_ieee11073_sfloat_t(&p_gatt_value->p_value[pos], &p_app_value->spo2pr_slow_spo2);
        pos += pack_st_ble_ieee11073_sfloat_t(&p_gatt_value->p_value[pos], &p_app_value->spo2pr_slow_pr);
    }

    if(p_app_value->flags.is_measurement_status_field_is_present)
    {
        pos += pack_st_ble_plxs_measurement_status_t(&p_gatt_value->p_value[pos], &p_app_value->measurement_status);
    }

    if(p_app_value->flags.is_device_and_sensor_status_field_is_present)
    {
        pos += pack_st_ble_plxs_device_and_sensor_status_t(&p_gatt_value->p_value[pos], &p_app_value->device_and_sensor_status);
    }

    if(p_app_value->flags.is_pulse_amplitude_index_field_is_present)
    {
        pos += pack_st_ble_ieee11073_sfloat_t(&p_gatt_value->p_value[pos], &p_app_value->pulse_amplitude_index);
    }

    p_gatt_value->value_len = (uint16_t)pos;
    return BLE_SUCCESS;
}

/* PLX Continuous Measurement characteristic descriptor definition */
static const st_ble_servs_desc_info_t *gspp_plx_continuous_measurement_descs[] = {
    &gs_plx_continuous_measurement_cli_cnfg,
};

/* PLX Continuous Measurement characteristic definition */
static const st_ble_servs_char_info_t gs_plx_continuous_measurement_char = {
    .start_hdl    = BLE_PLXS_PLX_CONTINUOUS_MEASUREMENT_DECL_HDL,
    .end_hdl      = BLE_PLXS_PLX_CONTINUOUS_MEASUREMENT_CLI_CNFG_DESC_HDL,
    .char_idx     = BLE_PLXS_PLX_CONTINUOUS_MEASUREMENT_IDX,
    .app_size     = sizeof(st_ble_plxs_plx_continuous_measurement_t),
    .db_size      = BLE_PLXS_PLX_CONTINUOUS_MEASUREMENT_LEN,
    .decode       = (ble_servs_attr_decode_t)decode_st_ble_plxs_plx_continuous_measurement_t,
    .encode       = (ble_servs_attr_encode_t)encode_st_ble_plxs_plx_continuous_measurement_t,
    .pp_descs     = gspp_plx_continuous_measurement_descs,
    .num_of_descs = ARRAY_SIZE(gspp_plx_continuous_measurement_descs),
};

ble_status_t R_BLE_PLXS_NotifyPlxContinuousMeasurement(uint16_t conn_hdl, const st_ble_plxs_plx_continuous_measurement_t *p_value)
{
    return R_BLE_SERVS_SendHdlVal(&gs_plx_continuous_measurement_char, conn_hdl, (const void *)p_value, true);
}

/*----------------------------------------------------------------------------------------------------------------------
    PLX Features characteristic
----------------------------------------------------------------------------------------------------------------------*/

static ble_status_t decode_st_ble_plxs_plx_features_t(st_ble_plxs_plx_features_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;
    uint16_t features = 0;

    BT_UNPACK_LE_2_BYTE(&features, &p_gatt_value->p_value[pos]);
    pos += 2;

    p_app_value->supported_features.is_measurement_status_support_is_present = (features >> 0) & 0x01;
    p_app_value->supported_features.is_device_and_sensor_status_support_is_present = (features >> 1) & 0x01;
    p_app_value->supported_features.is_measurement_storage_for_spot_check_measurements_is_supported = (features >> 2) & 0x01;
    p_app_value->supported_features.is_timestamp_for_spot_check_measurements_is_supported = (features >> 3) & 0x01;
    p_app_value->supported_features.is_spo2pr_fast_metric_is_supported = (features >> 4) & 0x01;
    p_app_value->supported_features.is_spo2pr_slow_metric_is_supported = (features >> 5) & 0x01;
    p_app_value->supported_features.is_pulse_amplitude_index_field_is_supported = (features >> 6) & 0x01;
    p_app_value->supported_features.is_multiple_bonds_supported = (features >> 7) & 0x01;

    if(p_app_value->supported_features.is_measurement_status_support_is_present)
    {
        pos += unpack_st_ble_plxs_measurement_status_t(&p_app_value->measurement_status_support, &p_gatt_value->p_value[pos]);
    }

    if(p_app_value->supported_features.is_device_and_sensor_status_support_is_present)
    {
        pos += unpack_st_ble_plxs_device_and_sensor_status_t(&p_app_value->device_and_sensor_status_support, &p_gatt_value->p_value[pos]);
    }

    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_plxs_plx_features_t(const st_ble_plxs_plx_features_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;
    uint16_t features;

    features = (uint8_t)(((p_app_value->supported_features.is_measurement_status_support_is_present & 0x01) << 0)
             | ((p_app_value->supported_features.is_device_and_sensor_status_support_is_present & 0x01) << 1)
             | ((p_app_value->supported_features.is_measurement_storage_for_spot_check_measurements_is_supported & 0x01) << 2)
             | ((p_app_value->supported_features.is_timestamp_for_spot_check_measurements_is_supported & 0x01) << 3)
             | ((p_app_value->supported_features.is_spo2pr_fast_metric_is_supported & 0x01) << 4)
             | ((p_app_value->supported_features.is_spo2pr_slow_metric_is_supported & 0x01) << 5)
             | ((p_app_value->supported_features.is_pulse_amplitude_index_field_is_supported & 0x01) << 6)
             | ((p_app_value->supported_features.is_multiple_bonds_supported & 0x01) << 7));

    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &features);
    pos += 2;

    if(p_app_value->supported_features.is_measurement_status_support_is_present)
    {
        pos += pack_st_ble_plxs_measurement_status_t(&p_gatt_value->p_value[pos], &p_app_value->measurement_status_support);
    }

    if(p_app_value->supported_features.is_device_and_sensor_status_support_is_present)
    {
        pos += pack_st_ble_plxs_device_and_sensor_status_t(&p_gatt_value->p_value[pos], &p_app_value->device_and_sensor_status_support);
    }

    return BLE_SUCCESS;
}

/* PLX Features characteristic definition */
static const st_ble_servs_char_info_t gs_plx_features_char = {
    .start_hdl    = BLE_PLXS_PLX_FEATURES_DECL_HDL,
    .end_hdl      = BLE_PLXS_PLX_FEATURES_VAL_HDL,
    .char_idx     = BLE_PLXS_PLX_FEATURES_IDX,
    .app_size     = sizeof(st_ble_plxs_plx_features_t),
    .db_size      = BLE_PLXS_PLX_FEATURES_LEN,
    .decode       = (ble_servs_attr_decode_t)decode_st_ble_plxs_plx_features_t,
    .encode       = (ble_servs_attr_encode_t)encode_st_ble_plxs_plx_features_t,
};

ble_status_t R_BLE_PLXS_SetPlxFeatures(const st_ble_plxs_plx_features_t *p_value)
{
    return R_BLE_SERVS_SetChar(&gs_plx_features_char, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
}

ble_status_t R_BLE_PLXS_GetPlxFeatures(st_ble_plxs_plx_features_t *p_value)
{
    return R_BLE_SERVS_GetChar(&gs_plx_features_char, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Record Access Control Point Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

static const st_ble_servs_desc_info_t gs_record_access_control_point_cli_cnfg = {
    .attr_hdl = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_CLI_CNFG_DESC_HDL,
    .app_size = sizeof(uint16_t),
    .desc_idx = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_CLI_CNFG_IDX,
    .db_size  = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_CLI_CNFG_LEN,
    .decode   = (ble_servs_attr_decode_t)decode_uint16_t,
    .encode   = (ble_servs_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_PLXS_SetRecordAccessControlPointCliCnfg(uint16_t conn_hdl, const uint16_t *p_value)
{
    return R_BLE_SERVS_SetDesc(&gs_record_access_control_point_cli_cnfg, conn_hdl, (const void *)p_value);
}

ble_status_t R_BLE_PLXS_GetRecordAccessControlPointCliCnfg(uint16_t conn_hdl, uint16_t *p_value)
{
    return R_BLE_SERVS_GetDesc(&gs_record_access_control_point_cli_cnfg, conn_hdl, (void *)p_value);
}

/*----------------------------------------------------------------------------------------------------------------------
    Record Access Control Point characteristic
----------------------------------------------------------------------------------------------------------------------*/

static ble_status_t decode_st_ble_plxs_record_access_control_point_t(st_ble_plxs_record_access_control_point_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;

    BT_UNPACK_LE_1_BYTE(&p_app_value->op_code, &p_gatt_value->p_value[pos]);
    pos++;

    BT_UNPACK_LE_1_BYTE(&p_app_value->operator, &p_gatt_value->p_value[pos]);
    pos++;

    if(p_gatt_value->value_len > pos)
    {
        BT_UNPACK_LE_1_BYTE(&p_app_value->operand.rsp_default, &p_gatt_value->p_value[pos]);
        pos++;
    }
    else
    {
        p_app_value->operand.rsp_default = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_NOT_STATED;
    }
    
    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_plxs_record_access_control_point_t(const st_ble_plxs_record_access_control_point_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->op_code);
    pos++;

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->operator);
    pos++;

    if(BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_RESPONSE_CODE == p_app_value->op_code)
    {
        BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->operand.rsp_value.req_op_code);
        pos++;
        BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->operand.rsp_value.rsp_code);
        pos++;
    }
    else if(BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_NUMBER_OF_STORED_RECORDS_RESPONSE == p_app_value->op_code)
    {
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->operand.rsp_record_num);
        pos += 2;
    }
    else
    {
        /* Do nothing */
    }

    p_gatt_value->value_len = (uint16_t)pos;
    return BLE_SUCCESS;
}

/* Record Access Control Point characteristic descriptor definition */
static const st_ble_servs_desc_info_t *gspp_record_access_control_point_descs[] = {
    &gs_record_access_control_point_cli_cnfg,
};

static void plxs_racb_writereq_cb(const void *p_attr, uint16_t conn_hdl, ble_status_t result, const void *p_app_value)
{
    UNUSED_ARG(p_attr);
    UNUSED_ARG(result);

    uint16_t clicnfg = 0;
    st_ble_plxs_record_access_control_point_t racb = *(st_ble_plxs_record_access_control_point_t *)p_app_value;

    if((racb.op_code != BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_ABORT_OPERATION) &&
       (true == gs_in_progress))
    {
        R_BLE_GATTS_SendErrRsp(BLE_ERR_GATT_PROC_ALREADY_IN_PROGRESS);
        return;
    }

    R_BLE_PLXS_GetRecordAccessControlPointCliCnfg(conn_hdl, &clicnfg);
    if(0 == (clicnfg & BLE_GATTS_CLI_CNFG_INDICATION))
    {
        R_BLE_GATTS_SendErrRsp(BLE_ERR_GATT_CCCD_IMPROPERLY_CFG);
        return;
    }

    return;
}

static void plxs_racb_writecomp_cb(const void *p_attr, uint16_t conn_hdl, ble_status_t result, const void *p_app_value)
{
    UNUSED_ARG(p_attr);

    st_ble_plxs_record_access_control_point_t racp = *(st_ble_plxs_record_access_control_point_t *)p_app_value;
    st_ble_plxs_record_access_control_point_t racp_rsp_value = {
        .op_code = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_RESPONSE_CODE,
        .operator = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERATOR_NULL,
        .operand.rsp_value.req_op_code = racp.op_code,
    };
        
    if((racp.op_code == BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_RESERVED_FOR_FUTURE_USE) || (racp.op_code > BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_RESPONSE_CODE))
    {
        racp_rsp_value.operand.rsp_value.rsp_code = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_RESPONSE_VALUE_OP_CODE_NOT_SUPPORTED;
        R_BLE_PLXS_IndicateRecordAccessControlPoint(conn_hdl, &racp_rsp_value);
        return;
    }
    if(racp.operator > BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERATOR_LAST_RECORD)
    {
        racp_rsp_value.operand.rsp_value.rsp_code = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_RESPONSE_VALUE_OPERATOR_NOT_SUPPORTED;
        R_BLE_PLXS_IndicateRecordAccessControlPoint(conn_hdl, &racp_rsp_value);
        return;
    }
    if(BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_NOT_STATED != racp.operand.rsp_default)
    {
        racp_rsp_value.operand.rsp_value.rsp_code = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_RESPONSE_VALUE_OPERAND_NOT_SUPPORTED;
        R_BLE_PLXS_IndicateRecordAccessControlPoint(conn_hdl, &racp_rsp_value);
        return;
    }

    switch(racp.op_code)
    {
        case BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_REPORT_STORED_RECORDS:
        {
            if(BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERATOR_ALL_RECORDS != racp.operator)
            {
                racp_rsp_value.operand.rsp_value.rsp_code = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_RESPONSE_VALUE_INVALID_OPERATOR;
                R_BLE_PLXS_IndicateRecordAccessControlPoint(conn_hdl, &racp_rsp_value);
                return;
            }

            e_ble_plxs_db_result_t ret = BLE_PLXS_DB_SUCCESS;
            st_ble_plxs_plx_spot_check_measurement_t psc_meas;

            ret = R_BLE_PLXS_DB_GetRecordOldest(&psc_meas);
            if(BLE_PLXS_DB_ERR_DB_EMPTY == ret)
            {
                racp_rsp_value.operand.rsp_value.rsp_code = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_RESPONSE_VALUE_NO_RECORDS_FOUND;
                R_BLE_PLXS_IndicateRecordAccessControlPoint(conn_hdl, &racp_rsp_value);
            }
            else
            {
                gs_in_progress = true;
                R_BLE_PLXS_IndicatePlxSpotCheckMeasurement(conn_hdl, &psc_meas);
            }
        }break;

        case BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_DELETE_STORED_RECORDS:
        {
            if(BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERATOR_ALL_RECORDS != racp.operator)
            {
                racp_rsp_value.operand.rsp_value.rsp_code = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_RESPONSE_VALUE_INVALID_OPERATOR;
                R_BLE_PLXS_IndicateRecordAccessControlPoint(conn_hdl, &racp_rsp_value);
                return;
            }

            R_BLE_PLXS_DB_Init();

            racp_rsp_value.operand.rsp_value.rsp_code = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_RESPONSE_VALUE_SUCCESS;
            R_BLE_PLXS_IndicateRecordAccessControlPoint(conn_hdl, &racp_rsp_value);
        }break;

        case BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_ABORT_OPERATION:
        {
            if(BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERATOR_NULL != racp.operator)
            {
                racp_rsp_value.operand.rsp_value.rsp_code = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_RESPONSE_VALUE_INVALID_OPERATOR;
                R_BLE_PLXS_IndicateRecordAccessControlPoint(conn_hdl, &racp_rsp_value);
                return;
            }

            gs_abort = true;
        }break;

        case BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_REPORT_NUMBER_OF_STORED_RECORDS:
        {
            if(BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERATOR_ALL_RECORDS != racp.operator)
            {
                racp_rsp_value.operand.rsp_value.rsp_code = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_RESPONSE_VALUE_INVALID_OPERATOR;
                R_BLE_PLXS_IndicateRecordAccessControlPoint(conn_hdl, &racp_rsp_value);
                return;
            }

            uint16_t record_num;
            R_BLE_PLXS_DB_GetRecordNum(&record_num);

            racp_rsp_value.op_code = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_NUMBER_OF_STORED_RECORDS_RESPONSE;
            racp_rsp_value.operand.rsp_record_num = record_num;
            R_BLE_PLXS_IndicateRecordAccessControlPoint(conn_hdl, &racp_rsp_value);
        }break;

        default:
        {
            /* Do nothing */
        }break;
    }

    st_ble_servs_evt_data_t evt_data = {
        .conn_hdl = conn_hdl,
        .param_len = sizeof(st_ble_plxs_record_access_control_point_t),
        .p_param = p_app_value,
    };
    gs_servs_info.cb(BLE_PLXS_EVENT_RECORD_ACCESS_CONTROL_POINT_WRITE_COMP, result, &evt_data);
    return;
}

/* Record Access Control Point characteristic definition */
static const st_ble_servs_char_info_t gs_record_access_control_point_char = {
    .start_hdl    = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_DECL_HDL,
    .end_hdl      = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_CLI_CNFG_DESC_HDL,
    .char_idx     = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_IDX,
    .app_size     = sizeof(st_ble_plxs_record_access_control_point_t),
    .db_size      = BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_LEN,
    .decode       = (ble_servs_attr_decode_t)decode_st_ble_plxs_record_access_control_point_t,
    .encode       = (ble_servs_attr_encode_t)encode_st_ble_plxs_record_access_control_point_t,
    .pp_descs     = gspp_record_access_control_point_descs,
    .num_of_descs = ARRAY_SIZE(gspp_record_access_control_point_descs),
    .write_req_cb = (ble_servs_attr_write_req_t)plxs_racb_writereq_cb,
    .write_comp_cb = (ble_servs_attr_write_comp_t)plxs_racb_writecomp_cb
};

ble_status_t R_BLE_PLXS_IndicateRecordAccessControlPoint(uint16_t conn_hdl, const st_ble_plxs_record_access_control_point_t *p_value)
{
        return R_BLE_SERVS_SendHdlVal(&gs_record_access_control_point_char, conn_hdl, (const void *)p_value, false);
}

/*----------------------------------------------------------------------------------------------------------------------
    Pulse Oximeter Service server
----------------------------------------------------------------------------------------------------------------------*/

/* Pulse Oximeter Service characteristics definition */
static const st_ble_servs_char_info_t *gspp_chars[] = {
    &gs_plx_spot_check_measurement_char,
    &gs_plx_continuous_measurement_char,
    &gs_plx_features_char,
    &gs_record_access_control_point_char,
};

/* Pulse Oximeter Service service definition */
static st_ble_servs_info_t gs_servs_info = {
    .pp_chars     = gspp_chars,
    .num_of_chars = ARRAY_SIZE(gspp_chars),
};

ble_status_t R_BLE_PLXS_Init(ble_servs_app_cb_t cb)
{
    R_BLE_PLXS_DB_Init();
    gs_in_progress = false;

    if (NULL == cb)
    {
        return BLE_ERR_INVALID_PTR;
    }

    gs_servs_info.cb = cb;

    return R_BLE_SERVS_RegisterServer(&gs_servs_info);
}
