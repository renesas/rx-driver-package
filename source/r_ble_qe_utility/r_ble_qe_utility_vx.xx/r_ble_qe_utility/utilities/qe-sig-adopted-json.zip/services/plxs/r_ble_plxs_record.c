/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_plxs.c
 * Version : 1.0
 * Description : The source file for Pulse Oximeter Service service.
 **********************************************************************************************************************/
#include "r_ble_plxs_record.h"

static st_ble_plxs_db_record_t gs_record[BLE_PLXS_DB_MAX_NUM_OF_RECORDS];
static uint16_t gs_oldest_index = BLE_PLXS_DB_INVALID_INDEX;
static uint16_t gs_newest_index = BLE_PLXS_DB_INVALID_INDEX;
static uint16_t gs_record_num = 0;

void R_BLE_PLXS_DB_Init(void)
{
    gs_oldest_index = BLE_PLXS_DB_INVALID_INDEX;
    gs_newest_index = BLE_PLXS_DB_INVALID_INDEX;
    gs_record_num = 0;

    for(uint16_t i = 0; i < BLE_PLXS_DB_MAX_NUM_OF_RECORDS; i++)
    {
        gs_record[i].status = false;
        gs_record[i].next_index = BLE_PLXS_DB_INVALID_INDEX;
        gs_record[i].prev_index = BLE_PLXS_DB_INVALID_INDEX;
    }
}

e_ble_plxs_db_result_t R_BLE_PLXS_DB_SetRecord(uint16_t *index, st_ble_plxs_plx_spot_check_measurement_t *psc_meas)
{
    if((NULL == index) || (NULL == psc_meas))
    {
        return BLE_PLXS_DB_ERR_INVALID_PTR;
    }

    if(0 == gs_record_num)
    {
        gs_oldest_index = 0;
        gs_newest_index = 0;
    }
    else
    {
        uint16_t temp_index = BLE_PLXS_DB_INVALID_INDEX;
        for(uint16_t i = 0; i < BLE_PLXS_DB_MAX_NUM_OF_RECORDS; i++)
        {
            if(false == gs_record[i].status)
            {
                temp_index = i;
                break;
            }
        }
        if(BLE_PLXS_DB_INVALID_INDEX == temp_index)
        {
            return BLE_PLXS_DB_ERR_DB_FULL;
        }
        gs_record[gs_newest_index].next_index = temp_index;
        gs_record[temp_index].prev_index = gs_newest_index;
        gs_newest_index = temp_index;
    }

    gs_record[gs_newest_index].status = true;
    gs_record[gs_newest_index].next_index = BLE_PLXS_DB_INVALID_INDEX;
    gs_record[gs_newest_index].psc_meas = *psc_meas;
    gs_record_num++;

    *index = gs_oldest_index;
    return BLE_PLXS_DB_SUCCESS;
}

e_ble_plxs_db_result_t R_BLE_PLXS_DB_GetRecordIndex(uint16_t index, st_ble_plxs_plx_spot_check_measurement_t *psc_meas)
{
    if(NULL == psc_meas)
    {
        return BLE_PLXS_DB_ERR_INVALID_PTR;
    }
    if(0 == gs_record_num)
    {
        return BLE_PLXS_DB_ERR_DB_EMPTY;
    }
    if((index >= BLE_PLXS_DB_MAX_NUM_OF_RECORDS) || (gs_record[index].status == false))
    {
        return BLE_PLXS_DB_ERR_INVALID_INDEX;
    }

    *psc_meas = gs_record[index].psc_meas;
    return BLE_PLXS_DB_SUCCESS;
}

e_ble_plxs_db_result_t R_BLE_PLXS_DB_GetRecordOldest(st_ble_plxs_plx_spot_check_measurement_t *psc_meas)
{
    if(NULL == psc_meas)
    {
        return BLE_PLXS_DB_ERR_INVALID_PTR;
    }
    if(0 == gs_record_num)
    {
        return BLE_PLXS_DB_ERR_DB_EMPTY;
    }
    
    *psc_meas = gs_record[gs_oldest_index].psc_meas;
    return BLE_PLXS_DB_SUCCESS;
}

e_ble_plxs_db_result_t R_BLE_PLXS_DB_GetRecordNum(uint16_t *record_num)
{
    if(NULL == record_num)
    {
        return BLE_PLXS_DB_ERR_INVALID_PTR;
    }

    *record_num = gs_record_num;
    return BLE_PLXS_DB_SUCCESS;
}

e_ble_plxs_db_result_t R_BLE_PLXS_DB_DeleteRecordIndex(uint16_t index)
{
    if(0 == gs_record_num)
    {
        return BLE_PLXS_DB_ERR_DB_EMPTY;
    }
    if((index >= BLE_PLXS_DB_MAX_NUM_OF_RECORDS) || (gs_record[index].status == false))
    {
        return BLE_PLXS_DB_ERR_INVALID_INDEX;
    }

    if(gs_oldest_index == index)
    {
        gs_oldest_index = gs_record[index].next_index;
    }
    else
    {
        gs_record[gs_record[index].prev_index].next_index = gs_record[index].next_index;
    }
    if(gs_newest_index == index)
    {
        gs_newest_index = gs_record[index].prev_index;
    }
    else
    {
        gs_record[gs_record[index].next_index].prev_index = gs_record[index].prev_index;
    }

    gs_record[index].status = false;
    gs_record[index].next_index = BLE_PLXS_DB_INVALID_INDEX;
    gs_record[index].prev_index = BLE_PLXS_DB_INVALID_INDEX;
    gs_record_num--;

    return BLE_PLXS_DB_SUCCESS;
}

e_ble_plxs_db_result_t R_BLE_PLXS_DB_DeleteRecordOldest(void)
{
    return R_BLE_PLXS_DB_DeleteRecordIndex(gs_oldest_index);
}



