/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_plxs.h
 * Version : 1.0
 * Description : The header file for Pulse Oximeter Service service.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 31.12.2999 1.00 First Release
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @file
 * @defgroup plxs Pulse Oximeter Service Server
 * @{
 * @ingroup profile
 * @brief   This Service specification proposes a pulse oximetry server for use in consumer and professional healthcare applications.
 **********************************************************************************************************************/
#include "profile_cmn/r_ble_servs_if.h"
#include "gatt_db.h"

#ifndef R_BLE_PLXS_H
#define R_BLE_PLXS_H

/***************************************************************************//**
 * @brief PLXS Measurement Status value Field structure.
*******************************************************************************/
typedef struct {
    bool is_measurement_ongoing; /**< Measurement Ongoing */
    bool is_early_estimated_data; /**< Early Estimated Data */
    bool is_validated_data; /**< Validated Data */
    bool is_fully_qualified_data; /**< Fully Qualified Data */
    bool is_data_from_measurement_storage; /**< Data from Measurement Storage */
    bool is_data_for_demonstration; /**< Data for Demonstration */
    bool is_data_for_testing; /**< Data for Testing */
    bool is_calibration_ongoing; /**< Calibration Ongoing */
    bool is_measurement_unavailable; /**< Measurement Unavailable */
    bool is_questionable_measurement_detected; /**< Questionable Measurement Detected */
    bool is_invalid_measurement_detected; /**< Invalid Measurement Detected */
} st_ble_plxs_measurement_status_t;

      
/***************************************************************************//**
 * @brief PLXS Device and Sensor Status value Field structure.
*******************************************************************************/
typedef struct {
    bool is_extended_display_update_ongoing; /**< Extended Display Update Ongoing */
    bool is_equipment_malfunction_detected; /**< Equipment Malfunction Detected */
    bool is_signal_processing_irregularity_detected; /**< Signal Processing Irregularity Detected */
    bool is_inadequite_signal_detected; /**< Inadequite Signal Detected */
    bool is_poor_signal_detected; /**< Poor Signal Detected */
    bool is_low_perfusion_detected; /**< Low Perfusion Detected */
    bool is_erratic_signal_detected; /**< Erratic Signal Detected */
    bool is_nonpulsatile_signal_detected; /**< Nonpulsatile Signal Detected */
    bool is_questionable_pulse_detected; /**< Questionable Pulse Detected */
    bool is_signal_analysis_ongoing; /**< Signal Analysis Ongoing */
    bool is_sensor_interface_detected; /**< Sensor Interface Detected */
    bool is_sensor_unconnected_to_user; /**< Sensor Unconnected to User */
    bool is_unknown_sensor_connected; /**< Unknown Sensor Connected */
    bool is_sensor_displaced; /**< Sensor Displaced */
    bool is_sensor_malfunctioning; /**< Sensor Malfunctioning */
    bool is_sensor_disconnected; /**< Sensor Disconnected */
} st_ble_plxs_device_and_sensor_status_t;

/*----------------------------------------------------------------------------------------------------------------------
    PLX Spot-Check Measurement Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/***************************************************************************//**
 * @brief PLX Spot-Check Measurement Flags value structure.
*******************************************************************************/
typedef struct {
    bool is_timestamp_field_is_present; /**< Timestamp field is present */
    bool is_measurement_status_field_present; /**< Measurement Status Field Present */
    bool is_device_and_sensor_status_field_present; /**< Device and Sensor Status Field Present */
    bool is_pulse_amplitude_index_field_is_present; /**< Pulse Amplitude Index field is present */
    bool is_device_clock_is_not_set; /**< Device Clock is Not Set */
} st_ble_plxs_plx_spot_check_measurement_flags_t;

/***************************************************************************//**
 * @brief PLX Spot-Check Measurement value structure.
*******************************************************************************/
typedef struct {
    st_ble_plxs_plx_spot_check_measurement_flags_t flags; /**< Flags */
    st_ble_ieee11073_sfloat_t spo2pr_spot_check_spo2; /**< SpO2PR-Spot-Check-SpO2 */
    st_ble_ieee11073_sfloat_t spo2pr_spot_check_pr; /**< SpO2PR-Spot-Check-PR */
    st_ble_date_time_t timestamp; /**< Timestamp */
    st_ble_plxs_measurement_status_t measurement_status; /**< Measurement Status */
    st_ble_plxs_device_and_sensor_status_t device_and_sensor_status; /**< Device and Sensor Status */
    st_ble_ieee11073_sfloat_t pulse_amplitude_index; /**< Pulse Amplitude Index */
} st_ble_plxs_plx_spot_check_measurement_t;

/***************************************************************************//**
 * @brief     Send indication of  PLX Spot-Check Measurement characteristic value to the remote device.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value  Characteristic value to send.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_PLXS_IndicatePlxSpotCheckMeasurement(uint16_t conn_hdl, const st_ble_plxs_plx_spot_check_measurement_t *p_value);

/***************************************************************************//**
 * @brief     Set PLX Spot-Check Measurement cli cnfg descriptor value to the local GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_PLXS_SetPlxSpotCheckMeasurementCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Get PLX Spot-Check Measurement cli cnfg descriptor value from the local GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_PLXS_GetPlxSpotCheckMeasurementCliCnfg(uint16_t conn_hdl, uint16_t *p_value);

/*----------------------------------------------------------------------------------------------------------------------
    PLX Continuous Measurement Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/***************************************************************************//**
 * @brief PLX Continuous Measurement Flags value structure.
*******************************************************************************/
typedef struct {
    bool is_spo2pr_fast_field_is_present; /**< SpO2PR-Fast field is present */
    bool is_spo2pr_slow_field_is_present; /**< SpO2PR-Slow field is present */
    bool is_measurement_status_field_is_present; /**< Measurement Status field is present */
    bool is_device_and_sensor_status_field_is_present; /**< Device and Sensor Status field is present */
    bool is_pulse_amplitude_index_field_is_present; /**< Pulse Amplitude Index field is present */
} st_ble_plxs_plx_continuous_measurement_flags_t;

/***************************************************************************//**
 * @brief PLX Continuous Measurement value structure.
*******************************************************************************/
typedef struct {
    st_ble_plxs_plx_continuous_measurement_flags_t flags; /**< Flags */
    st_ble_ieee11073_sfloat_t spo2pr_normal_spo2; /**< SpO2PR-Normal-SpO2 */
    st_ble_ieee11073_sfloat_t spo2pr_normal_pr; /**< SpO2PR-Normal-PR */
    st_ble_ieee11073_sfloat_t spo2pr_fast_spo2; /**< SpO2PR-Fast-SpO2 */
    st_ble_ieee11073_sfloat_t spo2pr_fast_pr; /**< SpO2PR-Fast-PR */
    st_ble_ieee11073_sfloat_t spo2pr_slow_spo2; /**< SpO2PR-Slow-SpO2 */
    st_ble_ieee11073_sfloat_t spo2pr_slow_pr; /**< SpO2PR-Slow-PR */
    st_ble_plxs_measurement_status_t measurement_status; /**< Measurement Status */
    st_ble_plxs_device_and_sensor_status_t device_and_sensor_status; /**< Device and Sensor Status */
    st_ble_ieee11073_sfloat_t pulse_amplitude_index; /**< Pulse Amplitude Index */
} st_ble_plxs_plx_continuous_measurement_t;

/***************************************************************************//**
 * @brief     Send notification of  PLX Continuous Measurement characteristic value to the remote device.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value  Characteristic value to send.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_PLXS_NotifyPlxContinuousMeasurement(uint16_t conn_hdl, const st_ble_plxs_plx_continuous_measurement_t *p_value);

/***************************************************************************//**
 * @brief     Set PLX Continuous Measurement cli cnfg descriptor value to the local GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_PLXS_SetPlxContinuousMeasurementCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Get PLX Continuous Measurement cli cnfg descriptor value from the local GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_PLXS_GetPlxContinuousMeasurementCliCnfg(uint16_t conn_hdl, uint16_t *p_value);

/*----------------------------------------------------------------------------------------------------------------------
    PLX Features Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/***************************************************************************//**
 * @brief PLX Features Supported Features value structure.
*******************************************************************************/
typedef struct {
    bool is_measurement_status_support_is_present; /**< Measurement Status support is present */
    bool is_device_and_sensor_status_support_is_present; /**< Device and Sensor Status support is present */
    bool is_measurement_storage_for_spot_check_measurements_is_supported; /**< Measurement Storage for Spot-check measurements is supported */
    bool is_timestamp_for_spot_check_measurements_is_supported; /**< Timestamp for Spot-check measurements is supported */
    bool is_spo2pr_fast_metric_is_supported; /**< SpO2PR-Fast metric is supported */
    bool is_spo2pr_slow_metric_is_supported; /**< SpO2PR-Slow metric is supported */
    bool is_pulse_amplitude_index_field_is_supported; /**< Pulse Amplitude Index field is supported */
    bool is_multiple_bonds_supported; /**< Multiple Bonds Supported */
} st_ble_plxs_plx_features_supported_features_t;

/***************************************************************************//**
 * @brief PLX Features value structure.
*******************************************************************************/
typedef struct {
    st_ble_plxs_plx_features_supported_features_t supported_features; /**< Supported Features */
    st_ble_plxs_measurement_status_t measurement_status_support; /**< Measurement Status Support */
    st_ble_plxs_device_and_sensor_status_t device_and_sensor_status_support; /**< Device and Sensor Status Support */
} st_ble_plxs_plx_features_t;

/***************************************************************************//**
 * @brief     Set PLX Features characteristic value to the local GATT database.
 * @param[in] p_value  Characteristic value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_PLXS_SetPlxFeatures(const st_ble_plxs_plx_features_t *p_value);

/***************************************************************************//**
 * @brief     Get PLX Features characteristic value from the local GATT database.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_PLXS_GetPlxFeatures(st_ble_plxs_plx_features_t *p_value);

/*----------------------------------------------------------------------------------------------------------------------
    Record Access Control Point Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/***************************************************************************//**
 * @brief Record Access Control Point Op Code enumeration.
*******************************************************************************/
typedef enum {
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_RESERVED_FOR_FUTURE_USE = 0, /**< Reserved for future use (Operator:N/A) */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_REPORT_STORED_RECORDS = 1, /**< Report stored records (Operator: Value from Operator Table) */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_DELETE_STORED_RECORDS = 2, /**< Delete stored records (Operator: Value from Operator Table) */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_ABORT_OPERATION = 3, /**< Abort operation (Operator: Null 'value of 0x00 from Operator Table') */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_REPORT_NUMBER_OF_STORED_RECORDS = 4, /**< Report number of stored records (Operator: Value from Operator Table) */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_NUMBER_OF_STORED_RECORDS_RESPONSE = 5, /**< Number of stored records response (Operator: Null 'value of 0x00 from Operator Table') */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_RESPONSE_CODE = 6, /**< Response Code (Operator: Null 'value of 0x00 from Operator Table') */
} e_ble_plxs_record_access_control_point_op_code_t;

/***************************************************************************//**
 * @brief Record Access Control Point Operator enumeration.
*******************************************************************************/
typedef enum {
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERATOR_NULL = 0, /**< Null */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERATOR_ALL_RECORDS = 1, /**< All records */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERATOR_LESS_THAN_OR_EQUAL_TO = 2, /**< Less than or equal to */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERATOR_GREATER_THAN_OR_EQUAL_TO = 3, /**< Greater than or equal to */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERATOR_WITHIN_RANGE_OF = 4, /**< Within range of (inclusive) */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERATOR_FIRST_RECORD = 5, /**< First record(i.e. oldest record) */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERATOR_LAST_RECORD = 6, /**< Last record (i.e. most recent record) */
} e_ble_plxs_record_access_control_point_operator_t;

/***************************************************************************//**
 * @brief Record Access Control Point Operand enumeration.
*******************************************************************************/
typedef enum {
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_N_A = 0, /**< N/A */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_FILTER_PARAMETERS_1 = 1, /**< Filter parameters (as appropriate to Operator and Service) */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_FILTER_PARAMETERS_2 = 2, /**< Filter parameters (as appropriate to Operator and Service) */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_NOT_INCLUDED = 3, /**< Not included */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_FILTER_PARAMETERS_4 = 4, /**< Filter parameters (as appropriate to Operator and Service) */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_NUMBER_OF_RECORDS = 5, /**< Number of Records (Field size defined per service) */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_REQUEST_OP_CODE_RESPONSE_CODE_VALUE = 6, /**< Request Op Code,Response Code Value */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_NOT_STATED = 0xFF, /**< Operand not stated in Record Access Control Point */
} e_ble_Plxs_record_access_control_point_operand_t;

/***************************************************************************//**
 * @brief Record Access Control Point Response Value enumeration.
*******************************************************************************/
typedef enum {
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_RESPONSE_VALUE_RESERVED_FOR_FUTURE_USE = 0, /**< N/A */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_RESPONSE_VALUE_SUCCESS = 1, /**< Normal response for successful operation */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_RESPONSE_VALUE_OP_CODE_NOT_SUPPORTED = 2, /**< Normal response if unsupported Op Code is received */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_RESPONSE_VALUE_INVALID_OPERATOR = 3, /**< Normal response if Operator received does not meet the requirements of the service (e.g. Null was expected) */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_RESPONSE_VALUE_OPERATOR_NOT_SUPPORTED = 4, /**< Normal response if unsupported Operator is received */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_RESPONSE_VALUE_INVALID_OPERAND = 5, /**< Normal response if Operand received does not meet the requirements of the service */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_RESPONSE_VALUE_NO_RECORDS_FOUND = 6, /**< Normal response if request to report stored records or request to delete stored records resulted in no records meeting criteria */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_RESPONSE_VALUE_ABORT_UNSUCCESSFUL = 7, /**< Normal response if request for Abort cannot be completed */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_RESPONSE_VALUE_PROCEDURE_NOT_COMPLETED = 8, /**< response if unable to complete a procedure for any reason */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_RESPONSE_VALUE_OPERAND_NOT_SUPPORTED = 9, /**< Normal response if unsupported Operand is received */
} e_ble_record_access_control_point_response_value_t;

/***************************************************************************//**
 * @brief Record Access Control Point characteristic Operand field.
*******************************************************************************/
typedef union {
    uint8_t rsp_default;
    uint16_t rsp_record_num;
    struct {
        uint8_t req_op_code;
        uint8_t rsp_code;
    }rsp_value;
} u_ble_plxs_racp_operand_t;

/***************************************************************************//**
 * @brief Record Access Control Point value structure.
*******************************************************************************/
typedef struct {
    uint8_t op_code; /**< Op Code */
    uint8_t operator; /**< Operator */
    u_ble_plxs_racp_operand_t operand; /**< Operand */
} st_ble_plxs_record_access_control_point_t;

/***************************************************************************//**
 * @brief     Send indication of  Record Access Control Point characteristic value to the remote device.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value  Characteristic value to send.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_PLXS_IndicateRecordAccessControlPoint(uint16_t conn_hdl, const st_ble_plxs_record_access_control_point_t *p_value);

/***************************************************************************//**
 * @brief     Set Record Access Control Point cli cnfg descriptor value to the local GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_PLXS_SetRecordAccessControlPointCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Get Record Access Control Point cli cnfg descriptor value from the local GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_PLXS_GetRecordAccessControlPointCliCnfg(uint16_t conn_hdl, uint16_t *p_value);

/*----------------------------------------------------------------------------------------------------------------------
    Pulse Oximeter Service Service
----------------------------------------------------------------------------------------------------------------------*/

/***************************************************************************//**
 * @brief Pulse Oximeter Service characteristic Index.
*******************************************************************************/
typedef enum {
    BLE_PLXS_PLX_SPOT_CHECK_MEASUREMENT_IDX,
    BLE_PLXS_PLX_SPOT_CHECK_MEASUREMENT_CLI_CNFG_IDX,
    BLE_PLXS_PLX_CONTINUOUS_MEASUREMENT_IDX,
    BLE_PLXS_PLX_CONTINUOUS_MEASUREMENT_CLI_CNFG_IDX,
    BLE_PLXS_PLX_FEATURES_IDX,
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_IDX,
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_CLI_CNFG_IDX,
} e_ble_plxs_char_idx_t;

/***************************************************************************//**
 * @brief Pulse Oximeter Service event type.
*******************************************************************************/
typedef enum {
    /* PLX Spot-Check Measurement */
    BLE_PLXS_EVENT_PLX_SPOT_CHECK_MEASUREMENT_HDL_VAL_CNF = BLE_SERVS_ATTR_EVENT(BLE_PLXS_PLX_SPOT_CHECK_MEASUREMENT_IDX, BLE_SERVS_HDL_VAL_CNF),
    BLE_PLXS_EVENT_PLX_SPOT_CHECK_MEASUREMENT_CLI_CNFG_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_PLXS_PLX_SPOT_CHECK_MEASUREMENT_CLI_CNFG_IDX, BLE_SERVS_WRITE_REQ),
    BLE_PLXS_EVENT_PLX_SPOT_CHECK_MEASUREMENT_CLI_CNFG_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_PLXS_PLX_SPOT_CHECK_MEASUREMENT_CLI_CNFG_IDX, BLE_SERVS_WRITE_COMP),
    BLE_PLXS_EVENT_PLX_SPOT_CHECK_MEASUREMENT_CLI_CNFG_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_PLXS_PLX_SPOT_CHECK_MEASUREMENT_CLI_CNFG_IDX, BLE_SERVS_READ_REQ),
    /* PLX Continuous Measurement */
    BLE_PLXS_EVENT_PLX_CONTINUOUS_MEASUREMENT_CLI_CNFG_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_PLXS_PLX_CONTINUOUS_MEASUREMENT_CLI_CNFG_IDX, BLE_SERVS_WRITE_REQ),
    BLE_PLXS_EVENT_PLX_CONTINUOUS_MEASUREMENT_CLI_CNFG_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_PLXS_PLX_CONTINUOUS_MEASUREMENT_CLI_CNFG_IDX, BLE_SERVS_WRITE_COMP),
    BLE_PLXS_EVENT_PLX_CONTINUOUS_MEASUREMENT_CLI_CNFG_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_PLXS_PLX_CONTINUOUS_MEASUREMENT_CLI_CNFG_IDX, BLE_SERVS_READ_REQ),
    /* PLX Features */
    BLE_PLXS_EVENT_PLX_FEATURES_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_PLXS_PLX_FEATURES_IDX, BLE_SERVS_READ_REQ),
    /* Record Access Control Point */
    BLE_PLXS_EVENT_RECORD_ACCESS_CONTROL_POINT_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_IDX, BLE_SERVS_WRITE_REQ),
    BLE_PLXS_EVENT_RECORD_ACCESS_CONTROL_POINT_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_IDX, BLE_SERVS_WRITE_COMP),
    BLE_PLXS_EVENT_RECORD_ACCESS_CONTROL_POINT_HDL_VAL_CNF = BLE_SERVS_ATTR_EVENT(BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_IDX, BLE_SERVS_HDL_VAL_CNF),
    BLE_PLXS_EVENT_RECORD_ACCESS_CONTROL_POINT_CLI_CNFG_WRITE_REQ = BLE_SERVS_ATTR_EVENT(BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_CLI_CNFG_IDX, BLE_SERVS_WRITE_REQ),
    BLE_PLXS_EVENT_RECORD_ACCESS_CONTROL_POINT_CLI_CNFG_WRITE_COMP = BLE_SERVS_ATTR_EVENT(BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_CLI_CNFG_IDX, BLE_SERVS_WRITE_COMP),
    BLE_PLXS_EVENT_RECORD_ACCESS_CONTROL_POINT_CLI_CNFG_READ_REQ = BLE_SERVS_ATTR_EVENT(BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_CLI_CNFG_IDX, BLE_SERVS_READ_REQ),
} e_ble_plxs_event_t;

/***************************************************************************//**
 * @brief     Initialize Pulse Oximeter Service service.
 * @param[in] cb Service callback.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_PLXS_Init(ble_servs_app_cb_t cb);

#include "r_ble_plxs_record.h"
#endif /* R_BLE_PLXS_H */


/** @} */
