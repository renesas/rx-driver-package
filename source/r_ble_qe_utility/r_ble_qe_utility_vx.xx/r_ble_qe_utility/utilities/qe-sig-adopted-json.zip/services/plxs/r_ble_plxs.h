/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************//**
* File Name: r_ble_plxs.h
* Version : 1.0
* Description : This module implements Pulse Oximeter Service Server.
**********************************************************************************************************************/
/***********************************************************************************************************************//**
* History : DD.MM.YYYY Version Description
*         : 22.03.2019 1.00 First Release
***********************************************************************************************************************/

/*******************************************************************************************************************//**
* @file
* @defgroup plxs Pulse Oximeter Service Server
* @{
* @ingroup profile
* @brief   This file provides APIs to interface Pulse Oximeter Service.
**********************************************************************************************************************/

/***********************************************************************************************************************//**
* Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_ble_rx23w_if.h"
#include "profile_cmn/r_ble_profile_cmn.h"

/***********************************************************************************************************************//**
* Macro definitions
***********************************************************************************************************************/
#ifndef R_BLE_PLXS_H_
#define R_BLE_PLXS_H_

/*******************************************************************************************************************//**
* @brief Procedure Already in Progress error code.
***********************************************************************************************************************/
#define BLE_PLXS_PROCEDURE_ALREADY_IN_PROGRESS                                               (BLE_ERR_GROUP_GATT | 0xFE)

/*******************************************************************************************************************//**
* @brief Client Characteristic Configuration descriptor improperly configured error code.
***********************************************************************************************************************/
#define BLE_PLXS_CLIENT_CHARACTERISTIC_CONFIGURATION_DESCRIPTOR_IMPROPERLY_CONFIGURED        (BLE_ERR_GROUP_GATT | 0xFD)

/***********************************************************************************************************************//**
* Typedef definitions
***********************************************************************************************************************/

/*******************************************************************************************************************//**
* @brief Pulse Oximeter Service event data.
***********************************************************************************************************************/
typedef struct
{
    uint16_t  conn_hdl;     /**< Connection handle */
    uint16_t  param_len;    /**< Event parameter length */
    void      *p_param;     /**< Event parameter */
} st_ble_plxs_evt_data_t;

/*******************************************************************************************************************//**
* @brief Pulse Oximeter Service event callback.
***********************************************************************************************************************/
typedef void (*ble_plxs_app_cb_t)(uint16_t type, ble_status_t result, st_ble_plxs_evt_data_t *data);

/*******************************************************************************************************************//**
* @brief Pulse Oximeter Service event type.
***********************************************************************************************************************/
typedef enum 
{
    BLE_PLXS_EVENT_PLX_SPOT_CHECK_MEASUREMENT_CLI_CNFG_ENABLED,      
    /**< PLX Spot-Check Measurement characteristic cli cnfg enabled event */
    BLE_PLXS_EVENT_PLX_SPOT_CHECK_MEASUREMENT_CLI_CNFG_DISABLED,     
    /**< PLX Spot-Check Measurement characteristic cli cnfg disabled event */
    BLE_PLXS_EVENT_PLX_SPOT_CHECK_MEASUREMENT_HDL_VAL_CNF,           
    /**< PLX Spot-Check Measurement characteristic handle value configuration event */
    BLE_PLXS_EVENT_RECORD_ACCESS_CONTROL_POINT_CLI_CNFG_ENABLED,     
    /**< Record Access Control Point characteristic cli cnfg enabled event */
    BLE_PLXS_EVENT_RECORD_ACCESS_CONTROL_POINT_CLI_CNFG_DISABLED,    
    /**< Record Access Control Point characteristic cli cnfg disabled event */
    BLE_PLXS_EVENT_RECORD_ACCESS_CONTROL_POINT_HDL_VAL_CNF,          
    /**< Record Access Control Point characteristic handle value configuration event */
    BLE_PLXS_EVENT_PLX_CONTINUOUS_MEASUREMENT_CLI_CNFG_ENABLED,      
    /**< PLX Continuous Measurement characteristic cli cnfg enabled event */
    BLE_PLXS_EVENT_PLX_CONTINUOUS_MEASUREMENT_CLI_CNFG_DISABLED,     
    /**< PLX Continuous Measurement characteristic cli cnfg disabled event */
    BLE_PLXS_EVENT_RECORD_ACCESS_CONTROL_POINT_WRITE_REQ,            
    /**< Record Access Control Point characteristic write request event */
    BLE_PLXS_EVENT_PLX_FEATURES_READ_REQ,                            
    /**< PLX Features characteristic read request event */
} e_ble_plxs_event_t;

/*******************************************************************************************************************//**
* @brief Op Code enumeration.
***********************************************************************************************************************/
typedef enum 
{
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_RESERVED_FOR_FUTURE_USE__OPERATOR_N_A_                                                 = 0,
    /**< Record Access Control Point Records OP CODE Reserved for Future Use */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_REPORT_STORED_RECORDS__OPERATOR__VALUE_FROM_OPERATOR_TABLE_                            = 1,
    /**< Record Access Control Point OP CODE Report Stored Records Operator Value */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_DELETE_STORED_RECORDS__OPERATOR__VALUE_FROM_OPERATOR_TABLE_                            = 2,
    /**< Record Access Control Point OP CODE Delete Stored Records Operated Value */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_ABORT_OPERATION__OPERATOR__NULL__VALUE_OF_0X00_FROM_OPERATOR_TABLE__                   = 3,
    /**< Record Access Control Point OP CODE Abort Operation Operator Null Value  */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_REPORT_NUMBER_OF_STORED_RECORDS__OPERATOR__VALUE_FROM_OPERATOR_TABLE_                  = 4,
    /**< Record Access Control Point OP CODE Reports Number of Stored Records Operator Value*/
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_NUMBER_OF_STORED_RECORDS_RESPONSE__OPERATOR__NULL__VALUE_OF_0X00_FROM_OPERATOR_TABLE__ = 5,
    /**< Record Access Control Point OP CODE Reports Number of Stored Records Response Operator Null Value */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OP_CODE_RESPONSE_CODE__OPERATOR__NULL__VALUE_OF_0X00_FROM_OPERATOR_TABLE__                     = 6, 
    /**< Record Access Control Point OP CODE Response Code for Operator Null Value */
} e_ble_plxs_record_access_control_point_op_code_t;

/*******************************************************************************************************************//**
* @brief Operator enumeration.
***********************************************************************************************************************/
typedef enum 
{
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERATOR_NULL                                   = 0, 
    /**< Record Access Control Point Operator of Null Records */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERATOR_ALL_RECORDS                            = 1, 
    /**< Record Access Control Point Operator of All Records */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERATOR_LESS_THAN_OR_EQUAL_TO                  = 2,
    /**< Record Access Control Point Operator of Records Lees then or Equal to Stored Records*/
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERATOR_GREATER_THAN_OR_EQUAL_TO               = 3, 
    /**< Record Access Control Point operator of Records Greater than or Equal to Stored Records */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERATOR_WITHIN_RANGE_OF__INCLUSIVE_            = 4,
    /**< Record Access Control Point Operator of within Range of Inclusive records */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERATOR_FIRST_RECORD_I_E__OLDEST_RECORD_       = 5,
    /**< Record Access Control Point Operator of First Record of IE Oldest  */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERATOR_LAST_RECORD__I_E__MOST_RECENT_RECORD_  = 6,
    /**< Record Access Control Point Operator of Last Record of IE Most Recent  */
} e_ble_plxs_record_access_control_point_operator_t;

/*******************************************************************************************************************//**
 * @brief Operand_Values enumeration.
***********************************************************************************************************************/
typedef enum
{
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_VALUES_N_A                                                         = 0, 
    /**< Not applicable */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_VALUES_FILTER_PARAMETERS__AS_APPROPRIATE_TO_OPERATOR_AND_SERVICE_1 = 1,
    /**< Filter parameters (as appropriate to Operator and Service) */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_VALUES_FILTER_PARAMETERS__AS_APPROPRIATE_TO_OPERATOR_AND_SERVICE_2 = 2,
    /**< Filter parameters (as appropriate to Operator and Service) */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_VALUES_NOT_INCLUDED                                                = 3, 
    /**< Not included */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_VALUES_FILTER_PARAMETERS__AS_APPROPRIATE_TO_OPERATOR_AND_SERVICE_3 = 4,
    /**< Filter parameters (as appropriate to Operator and Service) */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_VALUES_NUMBER_OF_RECORDS__FIELD_SIZE_DEFINED_PER_SERVICE_          = 5,
    /**< Number of Records (Field size defined per service) */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_VALUES_REQUEST_OP_CODE__RESPONSE_CODE_VALUE                        = 6,
    /**< Request Op Code, Response Code Value */
} e_ble_plxs_record_access_control_point_operand_t;

/*******************************************************************************************************************//**
 * @brief Operand_Reponse_Code_Values enumeration.
***********************************************************************************************************************/
typedef enum 
{
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_REPONSE_CODE_VALUES_RESERVED_FOR_FUTURE_USE   = 0,
    /**< Not applicable */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_REPONSE_CODE_VALUES_SUCCESS                   = 1,
    /**< Normal response for successful operation */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_REPONSE_CODE_VALUES_OP_CODE_NOT_SUPPORTED     = 2,
    /**< Normal response if unsupported Op Code is received */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_REPONSE_CODE_VALUES_INVALID_OPERATOR          = 3, 
    /**< Normal response if Operator received does not meet the requirements of the service (e.g. Null was expected) */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_REPONSE_CODE_VALUES_OPERATOR_NOT_SUPPORTED    = 4,
    /**< Normal response if unsupported Operator is received */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_REPONSE_CODE_VALUES_INVALID_OPERAND           = 5,
    /**< Normal response if Operand received does not meet the requirements of the service */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_REPONSE_CODE_VALUES_NO_RECORDS_FOUND          = 6,
    /**< Normal response if request to report stored records or request to delete stored records resulted in no records meeting criteria. */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_REPONSE_CODE_VALUES_ABORT_UNSUCCESSFUL        = 7,
    /**< Normal response if request for Abort cannot be completed */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_REPONSE_CODE_VALUES_PROCEDURE_NOT_COMPLETED   = 8,
    /**< Normal response if unable to complete a procedure for any reason */
    BLE_PLXS_RECORD_ACCESS_CONTROL_POINT_OPERAND_REPONSE_CODE_VALUES_OPERAND_NOT_SUPPORTED     = 9,
    /**< Normal response if unsupported Operand is received */
} e_ble_plxs_record_access_control_point_operand_response_code_vale_t;

/*******************************************************************************************************************//**
* @brief Pulse Oximeter Service initialization parameters.
***********************************************************************************************************************/
typedef struct 
{
    ble_plxs_app_cb_t cb; /**< Pulse Oximeter Service event callback */
} st_ble_plxs_init_param_t;

/*******************************************************************************************************************//**
* @brief Pulse Oximeter Service connection parameters.
***********************************************************************************************************************/
typedef struct 
{
    uint16_t plx_spot_check_measurement_cli_cnfg;    /**< PLX Spot-Check Measurement characteristic cli cnfg */
    uint16_t plx_continuous_measurement_cli_cnfg;    /**< PLX Continuous Measurement characteristic cli cnfg */
    uint16_t record_access_control_point_cli_cnfg;   /**< Record Access Control Point characteristic cli cnfg */
} st_ble_plxs_connect_param_t;

/*******************************************************************************************************************//**
* @brief Pulse Oximeter Service disconnection parameters.
***********************************************************************************************************************/
typedef struct 
{
    uint16_t plx_spot_check_measurement_cli_cnfg;   /**< PLX Spot-Check Measurement characteristic cli cnfg */
    uint16_t plx_continuous_measurement_cli_cnfg;   /**< PLX Continuous Measurement characteristic cli cnfg */
    uint16_t record_access_control_point_cli_cnfg;  /**< Record Access Control Point characteristic cli cnfg */
} st_ble_plxs_disconnect_param_t;

/*******************************************************************************************************************//**
* @brief PLX Spot-Check Measurement characteristic parameters.
***********************************************************************************************************************/
typedef struct 
{
    bool                           is_timestamp_present;                  /**< Timestamp field is present  */
    bool                           is_measurement_status_present;         /**< Measurement Status field is present */
    bool                           is_device_and_sensor_status_present;   /**< Device and Sensor Status field is present */
    bool                           is_pulse_amplitude_index_present;      /**< Pulse Amplitude Index field is present*/
    bool                           is_device_clock_present;               /**< Device Clock is Not Set*/
    st_ble_ieee11073_sfloat_t      spo2pr_spot_check___spo2;              /**< SpO2PR-Spot-Check - SpO2 value */
    st_ble_ieee11073_sfloat_t      spo2pr_spot_check___pr;                /**< SpO2PR-Spot-Check - PR value */
    st_ble_date_time_t             timestamp;                             /**< Timestamp value */
        
    /* measurement status definitions bit fields */
    bool is_measurement_ongoing;                                     /**< Measurement Ongoing */
    bool is_early_estimated_data;                                    /**< Early Estimated Data */
    bool is_validated_data;                                          /**< Validated Data */
    bool is_fully_qualified_data;                                    /**< Fully Qualified Data */
    bool is_data_from_measurement_storage;                           /**< Data from Measurement Storage */
    bool is_data_for_demonstration;                                  /**< Data for Demonstration */
    bool is_data_for_testing;                                        /**< Data for Testing */
    bool is_calibration_ongoing;                                     /**< Calibration Ongoing */
    bool is_measurement_unavailable;                                 /**< Measurement Unavailable */
    bool is_questionable_measurement_detected;                       /**< Questionable Measurement Detected */
    bool is_invalid_measurement_detected;                            /**< Invalid Measurement Detected */
    
    /* device and sensor status support bit fields */
    bool is_extended_display_update_ongoing;                         /**< Extended Display Update Ongoing */
    bool is_equipment_malfunction_detected;                          /**< Equipment Malfunction Detected */
    bool is_signal_processing_irregularity_detected;                 /**< Signal Processing Irregularity Detected */
    bool is_inadequate_signal_detected;                              /**< Inadequate Signal Detected */
    bool is_poor_signal_detected;                                    /**< Poor Signal Detected */
    bool is_low_perfusion_detected;                                  /**< Low Perfusion Detected */
    bool is_erratic_perfusion_detected;                              /**< Erratic Signal Detected */
    bool is_non_pulsatile_signal_detected;                           /**< Non-Pulsatile Signal Detected */
    bool is_questionable_pulse_detected;                             /**< Questionable Pulse Detected */
    bool is_signal_analysis_ongoing;                                 /**< Signal Analysis Ongoing */
    bool is_sensor_interference_detected;                            /**< Sensor Interference Detected */
    bool is_sensor_unconnected_to_user;                              /**< Sensor Unconnected to User */
    bool is_unknown_sensor_connected;                                /**< Unknown Sensor Connected */
    bool is_sensor_displaced;                                        /**< Sensor Displaced */
    bool is_sensor_malfunctioning;                                   /**< Sensor Malfunctioning */
    bool is_sensor_disconnected;                                     /**< Sensor Disconnected */
    st_ble_ieee11073_sfloat_t      pulse_amplitude_index;            /**< Pulse Amplitude Index value */
} st_ble_plxs_plx_spot_check_measurement_t;

/*******************************************************************************************************************//**
* @brief PLX Spot-Check Measurement Client Characteristic Configuration descriptor parameters.
***********************************************************************************************************************/
typedef struct 
{
    uint8_t value[20];  /**< PLX Spot-Check Measurement characteristic value */
} st_ble_plxs_plx_spot_check_measurement_client_characteristic_configuration_t;

/*******************************************************************************************************************//**
* @brief PLX Continuous Measurement characteristic parameters.
***********************************************************************************************************************/
typedef struct
{    
    bool                            is_spo2pr_fast_pr_present;             /**< SpO2PR-Slow field is present*/
    bool                            is_spo2pr_slow_pr_present;             /**< SpO2PR-Slow field is present*/
    bool                            is_measurement_status_present;         /**< Measurement Status field is present*/
    bool                            is_device_and_sensor_status_present;   /**< Device and Sensor Status field is present*/
    bool                            is_pulse_amplitude_index_present;      /**< Pulse Amplitude Index field is present*/
    st_ble_ieee11073_sfloat_t       spo2pr_normal___spo2;                  /**< SpO2PR-Normal - SpO2 value */
    st_ble_ieee11073_sfloat_t       spo2pr_normal___pr;                    /**< SpO2PR-Normal - PR value */
    st_ble_ieee11073_sfloat_t       spo2pr_fast___spo2;                    /**< SpO2PR-Fast - SpO2 value */
    st_ble_ieee11073_sfloat_t       spo2pr_fast___pr;                      /**< SpO2PR-Fast - PR value */
    st_ble_ieee11073_sfloat_t       spo2pr_slow___spo2;                    /**< SpO2PR-Slow - SpO2 value */
    st_ble_ieee11073_sfloat_t       spo2pr_slow___pr;                      /**< SpO2PR-Slow - PR value */

    
    /* measurement status definitions bit fields */
    bool is_measurement_ongoing;                                     /**< Measurement Ongoing */
    bool is_early_estimated_data;                                    /**< Early Estimated Data */
    bool is_validated_data;                                          /**< Validated Data */
    bool is_fully_qualified_data;                                    /**< Fully Qualified Data */
    bool is_data_from_measurement_storage;                           /**< Data from Measurement Storage */
    bool is_data_for_demonstration;                                  /**< Data for Demonstration */
    bool is_data_for_testing;                                        /**< Data for Testing */
    bool is_calibration_ongoing;                                     /**< Calibration Ongoing */
    bool is_measurement_unavailable;                                 /**< Measurement Unavailable */
    bool is_questionable_measurement_detected;                       /**< Questionable Measurement Detected */
    bool is_invalid_measurement_detected;                            /**< Invalid Measurement Detected */

    /* device and sensor status definitions bit fields */
    bool is_extended_display_update_ongoing;                         /**< Extended Display Update Ongoing */
    bool is_equipment_malfunction_detected;                          /**< Equipment Malfunction Detected */
    bool is_signal_processing_irregularity_detected;                 /**< Signal Processing Irregularity Detected */
    bool is_inadequate_signal_detected;                              /**< Inadequate Signal Detected */
    bool is_poor_signal_detected;                                    /**< Poor Signal Detected */
    bool is_low_perfusion_detected;                                  /**< Low Perfusion Detected */
    bool is_erratic_perfusion_detected;                              /**< Erratic Signal Detected */
    bool is_non_pulsatile_signal_detected;                           /**< Non-Pulsatile Signal Detected */
    bool is_questionable_pulse_detected;                             /**< Questionable Pulse Detected */
    bool is_signal_analysis_ongoing;                                 /**< Signal Analysis Ongoing */
    bool is_sensor_interference_detected;                            /**< Sensor Interference Detected */
    bool is_sensor_unconnected_to_user;                              /**< Sensor Unconnected to User */
    bool is_unknown_sensor_connected;                                /**< Unknown Sensor Connected */
    bool is_sensor_displaced;                                        /**< Sensor Displaced */
    bool is_sensor_malfunctioning;                                   /**< Sensor Malfunctioning */
    bool is_sensor_disconnected;                                     /**< Sensor Disconnected */

    st_ble_ieee11073_sfloat_t       pulse_amplitude_index;           /**< Pulse Amplitude Index value */
} st_ble_plxs_plx_continuous_measurement_t;

/*******************************************************************************************************************//**
* @brief PLX Continuous Measurement Client Characteristic Configuration descriptor parameters.
***********************************************************************************************************************/
typedef struct
{
    uint8_t value[20];  /**< PLX Continuous Measurement characteristic value */
} st_ble_plxs_plx_continuous_measurement_client_characteristic_configuration_t;

/*******************************************************************************************************************//**
* @brief PLX Features characteristic parameters.
***********************************************************************************************************************/
typedef struct 
{
    /* supported_features support bit fields */
    bool is_measurement_status_support_present;                      /**< Measurement Status support is present */
    bool is_device_sensor_status_support_present;                    /**< Device and Sensor Status support is present */
    bool is_measurement_storage_spot_check_measurement_supported;    /**< Measurement Storage for Spot-check measurements is supported */
    bool is_timestamp_spot_check_measurement_supported;              /**< Timestamp for Spot-check measurements is supported */
    bool is_spO2pr_fast_metric_supported;                            /**< SpO2PR-Fast metric is supported */
    bool is_spO2pr_slow_metric_supported;                            /**< SpO2PR-Slow metric is supported */
    bool is_pulse_amplitude_index_field_supported;                   /**< Pulse Amplitude Index field is supported */
    bool is_multiple_bonds_supported;                                /**< Multiple Bonds Supported */

    /* measurement status support bit fields */
    bool is_measurement_ongoing;                                     /**< Measurement Ongoing */    
    bool is_early_estimated_data;                                    /**< Early Estimated Data */
    bool is_validated_data;                                          /**< Validated Data */
    bool is_fully_qualified_data;                                    /**< Fully Qualified Data */
    bool is_data_from_measurement_storage;                           /**< Data from Measurement Storage */
    bool is_data_for_demonstration;                                  /**< Data for Demonstration */
    bool is_data_for_testing;                                        /**< Data for Testing */
    bool is_calibration_ongoing;                                     /**< Calibration Ongoing */
    bool is_measurement_unavailable;                                 /**< Measurement Unavailable */
    bool is_questionable_measurement_detected;                       /**< Questionable Measurement Detected */
    bool is_invalid_measurement_detected;                            /**< Invalid Measurement Detected */

    /* device and sensor status support bit fields */
    bool is_extended_display_update_ongoing;                         /**< Extended Display Update Ongoing */
    bool is_equipment_malfunction_detected;                          /**< Equipment Malfunction Detected */
    bool is_signal_processing_irregularity_detected;                 /**< Signal Processing Irregularity Detected */
    bool is_inadequate_signal_detected;                              /**< Inadequate Signal Detected */
    bool is_poor_signal_detected;                                    /**< Poor Signal Detected */
    bool is_low_perfusion_detected;                                  /**< Low Perfusion Detected */
    bool is_erratic_perfusion_detected;                              /**< Erratic Signal Detected */
    bool is_non_pulsatile_signal_detected;                           /**< Non-Pulsatile Signal Detected */
    bool is_questionable_pulse_detected;                             /**< Questionable Pulse Detected */
    bool is_signal_analysis_ongoing;                                 /**< Signal Analysis Ongoing */
    bool is_sensor_interference_detected;                            /**< Sensor Interference Detected */
    bool is_sensor_unconnected_to_user;                              /**< Sensor Unconnected to User */
    bool is_unknown_sensor_connected;                                /**< Unknown Sensor Connected */
    bool is_sensor_displaced;                                        /**< Sensor Displaced */
    bool is_sensor_malfunctioning;                                   /**< Sensor Malfunctioning */
    bool is_sensor_disconnected;                                     /**< Sensor Disconnected */     
} st_ble_plxs_plx_features_t;

/*******************************************************************************************************************//**
* @brief Record Access Control Point characteristic parameters.
***********************************************************************************************************************/
typedef struct 
{
    uint8_t op_code;                             /**< Op Code value */
    uint8_t racp_operator;                       /**< Operator value */
    uint8_t operand_values[8];                   /**< Operand value */
    uint8_t operand_reponse_code_values[10];     /**< Operand response code value */
} st_ble_plxs_record_access_control_point_t;

/*******************************************************************************************************************//**
* @brief Record Access Control Point Client Characteristic Configuration descriptor parameters.
***********************************************************************************************************************/
typedef struct 
{
    uint8_t value[20];  /**< Record Access Control Point characteristic value */
} st_ble_plxs_record_access_control_point_client_characteristic_configuration_t;

/***********************************************************************************************************************
* Exported global functions (to be accessed by other files)
***********************************************************************************************************************/

/*******************************************************************************************************************//**
* @brief     Initialize Pulse Oximeter Service .
* @details   This function shall be called once at startup.
* @param[in] p_param pointer to the Pulse Oximeter Service  initialization parameters.
* @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_PLXS_Init(const st_ble_plxs_init_param_t *p_param);

/*******************************************************************************************************************//**
* @brief     Perform Pulse Oximeter Service connection settings.
* @details   This function shall be called on each connection establishment.
* @param[in] conn_hdl Connection handle.
* @param[in] p_param  pointer to the  Connection parameters.
* @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_PLXS_Connect(uint16_t conn_hdl, const st_ble_plxs_connect_param_t *p_param);

/*******************************************************************************************************************//**
* @brief     Retrieve Pulse Oximeter Service connection specific settings before disconnection.
* @details   This function shall be called on each disconnection.
* @param[in] conn_hdl Connection handle.
* @param[in] p_param  pointer to the Disconnection parameters.
* @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_PLXS_Disconnect(uint16_t conn_hdl, st_ble_plxs_disconnect_param_t *p_param);
/*******************************************************************************************************************//**
* @brief     Send PLX Spot-Check Measurement indication.
* @param[in] conn_hdl  Connection handle.
* @param[in] p_app_value pointer to the PLX Spot-Check Measurement value to send.
* @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_PLXS_IndicatePlxSpotcheckMeasurement(uint16_t conn_hdl, 
    const st_ble_plxs_plx_spot_check_measurement_t *p_app_value);


/*******************************************************************************************************************//**
* @brief     Send PLX Continuous Measurement notification.
* @param[in] conn_hdl  Connection handle.
* @param[in] p_app_value pointer to the PLX Continuous Measurement value to send.
* @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_PLXS_NotifyPlxContinuousMeasurement(uint16_t conn_hdl,
    const st_ble_plxs_plx_continuous_measurement_t *p_app_value);

/*******************************************************************************************************************//**
* @brief      Get PLX Features characteristic value from local GATT database.
* @param[out] p_app_value pointer to the Retrieved PLX Features characteristic value.
* @return     @ref ble_status_t
**********************************************************************************************************************/
ble_status_t R_BLE_PLXS_GetPlxFeatures(st_ble_plxs_plx_features_t *p_app_value);

/*******************************************************************************************************************//**
* @brief     Set PLX Features characteristic value to local GATT database.
* @param[in] p_app_value pointer to the PLX Features characteristic value to set.
* @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_PLXS_SetPlxFeatures(const st_ble_plxs_plx_features_t *p_app_value);

/*******************************************************************************************************************//**
* @brief     Send Record Access Control Point indication.
* @param[in] conn_hdl  Connection handle.
* @param[in] p_app_value pointer to the Record Access Control Point value to send.
* @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_PLXS_IndicateRecordAccessControlPoint(uint16_t conn_hdl, 
    const st_ble_plxs_record_access_control_point_t *p_app_value);

/*******************************************************************************************************************//**
* @brief     Send All Record Access Control Point indication.
* @param[in] conn_hdl  Connection handle.
* @param[in] p_app_value pointer to the Record Access Control Point value to send.
* @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t plxs_indicate_report_stored_all_records(uint16_t conn_hdl, uint8_t opcode, uint16_t operand);

/*******************************************************************************************************************//**
* @brief     Return version of the PLXC service server.
* @return    version
***********************************************************************************************************************/
uint32_t R_BLE_PLXS_GetVersion(void);

#endif /* R_BLE_PLXS_H_ */

/** @} */
