/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_plxs_recode.h
 * Version : 1.0
 * Description : The header file for Pulse Oximeter Service PLX Spot-check Measurement Charcteristic measurement storage.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 31.12.2999 1.00 First Release
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @file
 * @defgroup plxs Pulse Oximeter Service Server
 * @{
 * @ingroup profile
 **********************************************************************************************************************/


/***********************************************************************************************************************//**
* Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#ifndef R_BLE_PLXS_H
#include "r_ble_plxs.h"
#endif /* R_BLE_PLXS_H */

#ifndef R_BLE_PLXS_RECORD_H
#define R_BLE_PLXS_RECORD_H

/***********************************************************************************************************************//**
* Macro definitions
***********************************************************************************************************************/
#define BLE_PLXS_DB_MAX_NUM_OF_RECORDS  (30)
#define BLE_PLXS_DB_INVALID_INDEX       (0xFFFF)

typedef struct
{
    bool status;
    uint16_t next_index;
    uint16_t prev_index;
    st_ble_plxs_plx_spot_check_measurement_t psc_meas;
} st_ble_plxs_db_record_t;

typedef enum {
    BLE_PLXS_DB_SUCCESS = 0,        //success
    BLE_PLXS_DB_ERR_INVALID_INDEX,  //accessed to wrong index
    BLE_PLXS_DB_ERR_INVALID_PTR,    //accessed to wrong pointer
    BLE_PLXS_DB_ERR_DB_FULL,        //max number of records are set to PLXS database
    BLE_PLXS_DB_ERR_DB_EMPTY,       //no records are set to PLXS database
} e_ble_plxs_db_result_t;

/*******************************************************************************************************************//**
* @brief        Initialize PLXS database.
* @details      This function shall be called to delete all records stored in database.
***********************************************************************************************************************/
void R_BLE_PLXS_DB_Init(void);

/*******************************************************************************************************************//**
* @brief        Set record to PLXS database.
* @param[out]   *index Pointer to retrieved index of record stored in PLXS database.
* @param[in]    *meas Pointer to PLX spot-check measurement value to be stored
* @return       Result of the function.
***********************************************************************************************************************/
e_ble_plxs_db_result_t R_BLE_PLXS_DB_SetRecord(uint16_t *index, st_ble_plxs_plx_spot_check_measurement_t *psc_meas);

/*******************************************************************************************************************//**
* @brief        Get record from index of PLXS database.
* @param[in]    index Index of record stored in PLXS database.
* @param[out]   *meas Pointer to the Retrieved PLX spot-check measurement value
* @return       Reult of function.
***********************************************************************************************************************/
e_ble_plxs_db_result_t R_BLE_PLXS_DB_GetRecordIndex(uint16_t index, st_ble_plxs_plx_spot_check_measurement_t *psc_meas);

/*******************************************************************************************************************//**
* @brief        Get record of oldest index
* @param[out]   *meas Pointer to the Retrieved PLX spot-check measurement value
* @return       Reult of function.
***********************************************************************************************************************/
e_ble_plxs_db_result_t R_BLE_PLXS_DB_GetRecordOldest(st_ble_plxs_plx_spot_check_measurement_t *psc_meas);

/*******************************************************************************************************************//**
* @brief        Get number of records stored in PLXS database.
* @param[out]   *num Pointer to retrieved number of records stored in PLXS database.
* @return       Result of the function.
***********************************************************************************************************************/
e_ble_plxs_db_result_t R_BLE_PLXS_DB_GetRecordNum(uint16_t *record_num);

/*******************************************************************************************************************//**
* @brief        Delete record specified by index.
* @param[in]    index Index of record stored in PLXS database.
* @return       Result of the function.
***********************************************************************************************************************/
e_ble_plxs_db_result_t R_BLE_PLXS_DB_DeleteRecordIndex(uint16_t index);

/*******************************************************************************************************************//**
* @brief        Delete oldest record from PLXS database and update oldest record index.
* @return       Result of the function.
***********************************************************************************************************************/
e_ble_plxs_db_result_t R_BLE_PLXS_DB_DeleteRecordOldest(void);



#endif /* R_BLE_PLXS_RECORD_H */

/** @} */