/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_ftmc.h
 * Version : 1.0
 * Description : This module implements Fitness Machine Service Client.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 29.05.2019 1.00
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @file
 * @defgroup ftmc Fitness Machine Service Client
 * @{
 * @ingroup profile
 * @brief This is the client for the Fitness Machine Service.
 **********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "profile_cmn/r_ble_serv_common.h"

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
#ifndef R_BLE_FTMC_H
#define R_BLE_FTMC_H

/*******************************************************************************************************************//**
 * @brief Training Status String Length.
***********************************************************************************************************************/
#define BLE_FTMC_TRAINING_STATUS_STRING_LEN                                    (18)

/*******************************************************************************************************************//**
 * @brief Fitness Machine Feature characteristic value length.
***********************************************************************************************************************/
#define BLE_FTMC_FITNESS_MACHINE_FEATURE_LEN                                   (8)

/*******************************************************************************************************************//**
 * @brief Treadmill Data characteristic value length.
***********************************************************************************************************************/
#define BLE_FTMC_TREADMILL_DATA_LEN                                            (34)

/*******************************************************************************************************************//**
 * @brief Cross Trainer Data characteristic value length.
***********************************************************************************************************************/
#define BLE_FTMC_CROSS_TRAINER_DATA_LEN                                        (41)

/*******************************************************************************************************************//**
 * @brief Step Climber Data characteristic value length.
***********************************************************************************************************************/
#define BLE_FTMC_STEP_CLIMBER_DATA_LEN                                         (23)

/*******************************************************************************************************************//**
 * @brief Stair Climber Data characteristic value length.
***********************************************************************************************************************/
#define BLE_FTMC_STAIR_CLIMBER_DATA_LEN                                        (23)

/*******************************************************************************************************************//**
 * @brief Rower Data characteristic value length.
***********************************************************************************************************************/
#define BLE_FTMC_ROWER_DATA_LEN                                                (30)

/*******************************************************************************************************************//**
 * @brief Indoor Bike Data characteristic value length.
***********************************************************************************************************************/
#define BLE_FTMC_INDOOR_BIKE_DATA_LEN                                          (30)

/*******************************************************************************************************************//**
 * @brief Training Status characteristic value length.
***********************************************************************************************************************/
#define BLE_FTMC_TRAINING_STATUS_LEN                                           (20)

/*******************************************************************************************************************//**
 * @brief Supported Speed Range characteristic value length.
***********************************************************************************************************************/
#define BLE_FTMC_SUPPORTED_SPEED_RANGE_LEN                                     (6)

/*******************************************************************************************************************//**
 * @brief Supported Inclination Range characteristic value length.
***********************************************************************************************************************/
#define BLE_FTMC_SUPPORTED_INCLINATION_RANGE_LEN                               (6)

/*******************************************************************************************************************//**
 * @brief Supported Resistance Level Range characteristic value length.
***********************************************************************************************************************/
#define BLE_FTMC_SUPPORTED_RESISTANCE_LEVEL_RANGE_LEN                          (6)

/*******************************************************************************************************************//**
 * @brief Supported Power Range characteristic value length.
***********************************************************************************************************************/
#define BLE_FTMC_SUPPORTED_POWER_RANGE_LEN                                     (6)

/*******************************************************************************************************************//**
 * @brief Supported Heart Rate Range characteristic value length.
***********************************************************************************************************************/
#define BLE_FTMC_SUPPORTED_HEART_RATE_RANGE_LEN                                (3)

/*******************************************************************************************************************//**
 * @brief Fitness Machine Control Point characteristic value length.
***********************************************************************************************************************/
#define BLE_FTMC_FITNESS_MACHINE_CONTROL_POINT_LEN                             (11)

/*******************************************************************************************************************//**
 * @brief Fitness Machine Status characteristic value length.
***********************************************************************************************************************/
#define BLE_FTMC_FITNESS_MACHINE_STATUS_LEN                                    (11)

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @brief Fitness Machine Service Client event data.
***********************************************************************************************************************/
typedef struct
{
    uint16_t  conn_hdl;  /**< Connection handle */
    uint16_t  param_len; /**< Event parameter length */
    void     *p_param;   /**< Event parameter */
} st_ble_ftmc_evt_data_t;

/*******************************************************************************************************************//**
 * @brief Fitness Machine Service Client event callback.
***********************************************************************************************************************/
typedef void (*ble_ftmc_app_cb_t)(uint16_t type, ble_status_t result, st_ble_ftmc_evt_data_t *p_data);

/*******************************************************************************************************************//**
 * @brief Fitness Machine Service Client event type.
***********************************************************************************************************************/
typedef enum {
    BLE_FTMC_EVENT_FITNESS_MACHINE_FEATURE_READ_RSP,
    /**< Fitness Machine Feature characteristic read response event */
    BLE_FTMC_EVENT_TREADMILL_DATA_HDL_VAL_NTF,
    /**< Treadmill Data characteristic handle value notification event */
    BLE_FTMC_EVENT_CROSS_TRAINER_DATA_HDL_VAL_NTF,
    /**< Cross Trainer Data characteristic handle value notification event */
    BLE_FTMC_EVENT_STEP_CLIMBER_DATA_HDL_VAL_NTF,
    /**< Step Climber Data characteristic handle value notification event */
    BLE_FTMC_EVENT_STAIR_CLIMBER_DATA_HDL_VAL_NTF,
    /**< Stair Climber Data characteristic handle value notification event */
    BLE_FTMC_EVENT_ROWER_DATA_HDL_VAL_NTF,
    /**< Rower Data characteristic handle value notification event */
    BLE_FTMC_EVENT_INDOOR_BIKE_DATA_HDL_VAL_NTF,
    /**< Indoor Bike Data characteristic handle value notification event */
    BLE_FTMC_EVENT_TRAINING_STATUS_HDL_VAL_NTF,
    /**< Training Status characteristic handle value notification event */
    BLE_FTMC_EVENT_TRAINING_STATUS_READ_RSP, 
    /**< Training Status characteristic read response event */
    BLE_FTMC_EVENT_SUPPORTED_SPEED_RANGE_READ_RSP,
    /**< Supported Speed Range characteristic read response event */
    BLE_FTMC_EVENT_SUPPORTED_INCLINATION_RANGE_READ_RSP,
    /**< Supported Inclination Range characteristic read response event */
    BLE_FTMC_EVENT_SUPPORTED_RESISTANCE_LEVEL_RANGE_READ_RSP,
    /**< Supported Resistance Level Range characteristic read response event */
    BLE_FTMC_EVENT_SUPPORTED_POWER_RANGE_READ_RSP,
    /**< Supported Power Range characteristic read response event */
    BLE_FTMC_EVENT_SUPPORTED_HEART_RATE_RANGE_READ_RSP,
    /**< Supported Heart Rate Range characteristic read response event */
    BLE_FTMC_EVENT_FITNESS_MACHINE_CONTROL_POINT_HDL_VAL_IND,
    /**< Fitness Machine Control Point characteristic handle value indication event */
    BLE_FTMC_EVENT_FITNESS_MACHINE_CONTROL_POINT_WRITE_RSP,
    /**< Fitness Machine Control Point characteristic write response event */
    BLE_FTMC_EVENT_FITNESS_MACHINE_STATUS_HDL_VAL_NTF,
    /**< Fitness Machine Status characteristic handle value notification event */
    BLE_FTMC_EVENT_CLI_CNFG_WRITE_RSP,
    /**< Cli Cnfig write response */
    BLE_FTMC_EVENT_ERROR_RSP,
    /**< error response */
} e_ble_ftmc_event_t;

/*******************************************************************************************************************//**
 * @brief Training Status enumeration.
***********************************************************************************************************************/
typedef enum {
    BLE_FTMC_TRAINING_STATUS_TRAINING_STATUS_OTHER                     = 0,  /**< Training Status Other */
    BLE_FTMC_TRAINING_STATUS_TRAINING_STATUS_IDLE                      = 1,  /**< Training Status Idle */
    BLE_FTMC_TRAINING_STATUS_TRAINING_STATUS_WARMING_UP                = 2,  /**< Training Status Warming Up */
    BLE_FTMC_TRAINING_STATUS_TRAINING_STATUS_LOW_INTENSITY_INTERVAL    = 3,  
    /**< Training Status Low Intensity Interval */
    BLE_FTMC_TRAINING_STATUS_TRAINING_STATUS_HIGH_INTENSITY_INTERVAL   = 4,  
    /**< Training Status High Intensity Interval */
    BLE_FTMC_TRAINING_STATUS_TRAINING_STATUS_RECOVERY_INTERVAL         = 5,  /**< Training Status Recovery Interval */
    BLE_FTMC_TRAINING_STATUS_TRAINING_STATUS_ISOMETRIC                 = 6,  /**< Training Status sometric */
    BLE_FTMC_TRAINING_STATUS_TRAINING_STATUS_HEART_RATE_CONTROL        = 7,  /**< Training Status Heart Rate Control */
    BLE_FTMC_TRAINING_STATUS_TRAINING_STATUS_FITNESS_TEST              = 8,  /**< Training Status Fitness Test */
 
    BLE_FTMC_TRAINING_STATUS_TRAINING_STATUS_COOL_DOWN                 = 11, /**< Training Status Cool Down */
    BLE_FTMC_TRAINING_STATUS_TRAINING_STATUS_WATT_CONTROL              = 12, /**< Training Status Watt Control */
    BLE_FTMC_TRAINING_STATUS_TRAINING_STATUS_MANUAL_MODE__QUICK_START_ = 13,
    /**< Training Status Manual Mode (Quick Start) */
    BLE_FTMC_TRAINING_STATUS_TRAINING_STATUS_PRE_WORKOUT               = 14, /**< Training Status Pre-Workout */
    BLE_FTMC_TRAINING_STATUS_TRAINING_STATUS_POST_WORKOUT              = 15, /**< Training Status  Post-Workout */
    BLE_FTMC_TRAINING_STATUS_TRAINING_STATUS_SPEED_OUTSIDE_OF_CONTROL_REGION_LOW = 9,
    /**< Training Status Speed Outside of Control Region - Low (increase speed to return to controllable region) */
    BLE_FTMC_TRAINING_STATUS_TRAINING_STATUS_SPEED_OUTSIDE_OF_CONTROL_REGION_HIGH = 10,
    /**< Training Status Speed Outside of Control Region - High (decrease speed to return to controllable region) */
} e_ble_ftmc_training_status_t;

/*******************************************************************************************************************//**
 * @brief Op Code enumeration.
***********************************************************************************************************************/
typedef enum {
    BLE_FTMC_FITNESS_MACHINE_CONTROL_POINT_OP_CODE_REQUEST_CONTROL                             = 0,
                            /**< Op Code for Request Control */
    BLE_FTMC_FITNESS_MACHINE_CONTROL_POINT_OP_CODE_RESET                                       = 1,
    /**< Op Code for Reset */
    BLE_FTMC_FITNESS_MACHINE_CONTROL_POINT_OP_CODE_SET_TARGET_SPEED                            = 2,
    /**< Op Code for Set Target Speed */
    BLE_FTMC_FITNESS_MACHINE_CONTROL_POINT_OP_CODE_SET_TARGET_INCLINATION                      = 3,
    /**< Op Code for Set Target Inclination */
    BLE_FTMC_FITNESS_MACHINE_CONTROL_POINT_OP_CODE_SET_TARGET_RESISTANCE_LEVEL                 = 4,
    /**< Op Code for Set Target Resistance Level */
    BLE_FTMC_FITNESS_MACHINE_CONTROL_POINT_OP_CODE_SET_TARGET_POWER                            = 5,
    /**< Op Code for Set Target Power */
    BLE_FTMC_FITNESS_MACHINE_CONTROL_POINT_OP_CODE_SET_TARGET_HEART_RATE                       = 6,
    /**< Op Code for Set Target Heart Rate */
    BLE_FTMC_FITNESS_MACHINE_CONTROL_POINT_OP_CODE_START_OR_RESUME                             = 7,
    /**< Op Code for Start or Resume */
    BLE_FTMC_FITNESS_MACHINE_CONTROL_POINT_OP_CODE_STOP_OR_PAUSE                               = 8,
    /**< Op Code for Stop or Pause */
    BLE_FTMC_FITNESS_MACHINE_CONTROL_POINT_OP_CODE_SET_TARGETED_EXPENDED_ENERGY                = 9,
    /**< Op Code for Set Targeted Expended Energy */
    BLE_FTMC_FITNESS_MACHINE_CONTROL_POINT_OP_CODE_SET_TARGETED_NUMBER_OF_STEPS                = 10,
    /**< Op Code for Set Targeted Number of Steps */
    BLE_FTMC_FITNESS_MACHINE_CONTROL_POINT_OP_CODE_SET_TARGETED_NUMBER_OF_STRIDES              = 11,
    /**< Op Code for Set Targeted Number of Strides */
    BLE_FTMC_FITNESS_MACHINE_CONTROL_POINT_OP_CODE_SET_TARGETED_DISTANCE                       = 12,
    /**< Op Code for Set Targeted Distance */
    BLE_FTMC_FITNESS_MACHINE_CONTROL_POINT_OP_CODE_SET_TARGETED_TRAINING_TIME                  = 13,
    /**< Op Code for Set Targeted Training Time */
    BLE_FTMC_FITNESS_MACHINE_CONTROL_POINT_OP_CODE_SET_TARGETED_TIME_IN_TWO_HEART_RATE_ZONES   = 14,
    /**< Op Code for Set Targeted Time in Two Heart Rate Zones*/
    BLE_FTMC_FITNESS_MACHINE_CONTROL_POINT_OP_CODE_SET_TARGETED_TIME_IN_THREE_HEART_RATE_ZONES = 15,
    /**< Op Code for Set Targeted Time in Three Heart Rate Zones */
    BLE_FTMC_FITNESS_MACHINE_CONTROL_POINT_OP_CODE_SET_TARGETED_TIME_IN_FIVE_HEART_RATE_ZONES  = 16,
    /**< Op Code for Set Targeted Time in Five Heart Rate Zones */
    BLE_FTMC_FITNESS_MACHINE_CONTROL_POINT_OP_CODE_SET_INDOOR_BIKE_SIMULATION_PARAMETERS       = 17,
    /**< Op Code for Set Indoor Bike Simulation Parameters */
    BLE_FTMC_FITNESS_MACHINE_CONTROL_POINT_OP_CODE_SET_WHEEL_CIRCUMFERENCE                     = 18,
    /**< Op Code for Set Wheel Circumference */
    BLE_FTMC_FITNESS_MACHINE_CONTROL_POINT_OP_CODE_SPIN_DOWN_CONTROL                           = 19,
    /**< Op Code for Spin Down Control */
    BLE_FTMC_FITNESS_MACHINE_CONTROL_POINT_OP_CODE_SET_TARGETED_CADENCE                        = 20,
    /**< Op Code for Set Targeted Cadence */
    BLE_FTMC_FITNESS_MACHINE_CONTROL_POINT_OP_CODE_RESPONSE_CODE                               = 128,
    /**< Op Code for Response Code */
} e_ble_ftmc_fitness_machine_control_point_op_code_t;

/*******************************************************************************************************************//**
 * @brief Control Information enumeration.
***********************************************************************************************************************/
typedef enum 
{
    BLE_FTMC_FITNESS_MACHINE_CONTROL_POINT_CONTROL_INFORMATION_RESERVED_FOR_FUTURE_USE = 0,
    /**< Control Information Value Reserved for Future Use */
    BLE_FTMC_FITNESS_MACHINE_CONTROL_POINT_CONTROL_INFORMATION_STOP                    = 1,
    /**< Control Information Value to Stop */
    BLE_FTMC_FITNESS_MACHINE_CONTROL_POINT_CONTROL_INFORMATION_PAUSE                   = 2,
    /**< Control Information Value to Pause */
} e_ble_ftmc_fitness_machine_control_point_control_information_t;

/*******************************************************************************************************************//**
 * @brief Control Parameter enumeration.
***********************************************************************************************************************/
typedef enum 
{
    BLE_FTMC_FITNESS_MACHINE_CONTROL_POINT_CONTROL_PARAMETER_RESERVED_FOR_FUTURE_USE = 0,
    /**< Control Parameter Value Reserved for Future Use */
    BLE_FTMC_FITNESS_MACHINE_CONTROL_POINT_CONTROL_PARAMETER_START                   = 1,
    /**< Control Parameter Value to Start */
    BLE_FTMC_FITNESS_MACHINE_CONTROL_POINT_CONTROL_PARAMETER_IGNORE                  = 2,
    /**< Control Parameter Value to Ignore */
} e_ble_ftmc_fitness_machine_control_point_control_parameter_t;

/*******************************************************************************************************************//**
 * @brief Result Code enumeration.
***********************************************************************************************************************/
typedef enum 
{
    BLE_FTMC_FITNESS_MACHINE_CONTROL_POINT_RESULT_CODE_RESERVED_FOR_FUTURE_USE = 0,
    /**< Result Code Value Reserved for Future Use */
    BLE_FTMC_FITNESS_MACHINE_CONTROL_POINT_RESULT_CODE_SUCCESS                 = 1,
    /**< Result Code Value for Success */
    BLE_FTMC_FITNESS_MACHINE_CONTROL_POINT_RESULT_CODE_OP_CODE_NOT_SUPPORTED   = 2,
    /**< Result Code Value for Op Code Not Supported */
    BLE_FTMC_FITNESS_MACHINE_CONTROL_POINT_RESULT_CODE_INVALID_PARAMETER       = 3,
    /**< Result Code Value for Invalid Parameter */
    BLE_FTMC_FITNESS_MACHINE_CONTROL_POINT_RESULT_CODE_OPERATION_FAILED        = 4,
    /**< Result Code Value for Operation Failed */
    BLE_FTMC_FITNESS_MACHINE_CONTROL_POINT_RESULT_CODE_CONTROL_NOT_PERMITTED   = 5,
    /**< Result Code Value for Control Not Permitted */
} e_ble_ftmc_fitness_machine_control_point_result_code_t;

/*******************************************************************************************************************//**
 * @brief Op Code enumeration.
***********************************************************************************************************************/
typedef enum 
{
    BLE_FTMC_FITNESS_MACHINE_STATUS_OP_CODE_RESERVED_FOR_FUTURE_USE                         = 0,
    /**< Op Code Reserved for Future Use */
    BLE_FTMC_FITNESS_MACHINE_STATUS_OP_CODE_RESET                                           = 1,
    /**< Op Code for Reset */
    BLE_FTMC_FITNESS_MACHINE_STATUS_OP_CODE_FITNESS_MACHINE_STOPPED_OR_PAUSED_BY_THE_USER   = 2,
    /**< Op Code for Fitness Machine Stopped or Paused by the User */
    BLE_FTMC_FITNESS_MACHINE_STATUS_OP_CODE_FITNESS_MACHINE_STOPPED_BY_SAFETY_KEY           = 3,
    /**< Op Code for Fitness Machine Stopped by Safety Key */
    BLE_FTMC_FITNESS_MACHINE_STATUS_OP_CODE_FITNESS_MACHINE_STARTED_OR_RESUMED_BY_THE_USER  = 4,
    /**< Op Code for Fitness Machine Started or Resumed by the User */
    BLE_FTMC_FITNESS_MACHINE_STATUS_OP_CODE_TARGET_SPEED_CHANGED                            = 5,
    /**< Op Code for Target Speed Changed */
    BLE_FTMC_FITNESS_MACHINE_STATUS_OP_CODE_TARGET_INCLINE_CHANGED                          = 6,
    /**< Op Code for Target Incline Changed */
    BLE_FTMC_FITNESS_MACHINE_STATUS_OP_CODE_TARGET_RESISTANCE_LEVEL_CHANGED                 = 7,
    /**< Op Code for Target Resistance Level Changed */
    BLE_FTMC_FITNESS_MACHINE_STATUS_OP_CODE_TARGET_POWER_CHANGED                            = 8,
    /**< Op Code for Target Power Changed */
    BLE_FTMC_FITNESS_MACHINE_STATUS_OP_CODE_TARGET_HEART_RATE_CHANGED                       = 9,
    /**< Op Code for Target Heart Rate Changed */
    BLE_FTMC_FITNESS_MACHINE_STATUS_OP_CODE_TARGETED_EXPENDED_ENERGY_CHANGED                = 10,
    /**< Op Code for Targeted Expended Energy Changed */
    BLE_FTMC_FITNESS_MACHINE_STATUS_OP_CODE_TARGETED_NUMBER_OF_STEPS_CHANGED                = 11,
    /**< Op Code for Targeted Number of Steps Changed */
    BLE_FTMC_FITNESS_MACHINE_STATUS_OP_CODE_TARGETED_NUMBER_OF_STRIDES_CHANGED              = 12,
    /**< Op Code for Targeted Number of Strides Changed */
    BLE_FTMC_FITNESS_MACHINE_STATUS_OP_CODE_TARGETED_DISTANCE_CHANGED                       = 13,
    /**< Op Code for Targeted Distance Changed */
    BLE_FTMC_FITNESS_MACHINE_STATUS_OP_CODE_TARGETED_TRAINING_TIME_CHANGED                  = 14,
    /**< Op Code for Targeted Training Time Changed */
    BLE_FTMC_FITNESS_MACHINE_STATUS_OP_CODE_TARGETED_TIME_IN_TWO_HEART_RATE_ZONES_CHANGED   = 15,
    /**< Op Code for Targeted Time in Two Heart Rate Zones Changed */
    BLE_FTMC_FITNESS_MACHINE_STATUS_OP_CODE_TARGETED_TIME_IN_THREE_HEART_RATE_ZONES_CHANGED = 16,
    /**< Op Code for Targeted Time in Three Heart Rate Zones Changed */
    BLE_FTMC_FITNESS_MACHINE_STATUS_OP_CODE_TARGETED_TIME_IN_FIVE_HEART_RATE_ZONES_CHANGED  = 17,
    /**< Op Code for Targeted Time in Five Heart Rate Zones Changed */
    BLE_FTMC_FITNESS_MACHINE_STATUS_OP_CODE_INDOOR_BIKE_SIMULATION_PARAMETERS_CHANGED       = 18,
    /**< Op Code for Indoor Bike Simulation Parameters Changed */
    BLE_FTMC_FITNESS_MACHINE_STATUS_OP_CODE_WHEEL_CIRCUMFERENCE_CHANGED                     = 19,
    /**< Op Code for Wheel Circumference Changed */
    BLE_FTMC_FITNESS_MACHINE_STATUS_OP_CODE_SPIN_DOWN_STATUS                                = 20,
    /**< Op Code for Spin Down Status */
    BLE_FTMC_FITNESS_MACHINE_STATUS_OP_CODE_TARGETED_CADENCE_CHANGED                        = 21,
    /**< Op Code for Targeted Cadence Changed */
    BLE_FTMC_FITNESS_MACHINE_STATUS_OP_CODE_CONTROL_PERMISSION_LOST                         = 255,
    /**< Op Code for Control Permission Lost */
} e_ble_ftmc_fitness_machine_status_op_code_t;

/*******************************************************************************************************************//**
 * @brief Control Information enumeration.
***********************************************************************************************************************/
typedef enum
{
    BLE_FTMC_FITNESS_MACHINE_STATUS_CONTROL_POINT_CONTROL_INFORMATION_RESERVED_FOR_FUTURE_USE = 0,
    /**< Control Information Value Reserved for Future Use */
    BLE_FTMC_FITNESS_MACHINE_STATUS_CONTROL_POINT_CONTROL_INFORMATION_STOP                    = 1,
    /**<  Control Information Value to Stop */
    BLE_FTMC_FITNESS_MACHINE_STATUS_CONTROL_POINT_CONTROL_INFORMATION_PAUSE                   = 2,
    /**<  Control Information Value to Pause */
} e_ble_ftmc_fitness_machine_status_control_information_t;

/*******************************************************************************************************************//**
 * @brief Spin Down Status enumeration.
***********************************************************************************************************************/
typedef enum 
{
    BLE_FTMC_FITNESS_MACHINE_STATUS_SPIN_DOWN_STATUS_RESERVED_FOR_FUTURE_USE = 0,
    /**< Spin Down Status Value Reserved for Future Use */
    BLE_FTMC_FITNESS_MACHINE_STATUS_SPIN_DOWN_STATUS_SPIN_DOWN_REQUESTED     = 1,
    /**< Spin Down Status Value for Spin Down Requested  */
    BLE_FTMC_FITNESS_MACHINE_STATUS_SPIN_DOWN_STATUS_SUCCESS                 = 2,
    /**< Spin Down Status Value for Success */
    BLE_FTMC_FITNESS_MACHINE_STATUS_SPIN_DOWN_STATUS_ERROR                   = 3,
    /**< Spin Down Status Value for Error */
    BLE_FTMC_FITNESS_MACHINE_STATUS_SPIN_DOWN_STATUS_STOP_PEDALING           = 4,
    /**< Spin Down Status Value for Stop Pedaling */
} e_ble_ftmc_fitness_machine_status_spindown_status_t;

/*******************************************************************************************************************//**
 * @brief Fitness Machine Service attribute handles.
***********************************************************************************************************************/
typedef struct 
{
    st_ble_gatt_hdl_range_t service_range;
    /**< Fitness Machine Service range */
    uint16_t fitness_machine_feature_char_val_hdl;
    /**< Fitness Machine Feature characteristic value handle */
    uint16_t treadmill_data_char_val_hdl;
    /**< Treadmill Data characteristic value handle */
    uint16_t treadmill_data_cli_cnfg_hdl;
    /**< Treadmill Data characteristic Client Characteristic Configuration descriptor handle */
    uint16_t cross_trainer_data_char_val_hdl;
    /**< Cross Trainer Data characteristic value handle */
    uint16_t cross_trainer_data_cli_cnfg_hdl;
    /**< Cross Trainer Data characteristic Client Characteristic Configuration descriptor handle */
    uint16_t step_climber_data_char_val_hdl;
    /**< Step Climber Data characteristic value handle */
    uint16_t step_climber_data_cli_cnfg_hdl;
    /**< Step Climber Data characteristic Client Characteristic Configuration descriptor handle */
    uint16_t stair_climber_data_char_val_hdl;
    /**< Stair Climber Data characteristic value handle */
    uint16_t stair_climber_data_cli_cnfg_hdl;
    /**< Stair Climber Data characteristic Client Characteristic Configuration descriptor handle */
    uint16_t rower_data_char_val_hdl;
    /**< Rower Data characteristic value handle */
    uint16_t rower_data_cli_cnfg_hdl;
    /**< Rower Data characteristic Client Characteristic Configuration descriptor handle */
    uint16_t indoor_bike_data_char_val_hdl;
    /**< Indoor Bike Data characteristic value handle */
    uint16_t indoor_bike_data_cli_cnfg_hdl;
    /**< Indoor Bike Data characteristic Client Characteristic Configuration descriptor handle */
    uint16_t training_status_char_val_hdl;
    /**< Training Status characteristic value handle */
    uint16_t training_status_cli_cnfg_hdl;
    /**< Training Status characteristic Client Characteristic Configuration descriptor handle */
    uint16_t supported_speed_range_char_val_hdl;
    /**< Supported Speed Range characteristic value handle */
    uint16_t supported_inclination_range_char_val_hdl;
    /**< Supported Inclination Range characteristic value handle */
    uint16_t supported_resistance_level_range_char_val_hdl;
    /**< Supported Resistance Level Range characteristic value handle */
    uint16_t supported_power_range_char_val_hdl;
    /**< Supported Power Range characteristic value handle */
    uint16_t supported_heart_rate_range_char_val_hdl;
    /**< Supported Heart Rate Range characteristic value handle */
    uint16_t fitness_machine_control_point_char_val_hdl;
    /**< Fitness Machine Control Point characteristic value handle */
    uint16_t fitness_machine_control_point_cli_cnfg_hdl;
    /**< Fitness Machine Control Point characteristic Client Characteristic Configuration descriptor handle */
    uint16_t fitness_machine_status_char_val_hdl;
    /**< Fitness Machine Status characteristic value handle */
    uint16_t fitness_machine_status_cli_cnfg_hdl;
    /**< Fitness Machine Status characteristic Client Characteristic Configuration descriptor handle */
} st_ble_ftmc_hdls_t;

/*******************************************************************************************************************//**
 * @brief Fitness Machine Service initialization parameters.
***********************************************************************************************************************/
typedef struct 
{
    ble_ftmc_app_cb_t cb;            /**< Fitness Machine Service Client event handler */
} st_ble_ftmc_init_param_t;

/*******************************************************************************************************************//**
 * @brief Fitness Machine Service Client connection parameters.
***********************************************************************************************************************/
typedef struct 
{
    st_ble_ftmc_hdls_t *p_hdls;      /**< Fitness Machine Service handles */
} st_ble_ftmc_connect_param_t;

/*******************************************************************************************************************//**
 * @brief Fitness Machine Service disconnection parameters.
***********************************************************************************************************************/
typedef struct 
{
    st_ble_ftmc_hdls_t *p_hdls;      /**< Fitness Machine Service handles */
} st_ble_ftmc_disconnect_param_t;

/*******************************************************************************************************************//**
 * @brief Fitness Machine Feature characteristic parameters.
***********************************************************************************************************************/
typedef struct 
{
    bool is_average_speed_supported;
    /**< Value indicating Average Speed Supported feature */
    bool is_cadence_supported;
    /**< Value indicating Cadence Supported feature */
    bool is_total_distance_supported;
    /**< Value indicating Total Distance Supported feature */
    bool is_inclination_supported;
    /**< Value indicating Inclination Supported feature */
    bool is_elevation_gain_supported;
    /**< Value indicating Elevation Gain Supported feature */
    bool is_pace_supported;
    /**< Value indicating Pace Supported feature */
    bool is_step_count_supported;
    /**< Value indicating Step Count Supported feature */
    bool is_resistance_level_supported;
    /**< Value indicating Resistance Level Supported feature */
    bool is_stride_count_supported;
    /**< Value indicating Stride Count Supported feature */
    bool is_expended_energy_supported;
    /**< Value indicating Expended Energy Supported feature */
    bool is_heart_rate_measurement_supported;
    /**< Value indicating Heart Rate Measurement Supported feature */
    bool is_metabolic_equivalent_supported;
    /**< Value indicating Metabolic Equivalent Supported feature */
    bool is_elapsed_time_supported;
    /**< Value indicating Elapsed Time Supported feature */
    bool is_remaining_time_supported;
    /**< Value indicating Remaining Time Supported feature */
    bool is_power_measurement_supported;
    /**< Value indicating Power Measurement Supported feature */
    bool is_force_on_belt_and_power_output_supported;
    /**< Value indicating Force on Belt and Power Output Supported feature */
    bool is_user_data_retention_supported;
    /**< Value indicating User Data Retention Supported feature */
    bool is_speed_target_setting_supported;
    /**< Value indicating Speed Target Setting Supported feature */
    bool is_inclination_target_setting_supported;
    /**< Value indicating Inclination Target Setting Supported feature */
    bool is_resistance_target_setting_supported;
    /**< Value indicating Resistance Target Setting Supported feature */
    bool is_power_target_setting_supported;
    /**< Value indicating Power Target Setting Supported feature */
    bool is_heart_rate_target_setting_supported;
    /**< Value indicating Heart Rate Target Setting Supported feature */
    bool is_targeted_expended_energy_configuration_supported;
    /**< Value indicating Targeted Expended Energy Configuration Supported feature */
    bool is_targeted_step_number_configuration_supported;
    /**< Value indicating Targeted Step Number Configuration Supported feature */
    bool is_targeted_stride_number_configuration_supported;
    /**< Value indicating Targeted Stride Number Configuration Supported feature */
    bool is_targeted_distance_configuration_supported;
    /**< Value indicating Targeted Distance Configuration Supported feature */
    bool is_targeted_training_time_configuration_supported;
    /**< Value indicating Targeted Training Time Configuration Supported feature */
    bool is_targeted_time_in_two_heart_rate_zones_configuration_supported;
    /**< Value indicating Targeted Time in Two Heart Rate Zones Configuration Supported feature */
    bool is_targeted_time_in_three_heart_rate_zones_configuration_supported;
    /**< Value indicating Targeted Time in Three Heart Rate Zones Configuration Supported feature */
    bool is_targeted_time_in_five_heart_rate_zones_configuration_supported;
    /**< Value indicating Targeted Time in Five Heart Rate Zones Configuration Supported feature */
    bool is_indoor_bike_simulation_parameters_supported;
    /**< Value indicating Indoor Bike Simulation Parameters Supported feature */
    bool is_wheel_circumference_configuration_supported;
    /**< Value indicating Wheel Circumference Configuration Supported feature */
    bool is_spin_down_control_supported;
    /**< Value indicating Spin Down Control Supported feature */
    bool is_targeted_cadence_configuration_supported;
    /**< Value indicating Targeted Cadence Configuration Supported feature */
} st_ble_ftmc_fitness_machine_feature_t;

/*******************************************************************************************************************//**
 * @brief Treadmill Data characteristic parameters.
***********************************************************************************************************************/
typedef struct 
{
    bool is_more_data_present;                          /**< More Data Present boolean value */
    bool is_average_speed_present;                      /**< Average Speed Present boolean value */
    bool is_total_distance_present;                     /**< Total Distance Present boolean value */
    bool is_inclination_and_ramp_angle_setting_present; 
    /**< Inclination and Ramp-angle setting present boolean value */ 
    bool is_elevation_gain_present;                     /**< Elevation Gain Present boolean value */
    bool is_instantaneous_pace_present;                 /**< Instantaneous Pace Present boolean value */
    bool is_average_pace_present;                       /**< Average Pace Present boolean value */
    bool is_expended_energy_present;                    /**< Expended Energy Present boolean value */
    bool is_heart_rate_present;                         /**< Heart Rate Present boolean value */
    bool is_metabolic_equivalent_present;               /**< Metablolic Equivalent Present boolean value */
    bool is_elapsed_time_present;                       /**< Elapsed Time Present boolean value */
    bool is_remaining_time_present;                     /**< Remaining Time Present boolean value */
    bool is_force_on_belt_and_power_output_present;     
    /**< Force on Belt and Power Output Present boolean value */
    uint16_t instantaneous_speed;                       /**< Instantaneous Speed value */
    uint16_t average_speed;                             /**< Average Speed value */
    uint32_t total_distance;                            /**< Total Distance value */
    int16_t  inclination;                               /**< Inclination value */
    int16_t  ramp_angle_setting;                        /**< Ramp Angle Setting value */
    uint16_t positive_elevation_gain;                   /**< Positive Elevation Gain value */
    uint16_t negative_elevation_gain;                   /**< Negative Elevation Gain value */
    uint8_t  instantaneous_pace;                        /**< Instantaneous Pace value */
    uint8_t  average_pace;                              /**< Average Pace value */
    uint16_t total_energy;                              /**< Total Energy value */
    uint16_t energy_per_hour;                           /**< Energy Per Hour value */
    uint8_t  energy_per_minute;                         /**< Energy Per Minute value */
    uint8_t  heart_rate;                                /**< Heart Rate value */
    uint8_t  metabolic_equivalent;                      /**< Metabolic Equivalent value */
    uint16_t elapsed_time;                              /**< Elapsed Time value */
    uint16_t remaining_time;                            /**< Remaining Time value */
    int16_t  force_on_belt;                             /**< Force on Belt value */
    int16_t  power_output;                              /**< Power Output value */
} st_ble_ftmc_treadmill_data_t;

/*******************************************************************************************************************//**
 * @brief Cross Trainer Data characteristic parameters.
***********************************************************************************************************************/
typedef struct 
{
    bool is_more_data_present;                          /**< More Data Present boolean value */
    bool is_average_speed_present;                      /**< Average Speed Present boolean value */
    bool is_total_distance_present;                     /**< Total Distance Present boolean value */
    bool is_step_count_present;                         /**< Step Count Present boolean value */
    bool is_stride_count_present;                       /**< Stride Count Present boolean value */
    bool is_elevation_gain_present;                     /**< Elevation Gain Present boolean value */
    bool is_inclination_and_ramp_angle_setting_present; 
    /**< Inclination and Ramp-angle setting present boolean value */ 
    bool is_resistance_level_present;                   /**< Resistance Level Present boolean value */
    bool is_instantaneous_power_present;                /**< Instantaneous Power Present boolean value */
    bool is_average_power_present;                      /**< Average Power Present boolean value */
    bool is_expended_energy_present;                    /**< Expended Energy Present boolean value */
    bool is_heart_rate_present;                         /**< Heart Rate Present boolean value */
    bool is_metabolic_equivalent_present;               /**< Metablolic Equivalent Present boolean value */
    bool is_elapsed_time_present;                       /**< Elapsed Time Present boolean value */
    bool is_remaining_time_present;                     /**< Remaining Time Present boolean value */
    bool is_movement_direction_present;                 /**< Movement Direction Present boolean value */
    uint16_t instantaneous_speed;                       /**< Instantaneous Speed value */
    uint16_t average_speed;                             /**< Average Speed value */
    uint32_t total_distance;                            /**< Total Distance value */
    uint16_t step_per_minute;                           /**< Step Per Minute value */
    uint16_t average_step_rate;                         /**< Average Step Rate value */
    uint16_t stride_count;                              /**< Stride Count value */
    uint16_t positive_elevation_gain;                   /**< Positive Elevation Gain value */
    uint16_t negative_elevation_gain;                   /**< Negative Elevation Gain value */
    int16_t  inclination;                               /**< Inclination value */
    int16_t  ramp_angle_setting;                        /**< Ramp Angle Setting value */
    int16_t  resistance_level;                          /**< Resistance Level value */
    int16_t  instantaneous_power;                       /**< Instantaneous Power value */
    int16_t  average_power;                             /**< Average Power value */
    uint16_t total_energy;                              /**< Total Energy value */
    uint16_t energy_per_hour;                           /**< Energy Per Hour value */
    uint8_t  energy_per_minute;                         /**< Energy Per Minute value */
    uint8_t  heart_rate;                                /**< Heart Rate value */
    uint8_t  metabolic_equivalent;                      /**< Metabolic Equivalent value */
    uint16_t elapsed_time;                              /**< Elapsed Time value */
    uint16_t remaining_time;                            /**< Remaining Time value */
} st_ble_ftmc_cross_trainer_data_t;

/*******************************************************************************************************************//**
 * @brief Step Climber Data characteristic parameters.
***********************************************************************************************************************/
typedef struct 
{
    bool is_more_data_present;                          /**< More Data Present boolean value */
    bool is_step_per_minute_present;                    /**< Step Per Minute Present boolean value */
    bool is_average_step_rate_present;                  /**< Average Step Rate Present boolean value */
    bool is_positive_elevation_gain_present;            /**< Positive Elevation Gain Present boolean value */
    bool is_expended_energy_present;                    /**< Expended Energy Present boolean value */
    bool is_heart_rate_present;                         /**< Heart Rate Present boolean value */
    bool is_metabolic_equivalent_present;               /**< Metablolic Equivalent Present boolean value */
    bool is_elapsed_time_present;                       /**< Elapsed Time Present boolean value */
    bool is_remaining_time_present;                     /**< Remaining Time Present boolean value */
    uint16_t floors;                                    /**< Floors value */
    uint16_t step_count;                                /**< Step Count value */
    uint16_t step_per_minute;                           /**< Step Per Minute value */
    uint16_t average_step_rate;                         /**< Average Step Rate value */
    uint16_t positive_elevation_gain;                   /**< Positive Elevation Gain value */
    uint16_t total_energy;                              /**< Total Energy value */
    uint16_t energy_per_hour;                           /**< Energy Per Hour value */
    uint8_t  energy_per_minute;                         /**< Energy Per Minute value */
    uint8_t  heart_rate;                                /**< Heart Rate value */
    uint8_t  metabolic_equivalent;                      /**< Metabolic Equivalent value */
    uint16_t elapsed_time;                              /**< Elapsed Time value */
    uint16_t remaining_time;                            /**< Remaining Time value */
} st_ble_ftmc_step_climber_data_t;

/*******************************************************************************************************************//**
 * @brief Stair Climber Data characteristic parameters.
***********************************************************************************************************************/
typedef struct 
{
    bool is_more_data_present;                 /**< More Data Present boolean value */
    bool is_step_per_minute_present;           /**< Step Per Minute Present boolean value */
    bool is_average_step_rate_present;         /**< Average Step Rate Present boolean value */
    bool is_positive_elevation_gain_present;   /**< Positive Elevation Gain Present boolean value */
    bool is_stride_count_present;              /**< Stride Count Present boolean value */
    bool is_expended_energy_present;           /**< Expended Energy Present boolean value */
    bool is_heart_rate_present;                /**< Heart Rate Present boolean value */
    bool is_metabolic_equivalent_present;      /**< Metablolic Equivalent Present boolean value */
    bool is_elapsed_time_present;              /**< Elapsed Time Present boolean value */
    bool is_remaining_time_present;            /**< Remaining Time Present boolean value */
    uint16_t floors;                           /**< Floors value */
    uint16_t step_per_minute;                  /**< Step Per Minute value */
    uint16_t average_step_rate;                /**< Average Step Rate value */
    uint16_t positive_elevation_gain;          /**< Positive Elevation Gain value */
    uint16_t stride_count;                     /**< Stride Count value */
    uint16_t total_energy;                     /**< Total Energy value */
    uint16_t energy_per_hour;                  /**< Energy Per Hour value */
    uint8_t  energy_per_minute;                /**< Energy Per Minute value */
    uint8_t  heart_rate;                       /**< Heart Rate value */
    uint8_t  metabolic_equivalent;             /**< Metabolic Equivalent value */
    uint16_t elapsed_time;                     /**< Elapsed Time value */
    uint16_t remaining_time;                   /**< Remaining Time value */
} st_ble_ftmc_stair_climber_data_t;

/*******************************************************************************************************************//**
 * @brief Rower Data characteristic parameters.
***********************************************************************************************************************/
typedef struct 
{
    bool is_more_data_present;            /**< More Data Present boolean value */
    bool is_average_stroke_rate_present;  /**< Average Stroke Present boolean value */
    bool is_total_distance_present;       /**< Total Distance Present boolean value */
    bool is_instantaneous_pace_present;   /**< Instantaneous Pace Present boolean value */
    bool is_average_pace_present;         /**< Average Pace Present boolean value */
    bool is_instantaneous_power_present;  /**< Instantaneous Power Present boolean value */
    bool is_average_power_present;        /**< Average Power Present boolean value */
    bool is_resistance_level_present;     /**< Resistance Level Present boolean value */
    bool is_expended_energy_present;      /**< Expended Energy Present boolean value */
    bool is_heart_rate_present;           /**< Heart Rate Present boolean value */
    bool is_metabolic_equivalent_present; /**< Metablolic Equivalent Present boolean value */
    bool is_elapsed_time_present;         /**< Elapsed Time Present boolean value */
    bool is_remaining_time_present;       /**< Remaining Time Present boolean value */
    uint8_t  stroke_rate;                 /**< Stroke Rate value */
    uint16_t stroke_count;                /**< Stroke Count value */
    uint8_t  average_stroke_rate;         /**< Average Stroke Rate value */
    uint32_t total_distance;              /**< Total Distance value */
    uint16_t instantaneous_pace;          /**< Instantaneous Pace value */
    uint16_t average_pace;                /**< Average Pace value */
    int16_t  instantaneous_power;         /**< Instantaneous Power value */
    int16_t  average_power;               /**< Average Power value */
    int16_t  resistance_level;            /**< Resistance Level value */
    uint16_t total_energy;                /**< Total Energy value */
    uint16_t energy_per_hour;             /**< Energy Per Hour value */
    uint8_t  energy_per_minute;           /**< Energy Per Minute value */
    uint8_t  heart_rate;                  /**< Heart Rate value */
    uint8_t  metabolic_equivalent;        /**< Metabolic Equivalent value */
    uint16_t elapsed_time;                /**< Elapsed Time value */
    uint16_t remaining_time;              /**< Remaining Time value */
} st_ble_ftmc_rower_data_t;

/*******************************************************************************************************************//**
 * @brief Indoor Bike Data characteristic parameters.
***********************************************************************************************************************/
typedef struct 
{
    bool is_more_data_present;             /**< More Data Present boolean value */
    bool is_average_speed_present;         /**< Average Speed Present boolean value */
    bool is_instantaneous_cadence_present; /**< Instantaneous Cadence Present boolean value */
    bool is_average_cadence_present;       /**< Average Cadence Present boolean value */
    bool is_total_distance_present;        /**< Total Present boolean value */
    bool is_resistance_level_present;      /**< Resistance Level Present boolean value */
    bool is_instantaneous_power_present;   /**< Instantaneous Power Present boolean value */
    bool is_average_power_present;         /**< Average Power Present boolean value */
    bool is_expended_energy_present;       /**< Expended Energy Present boolean value */
    bool is_heart_rate_present;            /**< Heart Rate Present boolean value */
    bool is_metabolic_equivalent_present;  /**< Metablolic Equivalent Present boolean value */
    bool is_elapsed_time_present;          /**< Elapsed Time Present boolean value */
    bool is_remaining_time_present;        /**< Remaining Time Present boolean value */
    uint16_t instantaneous_speed;          /**< Instantaneous Speed value */
    uint16_t average_speed;                /**< Average Speed value */
    uint16_t instantaneous_cadence;        /**< Instantaneous Cadence value */
    uint16_t average_cadence;              /**< Average Cadence value */
    uint32_t total_distance;               /**< Total Distance value */
    int16_t  resistance_level;             /**< Resistance Level value */
    int16_t  instantaneous_power;          /**< Instantaneous Power value */
    int16_t  average_power;                /**< Average Power value */
    uint16_t total_energy;                 /**< Total Energy value */
    uint16_t energy_per_hour;              /**< Energy Per Hour value */
    uint8_t  energy_per_minute;            /**< Energy Per Minute value */
    uint8_t  heart_rate;                   /**< Heart Rate value */
    uint8_t  metabolic_equivalent;         /**< Metabolic Equivalent value */
    uint16_t elapsed_time;                 /**< Elapsed Time value */
    uint16_t remaining_time;               /**< Remaining Time value */
} st_ble_ftmc_indoor_bike_data_t;

/*******************************************************************************************************************//**
 * @brief Training Status characteristic parameters.
***********************************************************************************************************************/
typedef struct 
{
    bool is_training_status_string_present;
    /**< Trianing Status String Present boolean value */
    bool is_extended_string_present;                                     /**< Extended String Present boolean value */
    uint8_t training_status;                                             /**< Training Status value */
    uint8_t training_status_string[BLE_FTMC_TRAINING_STATUS_STRING_LEN]; /**< Training Status String value */
} st_ble_ftmc_training_status_t;

/*******************************************************************************************************************//**
 * @brief Supported Speed Range characteristic parameters.
***********************************************************************************************************************/
typedef struct 
{
    uint16_t minimum_speed;                          /**< Minimum Speed value */
    uint16_t maximum_speed;                          /**< Maximum Speed value */
    uint16_t minimum_increment;                      /**< Minimum Increment value */
} st_ble_ftmc_supported_speed_range_t;

/*******************************************************************************************************************//**
 * @brief Supported Inclination Range characteristic parameters.
***********************************************************************************************************************/
typedef struct 
{
    int16_t minimum_inclination;                     /**< Minimum Inclination value */
    int16_t maximum_inclination;                     /**< Maximum Inclination value */
    uint16_t minimum_increment;                      /**< Minimum Increment value */
} st_ble_ftmc_supported_inclination_range_t;

/*******************************************************************************************************************//**
 * @brief Supported Resistance Level Range characteristic parameters.
***********************************************************************************************************************/
typedef struct 
{
    int16_t minimum_resistance_level;                /**< Minimum Resistance Level value */
    int16_t maximum_resistance_level;                /**< Maximum Resistance Level value */
    uint16_t minimum_increment;                      /**< Minimum Increment value */
} st_ble_ftmc_supported_resistance_level_range_t;

/*******************************************************************************************************************//**
 * @brief Supported Power Range characteristic parameters.
***********************************************************************************************************************/
typedef struct 
{
    int16_t minimum_power;                           /**< Minimum Power value */
    int16_t maximum_power;                           /**< Maximum Power value */
    uint16_t minimum_increment;                      /**< Minimum Increment value */
} st_ble_ftmc_supported_power_range_t;

/*******************************************************************************************************************//**
 * @brief Supported Heart Rate Range characteristic parameters.
***********************************************************************************************************************/
typedef struct 
{
    uint8_t minimum_heart_rate;                      /**< Minimum Heart Rate value */
    uint8_t maximum_heart_rate;                      /**< Maximum Heart Rate value */
    uint8_t minimum_increment;                       /**< Minimum Increment value */
} st_ble_ftmc_supported_heart_rate_range_t;

/*******************************************************************************************************************//**
 * @brief Fitness Machine Control Point characteristic parameters.
***********************************************************************************************************************/
typedef struct 
{
    uint8_t  op_code;                               /**< Op Code value */
    uint16_t target_speed;                          /**< Target Speed value */
    int16_t  target_inclination;                    /**< Target Inclination value */
    uint8_t  target_resistance_level;               /**< Target Resistance Level value */
    int16_t  target_power;                          /**< Target Power value */
    uint8_t  target_heart_rate;                     /**< Target Heart Rate value */
    uint8_t  control_information;                   /**< Control Information value */
    uint16_t targeted_expended_energy;              /**< Targeted Expended Energy value */
    uint16_t targeted_number_of_steps;              /**< Targeted Number of Steps value */
    uint16_t targeted_number_of_strides;            /**< Targeted Number of Strides value */
    uint32_t targeted_distance;                     /**< Targeted Distance value */
    uint16_t targeted_training_time;                /**< Targeted Training Time value */
    uint16_t targeted_time_in_fat_burn_zone;        /**< Targeted Time in Fat Burn Zone value */
    uint16_t targeted_time_in_fitness_zone;         /**< Targeted Time in Fitness Zone value */
    uint16_t targeted_time_in_light_zone;           /**< Targeted Time in Light Zone value */
    uint16_t targeted_time_in_moderate_zone;        /**< Targeted Time in Moderate Zone value */
    uint16_t targeted_time_in_hard_zone;            /**< Targeted Time in Hard Zone value */
    uint16_t five_zone_time_in_very_light_zone;     /**< Five Zone Time in Very Light Zone value */
    uint16_t five_zone_time_in_light_zone;          /**< Five Zone Time in Light Zone value */
    uint16_t five_zone_time_in_moderate_zone;       /**< Five Zone Time in Moderate Zone value */
    uint16_t five_zone_time_in_hard_zone;           /**< Five Zone Time in Hard Zone value */
    uint16_t five_zone_time_in_maximum_zone;        /**< Five Zone Time in Maximum Zone value */
    int16_t  wind_speed;                            /**< Wind Speed value */
    int16_t  grade;                                 /**< Grade value */
    uint8_t  coefficient_of_rolling_resistance;     /**< Coefficient of Rolling Resistance value */
    uint8_t  wind_resistance_coefficient;           /**< Wind Resistance Coefficient value */
    uint16_t wheel_circumference;                   /**< Wheel Circumference value */
    uint8_t  control_parameter;                     /**< Control Parameter value */
    uint16_t targeted_cadence;                      /**< Targeted Cadence value */
    uint8_t  response_code;                         /**< Response Code value */
    uint8_t  request_op_code;                       /**< Request Op Code value */
    uint8_t  result_code;                           /**< Result Code value */
    uint16_t target_speed_low;                      /**< Target Speed Low value */
    uint16_t target_speed_high;                     /**< Target Speed High value */
} st_ble_ftmc_fitness_machine_control_point_t;

/*******************************************************************************************************************//**
 * @brief Fitness Machine Status characteristic parameters.
***********************************************************************************************************************/
typedef struct 
{
    uint8_t  op_code;                                 /**< Op Code value */
    uint8_t  control_information;                     /**< Control Information value */
    uint16_t new_target_speed;                        /**< New Target Speed value */
    int16_t  new_target_inclination;                  /**< New Target Inclination value */
    uint8_t  new_target_resistance_level;             /**< New Target Resistance Level value */
    int16_t  new_target_power;                        /**< New Target Power value */
    uint8_t  new_target_heart_rate;                   /**< New Target Heart Rate value */
    uint16_t new_targeted_expended_energy;            /**< New Targeted Expended Energy value */
    uint16_t new_targeted_number_of_steps;            /**< New Targeted Number of Steps value */
    uint16_t new_targeted_number_of_strides;          /**< New Targeted Number of Strides value */
    uint32_t new_targeted_distance;                   /**< New Targeted Distance value */
    uint16_t new_targeted_training_time;              /**< New Targeted Training Time value */
    uint16_t new_targeted_time_in_fat_burn_zone;      /**< New Targeted Time in Fat Burn Zone value */
    uint16_t new_targeted_time_in_fitness_zone;       /**< New Targeted Time in Fitness Zone value */
    uint16_t new_targeted_time_in_light_zone;         /**< New Targeted Time in Light Zone value */
    uint16_t new_targeted_time_in_moderate_zone;      /**< New Targeted Time in Moderate Zone value */
    uint16_t new_targeted_time_in_hard_zone;          /**< New Targeted Time in Hard Zone value */
    uint16_t new_five_zone_time_in_very_light_zone;   /**< New Five Zone Time in Very Light Zone value */
    uint16_t new_five_zone_time_in_light_zone;        /**< New Five Zone Time in Light Zone value */
    uint16_t new_five_zone_time_in_moderate_zone;     /**< New Five Zone Time in Moderate Zone value */
    uint16_t new_five_zone_time_in_hard_zone;         /**< New Five Zone Time in Hard Zone value */
    uint16_t new_five_zone_time_in_maximum_zone;      /**< New Five Zone Time in Maximum Zone value */
    int16_t  new_wind_speed;                          /**< New Wind Speed value */
    int16_t  new_grade;                               /**< New Grade value */
    uint8_t  new_coefficient_of_rolling_resistance;   /**< New Coefficient of Rolling Resistance value */
    uint8_t  new_wind_resistance_coefficient;         /**< New Wind Resistance Coefficient value */
    uint16_t new_wheel_circumference;                 /**< New Wheel Circumference value */
    uint8_t  spin_down_status;                        /**< Spin Down Status value */
    uint16_t new_targeted_cadence;                    /**< New Targeted Cadence value */
} st_ble_ftmc_fitness_machine_status_t;

/***********************************************************************************************************************
Exported global variables (to be accessed by other files)
***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @brief Fitness Machine Service UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_FTMC_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Fitness Machine Feature characteristic UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_FTMC_FITNESS_MACHINE_FEATURE_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Treadmill Data characteristic UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_FTMC_TREADMILL_DATA_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Cross Trainer Data characteristic UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_FTMC_CROSS_TRAINER_DATA_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Step Climber Data characteristic UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_FTMC_STEP_CLIMBER_DATA_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Stair Climber Data characteristic UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_FTMC_STAIR_CLIMBER_DATA_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Rower Data characteristic UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_FTMC_ROWER_DATA_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Indoor Bike Data characteristic UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_FTMC_INDOOR_BIKE_DATA_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Training Status characteristic UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_FTMC_TRAINING_STATUS_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Supported Speed Range characteristic UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_FTMC_SUPPORTED_SPEED_RANGE_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Supported Inclination Range characteristic UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_FTMC_SUPPORTED_INCLINATION_RANGE_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Supported Resistance Level Range characteristic UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_FTMC_SUPPORTED_RESISTANCE_LEVEL_RANGE_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Supported Power Range characteristic UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_FTMC_SUPPORTED_POWER_RANGE_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Supported Heart Rate Range characteristic UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_FTMC_SUPPORTED_HEART_RATE_RANGE_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Fitness Machine Control Point characteristic UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_FTMC_FITNESS_MACHINE_CONTROL_POINT_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Fitness Machine Status characteristic UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_FTMC_FITNESS_MACHINE_STATUS_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/***********************************************************************************************************************
Exported global functions (to be accessed by other files)
***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @brief     Initialize Fitness Machine Service  Client.
 * @details   This function shall be called once at startup.
 * @param[in] p_param Pointer to Fitness Machine Service Client initialization parameters.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_FTMC_Init(const st_ble_ftmc_init_param_t *p_param);

/*******************************************************************************************************************//**
 * @brief     Perform Fitness Machine Service Client connection settings.
 * @details   This function shall be called on each connection establishment.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_param  Pointer to Connection parameters.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_FTMC_Connect(uint16_t conn_hdl, const st_ble_ftmc_connect_param_t *p_param);

/*******************************************************************************************************************//**
 * @brief     Retrieve Fitness Machine Service Client connection specific settings before disconnection.
 * @details   This function shall be called on each disconnection.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_param  Pointer to Disconnection parameters.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_FTMC_Disconnect(uint16_t conn_hdl, st_ble_ftmc_disconnect_param_t *p_param);

/*******************************************************************************************************************//**
 * @brief      Read Fitness Machine Feature characteristic value from remote GATT database.
 * @param[out] app_value Retrieved Fitness Machine Feature characteristic value.
 * @return     @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_FTMC_ReadFitnessMachineFeature(uint16_t conn_hdl);

/*******************************************************************************************************************//**
 * @brief     Set Treadmill Data characteristic cli cnfg.
 * @param[in] conn_hdl Connection handle.
 * @param[in] cli_cnfg Treadmill Data characteristic cli cnfg to set.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_FTMC_SetTreadmillDataCliCnfg(uint16_t conn_hdl, uint16_t cli_cnfg);

/*******************************************************************************************************************//**
 * @brief     Set Cross Trainer Data characteristic cli cnfg.
 * @param[in] conn_hdl Connection handle.
 * @param[in] cli_cnfg Cross Trainer Data characteristic cli cnfg to set.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_FTMC_SetCrossTrainerDataCliCnfg(uint16_t conn_hdl, uint16_t cli_cnfg);

/*******************************************************************************************************************//**
 * @brief     Set Step Climber Data characteristic cli cnfg.
 * @param[in] conn_hdl Connection handle.
 * @param[in] cli_cnfg Step Climber Data characteristic cli cnfg to set.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_FTMC_SetStepClimberDataCliCnfg(uint16_t conn_hdl, uint16_t cli_cnfg);

/*******************************************************************************************************************//**
 * @brief     Set Stair Climber Data characteristic cli cnfg.
 * @param[in] conn_hdl Connection handle.
 * @param[in] cli_cnfg Stair Climber Data characteristic cli cnfg to set.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_FTMC_SetStairClimberDataCliCnfg(uint16_t conn_hdl, uint16_t cli_cnfg);

/*******************************************************************************************************************//**
 * @brief     Set Rower Data characteristic cli cnfg.
 * @param[in] conn_hdl Connection handle.
 * @param[in] cli_cnfg Rower Data characteristic cli cnfg to set.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_FTMC_SetRowerDataCliCnfg(uint16_t conn_hdl, uint16_t cli_cnfg);

/*******************************************************************************************************************//**
 * @brief     Set Indoor Bike Data characteristic cli cnfg.
 * @param[in] conn_hdl Connection handle.
 * @param[in] cli_cnfg Indoor Bike Data characteristic cli cnfg to set.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_FTMC_SetIndoorBikeDataCliCnfg(uint16_t conn_hdl, uint16_t cli_cnfg);

/*******************************************************************************************************************//**
 * @brief      Read Training Status characteristic value from remote GATT database.
 * @param[out] app_value Retrieved Training Status characteristic value.
 * @return     @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_FTMC_ReadTrainingStatus(uint16_t conn_hdl);

/*******************************************************************************************************************//**
 * @brief     Set Training Status characteristic cli cnfg.
 * @param[in] conn_hdl Connection handle.
 * @param[in] cli_cnfg Training Status characteristic cli cnfg to set.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_FTMC_SetTrainingStatusCliCnfg(uint16_t conn_hdl, uint16_t cli_cnfg);

/*******************************************************************************************************************//**
 * @brief      Read Supported Speed Range characteristic value from remote GATT database.
 * @param[out] app_value Retrieved Supported Speed Range characteristic value.
 * @return     @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_FTMC_ReadSupportedSpeedRange(uint16_t conn_hdl);

/*******************************************************************************************************************//**
 * @brief      Read Supported Inclination Range characteristic value from remote GATT database.
 * @param[out] app_value Retrieved Supported Inclination Range characteristic value.
 * @return     @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_FTMC_ReadSupportedInclinationRange(uint16_t conn_hdl);

/*******************************************************************************************************************//**
 * @brief      Read Supported Resistance Level Range characteristic value from remote GATT database.
 * @param[out] app_value Retrieved Supported Resistance Level Range characteristic value.
 * @return     @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_FTMC_ReadSupportedResistanceLevelRange(uint16_t conn_hdl);

/*******************************************************************************************************************//**
 * @brief      Read Supported Power Range characteristic value from remote GATT database.
 * @param[out] app_value Retrieved Supported Power Range characteristic value.
 * @return     @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_FTMC_ReadSupportedPowerRange(uint16_t conn_hdl);

/*******************************************************************************************************************//**
 * @brief      Read Supported Heart Rate Range characteristic value from remote GATT database.
 * @param[out] app_value Retrieved Supported Heart Rate Range characteristic value.
 * @return     @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_FTMC_ReadSupportedHeartRateRange(uint16_t conn_hdl);

/*******************************************************************************************************************//**
 * @brief     Write Fitness Machine Control Point characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] p_app_value Pointer to Fitness Machine Control Point characteristic value to write.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_FTMC_WriteFitnessMachineControlPoint(uint16_t conn_hdl, const st_ble_ftmc_fitness_machine_control_point_t *p_app_value);

/*******************************************************************************************************************//**
 * @brief     Set Fitness Machine Control Point characteristic cli cnfg.
 * @param[in] conn_hdl Connection handle.
 * @param[in] cli_cnfg Fitness Machine Control Point characteristic cli cnfg to set.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_FTMC_SetFitnessMachineControlPointCliCnfg(uint16_t conn_hdl, uint16_t cli_cnfg);

/*******************************************************************************************************************//**
 * @brief     Set Fitness Machine Status characteristic cli cnfg.
 * @param[in] conn_hdl Connection handle.
 * @param[in] cli_cnfg Fitness Machine Status characteristic cli cnfg to set.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_FTMC_SetFitnessMachineStatusCliCnfg(uint16_t conn_hdl, uint16_t cli_cnfg);

/***********************************************************************************************************************
 * @brief      Callback function for the Fitness Machine Discovery events.
 * @param[out] conn_hdl Connection handle.
 * @param[out] idx      Service index used to distiguish the multiple same UUID service.
 * @param[out] type     Discovery event type
 * @param[out] p_param   Pointer to GATTC event data.
***********************************************************************************************************************/
void R_BLE_FTMC_ServDiscCb(uint16_t conn_hdl, uint8_t idx, uint16_t type, void *p_param);

/*******************************************************************************************************************//**
 * @brief     Return version of the FTMC service client.
 * @return    version
***********************************************************************************************************************/
uint32_t R_BLE_FTMC_GetVersion(void);

#endif /* R_BLE_FTMC_H */

/** @} */
