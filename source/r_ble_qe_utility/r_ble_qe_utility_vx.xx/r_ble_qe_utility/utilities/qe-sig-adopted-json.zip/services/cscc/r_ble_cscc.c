/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_cscc.c
 * Version : 1.0
 * Description : The source file for Cycling Speed and Cadence Service client.
 **********************************************************************************************************************/
 /************************************************************************************************************************//**
 * History : DD.MM.YYYY Version Description
 *         : 20.12.2019 1.00 First Release
 ***********************************************************************************************************************/
#include "r_ble_cscc.h"
#include "profile_cmn/r_ble_servc_if.h"
#include <string.h>

/***********************************************************************************************************************
 Macro definitions
 ***********************************************************************************************************************/
#ifndef UNUSED_ARG
#define UNUSED_ARG(arg)         (void)(arg)
#endif /* UNUSED_ARG */

 /* Version number */
#define BLE_CSCC_PRV_VERSION_MAJOR                                                                    (1)
#define BLE_CSCC_PRV_VERSION_MINOR                                                                    (0)

/*******************************************************************************************************************//**
 * @brief CSC Measurement characteristic value length.
***********************************************************************************************************************/
#define BLE_CSCC_PRV_CSC_MEASUREMENT_LEN                                                              (11)
/*******************************************************************************************************************//**
 * @brief CSC Feature characteristic value length.
***********************************************************************************************************************/
#define BLE_CSCC_PRV_CSC_FEATURE_LEN                                                                  (2)
/*******************************************************************************************************************//**
 * @brief Sensor Location characteristic value length.
***********************************************************************************************************************/
#define BLE_CSCC_PRV_SENSOR_LOCATION_LEN                                                              (1)
/*******************************************************************************************************************//**
 * @brief SC Control Point characteristic value length.
***********************************************************************************************************************/
#define BLE_CSCC_PRV_SC_CONTROL_POINT_LEN                                                             (20)
/*******************************************************************************************************************//**
 * @brief Wheel Revolution Data Present bit.
 ***********************************************************************************************************************/
#define BLE_CSCC_PRV_CSC_MEASUREMENT_FLAGS_WHEEL_REVOLUTION_DATA_PRESENT                              (1 << 0)

 /*******************************************************************************************************************//**
 * @brief Crank Revolution Data Present bit.
  ***********************************************************************************************************************/
#define BLE_CSCC_PRV_CSC_MEASUREMENT_FLAGS_CRANK_REVOLUTION_DATA_PRESENT                              (1 << 1)

/*******************************************************************************************************************//**
 * @brief Wheel Revolution Data Supported bit.
***********************************************************************************************************************/
#define BLE_CSCC_PRV_CSC_FEATURE_WHEEL_REVOLUTION_DATA_SUPPORTED                                      (1 << 0)

/*******************************************************************************************************************//**
 * @brief Crank Revolution Data Supported bit.
***********************************************************************************************************************/
#define BLE_CSCC_PRV_CSC_FEATURE_CRANK_REVOLUTION_DATA_SUPPORTED                                      (1 << 1)

/*******************************************************************************************************************//**
 * @brief Multiple Sensor Locations Supported bit.
***********************************************************************************************************************/
#define BLE_CSCC_PRV_CSC_FEATURE_MULTIPLE_SENSOR_LOCATIONS_SUPPORTED                                  (1 << 2)

static st_ble_servc_info_t gs_client_info;

/*----------------------------------------------------------------------------------------------------------------------
    CSC Measurement Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* CSC Measurement characteristic descriptors attribute handles */
static uint16_t gs_csc_meas_cli_cnfg_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_csc_measurement_cli_cnfg =
{
    .uuid_16     = BLE_CSCC_CSC_MEASUREMENT_CLI_CNFG_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint16_t),
    .db_size     = BLE_CSCC_CSC_MEASUREMENT_CLI_CNFG_LEN,
    .desc_idx    = BLE_CSCC_CSC_MEASUREMENT_CLI_CNFG_IDX,
    .p_attr_hdls = gs_csc_meas_cli_cnfg_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_CSCC_WriteCsc_measCliCnfg(uint16_t conn_hdl, const uint16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_csc_measurement_cli_cnfg, conn_hdl, p_value);
}

ble_status_t R_BLE_CSCC_ReadCsc_measCliCnfg(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_csc_measurement_cli_cnfg, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    CSC Measurement Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* CSC Measurement characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_csc_measurement_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************
 * Function Name: decode_csc_measurement
 * Description  : This function converts CSC Measurement characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the CSC Measurement value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_cscc_csc_meas_t(st_ble_cscc_csc_measurement_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t      pos = 1;

    if (BLE_CSCC_PRV_CSC_MEASUREMENT_LEN < p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Clear the data structure */
    memset(p_app_value, 0x00, sizeof(st_ble_cscc_csc_measurement_t));

    if ((p_gatt_value->p_value[0] & BLE_CSCC_PRV_CSC_MEASUREMENT_FLAGS_WHEEL_REVOLUTION_DATA_PRESENT))
    {
        p_app_value->is_wheel_rev_data_present = true;
        BT_UNPACK_LE_4_BYTE(&p_app_value->cumulative_wheel_revolutions, &p_gatt_value->p_value[pos]);
        pos += 4;

        BT_UNPACK_LE_2_BYTE(&p_app_value->last_wheel_event_time, &p_gatt_value->p_value[pos]);
        pos += 2;
    }
    else
    {
        p_app_value->is_wheel_rev_data_present = false;
    }

    if ((p_gatt_value->p_value[0] & BLE_CSCC_PRV_CSC_MEASUREMENT_FLAGS_CRANK_REVOLUTION_DATA_PRESENT))
    {
        p_app_value->is_crank_rev_data_present = true;
        BT_UNPACK_LE_2_BYTE(&p_app_value->cumulative_crank_revolutions, &p_gatt_value->p_value[pos]);
        pos += 2;

        BT_UNPACK_LE_2_BYTE(&p_app_value->last_crank_event_time, &p_gatt_value->p_value[pos]);
        pos += 2;
    }
    else
    {
        p_app_value->is_crank_rev_data_present = false;
    }

    return BLE_SUCCESS;
}

/***********************************************************************************************************************//**
* Function Name: encode_st_ble_cscc_csc_measurement_t
* Description  : This function converts CSC Measurement characteristic value representation in
*                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
* Arguments    : p_app_value - pointer to the CGM Measurement  value in the application layer
*                p_gatt_value - pointer to the characteristic value in the GATT database
* Return Value : ble_status_t
**********************************************************************************************************************/
static ble_status_t encode_st_ble_cscc_csc_meas_t(const st_ble_cscc_csc_measurement_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    UNUSED_ARG(p_app_value);
    UNUSED_ARG(p_gatt_value);

    /* Do Nothing as flow is not hitting here */
    return BLE_SUCCESS;
}

/* CSC Measurement characteristic descriptor definition */
static const st_ble_servc_desc_info_t *gspp_csc_measurement_descs[] =
{
    &gs_csc_measurement_cli_cnfg,
};

/* CSC Measurement characteristic definition */
const st_ble_servc_char_info_t gs_csc_measurement_char =
{
    .uuid_16      = BLE_CSCC_CSC_MEASUREMENT_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_cscc_csc_measurement_t),
    .db_size      = BLE_CSCC_CSC_MEASUREMENT_LEN,
    .char_idx     = BLE_CSCC_CSC_MEASUREMENT_IDX,
    .p_attr_hdls  = gs_csc_measurement_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_cscc_csc_meas_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_cscc_csc_meas_t,
    .num_of_descs = ARRAY_SIZE(gspp_csc_measurement_descs),
    .pp_descs     = gspp_csc_measurement_descs,
};

void R_BLE_CSCC_GetCsc_measurementAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_cscc_csc_meas_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx                 = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range             = gs_csc_measurement_char_ranges[conn_idx];
    p_hdl->cli_cnfg_desc_hdl = gs_csc_meas_cli_cnfg_desc_hdls[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    CSC Feature Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* CSC Feature characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_csc_feature_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************
 * Function Name: decode_csc_feature
 * Description  : This function converts CSC Feature characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the CSC Feature value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_cscc_csc_feat_t(st_ble_cscc_csc_feature_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint16_t csc_feature = 0;

    if (BLE_CSCC_PRV_CSC_FEATURE_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Clear the feature bit flags */
    memset(p_app_value, 0x00, sizeof(st_ble_cscc_csc_feature_t));

    BT_UNPACK_LE_2_BYTE(&csc_feature, p_gatt_value->p_value);

    if (csc_feature & BLE_CSCC_PRV_CSC_FEATURE_WHEEL_REVOLUTION_DATA_SUPPORTED)
    {
        p_app_value->is_wheel_rev_data_supported = true;
    }
    else
    {
        p_app_value->is_wheel_rev_data_supported = false;
    }

    if (csc_feature & BLE_CSCC_PRV_CSC_FEATURE_CRANK_REVOLUTION_DATA_SUPPORTED)
    {
        p_app_value->is_crank_rev_data_supported = true;
    }
    else
    {
        p_app_value->is_crank_rev_data_supported = false;
    }

    if (csc_feature & BLE_CSCC_PRV_CSC_FEATURE_MULTIPLE_SENSOR_LOCATIONS_SUPPORTED)
    {
        p_app_value->is_multiple_sen_loc_supported = true;
    }
    else
    {
        p_app_value->is_multiple_sen_loc_supported = false;
    }

    return BLE_SUCCESS;
}

/***********************************************************************************************************************//**
* Function Name: encode_st_ble_cscc_csc_feature_t
* Description  : This function converts CSC Measurement characteristic value representation in
*                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
* Arguments    : p_app_value - pointer to the CGM Measurement  value in the application layer
*                p_gatt_value - pointer to the characteristic value in the GATT database
* Return Value : ble_status_t
**********************************************************************************************************************/
static ble_status_t encode_st_ble_cscc_csc_feat_t(const st_ble_cscc_csc_feature_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    UNUSED_ARG(p_app_value);
    UNUSED_ARG(p_gatt_value);

    /* Do Nothing as flow is not hitting here */
    return BLE_SUCCESS;
}

/* CSC Feature characteristic definition */
const st_ble_servc_char_info_t gs_csc_feature_char =
{
    .uuid_16      = BLE_CSCC_CSC_FEATURE_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_cscc_csc_feature_t),
    .db_size      = BLE_CSCC_CSC_FEATURE_LEN,
    .char_idx     = BLE_CSCC_CSC_FEATURE_IDX,
    .p_attr_hdls  = gs_csc_feature_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_cscc_csc_feat_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_cscc_csc_feat_t,
};

ble_status_t R_BLE_CSCC_ReadCsc_feature(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_csc_feature_char, conn_hdl);
}

void R_BLE_CSCC_GetCsc_featureAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_cscc_csc_feat_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx     = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_csc_feature_char_ranges[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Sensor Location Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Sensor Location characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_sensor_location_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

/* Sensor Location characteristic definition */
static const st_ble_servc_char_info_t gs_sensor_location_char =
{
    .uuid_16      = BLE_CSCC_SENSOR_LOCATION_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(uint8_t),
    .db_size      = BLE_CSCC_SENSOR_LOCATION_LEN,
    .char_idx     = BLE_CSCC_SENSOR_LOCATION_IDX,
    .p_attr_hdls  = gs_sensor_location_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_uint8_t,
    .encode       = (ble_servc_attr_encode_t)encode_uint8_t,
};

ble_status_t R_BLE_CSCC_ReadSensor_location(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_sensor_location_char, conn_hdl);
}

void R_BLE_CSCC_GetSensor_locationAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_cscc_sen_loc_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx     = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_sensor_location_char_ranges[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    SC Control Point Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* SC Control Point characteristic descriptors attribute handles */
static uint16_t gs_sc_control_point_cli_cnfg_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_sc_control_point_cli_cnfg =
{
    .uuid_16     = BLE_CSCC_SC_CONTROL_POINT_CLI_CNFG_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint16_t),
    .db_size     = BLE_CSCC_SC_CONTROL_POINT_CLI_CNFG_LEN,
    .desc_idx    = BLE_CSCC_SC_CONTROL_POINT_CLI_CNFG_IDX,
    .p_attr_hdls = gs_sc_control_point_cli_cnfg_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_CSCC_WriteSc_control_pointCliCnfg(uint16_t conn_hdl, const uint16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_sc_control_point_cli_cnfg, conn_hdl, p_value);
}

ble_status_t R_BLE_CSCC_ReadSc_control_pointCliCnfg(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_sc_control_point_cli_cnfg, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    SC Control Point Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* SC Control Point characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_sc_control_point_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************
 * Function Name: decode_sc_control_point
 * Description  : This function converts SC Control Point characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the SC Control Point value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_cscc_sc_cp_t(st_ble_cscc_sc_control_point_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;
    uint8_t min_len = ((sizeof(p_app_value->response_code)) + (sizeof(p_app_value->request_op_code))
        + (sizeof(p_app_value->response_value)));

    if ((p_gatt_value->value_len > BLE_CSCC_PRV_SC_CONTROL_POINT_LEN) || (p_gatt_value->value_len < min_len))
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Clear the data structure */
    memset(p_app_value, 0x00, sizeof(st_ble_cscc_sc_control_point_t));

    /* Copy the response code, request opcode and the response value */
    BT_UNPACK_LE_1_BYTE(&p_app_value->response_code, &p_gatt_value->p_value[pos++]);
    BT_UNPACK_LE_1_BYTE(&p_app_value->request_op_code, &p_gatt_value->p_value[pos++]);
    BT_UNPACK_LE_1_BYTE(&p_app_value->response_value, &p_gatt_value->p_value[pos++]);

    /* Copy the response parameter if present */
    if ((BLE_CSCC_SC_CONTROL_POINT_OP_CODE_REQUEST_SUPPORTED_SENSOR_LOCATIONS == p_app_value->request_op_code)
        && (BLE_CSCC_SC_CONTROL_POINT_RESPONSE_VALUE_SUCCESS__RESPONSE_PARAMETER__NONE == p_app_value->response_value))
    {
        for (uint32_t i = pos; i < (p_gatt_value->value_len); i++)
        {
            p_app_value->response_parameter[i] = p_gatt_value->p_value[i];
        }

        p_app_value->no_of_supported_sen_loc = (uint8_t)(p_gatt_value->value_len - pos);
    }

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_sc_control_point
 * Description  : This function converts SC Control Point characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the SC Control Point  value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_cscc_sc_cp_t(const st_ble_cscc_sc_control_point_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    /* Copy the opcode */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->op_code);

    if (BLE_CSCC_SC_CONTROL_POINT_OP_CODE_SET_CUMULATIVE_VALUE == p_app_value->op_code)
    {
        /* copy the cumulative value */
        BT_PACK_LE_4_BYTE(&p_gatt_value->p_value[pos], &p_app_value->cumulative_value);
        pos += 4;
    }
    else if (BLE_CSCC_SC_CONTROL_POINT_OP_CODE_UPDATE_SENSOR_LOCATION == p_app_value->op_code)
    {
        /* Copy the sensor location value */
        BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->sensor_location_value);
    }
    else
    {
        /* Do nothing */
    }

    p_gatt_value->value_len = (uint16_t)pos;

    return BLE_SUCCESS;
}

/* SC Control Point characteristic descriptor definition */
static const st_ble_servc_desc_info_t *gspp_sc_control_point_descs[] = 
{
    &gs_sc_control_point_cli_cnfg,
};

/* SC Control Point characteristic definition */
static const st_ble_servc_char_info_t gs_sc_control_point_char =
{
    .uuid_16      = BLE_CSCC_SC_CONTROL_POINT_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_cscc_sc_control_point_t),
    .db_size      = BLE_CSCC_SC_CONTROL_POINT_LEN,
    .char_idx     = BLE_CSCC_SC_CONTROL_POINT_IDX,
    .p_attr_hdls  = gs_sc_control_point_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_cscc_sc_cp_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_cscc_sc_cp_t,
    .num_of_descs = ARRAY_SIZE(gspp_sc_control_point_descs),
    .pp_descs     = gspp_sc_control_point_descs,
};

ble_status_t R_BLE_CSCC_WriteSc_control_point(uint16_t conn_hdl, const st_ble_cscc_sc_control_point_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteChar(&gs_sc_control_point_char, conn_hdl, p_value);
}

void R_BLE_CSCC_GetSc_control_pointAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_cscc_sc_cp_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx                 = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range             = gs_sc_control_point_char_ranges[conn_idx];
    p_hdl->cli_cnfg_desc_hdl = gs_sc_control_point_cli_cnfg_desc_hdls[conn_idx];
}


/*----------------------------------------------------------------------------------------------------------------------
    Cycling Speed and Cadence Service client
----------------------------------------------------------------------------------------------------------------------*/

/* Cycling Speed and Cadence Service client attribute handles */
static st_ble_gatt_hdl_range_t gs_cscc_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

const st_ble_servc_char_info_t *gspp_cscc_chars[] =
{
    &gs_csc_measurement_char,
    &gs_csc_feature_char,
    &gs_sensor_location_char,
    &gs_sc_control_point_char,
};

static st_ble_servc_info_t gs_client_info =
{
    .pp_chars     = gspp_cscc_chars,
    .num_of_chars = ARRAY_SIZE(gspp_cscc_chars),
    .p_attr_hdls  = gs_cscc_ranges,
};

/***********************************************************************************************************************//**
* Function Name: R_BLE_CSCC_Init
* Description  : This function initializes the GATTS Server and CGM Service, registers the callback function for
*                GATTS.
* Arguments    : cb - cal back to the initialization parameters data
* Return Value : BLE_SUCCESS               - Success
*                BLE_ERR_INVALID_PTR       - The p_ntf_data parameter or the value field in the value field in
*                                            the p_ntf_data parameter is NULL.
*                BLE_ERR_INVALID_ARG       - The value_len field in the value field in the p_ntf_data parameter is 0
*                                            or the attr_hdl field in the p_ntf_data parameters is 0.
**********************************************************************************************************************/
ble_status_t R_BLE_CSCC_Init(ble_servc_app_cb_t cb) // @suppress("API function naming")
{
    if (NULL == cb)
    {
        return BLE_ERR_INVALID_PTR;
    }

    gs_client_info.cb = cb;

    return R_BLE_SERVC_RegisterClient(&gs_client_info);
}

/***********************************************************************************************************************//**
 * Function Name: R_BLE_CSCC_ServDiscCb
 * Description  : Callback function for the Continuous Glucose Monitoring Service Discovery events.
 * Arguments    : conn_hdl  - handle to the connection
 *                type      - discovery event id
 *              : p_param   - pointer to GATTC event data
 *              : serv_idx  - Service index used to distinguish the multiple same UUID service.
 * Return Value : none
***********************************************************************************************************************/
void R_BLE_CSCC_ServDiscCb(uint16_t conn_hdl, uint8_t serv_idx, uint16_t type, void *p_param) // @suppress("API function naming")
{
    R_BLE_SERVC_ServDiscCb(&gs_client_info, conn_hdl, serv_idx, type, p_param);
}

void R_BLE_CSCC_GetServAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_gatt_hdl_range_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    *p_hdl   = gs_cscc_ranges[conn_idx];
}
