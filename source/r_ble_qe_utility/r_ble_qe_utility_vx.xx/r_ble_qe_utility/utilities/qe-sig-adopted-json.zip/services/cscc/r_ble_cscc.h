/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_cscc.h
 * Version : 1.0
 * Description : The header file for Cycling Speed and Cadence Service client.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 20.12.2019 1.00 First Release
 ***********************************************************************************************************************/
/*******************************************************************************************************************//**
 * @file
 * @defgroup cscc Cycling Speed and Cadence Service Client
 * @{
 * @ingroup profile
 * @brief   This is the client for the Cycling Speed and Cadence Service Service.
 **********************************************************************************************************************/

#include "profile_cmn/r_ble_servc_if.h"

#ifndef R_BLE_CSCC_H
#define R_BLE_CSCC_H

/*******************************************************************************************************************//**
 * @brief Cumulative_value length .
***********************************************************************************************************************/
#define BLE_CSCC_SC_CONTROL_POINT_CUMULATIVE_VALUE_LEN                                    (17)

/*******************************************************************************************************************//**
 * @brief Response Parameter length .
***********************************************************************************************************************/
#define BLE_CSCC_SC_CONTROL_POINT_RESPONSE_PARAMETER_LEN                                  (17)

/*******************************************************************************************************************//**
 * @brief Max No of Supported Sensor Locations
***********************************************************************************************************************/
#define BLE_CSCC_MAX_SENSOR_LOCATIONS_SUPPORTED                                           (17)

/*----------------------------------------------------------------------------------------------------------------------
    CSC Measurement Characteristic
----------------------------------------------------------------------------------------------------------------------*/

#define BLE_CSCC_CSC_MEASUREMENT_UUID          (0x2A5B)
#define BLE_CSCC_CSC_MEASUREMENT_LEN           (2)
#define BLE_CSCC_CSC_MEASUREMENT_CLI_CNFG_UUID (0x2902)
#define BLE_CSCC_CSC_MEASUREMENT_CLI_CNFG_LEN  (2)

/***************************************************************************//**
 * @brief CSC Measurement value structure.
*******************************************************************************/
typedef struct 
{
    bool is_wheel_rev_data_present;        /**< Wheel Revolution Data Present */
    bool is_crank_rev_data_present;        /**< Crank Revolution Data Present */
    uint32_t cumulative_wheel_revolutions; /**< Cumulative Wheel Revolutions */
    uint16_t last_wheel_event_time;        /**< Last Wheel Event Time */
    uint16_t cumulative_crank_revolutions; /**< Cumulative Crank Revolutions */
    uint16_t last_crank_event_time;        /**< Last Crank Event Time */
} st_ble_cscc_csc_measurement_t;

/***************************************************************************//**
 * @brief CSC Measurement attribute handle value.
*******************************************************************************/
typedef struct
{
    st_ble_gatt_hdl_range_t range;
    uint16_t                cli_cnfg_desc_hdl;
} st_ble_cscc_csc_meas_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read CSC Measurement characteristic Client Characteristic Configuration descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_CSCC_ReadCsc_measCliCnfg(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write CSC Measurement characteristic Client Characteristic Configuration descriptor value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value CSC Measurement characteristic Client Characteristic Configuration descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_CSCC_WriteCsc_measCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief      Get CSC Measurement attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_CSCC_GetCsc_measurementAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_cscc_csc_meas_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    CSC Feature Characteristic
----------------------------------------------------------------------------------------------------------------------*/

#define BLE_CSCC_CSC_FEATURE_UUID (0x2A5C)
#define BLE_CSCC_CSC_FEATURE_LEN  (2)

/***************************************************************************//**
 * @brief CSC Feature value structure.
*******************************************************************************/
typedef struct 
{
    bool is_wheel_rev_data_supported;     /**< Wheel Revolution Data Supported */
    bool is_crank_rev_data_supported;     /**< Crank Revolution Data Supported */
    bool is_multiple_sen_loc_supported;   /**< Multiple Sensor Locations Supported */
} st_ble_cscc_csc_feature_t;

/***************************************************************************//**
 * @brief CSC Feature attribute handle value.
*******************************************************************************/
typedef struct
{
    st_ble_gatt_hdl_range_t range;
} st_ble_cscc_csc_feat_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read CSC Feature characteristic value from the remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_CSCC_ReadCsc_feature(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief      Get CSC Feature attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_CSCC_GetCsc_featureAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_cscc_csc_feat_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Sensor Location Characteristic
----------------------------------------------------------------------------------------------------------------------*/

#define BLE_CSCC_SENSOR_LOCATION_UUID (0x2A5D)
#define BLE_CSCC_SENSOR_LOCATION_LEN  (1)

/***************************************************************************//*
 * @brief Sensor Location Sensor Location enumeration.
*******************************************************************************/
typedef enum 
{
    BLE_CSCC_SENSOR_LOCATION_SENSOR_LOCATION_OTHER         = 0,  /**< Other */
    BLE_CSCC_SENSOR_LOCATION_SENSOR_LOCATION_TOP_OF_SHOE   = 1,  /**< Top of shoe */
    BLE_CSCC_SENSOR_LOCATION_SENSOR_LOCATION_IN_SHOE       = 2,  /**< In shoe */
    BLE_CSCC_SENSOR_LOCATION_SENSOR_LOCATION_HIP           = 3,  /**< Hip */
    BLE_CSCC_SENSOR_LOCATION_SENSOR_LOCATION__FRONT_WHEEL  = 4,  /**<  Front Wheel */
    BLE_CSCC_SENSOR_LOCATION_SENSOR_LOCATION_LEFT_CRANK    = 5,  /**< Left Crank */
    BLE_CSCC_SENSOR_LOCATION_SENSOR_LOCATION_RIGHT_CRANK   = 6,  /**< Right Crank */
    BLE_CSCC_SENSOR_LOCATION_SENSOR_LOCATION_LEFT_PEDAL    = 7,  /**< Left Pedal */
    BLE_CSCC_SENSOR_LOCATION_SENSOR_LOCATION_RIGHT_PEDAL   = 8,  /**< Right Pedal */
    BLE_CSCC_SENSOR_LOCATION_SENSOR_LOCATION__FRONT_HUB    = 9,  /**<  Front Hub */
    BLE_CSCC_SENSOR_LOCATION_SENSOR_LOCATION_REAR_DROPOUT  = 10, /**< Rear Dropout */
    BLE_CSCC_SENSOR_LOCATION_SENSOR_LOCATION_CHAINSTAY     = 11, /**< Chainstay */
    BLE_CSCC_SENSOR_LOCATION_SENSOR_LOCATION_REAR_WHEEL    = 12, /**< Rear Wheel */
    BLE_CSCC_SENSOR_LOCATION_SENSOR_LOCATION_REAR_HUB      = 13, /**< Rear Hub */
    BLE_CSCC_SENSOR_LOCATION_SENSOR_LOCATION_CHEST         = 14, /**< Chest */
    BLE_CSCC_SENSOR_LOCATION_SENSOR_LOCATION_SPIDER        = 15, /**< Spider */
    BLE_CSCC_SENSOR_LOCATION_SENSOR_LOCATION_CHAIN_RING    = 16, /**< Chain Ring */
} e_ble_sensor_location_sen_loc_t;

/***************************************************************************//**
 * @brief Sensor Location attribute handle value.
*******************************************************************************/
typedef struct
{
    st_ble_gatt_hdl_range_t range;
} st_ble_cscc_sen_loc_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Sensor Location characteristic value from the remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_CSCC_ReadSensor_location(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief      Get Sensor Location attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_CSCC_GetSensor_locationAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_cscc_sen_loc_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    SC Control Point Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_CSCC_SC_CONTROL_POINT_UUID          (0x2A55)
#define BLE_CSCC_SC_CONTROL_POINT_LEN           (20)
#define BLE_CSCC_SC_CONTROL_POINT_CLI_CNFG_UUID (0x2902)
#define BLE_CSCC_SC_CONTROL_POINT_CLI_CNFG_LEN  (2)

/***************************************************************************//********************************
 * @brief SC Control Point Op Code enumeration.
*************************************************************************************************************/
typedef enum
{
    BLE_CSCC_SC_CONTROL_POINT_OP_CODE_RESERVED_FOR_FUTURE_USE            = 0,  /**< Reserved for future use */
    BLE_CSCC_SC_CONTROL_POINT_OP_CODE_SET_CUMULATIVE_VALUE               = 1,  /**< Set Cumulative Value */
    BLE_CSCC_SC_CONTROL_POINT_OP_CODE_START_SENSOR_CALIBRATION           = 2,  /**< Start Sensor Calibration */
    BLE_CSCC_SC_CONTROL_POINT_OP_CODE_UPDATE_SENSOR_LOCATION             = 3,  /**< Update Sensor Location */
    BLE_CSCC_SC_CONTROL_POINT_OP_CODE_REQUEST_SUPPORTED_SENSOR_LOCATIONS = 4,  /**< Request Supported Sensor Locations */
    BLE_CSCC_SC_CONTROL_POINT_OP_CODE_RESPONSE_CODE                      = 16, /**< Response Code */
} e_ble_cscc_sc_cp_op_code_t;

/***************************************************************************//**
 * @brief SC Control Point Response Value enumeration.
*******************************************************************************/
typedef enum
{
    BLE_CSCC_SC_CONTROL_POINT_RESPONSE_VALUE_RESERVED_FOR_FUTURE_USE__RESPONSE_PARAMETER__N_A_ = 0, /**< Reserved For Future Use (Response Parameter: N/A) */
    BLE_CSCC_SC_CONTROL_POINT_RESPONSE_VALUE_SUCCESS__RESPONSE_PARAMETER__NONE                 = 1, /**< Success */
    BLE_CSCC_SC_CONTROL_POINT_RESPONSE_VALUE_OP_CODE_NOT_SUPPORTED__RESPONSE_PARAMETER__N_A_   = 2, /**< Op Code not supported (Response Parameter: N/A) */
    BLE_CSCC_SC_CONTROL_POINT_RESPONSE_VALUE_INVALID_PARAMETER__RESPONSE_PARAMETER__NONE_      = 3, /**< Invalid Parameter (Response Parameter: None) */
    BLE_CSCC_SC_CONTROL_POINT_RESPONSE_VALUE_OPERATION_FAILED__RESPONSE_PARAMETER__NONE_       = 4, /**< Operation Failed (Response Parameter: None) */
} e_ble_cscc_sc_cp_response_value_t;

/***************************************************************************//**
 * @brief SC Control Point value structure.
*******************************************************************************/
typedef struct
{
    uint8_t op_code;                                                              /**< Op Code */
    uint32_t cumulative_value;                                                    /**< Cumulative Value */
    uint8_t sensor_location_value;                                                /**< Sensor Location Value */
    uint8_t  response_code;                                                       /**< Response Code */
    uint8_t request_op_code;                                                      /**< Request Op Code */
    uint8_t response_value;                                                       /**< Response Value */
    uint8_t  response_parameter[BLE_CSCC_SC_CONTROL_POINT_RESPONSE_PARAMETER_LEN];/**< Response Parameter value */
    uint8_t  no_of_supported_sen_loc;                                             /**< No of sensor locations supported */
} st_ble_cscc_sc_control_point_t;

/***************************************************************************//**
 * @brief SC Control Point attribute handle value.
*******************************************************************************/
typedef struct
{
    st_ble_gatt_hdl_range_t range;
    uint16_t                cli_cnfg_desc_hdl;
} st_ble_cscc_sc_cp_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read SC Control Point characteristic Client Characteristic Configuration descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_CSCC_ReadSc_control_pointCliCnfg(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write SC Control Point characteristic Client Characteristic Configuration descriptor value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value pointer to SC Control Point characteristic Client Characteristic Configuration descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_CSCC_WriteSc_control_pointCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Write SC Control Point characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] p_value SC Control Point characteristic value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_CSCC_WriteSc_control_point(uint16_t conn_hdl, const st_ble_cscc_sc_control_point_t *p_value);

/***************************************************************************//**
 * @brief      Get SC Control Point attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_CSCC_GetSc_control_pointAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_cscc_sc_cp_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Cycling Speed and Cadence Service Client
----------------------------------------------------------------------------------------------------------------------*/

/***************************************************************************//******************************************
 * @brief Procedure already in progress
***********************************************************************************************************************/
#define BLE_CSCC_PROCEDURE_ALREADY_IN_PROGRESS_ERROR                                        (BLE_ERR_GROUP_GATT | 0x80)

/***************************************************************************//*****************************************
 * @brief Client Characteristic Configuration descriptor imporperly configured
**********************************************************************************************************************/
#define BLE_CSCC_CLIENT_CHARACTERISTIC_CONFIGURATION_DESCRIPTOR_IMPROPERLY_CONFIGURED_ERROR (BLE_ERR_GROUP_GATT | 0x81)

/***************************************************************************//**
 * @brief Cycling Speed and Cadence Service client event data.
*******************************************************************************/
typedef struct
{
    uint16_t    conn_hdl;  /**< Connection handle */
    uint16_t    param_len; /**< Event parameter length */
    const void *p_param;   /**< Event parameter */
} st_ble_cscc_evt_data_t;

/***************************************************************************//**
 * @brief Cycling Speed and Cadence Service characteristic ID.
*******************************************************************************/
typedef enum
{
    BLE_CSCC_CSC_MEASUREMENT_IDX,
    BLE_CSCC_CSC_MEASUREMENT_CLI_CNFG_IDX,
    BLE_CSCC_CSC_FEATURE_IDX,
    BLE_CSCC_SENSOR_LOCATION_IDX,
    BLE_CSCC_SC_CONTROL_POINT_IDX,
    BLE_CSCC_SC_CONTROL_POINT_CLI_CNFG_IDX,
} e_ble_cscc_char_idx_t;

/***************************************************************************//**
 * @brief Cycling Speed and Cadence Service client event type.
*******************************************************************************/
typedef enum
{
    /* CSC Measurement */
    BLE_CSCC_EVENT_CSC_MEASUREMENT_HDL_VAL_NTF        = BLE_SERVC_ATTR_EVENT(BLE_CSCC_CSC_MEASUREMENT_IDX, BLE_SERVC_HDL_VAL_NTF),
    BLE_CSCC_EVENT_CSC_MEASUREMENT_CLI_CNFG_READ_RSP  = BLE_SERVC_ATTR_EVENT(BLE_CSCC_CSC_MEASUREMENT_CLI_CNFG_IDX, BLE_SERVC_READ_RSP),
    BLE_CSCC_EVENT_CSC_MEASUREMENT_CLI_CNFG_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_CSCC_CSC_MEASUREMENT_CLI_CNFG_IDX, BLE_SERVC_WRITE_RSP),

    /* CSC Feature */
    BLE_CSCC_EVENT_CSC_FEATURE_READ_RSP               = BLE_SERVC_ATTR_EVENT(BLE_CSCC_CSC_FEATURE_IDX, BLE_SERVC_READ_RSP),

    /* Sensor Location */
    BLE_CSCC_EVENT_SENSOR_LOCATION_READ_RSP           = BLE_SERVC_ATTR_EVENT(BLE_CSCC_SENSOR_LOCATION_IDX, BLE_SERVC_READ_RSP),

    /* SC Control Point */
    BLE_CSCC_EVENT_SC_CONTROL_POINT_WRITE_RSP         = BLE_SERVC_ATTR_EVENT(BLE_CSCC_SC_CONTROL_POINT_IDX, BLE_SERVC_WRITE_RSP),
    BLE_CSCC_EVENT_SC_CONTROL_POINT_HDL_VAL_IND       = BLE_SERVC_ATTR_EVENT(BLE_CSCC_SC_CONTROL_POINT_IDX, BLE_SERVC_HDL_VAL_IND),
    BLE_CSCC_EVENT_SC_CONTROL_POINT_CLI_CNFG_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_CSCC_SC_CONTROL_POINT_CLI_CNFG_IDX, BLE_SERVC_READ_RSP),
    BLE_CSCC_EVENT_SC_CONTROL_POINT_CLI_CNFG_WRITE_RSP= BLE_SERVC_ATTR_EVENT(BLE_CSCC_SC_CONTROL_POINT_CLI_CNFG_IDX, BLE_SERVC_WRITE_RSP),
} e_ble_cscc_event_t;

/***************************************************************************//**
 * @brief     Initialize Cycling Speed and Cadence Service client.
 * @param[in] cb Client callback.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_CSCC_Init(ble_servc_app_cb_t cb);

/***************************************************************************//**
 * @brief     Cycling Speed and Cadence Service client discovery callback.
 * @param[in] conn_hdl Connection handle
 * @param[in] serv_idx Service instance index.
 * @param[in] type     Service discovery event type.
 * @param[out] p_param pointer to Service discovery event parameter.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_CSCC_ServDiscCb(uint16_t conn_hdl, uint8_t serv_idx, uint16_t type, void *p_param);

/***************************************************************************//**
 * @brief     Get Cycling Speed and Cadence Service client attribute handle.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
*******************************************************************************/
void R_BLE_CSCC_GetServAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_gatt_hdl_range_t *p_hdl);

#endif /* R_BLE_CSCC_H */

/** @} */
