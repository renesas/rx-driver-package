/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_cscc.h
 * Version : 1.0
 * Description : This module implements Cycling Speed and Cadence Service Client.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 22.03.2019 1.00 First Release
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @file
 * @defgroup cscc Cycling Speed and Cadence Service Client
 * @{
 * @ingroup profile
 * @brief This file provides APIs to interface Cycling Speed and Cadence Service Client.
 **********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_ble_rx23w_if.h"

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
#ifndef R_BLE_CSCC_H
#define R_BLE_CSCC_H

/*******************************************************************************************************************//**
 * @brief Procedure Already in Progress error code.
***********************************************************************************************************************/
#define BLE_CSCC_PROCEDURE_ALREADY_IN_PROGRESS                                          (BLE_ERR_GROUP_GATT | 0x80)
/*******************************************************************************************************************//**
 * @brief Client Characteristic Configuration descriptor improperly configured error code.
***********************************************************************************************************************/
#define BLE_CSCC_CLIENT_CHARACTERISTIC_CONFIGURATION_DESCRIPTOR_IMPROPERLY_CONFIGURED   (BLE_ERR_GROUP_GATT | 0x81)

/*******************************************************************************************************************//**
 * @brief Cumulative_value length .
***********************************************************************************************************************/
#define BLE_CSCC_SC_CONTROL_POINT_CUMULATIVE_VALUE_LEN                                  (17)

/*******************************************************************************************************************//**
 * @brief Response Parameter length .
***********************************************************************************************************************/
#define BLE_CSCC_SC_CONTROL_POINT_RESPONSE_PARAMETER_LEN                                (17)

/*******************************************************************************************************************//**
 * @brief Max No of Supported Sensor Locations
***********************************************************************************************************************/
#define BLE_CSCC_MAX_SENSOR_LOCATIONS_SUPPORTED                                         (17)

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @brief Cycling Speed and Cadence Service Client event data.
***********************************************************************************************************************/
typedef struct
{
    uint16_t  conn_hdl;  /**< Connection handle */
    uint16_t  param_len; /**< Event parameter length */
    void     *p_param;   /**< Event parameter */
} st_ble_cscc_evt_data_t;

/*******************************************************************************************************************//**
 * @brief Cycling Speed and Cadence Service Client event callback.
***********************************************************************************************************************/
typedef void (*ble_cscc_app_cb_t)(uint16_t type, ble_status_t result, st_ble_cscc_evt_data_t *p_data);

/*******************************************************************************************************************//**
 * @brief Cycling Speed and Cadence Service Client event type.
***********************************************************************************************************************/
typedef enum 
{
    BLE_CSCC_EVENT_CSC_MEASUREMENT_HDL_VAL_NTF, /**< CSC Measurement characteristic handle value notification event */
    BLE_CSCC_EVENT_CSC_FEATURE_READ_RSP, /**< CSC Feature characteristic read response event */
    BLE_CSCC_EVENT_SENSOR_LOCATION_READ_RSP, /**< Sensor Location characteristic read response event */
    BLE_CSCC_EVENT_SC_CONTROL_POINT_HDL_VAL_IND, /**< SC Control Point characteristic handle value indication event */
    BLE_CSCC_EVENT_SC_CONTROL_POINT_WRITE_RSP, /**< SC Control Point characteristic write response event */
    BLE_CSCC_EVENT_CLI_CNFG_WRITE_RSP, /**< Cli Cnfig write response */
    BLE_CSCC_EVENT_ERROR_RSP, /**< error response */
} e_ble_cscc_event_t;

/*******************************************************************************************************************//**
 * @brief Sensor Location enumeration.
***********************************************************************************************************************/
typedef enum 
{
    BLE_CSCC_SENSOR_LOCATION_SENSOR_LOCATION_OTHER        = 0, /**< Sensor Location - Other */
    BLE_CSCC_SENSOR_LOCATION_SENSOR_LOCATION_TOP_OF_SHOE  = 1, /**< Sensor Location - Top of Shoe */
    BLE_CSCC_SENSOR_LOCATION_SENSOR_LOCATION_IN_SHOE      = 2, /**< Sensor Location - In Shoe */
    BLE_CSCC_SENSOR_LOCATION_SENSOR_LOCATION_HIP          = 3, /**< Sensor Location - Hip */
    BLE_CSCC_SENSOR_LOCATION_SENSOR_LOCATION_FRONT_WHEEL  = 4, /**< Sensor Location - Front Wheel */
    BLE_CSCC_SENSOR_LOCATION_SENSOR_LOCATION_LEFT_CRANK   = 5, /**< Sensor Location - Left Crank */
    BLE_CSCC_SENSOR_LOCATION_SENSOR_LOCATION_RIGHT_CRANK  = 6, /**< Sensor Location - Right Crank */
    BLE_CSCC_SENSOR_LOCATION_SENSOR_LOCATION_LEFT_PEDAL   = 7, /**< Sensor Location - Left Pedal */
    BLE_CSCC_SENSOR_LOCATION_SENSOR_LOCATION_RIGHT_PEDAL  = 8, /**< Sensor Location - Right Pedal */
    BLE_CSCC_SENSOR_LOCATION_SENSOR_LOCATION_FRONT_HUB    = 9, /**< Sensor Location - Front Hub */
    BLE_CSCC_SENSOR_LOCATION_SENSOR_LOCATION_REAR_DROPOUT = 10, /**< Sensor Location - Rear Dropout */
    BLE_CSCC_SENSOR_LOCATION_SENSOR_LOCATION_CHAINSTAY    = 11, /**< Sensor Location - Chainstay */
    BLE_CSCC_SENSOR_LOCATION_SENSOR_LOCATION_REAR_WHEEL   = 12, /**< Sensor Location - Rear Wheel */
    BLE_CSCC_SENSOR_LOCATION_SENSOR_LOCATION_REAR_HUB     = 13, /**< Sensor Location - Rear Hub */
    BLE_CSCC_SENSOR_LOCATION_SENSOR_LOCATION_CHEST        = 14, /**< Sensor Location - Chest */
    BLE_CSCC_SENSOR_LOCATION_SENSOR_LOCATION_SPIDER       = 15, /**< Sensor Location - Spider */
    BLE_CSCC_SENSOR_LOCATION_SENSOR_LOCATION_CHAIN_RING   = 16, /**< Sensor Location - Chain Ring */
} e_ble_cscc_sensor_location_t;

/*******************************************************************************************************************//**
 * @brief Op Code enumeration.
***********************************************************************************************************************/
typedef enum 
{
    BLE_CSCC_SC_CONTROL_POINT_OP_CODE_RESERVED_FOR_FUTURE_USE            = 0, /**< Reserved for Future Use */
    BLE_CSCC_SC_CONTROL_POINT_OP_CODE_SET_CUMULATIVE_VALUE               = 1, /**< Set Cumulative Value */
    BLE_CSCC_SC_CONTROL_POINT_OP_CODE_START_SENSOR_CALIBRATION           = 2, /**< Start Sensor Calibration */
    BLE_CSCC_SC_CONTROL_POINT_OP_CODE_UPDATE_SENSOR_LOCATION             = 3, /**< Update the Sensor Location */
    BLE_CSCC_SC_CONTROL_POINT_OP_CODE_REQUEST_SUPPORTED_SENSOR_LOCATIONS = 4, 
    /**< Send list of supported sensor location values */
    BLE_CSCC_SC_CONTROL_POINT_OP_CODE_RESPONSE_CODE                      = 16, /**< Response Code */
} e_ble_cscc_sc_control_point_op_code_t;

/*******************************************************************************************************************//**
 * @brief Response Value enumeration.
***********************************************************************************************************************/
typedef enum 
{
    BLE_CSCC_SC_CONTROL_POINT_RESPONSE_VALUE_RESERVED_FOR_FUTURE_USE = 0, /**< Reserved For Future Use */
    BLE_CSCC_SC_CONTROL_POINT_RESPONSE_VALUE_SUCCESS                 = 1, /**< Success */
    BLE_CSCC_SC_CONTROL_POINT_RESPONSE_VALUE_OP_CODE_NOT_SUPPORTED   = 2, /**< Opcode not supported */
    BLE_CSCC_SC_CONTROL_POINT_RESPONSE_VALUE_INVALID_PARAMETER       = 3, /**< Invalid parameter */
    BLE_CSCC_SC_CONTROL_POINT_RESPONSE_VALUE_OPERATION_FAILED        = 4, /**< Operation Failed */
} e_ble_cscc_sc_control_point_response_value_t;

/*******************************************************************************************************************//**
 * @brief Cycling Speed and Cadence Service attribute handles.
***********************************************************************************************************************/
typedef struct 
{
    st_ble_gatt_hdl_range_t service_range; /**< Cycling Speed and Cadence Service range */
    uint16_t csc_measurement_char_val_hdl; /**< CSC Measurement characteristic value handle */
    uint16_t csc_measurement_cli_cnfg_hdl; /**< CSC Measurement characteristic Client Characteristic Configuration 
                                           descriptor handle */
    uint16_t csc_feature_char_val_hdl; /**< CSC Feature characteristic value handle */
    uint16_t sensor_location_char_val_hdl; /**< Sensor Location characteristic value handle */
    uint16_t sc_control_point_char_val_hdl; /**< SC Control Point characteristic value handle */
    uint16_t sc_control_point_cli_cnfg_hdl; /**< SC Control Point characteristic Client Characteristic Configuration 
                                            descriptor handle */
} st_ble_cscc_hdls_t;

/*******************************************************************************************************************//**
 * @brief Cycling Speed and Cadence Service initialization parameters.
***********************************************************************************************************************/
typedef struct 
{
    ble_cscc_app_cb_t cb; /**< Cycling Speed and Cadence Service Client event handler */
} st_ble_cscc_init_param_t;

/*******************************************************************************************************************//**
 * @brief Cycling Speed and Cadence Service Client connection parameters.
***********************************************************************************************************************/
typedef struct 
{
    st_ble_cscc_hdls_t *p_hdls; /**< Cycling Speed and Cadence Service handles */
} st_ble_cscc_connect_param_t;

/*******************************************************************************************************************//**
 * @brief Cycling Speed and Cadence Service disconnection parameters.
***********************************************************************************************************************/
typedef struct 
{
    st_ble_cscc_hdls_t *p_hdls; /**< Cycling Speed and Cadence Service handles */
} st_ble_cscc_disconnect_param_t;

/*******************************************************************************************************************//**
 * @brief CSC Measurement characteristic parameters.
***********************************************************************************************************************/
typedef struct 
{
    bool     is_wheel_revolution_data_present; /**< Wheel Revolution data present or not */
    bool     is_crank_revolution_data_present; /**< Crank Revolution data present or not */
    uint32_t cumulative_wheel_revolutions; /**< Cumulative Wheel Revolutions value */
    uint16_t last_wheel_event_time; /**< Last Wheel Event Time value */
    uint16_t cumulative_crank_revolutions; /**< Cumulative Crank Revolutions value */
    uint16_t last_crank_event_time; /**< Last Crank Event Time value */
} st_ble_cscc_csc_measurement_t;

/*******************************************************************************************************************//**
 * @brief CSC Feature characteristic parameters.
***********************************************************************************************************************/
typedef struct 
{
    bool is_wheel_revolution_data_supported;  /**< Wheel Revolution data supported or not */
    bool is_crank_revolution_data_supported;  /**< Crank Revolution data supported or not */
    bool is_multiple_sensor_locations_supported; /**< Multiple Sensor Locations supported or not */
} st_ble_cscc_csc_feature_t;

/*******************************************************************************************************************//**
 * @brief SC Control Point characteristic parameters.
***********************************************************************************************************************/
typedef struct 
{
    uint8_t  op_code; /**< Op Code value */
    uint32_t cumulative_value; /**< Cumulative Value value */
    uint8_t  sensor_location_value; /**< Sensor Location Value value */
    uint8_t  response_code;         /**< Response Code */
    uint8_t  request_op_code; /**< Request Op Code value */
    uint8_t  response_value; /**< Response Value value */
    uint8_t  response_parameter[BLE_CSCC_SC_CONTROL_POINT_RESPONSE_PARAMETER_LEN]; /**< Response Parameter value */
    uint8_t  no_of_supported_sensor_locations;                                   /**< No of sensor locations supported */
} st_ble_cscc_sc_control_point_t;

/***********************************************************************************************************************
Exported global variables (to be accessed by other files)
***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @brief Cycling Speed and Cadence Service UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_CSCC_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief CSC Measurement characteristic UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_CSCC_CSC_MEASUREMENT_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief CSC Feature characteristic UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_CSCC_CSC_FEATURE_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Sensor Location characteristic UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_CSCC_SENSOR_LOCATION_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief SC Control Point characteristic UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_CSCC_SC_CONTROL_POINT_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/***********************************************************************************************************************
Exported global functions (to be accessed by other files)
***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @brief     Initialize Cycling Speed and Cadence Service  Client.
 * @details   This function shall be called once at startup.
 * @param[in] p_param Pointer to Cycling Speed and Cadence Service Client initialization parameters.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_CSCC_Init(const st_ble_cscc_init_param_t *p_param);

/*******************************************************************************************************************//**
 * @brief     Perform Cycling Speed and Cadence Service Client connection settings.
 * @details   This function shall be called on each connection establishment.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_param  Pointer to Connection parameters.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_CSCC_Connect(uint16_t conn_hdl, const st_ble_cscc_connect_param_t *p_param);

/*******************************************************************************************************************//**
 * @brief     Retrieve Cycling Speed and Cadence Service Client connection specific settings before disconnection.
 * @details   This function shall be called on each disconnection.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_param  Pointer to Disconnection parameters.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_CSCC_Disconnect(uint16_t conn_hdl, st_ble_cscc_disconnect_param_t *p_param);

/*******************************************************************************************************************//**
 * @brief     Set CSC Measurement characteristic cli cnfg.
 * @param[in] conn_hdl Connection handle.
 * @param[in] cli_cnfg CSC Measurement characteristic cli cnfg to set.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_CSCC_SetCscMeasurementCliCnfg(uint16_t conn_hdl, uint16_t cli_cnfg);

/*******************************************************************************************************************//**
 * @brief      Read CSC Feature characteristic value from remote GATT database.
 * @param[in]  conn_hdl Connection handle.
 * @return     @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_CSCC_ReadCscFeature(uint16_t conn_hdl);

/*******************************************************************************************************************//**
 * @brief      Read Sensor Location characteristic value from remote GATT database.
 * @param[in]  conn_hdl Connection handle.
 * @return     @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_CSCC_ReadSensorLocation(uint16_t conn_hdl);

/*******************************************************************************************************************//**
 * @brief     Write SC Control Point characteristic value to remote GATT database.
 * @param[in] conn_hdl    Connection handle.
 * @param[in] p_app_value Pointer to SC Control Point characteristic value to write.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_CSCC_WriteScControlPoint(uint16_t conn_hdl, const st_ble_cscc_sc_control_point_t *p_app_value);

/*******************************************************************************************************************//**
 * @brief     Set SC Control Point characteristic cli cnfg.
 * @param[in] conn_hdl Connection handle.
 * @param[in] cli_cnfg SC Control Point characteristic cli cnfg to set.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_CSCC_SetScControlPointCliCnfg(uint16_t conn_hdl, uint16_t cli_cnfg);

/***********************************************************************************************************************
 * @brief      Callback function for the Cycling Speed and Cadence Discovery events.
 * @param[out] conn_hdl Connection handle.
 * @param[out] idx      Service index used to distiguish the multiple same UUID service.
 * @param[out] type     Discovery event type
 * @param[out] p_param  Pointer to GATTC event data.
***********************************************************************************************************************/
void R_BLE_CSCC_ServDiscCb(uint16_t conn_hdl, uint8_t idx, uint16_t type, void *p_param);

/*******************************************************************************************************************//**
 * @brief     Return version of the CSCC service client.
 * @return    version
***********************************************************************************************************************/
uint32_t R_BLE_CSCC_GetVersion(void);

#endif /* R_BLE_CSCC_H */

/** @} */
