/***********************************************************************************************************************
 * DISCLAIMER
 * This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
 * other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
 * applicable laws, including copyright laws.
 * THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
 * THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
 * EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
 * SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
 * SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
 * Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
 * this software. By using this software, you agree to the additional terms and conditions found by accessing the
 * following link:
 * http://www.renesas.com/disclaimer
 *
 * Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
 ***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_bcs.h
 * Version : 1.0
 * Description : This module implements Body Composition Service Server.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 22.03.2019 1.00 First Release
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @file
 * @defgroup bcs Body Composition Service Server 
 * @{
 * @ingroup profile
 * @brief   This service exposes data related to body composition from a body composition analyzer intended for consumer healthcare and sports/fitness applications. 
 **********************************************************************************************************************/

/***********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
 ***********************************************************************************************************************/
#include "profile_cmn/r_ble_serv_common.h"

/***********************************************************************************************************************
 Macro definitions
 ***********************************************************************************************************************/
#ifndef R_BLE_BCS_H
#define R_BLE_BCS_H

/***********************************************************************************************************************
 Typedef definitions
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @brief Body Composition Service event data.
 ***********************************************************************************************************************/
typedef struct
{
    uint16_t conn_hdl; /**< Connection handle */
    uint16_t param_len; /**< Event parameter length */
    void     *p_param; /**< Event parameter */
} st_ble_bcs_evt_data_t;

/*******************************************************************************************************************//**
 * @brief Body Composition Service event callback.
 ***********************************************************************************************************************/
typedef void (*ble_bcs_app_cb_t) (uint16_t type, ble_status_t result, st_ble_bcs_evt_data_t *p_data);

/*******************************************************************************************************************//**
 * @brief Body Composition Service event type.
 ***********************************************************************************************************************/
typedef enum
{
    BLE_BCS_EVENT_BODY_COMPOSITION_MEASUREMENT_CLI_CNFG_ENABLED, /**< Body Composition Measurement characteristic cli cnfg enabled event */
    BLE_BCS_EVENT_BODY_COMPOSITION_MEASUREMENT_CLI_CNFG_DISABLED, /**< Body Composition Measurement characteristic cli cnfg disabled event */
    BLE_BCS_EVENT_BODY_COMPOSITION_MEASUREMENT_HDL_VAL_CNF, /**< Body Composition Measurement characteristic handle value confiration event */
    BLE_BCS_EVENT_BODY_COMPOSITION_FEATURE_READ_REQ, /**< Body Composition Feature characteristic read request event */
} e_ble_bcs_event_t;

/*******************************************************************************************************************//**
 * @brief User ID enumeration.
 ***********************************************************************************************************************/
typedef enum
{
    BLE_BCS_BODY_COMPOSITION_MEASUREMENT_USER_ID_UNKNOWN_USER = 255, /**< Unknown User */
} e_ble_bcs_body_composition_measurement_t;

/*******************************************************************************************************************//**
 * @brief Mass Measurement Resolution enumeration.
 ***********************************************************************************************************************/
typedef enum
{
    BLE_BCS_BODY_COMPOSITION_FEATURE_MASS_MEASUREMENT_RESOLUTION_UNSPECIFIED, /**< Not Specified */
    BLE_BCS_BODY_COMPOSITION_FEATURE_MASS_MEASUREMENT_RESOLUTION_1_LB, /**< Resolution of 0.5 kg or 1 lb */
    BLE_BCS_BODY_COMPOSITION_FEATURE_MASS_MEASUREMENT_RESOLUTION_0_5_LB, /**< Resolution of 0.2 kg or 0.5 lb */
    BLE_BCS_BODY_COMPOSITION_FEATURE_MASS_MEASUREMENT_RESOLUTION_0_2_LB, /**< Resolution of 0.1 kg or 0.2 lb */
    BLE_BCS_BODY_COMPOSITION_FEATURE_MASS_MEASUREMENT_RESOLUTION_0_1_LB, /**< Resolution of 0.05 kg or 0.1 lb */
    BLE_BCS_BODY_COMPOSITION_FEATURE_MASS_MEASUREMENT_RESOLUTION_0_05_LB, /**< Resolution of 0.02 kg or 0.05 lb */
    BLE_BCS_BODY_COMPOSITION_FEATURE_MASS_MEASUREMENT_RESOLUTION_0_02_LB, /**< Resolution of 0.01 kg or 0.02 lb */
    BLE_BCS_BODY_COMPOSITION_FEATURE_MASS_MEASUREMENT_RESOLUTION_0_01_LB, /**< Resolution of 0.005 kg or 0.01 lb */
} e_ble_bcs_body_composition_feature_mass_measurement_resolution_t;

/*******************************************************************************************************************//**
 * @brief Height Measurement Resolution enumeration.
 ***********************************************************************************************************************/
typedef enum
{
    BLE_BCS_BODY_COMPOSITION_FEATURE_HEIGHT_MEASUREMENT_RESOLUTION_UNSPECIFIED, /**< Resolution Not Specified */
    BLE_BCS_BODY_COMPOSITION_FEATURE_HEIGHT_MEASUREMENT_RESOLUTION_1_INCH, /**< Resolution of 0.01 meter or 1 inch */
    BLE_BCS_BODY_COMPOSITION_FEATURE_HEIGHT_MEASUREMENT_RESOLUTION_0_5_INCH, /**< Resolution of 0.005 meter or 0.5 inch */
    BLE_BCS_BODY_COMPOSITION_FEATURE_HEIGHT_MEASUREMENT_RESOLUTION_0_1_INCH, /**< Resolution of 0.001 meter or 0.1 inch */
} e_ble_bcs_body_composition_feature_height_measurement_resolution_t;


/*******************************************************************************************************************//**
 * @brief Body Composition Service initialization parameters.
 ***********************************************************************************************************************/
typedef struct
{
    ble_bcs_app_cb_t cb; /**< Body Composition Service event callback */
} st_ble_bcs_init_param_t;

/*******************************************************************************************************************//**
 * @brief Body Composition Service connection parameters.
 ***********************************************************************************************************************/
typedef struct
{
    uint16_t body_composition_measurement_cli_cnfg; /**< Body Composition Measurement characteristic cli cnfg */
} st_ble_bcs_connect_param_t;

/*******************************************************************************************************************//**
 * @brief Body Composition Service disconnection parameters.
 ***********************************************************************************************************************/
typedef struct
{
    uint16_t body_composition_measurement_cli_cnfg; /**< Body Composition Measurement characteristic cli cnfg */
} st_ble_bcs_disconnect_param_t;

/*******************************************************************************************************************//**
 * @brief Body Composition Feature characteristic parameters.
 ***********************************************************************************************************************/
typedef struct
{
    bool    is_timestamp_supported;         /**< Time Stamp feature supported for Weight Scale or not */
    bool    is_multiple_users_supported;    /**< Multiple Users feature supported for Weight Scale or not */
    bool    is_basal_metabolism_supported;  /**< Basal Metabolism Supported or not */
    bool    is_muscle_percentage_supported; /**< Muscle Percentage Supported or not */
    bool    is_muscle_mass_supported;       /**< Muscle Mass Supported or not */
    bool    is_fat_free_mass_supported;     /**< Fat Free Mass Supported or not */
    bool    is_soft_lean_mass_supported;    /**< Soft Lean Mass Supported or not */
    bool    is_body_water_mass_supported;   /**< Body Water Mass Supported or not */
    bool    is_impedance_supported;         /**< Impedance Supported or not */
    bool    is_weight_supported;            /**< Weight Supported or not */
    bool    is_height_supported;            /**< Height Supported or not */
    uint8_t mass_measurement_resolution;    /**< Mass Measurement Resolution */
    uint8_t height_measurement_resolution;  /**< Height Measurement Resolution */
} st_ble_bcs_body_composition_feature_t;

/*******************************************************************************************************************//**
 * @brief Body Composition Measurement characteristic parameters.
 ***********************************************************************************************************************/
typedef struct
{
    bool               is_measurement_in_imperial_units;       /**< Weight and Mass in SI Units or Imperial Units */
    bool               is_timestamp_present;                   /**< Timestamp present or not */
    bool               is_user_id_present;                     /**< User ID present or not */
    bool               is_basal_metabolism_present;            /**< Basal Metabolism present or not */
    bool               is_muscle_percentage_present;           /**< Muscle Percentage present or not */
    bool               is_muscle_mass_present;                 /**< Muscle Mass present or not */
    bool               is_fat_free_mass_present;               /**< Fat Free Mass present or not */
    bool               is_soft_lean_mass_present;              /**< Soft Lean Mass present or not */
    bool               is_body_water_mass_present;             /**< Body Water Mass present or not */
    bool               is_impedance_present;                   /**< Impedance present or not */
    bool               is_weight_present;                      /**< Weight present or not */
    bool               is_height_present;                      /**< Height Supported or not */
    bool               is_multiple_packet_measurement_present; /**< Multiple Packet Measurement */
    uint16_t           body_fat_percentage;                    /**< Body Fat Percentage with a resolution of 0.1 */
    st_ble_date_time_t time_stamp;                             /**< Time Stamp */
    uint8_t            user_id;                                /**< User ID */
    uint16_t           basal_metabolism;                       /**< Basal Metabolism in Joules with a resolution of 1 */
    uint16_t           muscle_percentage;                      /**< Muscle Percentage with a resolutin of 0.1 */
    uint16_t           muscle_mass;                            /**< Muscle Mass in Kilograms or Ponds */
    uint16_t           fat_free_mass;                          /**< Fat Free Mass - Kilograms or Ponds */
    uint16_t           soft_lean_mass;                         /**< Soft Lean Mass - Kilograms or Ponds */
    uint16_t           body_water_mass;                        /**< Body Water Mass - Kilograms or Ponts */
    uint16_t           impedance;                              /**< Impedance in Ohms with a resolution of 0.1 */
    uint16_t           weight;                                 /**< Weight - Kilograms or Ponts */
    uint16_t           height;                                 /**< Height - Meters or Inches */
} st_ble_bcs_body_composition_measurement_t;

/***********************************************************************************************************************
 Exported global functions (to be accessed by other files)
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @brief     Initialize Body Composition Service.
 * @details   This function shall be called once at startup.
 * @param[in] p_param Pointer to Body Composition Service initialization parameters.
 * @return
 ***********************************************************************************************************************/
ble_status_t R_BLE_BCS_Init (const st_ble_bcs_init_param_t *p_param);

/*******************************************************************************************************************//**
 * @brief     Perform Body Composition Service connection settings.
 * @details   This function shall be called on each connection establishment.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_param    Pointer to Connection parameters.
 * @return    @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_BCS_Connect (uint16_t conn_hdl, const st_ble_bcs_connect_param_t *p_param);

/*******************************************************************************************************************//**
 * @brief     Retrieve Body Composition Service connection specific settings before disconnection.
 * @details   This function shall be called on each disconnection.
 * @param[in] conn_hdl   Connection handle.
 * @param[in] p_param    Pointer to Disconnection parameters.
 * @return    @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_BCS_Disconnect (uint16_t conn_hdl, st_ble_bcs_disconnect_param_t *p_param);

/*******************************************************************************************************************//**
 * @brief      Get Body Composition Feature characteristic value from local GATT database.
 * @param[out] p_app_value Pointer to Retrieved Body Composition Feature characteristic value.
 * @return     @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_BCS_GetBodyCompositionFeature (st_ble_bcs_body_composition_feature_t *p_app_value);

/*******************************************************************************************************************//**
 * @brief     Set Body Composition Feature characteristic value to local GATT database.
 * @param[in] p_app_value Pointer to Body Composition Feature characteristic value to set.
 * @return    @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_BCS_SetBodyCompositionFeature (const st_ble_bcs_body_composition_feature_t *p_app_value);

/*******************************************************************************************************************//**
 * @brief     Send Body Composition Measurement indication.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] p_app_value Pointer to Body Composition Measurement value to send.
 * @return    @ref ble_status_t
 ***********************************************************************************************************************/
ble_status_t R_BLE_BCS_IndicateBodyCompositionMeasurement (uint16_t conn_hdl,
        const st_ble_bcs_body_composition_measurement_t *p_app_value);

/*******************************************************************************************************************//**
 * @brief     Return version of the BCC service server.
 * @return    version
 ***********************************************************************************************************************/
uint32_t R_BLE_BCS_GetVersion (void);

#endif /* R_BLE_BCS_H */

/** @} */
