/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_bcs.c
 * Version : 1.0
 * Description : This module implements Body Composition Service Server.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 22.03.2019 1.00 First Release
 ***********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <string.h>
#include "r_ble_rx23w_if.h"
#include "r_ble_bcs.h"
#include "gatt_db.h"

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
/* Version number */
#define BLE_BCS_PRV_VERSION_MAJOR                 (1)
#define BLE_BCS_PRV_VERSION_MINOR                 (0)

#define BLE_BCS_PRV_MEAS_INDICATE_EVENT_ID        (11)


/*******************************************************************************************************************//**
 * Body Compostion Feature Bit definitions
 ***********************************************************************************************************************/
#define BLE_BCS_PRV_BODY_COMPOSITION_FEATURE_TIME_STAMP_SUPPORTED                  (1 << 0)
#define BLE_BCS_PRV_BODY_COMPOSITION_FEATURE_MULTIPLE_USERS_SUPPORTED              (1 << 1)
#define BLE_BCS_PRV_BODY_COMPOSITION_FEATURE_BASAL_METABOLISM_SUPPORTED            (1 << 2)
#define BLE_BCS_PRV_BODY_COMPOSITION_FEATURE_MUSCLE_PERCENTAGE_SUPPORTED           (1 << 3)
#define BLE_BCS_PRV_BODY_COMPOSITION_FEATURE_MUSCLE_MASS_SUPPORTED                 (1 << 4)
#define BLE_BCS_PRV_BODY_COMPOSITION_FEATURE_FAT_FREE_MASS_SUPPORTED               (1 << 5)
#define BLE_BCS_PRV_BODY_COMPOSITION_FEATURE_SOFT_LEAN_MASS_SUPPORTED              (1 << 6)
#define BLE_BCS_PRV_BODY_COMPOSITION_FEATURE_BODY_WATER_MASS_SUPPORTED             (1 << 7)
#define BLE_BCS_PRV_BODY_COMPOSITION_FEATURE_IMPEDANCE_SUPPORTED                   (1 << 8)
#define BLE_BCS_PRV_BODY_COMPOSITION_FEATURE_WEIGHT_SUPPORTED                      (1 << 9)
#define BLE_BCS_PRV_BODY_COMPOSITION_FEATURE_HEIGHT_SUPPORTED                      (1 << 10)
#define BLE_BCS_PRV_BODY_COMPOSITION_FEATURE_MASS_MEASUREMENT_RESOLUTION           (((1 << 4) - 1) << 11)
#define BLE_BCS_PRV_BODY_COMPOSITION_FEATURE_HEIGHT_MEASUREMENT_RESOLUTION         (((1 << 3) - 1) << 15)

 /*******************************************************************************************************************//**
 * @brief Body Composition Measurement Flag Bit definitions.
 ***********************************************************************************************************************/
#define BLE_BCS_BODY_COMPOSITION_MEASUREMENT_FLAGS_MEASUREMENT_UNITS               (1 << 0)
#define BLE_BCS_BODY_COMPOSITION_MEASUREMENT_FLAGS_TIME_STAMP_PRESENT              (1 << 1)
#define BLE_BCS_BODY_COMPOSITION_MEASUREMENT_FLAGS_USER_ID_PRESENT                 (1 << 2)
#define BLE_BCS_BODY_COMPOSITION_MEASUREMENT_FLAGS_BASAL_METABOLISM_PRESENT        (1 << 3)
#define BLE_BCS_BODY_COMPOSITION_MEASUREMENT_FLAGS_MUSCLE_PERCENTAGE_PRESENT       (1 << 4)
#define BLE_BCS_BODY_COMPOSITION_MEASUREMENT_FLAGS_MUSCLE_MASS_PRESENT             (1 << 5)
#define BLE_BCS_BODY_COMPOSITION_MEASUREMENT_FLAGS_FAT_FREE_MASS_PRESENT           (1 << 6)
#define BLE_BCS_BODY_COMPOSITION_MEASUREMENT_FLAGS_SOFT_LEAN_MASS_PRESENT          (1 << 7)
#define BLE_BCS_BODY_COMPOSITION_MEASUREMENT_FLAGS_BODY_WATER_MASS_PRESENT         (1 << 8)
#define BLE_BCS_BODY_COMPOSITION_MEASUREMENT_FLAGS_IMPEDANCE_PRESENT               (1 << 9)
#define BLE_BCS_BODY_COMPOSITION_MEASUREMENT_FLAGS_WEIGHT_PRESENT                  (1 << 10)
#define BLE_BCS_BODY_COMPOSITION_MEASUREMENT_FLAGS_HEIGHT_PRESENT                  (1 << 11)
#define BLE_BCS_BODY_COMPOSITION_MEASUREMENT_FLAGS_MULTIPLE_PACKET_MEASUREMENT     (1 << 12)

/***********************************************************************************************************************
Private global variables and functions
***********************************************************************************************************************/
static ble_bcs_app_cb_t gs_bcs_cb;
static bool gs_continous_packet_present      = false;
static uint8_t gs_bcs_continuous_packet_flag = 0;
static st_ble_bcs_body_composition_measurement_t gs_bcs_measurement_continuous_packet;

/***********************************************************************************************************************
 * Function Name: set_cli_cnfg
 * Description  : Set Characteristic value notification configuration in local GATT database.
 * Arguments    : conn_hdl - handle to connection.
 *                attr_hadl - handle to the attribute
 *                cli_cnfg - configuration value
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t set_cli_cnfg(uint16_t conn_hdl, uint16_t attr_hdl, uint16_t cli_cnfg)
{
    uint8_t data[2];

    BT_PACK_LE_2_BYTE(data, &cli_cnfg);

    st_ble_gatt_value_t gatt_value =
    {
        .p_value   = data,
        .value_len = 2,
    };

    return R_BLE_GATTS_SetAttr(conn_hdl, attr_hdl, &gatt_value);
}

/***********************************************************************************************************************
 * Function Name: get_cli_cnfg
 * Description  : Get Characteristic value notification configuration from local GATT database.
 * Arguments    : conn_hdl - handle to connection.
 *                attr_hadl - handle to the attribute
 *                p_cli_cnfg - pointer to variable to store configuration value
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t get_cli_cnfg(uint16_t conn_hdl, uint16_t attr_hdl, uint16_t *p_cli_cnfg)
{
    ble_status_t ret;
    st_ble_gatt_value_t gatt_value;

    ret = R_BLE_GATTS_GetAttr(conn_hdl, attr_hdl, &gatt_value);

    if (BLE_SUCCESS == ret)
    {
        BT_UNPACK_LE_2_BYTE(p_cli_cnfg, gatt_value.p_value);
    }

    return ret;
}

/***********************************************************************************************************************
 * Function Name: check_bcs_measurement_packet_length
 * Description  : This function checks if the measurement characteristic indicate packet length reached its maximum (MTU)
 *                size
 * Arguments    : max_len - maximum allowed length for the characteristic
 *                actual_len - actual length of the packet
 *                flag - flag field of the characteristic
 * Return Value : none
 **********************************************************************************************************************/
static void check_bcs_measurement_packet_length(uint16_t max_len, uint8_t actual_len, uint16_t flag)
{
    gs_continous_packet_present = false;

    /* check the actual length with (max_len - 3) since 3 bytes will be appended by the stack */
    if ((max_len - 3) == actual_len)
    {
        gs_continous_packet_present = true;
        
        /* Clear the bits for the fields which are already indicated */
        gs_bcs_measurement_continuous_packet.is_timestamp_present         = false; /* Always Fit in the first packet */
        gs_bcs_measurement_continuous_packet.is_user_id_present           = false; /* Always Fit in the first packet */
        gs_bcs_measurement_continuous_packet.is_basal_metabolism_present  = false; /* Always Fit in the first packet */
        gs_bcs_measurement_continuous_packet.is_muscle_percentage_present = false; /* Always Fit in the first packet */
        gs_bcs_measurement_continuous_packet.is_muscle_mass_present       = false; /* Always Fit in the first packet */
        gs_bcs_measurement_continuous_packet.is_fat_free_mass_present     = false; /* Always Fit in the first packet */

        /* Clear the present bits if already in the first packet */
        gs_bcs_measurement_continuous_packet.is_soft_lean_mass_present = 
            ((flag & BLE_BCS_BODY_COMPOSITION_MEASUREMENT_FLAGS_SOFT_LEAN_MASS_PRESENT) ? false : true);

        gs_bcs_measurement_continuous_packet.is_body_water_mass_present =
            ((flag & BLE_BCS_BODY_COMPOSITION_MEASUREMENT_FLAGS_BODY_WATER_MASS_PRESENT) ? false : true);
        
        gs_bcs_measurement_continuous_packet.is_impedance_present = 
        ((flag & BLE_BCS_BODY_COMPOSITION_MEASUREMENT_FLAGS_IMPEDANCE_PRESENT) ? false : true);
            
        gs_bcs_measurement_continuous_packet.is_weight_present =
        ((flag & BLE_BCS_BODY_COMPOSITION_MEASUREMENT_FLAGS_WEIGHT_PRESENT) ? false : true);
            
        gs_bcs_measurement_continuous_packet.is_height_present =
        ((flag & BLE_BCS_BODY_COMPOSITION_MEASUREMENT_FLAGS_HEIGHT_PRESENT) ? false : true);
            
        gs_bcs_measurement_continuous_packet.is_multiple_packet_measurement_present = true;
    }
}

/***********************************************************************************************************************
 * Function Name: encode_body_composition_feature
 * Description  : This function converts Body Composition Feature characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the Body Composition Feature  value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_body_composition_feature(const st_ble_bcs_body_composition_feature_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    /* Convert application data to byte sequence. */
    memset(p_gatt_value->p_value, 0x0, p_gatt_value->value_len);

    /* Time Stamp feature */
    if (p_app_value->is_timestamp_supported)
    {
        /* Set the bit */
        p_gatt_value->p_value[0] |= BLE_BCS_PRV_BODY_COMPOSITION_FEATURE_TIME_STAMP_SUPPORTED;
    }

    /* Multiple Users feature */
    if (p_app_value->is_multiple_users_supported)
    {
        /* Set the bit */
        p_gatt_value->p_value[0] |= BLE_BCS_PRV_BODY_COMPOSITION_FEATURE_MULTIPLE_USERS_SUPPORTED;
    }

    /* Basal Metabolism */
    if (p_app_value->is_basal_metabolism_supported)
    {
        /* Set the bit */
        p_gatt_value->p_value[0] |=
                BLE_BCS_PRV_BODY_COMPOSITION_FEATURE_BASAL_METABOLISM_SUPPORTED;
    }

    /* Muscle Percentage */
    if (p_app_value->is_muscle_percentage_supported)
    {
        /* Set the bit */
        p_gatt_value->p_value[0] |=
                BLE_BCS_PRV_BODY_COMPOSITION_FEATURE_MUSCLE_PERCENTAGE_SUPPORTED;
    }

    /* Muscle Mass */
    if (p_app_value->is_muscle_mass_supported)
    {
        /* Set the bit */
        p_gatt_value->p_value[0] |= BLE_BCS_PRV_BODY_COMPOSITION_FEATURE_MUSCLE_MASS_SUPPORTED;
    }

    /* Fat Free Mass */
    if (p_app_value->is_fat_free_mass_supported)
    {
        /* Set the bit */
        p_gatt_value->p_value[0] |= BLE_BCS_PRV_BODY_COMPOSITION_FEATURE_FAT_FREE_MASS_SUPPORTED;
    }

    /* Soft Lean Mass */
    if (p_app_value->is_soft_lean_mass_supported)
    {
        /* Set the bit */
        p_gatt_value->p_value[0] |= BLE_BCS_PRV_BODY_COMPOSITION_FEATURE_SOFT_LEAN_MASS_SUPPORTED;
    }

    /* Body Water Mass */
    if (p_app_value->is_body_water_mass_supported)
    {
        /* Set the bit */
        p_gatt_value->p_value[0] |= BLE_BCS_PRV_BODY_COMPOSITION_FEATURE_BODY_WATER_MASS_SUPPORTED;
    }

    /* Impedance */
    if (p_app_value->is_impedance_supported)
    {
        /* Set the bit */
        p_gatt_value->p_value[1] |= (BLE_BCS_PRV_BODY_COMPOSITION_FEATURE_IMPEDANCE_SUPPORTED >> 8);
    }

    /* Weight */
    if (p_app_value->is_weight_supported)
    {
        /* Set the bit */
        p_gatt_value->p_value[1] |= (BLE_BCS_PRV_BODY_COMPOSITION_FEATURE_WEIGHT_SUPPORTED >> 8);

        /* mass_measurement_resolution */
        p_gatt_value->p_value[1] |= ((p_app_value->mass_measurement_resolution & 0xF) << 0x3);
    }

    /* Height */
    if (p_app_value->is_height_supported)
    {
        /* Set the bit */
        p_gatt_value->p_value[1] |= (BLE_BCS_PRV_BODY_COMPOSITION_FEATURE_HEIGHT_SUPPORTED >> 8);

        /* height_measurement_resolution */
        p_gatt_value->p_value[1] |= ((p_app_value->height_measurement_resolution & 0x1) << 7);
        p_gatt_value->p_value[2] = ((p_app_value->height_measurement_resolution >> 1) && 0x3);
    }

    p_gatt_value->value_len = BLE_BCS_BODY_COMPOSITION_FEATURE_LEN;

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: decode_body_composition_feature
 * Description  : This function converts Body Composition Feature characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the Body Composition Feature value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_body_composition_feature(st_ble_bcs_body_composition_feature_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    /* Convert byte sequence to application data. */
    uint32_t bcs_feature = 0;

    if (BLE_BCS_BODY_COMPOSITION_FEATURE_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    memset(p_app_value, 0x0, sizeof(st_ble_bcs_body_composition_feature_t));
    
    BT_UNPACK_LE_4_BYTE(&bcs_feature, &p_gatt_value->p_value[0]);

    /* Time Stamp Supported bit */
    if (bcs_feature & BLE_BCS_PRV_BODY_COMPOSITION_FEATURE_TIME_STAMP_SUPPORTED)
    {
        p_app_value->is_timestamp_supported = true;
    }
    else
    {
        p_app_value->is_timestamp_supported = false;
    }

    /* Multiple Users Supported bit */
    if (bcs_feature & BLE_BCS_PRV_BODY_COMPOSITION_FEATURE_MULTIPLE_USERS_SUPPORTED)
    {
        p_app_value->is_multiple_users_supported = true;
    }
    else
    {
        p_app_value->is_multiple_users_supported = false;
    }

    /* Basal Metabolism Supported bit */
    if (bcs_feature & BLE_BCS_PRV_BODY_COMPOSITION_FEATURE_BASAL_METABOLISM_SUPPORTED)
    {
        p_app_value->is_basal_metabolism_supported = true;
    }
    else
    {
        p_app_value->is_basal_metabolism_supported = false;
    }

    /* Muscle Percentage Supported bit */
    if (bcs_feature & BLE_BCS_PRV_BODY_COMPOSITION_FEATURE_MUSCLE_PERCENTAGE_SUPPORTED)
    {
        p_app_value->is_muscle_percentage_supported = true;
    }
    else
    {
        p_app_value->is_muscle_percentage_supported = false;
    }

    /* Muscle Mass Supported bit */
    if (bcs_feature & BLE_BCS_PRV_BODY_COMPOSITION_FEATURE_MUSCLE_MASS_SUPPORTED)
    {
        p_app_value->is_muscle_mass_supported = true;
    }
    else
    {
        p_app_value->is_muscle_mass_supported = false;
    }

    /* Fat Free Mass Supported bit */
    if (bcs_feature & BLE_BCS_PRV_BODY_COMPOSITION_FEATURE_FAT_FREE_MASS_SUPPORTED)
    {
        p_app_value->is_fat_free_mass_supported = true;
    }
    else
    {
        p_app_value->is_fat_free_mass_supported = false;
    }

    /* Soft Lean Mass Supported bit */
    if (bcs_feature & BLE_BCS_PRV_BODY_COMPOSITION_FEATURE_SOFT_LEAN_MASS_SUPPORTED)
    {
        p_app_value->is_soft_lean_mass_supported = true;
    }
    else
    {
        p_app_value->is_soft_lean_mass_supported = false;
    }

    /* Body Water Mass Supported */
    if (bcs_feature & BLE_BCS_PRV_BODY_COMPOSITION_FEATURE_BODY_WATER_MASS_SUPPORTED)
    {
        p_app_value->is_body_water_mass_supported = true;
    }
    else
    {
        p_app_value->is_body_water_mass_supported = false;
    }

    /* Impedance Supported bit */
    if (bcs_feature & BLE_BCS_PRV_BODY_COMPOSITION_FEATURE_IMPEDANCE_SUPPORTED)
    {
        p_app_value->is_impedance_supported = true;
    }
    else
    {
        p_app_value->is_impedance_supported = false;
    }

    /* Weight Supported bit and Weight Resolution */
    if (bcs_feature & BLE_BCS_PRV_BODY_COMPOSITION_FEATURE_WEIGHT_SUPPORTED)
    {
        p_app_value->is_weight_supported = true;
        p_app_value->mass_measurement_resolution = (p_gatt_value->p_value[1] >> 3) & 0xF;
    }
    else
    {
        p_app_value->is_weight_supported = false;
        p_app_value->mass_measurement_resolution = 0;
    }

    /* Height Supported bit and Height Resolution */
    if (bcs_feature & BLE_BCS_PRV_BODY_COMPOSITION_FEATURE_HEIGHT_SUPPORTED)
    {
        p_app_value->is_height_supported = true;
        p_app_value->height_measurement_resolution = ((p_gatt_value->p_value[1] >> 7) & 0x1);
        p_app_value->height_measurement_resolution |= ((p_gatt_value->p_value[2] & 0x3) << 1);
    }
    else
    {
        p_app_value->is_height_supported           = false;
        p_app_value->height_measurement_resolution = 0;
    }

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_body_composition_measurement
 * Description  : This function converts Body Composition Measurement characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the Body Composition Measurement  value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_body_composition_measurement(const st_ble_bcs_body_composition_measurement_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    /* Convert application data to byte sequence. */
    uint8_t  pos  = 2;
    uint16_t flag = 0;

    st_ble_bcs_body_composition_feature_t bcs_feature = { 0 };

    /* Clear the gatt structure */
    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    /* Copy the Measurement structure to local structure */
    memcpy(&gs_bcs_measurement_continuous_packet, p_app_value, sizeof(st_ble_bcs_body_composition_measurement_t));
    gs_continous_packet_present = false;

    R_BLE_BCS_GetBodyCompositionFeature(&bcs_feature);

    /* Measurement Units Bit */
    if (p_app_value->is_measurement_in_imperial_units)
    {
        flag |= BLE_BCS_BODY_COMPOSITION_MEASUREMENT_FLAGS_MEASUREMENT_UNITS;
    }

    /* Copy Body Fat Percentage */
    BT_PACK_LE_2_BYTE(&(p_gatt_value->p_value[pos]), &(p_app_value->body_fat_percentage));
    pos += (sizeof(p_app_value->body_fat_percentage));

    /* Timestamp Present Bit */
    if (p_app_value->is_timestamp_present && bcs_feature.is_timestamp_supported)
    {
        flag |= BLE_BCS_BODY_COMPOSITION_MEASUREMENT_FLAGS_TIME_STAMP_PRESENT;
        
        /* Copy the timestamp */
        BT_PACK_LE_2_BYTE(&(p_gatt_value->p_value[pos]), &(p_app_value->time_stamp.year));
        pos += (sizeof(p_app_value->time_stamp.year));

        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->time_stamp.month));
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->time_stamp.day));
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->time_stamp.hours));
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->time_stamp.minutes));
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->time_stamp.seconds));
    }

    /* User ID Present Bit */
    if (p_app_value->is_user_id_present && bcs_feature.is_multiple_users_supported)
    {
        flag |= BLE_BCS_BODY_COMPOSITION_MEASUREMENT_FLAGS_USER_ID_PRESENT;

        /* Copy the User ID*/
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->user_id));
    }
    
    /* Basal Metabolism Present Bit */
    if (p_app_value->is_basal_metabolism_present && bcs_feature.is_basal_metabolism_supported)
    {
        flag |= BLE_BCS_BODY_COMPOSITION_MEASUREMENT_FLAGS_BASAL_METABOLISM_PRESENT;

        /* Copy the Basal Metabolism Value */
        BT_PACK_LE_2_BYTE(&(p_gatt_value->p_value[pos]), &(p_app_value->basal_metabolism));
        pos += (sizeof(p_app_value->basal_metabolism));
    }

    /* Muscle Percentage present or not */
    if (p_app_value->is_muscle_percentage_present && bcs_feature.is_muscle_percentage_supported)
    {
        flag |= BLE_BCS_BODY_COMPOSITION_MEASUREMENT_FLAGS_MUSCLE_PERCENTAGE_PRESENT;

        /* Copy Muscle Percentage */
        BT_PACK_LE_2_BYTE(&(p_gatt_value->p_value[pos]), &(p_app_value->muscle_percentage));
        pos += (sizeof(p_app_value->muscle_percentage));
    }

    /*  Muscle Mass present or not */
    if (p_app_value->is_muscle_mass_present && bcs_feature.is_muscle_mass_supported)
    {
        flag |= BLE_BCS_BODY_COMPOSITION_MEASUREMENT_FLAGS_MUSCLE_MASS_PRESENT;

        /* Copy the Muscle Mass */
        BT_PACK_LE_2_BYTE(&(p_gatt_value->p_value[pos]), &(p_app_value->muscle_mass));
        pos += (sizeof(p_app_value->muscle_mass));
    }

    /* Fat Free Mass present or not */
    if (p_app_value->is_fat_free_mass_present && bcs_feature.is_fat_free_mass_supported)
    {
        flag |= BLE_BCS_BODY_COMPOSITION_MEASUREMENT_FLAGS_FAT_FREE_MASS_PRESENT;

        /* Copy the Fat Free Mass */
        BT_PACK_LE_2_BYTE(&(p_gatt_value->p_value[pos]), &(p_app_value->fat_free_mass));
        pos += (sizeof(p_app_value->fat_free_mass));
    }

    check_bcs_measurement_packet_length(p_gatt_value->value_len, pos, flag);

    /* Soft Lean Mass present or not */
    if (((!gs_continous_packet_present) && p_app_value->is_soft_lean_mass_present)
        && bcs_feature.is_soft_lean_mass_supported)
    {
        flag |= BLE_BCS_BODY_COMPOSITION_MEASUREMENT_FLAGS_SOFT_LEAN_MASS_PRESENT;

        /* Copy the Soft Lean Mass */
        BT_PACK_LE_2_BYTE(&(p_gatt_value->p_value[pos]), &(p_app_value->soft_lean_mass));
        pos += (sizeof(p_app_value->soft_lean_mass));

        check_bcs_measurement_packet_length(p_gatt_value->value_len, pos, flag);
    }

    /*  Body Water Mass present or not */
    if ((!gs_continous_packet_present) && p_app_value->is_body_water_mass_present && bcs_feature.is_body_water_mass_supported)
    {
        flag |= BLE_BCS_BODY_COMPOSITION_MEASUREMENT_FLAGS_BODY_WATER_MASS_PRESENT;

        /* Copy the Body Water Mass */
        BT_PACK_LE_2_BYTE(&(p_gatt_value->p_value[pos]), &(p_app_value->body_water_mass));
        pos += (sizeof(p_app_value->body_water_mass));

        check_bcs_measurement_packet_length(p_gatt_value->value_len, pos, flag);
    }

    /*  Impedance present or not */
    if ((!gs_continous_packet_present) && p_app_value->is_impedance_present && bcs_feature.is_impedance_supported)
    {
        flag |= BLE_BCS_BODY_COMPOSITION_MEASUREMENT_FLAGS_IMPEDANCE_PRESENT;

        /* Copy the Impedance */
        BT_PACK_LE_2_BYTE(&(p_gatt_value->p_value[pos]), &(p_app_value->impedance));
        pos += (sizeof(p_app_value->impedance));

        check_bcs_measurement_packet_length(p_gatt_value->value_len, pos, flag);
    }

    /* Weight present or not */
    if ((!gs_continous_packet_present) && p_app_value->is_weight_present && bcs_feature.is_weight_supported)
    {
        flag |= BLE_BCS_BODY_COMPOSITION_MEASUREMENT_FLAGS_WEIGHT_PRESENT;

        /* Copy the Weight */
        BT_PACK_LE_2_BYTE(&(p_gatt_value->p_value[pos]), &(p_app_value->weight));
        pos += (sizeof(p_app_value->weight));

        check_bcs_measurement_packet_length(p_gatt_value->value_len, pos, flag);
    }

    /* Height Supported or not */
    if ((!gs_continous_packet_present) && p_app_value->is_height_present && bcs_feature.is_height_supported)
    {
        flag |= BLE_BCS_BODY_COMPOSITION_MEASUREMENT_FLAGS_HEIGHT_PRESENT;

        /* Copy the Weight */
        BT_PACK_LE_2_BYTE(&(p_gatt_value->p_value[pos]), &(p_app_value->height));
        pos += (sizeof(p_app_value->height));

        check_bcs_measurement_packet_length(p_gatt_value->value_len, pos, flag);
    }

    /* Multiple Packet Measurement */
    if (p_app_value->is_multiple_packet_measurement_present || gs_continous_packet_present)
    {
        flag |= BLE_BCS_BODY_COMPOSITION_MEASUREMENT_FLAGS_MULTIPLE_PACKET_MEASUREMENT;
    }

    BT_PACK_LE_2_BYTE(&(p_gatt_value->p_value[0]), &flag);
    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}


/***********************************************************************************************************************
 * Function Name: bcs_gatt_db_cb
 * Description  : Callback function for Body Composition GATT Server events.
 * Arguments    : conn_hdl - handle to the connection
 *                p_params - pointer to GATTS db parameter
 * Return Value : none
 **********************************************************************************************************************/
static void bcs_gatts_db_cb(uint16_t conn_hdl, st_ble_gatts_db_params_t *p_params) // @suppress("Function length")
{
    switch (p_params->db_op)
    {
        case BLE_GATTS_OP_CHAR_PEER_CLI_CNFG_WRITE_REQ:
        {
            uint16_t cli_cnfg;

            st_ble_bcs_evt_data_t evt_data = 
            {
                .conn_hdl  = conn_hdl,
                .param_len = 0,
                .p_param   = NULL,
            };

            BT_UNPACK_LE_2_BYTE(&cli_cnfg, p_params->value.p_value);

            if (BLE_BCS_BODY_COMPOSITION_MEASUREMENT_CLI_CNFG_DESC_HDL == p_params->attr_hdl)
            {
                if (BLE_GATTS_CLI_CNFG_INDICATION == cli_cnfg)
                {
                    gs_bcs_cb(BLE_BCS_EVENT_BODY_COMPOSITION_MEASUREMENT_CLI_CNFG_ENABLED, BLE_SUCCESS, &evt_data);
                }
                else
                {
                    gs_bcs_cb(BLE_BCS_EVENT_BODY_COMPOSITION_MEASUREMENT_CLI_CNFG_DISABLED, BLE_SUCCESS, &evt_data);
                }
            }
        } 
        break;

        default:
        {
            /* Do nothing. */
        } 
        break;
    }
}

/***********************************************************************************************************************
 * Function Name: bcs_gatts_cb
 * Description  : Callback function for the GATT Server events.
 * Arguments    : type - event id
 *                result - ble status
 *                p_data - pointer to the event data
 * Return Value : none
 **********************************************************************************************************************/
static void bcs_gatts_cb(uint16_t type, ble_status_t result, st_ble_gatts_evt_data_t *p_data)
{
    switch (type)
    {
        case BLE_GATTS_EVENT_DB_ACCESS_IND:
        {
            st_ble_gatts_db_access_evt_t *p_db_access_evt_param =
                (st_ble_gatts_db_access_evt_t *)p_data->p_param;

            bcs_gatts_db_cb(p_data->conn_hdl, p_db_access_evt_param->p_params);
        } 
        break;

        case BLE_GATTS_EVENT_HDL_VAL_CNF:
        {
            st_ble_gatts_cfm_evt_t *p_cfm_evt_param =
                (st_ble_gatts_cfm_evt_t *)p_data->p_param;

            if (BLE_BCS_BODY_COMPOSITION_MEASUREMENT_VAL_HDL == p_cfm_evt_param->attr_hdl)
            {
                if (gs_continous_packet_present)
                {
                    /* Send the second packet */
                    R_BLE_BCS_IndicateBodyCompositionMeasurement(p_data->conn_hdl, &gs_bcs_measurement_continuous_packet);
                    gs_continous_packet_present = false;
                }
                else
                {
                    st_ble_bcs_evt_data_t evt_data = 
                    {
                        .conn_hdl  = p_data->conn_hdl,
                        .param_len = 0,
                        .p_param   = NULL,
                    };
                    gs_bcs_cb(BLE_BCS_EVENT_BODY_COMPOSITION_MEASUREMENT_HDL_VAL_CNF, result, &evt_data);
                }
            }
        } 
        break;

        default:
        {
            /* Do nothing. */
        } 
        break;
    }
}

ble_status_t R_BLE_BCS_Init(const st_ble_bcs_init_param_t *p_param) // @suppress("API function naming")
{
    if (NULL == p_param)
    {
        return BLE_ERR_INVALID_PTR;
    }

    if (NULL == p_param->cb)
    {
        return BLE_ERR_INVALID_ARG;
    }

    R_BLE_GATTS_RegisterCb(bcs_gatts_cb, 2);

    gs_bcs_cb = p_param->cb;

    return BLE_SUCCESS;
}

ble_status_t R_BLE_BCS_Connect(uint16_t conn_hdl, const st_ble_bcs_connect_param_t *p_param) // @suppress("API function naming")
{
    if (BLE_GAP_INVALID_CONN_HDL == conn_hdl)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (NULL != p_param)
    {
        set_cli_cnfg(conn_hdl, BLE_BCS_BODY_COMPOSITION_MEASUREMENT_CLI_CNFG_DESC_HDL, p_param->body_composition_measurement_cli_cnfg);
    }

    return BLE_SUCCESS;
}

ble_status_t R_BLE_BCS_Disconnect(uint16_t conn_hdl, st_ble_bcs_disconnect_param_t *p_param) // @suppress("API function naming")
{
    if (BLE_GAP_INVALID_CONN_HDL == conn_hdl)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (NULL != p_param)
    {
        get_cli_cnfg(conn_hdl, BLE_BCS_BODY_COMPOSITION_MEASUREMENT_CLI_CNFG_DESC_HDL, &p_param->body_composition_measurement_cli_cnfg);
    }

    return BLE_SUCCESS;
}

ble_status_t R_BLE_BCS_GetBodyCompositionFeature(st_ble_bcs_body_composition_feature_t *p_app_value) // @suppress("API function naming")
{
    st_ble_gatt_value_t gatt_value;
    ble_status_t ret;

    if (NULL == p_app_value)
    {
        return BLE_ERR_INVALID_PTR;
    }

    ret = R_BLE_GATTS_GetAttr(BLE_GAP_INVALID_CONN_HDL, BLE_BCS_BODY_COMPOSITION_FEATURE_VAL_HDL, &gatt_value);

    if (BLE_SUCCESS == ret)
    {
        ret = decode_body_composition_feature(p_app_value, &gatt_value);
    }

    return ret;
}

ble_status_t R_BLE_BCS_SetBodyCompositionFeature(const st_ble_bcs_body_composition_feature_t *p_app_value) // @suppress("API function naming")
{
    uint8_t byte_value[BLE_BCS_BODY_COMPOSITION_FEATURE_LEN] = { 0 };
    ble_status_t ret;

    st_ble_gatt_value_t gatt_value = 
    {
        .p_value   = byte_value,
        .value_len = BLE_BCS_BODY_COMPOSITION_FEATURE_LEN,
    };

    encode_body_composition_feature(p_app_value, &gatt_value);

    return R_BLE_GATTS_SetAttr(BLE_GAP_INVALID_CONN_HDL, BLE_BCS_BODY_COMPOSITION_FEATURE_VAL_HDL, &gatt_value);
}

ble_status_t R_BLE_BCS_IndicateBodyCompositionMeasurement(uint16_t conn_hdl, const st_ble_bcs_body_composition_measurement_t *p_app_value) // @suppress("API function naming")
{
    ble_status_t ret;
    uint16_t cli_cnfg;
    uint16_t mtu;

    if (NULL == p_app_value)
    {
        return BLE_ERR_INVALID_PTR;
    }

    ret = get_cli_cnfg(conn_hdl, BLE_BCS_BODY_COMPOSITION_MEASUREMENT_CLI_CNFG_DESC_HDL, &cli_cnfg);
    if (BLE_SUCCESS != ret)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if ((cli_cnfg & BLE_GATTS_CLI_CNFG_INDICATION) == 0x0000)
    {
        return BLE_ERR_INVALID_STATE;
    }

    R_BLE_GATT_GetMtu(conn_hdl, &mtu);

    uint8_t byte_value[BLE_BCS_BODY_COMPOSITION_MEASUREMENT_LEN] = { 0 };

    st_ble_gatt_hdl_value_pair_t ind_data = 
    {
        .attr_hdl        = BLE_BCS_BODY_COMPOSITION_MEASUREMENT_VAL_HDL,
        .value.p_value   = byte_value,
        .value.value_len = MIN(BLE_BCS_BODY_COMPOSITION_MEASUREMENT_LEN, mtu),
    };

    encode_body_composition_measurement(p_app_value, &ind_data.value);
    
    return R_BLE_GATTS_Indication(conn_hdl, &ind_data);
}

uint32_t R_BLE_BCS_GetVersion(void) // @suppress("API function naming")
{
    uint32_t version;

    version = ((BLE_BCS_PRV_VERSION_MAJOR << 16) | (BLE_BCS_PRV_VERSION_MINOR << 8));

    return version;
}
