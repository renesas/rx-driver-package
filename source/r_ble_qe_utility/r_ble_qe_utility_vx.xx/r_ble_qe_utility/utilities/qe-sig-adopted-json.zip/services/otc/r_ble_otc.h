/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name   : r_ble_otc.h
 * Version     : 1.0
 * Description : The header file for Object Transfer Service client.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 29.05.2019 1.00 First Release
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @file
 * @defgroup otc Object Transfer Service Client
 * @{
 * @ingroup profile
 * @brief   This is the client for the Object Transfer Service Service.
 **********************************************************************************************************************/
#include "r_ble_rx23w_if.h"
#include "profile_cmn/r_ble_servc_if.h"

#ifndef R_BLE_OTC_H
#define R_BLE_OTC_H

//extern const uint8_t BLE_OTC_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/***********************************************************************************************************************
 Macro definitions
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
  * @brief OACP Create Op Code Supported bit
 ***********************************************************************************************************************/
#define BLE_OTC_PRV_OACP_CREATE_OP_CODE_SUPPORTED                                                       (1  << 0)

 /*******************************************************************************************************************//**
  * @brief OACP Delete Op Code Supported bit
 ***********************************************************************************************************************/
#define BLE_OTC_PRV_OACP_DELETE_OP_CODE_SUPPORTED                                                       (1 << 1)

 /*******************************************************************************************************************//**
  * @brief OACP Calculate Checksum Op Code Supported bit
 ***********************************************************************************************************************/
#define BLE_OTC_PRV_OACP_CALCULATE_CHECKSUM_OP_CODE_SUPPORTED                                           (1 << 2)

 /*******************************************************************************************************************//**
  * @brief OACP Execute Op Code Supported bit
 ***********************************************************************************************************************/
#define BLE_OTC_PRV_OACP_EXECUTE_OP_CODE_SUPPORTED                                                      (1 << 3)

 /*******************************************************************************************************************//**
  * @brief OACP Read Op Code Supported bit
 ***********************************************************************************************************************/
#define BLE_OTC_PRV_OACP_READ_OP_CODE_SUPPORTED                                                         (1 << 4)

 /*******************************************************************************************************************//**
  * @brief OACP Write Op Code Supported bit
 ***********************************************************************************************************************/
#define BLE_OTC_PRV_OACP_WRITE_OP_CODE_SUPPORTED                                                        (1 << 5)

 /*******************************************************************************************************************//**
  * @brief Appending Additional Data to Objects Supported bit
 ***********************************************************************************************************************/
#define BLE_OTC_PRV_APPENDING_ADDITIONAL_DATA_TO_OBJECTS_SUPPORTED                                      (1 << 6)

 /*******************************************************************************************************************//**
  * @brief Truncation of Objects Supported bit
 ***********************************************************************************************************************/
#define BLE_OTC_PRV_TRUNCATION_OF_OBJECTS_SUPPORTED                                                     (1 << 7)

 /*******************************************************************************************************************//**
  * @brief Patching of Objects Supported bit
 ***********************************************************************************************************************/
#define BLE_OTC_PRV_PATCHING_OF_OBJECTS_SUPPORTED                                                       (1 << 8)

 /*******************************************************************************************************************//**
  * @brief OACP Abort Op Code Supported bit
 ***********************************************************************************************************************/
#define BLE_OTC_PRV_OACP_ABORT_OP_CODE_SUPPORTED                                                        (1 << 9)

 /*******************************************************************************************************************//**
  * @brief OLCP Go To Op Code Supported bit
 ***********************************************************************************************************************/
#define BLE_OTC_PRV_OLCP_GO_TO_OP_CODE_SUPPORTED                                                        (1 << 0)

 /*******************************************************************************************************************//**
  * @brief OLCP Order Op Code Supported bit
 ***********************************************************************************************************************/
#define BLE_OTC_PRV_OLCP_ORDER_OP_CODE_SUPPORTED                                                        (1 << 1)

 /*******************************************************************************************************************//**
  * @brief OLCP Request Number of Objects Op Code Supported bit
 ***********************************************************************************************************************/
#define BLE_OTC_PRV_OLCP_REQUEST_NUMBER_OF_OBJECTS_OP_CODE_SUPPORTED                                    (1 << 2)

 /*******************************************************************************************************************//**
  * @brief OLCP Clear Marking Op Code Supported bit
 ***********************************************************************************************************************/
#define BLE_OTC_PRV_OLCP_CLEAR_MARKING_OP_CODE_SUPPORTED                                                (1 << 3)

 /*******************************************************************************************************************//**
  * @brief Deletion of this object is permitted bit
 ***********************************************************************************************************************/
#define BLE_OTC_PRV_DELETION_OF_THIS_OBJECT_IS_PERMITTED                                                (1 << 0)

 /*******************************************************************************************************************//**
  * @brief Execution of this object is permitted bit
 ***********************************************************************************************************************/
#define BLE_OTC_PRV_EXECUTION_OF_THIS_OBJECT_IS_PERMITTED                                               (1 << 1)

 /*******************************************************************************************************************//**
  * @brief Reading this object is permitted bit
 ***********************************************************************************************************************/
#define BLE_OTC_PRV_READING_THIS_OBJECT_IS_PERMITTED                                                    (1 << 2)

 /*******************************************************************************************************************//**
  * @brief Writing data to this object is permitted bit
 ***********************************************************************************************************************/
#define BLE_OTC_PRV_WRITING_DATA_TO_THIS_OBJECT_IS_PERMITTED                                            (1 << 3)

 /*******************************************************************************************************************//**
  * @brief Appending data to this object is permitted bit
 ***********************************************************************************************************************/
#define BLE_OTC_PRV_APPENDING_DATA_THAT_INCREASES_OBJ_ALLOCATED_SIZE_IS_PERMITTED                       (1 << 4)

 /*******************************************************************************************************************//**
  * @brief Truncation of this object is permitted bit
 ***********************************************************************************************************************/
#define BLE_OTC_PRV_TRUNCATION_OF_THIS_OBJECT_IS_PERMITTED                                              (1 << 5)

 /*******************************************************************************************************************//**
  * @brief Patching this object by overwriting is permitted bit
 ***********************************************************************************************************************/
#define BLE_OTC_PRV_PATCHING_BY_OVERWRITING_OBJECT_EXISTING_CONTENTS_IS_PERMITTED                       (1 << 6)

 /*******************************************************************************************************************//**
  * @brief This object is a marked object bit
 ***********************************************************************************************************************/
#define BLE_OTC_PRV_THIS_OBJECT_IS_A_MARKED_OBJECT                                                      (1 << 7)

 /*******************************************************************************************************************//**
   * @brief Source of change bit
  ***********************************************************************************************************************/
#define BLE_OTC_PRV_SOURCE_OF_CHANGE                                                                    (1 << 0)

 /*******************************************************************************************************************//**
   * @brief Change occured to the object contents bit
 ***********************************************************************************************************************/
#define BLE_OTC_PRV_CHANGE_OCCURRED_TO_THE_OBJECT_CONTENTS                                              (1 << 1)

 /*******************************************************************************************************************//**
    * @brief Change occured to the object metadata bit
  ***********************************************************************************************************************/
#define BLE_OTC_PRV_CHANGE_OCCURRED_TO_THE_OBJECT_METADATA                                              (1 << 2)

  /*******************************************************************************************************************//**
     * @brief Object creation bit
   ***********************************************************************************************************************/
#define BLE_OTC_PRV_OBJECT_CREATION                                                                     (1 << 3)

   /*******************************************************************************************************************//**
      * @brief Object deletion bit
    ***********************************************************************************************************************/
#define BLE_OTC_PRV_OBJECT_DELETION                                                                     (1 << 4)


typedef struct {
    uint16_t uuid_16;
    uint8_t uuid_128[16];
}st_ble_otc_uuid_value_t;

typedef struct {
    uint8_t uuid_type;
    st_ble_otc_uuid_value_t uuid;
}st_ble_otc_uuid_t;

/*----------------------------------------------------------------------------------------------------------------------
    OTS Feature Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_OTC_FEAT_UUID (0x2ABD)
#define BLE_OTC_FEAT_LEN (8)
/***************************************************************************//**
 * @brief OTS Feature OACP Features value structure.
*******************************************************************************/
typedef struct {
    bool is_oacp_create_op_code_supported; /**< OACP Create Op Code Supported */
    bool is_oacp_delete_op_code_supported; /**< OACP Delete Op Code Supported */
    bool is_oacp_calculate_checksum_op_code_supported; /**< OACP Calculate Checksum Op Code Supported */
    bool is_oacp_execute_op_code_supported; /**< OACP Execute Op Code Supported */
    bool is_oacp_read_op_code_supported; /**< OACP Read Op Code Supported */
    bool is_oacp_write_op_code_supported; /**< OACP Write Op Code Supported */
    bool is_appending_additional_data_to_objects_supported; /**< Appending Additional Data to Objects Supported */
    bool is_truncation_of_objects_supported; /**< Truncation of Objects Supported */
    bool is_patching_of_objects_supported; /**< Patching of Objects Supported */
    bool is_oacp_abort_op_code_supported; /**< OACP Abort Op Code Supported */
} st_ble_lnc_feat_oacp_features_t;

/***************************************************************************//**
 * @brief OTS Feature OLCP Features value structure.
*******************************************************************************/
typedef struct {
    bool is_olcp_go_to_op_code_supported; /**< OLCP Go To Op Code Supported */
    bool is_olcp_order_op_code_supported; /**< OLCP Order Op Code Supported */
    bool is_olcp_request_number_of_objects_op_code_supported; /**< OLCP Request Number of Objects Op Code Supported */
    bool is_olcp_clear_marking_op_code_supported; /**< OLCP Clear Marking Op Code Supported */
} st_ble_lnc_feat_olcp_features_t;

/***************************************************************************//**
 * @brief OTS Feature value structure.
*******************************************************************************/
typedef struct {
    st_ble_lnc_feat_oacp_features_t oacp_features; /**< OACP Features */
    st_ble_lnc_feat_olcp_features_t olcp_features; /**< OLCP Features */
} st_ble_otc_feat_t;

/***************************************************************************//**
 * @brief OTS Feature attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
} st_ble_otc_feat_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read OTS Feature characteristic value from the remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_OTC_ReadFeat(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief      Get OTS Feature attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_OTC_GetFeatAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_otc_feat_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Object Name Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_OTC_OBJ_NAME_UUID (0x2ABE)
#define BLE_OTC_OBJ_NAME_LEN (100)
/***************************************************************************//**
 * @brief Object Name attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
} st_ble_otc_obj_name_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Object Name characteristic value from the remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_OTC_ReadObjName(uint16_t conn_hdl, int32_t type);

/***************************************************************************//**
 * @brief     Write Object Name characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] p_value Object Name characteristic value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_OTC_WriteObjName(uint16_t conn_hdl, const st_ble_seq_data_t *p_value);
;
/***************************************************************************//**
 * @brief      Get Object Name attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_OTC_GetObjNameAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_otc_obj_name_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Object Type Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_OTC_OBJ_TYPE_UUID (0x2ABF)
#define BLE_OTC_OBJ_TYPE_LEN (16)
/***************************************************************************//**
 * @brief Object Type attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
} st_ble_otc_obj_type_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Object Type characteristic value from the remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_OTC_ReadObjType(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief      Get Object Type attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_OTC_GetObjTypeAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_otc_obj_type_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Object Size Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_OTC_OBJ_SIZE_UUID (0x2AC0)
#define BLE_OTC_OBJ_SIZE_LEN (8)
/***************************************************************************//**
 * @brief Object Size value structure.
*******************************************************************************/
typedef struct {
    uint32_t current_size; /**< Current Size */
    uint32_t allocated_size; /**< Allocated Size */
} st_ble_otc_obj_size_t;

/***************************************************************************//**
 * @brief Object Size attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
} st_ble_otc_obj_size_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Object Size characteristic value from the remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_OTC_ReadObjSize(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief      Get Object Size attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_OTC_GetObjSizeAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_otc_obj_size_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Object First-Created Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_OTC_OBJ_FIRST_CREATED_UUID (0x2AC1)
#define BLE_OTC_OBJ_FIRST_CREATED_LEN  (7)
/***************************************************************************//**
 * @brief Object First-Created attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
} st_ble_otc_obj_first_created_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Object First-Created characteristic value from the remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_OTC_ReadObjFirstCreated(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Object First-Created characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] p_value Object First-Created characteristic value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_OTC_WriteObjFirstCreated(uint16_t conn_hdl, const st_ble_date_time_t *p_value);
;
/***************************************************************************//**
 * @brief      Get Object First-Created attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_OTC_GetObjFirstCreatedAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_otc_obj_first_created_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Object Last-Modified Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_OTC_OBJ_LAST_MODIFIED_UUID (0x2AC2)
#define BLE_OTC_OBJ_LAST_MODIFIED_LEN  (7)
/***************************************************************************//**
 * @brief Object Last-Modified attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
} st_ble_otc_obj_last_modified_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Object Last-Modified characteristic value from the remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_OTC_ReadObjLastModified(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Object Last-Modified characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] p_value Object Last-Modified characteristic value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_OTC_WriteObjLastModified(uint16_t conn_hdl, const st_ble_date_time_t *p_value);
;
/***************************************************************************//**
 * @brief      Get Object Last-Modified attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_OTC_GetObjLastModifiedAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_otc_obj_last_modified_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Object ID Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_OTC_OBJ_ID_UUID (0x2AC3)
#define BLE_OTC_OBJ_ID_LEN  (6)
/***************************************************************************//**
 * @brief Object ID Object ID enumeration.
*******************************************************************************/
typedef enum {
    BLE_OTC_OBJ_ID_OBJECT_ID_RESERVED_FOR_THE_DIRECTORY_LISTING_OBJECT = 0, /**< Reserved for the Directory Listing Object */
} e_ble_otc_obj_id_object_id_t;

/***************************************************************************//**
 * @brief Object ID attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
} st_ble_otc_obj_id_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Object ID characteristic value from the remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_OTC_ReadObjId(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief      Get Object ID attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_OTC_GetObjIdAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_otc_obj_id_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Object Properties Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_OTC_OBJ_PROP_UUID (0x2AC4)
#define BLE_OTC_OBJ_PROP_LEN  (4)
/***************************************************************************//**
 * @brief Object Properties value structure.
*******************************************************************************/
typedef struct {
    bool is_deletion_of_this_object_is_permitted; /**< Deletion of this object is permitted */
    bool is_execution_of_this_object_is_permitted; /**< Execution of this object is permitted */
    bool is_reading_this_object_is_permitted; /**< Reading this object is permitted */
    bool is_writing_data_to_this_object_is_permitted; /**< Writing data to this object is permitted */
    bool is_appending_data_to_this_object_that_increases_its_allocated_size_is_permitted; /**< Appending data to this object that increases its Allocated Size is permitted */
    bool is_truncation_of_this_object_is_permitted; /**< Truncation of this object is permitted */
    bool is_patching_this_object_by_overwriting_some_of_the_object_s_existing_contents_is_permitted; /**< Patching this object by overwriting some of the object's existing contents is permitted */
    bool is_this_object_is_a_marked_object; /**< This object is a marked object */
} st_ble_otc_obj_prop_t;

/***************************************************************************//**
 * @brief Object Properties attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
} st_ble_otc_obj_prop_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Object Properties characteristic value from the remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_OTC_ReadObjProp(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Object Properties characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] p_value Object Properties characteristic value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_OTC_WriteObjProp(uint16_t conn_hdl, const st_ble_otc_obj_prop_t *p_value);
;
/***************************************************************************//**
 * @brief      Get Object Properties attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_OTC_GetObjPropAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_otc_obj_prop_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Object Action Control Point Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_OTC_OBJ_ACTION_CP_UUID (0x2AC5)
#define BLE_OTC_OBJ_ACTION_CP_LEN (21)
#define BLE_OTC_OBJ_ACTION_CP_CLI_CNFG_UUID (0x2902)
#define BLE_OTC_OBJ_ACTION_CP_CLI_CNFG_LEN (2)

/***************************************************************************//**
 * @brief Object Action Control Point Op Code enumeration.
*******************************************************************************/
typedef enum {
    BLE_OTC_OBJ_ACTION_CP_OP_CODE_CREATE = 1, /**< Create a new, empty object */
    BLE_OTC_OBJ_ACTION_CP_OP_CODE_DELETE = 2, /**< Delete the Current Object */
    BLE_OTC_OBJ_ACTION_CP_OP_CODE_CALCULATE_CHECKSUM = 3, /**< Compare a checksum */
    BLE_OTC_OBJ_ACTION_CP_OP_CODE_EXECUTE = 4, /**< Use the Current Object to perform an operation */
    BLE_OTC_OBJ_ACTION_CP_OP_CODE_READ = 5, /**< Send object data through Object Transfer Channel */
    BLE_OTC_OBJ_ACTION_CP_OP_CODE_WRITE = 6, /**< Open the Current Object for writing and prepare to accept data */
    BLE_OTC_OBJ_ACTION_CP_OP_CODE_ABORT = 7, /**< Cease sending previously requested data through Object Transfer Channel */
    BLE_OTC_OBJ_ACTION_CP_OP_CODE_RESPONSE_CODE = 96, /**< Used to identify the response to this Control Point */
} e_ble_otc_obj_action_cp_op_code_t;

/***************************************************************************//**
 * @brief Object Action Control Point Result Code enumeration.
*******************************************************************************/
typedef enum {
    BLE_OTC_OBJ_ACTION_CP_RESULT_CODE_SUCCESS = 1, /**< Response for successful operation */
    BLE_OTC_OBJ_ACTION_CP_RESULT_CODE_OP_CODE_NOT_SUPPORTED = 2, /**< Response if unsupported Op Code is received */
    BLE_OTC_OBJ_ACTION_CP_RESULT_CODE_INVALID_PARAMETER = 3, /**< Parameter received does not meet the requirements */
    BLE_OTC_OBJ_ACTION_CP_RESULT_CODE_INSUFFICIENT_RESOURCES = 4, /**< Size parameter exceeds the available memory */
    BLE_OTC_OBJ_ACTION_CP_RESULT_CODE_INVALID_OBJECT = 5, /**< Current Object is an Invalid Object */
    BLE_OTC_OBJ_ACTION_CP_RESULT_CODE_CHANNEL_UNAVAILABLE = 6, /**< Object Transfer Channel was not available for use */
    BLE_OTC_OBJ_ACTION_CP_RESULT_CODE_UNSUPPORTED_TYPE = 7, /**< OACP procedure Type parameter is not supported by the Server */
    BLE_OTC_OBJ_ACTION_CP_RESULT_CODE_PROCEDURE_NOT_PERMITTED = 8, /**< Requested procedure is not permitted */
    BLE_OTC_OBJ_ACTION_CP_RESULT_CODE_OBJECT_LOCKED = 9, /**< Current Object is temporarily locked */
    BLE_OTC_OBJ_ACTION_CP_RESULT_CODE_OPERATION_FAILED = 10, /**< Operation Failed */
} e_ble_otc_obj_action_cp_result_code_t;

/***************************************************************************//**
 * @brief Object Action Control Point value structure.
*******************************************************************************/
typedef struct {
    uint8_t op_code; /**< Op Code */
    uint32_t size; /**< size */
    st_ble_otc_uuid_t type; /**< type */
    uint32_t offset; /**< offset */
    uint32_t length; /**< length */
    uint8_t mode; /**< mode */
    uint8_t request_op_code; /**< Request Op Code */
    uint8_t result_code; /**< Result Code */
    uint32_t response_parameter; /**< Response Parameter */
    uint8_t response_code; /* Response code */
} st_ble_otc_obj_action_cp_t;

/***************************************************************************//**
 * @brief Object Action Control Point attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
    uint16_t cli_cnfg_desc_hdl;
} st_ble_otc_obj_action_cp_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Object Action Control Point characteristic Client Characteristic Configuration descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_OTC_ReadObjActionCpCliCnfg(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Object Action Control Point characteristic Client Characteristic Configuration descriptor value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value Object Action Control Point characteristic Client Characteristic Configuration descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_OTC_WriteObjActionCpCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Write Object Action Control Point characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] p_value Object Action Control Point characteristic value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_OTC_WriteObjActionCp(uint16_t conn_hdl, const st_ble_otc_obj_action_cp_t *p_value);
;
/***************************************************************************//**
 * @brief      Get Object Action Control Point attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_OTC_GetObjActionCpAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_otc_obj_action_cp_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Object List Control Point Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_OTC_OBJ_LIST_CP_UUID (0x2AC6)
#define BLE_OTC_OBJ_LIST_CP_LEN (7)
#define BLE_OTC_OBJ_LIST_CP_CLI_CNFG_UUID (0x2902)
#define BLE_OTC_OBJ_LIST_CP_CLI_CNFG_LEN (2)

/***************************************************************************//**
 * @brief Object List Control Point Op Code enumeration.
*******************************************************************************/
typedef enum {
    BLE_OTC_OBJ_LIST_CP_OP_CODE_FIRST = 1, /**< Make the first object in the list become the Current Object */
    BLE_OTC_OBJ_LIST_CP_OP_CODE_LAST = 2, /**< Make the last object in the list become the Current Object */
    BLE_OTC_OBJ_LIST_CP_OP_CODE_PREVIOUS = 3, /**< Make the object immediately preceding the Current Object in the list become the Current Object */
    BLE_OTC_OBJ_LIST_CP_OP_CODE_NEXT = 4, /**< Make the object immediately after the Current Object in the list become the Current Object */
    BLE_OTC_OBJ_LIST_CP_OP_CODE_GO_TO = 5, /**< Select an object by specifying its Object ID */
    BLE_OTC_OBJ_LIST_CP_OP_CODE_ORDER = 6, /**< Arrange the list of objects in order */
    BLE_OTC_OBJ_LIST_CP_OP_CODE_REQUEST_NUMBER_OF_OBJECTS = 7, /**< Report the total number of objects */
    BLE_OTC_OBJ_LIST_CP_OP_CODE_CLEAR_MARKING = 8, /**< Update the marking of objects */
    BLE_OTC_OBJ_LIST_CP_OP_CODE_RESPONSE_CODE = 112, /**< Used to identify the response to this Control Point */
} e_ble_otc_obj_list_cp_op_code_t;

/***************************************************************************//**
 * @brief Object List Control Point Result Code enumeration.
*******************************************************************************/
typedef enum {
    BLE_OTC_OBJ_LIST_CP_RESULT_CODE_SUCCESS = 1, /**< Response for successful operation */
    BLE_OTC_OBJ_LIST_CP_RESULT_CODE_OP_CODE_NOT_SUPPORTED = 2, /**< Response if unsupported Op Code is received */
    BLE_OTC_OBJ_LIST_CP_RESULT_CODE_INVALID_PARAMETER = 3, /**< Parameter received does not meet the requirements */
    BLE_OTC_OBJ_LIST_CP_RESULT_CODE_OPERATION_FAILED = 4, /**< Requested procedure failed */
    BLE_OTC_OBJ_LIST_CP_RESULT_CODE_OUT_OF_BOUNDS = 5, /**< Selected object is beyond the first or last object in the current list */
    BLE_OTC_OBJ_LIST_CP_RESULT_CODE_TOO_MANY_OBJECTS = 6, /**< Procedure failed due to too many objects */
    BLE_OTC_OBJ_LIST_CP_RESULT_CODE_NO_OBJECT = 7, /**< Procedure failed due to there being zero objects in the current list */
    BLE_OTC_OBJ_LIST_CP_RESULT_CODE_OBJECT_ID_NOT_FOUND = 8, /**< Procedure failed due to there being no object with the requested Object ID */
} e_ble_otc_obj_list_cp_result_code_t;

/***************************************************************************//**
 * @brief Object List Control Point List Sort Order enumeration.
*******************************************************************************/
typedef enum {
    BLE_OTC_OBJ_LIST_CP_LIST_SORT_ORDER_ORDER_THE_LIST_BY_OBJECT_NAME__ASCENDING = 1, /**< Order the list by object name, ascending */
    BLE_OTC_OBJ_LIST_CP_LIST_SORT_ORDER_ORDER_THE_LIST_BY_OBJECT_TYPE__ASCENDING = 2, /**< Order the list by object name, ascending */
    BLE_OTC_OBJ_LIST_CP_LIST_SORT_ORDER_ORDER_THE_LIST_BY_OBJECT_CURRENT_SIZE__ASCENDING = 3, /**< Order the list by object current size, ascending */
    BLE_OTC_OBJ_LIST_CP_LIST_SORT_ORDER_ORDER_THE_LIST_BY_OBJECT_FIRST_CREATED_TIMESTAMP__ASCENDING = 4, /**< Order the list by object first-created timestamp, ascending */
    BLE_OTC_OBJ_LIST_CP_LIST_SORT_ORDER_ORDER_THE_LIST_BY_OBJECT_LAST_MODIFIED_TIMESTAMP__ASCENDING = 5, /**< Order the list by object last-modified timestamp, ascending */
    BLE_OTC_OBJ_LIST_CP_LIST_SORT_ORDER_ORDER_THE_LIST_BY_OBJECT_NAME__DESCENDING = 17, /**< Order the list by object name, descending */
    BLE_OTC_OBJ_LIST_CP_LIST_SORT_ORDER_ORDER_THE_LIST_BY_OBJECT_TYPE__DESCENDING = 18, /**< Order the list by object type, descending */
    BLE_OTC_OBJ_LIST_CP_LIST_SORT_ORDER_ORDER_THE_LIST_BY_OBJECT_CURRENT_SIZE__DESCENDING = 19, /**< Order the list by object current size, descending */
    BLE_OTC_OBJ_LIST_CP_LIST_SORT_ORDER_ORDER_THE_LIST_BY_OBJECT_FIRST_CREATED_TIMESTAMP__DESCENDING = 20, /**< Order the list by object first-created timestamp, descending */
    BLE_OTC_OBJ_LIST_CP_LIST_SORT_ORDER_ORDER_THE_LIST_BY_OBJECT_LAST_MODIFIED_TIMESTAMP__DESCENDING = 21, /**< Order the list by object last-modified timestamp, descending */
} e_ble_otc_obj_list_cp_list_sort_order_t;

/*----------------------------------------------------------------------------------------------------------------------
    Object List Control Point Characteristic
----------------------------------------------------------------------------------------------------------------------*/
/** Parameter Length */
#define BLE_OTC_OBJ_LIST_CP_PARAMETER_LEN  (6)
#define BLE_OTC_OBJ_LIST_FILTER_STRING_LEN (18)

/** Object Name Length */
#define BLE_OTC_OBJ_NAME_OBJECT_NAME_LEN (100)

/***************************************************************************//**
 * @brief Object List Control Point value structure.
*******************************************************************************/
typedef struct {
    uint8_t op_code; /**< Op Code */
    uint8_t parameter[BLE_OTC_OBJ_LIST_CP_PARAMETER_LEN]; /**< Parameter */
    uint8_t request_op_code; /**< Request Op Code */
    uint8_t result_code; /**< Result Code */
    uint32_t response_parameter; /**< Response Parameter */
    uint8_t list_sort_order; /**< List Sort Order */
    uint8_t response_code;
} st_ble_otc_obj_list_cp_t;

/***************************************************************************//**
 * @brief Object List Control Point attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
    uint16_t cli_cnfg_desc_hdl;
} st_ble_otc_obj_list_cp_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Object List Control Point characteristic Client Characteristic Configuration descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_OTC_ReadObjListCpCliCnfg(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Object List Control Point characteristic Client Characteristic Configuration descriptor value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value Object List Control Point characteristic Client Characteristic Configuration descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_OTC_WriteObjListCpCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Write Object List Control Point characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] p_value Object List Control Point characteristic value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_OTC_WriteObjListCp(uint16_t conn_hdl, const st_ble_otc_obj_list_cp_t *p_value);
;
/***************************************************************************//**
 * @brief      Get Object List Control Point attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_OTC_GetObjListCpAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_otc_obj_list_cp_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Object List Filter 0 Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_OTC_OBJ_LIST_FILTER_0_UUID (0x2AC7)
#define BLE_OTC_OBJ_LIST_FILTER_0_LEN (100)
/***************************************************************************//**
 * @brief Object List Filter 0 Filter enumeration.
*******************************************************************************/
typedef enum {
    BLE_OTC_OBJ_LIST_FILTER_0_FILTER_NO_FILTER = 0, /**< No Filter */
    BLE_OTC_OBJ_LIST_FILTER_0_FILTER_NAME_STARTS_WITH = 1, /**< Name Starts With */
    BLE_OTC_OBJ_LIST_FILTER_0_FILTER_NAME_ENDS_WITH = 2, /**< Name Ends With */
    BLE_OTC_OBJ_LIST_FILTER_0_FILTER_NAME_CONTAINS = 3, /**< Name Contains */
    BLE_OTC_OBJ_LIST_FILTER_0_FILTER_NAME_IS_EXACTLY = 4, /**< Name is Exactly */
    BLE_OTC_OBJ_LIST_FILTER_0_FILTER_OBJECT_TYPE = 5, /**< Object Type */
    BLE_OTC_OBJ_LIST_FILTER_0_FILTER_CREATED_BETWEEN = 6, /**< Created between */
    BLE_OTC_OBJ_LIST_FILTER_0_FILTER_MODIFIED_BETWEEN = 7, /**< Modified between */
    BLE_OTC_OBJ_LIST_FILTER_0_FILTER_CURRENT_SIZE_BETWEEN = 8, /**< Current Size between */
    BLE_OTC_OBJ_LIST_FILTER_0_FILTER_ALLOCATED_SIZE_BETWEEN = 9, /**< Allocated Size between */
    BLE_OTC_OBJ_LIST_FILTER_0_FILTER_MARKED_OBJECTS = 10, /**< Marked Objects */
} e_ble_otc_obj_list_filter_0_filter_t;

/***************************************************************************//**
 * @brief Object List Filter 0 value structure.
*******************************************************************************/
typedef struct {
    uint8_t filter; /**< Filter */
    st_ble_seq_data_t string; /**< string */
    st_ble_otc_uuid_t uuid; /**< uuid */
    st_ble_date_time_t timestamp1; /**< timestamp1 */
    st_ble_date_time_t timestamp2; /**< timestamp2 */
    uint32_t size1; /**< size1 */
    uint32_t size2; /**< size2 */
} st_ble_otc_obj_list_filter_0_t;

/***************************************************************************//**
 * @brief Object List Filter 0 attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
} st_ble_otc_obj_list_filter_0_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Object List Filter 0 characteristic value from the remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_OTC_ReadObjListFilter0(uint16_t conn_hdl, int32_t type);

/***************************************************************************//**
 * @brief     Write Object List Filter 0 characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] p_value Object List Filter 0 characteristic value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_OTC_WriteObjListFilter0(uint16_t conn_hdl, const st_ble_otc_obj_list_filter_0_t *p_value);

/***************************************************************************//**
 * @brief      Get Object List Filter 0 attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_OTC_GetObjListFilter0AttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_otc_obj_list_filter_0_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Object List Filter 1 Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_OTC_OBJ_LIST_FILTER_1_UUID (0x2AC7)
#define BLE_OTC_OBJ_LIST_FILTER_1_LEN (100)
/***************************************************************************//**
 * @brief Object List Filter 1 Filter enumeration.
*******************************************************************************/
typedef enum {
    BLE_OTC_OBJ_LIST_FILTER_1_FILTER_NO_FILTER = 0, /**< No Filter */
    BLE_OTC_OBJ_LIST_FILTER_1_FILTER_NAME_STARTS_WITH = 1, /**< Name Starts With */
    BLE_OTC_OBJ_LIST_FILTER_1_FILTER_NAME_ENDS_WITH = 2, /**< Name Ends With */
    BLE_OTC_OBJ_LIST_FILTER_1_FILTER_NAME_CONTAINS = 3, /**< Name Contains */
    BLE_OTC_OBJ_LIST_FILTER_1_FILTER_NAME_IS_EXACTLY = 4, /**< Name is Exactly */
    BLE_OTC_OBJ_LIST_FILTER_1_FILTER_OBJECT_TYPE = 5, /**< Name is Exactly */
    BLE_OTC_OBJ_LIST_FILTER_1_FILTER_CREATED_BETWEEN = 6, /**< Created between */
    BLE_OTC_OBJ_LIST_FILTER_1_FILTER_MODIFIED_BETWEEN = 7, /**< Modified between */
    BLE_OTC_OBJ_LIST_FILTER_1_FILTER_CURRENT_SIZE_BETWEEN = 8, /**< Current Size between */
    BLE_OTC_OBJ_LIST_FILTER_1_FILTER_ALLOCATED_SIZE_BETWEEN = 9, /**< Allocated Size between */
    BLE_OTC_OBJ_LIST_FILTER_1_FILTER_MARKED_OBJECTS = 10, /**< Marked Objects */
} e_ble_otc_obj_list_filter_1_filter_t;

/***************************************************************************//**
 * @brief Object List Filter 1 value structure.
*******************************************************************************/
typedef struct {
    uint8_t filter; /**< Filter */
    st_ble_seq_data_t string; /**< string */
    st_ble_otc_uuid_t uuid; /**< uuid */
    st_ble_date_time_t timestamp1; /**< timestamp1 */
    st_ble_date_time_t timestamp2; /**< timestamp2 */
    uint32_t size1; /**< size1 */
    uint32_t size2; /**< size2 */
} st_ble_otc_obj_list_filter_1_t;

/***************************************************************************//**
 * @brief Object List Filter 1 attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
} st_ble_otc_obj_list_filter_1_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Object List Filter 1 characteristic value from the remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_OTC_ReadObjListFilter1(uint16_t conn_hdl, int32_t type);

/***************************************************************************//**
 * @brief     Write Object List Filter 1 characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] p_value Object List Filter 1 characteristic value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_OTC_WriteObjListFilter1(uint16_t conn_hdl, const st_ble_otc_obj_list_filter_1_t *p_value);

/***************************************************************************//**
 * @brief      Get Object List Filter 1 attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_OTC_GetObjListFilter1AttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_otc_obj_list_filter_1_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Object List Filter 2 Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_OTC_OBJ_LIST_FILTER_2_UUID (0x2AC7)
#define BLE_OTC_OBJ_LIST_FILTER_2_LEN (100)
/***************************************************************************//**
 * @brief Object List Filter 2 Filter enumeration.
*******************************************************************************/
typedef enum {
    BLE_OTC_OBJ_LIST_FILTER_2_FILTER_NO_FILTER = 0, /**< No Filter */
    BLE_OTC_OBJ_LIST_FILTER_2_FILTER_NAME_STARTS_WITH = 1, /**< Name Starts With */
    BLE_OTC_OBJ_LIST_FILTER_2_FILTER_NAME_ENDS_WITH = 2, /**< Name Ends With */
    BLE_OTC_OBJ_LIST_FILTER_2_FILTER_NAME_CONTAINS = 3, /**< Name Contains */
    BLE_OTC_OBJ_LIST_FILTER_2_FILTER_NAME_IS_EXACTLY = 4, /**< Name is Exactly */
    BLE_OTC_OBJ_LIST_FILTER_2_FILTER_OBJECT_TYPE = 5, /**< Name is Exactly */
    BLE_OTC_OBJ_LIST_FILTER_2_FILTER_CREATED_BETWEEN = 6, /**< Created between */
    BLE_OTC_OBJ_LIST_FILTER_2_FILTER_MODIFIED_BETWEEN = 7, /**< Modified between */
    BLE_OTC_OBJ_LIST_FILTER_2_FILTER_CURRENT_SIZE_BETWEEN = 8, /**< Current Size between */
    BLE_OTC_OBJ_LIST_FILTER_2_FILTER_ALLOCATED_SIZE_BETWEEN = 9, /**< Allocated Size between */
    BLE_OTC_OBJ_LIST_FILTER_2_FILTER_MARKED_OBJECTS = 10, /**< Marked Objects */
} e_ble_otc_obj_list_filter_2_filter_t;

/***************************************************************************//**
 * @brief Object List Filter 2 value structure.
*******************************************************************************/
typedef struct {
    uint8_t filter; /**< Filter */
    st_ble_seq_data_t string; /**< string */
    st_ble_otc_uuid_t uuid; /**< uuid */
    st_ble_date_time_t timestamp1; /**< timestamp1 */
    st_ble_date_time_t timestamp2; /**< timestamp2 */
    uint32_t size1; /**< size1 */
    uint32_t size2; /**< size2 */
} st_ble_otc_obj_list_filter_2_t;

/***************************************************************************//**
 * @brief Object List Filter 2 attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
} st_ble_otc_obj_list_filter_2_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Object List Filter 2 characteristic value from the remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_OTC_ReadObjListFilter2(uint16_t conn_hdl, int32_t type);

/***************************************************************************//**
 * @brief     Write Object List Filter 2 characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] p_value Object List Filter 2 characteristic value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_OTC_WriteObjListFilter2(uint16_t conn_hdl, const st_ble_otc_obj_list_filter_2_t *p_value);
;
/***************************************************************************//**
 * @brief      Get Object List Filter 2 attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_OTC_GetObjListFilter2AttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_otc_obj_list_filter_2_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Object Changed Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_OTC_OBJ_CHANGED_UUID (0x2AC8)
#define BLE_OTC_OBJ_CHANGED_LEN (7)
#define BLE_OTC_OBJ_CHANGED_CLI_CNFG_UUID (0x2902)
#define BLE_OTC_OBJ_CHANGED_CLI_CNFG_LEN (2)

/***************************************************************************//**
 * @brief Object Changed Flags value structure.
*******************************************************************************/
typedef struct {
    bool is_source_of_change; /**< Source of Change */
    bool is_change_occurred_to_the_object_contents; /**< Change occurred to the object contents */
    bool is_change_occurred_to_the_object_metadata; /**< Change occurred to the object metadata */
    bool is_object_creation; /**< Object Creation */
    bool is_object_deletion; /**< Object Deletion */
} st_ble_lnc_obj_changed_flags_t;

/***************************************************************************//**
 * @brief Object Changed value structure.
*******************************************************************************/
typedef struct {
    st_ble_lnc_obj_changed_flags_t flags; /**< Flags */
    uint8_t object_id[6]; /**< Object ID */
} st_ble_otc_obj_changed_t;

/***************************************************************************//**
 * @brief Object Changed attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
    uint16_t cli_cnfg_desc_hdl;
} st_ble_otc_obj_changed_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Object Changed characteristic Client Characteristic Configuration descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_OTC_ReadObjChangedCliCnfg(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Object Changed characteristic Client Characteristic Configuration descriptor value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value Object Changed characteristic Client Characteristic Configuration descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_OTC_WriteObjChangedCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief      Get Object Changed attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_OTC_GetObjChangedAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_otc_obj_changed_attr_hdl_t *p_hdl);


/*----------------------------------------------------------------------------------------------------------------------
    Object Transfer Service Client
----------------------------------------------------------------------------------------------------------------------*/

/***************************************************************************//**
 * @brief An attempt was made to write a value that is invalid or not supported by this Server for a reason other than the attribute permissions.
*******************************************************************************/
#define BLE_OTC_WRITE_REQUEST_REJECTED_ERROR (BLE_ERR_GROUP_GATT | 0x80)

/***************************************************************************//**
 * @brief An attempt was made to read or write to an Object Metadata characteristic while the Current Object was an Invalid Object (see Section 1.8 in the PDF sepcification).
*******************************************************************************/
#define BLE_OTC_OBJECT_NOT_SELECTED_ERROR (BLE_ERR_GROUP_GATT | 0x81)

/***************************************************************************//**
 * @brief The Server is unable to service the Read Request or Write Request because it exceeds the concurrency limit of the service.
*******************************************************************************/
#define BLE_OTC_CONCURRENCY_LIMIT_EXCEEDED_ERROR (BLE_ERR_GROUP_GATT | 0x82)

/***************************************************************************//**
 * @brief The requested object name was rejected because the name was already in use by an existing object on the Server.
*******************************************************************************/
#define BLE_OTC_OBJECT_NAME_ALREADY_EXISTS_ERROR (BLE_ERR_GROUP_GATT | 0x83)

/***************************************************************************//**
 * @brief Object Transfer Service client event data.
*******************************************************************************/
typedef struct {
    uint16_t    conn_hdl;  /**< Connection handle */
    uint16_t    param_len; /**< Event parameter length */
    const void *p_param;   /**< Event parameter */
} st_ble_otc_evt_data_t;

/***************************************************************************//**
 * @brief Object Transfer Service characteristic ID.
*******************************************************************************/
typedef enum {
    BLE_OTC_FEAT_IDX,
    BLE_OTC_OBJ_NAME_IDX,
    BLE_OTC_OBJ_TYPE_IDX,
    BLE_OTC_OBJ_SIZE_IDX,
    BLE_OTC_OBJ_FIRST_CREATED_IDX,
    BLE_OTC_OBJ_LAST_MODIFIED_IDX,
    BLE_OTC_OBJ_ID_IDX,
    BLE_OTC_OBJ_PROP_IDX,
    BLE_OTC_OBJ_ACTION_CP_IDX,
    BLE_OTC_OBJ_ACTION_CP_CLI_CNFG_IDX,
    BLE_OTC_OBJ_LIST_CP_IDX,
    BLE_OTC_OBJ_LIST_CP_CLI_CNFG_IDX,
    BLE_OTC_OBJ_LIST_FILTER_0_IDX,
    BLE_OTC_OBJ_LIST_FILTER_1_IDX,
    BLE_OTC_OBJ_LIST_FILTER_2_IDX,
    BLE_OTC_OBJ_CHANGED_IDX,
    BLE_OTC_OBJ_CHANGED_CLI_CNFG_IDX,
} e_ble_otc_char_idx_t;

/***************************************************************************//**
 * @brief Object Transfer Service client event type.
*******************************************************************************/
typedef enum {
    /* OTS Feature */
    BLE_OTC_EVENT_FEAT_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_OTC_FEAT_IDX, BLE_SERVC_READ_RSP),
    /* Object Name */
    BLE_OTC_EVENT_OBJ_NAME_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_OTC_OBJ_NAME_IDX, BLE_SERVC_READ_RSP),
    BLE_OTC_EVENT_OBJ_NAME_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_OTC_OBJ_NAME_IDX, BLE_SERVC_WRITE_RSP),
    /* Object Type */
    BLE_OTC_EVENT_OBJ_TYPE_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_OTC_OBJ_TYPE_IDX, BLE_SERVC_READ_RSP),
    /* Object Size */
    BLE_OTC_EVENT_OBJ_SIZE_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_OTC_OBJ_SIZE_IDX, BLE_SERVC_READ_RSP),
    /* Object First-Created */
    BLE_OTC_EVENT_OBJ_FIRST_CREATED_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_OTC_OBJ_FIRST_CREATED_IDX, BLE_SERVC_READ_RSP),
    BLE_OTC_EVENT_OBJ_FIRST_CREATED_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_OTC_OBJ_FIRST_CREATED_IDX, BLE_SERVC_WRITE_RSP),
    /* Object Last-Modified */
    BLE_OTC_EVENT_OBJ_LAST_MODIFIED_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_OTC_OBJ_LAST_MODIFIED_IDX, BLE_SERVC_READ_RSP),
    BLE_OTC_EVENT_OBJ_LAST_MODIFIED_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_OTC_OBJ_LAST_MODIFIED_IDX, BLE_SERVC_WRITE_RSP),
    /* Object ID */
    BLE_OTC_EVENT_OBJ_ID_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_OTC_OBJ_ID_IDX, BLE_SERVC_READ_RSP),
    /* Object Properties */
    BLE_OTC_EVENT_OBJ_PROP_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_OTC_OBJ_PROP_IDX, BLE_SERVC_READ_RSP),
    BLE_OTC_EVENT_OBJ_PROP_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_OTC_OBJ_PROP_IDX, BLE_SERVC_WRITE_RSP),
    /* Object Action Control Point */
    BLE_OTC_EVENT_OBJ_ACTION_CP_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_OTC_OBJ_ACTION_CP_IDX, BLE_SERVC_WRITE_RSP),
    BLE_OTC_EVENT_OBJ_ACTION_CP_HDL_VAL_IND = BLE_SERVC_ATTR_EVENT(BLE_OTC_OBJ_ACTION_CP_IDX, BLE_SERVC_HDL_VAL_IND),
    BLE_OTC_EVENT_OBJ_ACTION_CP_CLI_CNFG_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_OTC_OBJ_ACTION_CP_CLI_CNFG_IDX, BLE_SERVC_READ_RSP),
    BLE_OTC_EVENT_OBJ_ACTION_CP_CLI_CNFG_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_OTC_OBJ_ACTION_CP_CLI_CNFG_IDX, BLE_SERVC_WRITE_RSP),
    /* Object List Control Point */
    BLE_OTC_EVENT_OBJ_LIST_CP_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_OTC_OBJ_LIST_CP_IDX, BLE_SERVC_WRITE_RSP),
    BLE_OTC_EVENT_OBJ_LIST_CP_HDL_VAL_IND = BLE_SERVC_ATTR_EVENT(BLE_OTC_OBJ_LIST_CP_IDX, BLE_SERVC_HDL_VAL_IND),
    BLE_OTC_EVENT_OBJ_LIST_CP_CLI_CNFG_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_OTC_OBJ_LIST_CP_CLI_CNFG_IDX, BLE_SERVC_READ_RSP),
    BLE_OTC_EVENT_OBJ_LIST_CP_CLI_CNFG_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_OTC_OBJ_LIST_CP_CLI_CNFG_IDX, BLE_SERVC_WRITE_RSP),
    /* Object List Filter 0 */
    BLE_OTC_EVENT_OBJ_LIST_FILTER_0_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_OTC_OBJ_LIST_FILTER_0_IDX, BLE_SERVC_READ_RSP),
    BLE_OTC_EVENT_OBJ_LIST_FILTER_0_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_OTC_OBJ_LIST_FILTER_0_IDX, BLE_SERVC_WRITE_RSP),
    /* Object List Filter 1 */
    BLE_OTC_EVENT_OBJ_LIST_FILTER_1_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_OTC_OBJ_LIST_FILTER_1_IDX, BLE_SERVC_READ_RSP),
    BLE_OTC_EVENT_OBJ_LIST_FILTER_1_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_OTC_OBJ_LIST_FILTER_1_IDX, BLE_SERVC_WRITE_RSP),
    /* Object List Filter 2 */
    BLE_OTC_EVENT_OBJ_LIST_FILTER_2_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_OTC_OBJ_LIST_FILTER_2_IDX, BLE_SERVC_READ_RSP),
    BLE_OTC_EVENT_OBJ_LIST_FILTER_2_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_OTC_OBJ_LIST_FILTER_2_IDX, BLE_SERVC_WRITE_RSP),
    /* Object Changed */
    BLE_OTC_EVENT_OBJ_CHANGED_HDL_VAL_IND = BLE_SERVC_ATTR_EVENT(BLE_OTC_OBJ_CHANGED_IDX, BLE_SERVC_HDL_VAL_IND),
    BLE_OTC_EVENT_OBJ_CHANGED_CLI_CNFG_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_OTC_OBJ_CHANGED_CLI_CNFG_IDX, BLE_SERVC_READ_RSP),
    BLE_OTC_EVENT_OBJ_CHANGED_CLI_CNFG_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_OTC_OBJ_CHANGED_CLI_CNFG_IDX, BLE_SERVC_WRITE_RSP),
} e_ble_otc_event_t;

/***************************************************************************//**
 * @brief     Initialize Object Transfer Service client.
 * @param[in] cb Client callback.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_OTC_Init(ble_servc_app_cb_t cb);

/***************************************************************************//**
 * @brief     Object Transfer Service client discovery callback.
 * @param[in] conn_hdl Connection handle
 * @param[in] serv_idx Service instance index.
 * @param[in] type     Service discovery event type.
 * @param[in] p_param  Service discovery event parameter.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_OTC_ServDiscCb(uint16_t conn_hdl, uint8_t serv_idx, uint16_t type, void *p_param);

/***************************************************************************//**
 * @brief     Get Object Transfer Service client attribute handle.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
*******************************************************************************/
void R_BLE_OTC_GetServAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_gatt_hdl_range_t *p_hdl);

extern uint8_t g_obj_filter0_str[BLE_OTC_OBJ_LIST_FILTER_0_LEN - 3];
extern uint8_t g_obj_filter1_str[BLE_OTC_OBJ_LIST_FILTER_1_LEN - 3];
extern uint8_t g_obj_filter2_str[BLE_OTC_OBJ_LIST_FILTER_2_LEN - 3];

#endif /* R_BLE_OTC_H */

/** @} */
