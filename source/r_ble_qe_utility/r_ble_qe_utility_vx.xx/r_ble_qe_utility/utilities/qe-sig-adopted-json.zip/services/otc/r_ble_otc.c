/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_otc.c
 * Version : 1.0
 * Description : The source file for Object Transfer Service client.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 29.05.2019 1.00 First Release
***********************************************************************************************************************/

/***********************************************************************************************************************
 Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <string.h>
#include "r_ble_otc.h"

#ifndef UNUSED_ARG
#define UNUSED_ARG(arg)         (void)(arg)
#endif /* UNUSED_ARG */

uint8_t g_obj_filter0_str[BLE_OTC_OBJ_LIST_FILTER_0_LEN - 3];
uint8_t g_obj_filter1_str[BLE_OTC_OBJ_LIST_FILTER_1_LEN - 3];
uint8_t g_obj_filter2_str[BLE_OTC_OBJ_LIST_FILTER_2_LEN - 3];


static st_ble_servc_info_t gs_client_info;

/*----------------------------------------------------------------------------------------------------------------------
    OTS Feature Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* OTS Feature characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_feat_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

static ble_status_t decode_st_ble_otc_feat_t(st_ble_otc_feat_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    /* Convert byte sequence to app data. */
    uint32_t ots_oacp_features = 0;
    uint32_t ots_olcp_features = 0;

    if (BLE_OTC_FEAT_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Clear the feature bit flags */
    memset(p_app_value, 0x0, sizeof(st_ble_otc_feat_t));

    BT_UNPACK_LE_4_BYTE(&ots_oacp_features, &p_gatt_value->p_value[0]);
    BT_UNPACK_LE_4_BYTE(&ots_olcp_features, &p_gatt_value->p_value[4]);

    /* Create Op Code Supported */
    if (ots_oacp_features & BLE_OTC_PRV_OACP_CREATE_OP_CODE_SUPPORTED)
    {
        p_app_value->oacp_features.is_oacp_create_op_code_supported = true;
    }
    else
    {
        p_app_value->oacp_features.is_oacp_create_op_code_supported = false;
    }

    /* Delete Op Code Supported */
    if (ots_oacp_features & BLE_OTC_PRV_OACP_DELETE_OP_CODE_SUPPORTED)
    {
        p_app_value->oacp_features.is_oacp_delete_op_code_supported = true;
    }
    else
    {
        p_app_value->oacp_features.is_oacp_delete_op_code_supported = false;
    }

    /* OACP Calculate Checksum Op Code Supported */
    if (ots_oacp_features & BLE_OTC_PRV_OACP_CALCULATE_CHECKSUM_OP_CODE_SUPPORTED)
    {
        p_app_value->oacp_features.is_oacp_calculate_checksum_op_code_supported = true;
    }
    else
    {
        p_app_value->oacp_features.is_oacp_calculate_checksum_op_code_supported = false;
    }

    /* OACP Execute Op Code Supported */
    if (ots_oacp_features & BLE_OTC_PRV_OACP_EXECUTE_OP_CODE_SUPPORTED)
    {
        p_app_value->oacp_features.is_oacp_execute_op_code_supported = true;
    }
    else
    {
        p_app_value->oacp_features.is_oacp_execute_op_code_supported = false;
    }

    /* OACP Read Op Code Supported */
    if (ots_oacp_features & BLE_OTC_PRV_OACP_READ_OP_CODE_SUPPORTED)
    {
        p_app_value->oacp_features.is_oacp_read_op_code_supported = true;
    }
    else
    {
        p_app_value->oacp_features.is_oacp_read_op_code_supported = false;
    }

    /* OACP Write Op Code Supported */
    if (ots_oacp_features & BLE_OTC_PRV_OACP_WRITE_OP_CODE_SUPPORTED)
    {
        p_app_value->oacp_features.is_oacp_write_op_code_supported = true;
    }
    else
    {
        p_app_value->oacp_features.is_oacp_write_op_code_supported = false;
    }

    /* Appending Additional Data to Objects Supported */
    if (ots_oacp_features & BLE_OTC_PRV_APPENDING_ADDITIONAL_DATA_TO_OBJECTS_SUPPORTED)
    {
        p_app_value->oacp_features.is_appending_additional_data_to_objects_supported = true;
    }
    else
    {
        p_app_value->oacp_features.is_appending_additional_data_to_objects_supported = false;
    }

    /* Truncation of Objects Supported */
    if (ots_oacp_features & BLE_OTC_PRV_TRUNCATION_OF_OBJECTS_SUPPORTED)
    {
        p_app_value->oacp_features.is_truncation_of_objects_supported = true;
    }
    else
    {
        p_app_value->oacp_features.is_truncation_of_objects_supported = false;
    }

    /* Patching of Objects Supported */
    if (ots_oacp_features & BLE_OTC_PRV_PATCHING_OF_OBJECTS_SUPPORTED)
    {
        p_app_value->oacp_features.is_patching_of_objects_supported = true;
    }
    else
    {
        p_app_value->oacp_features.is_patching_of_objects_supported = false;
    }

    /* OACP Abort Op Code Supported */
    if (ots_oacp_features & BLE_OTC_PRV_OACP_ABORT_OP_CODE_SUPPORTED)
    {
        p_app_value->oacp_features.is_oacp_abort_op_code_supported = true;
    }
    else
    {
        p_app_value->oacp_features.is_oacp_abort_op_code_supported = false;
    }

    /* OLCP Go To Op Code Supported */
    if (ots_olcp_features & BLE_OTC_PRV_OLCP_GO_TO_OP_CODE_SUPPORTED)
    {
        p_app_value->olcp_features.is_olcp_go_to_op_code_supported = true;
    }
    else
    {
        p_app_value->olcp_features.is_olcp_go_to_op_code_supported = false;
    }

    /* OLCP Order Op Code Supported */
    if (ots_olcp_features & BLE_OTC_PRV_OLCP_ORDER_OP_CODE_SUPPORTED)
    {
        p_app_value->olcp_features.is_olcp_order_op_code_supported = true;
    }
    else
    {
        p_app_value->olcp_features.is_olcp_order_op_code_supported = false;
    }

    /* OLCP Request Number of Objects Op Code Supported */
    if (ots_olcp_features & BLE_OTC_PRV_OLCP_REQUEST_NUMBER_OF_OBJECTS_OP_CODE_SUPPORTED)
    {
        p_app_value->olcp_features.is_olcp_request_number_of_objects_op_code_supported = true;
    }
    else
    {
        p_app_value->olcp_features.is_olcp_request_number_of_objects_op_code_supported = false;
    }

    /* OLCP Clear Marking Op Code Supported */
    if (ots_olcp_features & BLE_OTC_PRV_OLCP_CLEAR_MARKING_OP_CODE_SUPPORTED)
    {
        p_app_value->olcp_features.is_olcp_clear_marking_op_code_supported = true;
    }
    else
    {
        p_app_value->olcp_features.is_olcp_clear_marking_op_code_supported = false;
    }

    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_otc_feat_t(const st_ble_otc_feat_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;
    uint32_t oacp_features_flag = 0;
    uint32_t olcp_features_flag = 0;

    /* Clear the byte array */
    memset(p_gatt_value->p_value, 0x0, BLE_OTC_FEAT_LEN);

    /* Create Op Code Supported */
    if (p_app_value->oacp_features.is_oacp_create_op_code_supported)
    {
        /* Set the bit */
        oacp_features_flag |= BLE_OTC_PRV_OACP_CREATE_OP_CODE_SUPPORTED;
    }

    /* OACP Delete Op Code Supported */
    if (p_app_value->oacp_features.is_oacp_delete_op_code_supported)
    {
        /* Set the bit */
        oacp_features_flag |= BLE_OTC_PRV_OACP_DELETE_OP_CODE_SUPPORTED;
    }

    /* OACP Calculate Checksum Op Code Supported */
    if (p_app_value->oacp_features.is_oacp_calculate_checksum_op_code_supported)
    {
        /* Set the bit */
        oacp_features_flag |= BLE_OTC_PRV_OACP_CALCULATE_CHECKSUM_OP_CODE_SUPPORTED;
    }

    /* OACP Execute Op Code Supported */
    if (p_app_value->oacp_features.is_oacp_execute_op_code_supported)
    {
        /* Set the bit */
        oacp_features_flag |= BLE_OTC_PRV_OACP_EXECUTE_OP_CODE_SUPPORTED;
    }

    /* OACP Read Op Code Supported */
    if (p_app_value->oacp_features.is_oacp_read_op_code_supported)
    {
        /* Set the bit */
        oacp_features_flag |= BLE_OTC_PRV_OACP_READ_OP_CODE_SUPPORTED;
    }

    /* OACP Write Op Code Supported */
    if (p_app_value->oacp_features.is_oacp_write_op_code_supported)
    {
        /* Set the bit */
        oacp_features_flag |= BLE_OTC_PRV_OACP_WRITE_OP_CODE_SUPPORTED;
    }

    /* Appending Additional Data to Objects Supported */
    if (p_app_value->oacp_features.is_appending_additional_data_to_objects_supported)
    {
        /* Set the bit */
        oacp_features_flag |= BLE_OTC_PRV_APPENDING_ADDITIONAL_DATA_TO_OBJECTS_SUPPORTED;
    }

    /* Truncation of Objects Supported */
    if (p_app_value->oacp_features.is_truncation_of_objects_supported)
    {
        /* Set the bit */
        oacp_features_flag |= BLE_OTC_PRV_TRUNCATION_OF_OBJECTS_SUPPORTED;
    }

    /* Patching of Objects Supported */
    if (p_app_value->oacp_features.is_patching_of_objects_supported)
    {
        /* Set the bit */
        oacp_features_flag |= BLE_OTC_PRV_PATCHING_OF_OBJECTS_SUPPORTED;
    }

    /* OACP Abort Op Code Supported */
    if (p_app_value->oacp_features.is_oacp_abort_op_code_supported)
    {
        /* Set the bit */
        oacp_features_flag |= BLE_OTC_PRV_OACP_ABORT_OP_CODE_SUPPORTED;
    }

    /* OLCP Go To Op Code Supported */
    if (p_app_value->olcp_features.is_olcp_go_to_op_code_supported)
    {
        /* Set the bit */
        oacp_features_flag |= BLE_OTC_PRV_OLCP_GO_TO_OP_CODE_SUPPORTED;
    }

    /* OLCP Order Op Code Supported */
    if (p_app_value->olcp_features.is_olcp_order_op_code_supported)
    {
        /* Set the bit */
        oacp_features_flag |= BLE_OTC_PRV_OLCP_ORDER_OP_CODE_SUPPORTED;
    }

    /* OLCP Request Number of Objects Op Code Supported */
    if (p_app_value->olcp_features.is_olcp_request_number_of_objects_op_code_supported)
    {
        /* Set the bit */
        oacp_features_flag |= BLE_OTC_PRV_OLCP_REQUEST_NUMBER_OF_OBJECTS_OP_CODE_SUPPORTED;
    }

    /* OLCP Clear Marking Op Code Supported */
    if (p_app_value->olcp_features.is_olcp_clear_marking_op_code_supported)
    {
        /* Set the bit */
        oacp_features_flag |= BLE_OTC_PRV_OLCP_CLEAR_MARKING_OP_CODE_SUPPORTED;
    }

    BT_PACK_LE_4_BYTE(&(p_gatt_value->p_value[pos]), &oacp_features_flag);
    pos += sizeof(oacp_features_flag);

    BT_PACK_LE_4_BYTE(&(p_gatt_value->p_value[pos]), &olcp_features_flag);
    pos += sizeof(olcp_features_flag);

    p_gatt_value->value_len = BLE_OTC_FEAT_LEN;

    return BLE_SUCCESS;
}

/* OTS Feature characteristic definition */
static const st_ble_servc_char_info_t gs_feat_char = {
    .uuid_16      = BLE_OTC_FEAT_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_otc_feat_t),
    .db_size      = BLE_OTC_FEAT_LEN,
    .char_idx     = BLE_OTC_FEAT_IDX,
    .p_attr_hdls  = gs_feat_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_otc_feat_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_otc_feat_t,
};

ble_status_t R_BLE_OTC_ReadFeat(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_feat_char, conn_hdl);
}

void R_BLE_OTC_GetFeatAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_otc_feat_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_feat_char_ranges[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Object Name Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Object Name characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_obj_name_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

/* Object Name characteristic definition */
const st_ble_servc_char_info_t gs_obj_name_char = {
    .uuid_16      = BLE_OTC_OBJ_NAME_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(uint8_t) * BLE_OTC_OBJ_NAME_LEN,
    .db_size      = BLE_OTC_OBJ_NAME_LEN,
    .char_idx     = BLE_OTC_OBJ_NAME_IDX,
    .p_attr_hdls  = gs_obj_name_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_seq_data_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_seq_data_t,
};

ble_status_t R_BLE_OTC_WriteObjName(uint16_t conn_hdl, const st_ble_seq_data_t *p_value) // @suppress("API function naming")
{
    //return R_BLE_SERVC_WriteChar_with_Size(&gs_obj_name_char, conn_hdl, p_value);
    return R_BLE_SERVC_WriteChar(&gs_obj_name_char, conn_hdl, p_value);
}

ble_status_t R_BLE_OTC_ReadObjName(uint16_t conn_hdl, int32_t type) // @suppress("API function naming")
{
    UNUSED_ARG(type);

    return R_BLE_SERVC_ReadChar(&gs_obj_name_char, conn_hdl);
    //return R_BLE_SERVC_ReadChar_with_Type(&gs_obj_name_char, conn_hdl, type);
}

void R_BLE_OTC_GetObjNameAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_otc_obj_name_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_obj_name_char_ranges[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Object Type Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Object Type characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_obj_type_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

static ble_status_t decode_st_ble_otc_uuid_t(st_ble_otc_uuid_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    /* Convert byte sequence to app data. */
    uint32_t pos = 0;
    uint8_t i = 0;

    if (BLE_OTC_OBJ_TYPE_LEN < p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Clear the application structure */
    memset(p_app_value, 0x0, sizeof(st_ble_otc_uuid_t));

    if (p_gatt_value->value_len == 2)
    {
        p_app_value->uuid_type = BLE_GATT_16_BIT_UUID_FORMAT;

        BT_UNPACK_LE_2_BYTE(&(p_app_value->uuid.uuid_16), &(p_gatt_value->p_value[pos]));
        pos += 2;
    }
    else
    {
        p_app_value->uuid_type = BLE_GATT_128_BIT_UUID_FORMAT;

        for (i = 0; i < 16; i++)
        {
            p_app_value->uuid.uuid_128[i] = p_gatt_value->p_value[pos++];
        }
    }
    
    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_otc_uuid_t(const st_ble_otc_uuid_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;
    uint8_t i = 0;

    /* Clear the byte array */
    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    if (p_app_value->uuid_type == BLE_GATT_16_BIT_UUID_FORMAT)
    {
        p_gatt_value->p_value[pos++] = (uint8_t)p_app_value->uuid.uuid_16 & 0xFF;
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->uuid.uuid_16 >> 8) & 0xFF);
    }
    else //if (p_app_value->uuid_type == BLE_GATT_128_BIT_UUID_FORMAT)
    {
        for (i = 0; i < 16; i++)
        {
            p_gatt_value->p_value[pos++] = (uint8_t)p_app_value->uuid.uuid_128[i];
        }
    }

    p_gatt_value->value_len = (uint16_t)pos;

    return BLE_SUCCESS;
}

/* Object Type characteristic definition */
const st_ble_servc_char_info_t gs_obj_type_char = {
    .uuid_16      = BLE_OTC_OBJ_TYPE_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_otc_uuid_t),
    .db_size      = BLE_OTC_OBJ_TYPE_LEN,
    .char_idx     = BLE_OTC_OBJ_TYPE_IDX,
    .p_attr_hdls  = gs_obj_type_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_otc_uuid_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_otc_uuid_t,
};

ble_status_t R_BLE_OTC_ReadObjType(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_obj_type_char, conn_hdl);
}

void R_BLE_OTC_GetObjTypeAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_otc_obj_type_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_obj_type_char_ranges[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Object Size Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Object Size characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_obj_size_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

static ble_status_t decode_st_ble_otc_obj_size_t(st_ble_otc_obj_size_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    /* Convert byte sequence to app data. */
    uint32_t pos = 0;

    if (BLE_OTC_OBJ_SIZE_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Clear the application structure */
    memset(p_app_value, 0x0, sizeof(st_ble_otc_obj_size_t));

    BT_UNPACK_LE_4_BYTE(&(p_app_value->current_size), &(p_gatt_value->p_value[pos]));
    pos += sizeof(p_app_value->current_size);

    BT_UNPACK_LE_4_BYTE(&(p_app_value->allocated_size), &(p_gatt_value->p_value[pos]));
    pos += sizeof(p_app_value->allocated_size);

    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_otc_obj_size_t(const st_ble_otc_obj_size_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    /* Convert app data to byte sequence. */
    uint32_t  pos = 0;

    /* Clear the gatt structure */
    memset(p_gatt_value->p_value, 0x0, BLE_OTC_OBJ_SIZE_LEN);

    BT_PACK_LE_4_BYTE(&(p_gatt_value->p_value[pos]), &(p_app_value->current_size));
    pos += sizeof(p_app_value->current_size);

    BT_PACK_LE_4_BYTE(&(p_gatt_value->p_value[pos]), &(p_app_value->allocated_size));
    pos += sizeof(p_app_value->allocated_size);

    /* Update Length */
    p_gatt_value->value_len = (uint16_t)pos;

    return BLE_SUCCESS;
}

/* Object Size characteristic definition */
const st_ble_servc_char_info_t gs_obj_size_char = {
    .uuid_16      = BLE_OTC_OBJ_SIZE_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_otc_obj_size_t),
    .db_size      = BLE_OTC_OBJ_SIZE_LEN,
    .char_idx     = BLE_OTC_OBJ_SIZE_IDX,
    .p_attr_hdls  = gs_obj_size_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_otc_obj_size_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_otc_obj_size_t,
};

ble_status_t R_BLE_OTC_ReadObjSize(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_obj_size_char, conn_hdl);
}

void R_BLE_OTC_GetObjSizeAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_otc_obj_size_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_obj_size_char_ranges[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Object First-Created Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Object First-Created characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_obj_first_created_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

static ble_status_t decode_st_ble_date_time_t(st_ble_date_time_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    /* Convert byte sequence to app data. */
    uint32_t pos = 0;

    if (BLE_OTC_OBJ_FIRST_CREATED_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Clear the application structure */
    memset(p_app_value, 0x0, sizeof(st_ble_date_time_t));

    BT_UNPACK_LE_2_BYTE(&(p_app_value->year), &(p_gatt_value->p_value[pos]));
    pos += 2;

    BT_UNPACK_LE_1_BYTE(&(p_app_value->month), &(p_gatt_value->p_value[pos++]));
    BT_UNPACK_LE_1_BYTE(&(p_app_value->day), &(p_gatt_value->p_value[pos++]));
    BT_UNPACK_LE_1_BYTE(&(p_app_value->hours), &(p_gatt_value->p_value[pos++]));
    BT_UNPACK_LE_1_BYTE(&(p_app_value->minutes), &(p_gatt_value->p_value[pos++]));
    BT_UNPACK_LE_1_BYTE(&(p_app_value->seconds), &(p_gatt_value->p_value[pos++]));

    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_date_time_t(const st_ble_date_time_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_OTC_OBJ_FIRST_CREATED_LEN);

    BT_PACK_LE_2_BYTE(&(p_gatt_value->p_value[pos]), &(p_app_value->year));
    pos += (sizeof(p_app_value->year));

    BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->month));
    BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->day));
    BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->hours));
    BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->minutes));
    BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->seconds));

    p_gatt_value->value_len = (uint16_t)pos;

    return BLE_SUCCESS;
}

/* Object First-Created characteristic definition */
const st_ble_servc_char_info_t gs_obj_first_created_char = {
    .uuid_16      = BLE_OTC_OBJ_FIRST_CREATED_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_date_time_t),
    .db_size      = BLE_OTC_OBJ_FIRST_CREATED_LEN,
    .char_idx     = BLE_OTC_OBJ_FIRST_CREATED_IDX,
    .p_attr_hdls  = gs_obj_first_created_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_date_time_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_date_time_t,
};

ble_status_t R_BLE_OTC_WriteObjFirstCreated(uint16_t conn_hdl, const st_ble_date_time_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteChar(&gs_obj_first_created_char, conn_hdl, p_value);
}

ble_status_t R_BLE_OTC_ReadObjFirstCreated(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_obj_first_created_char, conn_hdl);
}

void R_BLE_OTC_GetObjFirstCreatedAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_otc_obj_first_created_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_obj_first_created_char_ranges[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Object Last-Modified Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Object Last-Modified characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_obj_last_modified_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

/* Object Last-Modified characteristic definition */
const st_ble_servc_char_info_t gs_obj_last_modified_char = {
    .uuid_16      = BLE_OTC_OBJ_LAST_MODIFIED_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_date_time_t),
    .db_size      = BLE_OTC_OBJ_LAST_MODIFIED_LEN,
    .char_idx     = BLE_OTC_OBJ_LAST_MODIFIED_IDX,
    .p_attr_hdls  = gs_obj_last_modified_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_date_time_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_date_time_t,
};

ble_status_t R_BLE_OTC_WriteObjLastModified(uint16_t conn_hdl, const st_ble_date_time_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteChar(&gs_obj_last_modified_char, conn_hdl, p_value);
}

ble_status_t R_BLE_OTC_ReadObjLastModified(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_obj_last_modified_char, conn_hdl);
}

void R_BLE_OTC_GetObjLastModifiedAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_otc_obj_last_modified_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_obj_last_modified_char_ranges[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Object ID Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Object ID characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_obj_id_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

/* Object ID characteristic definition */
const st_ble_servc_char_info_t gs_obj_id_char = {
    .uuid_16      = BLE_OTC_OBJ_ID_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(uint8_t) * 6,
    .db_size      = BLE_OTC_OBJ_ID_LEN,
    .char_idx     = BLE_OTC_OBJ_ID_IDX,
    .p_attr_hdls  = gs_obj_id_char_ranges,
    .decode = (ble_servc_attr_decode_t)decode_allcopy,
    .encode = (ble_servc_attr_encode_t)encode_allcopy,
};

ble_status_t R_BLE_OTC_ReadObjId(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_obj_id_char, conn_hdl);
}

void R_BLE_OTC_GetObjIdAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_otc_obj_id_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_obj_id_char_ranges[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Object Properties Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Object Properties characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_obj_prop_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

static ble_status_t decode_st_ble_otc_obj_prop_t(st_ble_otc_obj_prop_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    /* Convert byte sequence to app data. */
    uint32_t pos = 0;
    uint32_t ots_object_properties = 0;

    if (BLE_OTC_OBJ_PROP_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Clear the application structure */
    memset(p_app_value, 0x0, sizeof(st_ble_otc_obj_prop_t));

    BT_UNPACK_LE_4_BYTE(&ots_object_properties, &p_gatt_value->p_value[pos]);

    /* Deletion of this object */
    if (ots_object_properties & BLE_OTC_PRV_DELETION_OF_THIS_OBJECT_IS_PERMITTED)
    {
        p_app_value->is_deletion_of_this_object_is_permitted = true;
    }
    else
    {
        p_app_value->is_deletion_of_this_object_is_permitted = false;
    }

    /* Execution of this object */
    if (ots_object_properties & BLE_OTC_PRV_EXECUTION_OF_THIS_OBJECT_IS_PERMITTED)
    {
        p_app_value->is_execution_of_this_object_is_permitted = true;
    }
    else
    {
        p_app_value->is_execution_of_this_object_is_permitted = false;
    }

    /* Reading this object */
    if (ots_object_properties & BLE_OTC_PRV_READING_THIS_OBJECT_IS_PERMITTED)
    {
        p_app_value->is_reading_this_object_is_permitted = true;
    }
    else
    {
        p_app_value->is_reading_this_object_is_permitted = false;
    }

    /* Writing data to this object */
    if (ots_object_properties & BLE_OTC_PRV_WRITING_DATA_TO_THIS_OBJECT_IS_PERMITTED)
    {
        p_app_value->is_writing_data_to_this_object_is_permitted = true;
    }
    else
    {
        p_app_value->is_writing_data_to_this_object_is_permitted = false;
    }

    /* Appending data to this object */
    if (ots_object_properties & BLE_OTC_PRV_APPENDING_DATA_THAT_INCREASES_OBJ_ALLOCATED_SIZE_IS_PERMITTED)
    {
        p_app_value->is_appending_data_to_this_object_that_increases_its_allocated_size_is_permitted = true;
    }
    else
    {
        p_app_value->is_appending_data_to_this_object_that_increases_its_allocated_size_is_permitted = false;
    }

    /* Truncation of this object */
    if (ots_object_properties & BLE_OTC_PRV_TRUNCATION_OF_THIS_OBJECT_IS_PERMITTED)
    {
        p_app_value->is_truncation_of_this_object_is_permitted = true;
    }
    else
    {
        p_app_value->is_truncation_of_this_object_is_permitted = false;
    }

    /* Patching this object by overwriting */
    if (ots_object_properties & BLE_OTC_PRV_PATCHING_BY_OVERWRITING_OBJECT_EXISTING_CONTENTS_IS_PERMITTED)
    {
        p_app_value->is_patching_this_object_by_overwriting_some_of_the_object_s_existing_contents_is_permitted = true;
    }
    else
    {
        p_app_value->is_patching_this_object_by_overwriting_some_of_the_object_s_existing_contents_is_permitted = false;
    }

    /* object is a marked */
    if (ots_object_properties & BLE_OTC_PRV_THIS_OBJECT_IS_A_MARKED_OBJECT)
    {
        p_app_value->is_this_object_is_a_marked_object = true;
    }
    else
    {
        p_app_value->is_this_object_is_a_marked_object = false;
    }

    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_otc_obj_prop_t(const st_ble_otc_obj_prop_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    /* Convert app data to byte sequence. */
    uint32_t pos = 0;

    /* Clear the gatt structure */
    memset(p_gatt_value->p_value, 0x0, BLE_OTC_OBJ_PROP_LEN);
    uint32_t ots_object_properties = 0;

    /* Deletion of this object */
    if (p_app_value->is_deletion_of_this_object_is_permitted)
    {
        /* Set the bit */
        ots_object_properties |= BLE_OTC_PRV_DELETION_OF_THIS_OBJECT_IS_PERMITTED;
    }

    /* Execution of this object */
    if (p_app_value->is_execution_of_this_object_is_permitted)
    {
        /* Set the bit */
        ots_object_properties |= BLE_OTC_PRV_EXECUTION_OF_THIS_OBJECT_IS_PERMITTED;
    }

    /* Reading this object */
    if (p_app_value->is_reading_this_object_is_permitted)
    {
        /* Set the bit */
        ots_object_properties |= BLE_OTC_PRV_READING_THIS_OBJECT_IS_PERMITTED;
    }

    /* Writing data to this object */
    if (p_app_value->is_writing_data_to_this_object_is_permitted)
    {
        /* Set the bit */
        ots_object_properties |= BLE_OTC_PRV_WRITING_DATA_TO_THIS_OBJECT_IS_PERMITTED;
    }

    /* Appending data to this object */
    if (p_app_value->is_appending_data_to_this_object_that_increases_its_allocated_size_is_permitted)
    {
        /* Set the bit */
        ots_object_properties |= BLE_OTC_PRV_APPENDING_DATA_THAT_INCREASES_OBJ_ALLOCATED_SIZE_IS_PERMITTED;
    }

    /* Truncation of this object */
    if (p_app_value->is_truncation_of_this_object_is_permitted)
    {
        /* Set the bit */
        ots_object_properties |= BLE_OTC_PRV_TRUNCATION_OF_THIS_OBJECT_IS_PERMITTED;
    }

    /* Patching this object by overwriting */
    if (p_app_value->is_patching_this_object_by_overwriting_some_of_the_object_s_existing_contents_is_permitted)
    {
        /* Set the bit */
        ots_object_properties |= BLE_OTC_PRV_PATCHING_BY_OVERWRITING_OBJECT_EXISTING_CONTENTS_IS_PERMITTED;
    }

    /* object is a marked */
    if (p_app_value->is_this_object_is_a_marked_object)
    {
        /* Set the bit */
        ots_object_properties |= BLE_OTC_PRV_THIS_OBJECT_IS_A_MARKED_OBJECT;
    }

    BT_PACK_LE_4_BYTE(&(p_gatt_value->p_value[pos]), &ots_object_properties);

    /* Update Length */
    p_gatt_value->value_len = BLE_OTC_OBJ_PROP_LEN;
    return BLE_SUCCESS;
}

/* Object Properties characteristic definition */
const st_ble_servc_char_info_t gs_obj_prop_char = {
    .uuid_16      = BLE_OTC_OBJ_PROP_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_otc_obj_prop_t),
    .db_size      = BLE_OTC_OBJ_PROP_LEN,
    .char_idx     = BLE_OTC_OBJ_PROP_IDX,
    .p_attr_hdls  = gs_obj_prop_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_otc_obj_prop_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_otc_obj_prop_t,
};

ble_status_t R_BLE_OTC_WriteObjProp(uint16_t conn_hdl, const st_ble_otc_obj_prop_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteChar(&gs_obj_prop_char, conn_hdl, p_value);
}

ble_status_t R_BLE_OTC_ReadObjProp(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_obj_prop_char, conn_hdl);
}

void R_BLE_OTC_GetObjPropAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_otc_obj_prop_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_obj_prop_char_ranges[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Object Action Control Point Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Object Action Control Point characteristic descriptors attribute handles */
static uint16_t gs_obj_action_cp_cli_cnfg_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_obj_action_cp_cli_cnfg = {
    .uuid_16 = BLE_OTC_OBJ_ACTION_CP_CLI_CNFG_UUID,
    .uuid_type = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size = sizeof(uint16_t),
    .db_size = BLE_OTC_OBJ_ACTION_CP_CLI_CNFG_LEN,
    .desc_idx = BLE_OTC_OBJ_ACTION_CP_CLI_CNFG_IDX,
    .p_attr_hdls = gs_obj_action_cp_cli_cnfg_desc_hdls,
    .decode = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode = (ble_servc_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_OTC_WriteObjActionCpCliCnfg(uint16_t conn_hdl, const uint16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_obj_action_cp_cli_cnfg, conn_hdl, p_value);
}

ble_status_t R_BLE_OTC_ReadObjActionCpCliCnfg(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_obj_action_cp_cli_cnfg, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Object Action Control Point Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Object Action Control Point characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_obj_action_cp_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

static ble_status_t decode_st_ble_otc_obj_action_cp_t(st_ble_otc_obj_action_cp_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;
    ble_status_t ret = BLE_SUCCESS;

    /* Clear the gatt_value byte sequence */
    memset(p_app_value, 0x0, sizeof(st_ble_otc_obj_action_cp_t));

    /* response opcode */
    BT_UNPACK_LE_1_BYTE(&p_app_value->response_code, &p_gatt_value->p_value[pos++]);

    /* request opcode */
    BT_UNPACK_LE_1_BYTE(&p_app_value->request_op_code, &p_gatt_value->p_value[pos++]);

    /* result code */
    BT_UNPACK_LE_1_BYTE(&p_app_value->result_code, &p_gatt_value->p_value[pos++]);

    /* Copy the response parameter if present */
    if ((BLE_OTC_OBJ_ACTION_CP_OP_CODE_CALCULATE_CHECKSUM == p_app_value->request_op_code)
        && (BLE_OTC_OBJ_ACTION_CP_RESULT_CODE_SUCCESS == p_app_value->result_code))
    {
        BT_UNPACK_LE_4_BYTE(&p_app_value->response_parameter, &p_gatt_value->p_value[pos]);
        pos += 4;
    }
     
    if (p_gatt_value->value_len != pos)
    {
        ret = BLE_ERR_INVALID_DATA;
    }

    return ret;
}

static ble_status_t encode_st_ble_otc_obj_action_cp_t(const st_ble_otc_obj_action_cp_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;
    uint8_t i = 0;

    /* Clear the gatt_value byte sequence */
    memset(p_gatt_value->p_value, 0x0, BLE_OTC_OBJ_ACTION_CP_LEN);

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->op_code);
    pos += 1;

    if (BLE_OTC_OBJ_ACTION_CP_OP_CODE_CREATE == p_app_value->op_code)
    {
        BT_PACK_LE_4_BYTE(&p_gatt_value->p_value[pos], &p_app_value->size);
        pos += 4;

        if (p_app_value->type.uuid_type == BLE_GATT_16_BIT_UUID_FORMAT)
        {
            BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->type.uuid.uuid_16);
            pos += 2;
        }
        else // if (p_app_value->type.uuid_type == BLE_GATT_128_BIT_UUID_FORMAT)
        {
            for (i = 0; i < 16; i++)
            {
                p_gatt_value->p_value[pos++] = p_app_value->type.uuid.uuid_128[i];
            }
        }
    }
    else if (BLE_OTC_OBJ_ACTION_CP_OP_CODE_DELETE == p_app_value->op_code)
    {
        /* Do Nothing */
    }
    else if (BLE_OTC_OBJ_ACTION_CP_OP_CODE_CALCULATE_CHECKSUM == p_app_value->op_code)
    {
        BT_PACK_LE_4_BYTE(&p_gatt_value->p_value[pos] , &p_app_value->offset);
        pos += 4;

        BT_PACK_LE_4_BYTE(&p_gatt_value->p_value[pos] , &p_app_value->length);
        pos += 4;
    }
    else if (BLE_OTC_OBJ_ACTION_CP_OP_CODE_EXECUTE == p_app_value->op_code)
    {
        /* Do Nothing */
    }
    else if (BLE_OTC_OBJ_ACTION_CP_OP_CODE_READ == p_app_value->op_code)
    {
        BT_PACK_LE_4_BYTE(&p_gatt_value->p_value[pos], &p_app_value->offset);
        pos += 4;

        BT_PACK_LE_4_BYTE(&p_gatt_value->p_value[pos], &p_app_value->length);
        pos += 4;
    }
    else if (BLE_OTC_OBJ_ACTION_CP_OP_CODE_WRITE == p_app_value->op_code)
    {
        BT_PACK_LE_4_BYTE(&p_gatt_value->p_value[pos], &p_app_value->offset);
        pos += 4;

        BT_PACK_LE_4_BYTE(&p_gatt_value->p_value[pos], &p_app_value->length);
        pos += 4;

        BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->mode);
        pos += 1;
    }
    else if (BLE_OTC_OBJ_ACTION_CP_OP_CODE_ABORT == p_app_value->op_code)
    {
        /* Do Nothing */
    }
    else
    {
        /* Do Nothing */
    }

    p_gatt_value->value_len = (uint16_t)pos;
    
    return BLE_SUCCESS;
}

/* Object Action Control Point characteristic descriptor definition */
static const st_ble_servc_desc_info_t *gspp_obj_action_cp_descs[] = {
    &gs_obj_action_cp_cli_cnfg,
};

/* Object Action Control Point characteristic definition */
const st_ble_servc_char_info_t gs_obj_action_cp_char = {
    .uuid_16      = BLE_OTC_OBJ_ACTION_CP_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_otc_obj_action_cp_t),
    .db_size      = BLE_OTC_OBJ_ACTION_CP_LEN,
    .char_idx     = BLE_OTC_OBJ_ACTION_CP_IDX,
    .p_attr_hdls  = gs_obj_action_cp_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_otc_obj_action_cp_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_otc_obj_action_cp_t,
    .num_of_descs = ARRAY_SIZE(gspp_obj_action_cp_descs),
    .pp_descs     = gspp_obj_action_cp_descs,
};

ble_status_t R_BLE_OTC_WriteObjActionCp(uint16_t conn_hdl, const st_ble_otc_obj_action_cp_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteChar(&gs_obj_action_cp_char, conn_hdl, p_value);
}

void R_BLE_OTC_GetObjActionCpAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_otc_obj_action_cp_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_obj_action_cp_char_ranges[conn_idx];
    p_hdl->cli_cnfg_desc_hdl = gs_obj_action_cp_cli_cnfg_desc_hdls[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Object List Control Point Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Object List Control Point characteristic descriptors attribute handles */
static uint16_t gs_obj_list_cp_cli_cnfg_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_obj_list_cp_cli_cnfg ={
    .uuid_16     = BLE_OTC_OBJ_LIST_CP_CLI_CNFG_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint16_t),
    .db_size     = BLE_OTC_OBJ_LIST_CP_CLI_CNFG_LEN,
    .desc_idx    = BLE_OTC_OBJ_LIST_CP_CLI_CNFG_IDX,
    .p_attr_hdls = gs_obj_list_cp_cli_cnfg_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_OTC_WriteObjListCpCliCnfg(uint16_t conn_hdl, const uint16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_obj_list_cp_cli_cnfg, conn_hdl, p_value);
}

ble_status_t R_BLE_OTC_ReadObjListCpCliCnfg(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_obj_list_cp_cli_cnfg, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Object List Control Point Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Object List Control Point characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_obj_list_cp_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

static ble_status_t decode_st_ble_otc_obj_list_cp_t(st_ble_otc_obj_list_cp_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    /* Convert app data to byte sequence. */
    uint32_t pos = 0;
    ble_status_t ret = BLE_SUCCESS;

    /* Clear the gatt structure */
    memset(p_app_value, 0x0, sizeof(st_ble_otc_obj_list_cp_t));

    /* response code */
    BT_UNPACK_LE_1_BYTE(&p_app_value->response_code, &p_gatt_value->p_value[pos++]);

    /* request opcode */
    BT_UNPACK_LE_1_BYTE(&p_app_value->request_op_code, &p_gatt_value->p_value[pos++]);

    /* result code */
    BT_UNPACK_LE_1_BYTE(&p_app_value->result_code, &p_gatt_value->p_value[pos++]);

    /* response parameter */
    if ((BLE_OTC_OBJ_LIST_CP_OP_CODE_REQUEST_NUMBER_OF_OBJECTS == p_app_value->request_op_code)
        && (BLE_OTC_OBJ_LIST_CP_RESULT_CODE_SUCCESS == p_app_value->result_code))
    {
        /* response parameter - Total Number of objects */
        BT_UNPACK_LE_4_BYTE(&p_app_value->response_parameter, &p_gatt_value->p_value[pos]);
        pos += 4;
    }

    if (p_gatt_value->value_len != pos)
    {
        ret = BLE_ERR_INVALID_DATA;
    }

    return ret;
}

static ble_status_t encode_st_ble_otc_obj_list_cp_t(const st_ble_otc_obj_list_cp_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;
    uint8_t i = 0;
    
    /* Clear the gatt_value byte sequence */
    memset(p_gatt_value->p_value, 0x0, BLE_OTC_OBJ_LIST_CP_LEN);

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->op_code);
    pos += 1;

    if (BLE_OTC_OBJ_LIST_CP_OP_CODE_GO_TO == p_app_value->op_code)
    {
        for (i = 0; i < 6; i++)
        {
            p_gatt_value->p_value[pos++] = p_app_value->parameter[i];
        }
    }
    else if (BLE_OTC_OBJ_LIST_CP_OP_CODE_ORDER == p_app_value->op_code)
    {
        BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], p_app_value->parameter);
        pos += 1;
    }
    else
    {
        /* Do Nothing */
    }

    /* Update length value */
    p_gatt_value->value_len = (uint16_t)pos;
    return BLE_SUCCESS;
}

/* Object List Control Point characteristic descriptor definition */
static const st_ble_servc_desc_info_t *gspp_obj_list_cp_descs[] = {
    &gs_obj_list_cp_cli_cnfg,
};

/* Object List Control Point characteristic definition */
const st_ble_servc_char_info_t gs_obj_list_cp_char = {
    .uuid_16      = BLE_OTC_OBJ_LIST_CP_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_otc_obj_list_cp_t),
    .db_size      = BLE_OTC_OBJ_LIST_CP_LEN,
    .char_idx     = BLE_OTC_OBJ_LIST_CP_IDX,
    .p_attr_hdls  = gs_obj_list_cp_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_otc_obj_list_cp_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_otc_obj_list_cp_t,
    .num_of_descs = ARRAY_SIZE(gspp_obj_list_cp_descs),
    .pp_descs     = gspp_obj_list_cp_descs,
};

ble_status_t R_BLE_OTC_WriteObjListCp(uint16_t conn_hdl, const st_ble_otc_obj_list_cp_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteChar(&gs_obj_list_cp_char, conn_hdl, p_value);
}

void R_BLE_OTC_GetObjListCpAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_otc_obj_list_cp_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_obj_list_cp_char_ranges[conn_idx];
    p_hdl->cli_cnfg_desc_hdl = gs_obj_list_cp_cli_cnfg_desc_hdls[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Object List Filter 0 Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Object List Filter 0 characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_obj_list_filter_0_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

static ble_status_t decode_st_ble_otc_obj_list_filter_0_t(st_ble_otc_obj_list_filter_0_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;
    uint8_t i = 0;

    if (BLE_OTC_OBJ_LIST_FILTER_0_LEN < p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Clear the application structure */
    memset(p_app_value, 0x0, sizeof(st_ble_otc_obj_list_filter_0_t));

    BT_UNPACK_LE_1_BYTE(&p_app_value->filter, &p_gatt_value->p_value[pos]);
    pos += 1;

    if (BLE_OTC_OBJ_LIST_FILTER_0_FILTER_NO_FILTER == p_app_value->filter)
    {
        /* Do Nothing */
    }
    else if (BLE_OTC_OBJ_LIST_FILTER_0_FILTER_NAME_STARTS_WITH == p_app_value->filter)
    {	
        p_app_value->string.data = &g_obj_filter0_str[0];
        memcpy(p_app_value->string.data, &p_gatt_value->p_value[pos++], (size_t)(p_gatt_value->value_len - 1));
        p_app_value->string.len  = (uint16_t)(p_gatt_value->value_len - 1);
    }
    else if (BLE_OTC_OBJ_LIST_FILTER_0_FILTER_NAME_ENDS_WITH == p_app_value->filter)
    {
        p_app_value->string.data = &g_obj_filter0_str[0];
        memcpy(p_app_value->string.data, &p_gatt_value->p_value[pos++], (size_t)(p_gatt_value->value_len - 1));
        p_app_value->string.len  = (uint16_t)(p_gatt_value->value_len - 1);
    }
    else if (BLE_OTC_OBJ_LIST_FILTER_0_FILTER_NAME_CONTAINS == p_app_value->filter)
    {
        p_app_value->string.data = &g_obj_filter0_str[0];
        memcpy(p_app_value->string.data, &p_gatt_value->p_value[pos++], (size_t)(p_gatt_value->value_len - 1));
        p_app_value->string.len  = (uint16_t)(p_gatt_value->value_len - 1);
    }
    else if (BLE_OTC_OBJ_LIST_FILTER_0_FILTER_NAME_IS_EXACTLY == p_app_value->filter)
    {
        p_app_value->string.data = &g_obj_filter0_str[0];
        memcpy(p_app_value->string.data, &p_gatt_value->p_value[pos++], (size_t)(p_gatt_value->value_len - 1));
        p_app_value->string.len  = (uint16_t)(p_gatt_value->value_len - 1);
    }
    else if (BLE_OTC_OBJ_LIST_FILTER_0_FILTER_OBJECT_TYPE == p_app_value->filter)
    {
        if (BLE_GATT_16_BIT_UUID_SIZE == ((p_gatt_value->value_len - 1 )))
        {
            p_app_value->uuid.uuid_type = BLE_GATT_16_BIT_UUID_FORMAT;
            BT_UNPACK_LE_2_BYTE(&(p_app_value->uuid.uuid.uuid_16), &(p_gatt_value->p_value[pos]));
            pos += 2;
        }
        else if (BLE_GATT_128_BIT_UUID_SIZE == ((p_gatt_value->value_len - 1)))
        {
            p_app_value->uuid.uuid_type = BLE_GATT_128_BIT_UUID_FORMAT;
            for (i = 0; i < BLE_GATT_128_BIT_UUID_SIZE; i++)
            {
                p_app_value->uuid.uuid.uuid_128[i] = p_gatt_value->p_value[pos++];
            }
        }
        else
        {
            /* Nothing */
        }
    }
    else if ((BLE_OTC_OBJ_LIST_FILTER_0_FILTER_CREATED_BETWEEN == p_app_value->filter) || 
            (BLE_OTC_OBJ_LIST_FILTER_0_FILTER_MODIFIED_BETWEEN == p_app_value->filter))
    {
        BT_UNPACK_LE_2_BYTE(&(p_app_value->timestamp1.year), &(p_gatt_value->p_value[pos]));
        pos += 2;

        BT_UNPACK_LE_1_BYTE(&(p_app_value->timestamp1.month), &(p_gatt_value->p_value[pos++]));
        BT_UNPACK_LE_1_BYTE(&(p_app_value->timestamp1.day), &(p_gatt_value->p_value[pos++]));
        BT_UNPACK_LE_1_BYTE(&(p_app_value->timestamp1.hours), &(p_gatt_value->p_value[pos++]));
        BT_UNPACK_LE_1_BYTE(&(p_app_value->timestamp1.minutes), &(p_gatt_value->p_value[pos++]));
        BT_UNPACK_LE_1_BYTE(&(p_app_value->timestamp1.seconds), &(p_gatt_value->p_value[pos++]));
        
        BT_UNPACK_LE_2_BYTE(&(p_app_value->timestamp2.year), &(p_gatt_value->p_value[pos]));
        pos += 2;

        BT_UNPACK_LE_1_BYTE(&(p_app_value->timestamp2.month), &(p_gatt_value->p_value[pos++]));
        BT_UNPACK_LE_1_BYTE(&(p_app_value->timestamp2.day), &(p_gatt_value->p_value[pos++]));
        BT_UNPACK_LE_1_BYTE(&(p_app_value->timestamp2.hours), &(p_gatt_value->p_value[pos++]));
        BT_UNPACK_LE_1_BYTE(&(p_app_value->timestamp2.minutes), &(p_gatt_value->p_value[pos++]));
        BT_UNPACK_LE_1_BYTE(&(p_app_value->timestamp2.seconds), &(p_gatt_value->p_value[pos++]));
    }
    else if (BLE_OTC_OBJ_LIST_FILTER_0_FILTER_CURRENT_SIZE_BETWEEN == p_app_value->filter)
    {
        BT_UNPACK_LE_4_BYTE(&(p_app_value->size1), &(p_gatt_value->p_value[pos]));
        pos += 4;

        BT_UNPACK_LE_4_BYTE(&(p_app_value->size2), &(p_gatt_value->p_value[pos]));
        pos += 4;
    }
    else if (BLE_OTC_OBJ_LIST_FILTER_0_FILTER_ALLOCATED_SIZE_BETWEEN == p_app_value->filter)
    {
        BT_UNPACK_LE_4_BYTE(&(p_app_value->size1), &(p_gatt_value->p_value[pos]));
        pos += 4;

        BT_UNPACK_LE_4_BYTE(&(p_app_value->size2), &(p_gatt_value->p_value[pos]));
        pos += 4;
    }
    else //if (BLE_OTC_OBJ_LIST_FILTER_0_FILTER_MARKED_OBJECTS == p_app_value->filter) or RFU
    {
        /* Do Nothing */
    }
    
    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_otc_obj_list_filter_0_t(const st_ble_otc_obj_list_filter_0_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;
    uint8_t i = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_OTC_OBJ_LIST_FILTER_0_LEN);

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->filter);
    pos += 1;

    if (BLE_OTC_OBJ_LIST_FILTER_0_FILTER_NO_FILTER == p_app_value->filter)
    {
        /* Do Nothing */
    }

    if (BLE_OTC_OBJ_LIST_FILTER_0_FILTER_NAME_STARTS_WITH == p_app_value->filter)
    {
        memcpy(&p_gatt_value->p_value[pos], p_app_value->string.data, p_app_value->string.len);
        pos += p_app_value->string.len;
    }

    if (BLE_OTC_OBJ_LIST_FILTER_0_FILTER_NAME_ENDS_WITH == p_app_value->filter)
    {
        memcpy(&p_gatt_value->p_value[pos], p_app_value->string.data, p_app_value->string.len);
        pos += p_app_value->string.len;
    }

    if (BLE_OTC_OBJ_LIST_FILTER_0_FILTER_NAME_CONTAINS == p_app_value->filter)
    {
        memcpy(&p_gatt_value->p_value[pos], p_app_value->string.data, p_app_value->string.len);
        pos += p_app_value->string.len;
    }

    if (BLE_OTC_OBJ_LIST_FILTER_0_FILTER_NAME_IS_EXACTLY == p_app_value->filter)
    {
        memcpy(&p_gatt_value->p_value[pos], p_app_value->string.data, p_app_value->string.len);
        pos += p_app_value->string.len;
    }

    if (BLE_OTC_OBJ_LIST_FILTER_0_FILTER_OBJECT_TYPE == p_app_value->filter)
    {
        if (p_app_value->uuid.uuid_type == BLE_GATT_16_BIT_UUID_FORMAT)
        {
            p_gatt_value->p_value[pos++] = (uint8_t)p_app_value->uuid.uuid.uuid_16 & 0xFF;
            p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->uuid.uuid.uuid_16 >> 8) & 0xFF);
        }
        else if (p_app_value->uuid.uuid_type == BLE_GATT_128_BIT_UUID_FORMAT)
        {
            for (i = 0; i < 16; i++)
            {
                p_gatt_value->p_value[pos++] = (uint8_t)p_app_value->uuid.uuid.uuid_128[i];
            }
        }
    }

    if (BLE_OTC_OBJ_LIST_FILTER_0_FILTER_CREATED_BETWEEN == p_app_value->filter)
    {
        BT_PACK_LE_2_BYTE(&(p_gatt_value->p_value[pos]), &(p_app_value->timestamp1.year));
        pos += 2;

        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp1.month));
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp1.day));
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp1.hours));
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp1.minutes));
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp1.seconds));

        BT_PACK_LE_2_BYTE(&(p_gatt_value->p_value[pos]), &(p_app_value->timestamp2.year));
        pos += 2;

        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp2.month));
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp2.day));
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp2.hours));
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp2.minutes));
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp2.seconds));
    }

    if (BLE_OTC_OBJ_LIST_FILTER_0_FILTER_MODIFIED_BETWEEN == p_app_value->filter)
    {
        BT_PACK_LE_2_BYTE(&(p_gatt_value->p_value[pos]), &(p_app_value->timestamp1.year));
        pos += 2;

        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp1.month));
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp1.day));
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp1.hours));
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp1.minutes));
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp1.seconds));

        BT_PACK_LE_2_BYTE(&(p_gatt_value->p_value[pos]), &(p_app_value->timestamp2.year));
        pos += 2;

        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp2.month));
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp2.day));
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp2.hours));
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp2.minutes));
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp2.seconds));
    }

    if (BLE_OTC_OBJ_LIST_FILTER_0_FILTER_CURRENT_SIZE_BETWEEN == p_app_value->filter)
    {
        BT_PACK_LE_4_BYTE(&(p_gatt_value->p_value[pos]), &(p_app_value->size1));
        pos += 4;

        BT_PACK_LE_4_BYTE(&(p_gatt_value->p_value[pos]), &(p_app_value->size2));
        pos += 4;
    }

    if (BLE_OTC_OBJ_LIST_FILTER_0_FILTER_ALLOCATED_SIZE_BETWEEN == p_app_value->filter)
    {
        BT_PACK_LE_4_BYTE(&(p_gatt_value->p_value[pos]), &(p_app_value->size1));
        pos += 4;

        BT_PACK_LE_4_BYTE(&(p_gatt_value->p_value[pos]), &(p_app_value->size2));
        pos += 4;
    }

    if (BLE_OTC_OBJ_LIST_FILTER_0_FILTER_MARKED_OBJECTS == p_app_value->filter)
    {
        /* Do Nothing */
    }

    p_gatt_value->value_len = (uint16_t)pos;
    return BLE_SUCCESS;
}

/* Object List Filter 0 characteristic definition */
const st_ble_servc_char_info_t gs_obj_list_filter_0_char = {
    .uuid_16      = BLE_OTC_OBJ_LIST_FILTER_0_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_otc_obj_list_filter_0_t),
    .db_size      = BLE_OTC_OBJ_LIST_FILTER_0_LEN,
    .char_idx     = BLE_OTC_OBJ_LIST_FILTER_0_IDX,
    .p_attr_hdls  = gs_obj_list_filter_0_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_otc_obj_list_filter_0_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_otc_obj_list_filter_0_t,
};

ble_status_t R_BLE_OTC_WriteObjListFilter0(uint16_t conn_hdl, const st_ble_otc_obj_list_filter_0_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteChar(&gs_obj_list_filter_0_char, conn_hdl, p_value);
}

ble_status_t R_BLE_OTC_ReadObjListFilter0(uint16_t conn_hdl, int32_t type) // @suppress("API function naming")
{
    UNUSED_ARG(type);

    return R_BLE_SERVC_ReadChar(&gs_obj_list_filter_0_char, conn_hdl);
    //return R_BLE_SERVC_ReadChar_with_Type(&gs_obj_list_filter_0_char, conn_hdl, type);
}

void R_BLE_OTC_GetObjListFilter0AttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_otc_obj_list_filter_0_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_obj_list_filter_0_char_ranges[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Object List Filter 1 Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Object List Filter 1 characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_obj_list_filter_1_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

static ble_status_t decode_st_ble_otc_obj_list_filter_1_t(st_ble_otc_obj_list_filter_1_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;
    uint8_t i = 0;

    if (BLE_OTC_OBJ_LIST_FILTER_1_LEN <= p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Clear the application structure */
    memset(p_app_value, 0x0, sizeof(st_ble_otc_obj_list_filter_1_t));

    BT_UNPACK_LE_1_BYTE(&p_app_value->filter, &p_gatt_value->p_value[pos]);
    pos += 1;

    if (BLE_OTC_OBJ_LIST_FILTER_1_FILTER_NO_FILTER == p_app_value->filter)
    {
        /* Do Nothing */
    }
    else if (BLE_OTC_OBJ_LIST_FILTER_1_FILTER_NAME_STARTS_WITH == p_app_value->filter)
    {
        p_app_value->string.data = &g_obj_filter1_str[0];
        memcpy(p_app_value->string.data, &p_gatt_value->p_value[pos++], (size_t)(p_gatt_value->value_len - 1));
        p_app_value->string.len  = (uint16_t)(p_gatt_value->value_len - 1);
    }
    else if (BLE_OTC_OBJ_LIST_FILTER_1_FILTER_NAME_ENDS_WITH == p_app_value->filter)
    {
        p_app_value->string.data = &g_obj_filter1_str[0];
        memcpy(p_app_value->string.data, &p_gatt_value->p_value[pos++], (size_t)(p_gatt_value->value_len - 1));
        p_app_value->string.len  = (uint16_t)(p_gatt_value->value_len - 1);
    }
    else if (BLE_OTC_OBJ_LIST_FILTER_1_FILTER_NAME_CONTAINS == p_app_value->filter)
    {
        p_app_value->string.data = &g_obj_filter1_str[0];
        memcpy(p_app_value->string.data, &p_gatt_value->p_value[pos++], (size_t)(p_gatt_value->value_len - 1));
        p_app_value->string.len  = (uint16_t)(p_gatt_value->value_len - 1);
    }
    else if (BLE_OTC_OBJ_LIST_FILTER_1_FILTER_NAME_IS_EXACTLY == p_app_value->filter)
    {
        p_app_value->string.data = &g_obj_filter1_str[0];
        memcpy(p_app_value->string.data, &p_gatt_value->p_value[pos++], (size_t)(p_gatt_value->value_len - 1));
        p_app_value->string.len  = (uint16_t)(p_gatt_value->value_len - 1);
    }

    else if (BLE_OTC_OBJ_LIST_FILTER_1_FILTER_OBJECT_TYPE == p_app_value->filter)
    {
        if (BLE_GATT_16_BIT_UUID_SIZE == ((p_gatt_value->value_len - 1)))
        {
            p_app_value->uuid.uuid_type = BLE_GATT_16_BIT_UUID_FORMAT;
            BT_UNPACK_LE_2_BYTE(&(p_app_value->uuid.uuid.uuid_16), &(p_gatt_value->p_value[pos]));
            pos += 2;
        }
        else if (BLE_GATT_128_BIT_UUID_SIZE == ((p_gatt_value->value_len - 1)))
        {
            p_app_value->uuid.uuid_type = BLE_GATT_128_BIT_UUID_FORMAT;
            for (i = 0; i < BLE_GATT_128_BIT_UUID_SIZE; i++)
            {
                p_app_value->uuid.uuid.uuid_128[i] = p_gatt_value->p_value[pos++];
            }
        }
        else
        {
            /* Nothing */
        }
    }
    else if ((BLE_OTC_OBJ_LIST_FILTER_1_FILTER_CREATED_BETWEEN == p_app_value->filter) || 
            (BLE_OTC_OBJ_LIST_FILTER_1_FILTER_MODIFIED_BETWEEN == p_app_value->filter))
    {
        BT_UNPACK_LE_2_BYTE(&(p_app_value->timestamp1.year), &(p_gatt_value->p_value[pos]));
        pos += 2;

        BT_UNPACK_LE_1_BYTE(&(p_app_value->timestamp1.month), &(p_gatt_value->p_value[pos++]));
        BT_UNPACK_LE_1_BYTE(&(p_app_value->timestamp1.day), &(p_gatt_value->p_value[pos++]));
        BT_UNPACK_LE_1_BYTE(&(p_app_value->timestamp1.hours), &(p_gatt_value->p_value[pos++]));
        BT_UNPACK_LE_1_BYTE(&(p_app_value->timestamp1.minutes), &(p_gatt_value->p_value[pos++]));
        BT_UNPACK_LE_1_BYTE(&(p_app_value->timestamp1.seconds), &(p_gatt_value->p_value[pos++]));
        
        BT_UNPACK_LE_2_BYTE(&(p_app_value->timestamp2.year), &(p_gatt_value->p_value[pos]));
        pos += 2;

        BT_UNPACK_LE_1_BYTE(&(p_app_value->timestamp2.month), &(p_gatt_value->p_value[pos++]));
        BT_UNPACK_LE_1_BYTE(&(p_app_value->timestamp2.day), &(p_gatt_value->p_value[pos++]));
        BT_UNPACK_LE_1_BYTE(&(p_app_value->timestamp2.hours), &(p_gatt_value->p_value[pos++]));
        BT_UNPACK_LE_1_BYTE(&(p_app_value->timestamp2.minutes), &(p_gatt_value->p_value[pos++]));
        BT_UNPACK_LE_1_BYTE(&(p_app_value->timestamp2.seconds), &(p_gatt_value->p_value[pos++]));
    }
    else if (BLE_OTC_OBJ_LIST_FILTER_1_FILTER_CURRENT_SIZE_BETWEEN == p_app_value->filter)
    {
        BT_UNPACK_LE_4_BYTE(&(p_app_value->size1), &(p_gatt_value->p_value[pos]));
        pos += 4;

        BT_UNPACK_LE_4_BYTE(&(p_app_value->size2), &(p_gatt_value->p_value[pos]));
        pos += 4;
    }

    else if (BLE_OTC_OBJ_LIST_FILTER_1_FILTER_ALLOCATED_SIZE_BETWEEN == p_app_value->filter)
    {
        BT_UNPACK_LE_4_BYTE(&(p_app_value->size1), &(p_gatt_value->p_value[pos]));
        pos += 4;

        BT_UNPACK_LE_4_BYTE(&(p_app_value->size2), &(p_gatt_value->p_value[pos]));
        pos += 4;
    }

    else // if (BLE_OTC_OBJ_LIST_FILTER_1_FILTER_MARKED_OBJECTS == p_app_value->filter) or RFU
    {
        /* Do Nothing */
    }
    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_otc_obj_list_filter_1_t(const st_ble_otc_obj_list_filter_1_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;
    uint8_t i = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_OTC_OBJ_LIST_FILTER_1_LEN);

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->filter);
    pos += 1;

    if (BLE_OTC_OBJ_LIST_FILTER_1_FILTER_NO_FILTER == p_app_value->filter)
    {
        /* Do Nothing */
    }

    if (BLE_OTC_OBJ_LIST_FILTER_1_FILTER_NAME_STARTS_WITH == p_app_value->filter)
    {
        memcpy(&p_gatt_value->p_value[pos], p_app_value->string.data, p_app_value->string.len);
        pos += p_app_value->string.len;
    }

    if (BLE_OTC_OBJ_LIST_FILTER_1_FILTER_NAME_ENDS_WITH == p_app_value->filter)
    {
        memcpy(&p_gatt_value->p_value[pos], p_app_value->string.data, p_app_value->string.len);
        pos += p_app_value->string.len;
    }

    if (BLE_OTC_OBJ_LIST_FILTER_1_FILTER_NAME_CONTAINS == p_app_value->filter)
    {
        memcpy(&p_gatt_value->p_value[pos], p_app_value->string.data, p_app_value->string.len);
        pos += p_app_value->string.len;
    }

    if (BLE_OTC_OBJ_LIST_FILTER_1_FILTER_NAME_IS_EXACTLY == p_app_value->filter)
    {
        memcpy(&p_gatt_value->p_value[pos], p_app_value->string.data, p_app_value->string.len);
        pos += p_app_value->string.len;
    }

    if (BLE_OTC_OBJ_LIST_FILTER_1_FILTER_OBJECT_TYPE == p_app_value->filter)
    {
        if (p_app_value->uuid.uuid_type == BLE_GATT_16_BIT_UUID_FORMAT)
        {
            p_gatt_value->p_value[pos++] = (uint8_t)p_app_value->uuid.uuid.uuid_16 & 0xFF;
            p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->uuid.uuid.uuid_16 >> 8) & 0xFF);
        }
        else if (p_app_value->uuid.uuid_type == BLE_GATT_128_BIT_UUID_FORMAT)
        {
            for (i = 0; i < 16; i++)
            {
                p_gatt_value->p_value[pos++] = (uint8_t)p_app_value->uuid.uuid.uuid_128[i];
            }
        }
    }

    if (BLE_OTC_OBJ_LIST_FILTER_1_FILTER_CREATED_BETWEEN == p_app_value->filter)
    {
        BT_PACK_LE_2_BYTE(&(p_gatt_value->p_value[pos]), &(p_app_value->timestamp1.year));
        pos += 2;

        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp1.month));
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp1.day));
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp1.hours));
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp1.minutes));
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp1.seconds));

        BT_PACK_LE_2_BYTE(&(p_gatt_value->p_value[pos]), &(p_app_value->timestamp2.year));
        pos += 2;

        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp2.month));
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp2.day));
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp2.hours));
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp2.minutes));
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp2.seconds));
    }

    if (BLE_OTC_OBJ_LIST_FILTER_1_FILTER_MODIFIED_BETWEEN == p_app_value->filter)
    {
        BT_PACK_LE_2_BYTE(&(p_gatt_value->p_value[pos]), &(p_app_value->timestamp1.year));
        pos += 2;

        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp1.month));
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp1.day));
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp1.hours));
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp1.minutes));
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp1.seconds));

        BT_PACK_LE_2_BYTE(&(p_gatt_value->p_value[pos]), &(p_app_value->timestamp2.year));
        pos += 2;

        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp2.month));
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp2.day));
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp2.hours));
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp2.minutes));
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp2.seconds));
    }

    if (BLE_OTC_OBJ_LIST_FILTER_1_FILTER_CURRENT_SIZE_BETWEEN == p_app_value->filter)
    {
        BT_PACK_LE_4_BYTE(&(p_gatt_value->p_value[pos]), &(p_app_value->size1));
        pos += 4;

        BT_PACK_LE_4_BYTE(&(p_gatt_value->p_value[pos]), &(p_app_value->size2));
        pos += 4;
    }

    if (BLE_OTC_OBJ_LIST_FILTER_1_FILTER_ALLOCATED_SIZE_BETWEEN == p_app_value->filter)
    {
        BT_PACK_LE_4_BYTE(&(p_gatt_value->p_value[pos]), &(p_app_value->size1));
        pos += 4;

        BT_PACK_LE_4_BYTE(&(p_gatt_value->p_value[pos]), &(p_app_value->size2));
        pos += 4;
    }

    if (BLE_OTC_OBJ_LIST_FILTER_1_FILTER_MARKED_OBJECTS == p_app_value->filter)
    {
        /* Do Nothing */
    }

    p_gatt_value->value_len = (uint16_t)pos;
    return BLE_SUCCESS;
}

/* Object List Filter 1 characteristic definition */
const st_ble_servc_char_info_t gs_obj_list_filter_1_char = {
    .uuid_16      = BLE_OTC_OBJ_LIST_FILTER_1_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_otc_obj_list_filter_1_t),
    .db_size      = BLE_OTC_OBJ_LIST_FILTER_1_LEN,
    .char_idx     = BLE_OTC_OBJ_LIST_FILTER_1_IDX,
    .p_attr_hdls  = gs_obj_list_filter_1_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_otc_obj_list_filter_1_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_otc_obj_list_filter_1_t,
};

ble_status_t R_BLE_OTC_WriteObjListFilter1(uint16_t conn_hdl, const st_ble_otc_obj_list_filter_1_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteChar(&gs_obj_list_filter_1_char, conn_hdl, p_value);
}

ble_status_t R_BLE_OTC_ReadObjListFilter1(uint16_t conn_hdl, int32_t type) // @suppress("API function naming")
{
    UNUSED_ARG(type);

    return R_BLE_SERVC_ReadChar(&gs_obj_list_filter_1_char, conn_hdl);
    //return R_BLE_SERVC_ReadChar_with_Type (&gs_obj_list_filter_1_char, conn_hdl, type);
}

void R_BLE_OTC_GetObjListFilter1AttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_otc_obj_list_filter_1_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_obj_list_filter_1_char_ranges[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Object List Filter 2 Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Object List Filter 2 characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_obj_list_filter_2_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

static ble_status_t decode_st_ble_otc_obj_list_filter_2_t(st_ble_otc_obj_list_filter_2_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;
    uint8_t i   = 0;

    if (BLE_OTC_OBJ_LIST_FILTER_2_LEN <= p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Clear the application structure */
    memset(p_app_value, 0x0, sizeof(st_ble_otc_obj_list_filter_2_t));

    BT_UNPACK_LE_1_BYTE(&p_app_value->filter, &p_gatt_value->p_value[pos]);
    pos += 1;

    if (BLE_OTC_OBJ_LIST_FILTER_2_FILTER_NO_FILTER == p_app_value->filter)
    {
        /* Do Nothing */
    }
    else if (BLE_OTC_OBJ_LIST_FILTER_2_FILTER_NAME_STARTS_WITH == p_app_value->filter)
    {
        p_app_value->string.data = &g_obj_filter2_str[0];
        memcpy(p_app_value->string.data, &p_gatt_value->p_value[pos++], (size_t)(p_gatt_value->value_len - 1));
        p_app_value->string.len = (uint16_t)(p_gatt_value->value_len - 1);
    }
    else if (BLE_OTC_OBJ_LIST_FILTER_2_FILTER_NAME_ENDS_WITH == p_app_value->filter)
    {
        p_app_value->string.data = &g_obj_filter2_str[0];
        memcpy(p_app_value->string.data, &p_gatt_value->p_value[pos++], (size_t)(p_gatt_value->value_len - 1));
        p_app_value->string.len = (uint16_t)(p_gatt_value->value_len - 1);
    }
    else if (BLE_OTC_OBJ_LIST_FILTER_2_FILTER_NAME_CONTAINS == p_app_value->filter)
    {
        p_app_value->string.data = &g_obj_filter2_str[0];
        memcpy(p_app_value->string.data, &p_gatt_value->p_value[pos++], (size_t)(p_gatt_value->value_len - 1));
        p_app_value->string.len = (uint16_t)(p_gatt_value->value_len - 1);
    }
    else if (BLE_OTC_OBJ_LIST_FILTER_2_FILTER_NAME_IS_EXACTLY == p_app_value->filter)
    {
        p_app_value->string.data = &g_obj_filter2_str[0];
        memcpy(p_app_value->string.data, &p_gatt_value->p_value[pos++], (size_t)(p_gatt_value->value_len - 1));
        p_app_value->string.len = (uint16_t)(p_gatt_value->value_len - 1);
    }

    else if (BLE_OTC_OBJ_LIST_FILTER_2_FILTER_OBJECT_TYPE == p_app_value->filter)
    {
        if (BLE_GATT_16_BIT_UUID_SIZE == ((p_gatt_value->value_len - 1)))
        {
            p_app_value->uuid.uuid_type = BLE_GATT_16_BIT_UUID_FORMAT;
            BT_UNPACK_LE_2_BYTE(&(p_app_value->uuid.uuid.uuid_16), &(p_gatt_value->p_value[pos]));
            pos += 2;
        }
        else if (BLE_GATT_128_BIT_UUID_SIZE == ((p_gatt_value->value_len - 1)))
        {
            p_app_value->uuid.uuid_type = BLE_GATT_128_BIT_UUID_FORMAT;
            for (i = 0; i < BLE_GATT_128_BIT_UUID_SIZE; i++)
            {
                p_app_value->uuid.uuid.uuid_128[i] = p_gatt_value->p_value[pos++];
            }
        }
        else
        {
            /* Nothing */
        }
    }
    else if ((BLE_OTC_OBJ_LIST_FILTER_2_FILTER_CREATED_BETWEEN == p_app_value->filter) || 
            (BLE_OTC_OBJ_LIST_FILTER_2_FILTER_MODIFIED_BETWEEN == p_app_value->filter))
    {
        BT_UNPACK_LE_2_BYTE(&(p_app_value->timestamp1.year), &(p_gatt_value->p_value[pos]));
        pos += 2;

        BT_UNPACK_LE_1_BYTE(&(p_app_value->timestamp1.month), &(p_gatt_value->p_value[pos++]));
        BT_UNPACK_LE_1_BYTE(&(p_app_value->timestamp1.day), &(p_gatt_value->p_value[pos++]));
        BT_UNPACK_LE_1_BYTE(&(p_app_value->timestamp1.hours), &(p_gatt_value->p_value[pos++]));
        BT_UNPACK_LE_1_BYTE(&(p_app_value->timestamp1.minutes), &(p_gatt_value->p_value[pos++]));
        BT_UNPACK_LE_1_BYTE(&(p_app_value->timestamp1.seconds), &(p_gatt_value->p_value[pos++]));
        
        BT_UNPACK_LE_2_BYTE(&(p_app_value->timestamp2.year), &(p_gatt_value->p_value[pos]));
        pos += 2;

        BT_UNPACK_LE_1_BYTE(&(p_app_value->timestamp2.month), &(p_gatt_value->p_value[pos++]));
        BT_UNPACK_LE_1_BYTE(&(p_app_value->timestamp2.day), &(p_gatt_value->p_value[pos++]));
        BT_UNPACK_LE_1_BYTE(&(p_app_value->timestamp2.hours), &(p_gatt_value->p_value[pos++]));
        BT_UNPACK_LE_1_BYTE(&(p_app_value->timestamp2.minutes), &(p_gatt_value->p_value[pos++]));
        BT_UNPACK_LE_1_BYTE(&(p_app_value->timestamp2.seconds), &(p_gatt_value->p_value[pos++]));
    }
    else if (BLE_OTC_OBJ_LIST_FILTER_2_FILTER_CURRENT_SIZE_BETWEEN == p_app_value->filter)
    {
        BT_UNPACK_LE_4_BYTE(&(p_app_value->size1), &(p_gatt_value->p_value[pos]));
        pos += 4;

        BT_UNPACK_LE_4_BYTE(&(p_app_value->size2), &(p_gatt_value->p_value[pos]));
        pos += 4;
    }

    else if (BLE_OTC_OBJ_LIST_FILTER_2_FILTER_ALLOCATED_SIZE_BETWEEN == p_app_value->filter)
    {
        BT_UNPACK_LE_4_BYTE(&(p_app_value->size1), &(p_gatt_value->p_value[pos]));
        pos += 4;

        BT_UNPACK_LE_4_BYTE(&(p_app_value->size2), &(p_gatt_value->p_value[pos]));
        pos += 4;
    }

    else // if (BLE_OTC_OBJ_LIST_FILTER_2_FILTER_MARKED_OBJECTS == p_app_value->filter) or RFU
    {
        /* Do Nothing */
    }
    
    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_otc_obj_list_filter_2_t(const st_ble_otc_obj_list_filter_2_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;
    uint8_t i   = 0;

    memset(p_gatt_value->p_value, 0x00, BLE_OTC_OBJ_LIST_FILTER_2_LEN);

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->filter);
    pos += 1;

    if (BLE_OTC_OBJ_LIST_FILTER_2_FILTER_NO_FILTER == p_app_value->filter)
    {
        /* Do Nothing */
    }

    if (BLE_OTC_OBJ_LIST_FILTER_2_FILTER_NAME_STARTS_WITH == p_app_value->filter)
    {
        memcpy(&p_gatt_value->p_value[pos], p_app_value->string.data, p_app_value->string.len);
        pos += p_app_value->string.len;
    }

    if (BLE_OTC_OBJ_LIST_FILTER_2_FILTER_NAME_ENDS_WITH == p_app_value->filter)
    {
        memcpy(&p_gatt_value->p_value[pos], p_app_value->string.data, p_app_value->string.len);
        pos += p_app_value->string.len;
    }

    if (BLE_OTC_OBJ_LIST_FILTER_2_FILTER_NAME_CONTAINS == p_app_value->filter)
    {
        memcpy(&p_gatt_value->p_value[pos], p_app_value->string.data, p_app_value->string.len);
        pos += p_app_value->string.len;
    }

    if (BLE_OTC_OBJ_LIST_FILTER_2_FILTER_NAME_IS_EXACTLY == p_app_value->filter)
    {
        memcpy(&p_gatt_value->p_value[pos], p_app_value->string.data, p_app_value->string.len);
        pos += p_app_value->string.len;
    }

    if (BLE_OTC_OBJ_LIST_FILTER_2_FILTER_OBJECT_TYPE == p_app_value->filter)
    {
        if (p_app_value->uuid.uuid_type == BLE_GATT_16_BIT_UUID_FORMAT)
        {
            p_gatt_value->p_value[pos++] = (uint8_t)p_app_value->uuid.uuid.uuid_16 & 0xFF;
            p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->uuid.uuid.uuid_16 >> 8) & 0xFF);
        }
        else if (p_app_value->uuid.uuid_type == BLE_GATT_128_BIT_UUID_FORMAT)
        {
            for (i = 0; i < 16; i++)
            {
                p_gatt_value->p_value[pos++] = (uint8_t)p_app_value->uuid.uuid.uuid_128[i];
            }
        }
    }

    if (BLE_OTC_OBJ_LIST_FILTER_2_FILTER_CREATED_BETWEEN == p_app_value->filter)
    {
        BT_PACK_LE_2_BYTE(&(p_gatt_value->p_value[pos]), &(p_app_value->timestamp1.year));
        pos += 2;

        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp1.month));
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp1.day));
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp1.hours));
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp1.minutes));
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp1.seconds));

        BT_PACK_LE_2_BYTE(&(p_gatt_value->p_value[pos]), &(p_app_value->timestamp2.year));
        pos += 2;

        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp2.month));
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp2.day));
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp2.hours));
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp2.minutes));
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp2.seconds));
    }

    if (BLE_OTC_OBJ_LIST_FILTER_2_FILTER_MODIFIED_BETWEEN == p_app_value->filter)
    {
        BT_PACK_LE_2_BYTE(&(p_gatt_value->p_value[pos]), &(p_app_value->timestamp1.year));
        pos += 2;

        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp1.month));
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp1.day));
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp1.hours));
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp1.minutes));
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp1.seconds));

        BT_PACK_LE_2_BYTE(&(p_gatt_value->p_value[pos]), &(p_app_value->timestamp2.year));
        pos += 2;

        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp2.month));
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp2.day));
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp2.hours));
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp2.minutes));
        BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[pos++]), &(p_app_value->timestamp2.seconds));
    }

    if (BLE_OTC_OBJ_LIST_FILTER_2_FILTER_CURRENT_SIZE_BETWEEN == p_app_value->filter)
    {
        BT_PACK_LE_4_BYTE(&(p_gatt_value->p_value[pos]), &(p_app_value->size1));
        pos += 4;

        BT_PACK_LE_4_BYTE(&(p_gatt_value->p_value[pos]), &(p_app_value->size2));
        pos += 4;
    }

    if (BLE_OTC_OBJ_LIST_FILTER_2_FILTER_ALLOCATED_SIZE_BETWEEN == p_app_value->filter)
    {
        BT_PACK_LE_4_BYTE(&(p_gatt_value->p_value[pos]), &(p_app_value->size1));
        pos += 4;

        BT_PACK_LE_4_BYTE(&(p_gatt_value->p_value[pos]), &(p_app_value->size2));
        pos += 4;
    }

    if (BLE_OTC_OBJ_LIST_FILTER_2_FILTER_MARKED_OBJECTS == p_app_value->filter)
    {
        /* Do Nothing */
    }

    p_gatt_value->value_len = (uint16_t)pos;
    
    return BLE_SUCCESS;
}

/* Object List Filter 2 characteristic definition */
const st_ble_servc_char_info_t gs_obj_list_filter_2_char = {
    .uuid_16      = BLE_OTC_OBJ_LIST_FILTER_2_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_otc_obj_list_filter_2_t),
    .db_size      = BLE_OTC_OBJ_LIST_FILTER_2_LEN,
    .char_idx     = BLE_OTC_OBJ_LIST_FILTER_2_IDX,
    .p_attr_hdls  = gs_obj_list_filter_2_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_otc_obj_list_filter_2_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_otc_obj_list_filter_2_t,
};

ble_status_t R_BLE_OTC_WriteObjListFilter2(uint16_t conn_hdl, const st_ble_otc_obj_list_filter_2_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteChar(&gs_obj_list_filter_2_char, conn_hdl, p_value);
}

ble_status_t R_BLE_OTC_ReadObjListFilter2(uint16_t conn_hdl, int32_t type) // @suppress("API function naming")
{
    UNUSED_ARG(type);

    return R_BLE_SERVC_ReadChar(&gs_obj_list_filter_2_char, conn_hdl);
    //return R_BLE_SERVC_ReadChar_with_Type(&gs_obj_list_filter_2_char, conn_hdl, type);
}

void R_BLE_OTC_GetObjListFilter2AttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_otc_obj_list_filter_2_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_obj_list_filter_2_char_ranges[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Object Changed Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Object Changed characteristic descriptors attribute handles */
static uint16_t gs_obj_changed_cli_cnfg_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_obj_changed_cli_cnfg ={
    .uuid_16     = BLE_OTC_OBJ_CHANGED_CLI_CNFG_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint16_t),
    .db_size     = BLE_OTC_OBJ_CHANGED_CLI_CNFG_LEN,
    .desc_idx    = BLE_OTC_OBJ_CHANGED_CLI_CNFG_IDX,
    .p_attr_hdls = gs_obj_changed_cli_cnfg_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_OTC_WriteObjChangedCliCnfg(uint16_t conn_hdl, const uint16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_obj_changed_cli_cnfg, conn_hdl, p_value);
}

ble_status_t R_BLE_OTC_ReadObjChangedCliCnfg(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_obj_changed_cli_cnfg, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Object Changed Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Object Changed characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_obj_changed_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

static ble_status_t decode_st_ble_otc_obj_changed_t(st_ble_otc_obj_changed_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    /* Convert byte sequence to app data. */
    /*uint8_t pos = 2;*/
    uint8_t otc_obj_change = 0;

    if (BLE_OTC_OBJ_CHANGED_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    BT_UNPACK_LE_2_BYTE(&otc_obj_change, &p_gatt_value->p_value[0]);

    /* Clear the application structure */
    memset(p_app_value, 0x0, sizeof(st_ble_otc_obj_changed_t));

    if (otc_obj_change & BLE_OTC_PRV_SOURCE_OF_CHANGE)
    {
        p_app_value->flags.is_source_of_change = true;
    }
    else
    {
        p_app_value->flags.is_source_of_change = false;
    }

    if (otc_obj_change & BLE_OTC_PRV_CHANGE_OCCURRED_TO_THE_OBJECT_CONTENTS)
    {
        p_app_value->flags.is_change_occurred_to_the_object_contents = true;
    }
    else
    {
        p_app_value->flags.is_change_occurred_to_the_object_contents = false;
    }

    if (otc_obj_change & BLE_OTC_PRV_CHANGE_OCCURRED_TO_THE_OBJECT_METADATA)
    {
        p_app_value->flags.is_change_occurred_to_the_object_metadata = true;
    }
    else
    {
        p_app_value->flags.is_change_occurred_to_the_object_metadata = false;
    }

    if (otc_obj_change & BLE_OTC_PRV_OBJECT_CREATION)
    {
        p_app_value->flags.is_object_creation = true;
    }
    else
    {
        p_app_value->flags.is_object_creation = false;
    }

    if (otc_obj_change & BLE_OTC_PRV_OBJECT_DELETION)
    {
        p_app_value->flags.is_object_deletion = true;
    }
    else
    {
        p_app_value->flags.is_object_deletion = false;
    }

    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_otc_obj_changed_t(const st_ble_otc_obj_changed_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    /* Convert app data to byte sequence. */
    uint32_t  pos = 0;
    uint8_t otc_obj_change = 0;

    /* Clear the gatt structure */
    memset(p_gatt_value->p_value, 0x0, BLE_OTC_OBJ_CHANGED_LEN);

    if (p_app_value->flags.is_source_of_change)
    {
        otc_obj_change |= BLE_OTC_PRV_SOURCE_OF_CHANGE;
    }

    if (p_app_value->flags.is_change_occurred_to_the_object_contents)
    {
        otc_obj_change |= BLE_OTC_PRV_CHANGE_OCCURRED_TO_THE_OBJECT_CONTENTS;
    }

    if (p_app_value->flags.is_change_occurred_to_the_object_metadata)
    {
        otc_obj_change |= BLE_OTC_PRV_CHANGE_OCCURRED_TO_THE_OBJECT_METADATA;
    }

    if (p_app_value->flags.is_object_creation)
    {
        otc_obj_change |= BLE_OTC_PRV_OBJECT_CREATION;
    }

    if (p_app_value->flags.is_object_deletion)
    {
        otc_obj_change |= BLE_OTC_PRV_OBJECT_DELETION;
    }

    BT_PACK_LE_1_BYTE(&(p_gatt_value->p_value[0]), &otc_obj_change);
    pos += 1;
    
    memcpy(&p_gatt_value->p_value[pos], &p_app_value->object_id[0], 6);
    pos += 6;

    /* Update Length */
    p_gatt_value->value_len = (uint16_t)pos;

    return BLE_SUCCESS;
}

/* Object Changed characteristic descriptor definition */
static const st_ble_servc_desc_info_t *gspp_obj_changed_descs[] = {
    &gs_obj_changed_cli_cnfg,
};

/* Object Changed characteristic definition */
const st_ble_servc_char_info_t gs_obj_changed_char = {
    .uuid_16      = BLE_OTC_OBJ_CHANGED_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_otc_obj_changed_t),
    .db_size      = BLE_OTC_OBJ_CHANGED_LEN,
    .char_idx     = BLE_OTC_OBJ_CHANGED_IDX,
    .p_attr_hdls  = gs_obj_changed_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_otc_obj_changed_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_otc_obj_changed_t,
    .num_of_descs = ARRAY_SIZE(gspp_obj_changed_descs),
    .pp_descs     = gspp_obj_changed_descs,
};

void R_BLE_OTC_GetObjChangedAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_otc_obj_changed_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_obj_changed_char_ranges[conn_idx];
    p_hdl->cli_cnfg_desc_hdl = gs_obj_changed_cli_cnfg_desc_hdls[conn_idx];
}


/*----------------------------------------------------------------------------------------------------------------------
    Object Transfer Service client
----------------------------------------------------------------------------------------------------------------------*/

/* Object Transfer Service client attribute handles */
static st_ble_gatt_hdl_range_t gs_otc_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

const st_ble_servc_char_info_t *gspp_otc_chars[] = {
    &gs_feat_char,
    &gs_obj_name_char,
    &gs_obj_type_char,
    &gs_obj_size_char,
    &gs_obj_first_created_char,
    &gs_obj_last_modified_char,
    &gs_obj_id_char,
    &gs_obj_prop_char,
    &gs_obj_action_cp_char,
    &gs_obj_list_cp_char,
    &gs_obj_list_filter_0_char,
    &gs_obj_list_filter_1_char,
    &gs_obj_list_filter_2_char,
    &gs_obj_changed_char,
};

static st_ble_servc_info_t gs_client_info = {
    .pp_chars     = gspp_otc_chars,
    .num_of_chars = ARRAY_SIZE(gspp_otc_chars),
    .p_attr_hdls  = gs_otc_ranges,
};

ble_status_t R_BLE_OTC_Init(ble_servc_app_cb_t cb) // @suppress("API function naming")
{
    if (NULL == cb)
    {
        return BLE_ERR_INVALID_PTR;
    }

    gs_client_info.cb = cb;

    return R_BLE_SERVC_RegisterClient(&gs_client_info);
}

void R_BLE_OTC_ServDiscCb(uint16_t conn_hdl, uint8_t serv_idx, uint16_t type, void *p_param) // @suppress("API function naming")
{
    R_BLE_SERVC_ServDiscCb(&gs_client_info, conn_hdl, serv_idx, type, p_param);
}

void R_BLE_OTC_GetServAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_gatt_hdl_range_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    *p_hdl = gs_otc_ranges[conn_idx];
}
