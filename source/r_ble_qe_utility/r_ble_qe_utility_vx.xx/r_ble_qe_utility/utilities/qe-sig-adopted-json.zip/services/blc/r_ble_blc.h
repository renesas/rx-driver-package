/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_blc.h
 * Version : 1.0
 * Description : The header file for Blood Pressure client.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 31.12.2999 1.00 First Release
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @file
 * @defgroup blc Blood Pressure Service Client
 * @{
 * @ingroup profile
 * @brief   This is the client for the Blood Pressure Service.
 **********************************************************************************************************************/
#include "profile_cmn/r_ble_servc_if.h"

#ifndef R_BLE_BLC_H
#define R_BLE_BLC_H

/*----------------------------------------------------------------------------------------------------------------------
    Blood Pressure Measurement Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_BLC_MEAS_UUID (0x2A35)
#define BLE_BLC_MEAS_LEN (18)
#define BLE_BLC_MEAS_CLI_CNFG_UUID (0x2902)
#define BLE_BLC_MEAS_CLI_CNFG_LEN (2)

      
      
      
      
      
/***************************************************************************//**
 * @brief Blood Pressure Measurement User ID enumeration.
*******************************************************************************/
typedef enum {
    BLE_BLC_MEAS_USER_ID_UNKNOWN_USER = 255, /**< Unknown User */
} e_ble_blc_meas_user_id_t;

      
/***************************************************************************//**
 * @brief Blood Pressure Measurement Pulse Rate Range enumeration.
*******************************************************************************/
typedef enum {
    BLE_BLC_MEAS_PULSE_RATE_RANGE_PULSE_RATE_IS_WITHIN_THE_RANGE = 0, /**< Pulse rate is within the range */
    BLE_BLC_MEAS_PULSE_RATE_RANGE_PULSE_RATE_EXCEEDS_UPPER_LIMIT = 1, /**< Pulse rate exceeds upper limit */
    BLE_BLC_MEAS_PULSE_RATE_RANGE_PULSE_RATE_IS_LESS_THAN_LOWER_LIMIT = 2, /**< Pulse rate is less than lower limit */
} e_ble_blc_meas_pulse_rate_range_t;

      
/***************************************************************************//**
 * @brief Blood Pressure Measurement Flags value structure.
*******************************************************************************/
typedef struct {
    bool is_blood_pressure_units_kpa; /**< Blood Pressure Units Flag is mmHg(false) or kPa(true) */
    bool is_time_stamp_present; /**< Time Stamp Flag */
    bool is_pulse_rate_present; /**< Pulse Rate Flag */
    bool is_user_id_present; /**< User ID Flag */
    bool is_measurement_status_present; /**< Measurement Status Flag */
} st_ble_blc_meas_flags_t;

      
/***************************************************************************//**
 * @brief Blood Pressure Measurement Measurement Status value structure.
*******************************************************************************/
typedef struct {
    bool is_body_movement_detected; /**< Body Movement Detected */
    bool is_cuff_fit_loose; /**< Cuff Fit is Loose */
    bool is_irregular_pulse_detected; /**< Irregular Pulse Detected */
    uint8_t pulse_rate_range; /**< Pulse Rate Range */
    bool is_measurement_position_improper; /**< Measurement Position Improper */
} st_ble_blc_meas_measurement_status_t;

/***************************************************************************//**
 * @brief Blood Pressure Measurement value structure.
*******************************************************************************/
typedef struct {
    st_ble_blc_meas_flags_t flags; /**< Flags */
    st_ble_ieee11073_sfloat_t systolic; /**< Blood Pressure Measurement Compound Value - Systolic (mmHg or kPa) */
    st_ble_ieee11073_sfloat_t diastolic; /**< Blood Pressure Measurement Compound Value - Diastolic (mmHg) */
    st_ble_ieee11073_sfloat_t mean_arterial_pressure; /**< Blood Pressure Measurement Compound Value - Mean Arterial Pressure (mmHg or kPa) */
    st_ble_date_time_t time_stamp; /**< Time Stamp */
    st_ble_ieee11073_sfloat_t pulse_rate; /**< Pulse Rate */
    uint8_t user_id; /**< User ID */
    st_ble_blc_meas_measurement_status_t measurement_status; /**< Measurement Status */
} st_ble_blc_meas_t;

/***************************************************************************//**
 * @brief Blood Pressure Measurement attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
    uint16_t cli_cnfg_desc_hdl;
} st_ble_blc_meas_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Blood Pressure Measurement characteristic Client Characteristic Configuration descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_BLC_ReadMeasCliCnfg(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Blood Pressure Measurement characteristic Client Characteristic Configuration descriptor value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value Blood Pressure Measurement characteristic Client Characteristic Configuration descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_BLC_WriteMeasCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief      Get Blood Pressure Measurement attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_BLC_GetMeasAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_blc_meas_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Intermediate Cuff Pressure Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_BLC_INTERMEDIATE_CUFF_PRESSURE_UUID (0x2A36)
#define BLE_BLC_INTERMEDIATE_CUFF_PRESSURE_LEN (18)
#define BLE_BLC_INTERMEDIATE_CUFF_PRESSURE_CLI_CNFG_UUID (0x2902)
#define BLE_BLC_INTERMEDIATE_CUFF_PRESSURE_CLI_CNFG_LEN (2)

/***************************************************************************//**
 * @brief Intermediate Cuff Pressure attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
    uint16_t cli_cnfg_desc_hdl;
} st_ble_blc_intermediate_cuff_pressure_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Intermediate Cuff Pressure characteristic Client Characteristic Configuration descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_BLC_ReadIntermediateCuffPressureCliCnfg(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Intermediate Cuff Pressure characteristic Client Characteristic Configuration descriptor value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value Intermediate Cuff Pressure characteristic Client Characteristic Configuration descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_BLC_WriteIntermediateCuffPressureCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief      Get Intermediate Cuff Pressure attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_BLC_GetIntermediateCuffPressureAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_blc_intermediate_cuff_pressure_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Blood Pressure Feature Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_BLC_FEAT_UUID (0x2A49)
#define BLE_BLC_FEAT_LEN (2)
/***************************************************************************//**
 * @brief Blood Pressure Feature value structure.
*******************************************************************************/
typedef struct {
    bool is_body_movement_detection_support_bit; /**< Body Movement Detection Support bit */
    bool is_cuff_fit_detection_support_bit; /**< Cuff Fit Detection Support bit */
    bool is_irregular_pulse_detection_support_bit; /**< Irregular Pulse Detection Support bit */
    bool is_pulse_rate_range_detection_support_bit; /**< Pulse Rate Range Detection Support bit */
    bool is_measurement_position_detection_support_bit; /**< Measurement Position Detection Support bit */
    bool is_multiple_bond_support_bit; /**< Multiple Bond Support bit */
} st_ble_blc_feat_t;

/***************************************************************************//**
 * @brief Blood Pressure Feature attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
} st_ble_blc_feat_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Blood Pressure Feature characteristic value from the remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_BLC_ReadFeat(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief      Get Blood Pressure Feature attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_BLC_GetFeatAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_blc_feat_attr_hdl_t *p_hdl);


/*----------------------------------------------------------------------------------------------------------------------
    Blood Pressure Client
----------------------------------------------------------------------------------------------------------------------*/

/***************************************************************************//**
 * @brief Blood Pressure client event data.
*******************************************************************************/
typedef struct {
    uint16_t    conn_hdl;  /**< Connection handle */
    uint16_t    param_len; /**< Event parameter length */
    const void *p_param;   /**< Event parameter */
} st_ble_blc_evt_data_t;

/***************************************************************************//**
 * @brief Blood Pressure characteristic ID.
*******************************************************************************/
typedef enum {
    BLE_BLC_MEAS_IDX,
    BLE_BLC_MEAS_CLI_CNFG_IDX,
    BLE_BLC_INTERMEDIATE_CUFF_PRESSURE_IDX,
    BLE_BLC_INTERMEDIATE_CUFF_PRESSURE_CLI_CNFG_IDX,
    BLE_BLC_FEAT_IDX,
} e_ble_blc_char_idx_t;

/***************************************************************************//**
 * @brief Blood Pressure client event type.
*******************************************************************************/
typedef enum {
    /* Blood Pressure Measurement */
    BLE_BLC_EVENT_MEAS_HDL_VAL_IND = BLE_SERVC_ATTR_EVENT(BLE_BLC_MEAS_IDX, BLE_SERVC_HDL_VAL_IND),
    BLE_BLC_EVENT_MEAS_CLI_CNFG_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_BLC_MEAS_CLI_CNFG_IDX, BLE_SERVC_READ_RSP),
    BLE_BLC_EVENT_MEAS_CLI_CNFG_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_BLC_MEAS_CLI_CNFG_IDX, BLE_SERVC_WRITE_RSP),
    /* Intermediate Cuff Pressure */
    BLE_BLC_EVENT_INTERMEDIATE_CUFF_PRESSURE_HDL_VAL_NTF = BLE_SERVC_ATTR_EVENT(BLE_BLC_INTERMEDIATE_CUFF_PRESSURE_IDX, BLE_SERVC_HDL_VAL_NTF),
    BLE_BLC_EVENT_INTERMEDIATE_CUFF_PRESSURE_CLI_CNFG_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_BLC_INTERMEDIATE_CUFF_PRESSURE_CLI_CNFG_IDX, BLE_SERVC_READ_RSP),
    BLE_BLC_EVENT_INTERMEDIATE_CUFF_PRESSURE_CLI_CNFG_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_BLC_INTERMEDIATE_CUFF_PRESSURE_CLI_CNFG_IDX, BLE_SERVC_WRITE_RSP),
    /* Blood Pressure Feature */
    BLE_BLC_EVENT_FEAT_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_BLC_FEAT_IDX, BLE_SERVC_READ_RSP),
} e_ble_blc_event_t;

/***************************************************************************//**
 * @brief     Initialize Blood Pressure client.
 * @param[in] cb Client callback.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_BLC_Init(ble_servc_app_cb_t cb);

/***************************************************************************//**
 * @brief     Blood Pressure client discovery callback.
 * @param[in] conn_hdl Connection handle
 * @param[in] serv_idx Service instance index.
 * @param[in] type     Service discovery event type.
 * @param[in] p_param  Service discovery event parameter.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_BLC_ServDiscCb(uint16_t conn_hdl, uint8_t serv_idx, uint16_t type, void *p_param);

/***************************************************************************//**
 * @brief     Get Blood Pressure client attribute handle.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
*******************************************************************************/
void R_BLE_BLC_GetServAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_gatt_hdl_range_t *p_hdl);

#endif /* R_BLE_BLC_H */

/** @} */
