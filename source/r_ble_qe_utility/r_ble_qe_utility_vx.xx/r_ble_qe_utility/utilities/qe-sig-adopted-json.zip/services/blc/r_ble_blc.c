/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_blc.c
 * Version : 1.0
 * Description : The source file for Blood Pressure client.
 **********************************************************************************************************************/
#include <string.h>
#include "r_ble_blc.h"
#include "profile_cmn/r_ble_servc_if.h"

static st_ble_servc_info_t gs_client_info;

/*----------------------------------------------------------------------------------------------------------------------
    Blood Pressure Measurement Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Blood Pressure Measurement characteristic descriptors attribute handles */
static uint16_t gs_meas_cli_cnfg_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_meas_cli_cnfg ={
    .uuid_16     = BLE_BLC_MEAS_CLI_CNFG_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint16_t),
    .db_size     = BLE_BLC_MEAS_CLI_CNFG_LEN,
    .desc_idx    = BLE_BLC_MEAS_CLI_CNFG_IDX,
    .p_attr_hdls = gs_meas_cli_cnfg_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_BLC_WriteMeasCliCnfg(uint16_t conn_hdl, const uint16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_meas_cli_cnfg, conn_hdl, p_value);
}

ble_status_t R_BLE_BLC_ReadMeasCliCnfg(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_meas_cli_cnfg, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Blood Pressure Measurement Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Blood Pressure Measurement characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_meas_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

static ble_status_t decode_st_ble_blc_meas_t(st_ble_blc_meas_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;

    p_app_value->flags.is_blood_pressure_units_kpa   = !!(p_gatt_value->p_value[pos] & 0x01);
    p_app_value->flags.is_time_stamp_present         = !!(p_gatt_value->p_value[pos] & 0x02);
    p_app_value->flags.is_pulse_rate_present         = !!(p_gatt_value->p_value[pos] & 0x04);
    p_app_value->flags.is_user_id_present            = !!(p_gatt_value->p_value[pos] & 0x08);
    p_app_value->flags.is_measurement_status_present = !!(p_gatt_value->p_value[pos] & 0x10);
    pos++;

    pos += unpack_st_ble_ieee11073_sfloat_t(&p_app_value->systolic, &p_gatt_value->p_value[pos]);
    pos += unpack_st_ble_ieee11073_sfloat_t(&p_app_value->diastolic, &p_gatt_value->p_value[pos]);
    pos += unpack_st_ble_ieee11073_sfloat_t(&p_app_value->mean_arterial_pressure, &p_gatt_value->p_value[pos]);

    if (p_app_value->flags.is_time_stamp_present)
    {
        pos += unpack_st_ble_date_time_t(&p_app_value->time_stamp, &p_gatt_value->p_value[pos]);
    }

    if (p_app_value->flags.is_pulse_rate_present)
    {
        pos += unpack_st_ble_ieee11073_sfloat_t(&p_app_value->pulse_rate, &p_gatt_value->p_value[pos]);
    }

    if (p_app_value->flags.is_user_id_present)
    {
        p_app_value->user_id = p_gatt_value->p_value[pos++];
    }

    if (p_app_value->flags.is_measurement_status_present)
    {
        p_app_value->measurement_status.is_body_movement_detected        = !!(p_gatt_value->p_value[pos] & 0x01);
        p_app_value->measurement_status.is_cuff_fit_loose                = !!(p_gatt_value->p_value[pos] & 0x02);
        p_app_value->measurement_status.is_irregular_pulse_detected      = !!(p_gatt_value->p_value[pos] & 0x04);
        p_app_value->measurement_status.pulse_rate_range                 = (p_gatt_value->p_value[pos] >> 3) & 0x03;
        p_app_value->measurement_status.is_measurement_position_improper = !!(p_gatt_value->p_value[pos] & 0x20);
    }

    return BLE_SUCCESS;
}

/* Blood Pressure Measurement characteristic descriptor definition */
static const st_ble_servc_desc_info_t *gspp_meas_descs[] = {
    &gs_meas_cli_cnfg,
};

/* Blood Pressure Measurement characteristic definition */
static const st_ble_servc_char_info_t gs_meas_char = {
    .uuid_16      = BLE_BLC_MEAS_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_blc_meas_t),
    .db_size      = BLE_BLC_MEAS_LEN,
    .char_idx     = BLE_BLC_MEAS_IDX,
    .p_attr_hdls  = gs_meas_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_blc_meas_t,
    .num_of_descs = ARRAY_SIZE(gspp_meas_descs),
    .pp_descs     = gspp_meas_descs,
};

void R_BLE_BLC_GetMeasAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_blc_meas_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_meas_char_ranges[conn_idx];
    p_hdl->cli_cnfg_desc_hdl = gs_meas_cli_cnfg_desc_hdls[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Intermediate Cuff Pressure Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Intermediate Cuff Pressure characteristic descriptors attribute handles */
static uint16_t gs_intermediate_cuff_pressure_cli_cnfg_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_intermediate_cuff_pressure_cli_cnfg ={
    .uuid_16     = BLE_BLC_INTERMEDIATE_CUFF_PRESSURE_CLI_CNFG_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint16_t),
    .db_size     = BLE_BLC_INTERMEDIATE_CUFF_PRESSURE_CLI_CNFG_LEN,
    .desc_idx    = BLE_BLC_INTERMEDIATE_CUFF_PRESSURE_CLI_CNFG_IDX,
    .p_attr_hdls = gs_intermediate_cuff_pressure_cli_cnfg_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_BLC_WriteIntermediateCuffPressureCliCnfg(uint16_t conn_hdl, const uint16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_intermediate_cuff_pressure_cli_cnfg, conn_hdl, p_value);
}

ble_status_t R_BLE_BLC_ReadIntermediateCuffPressureCliCnfg(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_intermediate_cuff_pressure_cli_cnfg, conn_hdl);
}

/*----------------------------------------------------------------------------------------------------------------------
    Intermediate Cuff Pressure Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Intermediate Cuff Pressure characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_intermediate_cuff_pressure_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

/* Intermediate Cuff Pressure characteristic descriptor definition */
static const st_ble_servc_desc_info_t *gspp_intermediate_cuff_pressure_descs[] = {
    &gs_intermediate_cuff_pressure_cli_cnfg,
};

/* Intermediate Cuff Pressure characteristic definition */
const st_ble_servc_char_info_t gs_intermediate_cuff_pressure_char = {
    .uuid_16      = BLE_BLC_INTERMEDIATE_CUFF_PRESSURE_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_blc_meas_t),
    .db_size      = BLE_BLC_INTERMEDIATE_CUFF_PRESSURE_LEN,
    .char_idx     = BLE_BLC_INTERMEDIATE_CUFF_PRESSURE_IDX,
    .p_attr_hdls  = gs_intermediate_cuff_pressure_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_blc_meas_t,
    .num_of_descs = ARRAY_SIZE(gspp_intermediate_cuff_pressure_descs),
    .pp_descs     = gspp_intermediate_cuff_pressure_descs,
};

void R_BLE_BLC_GetIntermediateCuffPressureAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_blc_intermediate_cuff_pressure_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_intermediate_cuff_pressure_char_ranges[conn_idx];
    p_hdl->cli_cnfg_desc_hdl = gs_intermediate_cuff_pressure_cli_cnfg_desc_hdls[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Blood Pressure Feature Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Blood Pressure Feature characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_feat_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

static ble_status_t decode_st_ble_blc_feat_t(st_ble_blc_feat_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    p_app_value->is_body_movement_detection_support_bit        = !!(p_gatt_value->p_value[0] & 0x01);
    p_app_value->is_cuff_fit_detection_support_bit             = !!(p_gatt_value->p_value[0] & 0x02);
    p_app_value->is_irregular_pulse_detection_support_bit      = !!(p_gatt_value->p_value[0] & 0x04);
    p_app_value->is_pulse_rate_range_detection_support_bit     = !!(p_gatt_value->p_value[0] & 0x08);
    p_app_value->is_measurement_position_detection_support_bit = !!(p_gatt_value->p_value[0] & 0x10);
    p_app_value->is_multiple_bond_support_bit                  = !!(p_gatt_value->p_value[0] & 0x20);

    return BLE_SUCCESS;
}

static ble_status_t encode_st_ble_blc_feat_t(const st_ble_blc_feat_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    p_gatt_value->p_value[0] = (uint8_t)((p_app_value->is_body_movement_detection_support_bit ? 0x01 : 0x00)
                             | (p_app_value->is_cuff_fit_detection_support_bit ? 0x02 : 0x00)
                             | (p_app_value->is_irregular_pulse_detection_support_bit ? 0x04 : 0x00)
                             | (p_app_value->is_pulse_rate_range_detection_support_bit ? 0x08 : 0x00)
                             | (p_app_value->is_measurement_position_detection_support_bit ? 0x10 : 0x00)
                             | (p_app_value->is_multiple_bond_support_bit ? 0x20 : 0x00));

    return BLE_SUCCESS;
}

/* Blood Pressure Feature characteristic definition */
static const st_ble_servc_char_info_t gs_feat_char = {
    .uuid_16      = BLE_BLC_FEAT_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_blc_feat_t),
    .db_size      = BLE_BLC_FEAT_LEN,
    .char_idx     = BLE_BLC_FEAT_IDX,
    .p_attr_hdls  = gs_feat_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_blc_feat_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_blc_feat_t,
};

ble_status_t R_BLE_BLC_ReadFeat(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_feat_char, conn_hdl);
}

void R_BLE_BLC_GetFeatAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_blc_feat_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_feat_char_ranges[conn_idx];
}


/*----------------------------------------------------------------------------------------------------------------------
    Blood Pressure client
----------------------------------------------------------------------------------------------------------------------*/

/* Blood Pressure client attribute handles */
static st_ble_gatt_hdl_range_t gs_blc_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

const st_ble_servc_char_info_t *gspp_blc_chars[] = {
    &gs_meas_char,
    &gs_intermediate_cuff_pressure_char,
    &gs_feat_char,
};

static st_ble_servc_info_t gs_client_info = {
    .pp_chars     = gspp_blc_chars,
    .num_of_chars = ARRAY_SIZE(gspp_blc_chars),
    .p_attr_hdls  = gs_blc_ranges,
};

ble_status_t R_BLE_BLC_Init(ble_servc_app_cb_t cb) // @suppress("API function naming")
{
    if (NULL == cb)
    {
        return BLE_ERR_INVALID_PTR;
    }

    gs_client_info.cb = cb;

    return R_BLE_SERVC_RegisterClient(&gs_client_info);
}

void R_BLE_BLC_ServDiscCb(uint16_t conn_hdl, uint8_t serv_idx, uint16_t type, void *p_param) // @suppress("API function naming")
{
    R_BLE_SERVC_ServDiscCb(&gs_client_info, conn_hdl, serv_idx, type, p_param);
}

void R_BLE_BLC_GetServAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_gatt_hdl_range_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    *p_hdl = gs_blc_ranges[conn_idx];
}
