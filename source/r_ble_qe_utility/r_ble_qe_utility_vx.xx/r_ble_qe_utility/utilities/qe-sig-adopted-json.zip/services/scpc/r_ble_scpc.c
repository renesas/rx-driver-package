/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2018 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_scpc.c
 * Version : 1.0
 * Description : This module implements Scan Parameters Service Client.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 31.12.2999 1.00 First Release
 ***********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <string.h>
#include "r_ble_rx23w_if.h"
#include "r_ble_scpc.h"
#include "discovery/r_ble_disc.h"

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/

/* Version number */
#define BLE_SCPC_PRV_VERSION_MAJOR (1)
#define BLE_SCPC_PRV_VERSION_MINOR (0)

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/
typedef struct
{
    uint16_t conn_hdl;
    st_ble_scpc_hdls_t hdls;
} st_scpc_peer_param_t;

/***********************************************************************************************************************
Exported global variables (to be accessed by other files)
***********************************************************************************************************************/
const uint8_t BLE_SCPC_UUID[BLE_GATT_16_BIT_UUID_SIZE] = { 0x13, 0x18 };
const uint8_t BLE_SCPC_SCAN_INTERVAL_WINDOW_UUID[BLE_GATT_16_BIT_UUID_SIZE] = { 0x4F, 0x2A };
const uint8_t BLE_SCPC_SCAN_REFRESH_UUID[BLE_GATT_16_BIT_UUID_SIZE] = { 0x31, 0x2A };
const uint8_t BLE_SCPC_SCAN_REFRESH_CLIENT_CHARACTERISTIC_CONFIGURATION_UUID[BLE_GATT_16_BIT_UUID_SIZE] = { 0x02, 0x29 };

/***********************************************************************************************************************
Private global variables and functions
***********************************************************************************************************************/
static st_scpc_peer_param_t gs_peer_params[7];
static ble_scpc_app_cb_t gs_scpc_cb;

/***********************************************************************************************************************
 * Function Name: find_peer_param
 * Description  : This function finds the attribute handles for the given connection handle.
 * Arguments    : conn_hdl - handle to connection
 * Return Value : pointer to the attribute handles structure
 **********************************************************************************************************************/
static st_scpc_peer_param_t *find_peer_param(uint16_t conn_hdl)
{
    for (uint8_t i = 0; i < 7; i++)
    {
        if ((BLE_GAP_INVALID_CONN_HDL != gs_peer_params[i].conn_hdl) &&
            (gs_peer_params[i].conn_hdl == conn_hdl))
        {
            return &gs_peer_params[i];
        }
    }
    return NULL;
}

/***********************************************************************************************************************
 * Function Name: get_new_peer_param
 * Description  : This function finds the free attribute handle.
 * Arguments    : conn_hdl - handle to connection.
 * Return Value : pointer to the free attribute handles structure
 **********************************************************************************************************************/
static st_scpc_peer_param_t *get_new_peer_param(uint16_t conn_hdl)
{
    for (uint8_t i = 0; i < 7; i++)
    {
        if (BLE_GAP_INVALID_CONN_HDL == gs_peer_params[i].conn_hdl)
        {
            gs_peer_params[i].conn_hdl = conn_hdl;
            return &gs_peer_params[i];
        }
    }
    return NULL;
}

/***********************************************************************************************************************
 * Function Name: clear_peer_param
 * Description  : This function frees all the attribute handles.
 * Arguments    : p_peer - pointer to the attribute handle structure to be freed
 * Return Value : none
***********************************************************************************************************************/
static void clear_peer_param(st_scpc_peer_param_t *p_peer)
{
    if (NULL != p_peer)
    {
        p_peer->conn_hdl = BLE_GAP_INVALID_CONN_HDL;
        memset(&p_peer->hdls, 0x00, sizeof(p_peer->hdls));
    }
}

/***********************************************************************************************************************
 * Function Name: encode_scan_interval_window
 * Description  : This function converts Scan Interval Window characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the Scan Interval Window  value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : none
 **********************************************************************************************************************/
static void encode_scan_interval_window(const st_ble_scpc_scan_interval_window_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    /* Convert app data to byte sequence. */
    p_gatt_value->value_len = 4;
    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[0], &p_app_value->le_scan_interval);
    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[2], &p_app_value->le_scan_window);

}

/***********************************************************************************************************************
 * Function Name: scpc_gattc_cb
 * Description  : Callback function for the Scan Parameters GATTC events.
 * Arguments    : conn_hdl - handle to the connection
 *                result - ble status
 *              : p_data - pointer to GATTC event data
 * Return Value : none
***********************************************************************************************************************/
static void scpc_gattc_cb(uint16_t type, ble_status_t result, st_ble_gattc_evt_data_t *p_data) // @suppress("Function length")
{
    st_scpc_peer_param_t *p_peer = find_peer_param(p_data->conn_hdl);

    switch (type)
    {
        case BLE_GATTC_EVENT_HDL_VAL_NTF:
        {
            st_ble_gattc_ntf_evt_t *p_ntf_evt_param =
                (st_ble_gattc_ntf_evt_t *)p_data->p_param;
            if (p_ntf_evt_param->data.attr_hdl == p_peer->hdls.scan_refresh_char_val_hdl)
            {
                uint8_t app_value;
                BT_UNPACK_LE_1_BYTE(&app_value, p_ntf_evt_param->data.value.p_value);

                st_ble_scpc_evt_data_t evt_data = {
                    .conn_hdl  = p_data->conn_hdl,
                    .param_len = sizeof(app_value),
                    .p_param   = &app_value,
                };
                gs_scpc_cb(BLE_SCPC_EVENT_SCAN_REFRESH_HDL_VAL_NTF, result, &evt_data);
            }
        } break;

        default:
        {
            /* Do nothing. */
        } break;
    }
}

ble_status_t R_BLE_SCPC_Init(const st_ble_scpc_init_param_t *p_param) // @suppress("API function naming")
{
    if (NULL == p_param)
    {
        return BLE_ERR_INVALID_PTR;
    }

    if (NULL == p_param->cb)
    {
        return BLE_ERR_INVALID_ARG;
    }

    for (uint8_t i = 0; i < 7; i++)
    {
        clear_peer_param(&gs_peer_params[i]);
    }

    R_BLE_GATTC_RegisterCb(scpc_gattc_cb, 2);

    gs_scpc_cb = p_param->cb;

    return BLE_SUCCESS;
}

ble_status_t R_BLE_SCPC_Connect(uint16_t conn_hdl, const st_ble_scpc_connect_param_t *p_param) // @suppress("API function naming")
{
    st_scpc_peer_param_t *p_peer = get_new_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if ((NULL != p_param) && (NULL != p_param->p_hdls))
    {
        memcpy(&p_peer->hdls, p_param->p_hdls, sizeof(p_peer->hdls));
    }

    return BLE_SUCCESS;
}

ble_status_t R_BLE_SCPC_Disconnect(uint16_t conn_hdl, st_ble_scpc_disconnect_param_t *p_param) // @suppress("API function naming")
{
    st_scpc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if ((NULL != p_param) && (NULL != p_param->p_hdls))
    {
        memcpy(p_param->p_hdls, &p_peer->hdls, sizeof(*p_param->p_hdls));
    }

    clear_peer_param(p_peer);

    return BLE_SUCCESS;
}
ble_status_t R_BLE_SCPC_WriteWithoutRspScanIntervalWindow(uint16_t conn_hdl, const st_ble_scpc_scan_interval_window_t *p_app_value) // @suppress("API function naming")
{
    st_scpc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (NULL == p_app_value)
    {
        return BLE_ERR_INVALID_PTR;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.scan_interval_window_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    uint8_t byte_value[BLE_SCPC_SCAN_INTERVAL_WINDOW_LEN] = { 0 };

    st_ble_gatt_hdl_value_pair_t wwr_value = {
        .attr_hdl  = p_peer->hdls.scan_interval_window_char_val_hdl,
        .value = {
            .p_value   = byte_value,
            .value_len = BLE_SCPC_SCAN_INTERVAL_WINDOW_LEN,
        }
    };
    encode_scan_interval_window(p_app_value, &wwr_value.value);

    return R_BLE_GATTC_WriteCharWithoutRsp(conn_hdl, &wwr_value);
}


ble_status_t R_BLE_SCPC_SetScanRefreshCliCnfg(uint16_t conn_hdl, uint16_t cli_cnfg) // @suppress("API function naming")
{
    st_scpc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.scan_refresh_cli_cnfg_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    if (0 != (cli_cnfg & 0xFFFC))
    {
        return BLE_ERR_INVALID_ARG;
    }

    uint8_t byte_value[2] = { 0 };
    BT_PACK_LE_2_BYTE(byte_value, &cli_cnfg);

    st_ble_gatt_hdl_value_pair_t gatt_value = {
        .attr_hdl = p_peer->hdls.scan_refresh_cli_cnfg_hdl,
        .value = {
            .p_value   = byte_value,
            .value_len = 2,
        }
    };

    return R_BLE_GATTC_WriteChar(conn_hdl, &gatt_value);
}


void R_BLE_SCPC_ServDiscCb(uint16_t conn_hdl, uint8_t idx, uint16_t type, void *p_param) // @suppress("API function naming")
{
    st_scpc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    switch (type)
    {
        case BLE_DISC_PRIM_SERV_FOUND:
        {
            st_disc_serv_param_t *p_serv_param = (st_disc_serv_param_t *)p_param;
            memcpy(&p_peer->hdls.service_range, &p_serv_param->value.serv_16.range, sizeof(p_peer->hdls.service_range));
        } break;

        case BLE_DISC_CHAR_FOUND:
        {
            st_disc_char_param_t *p_char_param = (st_disc_char_param_t *)p_param;

            if (BLE_GATT_16_BIT_UUID_FORMAT == p_char_param->uuid_type)
            {
                uint8_t uuid_16[BLE_GATT_16_BIT_UUID_SIZE] = {
                    (uint8_t)((p_char_param->value.char_16.uuid_16 >> 0) & 0xFF),
                    (uint8_t)((p_char_param->value.char_16.uuid_16 >> 8) & 0xFF),
                };

                if (0 == memcmp(uuid_16, BLE_SCPC_SCAN_INTERVAL_WINDOW_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.scan_interval_window_char_val_hdl = p_char_param->value.char_16.value_hdl;

                    for (uint8_t i = 0; i < p_char_param->num_of_descs; i++)
                    {
                        uuid_16[0] = (uint8_t)((p_char_param->descs[i].value.desc_16.uuid_16 >> 0) & 0xFF);
                        uuid_16[1] = (uint8_t)((p_char_param->descs[i].value.desc_16.uuid_16 >> 8) & 0xFF);

                    }
                }
                else if (0 == memcmp(uuid_16, BLE_SCPC_SCAN_REFRESH_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.scan_refresh_char_val_hdl = p_char_param->value.char_16.value_hdl;

                    for (uint8_t i = 0; i < p_char_param->num_of_descs; i++)
                    {
                        uuid_16[0] = (uint8_t)((p_char_param->descs[i].value.desc_16.uuid_16 >> 0) & 0xFF);
                        uuid_16[1] = (uint8_t)((p_char_param->descs[i].value.desc_16.uuid_16 >> 8) & 0xFF);

                        if (0 == memcmp(uuid_16, BLE_SCPC_SCAN_REFRESH_CLIENT_CHARACTERISTIC_CONFIGURATION_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                        {
                            p_peer->hdls.scan_refresh_cli_cnfg_hdl = p_char_param->descs[i].value.desc_16.desc_hdl;
                        }
                    }
                }
            }
            else if (BLE_GATT_128_BIT_UUID_FORMAT == p_char_param->uuid_type)
            {
            }
            else
            {
                /* Do nothing. */
            }
        } break;

        default:
        {
            /* Do nothing. */
        } break;
    }
}

uint32_t R_BLE_SCPC_GetVersion(void) // @suppress("API function naming")
{
    uint32_t version;

    version = ((BLE_SCPC_PRV_VERSION_MAJOR << 16) | (BLE_SCPC_PRV_VERSION_MINOR << 8));

    return version;
}

