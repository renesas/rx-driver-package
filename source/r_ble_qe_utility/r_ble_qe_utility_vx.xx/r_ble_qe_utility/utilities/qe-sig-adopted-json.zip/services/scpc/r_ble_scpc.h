/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2018 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_scpc.h
 * Version : 1.0
 * Description : This module implements Scan Parameters Service Client.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 31.12.2999 1.00 First Release
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @file
 * @defgroup scpc Scan Parameters Service Client
 * @{
 * @ingroup profile
 * @brief This file provides APIs to interface Scan Parameters Service Client.
 **********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_ble_rx23w_if.h"

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
#ifndef R_BLE_SCPC
#define R_BLE_SCPC

/*******************************************************************************************************************//**
 * @brief Scan Interval Window characteristic value length.
***********************************************************************************************************************/
#define BLE_SCPC_SCAN_INTERVAL_WINDOW_LEN (4)
/*******************************************************************************************************************//**
 * @brief Scan Refresh characteristic value length.
***********************************************************************************************************************/
#define BLE_SCPC_SCAN_REFRESH_LEN (1)

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @brief Scan Parameters Service Client event data.
***********************************************************************************************************************/
typedef struct
{
    uint16_t  conn_hdl;  /**< Connection handle */
    uint16_t  param_len; /**< Event parameter length */
    void     *p_param;   /**< Event parameter */
} st_ble_scpc_evt_data_t;

/*******************************************************************************************************************//**
 * @brief Scan Parameters Service Client event callback.
***********************************************************************************************************************/
typedef void (*ble_scpc_app_cb_t)(uint16_t type, ble_status_t result, st_ble_scpc_evt_data_t *p_data);

/*******************************************************************************************************************//**
 * @brief Scan Parameters Service Client event type.
***********************************************************************************************************************/
typedef enum {
    BLE_SCPC_EVENT_SCAN_REFRESH_HDL_VAL_NTF, /**< Scan Refresh characteristic handle value notification event */
    BLE_SCPC_EVENT_CLI_CNFG_WRITE_RSP, /**< Cli Cnfig write response */
    BLE_SCPC_EVENT_ERROR_RSP, /**< error response */
} e_ble_scpc_event_t;

/*******************************************************************************************************************//**
 * @brief Scan Refresh Value enumeration.
***********************************************************************************************************************/
typedef enum {
    BLE_SCPC_SCAN_REFRESH_SCAN_REFRESH_VALUE_SERVER_REQUIRES_REFRESH = 0, /**< TODO */
} e_ble_scpc_scan_refresh_t;

/*******************************************************************************************************************//**
 * @brief Scan Parameters Service attribute handles.
***********************************************************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t service_range; /**< Scan Parameters Service range */
    uint16_t scan_interval_window_char_val_hdl; /**< Scan Interval Window characteristic value handle */
    uint16_t scan_refresh_char_val_hdl; /**< Scan Refresh characteristic value handle */
    uint16_t scan_refresh_cli_cnfg_hdl; /**< Scan Refresh characteristic Client Characteristic Configuration descriptor handle */
} st_ble_scpc_hdls_t;

/*******************************************************************************************************************//**
 * @brief Scan Parameters Service initialization parameters.
***********************************************************************************************************************/
typedef struct {
    ble_scpc_app_cb_t cb; /**< Scan Parameters Service Client event handler */
} st_ble_scpc_init_param_t;

/*******************************************************************************************************************//**
 * @brief Scan Parameters Service Client connection parameters.
***********************************************************************************************************************/
typedef struct {
    st_ble_scpc_hdls_t *p_hdls; /**< Scan Parameters Service handles */
} st_ble_scpc_connect_param_t;

/*******************************************************************************************************************//**
 * @brief Scan Parameters Service disconnection parameters.
***********************************************************************************************************************/
typedef struct {
    st_ble_scpc_hdls_t *p_hdls; /**< Scan Parameters Service handles */
} st_ble_scpc_disconnect_param_t;

/*******************************************************************************************************************//**
 * @brief Scan Interval Window characteristic parameters.
***********************************************************************************************************************/
typedef struct {
    uint16_t le_scan_interval; /**< LE_Scan_Interval value */
    uint16_t le_scan_window; /**< LE_Scan_Window value */
} st_ble_scpc_scan_interval_window_t;

/*******************************************************************************************************************//**
 * @brief Scan Refresh Client Characteristic Configuration descriptor parameters.
***********************************************************************************************************************/
typedef struct {
    uint8_t value[1];  /**< Scan Refresh characteristic value */
} st_ble_scpc_scan_refresh_client_characteristic_configuration_t;

/***********************************************************************************************************************
Exported global variables (to be accessed by other files)
***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @brief Scan Parameters Service UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_SCPC_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Scan Interval Window characteristic UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_SCPC_SCAN_INTERVAL_WINDOW_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Scan Refresh characteristic UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_SCPC_SCAN_REFRESH_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/***********************************************************************************************************************
Exported global functions (to be accessed by other files)
***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @brief     Initialize Scan Parameters Service  Client.
 * @details   This function shall be called once at startup.
 * @param[in] param Scan Parameters Service Client initialization parameters.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_SCPC_Init(const st_ble_scpc_init_param_t *p_param);

/*******************************************************************************************************************//**
 * @brief     Perform Scan Parameters Service Client connection settings.
 * @details   This function shall be called on each connection establishment.
 * @param[in] conn_hdl Connection handle.
 * @param[in] param    Connection parameters.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_SCPC_Connect(uint16_t conn_hdl, const st_ble_scpc_connect_param_t *p_param);

/*******************************************************************************************************************//**
 * @brief     Retrieve Scan Parameters Service Client connection specific settings before disconnection.
 * @details   This function shall be called on each disconnection.
 * @param[in] conn_hdl Connection handle.
 * @param[in] param    Disconnection parameters.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_SCPC_Disconnect(uint16_t conn_hdl, st_ble_scpc_disconnect_param_t *p_param);

/*******************************************************************************************************************//**
 * @brief     Write Scan Interval Window characteristic value without response to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] app_value Scan Interval Window characteristic value to write.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_SCPC_WriteWithoutRspScanIntervalWindow(uint16_t conn_hdl, st_ble_scpc_scan_interval_window_t *p_app_value);

/*******************************************************************************************************************//**
 * @brief     Set Scan Refresh characteristic cli cnfg.
 * @param[in] conn_hdl Connection handle.
 * @param[in] cli_cnfg Scan Refresh characteristic cli cnfg to set.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_SCPC_SetScanRefreshCliCnfg(uint16_t conn_hdl, uint16_t cli_cnfg);

/***********************************************************************************************************************
 * @brief      Callback function for the Scan Parameters Discovery events.
 * @param[out] conn_hdl Connection handle.
 * @param[out] idx      Service index used to distiguish the multiple same UUID service.
 * @param[out] type     Discovery event type
 * @param[out] p_data   Pointer to GATTC event data.
***********************************************************************************************************************/
void R_BLE_SCPC_ServDiscCb(uint16_t conn_hdl, uint8_t idx, uint16_t type, void *p_param);

/*******************************************************************************************************************//**
 * @brief     Return version of the SCPC service client.
 * @return    version
***********************************************************************************************************************/
uint32_t R_BLE_SCPC_GetVersion(void);

#endif /* R_BLE_SCPC */

/** @} */
