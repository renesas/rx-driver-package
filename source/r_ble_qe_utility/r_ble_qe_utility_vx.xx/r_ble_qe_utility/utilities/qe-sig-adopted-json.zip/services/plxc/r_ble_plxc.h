/***********************************************************************************************************************//**
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************//**
* File Name: r_ble_plxc.h
* Version : 1.0
* Description : This module implements Pulse Oximeter Service Client.
**********************************************************************************************************************/
/***********************************************************************************************************************//**
* History : DD.MM.YYYY Version Description
*         : 22.03.2019 1.00 First Release
***********************************************************************************************************************/

/***********************************************************************************************************************//**
* @file
* @defgroup plxc Pulse Oximeter Service Client
* @{
* @ingroup profile
* @brief This file provides APIs to interface Pulse Oximeter Service Client.
**********************************************************************************************************************/

/***********************************************************************************************************************//**
* Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "profile_cmn/r_ble_serv_common.h"

/***********************************************************************************************************************//**
* Macro definitions
***********************************************************************************************************************/
#ifndef R_BLE_PLXC_H
#define R_BLE_PLXC_H

/***********************************************************************************************************************//**
* @brief Record Access Control Point characteristic value length.
***********************************************************************************************************************/
#define BLE_PLXC_RECORD_ACCESS_CONTROL_POINT_LEN                                                (4)
         
/***********************************************************************************************************************//**
* Typedef definitions
***********************************************************************************************************************/

/***********************************************************************************************************************//**
* @brief Pulse Oximeter Service Client event data.
***********************************************************************************************************************/
typedef struct
{
    uint16_t  conn_hdl;   /**< Connection handle */
    uint16_t  param_len;  /**< Event parameter length */
    void      *p_param;   /**< Event parameter */
} st_ble_plxc_evt_data_t;

/***********************************************************************************************************************//**
* @brief Pulse Oximeter Service Client event callback.
***********************************************************************************************************************/
typedef void (*ble_plxc_app_cb_t)(uint16_t type, ble_status_t result, st_ble_plxc_evt_data_t *p_data);

/***********************************************************************************************************************//**
* @brief Pulse Oximeter Service Client event type.
***********************************************************************************************************************/
typedef enum 
{
    BLE_PLXC_EVENT_PLX_SPOT_CHECK_MEASUREMENT_HDL_VAL_IND,    
    /**< PLX Spot-Check Measurement characteristic handle value indication event */
    BLE_PLXC_EVENT_PLX_CONTINUOUS_MEASUREMENT_HDL_VAL_NTF,    
    /**< PLX Continuous Measurement characteristic handle value notification event */
    BLE_PLXC_EVENT_PLX_FEATURES_READ_RSP,                     
    /**< PLX Features characteristic read response event */
    BLE_PLXC_EVENT_RECORD_ACCESS_CONTROL_POINT_HDL_VAL_IND,   
    /**< Record Access Control Point characteristic handle value indication event */
    BLE_PLXC_EVENT_RECORD_ACCESS_CONTROL_POINT_WRITE_RSP,     
    /**< Record Access Control Point characteristic write response event */
    BLE_PLXC_EVENT_CLI_CNFG_WRITE_RSP,                        
    /**< Cli Cnfig write response */
    BLE_PLXC_EVENT_ERROR_RSP,                                 
    /**< error response */
} e_ble_plxc_event_t;

/*******************************************************************************************************************//**
* @brief Op Code enumeration.
***********************************************************************************************************************/
typedef enum
{
    BLE_PLXC_RECORD_ACCESS_CONTROL_POINT_OP_CODE_RESERVED_FOR_FUTURE_USE__OPERATOR_N_A_                                                 = 0,
    /**< Record Access Control Point Records OP CODE Reserved for Future Use */
    BLE_PLXC_RECORD_ACCESS_CONTROL_POINT_OP_CODE_REPORT_STORED_RECORDS__OPERATOR__VALUE_FROM_OPERATOR_TABLE_                            = 1,
    /**< Record Access Control Point OP CODE Report Stored Records Operator Value */
    BLE_PLXC_RECORD_ACCESS_CONTROL_POINT_OP_CODE_DELETE_STORED_RECORDS__OPERATOR__VALUE_FROM_OPERATOR_TABLE_                            = 2,
    /**< Record Access Control Point OP CODE Delete Stored Records Operated Value */
    BLE_PLXC_RECORD_ACCESS_CONTROL_POINT_OP_CODE_ABORT_OPERATION__OPERATOR__NULL__VALUE_OF_0X00_FROM_OPERATOR_TABLE__                   = 3,
    /**< Record Access Control Point OP CODE Abort Operation Operator Null Value  */
    BLE_PLXC_RECORD_ACCESS_CONTROL_POINT_OP_CODE_REPORT_NUMBER_OF_STORED_RECORDS__OPERATOR__VALUE_FROM_OPERATOR_TABLE_                  = 4,
    /**< Record Access Control Point OP CODE Reports Number of Stored Records Operator Value*/
    BLE_PLXC_RECORD_ACCESS_CONTROL_POINT_OP_CODE_NUMBER_OF_STORED_RECORDS_RESPONSE__OPERATOR__NULL__VALUE_OF_0X00_FROM_OPERATOR_TABLE__ = 5,
    /**< Record Access Control Point OP CODE Reports Number of Stored Records Response Operator Null Value */
    BLE_PLXC_RECORD_ACCESS_CONTROL_POINT_OP_CODE_RESPONSE_CODE__OPERATOR__NULL__VALUE_OF_0X00_FROM_OPERATOR_TABLE__                     = 6,
    /**< Record Access Control Point OP CODE Responce Code for Operator Null Value */
} e_ble_plxc_record_access_control_point_op_code_t;

/*******************************************************************************************************************//**
* @brief Operator enumeration.
***********************************************************************************************************************/
typedef enum
{
    BLE_PLXC_RECORD_ACCESS_CONTROL_POINT_OPERATOR_NULL                                      = 0,
    /**< Record Access Control Point Operator of Null Records */
    BLE_PLXC_RECORD_ACCESS_CONTROL_POINT_OPERATOR_ALL_RECORDS                               = 1,
    /**< Record Access Control Point Operator of All Records */
    BLE_PLXC_RECORD_ACCESS_CONTROL_POINT_OPERATOR_LESS_THAN_OR_EQUAL_TO                     = 2,
    /**< Record Access Control Point Operator of Records Lees then or Equal to Stored Records*/
    BLE_PLXC_RECORD_ACCESS_CONTROL_POINT_OPERATOR_GREATER_THAN_OR_EQUAL_TO                  = 3,
    /**< Record Access Control Point operator of Records Greater than or Equal to Stored Records */
    BLE_PLXC_RECORD_ACCESS_CONTROL_POINT_OPERATOR_WITHIN_RANGE_OF__INCLUSIVE_               = 4,
    /**< Record Access Control Point Operator of within Range of Inclusive records */
    BLE_PLXC_RECORD_ACCESS_CONTROL_POINT_OPERATOR_FIRST_RECORD_I_E__OLDEST_RECORD_          = 5,
    /**< Record Access Control Point Operator of First Record of IE Oldest  */
    BLE_PLXC_RECORD_ACCESS_CONTROL_POINT_OPERATOR_LAST_RECORD__I_E__MOST_RECENT_RECORD_     = 6,
    /**< Record Access Control Point Operator of Last Record of IE Most Recent  */
} e_ble_plxc_record_access_control_point_operator_t;

/*******************************************************************************************************************//**
 * @brief Operand_Values enumeration.
***********************************************************************************************************************/
typedef enum 
{
    BLE_PLXC_RECORD_ACCESS_CONTROL_POINT_OPERAND_VALUES_N_A                                                          = 0,
    /**< Not applicable */
    BLE_PLXC_RECORD_ACCESS_CONTROL_POINT_OPERAND_VALUES_FILTER_PARAMETERS__AS_APPROPRIATE_TO_OPERATOR_AND_SERVICE_1  = 1,
    /**< Filter parameters (as appropriate to Operator and Service) */
    BLE_PLXC_RECORD_ACCESS_CONTROL_POINT_OPERAND_VALUES_FILTER_PARAMETERS__AS_APPROPRIATE_TO_OPERATOR_AND_SERVICE_2  = 2,
    /**< Filter parameters (as appropriate to Operator and Service) */
    BLE_PLXC_RECORD_ACCESS_CONTROL_POINT_OPERAND_VALUES_NOT_INCLUDED                                                 = 3,
    /**< Not included */
    BLE_PLXC_RECORD_ACCESS_CONTROL_POINT_OPERAND_VALUES_FILTER_PARAMETERS__AS_APPROPRIATE_TO_OPERATOR_AND_SERVICE_3  = 4,
    /**< Filter parameters (as appropriate to Operator and Service) */
    BLE_PLXC_RECORD_ACCESS_CONTROL_POINT_OPERAND_VALUES_NUMBER_OF_RECORDS__FIELD_SIZE_DEFINED_PER_SERVICE_           = 5,
    /**< Number of Records (Field size defined per service) */
    BLE_PLXC_RECORD_ACCESS_CONTROL_POINT_OPERAND_VALUES_REQUEST_OP_CODE__RESPONSE_CODE_VALUE                         = 6,
    /**< Request Op Code, Response Code Value */
} e_ble_plxc_record_access_control_point_operand_t;

/*******************************************************************************************************************//**
 * @brief Operand_Reponse_Code_Values enumeration.
***********************************************************************************************************************/
typedef enum 
{
    BLE_PLXC_RECORD_ACCESS_CONTROL_POINT_OPERAND_REPONSE_CODE_VALUES_RESERVED_FOR_FUTURE_USE        = 0,
    /**< Not applicable */
    BLE_PLXC_RECORD_ACCESS_CONTROL_POINT_OPERAND_REPONSE_CODE_VALUES_SUCCESS                        = 1,
    /**< Normal response for successful operation */
    BLE_PLXC_RECORD_ACCESS_CONTROL_POINT_OPERAND_REPONSE_CODE_VALUES_OP_CODE_NOT_SUPPORTED          = 2,
    /**< Normal response if unsupported Op Code is received */
    BLE_PLXC_RECORD_ACCESS_CONTROL_POINT_OPERAND_REPONSE_CODE_VALUES_INVALID_OPERATOR               = 3,
    /**< Normal response if Operator received does not meet the requirements of the service (e.g. Null was expected) */
    BLE_PLXC_RECORD_ACCESS_CONTROL_POINT_OPERAND_REPONSE_CODE_VALUES_OPERATOR_NOT_SUPPORTED         = 4,
    /**< Normal response if unsupported Operator is received */
    BLE_PLXC_RECORD_ACCESS_CONTROL_POINT_OPERAND_REPONSE_CODE_VALUES_INVALID_OPERAND                = 5,
    /**< Normal response if Operand received does not meet the requirements of the service */
    BLE_PLXC_RECORD_ACCESS_CONTROL_POINT_OPERAND_REPONSE_CODE_VALUES_NO_RECORDS_FOUND               = 6,
    /**< Normal response if request to report stored records or request to delete stored records resulted in no records meeting criteria. */
    BLE_PLXC_RECORD_ACCESS_CONTROL_POINT_OPERAND_REPONSE_CODE_VALUES_ABORT_UNSUCCESSFUL             = 7,
    /**< Normal response if request for Abort cannot be completed */
    BLE_PLXC_RECORD_ACCESS_CONTROL_POINT_OPERAND_REPONSE_CODE_VALUES_PROCEDURE_NOT_COMPLETED        = 8,
    /**< Normal response if unable to complete a procedure for any reason */
    BLE_PLXC_RECORD_ACCESS_CONTROL_POINT_OPERAND_REPONSE_CODE_VALUES_OPERAND_NOT_SUPPORTED          = 9,
    /**< Normal response if unsupported Operand is received */
} e_ble_plxc_record_access_control_point_operand_response_code_vale_t;

/***********************************************************************************************************************//**
* @brief Pulse Oximeter Service attribute handles.
***********************************************************************************************************************/
typedef struct
{
    st_ble_gatt_hdl_range_t        service_range;                            
    /**< Pulse Oximeter Service range */
    uint16_t                       plx_spot_check_measurement_char_val_hdl;  
    /**< PLX Spot-Check Measurement characteristic value handle */
    uint16_t                       plx_spot_check_measurement_cli_cnfg_hdl;  
    /**< PLX Spot-Check Measurement characteristic Client Characteristic Configuration descriptor handle */
    uint16_t                       plx_continuous_measurement_char_val_hdl;  
    /**< PLX Continuous Measurement characteristic value handle */
    uint16_t                       plx_continuous_measurement_cli_cnfg_hdl;  
    /**< PLX Continuous Measurement characteristic Client Characteristic Configuration descriptor handle */
    uint16_t                       plx_features_char_val_hdl;                
    /**< PLX Features characteristic value handle */
    uint16_t                       record_access_control_point_char_val_hdl;
    /**< Record Access Control Point characteristic value handle */
    uint16_t                       record_access_control_point_cli_cnfg_hdl; 
    /**< Record Access Control Point characteristic Client Characteristic Configuration descriptor handle */
} st_ble_plxc_hdls_t;

/***********************************************************************************************************************//**
* @brief Pulse Oximeter Service initialization parameters.
***********************************************************************************************************************/
typedef struct
{
    ble_plxc_app_cb_t cb; /**< Pulse Oximeter Service Client event handler */
} st_ble_plxc_init_param_t;

/***********************************************************************************************************************//**
* @brief Pulse Oximeter Service Client connection parameters.
***********************************************************************************************************************/
typedef struct 
{
    st_ble_plxc_hdls_t *p_hdls; /**< Pulse Oximeter Service handles */
} st_ble_plxc_connect_param_t;

/*******************************************************************************************************************//**
* @brief Pulse Oximeter Service disconnection parameters.
***********************************************************************************************************************/
typedef struct
{
    st_ble_plxc_hdls_t *p_hdls; /**< Pulse Oximeter Service handles */
} st_ble_plxc_disconnect_param_t;

/*******************************************************************************************************************//**
* @brief PLX Spot-Check Measurement characteristic parameters.
***********************************************************************************************************************/
typedef struct 
{
    bool                           is_timestamp_present;               /**< Timestamp field is present  */
    bool                           is_measurement_status_present;      
    /**< Measurement Status field is present */
    bool                           is_device_and_sensor_status_present;
    /**< Device and Sensor Status field is present */
    bool                           is_pulse_amplitude_index_present;   
    /**< Pulse Amplitude Index field is present*/
    bool                           is_device_clock_present;            /**< Device Clock is Not Set*/
    st_ble_ieee11073_sfloat_t      spo2pr_spot_check___spo2;           /**< SpO2PR-Spot-Check - SpO2 value */
    st_ble_ieee11073_sfloat_t      spo2pr_spot_check___pr;             /**< SpO2PR-Spot-Check - PR value */
    st_ble_date_time_t             timestamp;                          /**< Timestamp value */

    /* measurement status definitions bit fields */
    bool is_measurement_ongoing;                               /**< Measurement Ongoing */
    bool is_early_estimated_data;                              /**< Early Estimated Data */
    bool is_validated_data;                                    /**< Validated Data */
    bool is_fully_qualified_data;                              /**< Fully Qualified Data */
    bool is_data_from_measurement_storage;                     /**< Data from Measurement Storage */
    bool is_data_for_demonstration;                            /**< Data for Demonstration */
    bool is_data_for_testing;                                  /**< Data for Testing */
    bool is_calibration_ongoing;                               /**< Calibration Ongoing */
    bool is_measurement_unavailable;                           /**< Measurement Unavailable */
    bool is_questionable_measurement_detected;                 /**< Questionable Measurement Detected */
    bool is_invalid_measurement_detected;                      /**< Invalid Measurement Detected */

    /* device and sensor status support bit fields */
    bool is_extended_display_update_ongoing;                   /**< Extended Display Update Ongoing */
    bool is_equipment_malfunction_detected;                    /**< Equipment Malfunction Detected */
    bool is_signal_processing_irregularity_detected;           /**< Signal Processing Irregularity Detected */
    bool is_inadequate_signal_detected;                        /**< Inadequate Signal Detected */
    bool is_poor_signal_detected;                              /**< Poor Signal Detected */
    bool is_low_perfusion_detected;                            /**< Low Perfusion Detected */
    bool is_erratic_perfusion_detected;                        /**< Erratic Signal Detected */
    bool is_non_pulsatile_signal_detected;                     /**< Non-Pulsatile Signal Detected */
    bool is_questionable_pulse_detected;                       /**< Questionable Pulse Detected */
    bool is_siganl_analysis_ongoing;                           /**< Signal Analysis Ongoing */
    bool is_sensor_interference_detected;                      /**< Sensor Interference Detected */
    bool is_sensor_unconnected_to_user;                        /**< Sensor Unconnected to User */
    bool is_unknown_sensor_connected;                          /**< Unknown Sensor Connected */
    bool is_sensor_displaced;                                  /**< Sensor Displaced */
    bool is_sensor_malfunctioning;                             /**< Sensor Malfunctioning */
    bool is_sensor_disconnected;                               /**< Sensor Disconnected */

    st_ble_ieee11073_sfloat_t      pulse_amplitude_index;      /**< Pulse Amplitude Index value */
} st_ble_plxc_plx_spot_check_measurement_t;

/*******************************************************************************************************************//**
* @brief PLX Continuous Measurement characteristic parameters.
***********************************************************************************************************************/
typedef struct 
{
    bool                            is_spo2pr_fast_pr_present;             /**< SpO2PR-Slow field is present*/
    bool                            is_spo2pr_slow_pr_present;             /**< SpO2PR-Slow field is present*/
    bool                            is_measurement_status_present;         
    /**< Measurement Status field is present*/
    bool                            is_device_and_sensor_status_present;   
    /**< Device and Sensor Status field is present*/
    bool                            pulse_amplitude_index_present;         
    /**< Pulse Amplitude Index field is present*/
    st_ble_ieee11073_sfloat_t       spo2pr_normal___spo2;                  /**< SpO2PR-Normal - SpO2 value */
    st_ble_ieee11073_sfloat_t       spo2pr_normal___pr;                    /**< SpO2PR-Normal - PR value */
    st_ble_ieee11073_sfloat_t       spo2pr_fast___spo2;                    /**< SpO2PR-Fast - SpO2 value */
    st_ble_ieee11073_sfloat_t       spo2pr_fast___pr;                      /**< SpO2PR-Fast - PR value */
    st_ble_ieee11073_sfloat_t       spo2pr_slow___spo2;                    /**< SpO2PR-Slow - SpO2 value */
    st_ble_ieee11073_sfloat_t       spo2pr_slow___pr;                      /**< SpO2PR-Slow - PR value */


    /* measurement status definitions bit fields */
    bool is_measurement_ongoing;                                     /**< Measurement Ongoing */
    bool is_early_estimated_data;                                    /**< Early Estimated Data */
    bool is_validated_data;                                          /**< Validated Data */
    bool is_fully_qualified_data;                                    /**< Fully Qualified Data */
    bool is_data_from_measurement_storage;                           /**< Data from Measurement Storage */
    bool is_data_for_demonstration;                                  /**< Data for Demonstration */
    bool is_data_for_testing;                                        /**< Data for Testing */
    bool is_calibration_ongoing;                                     /**< Calibration Ongoing */
    bool is_measurement_unavailable;                                 /**< Measurement Unavailable */
    bool is_questionable_measurement_detected;                       /**< Questionable Measurement Detected */
    bool is_invalid_measurement_detected;                            /**< Invalid Measurement Detected */

    /* device and sensor status definitions bit fields */
    bool is_extended_display_update_ongoing;                         /**< Extended Display Update Ongoing */
    bool is_equipment_malfunction_detected;                          /**< Equipment Malfunction Detected */
    bool is_signal_processing_irregularity_detected;                 /**< Signal Processing Irregularity Detected */
    bool is_inadequate_signal_detected;                              /**< Inadequate Signal Detected */
    bool is_poor_signal_detected;                                    /**< Poor Signal Detected */
    bool is_low_perfusion_detected;                                  /**< Low Perfusion Detected */
    bool is_erratic_perfusion_detected;                              /**< Erratic Signal Detected */
    bool is_non_pulsatile_signal_detected;                           /**< Non-Pulsatile Signal Detected */
    bool is_questionable_pulse_detected;                             /**< Questionable Pulse Detected */
    bool is_siganl_analysis_ongoing;                                 /**< Signal Analysis Ongoing */
    bool is_sensor_interference_detected;                            /**< Sensor Interference Detected */
    bool is_sensor_unconnected_to_user;                              /**< Sensor Unconnected to User */
    bool is_unknown_sensor_connected;                                /**< Unknown Sensor Connected */
    bool is_sensor_displaced;                                        /**< Sensor Displaced */
    bool is_sensor_malfunctioning;                                   /**< Sensor Malfunctioning */
    bool is_sensor_disconnected;                                     /**< Sensor Disconnected */

    st_ble_ieee11073_sfloat_t       pulse_amplitude_index;           /**< Pulse Amplitude Index value */
} st_ble_plxc_plx_continuous_measurement_t;

/*******************************************************************************************************************//**
* @brief PLX Features characteristic parameters.
***********************************************************************************************************************/
typedef struct 
{
    /* supported_features bit fields */
    bool is_measurement_status_support_present;                      /**< Measurement Status support is present */
    bool is_device_sensor_status_support_present;                    /**< Device and Sensor Status support is present */
    bool is_measurement_storage_spot_check_measurement_supported;    /**< Measurement Storage for Spot-check measurements is supported */
    bool is_timestamp_spot_check_measurement_supported;              /**< Timestamp for Spot-check measurements is supported */
    bool is_spO2pr_fast_metric_supported;                            /**< SpO2PR-Fast metric is supported */
    bool is_spO2pr_slow_metric_supported;                            /**< SpO2PR-Slow metric is supported */
    bool is_pulse_amplitude_index_field_supported;                   /**< Pulse Amplitude Index field is supported */
    bool is_multiple_bonds_supported;                                /**< Multiple Bonds Supported */

    /* measurement status bit fields */
    bool is_measurement_ongoing;                                     /**< Measurement Ongoing */
    bool is_early_estimated_data;                                    /**< Early Estimated Data */
    bool is_validated_data;                                          /**< Validated Data */
    bool is_fully_qualified_data;                                    /**< Fully Qualified Data */
    bool is_data_from_measurement_storage;                           /**< Data from Measurement Storage */
    bool is_data_for_demonstration;                                  /**< Data for Demonstration */
    bool is_data_for_testing;                                        /**< Data for Testing */
    bool is_calibration_ongoing;                                     /**< Calibration Ongoing */
    bool is_measurement_unavailable;                                 /**< Measurement Unavailable */
    bool is_questionable_measurement_detected;                       /**< Questionable Measurement Detected */
    bool is_invalid_measurement_detected;                            /**< Invalid Measurement Detected */

    /* device and sensor status bit fields */
    bool is_extended_display_update_ongoing;                         /**< Extended Display Update Ongoing */
    bool is_equipment_malfunction_detected;                          /**< Equipment Malfunction Detected */
    bool is_signal_processing_irregularity_detected;                 /**< Signal Processing Irregularity Detected */
    bool is_inadequate_signal_detected;                              /**< Inadequate Signal Detected */
    bool is_poor_signal_detected;                                    /**< Poor Signal Detected */
    bool is_low_perfusion_detected;                                  /**< Low Perfusion Detected */
    bool is_erratic_perfusion_detected;                              /**< Erratic Signal Detected */
    bool is_non_pulsatile_signal_detected;                           /**< Non-Pulsatile Signal Detected */
    bool is_questionable_pulse_detected;                             /**< Questionable Pulse Detected */
    bool is_siganl_analysis_ongoing;                                 /**< Signal Analysis Ongoing */
    bool is_sensor_interference_detected;                            /**< Sensor Interference Detected */
    bool is_sensor_unconnected_to_user;                              /**< Sensor Unconnected to User */
    bool is_unknown_sensor_connected;                                /**< Unknown Sensor Connected */
    bool is_sensor_displaced;                                        /**< Sensor Displaced */
    bool is_sensor_malfunctioning;                                   /**< Sensor Malfunctioning */
    bool is_sensor_disconnected;                                     /**< Sensor Disconnected */
} st_ble_plxc_plx_features_t;

/*******************************************************************************************************************//**
* @brief Record Access Control Point characteristic parameters.
***********************************************************************************************************************/
typedef struct
{
    uint8_t racp_op_code;                                           /**< Op Code value */
    uint8_t racp_operator;                                          /**< Operator value */
    uint8_t operand_values[8];     /**< Operand value */
    uint8_t operand_reponse_code_values[10];     /**< Operand response code value */
} st_ble_plxc_record_access_control_point_t;

/***********************************************************************************************************************//**
*Exported global variables (to be accessed by other files)
***********************************************************************************************************************/
/*******************************************************************************************************************//**
* @brief Pulse Oximeter Service UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_PLXC_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
* @brief PLX Spot-Check Measurement characteristic UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_PLXC_PLX_SPOT_CHECK_MEASUREMENT_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
* @brief PLX Continuous Measurement characteristic UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_PLXC_PLX_CONTINUOUS_MEASUREMENT_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
* @brief PLX Features characteristic UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_PLXC_PLX_FEATURES_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
* @brief Record Access Control Point characteristic UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_PLXC_RECORD_ACCESS_CONTROL_POINT_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/***********************************************************************************************************************//**
* Exported global functions (to be accessed by other files)
***********************************************************************************************************************/
/*******************************************************************************************************************//**
* @brief     Initialize Pulse Oximeter Service  Client.
* @details   This function shall be called once at startup.
* @param[in] p_param Pointer to the Pulse Oximeter Service  Client initialization parameters.
* @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_PLXC_Init(const st_ble_plxc_init_param_t *p_param);

/*******************************************************************************************************************//**
* @brief     Perform Pulse Oximeter Service Client connection settings.
* @details   This function shall be called on each connection establishment.
* @param[in] conn_hdl Connection handle.
* @param[in] p_param Pointer to the  Connection parameters.
* @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_PLXC_Connect(uint16_t conn_hdl, const st_ble_plxc_connect_param_t *p_param);

/*******************************************************************************************************************//**
* @brief     Retrieve Pulse Oximeter Service Client connection specific settings before disconnection.
* @details   This function shall be called on each disconnection.
* @param[in] conn_hdl Connection handle.
* @param[in] p_param Pointer to the    Disconnection parameters.
* @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_PLXC_Disconnect(uint16_t conn_hdl, st_ble_plxc_disconnect_param_t *p_param);

/*******************************************************************************************************************//**
* @brief     Set PLX Spot-Check Measurement characteristic cli cnfg.
* @param[in] conn_hdl Connection handle.
* @param[in] cli_cnfg PLX Spot-Check Measurement characteristic cli cnfg to set.
* @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_PLXC_SetPlxSpotcheckMeasurementCliCnfg(uint16_t conn_hdl, uint16_t cli_cnfg);

/*******************************************************************************************************************//**
* @brief     Set PLX Continuous Measurement characteristic cli cnfg.
* @param[in] conn_hdl Connection handle.
* @param[in] cli_cnfg PLX Continuous Measurement characteristic cli cnfg to set.
* @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_PLXC_SetPlxContinuousMeasurementCliCnfg(uint16_t conn_hdl, uint16_t cli_cnfg);

/*******************************************************************************************************************//**
* @brief      Read PLX Features characteristic value from remote GATT database.
* @param[out] app_value Retrieved PLX Features characteristic value.
* @return     @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_PLXC_ReadPlxFeatures(uint16_t conn_hdl);

/*******************************************************************************************************************//**
* @brief     Write Record Access Control Point characteristic value to remote GATT database.
* @param[in] conn_hdl  Connection handle.
* @param[in] p_app_value Pointer to the Record Access Control Point characteristic value to write.
* @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_PLXC_WriteRecordAccessControlPoint(uint16_t conn_hdl, 
                     const st_ble_plxc_record_access_control_point_t *p_app_value);

/*******************************************************************************************************************//**
* @brief     Write Record Access Control Point characteristic value to remote GATT database.
* @param[in] conn_hdl  Connection handle.
* @param[in] p_app_value Pointer to the Record Access Control Point characteristic value to write.
* @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_PLXC_WriteRecordAccessControlPointRAT(uint16_t conn_hdl, 
                     const st_ble_plxc_record_access_control_point_t *p_app_value);

/*******************************************************************************************************************//**
* @brief     Set Record Access Control Point characteristic cli cnfg.
* @param[in] conn_hdl Connection handle.
* @param[in] cli_cnfg Record Access Control Point characteristic cli cnfg to set.
* @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_PLXC_SetRecordAccessControlPointCliCnfg(uint16_t conn_hdl, uint16_t cli_cnfg);

/***********************************************************************************************************************//**
* @brief      Callback function for the Pulse Oximeter Service Discovery events.
* @param[out] conn_hdl Connection handle.
* @param[out] idx      Service index used to distinguish the multiple same UUID service.
* @param[out] type     Discovery event type
* @param[out] p_param  Pointer to the GATTC event data.
***********************************************************************************************************************/
void R_BLE_PLXC_ServDiscCb(uint16_t conn_hdl, uint8_t idx, uint16_t type, void *p_param);

/*******************************************************************************************************************//**
* @brief     Return version of the PLXC service client.
* @return    version
***********************************************************************************************************************/
uint32_t R_BLE_PLXC_GetVersion(void);

#endif /* R_BLE_PLXC_H */

/** @} */
