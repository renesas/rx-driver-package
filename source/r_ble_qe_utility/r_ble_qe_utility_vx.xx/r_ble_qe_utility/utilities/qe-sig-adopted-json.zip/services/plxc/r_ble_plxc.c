/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************//**
* File Name: r_ble_plxc.c
* Version : 1.0
* Description : This module implements Pulse Oximeter Service Client.
**********************************************************************************************************************/
/************************************************************************************************************************//**
* History : DD.MM.YYYY Version Description
*         : 22.03.2019 1.00 First Release
***********************************************************************************************************************/

/***********************************************************************************************************************//**
* Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <string.h>
#include "r_ble_rx23w_if.h"
#include "r_ble_plxc.h"
#include "discovery/r_ble_disc.h"

/***********************************************************************************************************************//**
* Macro definitions
***********************************************************************************************************************/
/* Version number */
#define BLE_PLXC_PRV_VERSION_MAJOR               (1)
#define BLE_PLXC_PRV_VERSION_MINOR               (0)
#define BLE_PLXC_PRV_STRUCTURE_ELEMENT_LENGTH    (8)
#define BLE_PLXC_PRV_RACP_LENGTH                 (4)

/***********************************************************************************************************************//**
* @brief PLX Spot-Check Measurement characteristic value length.
***********************************************************************************************************************/
#define BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_LEN                                                                (19)
/***********************************************************************************************************************//**
* @brief PLX Continuous Measurement characteristic value length.      
***********************************************************************************************************************/    
#define BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_LEN                                                                (20)
/***********************************************************************************************************************//**    
* @brief PLX Features characteristic value length.     
***********************************************************************************************************************/    
#define BLE_PLXC_PRV_PLX_FEATURES_LEN                                                                              (7)

/***********************************************************************************************************************//**
* PLX Spot Check Measurement - Measurement Status Flags Bits Definition.
***********************************************************************************************************************/
#define BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_FLAGS_TIMESTAMP_FIELD_IS_PRESENT                                   (1 << 0)
#define BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_FLAGS_MEASUREMENT_STATUS_FIELD_PRESENT                             (1 << 1)
#define BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_FLAGS_DEVICE_AND_SENSOR_STATUS_FIELD_PRESENT                       (1 << 2)
#define BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_FLAGS_PULSE_AMPLITUDE_INDEX_FIELD_IS_PRESENT                       (1 << 3)
#define BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_FLAGS_DEVICE_CLOCK_IS_NOT_SET                                      (1 << 4)

/***********************************************************************************************************************//**
* PLX Spot Check Measurement - Measurement Status Fields Bits Definition.
***********************************************************************************************************************/
#define BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_MEASUREMENT_STATUS_MEASUREMENT_ONGOING                             (1 << 5)
#define BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_MEASUREMENT_STATUS_EARLY_ESTIMATED_DATA                            (1 << 6)
#define BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_MEASUREMENT_STATUS_VALIDATED_DATA                                  (1 << 7)
#define BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_MEASUREMENT_STATUS_FULLY_QUALIFIED_DATA                            (1 << 8)
#define BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_MEASUREMENT_STATUS_DATA_FROM_MEASUREMENT_STORAGE                   (1 << 9)
#define BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_MEASUREMENT_STATUS_DATA_FOR_DEMONSTRATION                          (1 << 10)
#define BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_MEASUREMENT_STATUS_DATA_FOR_TESTING                                (1 << 11)
#define BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_MEASUREMENT_STATUS_CALIBRATION_ONGOING                             (1 << 12)
#define BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_MEASUREMENT_STATUS_MEASUREMENT_UNAVAILABLE                         (1 << 13)
#define BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_MEASUREMENT_STATUS_QUESTIONABLE_MEASUREMENT_DETECTED               (1 << 14)
#define BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_MEASUREMENT_STATUS_INVALID_MEASUREMENT_DETECTED                    (1 << 15)

/***********************************************************************************************************************//**
* PLX Spot Check Measurement - Device and Sensor Status Fields Bits Definition.
***********************************************************************************************************************/
#define BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_EXTENDED_DISPLAY_UPDATE_ONGOING           (1 << 0)
#define BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_EQUIPMENT_MALFUNCTION_DETECTED            (1 << 1)
#define BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SIGNAL_PROCESSING_IRREGULARITY_DETECTED   (1 << 2)
#define BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_INADEQUITE_SIGNAL_DETECTED                (1 << 3)
#define BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_POOR_SIGNAL_DETECTED                      (1 << 4)
#define BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_LOW_PERFUSION_DETECTED                    (1 << 5)
#define BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_ERRATIC_SIGNAL_DETECTED                   (1 << 6)
#define BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_NONPULSATILE_SIGNAL_DETECTED              (1 << 7)
#define BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_QUESTIONABLE_PULSE_DETECTED               (1 << 8)
#define BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SIGNAL_ANALYSIS_ONGOING                   (1 << 9)
#define BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SENSOR_INTERFACE_DETECTED                 (1 << 10)
#define BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SENSOR_UNCONNECTED_TO_USER                (1 << 11)
#define BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_UNKNOWN_SENSOR_CONNECTED                  (1 << 12)
#define BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SENSOR_DISPLACED                          (1 << 13)
#define BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SENSOR_MALFUNCTIONING                     (1 << 14)
#define BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SENSOR_DISCONNECTED                       (1 << 15)

/***********************************************************************************************************************//**
* PLX Continuous Measurement Flags Bits Definition.
***********************************************************************************************************************/
#define BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_FLAGS_SPO2PR_FAST_FIELD_IS_PRESENT                                 (1 << 0)
#define BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_FLAGS_SPO2PR_SLOW_FIELD_IS_PRESENT                                 (1 << 1)
#define BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_FLAGS_MEASUREMENT_STATUS_FIELD_IS_PRESENT                          (1 << 2)
#define BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_FLAGS_DEVICE_AND_SENSOR_STATUS_FIELD_IS_PRESENT                    (1 << 3)
#define BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_FLAGS_PULSE_AMPLITUDE_INDEX_FIELD_IS_PRESENT                       (1 << 4)

/***********************************************************************************************************************//**
* PLX Continuous Measurement - Measurement Status Fields Bits Definition.
***********************************************************************************************************************/
#define BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_MEASUREMENT_STATUS_MEASUREMENT_ONGOING                             (1 << 5)
#define BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_MEASUREMENT_STATUS_EARLY_ESTIMATED_DATA                            (1 << 6)
#define BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_MEASUREMENT_STATUS_VALIDATED_DATA                                  (1 << 7)
#define BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_MEASUREMENT_STATUS_FULLY_QUALIFIED_DATA                            (1 << 8)
#define BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_MEASUREMENT_STATUS_DATA_FROM_MEASUREMENT_STORAGE                   (1 << 9)
#define BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_MEASUREMENT_STATUS_DATA_FOR_DEMONSTRATION                          (1 << 10)
#define BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_MEASUREMENT_STATUS_DATA_FOR_TESTING                                (1 << 11)
#define BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_MEASUREMENT_STATUS_CALIBRATION_ONGOING                             (1 << 12)
#define BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_MEASUREMENT_STATUS_MEASUREMENT_UNAVAILABLE                         (1 << 13)
#define BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_MEASUREMENT_STATUS_QUESTIONABLE_MEASUREMENT_DETECTED               (1 << 14)
#define BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_MEASUREMENT_STATUS_INVALID_MEASUREMENT_DETECTED                    (1 << 15)

/***********************************************************************************************************************//**
* PLX Continuous Measurement - Device and Sensor Status Fields Bits Definition.
***********************************************************************************************************************/
#define BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_EXTENDED_DISPLAY_UPDATE_ONGOING_BIT_SUPPORTED         (1 << 0)
#define BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_EQUIPMENT_MALFUNCTION_DETECTED_BIT_SUPPORTED          (1 << 1)
#define BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SIGNAL_PROCESSING_IRREGULARITY_DETECTED_BIT_SUPPORTED (1 << 2)
#define BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_INADEQUITE_SIGNAL_DETECTED_BIT_SUPPORTED              (1 << 3)
#define BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_POOR_SIGNAL_DETECTED_BIT_SUPPORTED                    (1 << 4)
#define BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_LOW_PERFUSION_DETECTED_BIT_SUPPORTED                  (1 << 5)
#define BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_ERRATIC_SIGNAL_DETECTED_BIT_SUPPORTED                 (1 << 6)
#define BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_NONPULSATILE_SIGNAL_DETECTED_BIT_SUPPORTED            (1 << 7)
#define BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_QUESTIONABLE_PULSE_DETECTED_BIT_SUPPORTED             (1 << 8)
#define BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SIGNAL_ANALYSIS_ONGOING_BIT_SUPPORTED                 (1 << 9)
#define BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SENSOR_INTERFERENCE_DETECTED_BIT_SUPPORTED            (1 << 10)
#define BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SENSOR_UNCONNECTED_TO_USER_BIT_SUPPORTED              (1 << 11)
#define BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_UNKNOWN_SENSOR_CONNECTED_BIT_SUPPORTED                (1 << 12)
#define BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SENSOR_DISPLACED_BIT_SUPPORTED                        (1 << 13)
#define BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SENSOR_MALFUNCTIONING_BIT_SUPPORTED                   (1 << 14)
#define BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SENSOR_DISCONNECTED_BIT_SUPPORTED                     (1 << 15)

/***********************************************************************************************************************//**
* PLX Features Supported Features Bits Definition.
***********************************************************************************************************************/
#define BLE_PLXC_PRV_PLX_FEATURES_SUPPORTED_FEATURES_MEASUREMENT_STATUS_SUPPORT_IS_PRESENT                          (1 << 0)
#define BLE_PLXC_PRV_PLX_FEATURES_SUPPORTED_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_IS_PRESENT                    (1 << 1)
#define BLE_PLXC_PRV_PLX_FEATURES_SUPPORTED_FEATURES_MEASUREMENT_STORAGE_FOR_SPOT_CHECK_MEASUREMENTS_IS_SUPPORTED   (1 << 2)
#define BLE_PLXC_PRV_PLX_FEATURES_SUPPORTED_FEATURES_TIMESTAMP_FOR_SPOT_CHECK_MEASUREMENTS_IS_SUPPORTED             (1 << 3)
#define BLE_PLXC_PRV_PLX_FEATURES_SUPPORTED_FEATURES_SPO2PR_FAST_METRIC_IS_SUPPORTED                                (1 << 4)
#define BLE_PLXC_PRV_PLX_FEATURES_SUPPORTED_FEATURES_SPO2PR_SLOW_METRIC_IS_SUPPORTED                                (1 << 5)
#define BLE_PLXC_PRV_PLX_FEATURES_SUPPORTED_FEATURES_PULSE_AMPLITUDE_INDEX_FIELD_IS_SUPPORTED                       (1 << 6)
#define BLE_PLXC_PRV_PLX_FEATURES_SUPPORTED_FEATURES_MULTIPLE_BONDS_SUPPORTED                                       (1 << 7)

/***********************************************************************************************************************//**
* PLX Features Measurement Status Supported Bits Definition.
***********************************************************************************************************************/
#define BLE_PLXC_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_MEASUREMENT_ONGOING_BIT_SUPPORTED                (1 << 5)
#define BLE_PLXC_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_EARLY_ESTIMATED_DATA_BIT_SUPPORTED               (1 << 6)
#define BLE_PLXC_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_VALIDATED_DATA_BIT_SUPPORTED                     (1 << 7)
#define BLE_PLXC_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_FULLY_QUALIFIED_DATA_BIT_SUPPORTED               (1 << 8)
#define BLE_PLXC_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_DATA_FROM_MEASUREMENT_STORAGE_BIT_SUPPORTED      (1 << 9)
#define BLE_PLXC_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_DATA_FOR_DEMONSTRATION_BIT_SUPPORTED             (1 << 10)
#define BLE_PLXC_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_DATA_FOR_TESTING_BIT_SUPPORTED                   (1 << 11)
#define BLE_PLXC_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_CALIBRATION_ONGOING_BIT_SUPPORTED                (1 << 12)
#define BLE_PLXC_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_MEASUREMENT_UNAVAILABLE_BIT_SUPPORTED            (1 << 13)
#define BLE_PLXC_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_QUESTIONABLE_MEASUREMENT_DETECTED_BIT_SUPPORTED  (1 << 14)
#define BLE_PLXC_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_INVALID_MEASUREMENT_DETECTED_BIT_SUPPORTED       (1 << 15)

/***********************************************************************************************************************//**
* PLX Features Device and Sensor Status Supported Bits Definition.
***********************************************************************************************************************/
#define BLE_PLXC_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_EXTENDED_DISPLAY_UPDATE_ONGOING_BIT_SUPPORTED          (1 << 0)
#define BLE_PLXC_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_EQUIPMENT_MALFUNCTION_DETECTED_BIT_SUPPORTED           (1 << 1)
#define BLE_PLXC_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_SIGNAL_PROCESSING_IRREGULARITY_DETECTED_BIT_SUPPORTED  (1 << 2)
#define BLE_PLXC_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_INADEQUITE_SIGNAL_DETECTED_BIT_SUPPORTED               (1 << 3)
#define BLE_PLXC_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_POOR_SIGNAL_DETECTED_BIT_SUPPORTED                     (1 << 4)
#define BLE_PLXC_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_LOW_PERFUSION_DETECTED_BIT_SUPPORTED                   (1 << 5)
#define BLE_PLXC_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_ERRATIC_SIGNAL_DETECTED_BIT_SUPPORTED                  (1 << 6)
#define BLE_PLXC_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_NONPULSATILE_SIGNAL_DETECTED_BIT_SUPPORTED             (1 << 7)
#define BLE_PLXC_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_QUESTIONABLE_PULSE_DETECTED_BIT_SUPPORTED              (1 << 8)
#define BLE_PLXC_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_SIGNAL_ANALYSIS_ONGOING_BIT_SUPPORTED                  (1 << 9)
#define BLE_PLXC_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_SENSOR_INTERFACE_DETECTED_BIT_SUPPORTED                (1 << 10)
#define BLE_PLXC_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_SENSOR_UNCONNECTED_TO_USER_BIT_SUPPORTED               (1 << 11)
#define BLE_PLXC_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_UNKNOWN_SENSOR_CONNECTED_BIT_SUPPORTED                 (1 << 12)
#define BLE_PLXC_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_SENSOR_DISPLACED_BIT_SUPPORTED                         (1 << 13)
#define BLE_PLXC_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_SENSOR_MALFUNCTIONING_BIT_SUPPORTED                    (1 << 14)
#define BLE_PLXC_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_SENSOR_DISCONNECTED_BIT_SUPPORTED                      (1 << 15)

/***********************************************************************************************************************//**
* Typedef definitions
***********************************************************************************************************************/
typedef struct
{
    uint16_t              conn_hdl;
    st_ble_plxc_hdls_t    hdls;
} st_plxc_peer_param_t;

/***********************************************************************************************************************//**
* Exported global variables (to be accessed by other files)
***********************************************************************************************************************/
const uint8_t BLE_PLXC_UUID[BLE_GATT_16_BIT_UUID_SIZE]                                                                  = { 0x22, 0x18 };
const uint8_t BLE_PLXC_PLX_SPOT_CHECK_MEASUREMENT_UUID[BLE_GATT_16_BIT_UUID_SIZE]                                       = { 0x5E, 0x2A };
const uint8_t BLE_PLXC_PLX_SPOT_CHECK_MEASUREMENT_CLIENT_CHARACTERISTIC_CONFIGURATION_UUID[BLE_GATT_16_BIT_UUID_SIZE]   = { 0x02, 0x29 };
const uint8_t BLE_PLXC_PLX_CONTINUOUS_MEASUREMENT_UUID[BLE_GATT_16_BIT_UUID_SIZE]                                       = { 0x5F, 0x2A };
const uint8_t BLE_PLXC_PLX_CONTINUOUS_MEASUREMENT_CLIENT_CHARACTERISTIC_CONFIGURATION_UUID[BLE_GATT_16_BIT_UUID_SIZE]   = { 0x02, 0x29 };
const uint8_t BLE_PLXC_PLX_FEATURES_UUID[BLE_GATT_16_BIT_UUID_SIZE]                                                     = { 0x60, 0x2A };
const uint8_t BLE_PLXC_RECORD_ACCESS_CONTROL_POINT_UUID[BLE_GATT_16_BIT_UUID_SIZE]                                      = { 0x52, 0x2A };
const uint8_t BLE_PLXC_RECORD_ACCESS_CONTROL_POINT_CLIENT_CHARACTERISTIC_CONFIGURATION_UUID[BLE_GATT_16_BIT_UUID_SIZE]  = { 0x02, 0x29 };

/***********************************************************************************************************************//**
* Private global variables and functions
***********************************************************************************************************************/
static st_plxc_peer_param_t   gs_peer_params[8];
static ble_plxc_app_cb_t      gs_plxc_cb;

/***********************************************************************************************************************//**
* Function Name: find_peer_param
* Description  : This function finds the attribute handles for the given connection handle.
* Arguments    : conn_hdl - handle to connection
* Return Value : pointer to the attribute handles structure
**********************************************************************************************************************/
static st_plxc_peer_param_t *find_peer_param(uint16_t conn_hdl)
{
    for (uint8_t i = 0; i < BLE_PLXC_PRV_STRUCTURE_ELEMENT_LENGTH; i++)
    {
        if ((BLE_GAP_INVALID_CONN_HDL != gs_peer_params[i].conn_hdl) &&
            (gs_peer_params[i].conn_hdl == conn_hdl))
        {
            return &gs_peer_params[i];
        }
    }
    return NULL;
}

/***********************************************************************************************************************//**
* Function Name: st_plxc_peer_param_t
* Description  : This function finds the free attribute handle.
* Arguments    : conn_hdl - handle to connection.
* Return Value : pointer to the free attribute handles structure
**********************************************************************************************************************/
static st_plxc_peer_param_t *get_new_peer_param(uint16_t conn_hdl)
{
    for (uint8_t i = 0; i < BLE_PLXC_PRV_STRUCTURE_ELEMENT_LENGTH; i++)
    {
        if (BLE_GAP_INVALID_CONN_HDL == gs_peer_params[i].conn_hdl)
        {
            gs_peer_params[i].conn_hdl = conn_hdl;
            return &gs_peer_params[i];
        }        
    }
    return NULL;
}

/***********************************************************************************************************************//**
* Function Name: clear_peer_param
* Description  : This function frees all the attribute handles.
* Arguments    : p_peer - pointer to the attribute handle structure to be freed
* Return Value : none
***********************************************************************************************************************/
static void clear_peer_param(st_plxc_peer_param_t *p_peer)
{
    if (NULL != p_peer)
    {
        p_peer->conn_hdl = BLE_GAP_INVALID_CONN_HDL;
        memset(&p_peer->hdls, 0x00, sizeof(p_peer->hdls));
    }    
}

/***********************************************************************************************************************//**
* Function Name: decode_plx_spot_check_measurement
* Description  : This function converts PLX Spot-Check Measurement characteristic value representation in
*                GATT (uint8_t[]) to representation in application layer (struct).
* Arguments    : p_app_value - pointer to the PLX Spot-Check Measurement value in the application layer
*                p_gatt_value - pointer to the characteristic value in the GATT database
* Return Value : ble_status_t
**********************************************************************************************************************/
static ble_status_t decode_plx_spot_check_measurement(st_ble_plxc_plx_spot_check_measurement_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{   
    uint8_t pos = 1;

    if (BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }
    
    memset((uint8_t*)p_app_value, 0x00, sizeof(*p_app_value));

    /* Convert byte sequence to application data. */
    uint8_t feature_byte0 = 0;
    BT_UNPACK_LE_1_BYTE(&feature_byte0, &p_gatt_value->p_value[0]);
   
    /*Copy the Spot_Check_Measurement_SP02_Value*/
    BT_UNPACK_LE_2_BYTE(&p_app_value->spo2pr_spot_check___spo2.mantissa, &p_gatt_value->p_value[pos]);
    p_app_value->spo2pr_spot_check___spo2.exponent = (int8_t)(((int16_t)p_app_value->spo2pr_spot_check___spo2.mantissa) >> 12);
    p_app_value->spo2pr_spot_check___spo2.mantissa = (int16_t)(p_app_value->spo2pr_spot_check___spo2.mantissa & 0x0FFF);
   
    pos += 2;
    
    /*Copy the Spot_Check_Measurement_PR_Value*/
    BT_UNPACK_LE_2_BYTE(&p_app_value->spo2pr_spot_check___pr.mantissa, &p_gatt_value->p_value[pos]);
    p_app_value->spo2pr_spot_check___pr.exponent = (int8_t)(((int16_t)p_app_value->spo2pr_spot_check___pr.mantissa) >> 12);
    p_app_value->spo2pr_spot_check___pr.mantissa = (int16_t)(p_app_value->spo2pr_spot_check___pr.mantissa & 0x0FFF);
 
    pos += 2;

    /*Copy the Spot_Check_Measurement_TIME_STAMP_Value*/
    if (feature_byte0 & BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_FLAGS_TIMESTAMP_FIELD_IS_PRESENT)
    {
        BT_UNPACK_LE_2_BYTE(&p_app_value->timestamp.year, &p_gatt_value->p_value[pos]);
        pos += (sizeof(p_app_value->timestamp.year));

        p_app_value->timestamp.month   = p_gatt_value->p_value[pos++];
        p_app_value->timestamp.day     = p_gatt_value->p_value[pos++];
        p_app_value->timestamp.hours   = p_gatt_value->p_value[pos++];
        p_app_value->timestamp.minutes = p_gatt_value->p_value[pos++];
        p_app_value->timestamp.seconds = p_gatt_value->p_value[pos++];
    }
    
    uint16_t feature_byte1 = 0;
    BT_UNPACK_LE_2_BYTE(&feature_byte1, &p_gatt_value->p_value[pos]);

    /*Copy the PLX_Spot_Check_Measurement_STATUS_FIELD_Value*/
    if (feature_byte0 & BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_FLAGS_MEASUREMENT_STATUS_FIELD_PRESENT)
    {
        /* PLXS Spot Check MEASUREMENT STATUS SUPPORTED BITS */
        /*Measurement Ongoing supported bit */
        if (feature_byte1 & BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_MEASUREMENT_STATUS_MEASUREMENT_ONGOING)
        {
            p_app_value->is_measurement_ongoing = true;
        }
        else
        {
            p_app_value->is_measurement_ongoing = false;
        }

        /* Early Estimated Data supported bit */
        if (feature_byte1 & BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_MEASUREMENT_STATUS_EARLY_ESTIMATED_DATA)
        {
            p_app_value->is_early_estimated_data = true;
        }
        else
        {
            p_app_value->is_early_estimated_data = false;
        }

        /* Validated Data supported bit */
        if (feature_byte1 & BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_MEASUREMENT_STATUS_VALIDATED_DATA)
        {
            p_app_value->is_validated_data = true;
        }
        else
        {
            p_app_value->is_validated_data = false;
        }

        /* Fully Qualified Data  supported bit */
        if (feature_byte1 & BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_MEASUREMENT_STATUS_FULLY_QUALIFIED_DATA)
        {
            p_app_value->is_fully_qualified_data = true;
        }
        else
        {
            p_app_value->is_fully_qualified_data = false;
        }

        /* Data from Measurement Storage supported bit */
        if (feature_byte1 & BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_MEASUREMENT_STATUS_DATA_FROM_MEASUREMENT_STORAGE)
        {
            p_app_value->is_data_from_measurement_storage = true;
        }
        else
        {
            p_app_value->is_data_from_measurement_storage = false;
        }

        /*  Data for Demonstration supported bit */
        if (feature_byte1 & BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_MEASUREMENT_STATUS_DATA_FOR_DEMONSTRATION)
        {
            p_app_value->is_data_for_demonstration = true;
        }
        else
        {
            p_app_value->is_data_for_demonstration = false;
        }

        /*   Data for Testing supported bit */
        if (feature_byte1 & BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_MEASUREMENT_STATUS_DATA_FOR_TESTING)
        {
            p_app_value->is_data_for_testing = true;
        }
        else
        {
            p_app_value->is_data_for_testing = false;
        }

        /*   Calibration Ongoing supported bit */
        if (feature_byte1 & BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_MEASUREMENT_STATUS_CALIBRATION_ONGOING)
        {
            p_app_value->is_calibration_ongoing = true;
        }
        else
        {
            p_app_value->is_calibration_ongoing = false;
        }
       
        /*   Measurement Unavailable supported bit */
        if (feature_byte1 & BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_MEASUREMENT_STATUS_MEASUREMENT_UNAVAILABLE)
        {
            p_app_value->is_measurement_unavailable = true;
        }
        else
        {
            p_app_value->is_measurement_unavailable = false;
        }

        /*    Questionable Measurement Detected supported bit */
        if (feature_byte1 & BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_MEASUREMENT_STATUS_QUESTIONABLE_MEASUREMENT_DETECTED)
        {
            p_app_value->is_questionable_measurement_detected = true;
        }
        else
        {
            p_app_value->is_questionable_measurement_detected = false;
        }

        /* Invalid Measurement Detected supported bit */
        if (feature_byte1 & BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_MEASUREMENT_STATUS_INVALID_MEASUREMENT_DETECTED)
        {
            p_app_value->is_invalid_measurement_detected = true;
        }
        else
        {
            p_app_value->is_invalid_measurement_detected = false;
        }
    }

    pos += 2;

    uint32_t feature_byte2 = 0;
    BT_UNPACK_LE_3_BYTE(&feature_byte2, &p_gatt_value->p_value[pos]);
   
    /*Copy the Spot_Check_Measurement_DEVICE_SENSOR_STATUS_Value*/
    if (feature_byte0 & BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_FLAGS_DEVICE_AND_SENSOR_STATUS_FIELD_PRESENT)
    {
        /*PLXS Spot Check Measurement Device and Sensor status bit fields*/
        /* Extended Display Update Ongoing supported bit */
        if (feature_byte2 & BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_EXTENDED_DISPLAY_UPDATE_ONGOING)
        {
            p_app_value->is_extended_display_update_ongoing = true;
        }
        else
        {
            p_app_value->is_extended_display_update_ongoing = false;
        }

        /* Equipment Malfunction Detected supported bit */
        if (feature_byte2 & BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_EQUIPMENT_MALFUNCTION_DETECTED)
        {
            p_app_value->is_equipment_malfunction_detected = true;
        }
        else
        {
            p_app_value->is_equipment_malfunction_detected = false;
        }

        /* Signal Processing Irregularity Detected supported bit */
        if (feature_byte2 & BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SIGNAL_PROCESSING_IRREGULARITY_DETECTED)
        {
            p_app_value->is_signal_processing_irregularity_detected = true;
        }
        else
        {
            p_app_value->is_signal_processing_irregularity_detected = false;
        }

        /* Inadequate Signal Detected supported bit */
        if (feature_byte2 & BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_INADEQUITE_SIGNAL_DETECTED)
        {
            p_app_value->is_inadequate_signal_detected = true;
        }
        else
        {
            p_app_value->is_inadequate_signal_detected = false;
        }

        /* Poor Signal Detected supported bit */
        if (feature_byte2 & BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_POOR_SIGNAL_DETECTED)
        {
            p_app_value->is_poor_signal_detected = true;
        }
        else
        {
            p_app_value->is_poor_signal_detected = false;
        }
        
        /*  Low Perfusion Detected supported bit */
        if (feature_byte2 & BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_LOW_PERFUSION_DETECTED)
        {
            p_app_value->is_low_perfusion_detected = true;
        }
        else
        {
            p_app_value->is_low_perfusion_detected = false;
        }

        /*  Erratic Signal Detected supported bit */
        if (feature_byte2 & BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_ERRATIC_SIGNAL_DETECTED)
        {
            p_app_value->is_erratic_perfusion_detected = true;
        }
        else
        {
            p_app_value->is_erratic_perfusion_detected = false;
        }

        /*  Non-Pulsatile Signal Detected supported bit */
        if (feature_byte2 & BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_NONPULSATILE_SIGNAL_DETECTED)
        {
            p_app_value->is_non_pulsatile_signal_detected = true;
        }
        else
        {
            p_app_value->is_non_pulsatile_signal_detected = false;
        }
       
        /* Questionable Pulse Detected supported bit */
        if (feature_byte2 & BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_QUESTIONABLE_PULSE_DETECTED)
        {
            p_app_value->is_questionable_pulse_detected = true;
        }
        else
        {
            p_app_value->is_questionable_pulse_detected = false;
        }

        /* Signal Analysis Ongoing supported bit */
        if (feature_byte2 & BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SIGNAL_ANALYSIS_ONGOING)
        {
            p_app_value->is_siganl_analysis_ongoing = true;
        }
        else
        {
            p_app_value->is_siganl_analysis_ongoing = false;
        }

        /* Sensor Interference Detected supported bit */
        if (feature_byte2 & BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SENSOR_INTERFACE_DETECTED)
        {
            p_app_value->is_sensor_interference_detected = true;
        }
        else
        {
            p_app_value->is_sensor_interference_detected = false;
        }

        /* Sensor Unconnected to User supported bit */
        if (feature_byte2 & BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SENSOR_UNCONNECTED_TO_USER)
        {
            p_app_value->is_sensor_unconnected_to_user = true;
        }
        else
        {
            p_app_value->is_sensor_unconnected_to_user = false;
        }

        /* Unknown Sensor Connected supported bit */
        if (feature_byte2 & BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_UNKNOWN_SENSOR_CONNECTED)
        {
            p_app_value->is_unknown_sensor_connected = true;
        }
        else
        {
            p_app_value->is_unknown_sensor_connected = false;
        }
        
        /* Sensor Displaced  supported bit */
        if (feature_byte2 & BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SENSOR_DISPLACED)
        {
            p_app_value->is_sensor_displaced = true;
        }
        else
        {
            p_app_value->is_sensor_displaced = false;
        }

        /* Sensor Malfunctioning supported bit */
        if (feature_byte2 & BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SENSOR_MALFUNCTIONING)
        {
            p_app_value->is_sensor_malfunctioning = true;
        }
        else
        {
            p_app_value->is_sensor_malfunctioning = false;
        }

        /* Sensor Disconnected supported bit */
        if (feature_byte2 & BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SENSOR_DISCONNECTED)
        {
            p_app_value->is_sensor_disconnected = true;
        }
        else
        {
            p_app_value->is_sensor_disconnected = false;
        }
    }
   
    pos += 3;

    /*Copy the Spot_Check_Measurement_Pulse_Amplitude_Index_Value*/
    if (feature_byte0 & BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_FLAGS_PULSE_AMPLITUDE_INDEX_FIELD_IS_PRESENT)
    {
        BT_UNPACK_LE_2_BYTE(&p_app_value->pulse_amplitude_index.mantissa, &p_gatt_value->p_value[pos]);
        p_app_value->pulse_amplitude_index.exponent = (int8_t)(((int16_t)p_app_value->pulse_amplitude_index.mantissa) >> 12);
        p_app_value->pulse_amplitude_index.mantissa = (int16_t)(p_app_value->pulse_amplitude_index.mantissa & 0x0FFF);
        
        pos += 2;
    }
    
    /*Copy the Spot_Check_Measurement Device Clock present bit*/
    if (feature_byte0 & BLE_PLXC_PRV_PLX_SPOT_CHECK_MEASUREMENT_FLAGS_DEVICE_CLOCK_IS_NOT_SET)
    {
        p_app_value->is_device_clock_present = true;
    }
    else
    {
        p_app_value->is_device_clock_present = false;
    }
    
    return BLE_SUCCESS;
}

/***********************************************************************************************************************//**
* Function Name: decode_plx_continuous_measurement
* Description  : This function converts PLX Continuous Measurement characteristic value representation in
*                GATT (uint8_t[]) to representation in application layer (struct).
* Arguments    : p_app_value - pointer to the PLX Continuous Measurement value in the application layer
*                p_gatt_value - pointer to the characteristic value in the GATT database
* Return Value : ble_status_t
**********************************************************************************************************************/
static ble_status_t decode_plx_continuous_measurement(st_ble_plxc_plx_continuous_measurement_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 1;

    if (BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }
    
    memset((uint8_t*)p_app_value, 0x00, sizeof(*p_app_value));

    /* Convert byte sequence to application data. */
    
    uint8_t feature_byte0 = 0;
    BT_UNPACK_LE_1_BYTE(&feature_byte0, &p_gatt_value->p_value[0]);
                
    /*Copy the PLX_Continuous_Measurement_SP02pr_Normal_Value*/
    BT_UNPACK_LE_2_BYTE(&p_app_value->spo2pr_normal___spo2.mantissa, &p_gatt_value->p_value[pos]);
    p_app_value->spo2pr_normal___spo2.exponent = (int8_t)(((int16_t)p_app_value->spo2pr_normal___spo2.mantissa) >> 12);
    p_app_value->spo2pr_normal___spo2.mantissa = (int16_t)(p_app_value->spo2pr_normal___spo2.mantissa & 0x0FFF);
    
    pos += 2;
  
    /*Copy the PLX_Continuous_Measurement_SP02pr_Normal_pr_Value*/
    BT_UNPACK_LE_2_BYTE(&p_app_value->spo2pr_normal___pr.mantissa, &p_gatt_value->p_value[pos]);
    p_app_value->spo2pr_normal___pr.exponent = (int8_t)(((int16_t)p_app_value->spo2pr_normal___pr.mantissa) >> 12);
    p_app_value->spo2pr_normal___pr.mantissa = (int16_t)(p_app_value->spo2pr_normal___pr.mantissa & 0x0FFF);
    
    pos += 2;
   
    /*Copy the PLX_Continuous_Measurement_SP02pr_FAST_Value & PLX_Continuous_Measurement_SP02pr_FAST_pr_Value */
    if (feature_byte0 & BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_FLAGS_SPO2PR_FAST_FIELD_IS_PRESENT)
    {
        BT_UNPACK_LE_2_BYTE(&p_app_value->spo2pr_fast___spo2.mantissa, &p_gatt_value->p_value[pos]);
        p_app_value->spo2pr_fast___spo2.exponent = (int8_t)(((int16_t)p_app_value->spo2pr_fast___spo2.mantissa) >> 12);
        p_app_value->spo2pr_fast___spo2.mantissa = (int16_t)(p_app_value->spo2pr_fast___spo2.mantissa & 0x0FFF);
        
        pos += 2;

        BT_UNPACK_LE_2_BYTE(&p_app_value->spo2pr_fast___pr.mantissa, &p_gatt_value->p_value[pos]);
        p_app_value->spo2pr_fast___pr.exponent = (int8_t)(((int16_t)p_app_value->spo2pr_fast___pr.mantissa) >> 12);
        p_app_value->spo2pr_fast___pr.mantissa = (int16_t)(p_app_value->spo2pr_fast___pr.mantissa & 0x0FFF);
       
        pos += 2;
                
    }
    
    /*Copy the PLX_Continuous_Measurement_SP02pr_Slow_Value & Spot_Check_Measurement_SP02pr_Slow_pr_Value */
    if (feature_byte0 & BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_FLAGS_SPO2PR_SLOW_FIELD_IS_PRESENT)
    {
        BT_UNPACK_LE_2_BYTE(&p_app_value->spo2pr_slow___spo2.mantissa, &p_gatt_value->p_value[pos]);
        p_app_value->spo2pr_slow___spo2.exponent = (int8_t)(((int16_t)p_app_value->spo2pr_slow___spo2.mantissa) >> 12);
        p_app_value->spo2pr_slow___spo2.mantissa = (int16_t)(p_app_value->spo2pr_slow___spo2.mantissa & 0x0FFF);
        
        pos += 2;

        BT_UNPACK_LE_2_BYTE(&p_app_value->spo2pr_slow___pr.mantissa, &p_gatt_value->p_value[pos]);
        p_app_value->spo2pr_slow___pr.exponent = (int8_t)(((int16_t)p_app_value->spo2pr_slow___pr.mantissa) >> 12);
        p_app_value->spo2pr_slow___pr.mantissa = (int16_t)(p_app_value->spo2pr_slow___pr.mantissa & 0x0FFF);
        
        pos += 2;

    }
    
    uint16_t feature_byte1 = 0;

    BT_UNPACK_LE_2_BYTE(&feature_byte1, &p_gatt_value->p_value[pos]);

    /*Copy the PLX Continuous Measurement_STATUS_FIELD_Value*/
    if (feature_byte0 & BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_FLAGS_MEASUREMENT_STATUS_FIELD_IS_PRESENT)
    {
        /* PLXS Spot Check MEASUREMENT STATUS SUPPORTED BITS */
        /*  Measurement Ongoing supported bit */
        if (feature_byte1 & BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_MEASUREMENT_STATUS_MEASUREMENT_ONGOING)
        {
            p_app_value->is_measurement_ongoing = true;
        }
        else
        {
            p_app_value->is_measurement_ongoing = false;
        }

        /* Early Estimated Data supported bit */
        if (feature_byte1 & BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_MEASUREMENT_STATUS_EARLY_ESTIMATED_DATA)
        {
            p_app_value->is_early_estimated_data = true;
        }
        else
        {
            p_app_value->is_early_estimated_data = false;
        }

        /* Validated Data supported bit */
        if (feature_byte1 & BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_MEASUREMENT_STATUS_VALIDATED_DATA)
        {
            p_app_value->is_validated_data = true;
        }
        else
        {
            p_app_value->is_validated_data = false;
        }

        /* Fully Qualified Data  supported bit */
        if (feature_byte1 & BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_MEASUREMENT_STATUS_FULLY_QUALIFIED_DATA)
        {
            p_app_value->is_fully_qualified_data = true;
        }
        else
        {
            p_app_value->is_fully_qualified_data = false;
        }

        /* Data from Measurement Storage supported bit */
        if (feature_byte1 & BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_MEASUREMENT_STATUS_DATA_FROM_MEASUREMENT_STORAGE)
        {
            p_app_value->is_data_from_measurement_storage = true;
        }
        else
        {
            p_app_value->is_data_from_measurement_storage = false;
        }

        /*  Data for Demonstration supported bit */
        if (feature_byte1 & BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_MEASUREMENT_STATUS_DATA_FOR_DEMONSTRATION)
        {
            p_app_value->is_data_for_demonstration = true;
        }
        else
        {
            p_app_value->is_data_for_demonstration = false;
        }

        /*   Data for Testing supported bit */
        if (feature_byte1 & BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_MEASUREMENT_STATUS_DATA_FOR_TESTING)
        {
            p_app_value->is_data_for_testing = true;
        }
        else
        {
            p_app_value->is_data_for_testing = false;
        }

        /*   Calibration Ongoing supported bit */
        if (feature_byte1 & BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_MEASUREMENT_STATUS_CALIBRATION_ONGOING)
        {
            p_app_value->is_calibration_ongoing = true;
        }
        else
        {
            p_app_value->is_calibration_ongoing = false;
        }
        
        /*   Measurement Unavailable supported bit */
        if (feature_byte1 & BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_MEASUREMENT_STATUS_MEASUREMENT_UNAVAILABLE)
        {
            p_app_value->is_measurement_unavailable = true;
        }
        else
        {
            p_app_value->is_measurement_unavailable = false;
        }

        /*    Questionable Measurement Detected supported bit */
        if (feature_byte1 & BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_MEASUREMENT_STATUS_QUESTIONABLE_MEASUREMENT_DETECTED)
        {
            p_app_value->is_questionable_measurement_detected = true;
        }
        else
        {
            p_app_value->is_questionable_measurement_detected = false;
        }

        /* Invalid Measurement Detected supported bit */
        if (feature_byte1 & BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_MEASUREMENT_STATUS_INVALID_MEASUREMENT_DETECTED)
        {
            p_app_value->is_invalid_measurement_detected = true;
        }
        else
        {
            p_app_value->is_invalid_measurement_detected = false;
        }
    }

    pos += 2;

    uint32_t feature_byte2 = 0;

    BT_UNPACK_LE_3_BYTE(&feature_byte2, &p_gatt_value->p_value[pos]);

    /*Copy the PLX_Continuous_Measurement Flags Device and Sensor status value */
    if (feature_byte0 & BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_FLAGS_DEVICE_AND_SENSOR_STATUS_FIELD_IS_PRESENT)
    {
        /*PLXS Features Device and Sensor status bit fields*/
        /* Extended Display Update Ongoing supported bit */

        if ((feature_byte2) & BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_EXTENDED_DISPLAY_UPDATE_ONGOING_BIT_SUPPORTED)
        {
            p_app_value->is_extended_display_update_ongoing = true;
        }
        else
        {
            p_app_value->is_extended_display_update_ongoing = false;
        }

        /* Equipment Malfunction Detected supported bit */
        if (feature_byte2 & BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_EQUIPMENT_MALFUNCTION_DETECTED_BIT_SUPPORTED)
        {
            p_app_value->is_equipment_malfunction_detected = true;
        }
        else
        {
            p_app_value->is_equipment_malfunction_detected = false;
        }

        /* Signal Processing Irregularity Detected supported bit */
        if (feature_byte2 & BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SIGNAL_PROCESSING_IRREGULARITY_DETECTED_BIT_SUPPORTED)
        {
            p_app_value->is_signal_processing_irregularity_detected = true;
        }
        else
        {
            p_app_value->is_signal_processing_irregularity_detected = false;
        }

        /* Inadequate Signal Detected supported bit */
        if (feature_byte2 & BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_INADEQUITE_SIGNAL_DETECTED_BIT_SUPPORTED)
        {
            p_app_value->is_inadequate_signal_detected = true;
        }
        else
        {
            p_app_value->is_inadequate_signal_detected = false;
        }

        /* Poor Signal Detected supported bit */
        if (feature_byte2 & BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_POOR_SIGNAL_DETECTED_BIT_SUPPORTED)
        {
            p_app_value->is_poor_signal_detected = true;
        }
        else
        {
            p_app_value->is_poor_signal_detected = false;
        }
        
        /*  Low Perfusion Detected supported bit */
        if (feature_byte2 & BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_LOW_PERFUSION_DETECTED_BIT_SUPPORTED)
        {
            p_app_value->is_low_perfusion_detected = true;
        }
        else
        {
            p_app_value->is_low_perfusion_detected = false;
        }

        /*  Erratic Signal Detected supported bit */
        if (feature_byte2 & BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_ERRATIC_SIGNAL_DETECTED_BIT_SUPPORTED)
        {
            p_app_value->is_erratic_perfusion_detected = true;
        }
        else
        {
            p_app_value->is_erratic_perfusion_detected = false;
        }

        /*  Non-Pulsatile Signal Detected supported bit */
        if (feature_byte2 & BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_NONPULSATILE_SIGNAL_DETECTED_BIT_SUPPORTED)
        {
            p_app_value->is_non_pulsatile_signal_detected = true;
        }
        else
        {
            p_app_value->is_non_pulsatile_signal_detected = false;
        }

        /* Questionable Pulse Detected supported bit */
        if (feature_byte2 & BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_QUESTIONABLE_PULSE_DETECTED_BIT_SUPPORTED)
        {
            p_app_value->is_questionable_pulse_detected = true;
        }
        else
        {
            p_app_value->is_questionable_pulse_detected = false;
        }

        /* Signal Analysis Ongoing supported bit */
        if (feature_byte2 & BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SIGNAL_ANALYSIS_ONGOING_BIT_SUPPORTED)
        {
            p_app_value->is_siganl_analysis_ongoing = true;
        }
        else
        {
            p_app_value->is_siganl_analysis_ongoing = false;
        }

        /* Sensor Interference Detected supported bit */
        if (feature_byte2 & BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SENSOR_INTERFERENCE_DETECTED_BIT_SUPPORTED)
        {
            p_app_value->is_sensor_interference_detected = true;
        }
        else
        {
            p_app_value->is_sensor_interference_detected = false;
        }

        /* Sensor Unconnected to User supported bit */
        if (feature_byte2 & BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SENSOR_UNCONNECTED_TO_USER_BIT_SUPPORTED)
        {
            p_app_value->is_sensor_unconnected_to_user = true;
        }
        else
        {
            p_app_value->is_sensor_unconnected_to_user = false;
        }

        /* Unknown Sensor Connected supported bit */
        if (feature_byte2 & BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_UNKNOWN_SENSOR_CONNECTED_BIT_SUPPORTED)
        {
            p_app_value->is_unknown_sensor_connected = true;
        }
        else
        {
            p_app_value->is_unknown_sensor_connected = false;
        }
        
        /* Sensor Displaced  supported bit */
        if (feature_byte2 & BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SENSOR_DISPLACED_BIT_SUPPORTED)
        {
            p_app_value->is_sensor_displaced = true;
        }
        else
        {
            p_app_value->is_sensor_displaced = false;
        }

        /* Sensor Malfunctioning supported bit */
        if (feature_byte2 & BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SENSOR_MALFUNCTIONING_BIT_SUPPORTED)
        {
            p_app_value->is_sensor_malfunctioning = true;
        }
        else
        {
            p_app_value->is_sensor_malfunctioning = false;
        }

        /* Sensor Disconnected supported bit */
        if (feature_byte2 & BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_DEVICE_AND_SENSOR_STATUS_SENSOR_DISCONNECTED_BIT_SUPPORTED)
        {
            p_app_value->is_sensor_disconnected = true;
        }
        else
        {
            p_app_value->is_sensor_disconnected = false;
        }
        pos += 3;        
    }
    
    /*Copy the PLX_Continuous_Measurement Flags Pulse Amplitude Indexs value */
    if (feature_byte0 & BLE_PLXC_PRV_PLX_CONTINUOUS_MEASUREMENT_FLAGS_PULSE_AMPLITUDE_INDEX_FIELD_IS_PRESENT)
    {
        BT_UNPACK_LE_2_BYTE(&p_app_value->pulse_amplitude_index.mantissa, &p_gatt_value->p_value[pos]);
        p_app_value->pulse_amplitude_index.exponent = (int8_t)(((int16_t)p_app_value->pulse_amplitude_index.mantissa) >> 12);
        p_app_value->pulse_amplitude_index.mantissa = (int16_t)(p_app_value->pulse_amplitude_index.mantissa & 0x0FFF);
        
        pos += 2;
    }
    
    return BLE_SUCCESS;
}

/***********************************************************************************************************************//**
* Function Name: decode_plx_features
* Description  : This function converts PLX Features characteristic value representation in
*                GATT (uint8_t[]) to representation in application layer (struct).
* Arguments    : p_app_value - pointer to the PLX Features value in the application layer
*                p_gatt_value - pointer to the characteristic value in the GATT database
* Return Value : ble_status_t
**********************************************************************************************************************/
static ble_status_t decode_plx_features(st_ble_plxc_plx_features_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    uint16_t feature_byte0 = 0;
    BT_UNPACK_LE_2_BYTE(&feature_byte0, &p_gatt_value->p_value[0]);
    pos += 2;

    uint16_t feature_byte1 = 0;
    BT_UNPACK_LE_2_BYTE(&feature_byte1, &p_gatt_value->p_value[pos]);
    pos += 2;

    uint32_t feature_byte2 = 0;
    BT_UNPACK_LE_3_BYTE(&feature_byte2, &p_gatt_value->p_value[pos]);
    pos += 3;

    if (BLE_PLXC_PRV_PLX_FEATURES_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }
    
    memset((uint8_t*)p_app_value, 0x00, sizeof(*p_app_value));

    /* PLXS SUPPORTED FEATURES SUPPORTED BITS */
    /* Measurement Status Supported bit */
    if (feature_byte0 & BLE_PLXC_PRV_PLX_FEATURES_SUPPORTED_FEATURES_MEASUREMENT_STATUS_SUPPORT_IS_PRESENT)
    {
        p_app_value->is_measurement_status_support_present = true;
    }
    else
    {
        p_app_value->is_measurement_status_support_present = false;
    }

    /* Device Sensor Status Supported bit */
    if (feature_byte0 & BLE_PLXC_PRV_PLX_FEATURES_SUPPORTED_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_IS_PRESENT)
    {
        p_app_value->is_device_sensor_status_support_present = true;
    }
    else
    {
        p_app_value->is_device_sensor_status_support_present = false;
    }

    /* Measurement Storage for Spot Check Measurement Status Supported bit */
    if (feature_byte0 & BLE_PLXC_PRV_PLX_FEATURES_SUPPORTED_FEATURES_MEASUREMENT_STORAGE_FOR_SPOT_CHECK_MEASUREMENTS_IS_SUPPORTED)
    {
        p_app_value->is_measurement_storage_spot_check_measurement_supported = true;
    }
    else
    {
        p_app_value->is_measurement_storage_spot_check_measurement_supported = false;
    }

    /* Time Stamp for Spot Check Measurement Status Supported bit */
    if (feature_byte0 & BLE_PLXC_PRV_PLX_FEATURES_SUPPORTED_FEATURES_TIMESTAMP_FOR_SPOT_CHECK_MEASUREMENTS_IS_SUPPORTED)
    {
        p_app_value->is_timestamp_spot_check_measurement_supported = true;
    }
    else
    {
        p_app_value->is_timestamp_spot_check_measurement_supported = false;
    }

    /* SPO2PR_FAST_METRIC Status Supported bit */
    if (feature_byte0 & BLE_PLXC_PRV_PLX_FEATURES_SUPPORTED_FEATURES_SPO2PR_FAST_METRIC_IS_SUPPORTED)
    {
        p_app_value->is_spO2pr_fast_metric_supported = true;
    }
    else
    {
        p_app_value->is_spO2pr_fast_metric_supported = false;
    }

    /* SPO2PR_SLOW_METRIC Status Supported bit */
    if (feature_byte0 & BLE_PLXC_PRV_PLX_FEATURES_SUPPORTED_FEATURES_SPO2PR_SLOW_METRIC_IS_SUPPORTED)
    {
        p_app_value->is_spO2pr_slow_metric_supported = true;
    }
    else
    {
        p_app_value->is_spO2pr_slow_metric_supported = false;
    }

    /* Pulse Amplitude Index field is supported bit */
    if (feature_byte0 & BLE_PLXC_PRV_PLX_FEATURES_SUPPORTED_FEATURES_PULSE_AMPLITUDE_INDEX_FIELD_IS_SUPPORTED)
    {
        p_app_value->is_pulse_amplitude_index_field_supported = true;
    }
    else
    {
        p_app_value->is_pulse_amplitude_index_field_supported = false;
    }

    /*  Multiple Bonds Index field is supported bit */
    if (feature_byte0 & BLE_PLXC_PRV_PLX_FEATURES_SUPPORTED_FEATURES_MULTIPLE_BONDS_SUPPORTED)
    {
        p_app_value->is_multiple_bonds_supported = true;
    }
    else
    {
        p_app_value->is_multiple_bonds_supported = false;
    }

    /* PLXS FEATURES MEASUREMENT STATUS SUPPORTED BITS */
    /*  Measurement Ongoing supported bit */
    if (feature_byte1 & BLE_PLXC_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_MEASUREMENT_ONGOING_BIT_SUPPORTED)
    {
        p_app_value->is_measurement_ongoing = true;
    }
    else
    {
        p_app_value->is_measurement_ongoing = false;
    }

    /* Early Estimated Data supported bit */
    if (feature_byte1 & BLE_PLXC_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_EARLY_ESTIMATED_DATA_BIT_SUPPORTED)
    {
        p_app_value->is_early_estimated_data = true;
    }
    else
    {
        p_app_value->is_early_estimated_data = false;
    }

    /* Validated Data supported bit */
    if (feature_byte1 & BLE_PLXC_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_VALIDATED_DATA_BIT_SUPPORTED)
    {
        p_app_value->is_validated_data = true;
    }
    else
    {
        p_app_value->is_validated_data = false;
    }

    /* Fully Qualified Data  supported bit */
    if (feature_byte1 & BLE_PLXC_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_FULLY_QUALIFIED_DATA_BIT_SUPPORTED)
    {
        p_app_value->is_fully_qualified_data = true;
    }
    else
    {
        p_app_value->is_fully_qualified_data = false;
    }

    /* Data from Measurement Storage supported bit */
    if (feature_byte1 & BLE_PLXC_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_DATA_FROM_MEASUREMENT_STORAGE_BIT_SUPPORTED)
    {
        p_app_value->is_data_from_measurement_storage = true;
    }
    else
    {
        p_app_value->is_data_from_measurement_storage = false;
    }

    /*  Data for Demonstration supported bit */
    if (feature_byte1 & BLE_PLXC_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_DATA_FOR_DEMONSTRATION_BIT_SUPPORTED)
    {
        p_app_value->is_data_for_demonstration = true;
    }
    else
    {
        p_app_value->is_data_for_demonstration = false;
    }

    /*   Data for Testing supported bit */
    if (feature_byte1 & BLE_PLXC_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_DATA_FOR_TESTING_BIT_SUPPORTED)
    {
        p_app_value->is_data_for_testing = true;
    }
    else
    {
        p_app_value->is_data_for_testing = false;
    }

    /*   Calibration Ongoing supported bit */
    if (feature_byte1 & BLE_PLXC_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_CALIBRATION_ONGOING_BIT_SUPPORTED)
    {
        p_app_value->is_calibration_ongoing = true;
    }
    else
    {
        p_app_value->is_calibration_ongoing = false;
    }

    /*   Measurement Unavailable supported bit */
    if (feature_byte1 & BLE_PLXC_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_MEASUREMENT_UNAVAILABLE_BIT_SUPPORTED)
    {
        p_app_value->is_measurement_unavailable = true;
    }
    else
    {
        p_app_value->is_measurement_unavailable = false;
    }

    /*    Questionable Measurement Detected supported bit */
    if (feature_byte1 & BLE_PLXC_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_QUESTIONABLE_MEASUREMENT_DETECTED_BIT_SUPPORTED)
    {
        p_app_value->is_questionable_measurement_detected = true;
    }
    else
    {
        p_app_value->is_questionable_measurement_detected = false;
    }

    /* Invalid Measurement Detected supported bit */
    if (feature_byte1 & BLE_PLXC_PRV_PLX_FEATURES_MEASUREMENT_STATUS_SUPPORT_INVALID_MEASUREMENT_DETECTED_BIT_SUPPORTED)
    {
        p_app_value->is_invalid_measurement_detected = true;
    }
    else
    {
        p_app_value->is_invalid_measurement_detected = false;
    }

    /*PLXS Features Device and Sensor status bit fields*/
    /* Extended Display Update Ongoing supported bit */
    if (feature_byte2 & BLE_PLXC_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_EXTENDED_DISPLAY_UPDATE_ONGOING_BIT_SUPPORTED)
    {
        p_app_value->is_extended_display_update_ongoing = true;
    }
    else
    {
        p_app_value->is_extended_display_update_ongoing = false;
    }

    /* Equipment Malfunction Detected supported bit */
    if (feature_byte2 & BLE_PLXC_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_EQUIPMENT_MALFUNCTION_DETECTED_BIT_SUPPORTED)
    {
        p_app_value->is_equipment_malfunction_detected = true;
    }
    else
    {
        p_app_value->is_equipment_malfunction_detected = false;
    }

    /* Signal Processing Irregularity Detected supported bit */
    if (feature_byte2 & BLE_PLXC_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_SIGNAL_PROCESSING_IRREGULARITY_DETECTED_BIT_SUPPORTED)
    {
        p_app_value->is_signal_processing_irregularity_detected = true;
    }
    else
    {
        p_app_value->is_signal_processing_irregularity_detected = false;
    }

    /* Inadequate Signal Detected supported bit */
    if (feature_byte2 & BLE_PLXC_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_INADEQUITE_SIGNAL_DETECTED_BIT_SUPPORTED)
    {
        p_app_value->is_inadequate_signal_detected = true;
    }
    else
    {
        p_app_value->is_inadequate_signal_detected = false;
    }

    /* Poor Signal Detected supported bit */
    if (feature_byte2 & BLE_PLXC_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_POOR_SIGNAL_DETECTED_BIT_SUPPORTED)
    {
        p_app_value->is_poor_signal_detected = true;
    }
    else
    {
        p_app_value->is_poor_signal_detected = false;
    }

    /*  Low Perfusion Detected supported bit */
    if (feature_byte2 & BLE_PLXC_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_LOW_PERFUSION_DETECTED_BIT_SUPPORTED)
    {
        p_app_value->is_low_perfusion_detected = true;
    }
    else
    {
        p_app_value->is_low_perfusion_detected = false;
    }

    /*  Erratic Signal Detected supported bit */
    if (feature_byte2 & BLE_PLXC_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_ERRATIC_SIGNAL_DETECTED_BIT_SUPPORTED)
    {
        p_app_value->is_erratic_perfusion_detected = true;
    }
    else
    {
        p_app_value->is_erratic_perfusion_detected = false;
    }

    /*  Non-Pulsatile Signal Detected supported bit */
    if (feature_byte2 & BLE_PLXC_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_NONPULSATILE_SIGNAL_DETECTED_BIT_SUPPORTED)
    {
        p_app_value->is_non_pulsatile_signal_detected = true;
    }
    else
    {
        p_app_value->is_non_pulsatile_signal_detected = false;
    }

    /* Questionable Pulse Detected supported bit */
    if (feature_byte2 & BLE_PLXC_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_QUESTIONABLE_PULSE_DETECTED_BIT_SUPPORTED)
    {
        p_app_value->is_questionable_pulse_detected = true;
    }
    else
    {
        p_app_value->is_questionable_pulse_detected = false;
    }

    /* Signal Analysis Ongoing supported bit */
    if (feature_byte2 & BLE_PLXC_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_SIGNAL_ANALYSIS_ONGOING_BIT_SUPPORTED)
    {
        p_app_value->is_siganl_analysis_ongoing = true;
    }
    else
    {
        p_app_value->is_siganl_analysis_ongoing = false;
    }

    /* Sensor Interference Detected supported bit */
    if (feature_byte2 & BLE_PLXC_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_SENSOR_INTERFACE_DETECTED_BIT_SUPPORTED)
    {
        p_app_value->is_sensor_interference_detected = true;
    }
    else
    {
        p_app_value->is_sensor_interference_detected = false;
    }

    /* Sensor Unconnected to User supported bit */
    if (feature_byte2 & BLE_PLXC_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_SENSOR_UNCONNECTED_TO_USER_BIT_SUPPORTED)
    {
        p_app_value->is_sensor_unconnected_to_user = true;
    }
    else
    {
        p_app_value->is_sensor_unconnected_to_user = false;
    }

    /* Unknown Sensor Connected supported bit */
    if (feature_byte2 & BLE_PLXC_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_UNKNOWN_SENSOR_CONNECTED_BIT_SUPPORTED)
    {
        p_app_value->is_unknown_sensor_connected = true;
    }
    else
    {
        p_app_value->is_unknown_sensor_connected = false;
    }

    /* Sensor Displaced  supported bit */
    if (feature_byte2 & BLE_PLXC_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_SENSOR_DISPLACED_BIT_SUPPORTED)
    {
        p_app_value->is_sensor_displaced = true;
    }
    else
    {
        p_app_value->is_sensor_displaced = false;
    }

    /* Sensor Malfunctioning supported bit */
    if (feature_byte2 & BLE_PLXC_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_SENSOR_MALFUNCTIONING_BIT_SUPPORTED)
    {
        p_app_value->is_sensor_malfunctioning = true;
    }
    else
    {
        p_app_value->is_sensor_malfunctioning = false;
    }

    /* Sensor Disconnected supported bit */
    if (feature_byte2 & BLE_PLXC_PRV_PLX_FEATURES_DEVICE_AND_SENSOR_STATUS_SUPPORT_SENSOR_DISCONNECTED_BIT_SUPPORTED)
    {
        p_app_value->is_sensor_disconnected = true;
    }
    else
    {
        p_app_value->is_sensor_disconnected = false;
    }
    
    return BLE_SUCCESS;
}

/***********************************************************************************************************************//**
* Function Name: encode_record_access_control_point
* Description  : This function converts Record Access Control Point characteristic value representation in
*                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
* Arguments    : p_app_value - pointer to the Record Access Control Point  value in the application layer
*                p_gatt_value - pointer to the characteristic value in the GATT database
* Return Value : ble_status_t
**********************************************************************************************************************/
static ble_status_t encode_record_access_control_point(const st_ble_plxc_record_access_control_point_t *p_app_value,
                                                          st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->racp_op_code);
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->racp_operator);

    if (BLE_PLXC_PRV_RACP_LENGTH == p_gatt_value->value_len)
    {
        for (int32_t i = 0; (i < 8); i++)
        {
            p_gatt_value->p_value[pos] = p_app_value->operand_values[i];
        }

        pos += 1;

        for (int32_t i = 0; (i < 10); i++)
        {
            p_gatt_value->p_value[pos] = p_app_value->operand_reponse_code_values[i];
        }

        pos += 1;
    }
    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

/***********************************************************************************************************************//**
* Function Name: encode_record_access_control_point_rat
* Description  : This function converts Record Access Control Point characteristic value representation in
*                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
* Arguments    : p_app_value - pointer to the Record Access Control Point  value in the application layer
*                p_gatt_value - pointer to the characteristic value in the GATT database
* Return Value : ble_status_t
**********************************************************************************************************************/
static ble_status_t encode_record_access_control_point_rat(const st_ble_plxc_record_access_control_point_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->racp_op_code);
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->racp_operator);

    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}

/***********************************************************************************************************************//**
* Function Name: decode_record_access_control_point
* Description  : This function converts Record Access Control Point characteristic value representation in
*                GATT (uint8_t[]) to representation in application layer (struct).
* Arguments    : p_app_value - pointer to the Record Access Control Point value in the application layer
*                p_gatt_value - pointer to the characteristic value in the GATT database
* Return Value : ble_status_t
**********************************************************************************************************************/
static ble_status_t decode_record_access_control_point(st_ble_plxc_record_access_control_point_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    if (BLE_PLXC_RECORD_ACCESS_CONTROL_POINT_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }
    
    p_app_value->racp_op_code         = p_gatt_value->p_value[pos++];
    p_app_value->racp_operator   = p_gatt_value->p_value[pos++];

    for (int32_t i = 0; (i < 8); i++)
    {
        p_app_value->operand_values[i] = p_gatt_value->p_value[pos];
    }
    pos += 1;

    for (int32_t i = 0; (i < 10); i++)
    {
        p_app_value->operand_reponse_code_values[i] = p_gatt_value->p_value[pos];
    }
    pos += 1;

    return BLE_SUCCESS;
}

/***********************************************************************************************************************//**
* Function Name: plxc_gattc_cb
* Description  : Callback function for the Pulse Oximeter Service GATTC events.
* Arguments    : conn_hdl - handle to the connection
*                result - ble status
*              : p_data - pointer to GATTC event data
* Return Value : none
***********************************************************************************************************************/
static void plxc_gattc_cb(uint16_t type, ble_status_t result, st_ble_gattc_evt_data_t *p_data) // @suppress("Function length")
{
    st_plxc_peer_param_t *p_peer = find_peer_param(p_data->conn_hdl);
    ble_status_t ret;

    switch (type)
    {
        case BLE_GATTC_EVENT_CHAR_READ_RSP:
        {
            st_ble_gattc_rd_char_evt_t *p_rd_char_evt_param =
                (st_ble_gattc_rd_char_evt_t *)p_data->p_param;

            if (p_rd_char_evt_param->read_data.attr_hdl == p_peer->hdls.plx_features_char_val_hdl)
            {
                ble_status_t ret;
                st_ble_plxc_plx_features_t app_value;

                ret = decode_plx_features(&app_value, &p_rd_char_evt_param->read_data.value);
                
                st_ble_plxc_evt_data_t evt_data =
                {
                    .conn_hdl = p_data->conn_hdl,
                    .param_len = sizeof(app_value),
                    .p_param = &app_value,
                };

                gs_plxc_cb(BLE_PLXC_EVENT_PLX_FEATURES_READ_RSP, ret, &evt_data);
                
            }            
        }
        break;

        case BLE_GATTC_EVENT_CHAR_WRITE_RSP:
        {
            st_ble_gattc_wr_char_evt_t *p_wr_char_evt_param =
                (st_ble_gattc_wr_char_evt_t *)p_data->p_param;

            st_ble_plxc_evt_data_t evt_data = 
            {
                .conn_hdl  = p_data->conn_hdl,
                .param_len = 0,
                .p_param   = NULL,
            };

            if (p_wr_char_evt_param->value_hdl == p_peer->hdls.record_access_control_point_char_val_hdl)
            {
                gs_plxc_cb(BLE_PLXC_EVENT_RECORD_ACCESS_CONTROL_POINT_WRITE_RSP, result, &evt_data);
            }
            else if ((p_wr_char_evt_param->value_hdl == p_peer->hdls.plx_spot_check_measurement_cli_cnfg_hdl) ||
                     (p_wr_char_evt_param->value_hdl == p_peer->hdls.plx_continuous_measurement_cli_cnfg_hdl) ||
                     (p_wr_char_evt_param->value_hdl == p_peer->hdls.record_access_control_point_cli_cnfg_hdl))
            {
                gs_plxc_cb(BLE_PLXC_EVENT_CLI_CNFG_WRITE_RSP, result, &evt_data);
            }
            else
            {
                /* DO NOTHING */
            }
        }
        break;

        case BLE_GATTC_EVENT_HDL_VAL_IND:
        {
            st_ble_gattc_ind_evt_t *p_ind_evt_param =
                (st_ble_gattc_ind_evt_t *)p_data->p_param;

            if (p_ind_evt_param->data.attr_hdl == p_peer->hdls.plx_spot_check_measurement_char_val_hdl)
            {
                ble_status_t ret;
                st_ble_plxc_plx_spot_check_measurement_t app_value;

                ret = decode_plx_spot_check_measurement(&app_value, &p_ind_evt_param->data.value);
               
                st_ble_plxc_evt_data_t evt_data =
                {
                    .conn_hdl  = p_data->conn_hdl,
                    .param_len = sizeof(app_value),
                    .p_param   = &app_value,
                };

                gs_plxc_cb(BLE_PLXC_EVENT_PLX_SPOT_CHECK_MEASUREMENT_HDL_VAL_IND, ret, &evt_data);
                
            }
            else if (p_ind_evt_param->data.attr_hdl == p_peer->hdls.record_access_control_point_char_val_hdl)
            {
                ble_status_t ret;
                st_ble_plxc_record_access_control_point_t app_value;

                ret = decode_record_access_control_point(&app_value, &p_ind_evt_param->data.value);

                st_ble_plxc_evt_data_t evt_data =
                {
                    .conn_hdl  = p_data->conn_hdl,
                    .param_len = sizeof(app_value),
                    .p_param   = &app_value,
                };

                gs_plxc_cb(BLE_PLXC_EVENT_RECORD_ACCESS_CONTROL_POINT_HDL_VAL_IND, ret, &evt_data);
            }
            else
            {
                /* DO NOTHING */
            }
        } 
        break;

        case BLE_GATTC_EVENT_HDL_VAL_NTF:
        {
            st_ble_gattc_ntf_evt_t *p_ntf_evt_param =
                (st_ble_gattc_ntf_evt_t *)p_data->p_param;
            if (p_ntf_evt_param->data.attr_hdl == p_peer->hdls.plx_continuous_measurement_char_val_hdl)
            {
                ble_status_t ret;
                st_ble_plxc_plx_continuous_measurement_t app_value;

                ret = decode_plx_continuous_measurement(&app_value, &p_ntf_evt_param->data.value);

                st_ble_plxc_evt_data_t evt_data =
                {
                    .conn_hdl  = p_data->conn_hdl,
                    .param_len = sizeof(app_value),
                    .p_param   = &app_value,
                };

                gs_plxc_cb(BLE_PLXC_EVENT_PLX_CONTINUOUS_MEASUREMENT_HDL_VAL_NTF, ret, &evt_data);
               
            }            
        }
        break;

        case BLE_GATTC_EVENT_ERROR_RSP:
        {
            st_ble_gattc_err_rsp_evt_t *p_err_rsp_evt_param =
                (st_ble_gattc_err_rsp_evt_t *)p_data->p_param;

            st_ble_plxc_evt_data_t evt_data = 
            {
                .conn_hdl  = p_data->conn_hdl,
                .param_len = sizeof(st_ble_gattc_err_rsp_evt_t),
                .p_param   = p_err_rsp_evt_param,
            };

            if ((p_err_rsp_evt_param->attr_hdl == p_peer->hdls.plx_features_char_val_hdl) ||
                (p_err_rsp_evt_param->attr_hdl == p_peer->hdls.record_access_control_point_char_val_hdl))
            {
                gs_plxc_cb(BLE_PLXC_EVENT_ERROR_RSP, result, &evt_data);
            }            
        }
        break;

        default:
        {
            /* Do nothing. */
        }
        break;
    }
}

/***********************************************************************************************************************//**
* Function Name: R_BLE_PLXC_Init
* Description  : This function initializes the GATTS Server and Pulse Oximeter Service, registers the callback function for
*                GATTS.
* Arguments    : p_param - pointer to the initialization parameters data
* Return Value : BLE_SUCCESS               - Success
*                BLE_ERR_INVALID_PTR       - The p_ntf_data parameter or the value field in the value field in
*                                            the p_ntf_data parameter is NULL.
*                BLE_ERR_INVALID_ARG       - The value_len field in the value field in the p_ntf_data parameter is 0
*                                            or the attr_hdl field in the p_ntf_data parameters is 0.
**********************************************************************************************************************/
ble_status_t R_BLE_PLXC_Init(const st_ble_plxc_init_param_t *p_param) // @suppress("API function naming")
{
    if (NULL == p_param)
    {
        return BLE_ERR_INVALID_PTR;
    }
    
    if (NULL == p_param->cb)
    {
        return BLE_ERR_INVALID_ARG;
    }
    
    for (uint8_t i = 0; i < 8; i++)
    {
        clear_peer_param(&gs_peer_params[i]);
    }

    R_BLE_GATTC_RegisterCb(plxc_gattc_cb, 1);

    gs_plxc_cb = p_param->cb;
    
    return BLE_SUCCESS;
}

/***********************************************************************************************************************//**
* Function Name: R_BLE_PLXC_Connect
* Description  : This function Connects the GATTS Server and Pulse Oximeter Service.
* Arguments    : conn_hdl - Connection Handler
*                p_param  - pointer to the Connecting parameters data
* Return Value : BLE_SUCCESS           - Success
*                BLE_ERR_INVALID_HDL   - The remote device specified by conn_hdl was not found.
**********************************************************************************************************************/
ble_status_t R_BLE_PLXC_Connect(uint16_t conn_hdl, const st_ble_plxc_connect_param_t *p_param) // @suppress("API function naming")
{
    st_plxc_peer_param_t *p_peer = get_new_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }
    
    if ((NULL != p_param) && (NULL != p_param->p_hdls))
    {
        memcpy(&p_peer->hdls, p_param->p_hdls, sizeof(p_peer->hdls));
    }
       
    return BLE_SUCCESS;
}

/***********************************************************************************************************************//**
* Function Name: R_BLE_PLXC_Disconnect
* Description  : This function Dis_Connects the GATTS Server and Pulse Oximeter Service.
* Arguments    : conn_hdl - Connection Handler
*                p_param  - pointer to the Connecting parameters data
* Return Value : BLE_SUCCESS           - Success
*                BLE_ERR_INVALID_HDL   - The remote device specified by conn_hdl was not found.
**********************************************************************************************************************/
ble_status_t R_BLE_PLXC_Disconnect(uint16_t conn_hdl, st_ble_plxc_disconnect_param_t *p_param) // @suppress("API function naming")
{
    st_plxc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }
    
    if ((NULL != p_param) && (NULL != p_param->p_hdls))
    {
        memcpy(p_param->p_hdls, &p_peer->hdls, sizeof(*p_param->p_hdls));
    }
   
    clear_peer_param(p_peer);

    return BLE_SUCCESS;
}

/***********************************************************************************************************************//**
* Function Name: R_BLE_PLXC_SetPlxSpotcheckMeasurementCliCnfg
* Description  : This function Indicates Pulse Oximeter Service Spot Check Measurement
* Arguments    : conn_hdl     - Connection handle identifying the remote device to be sent the indication.
*                cli_cnfg     - pointer to the Connecting parameters data(The attribute value to send)
* Return Value : BLE_SUCCESS           - Success
*                BLE_ERR_INVALID_PTR   - The p_ntf_data parameter or the value field in the value field in
*                                        the p_ntf_data parameter is NULL.
*                BLE_ERR_INVALID_HDL   - The remote device specified by conn_hdl was not found.
*                BLE_ERR_INVALID_STATE - The attribute is not in a state to be written.
**********************************************************************************************************************/
ble_status_t R_BLE_PLXC_SetPlxSpotcheckMeasurementCliCnfg(uint16_t conn_hdl, uint16_t cli_cnfg) // @suppress("API function naming")
{
    st_plxc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }
    
    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.plx_spot_check_measurement_cli_cnfg_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }
   
   if (0 != (cli_cnfg & 0xFFFC))
    {
        return BLE_ERR_INVALID_ARG;
    }
    
    uint8_t byte_value[2] = { 0 };
    BT_PACK_LE_2_BYTE(byte_value, &cli_cnfg);

    st_ble_gatt_hdl_value_pair_t gatt_value =
    {
        .attr_hdl = p_peer->hdls.plx_spot_check_measurement_cli_cnfg_hdl,
        .value    = 
        {
            .p_value   = byte_value,
            .value_len = 2,
        }
    };

    return R_BLE_GATTC_WriteChar(conn_hdl, &gatt_value);
}

/***********************************************************************************************************************//**
* Function Name: R_BLE_PLXC_SetPlxContinuousMeasurementCliCnfg
* Description  : This function Indicates Pulse Oximeter Service Continuous Measurement Data
* Arguments    : conn_hdl    - Connection handle identifying the remote device to be sent the indication.
*                cli_cnfg    - pointer to the Connecting parameters data(The attribute value to send)
* Return Value : BLE_SUCCESS           - Success
*                BLE_ERR_INVALID_PTR   - The p_ntf_data parameter or the value field in the value field in
*                                        the p_ntf_data parameter is NULL.
*                BLE_ERR_INVALID_HDL   - The remote device specified by conn_hdl was not found.
*                BLE_ERR_INVALID_STATE - The attribute is not in a state to be written.
**********************************************************************************************************************/
ble_status_t R_BLE_PLXC_SetPlxContinuousMeasurementCliCnfg(uint16_t conn_hdl, uint16_t cli_cnfg) // @suppress("API function naming")
{
    st_plxc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }
   
    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.plx_continuous_measurement_cli_cnfg_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }
   
    if (0 != (cli_cnfg & 0xFFFC))
    {
        return BLE_ERR_INVALID_ARG;
    }
    
    uint8_t byte_value[2] = { 0 };
    BT_PACK_LE_2_BYTE(byte_value, &cli_cnfg);

    st_ble_gatt_hdl_value_pair_t gatt_value =
    {
        .attr_hdl = p_peer->hdls.plx_continuous_measurement_cli_cnfg_hdl,
        .value    = 
        {
            .p_value   = byte_value,
            .value_len = 2,
        }
    };

    return R_BLE_GATTC_WriteChar(conn_hdl, &gatt_value);
}

/***********************************************************************************************************************//**
* Function Name: R_BLE_PLXC_ReadPlxFeatures
* Description  : This function sets the Pulse Oximeter Service Features data
* Arguments    : conn_hdl  - Connection handler
* Return Value : BLE_SUCCESS           - Success
*                BLE_ERR_INVALID_PTR   - The p_ntf_data parameter or the value field in the value field in
*                                        the p_ntf_data parameter is NULL.
*                BLE_ERR_INVALID_HDL   - The remote device specified by conn_hdl was not found.
*                BLE_ERR_INVALID_STATE - The attribute is not in a state to be written.
**********************************************************************************************************************/
ble_status_t R_BLE_PLXC_ReadPlxFeatures(uint16_t conn_hdl) // @suppress("API function naming")
{
    st_plxc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }
    
    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.plx_features_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }
    
    return R_BLE_GATTC_ReadChar(conn_hdl, p_peer->hdls.plx_features_char_val_hdl);
}

/***********************************************************************************************************************//**
* Function Name: R_BLE_PLXC_WriteRecordAccessControlPoint
* Description  : This function Writes to the Pulse Oximeter Service response of record access control point
* Arguments    : conn_hdl      - Connection Handler
*                p_app_value   - pointer to the record access control point parameters data
* Return Value : BLE_SUCCESS           - Success
*                BLE_ERR_INVALID_PTR   - The p_ntf_data parameter or the value field in the value field in
*                                        the p_ntf_data parameter is NULL.
*                BLE_ERR_INVALID_HDL   - The remote device specified by conn_hdl was not found.
*                BLE_ERR_INVALID_STATE - The attribute is not in a state to be written.
**********************************************************************************************************************/
ble_status_t R_BLE_PLXC_WriteRecordAccessControlPointRAT(uint16_t conn_hdl, const st_ble_plxc_record_access_control_point_t *p_app_value) // @suppress("API function naming")
{
    ble_status_t ret;
    st_plxc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (NULL == p_app_value)
    {
        return BLE_ERR_INVALID_PTR;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.record_access_control_point_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    uint8_t byte_value[BLE_PLXC_RECORD_ACCESS_CONTROL_POINT_LEN] = { 0 };

    st_ble_gatt_hdl_value_pair_t write_value =
    {
        .attr_hdl = p_peer->hdls.record_access_control_point_char_val_hdl,
        .value =
        {
            .p_value = byte_value,
            .value_len = BLE_PLXC_RECORD_ACCESS_CONTROL_POINT_LEN,
        }
    };

    ret = encode_record_access_control_point_rat(p_app_value, &write_value.value);

    if (BLE_SUCCESS != ret)
    {
        return BLE_ERR_INVALID_DATA;
    }

    return R_BLE_GATTC_WriteChar(conn_hdl, &write_value);
}

/***********************************************************************************************************************//**
* Function Name: R_BLE_PLXC_WriteRecordAccessControlPoint
* Description  : This function Writes to the Pulse Oximeter Service response of record access control point
* Arguments    : conn_hdl      - Connection Handler
*                p_app_value   - pointer to the record access control point parameters data
* Return Value : BLE_SUCCESS           - Success
*                BLE_ERR_INVALID_PTR   - The p_ntf_data parameter or the value field in the value field in
*                                        the p_ntf_data parameter is NULL.
*                BLE_ERR_INVALID_HDL   - The remote device specified by conn_hdl was not found.
*                BLE_ERR_INVALID_STATE - The attribute is not in a state to be written.
**********************************************************************************************************************/
ble_status_t R_BLE_PLXC_WriteRecordAccessControlPoint(uint16_t conn_hdl, const st_ble_plxc_record_access_control_point_t *p_app_value) // @suppress("API function naming")
{
    ble_status_t ret;
    st_plxc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }
    
    if (NULL == p_app_value)
    {
        return BLE_ERR_INVALID_PTR;
    }
    
    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.record_access_control_point_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }        

    uint8_t byte_value[BLE_PLXC_RECORD_ACCESS_CONTROL_POINT_LEN] = { 0 };

    st_ble_gatt_hdl_value_pair_t write_value =
    {
        .attr_hdl  = p_peer->hdls.record_access_control_point_char_val_hdl,
        .value     = 
        {
            .p_value   = byte_value,
            .value_len = BLE_PLXC_RECORD_ACCESS_CONTROL_POINT_LEN,
        }
    };
    
    ret = encode_record_access_control_point(p_app_value, &write_value.value);
    if (BLE_SUCCESS != ret)
    {
        return BLE_ERR_INVALID_DATA;
    }

    return R_BLE_GATTC_WriteChar(conn_hdl, &write_value);
}

/***********************************************************************************************************************//**
* Function Name: R_BLE_PLXC_SetRecordAccessControlPointCliCnfg
* Description  : This function Sets the Pulse Oximeter Service Record Access Control  Point Data
* Arguments    : conn_hdl      - Connection handle identifying the remote device to be sent the indication.
*                cli_cnfg      - pointer to the Connecting parameters data(The attribute value to send)
* Return Value : BLE_SUCCESS           - Success
*                BLE_ERR_INVALID_PTR   - The p_ntf_data parameter or the value field in the value field in
*                                        the p_ntf_data parameter is NULL.
*                BLE_ERR_INVALID_HDL   - The remote device specified by conn_hdl was not found.
*                BLE_ERR_INVALID_STATE - The attribute is not in a state to be written.
**********************************************************************************************************************/
ble_status_t R_BLE_PLXC_SetRecordAccessControlPointCliCnfg(uint16_t conn_hdl, uint16_t cli_cnfg) // @suppress("API function naming")
{
    st_plxc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }
    
    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.record_access_control_point_cli_cnfg_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }
   
    if (0 != (cli_cnfg & 0xFFFC))
    {
        return BLE_ERR_INVALID_ARG;
    }
    
    uint8_t byte_value[2] = { 0 };
    BT_PACK_LE_2_BYTE(byte_value, &cli_cnfg);

    st_ble_gatt_hdl_value_pair_t gatt_value = 
    {
        .attr_hdl = p_peer->hdls.record_access_control_point_cli_cnfg_hdl,
        .value    = 
        {
            .p_value   = byte_value,
            .value_len = 2,
        }
    };

    return R_BLE_GATTC_WriteChar(conn_hdl, &gatt_value);
}

/***********************************************************************************************************************//**
 * Function Name: R_BLE_PLXC_ServDiscCb
 * Description  : Callback function for the Pulse Oximeter Service Discovery events.
 * Arguments    : conn_hdl  - handle to the connection
 *                type      - discovery event id
 *              : p_param   - pointer to GATTC event data
 *              : idx       - Service index used to distinguish the multiple same UUID service.
 * Return Value : none
***********************************************************************************************************************/
void R_BLE_PLXC_ServDiscCb(uint16_t conn_hdl, uint8_t idx, uint16_t type, void *p_param) // @suppress("API function naming")
{
    st_plxc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    switch (type)
    {
        case BLE_DISC_PRIM_SERV_FOUND:
        {
            st_disc_serv_param_t *p_serv_param = (st_disc_serv_param_t *)p_param;
            memcpy(&p_peer->hdls.service_range, &p_serv_param->value.serv_16.range, sizeof(p_peer->hdls.service_range));
        }
        break;

        case BLE_DISC_CHAR_FOUND:
        {
            st_disc_char_param_t *p_char_param = (st_disc_char_param_t *)p_param;

            if (BLE_GATT_16_BIT_UUID_FORMAT == p_char_param->uuid_type)
            {
                uint8_t uuid_16[BLE_GATT_16_BIT_UUID_SIZE];
                BT_PACK_LE_2_BYTE(uuid_16, &p_char_param->value.char_16.uuid_16);

                if (0 == memcmp(uuid_16, BLE_PLXC_PLX_SPOT_CHECK_MEASUREMENT_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.plx_spot_check_measurement_char_val_hdl = p_char_param->value.char_16.value_hdl;

                    for (uint8_t i = 0; i < p_char_param->num_of_descs; i++)
                    {
                        BT_PACK_LE_2_BYTE(uuid_16, &p_char_param->descs[i].value.desc_16.uuid_16);

                        if (0 == memcmp(uuid_16, BLE_PLXC_PLX_SPOT_CHECK_MEASUREMENT_CLIENT_CHARACTERISTIC_CONFIGURATION_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                        {
                            p_peer->hdls.plx_spot_check_measurement_cli_cnfg_hdl = p_char_param->descs[i].value.desc_16.desc_hdl;
                        }                        
                    }
                }
                else if (0 == memcmp(uuid_16, BLE_PLXC_PLX_CONTINUOUS_MEASUREMENT_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.plx_continuous_measurement_char_val_hdl = p_char_param->value.char_16.value_hdl;

                    for (uint8_t i = 0; i < p_char_param->num_of_descs; i++)
                    {
                        BT_PACK_LE_2_BYTE(uuid_16, &p_char_param->descs[i].value.desc_16.uuid_16);

                        if (0 == memcmp(uuid_16, BLE_PLXC_PLX_CONTINUOUS_MEASUREMENT_CLIENT_CHARACTERISTIC_CONFIGURATION_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                        {
                            p_peer->hdls.plx_continuous_measurement_cli_cnfg_hdl = p_char_param->descs[i].value.desc_16.desc_hdl;
                        }                       
                    }
                }
                else if (0 == memcmp(uuid_16, BLE_PLXC_PLX_FEATURES_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.plx_features_char_val_hdl = p_char_param->value.char_16.value_hdl;
                }
                else if (0 == memcmp(uuid_16, BLE_PLXC_RECORD_ACCESS_CONTROL_POINT_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.record_access_control_point_char_val_hdl = p_char_param->value.char_16.value_hdl;

                    for (uint8_t i = 0; i < p_char_param->num_of_descs; i++)
                    {
                        BT_PACK_LE_2_BYTE(uuid_16, &p_char_param->descs[i].value.desc_16.uuid_16);

                        if (0 == memcmp(uuid_16, BLE_PLXC_RECORD_ACCESS_CONTROL_POINT_CLIENT_CHARACTERISTIC_CONFIGURATION_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                        {
                            p_peer->hdls.record_access_control_point_cli_cnfg_hdl = p_char_param->descs[i].value.desc_16.desc_hdl;
                        }                        
                    }
                }
            }
            else
            {
                /* DO NOTHING */
            }
        } 
        break;

        default:
        {
            /* Do nothing. */
        } 
        break;
    }
}

/***********************************************************************************************************************//**
* Function Name: R_BLE_PLXC_GetVersion
* Description  : This function gets the Pulse Oximeter Service Version
* Arguments    : none
* Return Value : version - version of the device
**********************************************************************************************************************/
uint32_t R_BLE_PLXC_GetVersion(void) // @suppress("API function naming")
{
    uint32_t version;

    version = ((BLE_PLXC_PRV_VERSION_MAJOR << 16) | (BLE_PLXC_PRV_VERSION_MINOR << 8));

    return version;
}
