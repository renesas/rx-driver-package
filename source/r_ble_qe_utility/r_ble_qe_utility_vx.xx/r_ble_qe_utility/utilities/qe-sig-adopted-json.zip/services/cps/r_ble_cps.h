/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_cps.h
 * Version : 1.0
 * Description : This module implements Cycling Power Service Server.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 26.04.2019 1.00 First Release
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @file
 * @defgroup cps Cycling Power Service 
 * @{
 * @ingroup profile
 * @brief   This file provides APIs to interface Cycling Power Service.
 **********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_ble_rx23w_if.h"
#include "profile_cmn/r_ble_profile_cmn.h"

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
#ifndef R_BLE_CPS
#define R_BLE_CPS

/*******************************************************************************************************************//**
 * @brief Number of sensor locations.
***********************************************************************************************************************/
#define NUM_OF_SUPPORTED_SENSOR_LOCATIONS (17)

/*******************************************************************************************************************//**
 * @brief Inappopropriate Connection Parameters error code.
***********************************************************************************************************************/
#define BLE_CPS_INAPPOPROPRIATE_CONNECTION_PARAMETERS (BLE_ERR_GROUP_GATT | 0x80)

/*******************************************************************************************************************//**
 * @brief Pedal Power Balance Supported bit.
***********************************************************************************************************************/
#define BLE_CPS_CYCLING_POWER_FEATURE_CYCLING_POWER_FEATURE_PEDAL_POWER_BALANCE_SUPPORTED (1 << 0)
            
/*******************************************************************************************************************//**
 * @brief Accumulated Torque Supported bit.
***********************************************************************************************************************/
#define BLE_CPS_CYCLING_POWER_FEATURE_CYCLING_POWER_FEATURE_ACCUMULATED_TORQUE_SUPPORTED (1 << 1)
            
/*******************************************************************************************************************//**
 * @brief Wheel Revolution Data Supported bit.
***********************************************************************************************************************/
#define BLE_CPS_CYCLING_POWER_FEATURE_CYCLING_POWER_FEATURE_WHEEL_REVOLUTION_DATA_SUPPORTED (1 << 2)
            
/*******************************************************************************************************************//**
 * @brief Crank Revolution Data Supported bit.
***********************************************************************************************************************/
#define BLE_CPS_CYCLING_POWER_FEATURE_CYCLING_POWER_FEATURE_CRANK_REVOLUTION_DATA_SUPPORTED (1 << 3)
            
/*******************************************************************************************************************//**
 * @brief Extreme Magnitudes Supported bit.
***********************************************************************************************************************/
#define BLE_CPS_CYCLING_POWER_FEATURE_CYCLING_POWER_FEATURE_EXTREME_MAGNITUDES_SUPPORTED (1 << 4)
            
/*******************************************************************************************************************//**
 * @brief Extreme Angles Supported bit.
***********************************************************************************************************************/
#define BLE_CPS_CYCLING_POWER_FEATURE_CYCLING_POWER_FEATURE_EXTREME_ANGLES_SUPPORTED (1 << 5)
            
/*******************************************************************************************************************//**
 * @brief Top and Bottom Dead Spot Angles Supported bit.
***********************************************************************************************************************/
#define BLE_CPS_CYCLING_POWER_FEATURE_CYCLING_POWER_FEATURE_TOP_AND_BOTTOM_DEAD_SPOT_ANGLES_SUPPORTED (1 << 6)
            
/*******************************************************************************************************************//**
 * @brief Accumulated Energy Supported bit.
***********************************************************************************************************************/
#define BLE_CPS_CYCLING_POWER_FEATURE_CYCLING_POWER_FEATURE_ACCUMULATED_ENERGY_SUPPORTED (1 << 7)
            
/*******************************************************************************************************************//**
 * @brief Offset Compensation Indicator Supported bit.
***********************************************************************************************************************/
#define BLE_CPS_CYCLING_POWER_FEATURE_CYCLING_POWER_FEATURE_OFFSET_COMPENSATION_INDICATOR_SUPPORTED (1 << 8)
            
/*******************************************************************************************************************//**
 * @brief Offset Compensation Supported bit.
***********************************************************************************************************************/
#define BLE_CPS_CYCLING_POWER_FEATURE_CYCLING_POWER_FEATURE_OFFSET_COMPENSATION_SUPPORTED (1 << 9)
            
/*******************************************************************************************************************//**
 * @brief Cycling Power Measurement Characteristic Content Masking Supported bit.
***********************************************************************************************************************/
#define BLE_CPS_CYCLING_POWER_FEATURE_CYCLING_POWER_FEATURE_CYCLING_POWER_MEASUREMENT_CHARACTERISTIC_CONTENT_MASKING_SUPPORTED (1 << 10)
            
/*******************************************************************************************************************//**
 * @brief Multiple Sensor Locations Supported bit.
***********************************************************************************************************************/
#define BLE_CPS_CYCLING_POWER_FEATURE_CYCLING_POWER_FEATURE_MULTIPLE_SENSOR_LOCATIONS_SUPPORTED (1 << 11)
            
/*******************************************************************************************************************//**
 * @brief Crank Length Adjustment Supported  bit.
***********************************************************************************************************************/
#define BLE_CPS_CYCLING_POWER_FEATURE_CYCLING_POWER_FEATURE_CRANK_LENGTH_ADJUSTMENT_SUPPORTED_ (1 << 12)
            
/*******************************************************************************************************************//**
 * @brief Chain Length Adjustment Supported bit.
***********************************************************************************************************************/
#define BLE_CPS_CYCLING_POWER_FEATURE_CYCLING_POWER_FEATURE_CHAIN_LENGTH_ADJUSTMENT_SUPPORTED (1 << 13)
            
/*******************************************************************************************************************//**
 * @brief Chain Weight Adjustment Supported bit.
***********************************************************************************************************************/
#define BLE_CPS_CYCLING_POWER_FEATURE_CYCLING_POWER_FEATURE_CHAIN_WEIGHT_ADJUSTMENT_SUPPORTED (1 << 14)
            
/*******************************************************************************************************************//**
 * @brief Span Length Adjustment Supported bit.
***********************************************************************************************************************/
#define BLE_CPS_CYCLING_POWER_FEATURE_CYCLING_POWER_FEATURE_SPAN_LENGTH_ADJUSTMENT_SUPPORTED (1 << 15)
            
/*******************************************************************************************************************//**
 * @brief Sensor Measurement Context bit.
***********************************************************************************************************************/
#define BLE_CPS_CYCLING_POWER_FEATURE_CYCLING_POWER_FEATURE_SENSOR_MEASUREMENT_CONTEXT (1 << 16)
            
/*******************************************************************************************************************//**
 * @brief Instantaneous Measurement Direction Supported bit.
***********************************************************************************************************************/
#define BLE_CPS_CYCLING_POWER_FEATURE_CYCLING_POWER_FEATURE_INSTANTANEOUS_MEASUREMENT_DIRECTION_SUPPORTED (1 << 17)
            
/*******************************************************************************************************************//**
 * @brief Factory Calibration Date Supported bit.
***********************************************************************************************************************/
#define BLE_CPS_CYCLING_POWER_FEATURE_CYCLING_POWER_FEATURE_FACTORY_CALIBRATION_DATE_SUPPORTED (1 << 18)
            
/*******************************************************************************************************************//**
 * @brief Enhanced Offset Compensation Supported bit.
***********************************************************************************************************************/
#define BLE_CPS_CYCLING_POWER_FEATURE_CYCLING_POWER_FEATURE_ENHANCED_OFFSET_COMPENSATION_SUPPORTED (1 << 19)
            
/*******************************************************************************************************************//**
 * @brief Distribute System Support bits.
***********************************************************************************************************************/
#define BLE_CPS_CYCLING_POWER_FEATURE_CYCLING_POWER_FEATURE_DISTRIBUTE_SYSTEM_SUPPORT (((1 << 2) - 1) << 20)


/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @brief Cycling Power Service event data.
***********************************************************************************************************************/
typedef struct
{
    uint16_t  conn_hdl;  /**< Connection handle */
    uint16_t  param_len; /**< Event parameter length */
    void     *p_param;    /**< Event parameter */
} st_ble_cps_evt_data_t;

/*******************************************************************************************************************//**
 * @brief Cycling Power Service event callback.
***********************************************************************************************************************/
typedef void (*ble_cps_app_cb_t)(uint16_t type, ble_status_t result, st_ble_cps_evt_data_t *p_data);

/*******************************************************************************************************************//**
 * @brief Cycling Power Service event type.
***********************************************************************************************************************/
typedef enum {
    BLE_CPS_EVENT_CYCLING_POWER_CONTROL_POINT_CLI_CNFG_ENABLED, /**< Cycling Power Control Point characteristic cli cnfg enabled event */
    BLE_CPS_EVENT_CYCLING_POWER_CONTROL_POINT_CLI_CNFG_DISABLED, /**< Cycling Power Control Point characteristic cli cnfg disabled event */
    BLE_CPS_EVENT_CYCLING_POWER_CONTROL_POINT_HDL_VAL_CNF, /**< Cycling Power Control Point characteristic handle value confiration event */
    BLE_CPS_EVENT_CYCLING_POWER_MEASUREMENT_CLI_CNFG_ENABLED, /**< Cycling Power Measurement characteristic cli cnfg enabled event */
    BLE_CPS_EVENT_CYCLING_POWER_MEASUREMENT_CLI_CNFG_DISABLED, /**< Cycling Power Measurement characteristic cli cnfg disabled event */
    BLE_CPS_EVENT_CYCLING_POWER_VECTOR_CLI_CNFG_ENABLED, /**< Cycling Power Vector characteristic cli cnfg enabled event */
    BLE_CPS_EVENT_CYCLING_POWER_VECTOR_CLI_CNFG_DISABLED, /**< Cycling Power Vector characteristic cli cnfg disabled event */
    BLE_CPS_EVENT_CYCLING_POWER_CONTROL_POINT_WRITE_REQ, /**< Cycling Power Control Point characteristic write request event */
    BLE_CPS_EVENT_CYCLING_POWER_FEATURE_READ_REQ, /**< Cycling Power Feature characteristic read request event */
    BLE_CPS_EVENT_SENSOR_LOCATION_READ_REQ, /**< Sensor Location characteristic read request event */
} e_ble_cps_event_t;

/*******************************************************************************************************************//**
 * @brief Sensor Location enumeration.
***********************************************************************************************************************/
typedef enum {
    BLE_CPS_SENSOR_LOCATION_SENSOR_LOCATION_OTHER = 0, /**< TODO */
    BLE_CPS_SENSOR_LOCATION_SENSOR_LOCATION_TOP_OF_SHOE = 1, /**< TODO */
    BLE_CPS_SENSOR_LOCATION_SENSOR_LOCATION_IN_SHOE = 2, /**< TODO */
    BLE_CPS_SENSOR_LOCATION_SENSOR_LOCATION_HIP = 3, /**< TODO */
    BLE_CPS_SENSOR_LOCATION_SENSOR_LOCATION__FRONT_WHEEL = 4, /**< TODO */
    BLE_CPS_SENSOR_LOCATION_SENSOR_LOCATION_LEFT_CRANK = 5, /**< TODO */
    BLE_CPS_SENSOR_LOCATION_SENSOR_LOCATION_RIGHT_CRANK = 6, /**< TODO */
    BLE_CPS_SENSOR_LOCATION_SENSOR_LOCATION_LEFT_PEDAL = 7, /**< TODO */
    BLE_CPS_SENSOR_LOCATION_SENSOR_LOCATION_RIGHT_PEDAL = 8, /**< TODO */
    BLE_CPS_SENSOR_LOCATION_SENSOR_LOCATION__FRONT_HUB = 9, /**< TODO */
    BLE_CPS_SENSOR_LOCATION_SENSOR_LOCATION_REAR_DROPOUT = 10, /**< TODO */
    BLE_CPS_SENSOR_LOCATION_SENSOR_LOCATION_CHAINSTAY = 11, /**< TODO */
    BLE_CPS_SENSOR_LOCATION_SENSOR_LOCATION_REAR_WHEEL = 12, /**< TODO */
    BLE_CPS_SENSOR_LOCATION_SENSOR_LOCATION_REAR_HUB = 13, /**< TODO */
    BLE_CPS_SENSOR_LOCATION_SENSOR_LOCATION_CHEST = 14, /**< TODO */
    BLE_CPS_SENSOR_LOCATION_SENSOR_LOCATION_SPIDER = 15, /**< TODO */
    BLE_CPS_SENSOR_LOCATION_SENSOR_LOCATION_CHAIN_RING = 16, /**< TODO */
} e_ble_cps_sensor_location_t;

/*******************************************************************************************************************//**
 * @brief Op Codes enumeration.
***********************************************************************************************************************/
typedef enum {
    BLE_CPS_CYCLING_POWER_CONTROL_POINT_OP_CODES_SET_CUMULATIVE_VALUE = 1, /**< TODO */
    BLE_CPS_CYCLING_POWER_CONTROL_POINT_OP_CODES_UPDATE_SENSOR_LOCATION = 2, /**< TODO */
    BLE_CPS_CYCLING_POWER_CONTROL_POINT_OP_CODES_REQUEST_SUPPORTED_SENSOR_LOCATIONS = 3, /**< TODO */
    BLE_CPS_CYCLING_POWER_CONTROL_POINT_OP_CODES_SET_CRANK_LENGTH = 4, /**< TODO */
    BLE_CPS_CYCLING_POWER_CONTROL_POINT_OP_CODES_REQUEST_CRANK_LENGTH = 5, /**< TODO */
    BLE_CPS_CYCLING_POWER_CONTROL_POINT_OP_CODES_SET_CHAIN_LENGTH = 6, /**< TODO */
    BLE_CPS_CYCLING_POWER_CONTROL_POINT_OP_CODES_REQUEST_CHAIN_LENGTH = 7, /**< TODO */
    BLE_CPS_CYCLING_POWER_CONTROL_POINT_OP_CODES_SET_CHAIN_WEIGHT = 8, /**< TODO */
    BLE_CPS_CYCLING_POWER_CONTROL_POINT_OP_CODES_REQUEST_CHAIN_WEIGHT = 9, /**< TODO */
    BLE_CPS_CYCLING_POWER_CONTROL_POINT_OP_CODES_SET_SPAN_LENGTH = 10, /**< TODO */
    BLE_CPS_CYCLING_POWER_CONTROL_POINT_OP_CODES_REQUEST_SPAN_LENGTH = 11, /**< TODO */
    BLE_CPS_CYCLING_POWER_CONTROL_POINT_OP_CODES_START_OFFSET_COMPENSATION = 12, /**< TODO */
    BLE_CPS_CYCLING_POWER_CONTROL_POINT_OP_CODES_MASK_CYCLING_POWER_MEASUREMENT_CHARACTERISTIC_CONTENT = 13, /**< TODO */
    BLE_CPS_CYCLING_POWER_CONTROL_POINT_OP_CODES_REQUEST_SAMPLING_RATE = 14, /**< TODO */
    BLE_CPS_CYCLING_POWER_CONTROL_POINT_OP_CODES_REQUEST_FACTORY_CALIBRATION_DATE = 15, /**< TODO */
    BLE_CPS_CYCLING_POWER_CONTROL_POINT_OP_CODES_START_ENHANCED_OFFSET_COMPENSATION = 16, /**< TODO */
} e_ble_cps_cycling_power_control_point_opcodes_t;

/*******************************************************************************************************************//**
 * @brief Response Value enumeration.
***********************************************************************************************************************/
typedef enum {
    BLE_CPS_CYCLING_POWER_CONTROL_POINT_RESPONSE_VALUE_SUCCESS = 1, /**< TODO */
    BLE_CPS_CYCLING_POWER_CONTROL_POINT_RESPONSE_VALUE_OP_CODE_NOT_SUPPORTED = 2, /**< TODO */
    BLE_CPS_CYCLING_POWER_CONTROL_POINT_RESPONSE_VALUE_INVALID_PARAMETER = 3, /**< TODO */
    BLE_CPS_CYCLING_POWER_CONTROL_POINT_RESPONSE_VALUE_OPERATION_FAILED = 4, /**< TODO */
} e_ble_cps_cycling_power_control_point_t;

/*******************************************************************************************************************//**
 * @brief Cycling Power Service initialization parameters.
***********************************************************************************************************************/
typedef struct {
    ble_cps_app_cb_t cb; /**< Cycling Power Service event callback */
} st_ble_cps_init_param_t;

/*******************************************************************************************************************//**
 * @brief Cycling Power Service connection parameters.
***********************************************************************************************************************/
typedef struct {
    uint16_t cycling_power_measurement_cli_cnfg; /**< Cycling Power Measurement characteristic cli cnfg */
    uint16_t cycling_power_vector_cli_cnfg; /**< Cycling Power Vector characteristic cli cnfg */
    uint16_t cycling_power_control_point_cli_cnfg; /**< Cycling Power Control Point characteristic cli cnfg */
} st_ble_cps_connect_param_t;

/*******************************************************************************************************************//**
 * @brief Cycling Power Service disconnection parameters.
***********************************************************************************************************************/
typedef struct {
    uint16_t cycling_power_measurement_cli_cnfg; /**< Cycling Power Measurement characteristic cli cnfg */
    uint16_t cycling_power_vector_cli_cnfg; /**< Cycling Power Vector characteristic cli cnfg */
    uint16_t cycling_power_control_point_cli_cnfg; /**< Cycling Power Control Point characteristic cli cnfg */
} st_ble_cps_disconnect_param_t;

/*******************************************************************************************************************//**
 * @brief Cycling Power Measurement characteristic flag parameters.
***********************************************************************************************************************/
typedef struct {
    bool is_pedal_power_balance_present; /**< Pedal Power Balance is present or not */
    bool pedal_power_balance_ref; /**< Pedal Power Balance reference */
    bool is_accu_torque_present; /**<  Accumulated Torque is present or not */
    uint8_t accu_torque_source:1; /**<  Accumulated Torque source */
    bool is_wheel_revlutn_data_prsnt; /**< Wheel Revolution Data is present or not */
    bool is_crank_revlutn_data_prsnt; /**<Crank Revolution Data is present or not */
    bool is_extreme_force_mag_prsnt; /**< Extreme Force Magnitudes  is present or not */
    bool is_extreme_torque_mag_prsnt; /**< Extreme Torque Magnitudes is present or not */
    bool is_extreme_angles_prsnt; /**< Extreme Angles  is present or not */
    bool is_top_dead_spot_angle_prsnt; /**< Top Dead Spot Angle  is present or not */
    bool is_bottom_dead_spot_angle_prsnt; /**< Bottom Dead Spot Angle is present or not */
    bool is_accu_energy_prsnt; /**< Accumulated Energy is present or not */
    uint8_t offset_comp_indicator:1; /**< Offset Compensation Indicator */
} st_ble_cps_cycling_power_measurement_t_flags_t;

/*******************************************************************************************************************//**
 * @brief Cycling Power Measurement characteristic parameters.
***********************************************************************************************************************/
typedef struct {
    st_ble_cps_cycling_power_measurement_t_flags_t flags; /**< Flags value */
    int16_t instantaneous_power; /**< Instantaneous Power value */
    uint8_t pedal_power_balance; /**< Pedal Power Balance value */
    uint16_t accumulated_torque; /**< Accumulated Torque value */
    uint32_t wheel_revolution_data___cumulative_wheel_revolutions; /**< Wheel Revolution Data - Cumulative Wheel Revolutions value */
    uint16_t wheel_revolution_data___last_wheel_event_time; /**< Wheel Revolution Data - Last Wheel Event Time value */
    uint16_t crank_revolution_data__cumulative_crank_revolutions; /**< Crank Revolution Data- Cumulative Crank Revolutions value */
    uint16_t crank_revolution_data__last_crank_event_time; /**< Crank Revolution Data- Last Crank Event Time value */
    int16_t extreme_force_magnitudes___maximum_force_magnitude; /**< Extreme Force Magnitudes - Maximum Force Magnitude value */
    int16_t extreme_force_magnitudes___minimum_force_magnitude; /**< Extreme Force Magnitudes - Minimum Force Magnitude value */
    int16_t extreme_torque_magnitudes__maximum_torque_magnitude; /**< Extreme Torque Magnitudes- Maximum Torque Magnitude value */
    int16_t extreme_torque_magnitudes__minimum_torque_magnitude; /**< Extreme Torque Magnitudes- Minimum Torque Magnitude value */
    uint16_t extreme_angles___maximum_angle; /**< Extreme Angles - Maximum Angle value */
    uint16_t extreme_angles___minimum_angle; /**< Extreme Angles - Minimum Angle value */
    uint16_t top_dead_spot_angle; /**< Top Dead Spot Angle value */
    uint16_t bottom_dead_spot_angle; /**< Bottom Dead Spot Angle value */
    uint16_t accumulated_energy; /**< Accumulated Energy value */
} st_ble_cps_cycling_power_measurement_t;

/*******************************************************************************************************************//**
 * @brief Cycling Power Vector characteristic flag parameters.
***********************************************************************************************************************/
typedef struct {
    bool is_crank_revolution_data_prsnt; /**< Crank Revolution Data is present or not */
    bool is_first_crank_mesurmnt; /**< First Crank Measurement */
    bool is_inst_force_magn_arr__prsnt; /**<  Instantaneous Force Magnitude is present or not */
    bool is_inst_torque_magn_arr__prsnt; /**<  Instantaneous Torque Magnitude is present or not */
    uint8_t inst_mesurmnt_direction:2; /**<  Accumulated Torque source */
} st_ble_cps_cycling_power_vector_t_flags_t;

/*******************************************************************************************************************//**
 * @brief Cycling Power Vector characteristic parameters.
***********************************************************************************************************************/
typedef struct {
    st_ble_cps_cycling_power_vector_t_flags_t flags; /**< Flags value */
    uint16_t crank_revolution_data___cumulative_crank_revolutions; /**< Crank Revolution Data - Cumulative Crank Revolutions value */
    uint16_t crank_revolution_data___last_crank_event_time; /**< Crank Revolution Data - Last Crank Event Time value */
    uint16_t first_crank_measurement_angle; /**< First Crank Measurement Angle  value */
    int16_t instantaneous_force_magnitude_array; /**< Instantaneous Force Magnitude Array value */
    int16_t instantaneous_torque_magnitude_array; /**< Instantaneous Torque Magnitude Array value */
} st_ble_cps_cycling_power_vector_t;

/*******************************************************************************************************************//**
 * @brief Cycling Power Control Point Request .
***********************************************************************************************************************/
typedef union {
    uint32_t cumultive_value;
    uint8_t sensor_location; /**< Supported Location */
    uint16_t crank_length; /**<  crank length in millimeters with a resolution of 1/2 millimeter */
    uint16_t chain_length; /**<  chain length in millimeters with a resolution of 1 millimeter */
    uint16_t chain_weight; /**<  chain weight in grams with a resolution of 1 gram */
    uint16_t span_length; /**<   span length in millimeters with a resolution of 1 millimeter */
    uint16_t content_settings_cp_mesurmnt; /**< content settings of the Cycling Power Measurement characteristic  */
} un_ble_cps_cp_control_point_request_parameter_t;

/*******************************************************************************************************************//**
 * @brief Cycling Power Control Point Request parameters.
***********************************************************************************************************************/
typedef struct {
    uint8_t opcode; /**< Request opcode */
    un_ble_cps_cp_control_point_request_parameter_t req_param; /**< Request param */
} st_ble_cps_cp_control_point_request_t;

/*******************************************************************************************************************//**
 * @brief Cycling Power Control Point Response parameters.
***********************************************************************************************************************/

typedef struct {
    int16_t cntxt_bit_cyclic_power_feature; /**< Context bit of the Cycling Power Feature */
    uint16_t company_id; /**< manufacturer Company ID */
    uint8_t num_of_octets; /**< number of octets of manufacturer specific data */
    uint8_t manufacturer_data; /**< manufacturer specific data */
} st_ble_cps_start_enhanced_offset_compensation_respnse_t;

typedef union {
    uint8_t list_of_supported_locations[NUM_OF_SUPPORTED_SENSOR_LOCATIONS]; /**< List of supported locations */
    uint16_t crank_length; /**< crank length in millimeters with a resolution of 1/2 millimeter */
    uint16_t chain_length; /**< chain length in millimeters with a resolution of 1 millimeter */
    uint16_t chain_weight; /**< chain weight in grams with a resolution of 1 gram */
    uint16_t span_length;  /**< span length in millimeters with a resolution of 1 millimeter */
    uint8_t sampling_rate; /**< sampling rate in Hertz with a resolution of 1 Hertz */
    st_ble_date_time_t factory_calibration_date; /**< factory calibration date */
    uint16_t offset_comp; /**< start offset compensation */
    st_ble_cps_start_enhanced_offset_compensation_respnse_t eocr_response; /**< Enhanced offset compensation response */
} un_ble_cps_cp_control_point_response_parameter_t;

/*******************************************************************************************************************//**
 * @brief Cycling Power Control Point Response .
***********************************************************************************************************************/
typedef struct {
    uint8_t opcode; /* Request Opcode*/
    uint8_t rsp_value; /**< Response value */ 
    un_ble_cps_cp_control_point_response_parameter_t param; /**< Response param */
} st_ble_cps_cp_control_point_response_t;


/***********************************************************************************************************************
Exported global functions (to be accessed by other files)
***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @brief     Initialize Cycling Power Service.
 * @details   This function shall be called once at startup.
 * @param[in] param Cycling Power Service initialization parameters.
 * @return
***********************************************************************************************************************/
ble_status_t R_BLE_CPS_Init(const st_ble_cps_init_param_t *p_param);

/*******************************************************************************************************************//**
 * @brief     Perform Cycling Power Service connection settings.
 * @details   This function shall be called on each connection establishment.
 * @param[in] conn_hdl Connection handle.
 * @param[in] param    Connection parameters.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_CPS_Connect(uint16_t conn_hdl, const st_ble_cps_connect_param_t *p_param);

/*******************************************************************************************************************//**
 * @brief     Retrieve Cycling Power Service connection specific settings before disconnection.
 * @details   This function shall be called on each disconnection.
 * @param[in] conn_hdl Connection handle.
 * @param[in] param    Disconnection parameters.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_CPS_Disconnect(uint16_t conn_hdl, st_ble_cps_disconnect_param_t *p_param);

/*******************************************************************************************************************//**
 * @brief     Send Cycling Power Measurement notification.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] app_value Cycling Power Measurement value to send.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_CPS_NotifyCyclingPowerMeasurement(uint16_t conn_hdl, const st_ble_cps_cycling_power_measurement_t *p_app_value);

/*******************************************************************************************************************//**
 * @brief      Get Cycling Power Feature characteristic value from local GATT database.
 * @param[out] app_value Retrieved Cycling Power Feature characteristic value.
 * @return     @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_CPS_GetCyclingPowerFeature(uint32_t *p_app_value);

/*******************************************************************************************************************//**
 * @brief     Set Cycling Power Feature characteristic value to local GATT database.
 * @param[in] app_value Cycling Power Feature characteristic value to set.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_CPS_SetCyclingPowerFeature(uint32_t app_value);

/*******************************************************************************************************************//**
 * @brief      Get Sensor Location characteristic value from local GATT database.
 * @param[out] app_value Retrieved Sensor Location characteristic value.
 * @return     @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_CPS_GetSensorLocation(uint8_t *p_app_value);

/*******************************************************************************************************************//**
 * @brief     Set Sensor Location characteristic value to local GATT database.
 * @param[in] app_value Sensor Location characteristic value to set.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_CPS_SetSensorLocation(uint8_t app_value);

/*******************************************************************************************************************//**
 * @brief     Send Cycling Power Vector notification.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] app_value Cycling Power Vector value to send.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_CPS_NotifyCyclingPowerVector(uint16_t conn_hdl, const st_ble_cps_cycling_power_vector_t *p_app_value);

/*******************************************************************************************************************//**
 * @brief     Send Cycling Power Control Point indication.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] app_value Cycling Power Control Point value to send.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_CPS_IndicateCyclingPowerControlPoint(uint16_t conn_hdl, const st_ble_cps_cp_control_point_response_t *p_app_value);


/*******************************************************************************************************************//**
 * @brief     Return version of the CPC service server.
 * @return    version
***********************************************************************************************************************/
uint32_t R_BLE_CPS_GetVersion(void);

#endif /* R_BLE_CPS */

/** @} */
