/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_cps.c
 * Version : 1.0
 * Description : This module implements Cycling Power Service Server.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 26.04.2019 1.00 First Release
 ***********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <string.h>
#include "profile_cmn/r_ble_serv_common.h"
#include "r_ble_cps.h"
#include "gatt_db.h"

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/

/* Version number */
#define BLE_CPS_PRV_VERSION_MAJOR (1)
#define BLE_CPS_PRV_VERSION_MINOR (0)

/*******************************************************************************************************************//**
 * @brief Pedal Power Balance Present bit.
***********************************************************************************************************************/
#define BLE_PRV_CPS_CP_MESURMNT_FLAGS_PEDAL_POWER_BALANCE_PRSNT (1 << 0)

/*******************************************************************************************************************//**
 * @brief Pedal Power Balance Reference bit.
***********************************************************************************************************************/
#define BLE_PRV_CPS_CP_MESURMNT_FLAGS_PEDAL_POWER_BALANCE_REFERENCE (1 << 1)

/*******************************************************************************************************************//**
 * @brief Accumulated Torque Present bit.
***********************************************************************************************************************/
#define BLE_PRV_CPS_CP_MESURMNT_FLAGS_ACCUMULATED_TORQUE_PRSNT (1 << 2)

/*******************************************************************************************************************//**
 * @brief Accumulated Torque Source bit.
***********************************************************************************************************************/
#define BLE_PRV_CPS_CP_MESURMNT_FLAGS_ACCUMULATED_TORQUE_SOURCE (1 << 3)

/*******************************************************************************************************************//**
 * @brief Wheel Revolution Data Present bit.
***********************************************************************************************************************/
#define BLE_PRV_CPS_CP_MESURMNT_FLAGS_WHEEL_REVOLUTION_DATA_PRSNT (1 << 4)

/*******************************************************************************************************************//**
 * @brief Crank Revolution Data Present bit.
***********************************************************************************************************************/
#define BLE_PRV_CPS_CP_MESURMNT_FLAGS_CRANK_REVOLUTION_DATA_PRSNT (1 << 5)

/*******************************************************************************************************************//**
 * @brief Extreme Force Magnitudes Present bit.
***********************************************************************************************************************/
#define BLE_PRV_CPS_CP_MESURMNT_FLAGS_EXTREME_FORCE_MAGNITUDES_PRSNT (1 << 6)

/*******************************************************************************************************************//**
 * @brief Extreme Torque Magnitudes Present bit.
***********************************************************************************************************************/
#define BLE_PRV_CPS_CP_MESURMNT_FLAGS_EXTREME_TORQUE_MAGNITUDES_PRSNT (1 << 7)

/*******************************************************************************************************************//**
 * @brief Extreme Angles Present bit.
***********************************************************************************************************************/
#define BLE_PRV_CPS_CP_MESURMNT_FLAGS_EXTREME_ANGLES_PRSNT (1 << 0)

/*******************************************************************************************************************//**
 * @brief Top Dead Spot Angle Present bit.
***********************************************************************************************************************/
#define BLE_PRV_CPS_CP_MESURMNT_FLAGS_TOP_DEAD_SPOT_ANGLE_PRSNT (1 << 1)

/*******************************************************************************************************************//**
 * @brief Bottom Dead Spot Angle Present bit.
***********************************************************************************************************************/
#define BLE_PRV_CPS_CP_MESURMNT_FLAGS_BOTTOM_DEAD_SPOT_ANGLE_PRSNT (1 << 2)

/*******************************************************************************************************************//**
 * @brief Accumulated Energy Present bit.
***********************************************************************************************************************/
#define BLE_PRV_CPS_CP_MESURMNT_FLAGS_ACCUMULATED_ENERGY_PRSNT (1 << 3)

/*******************************************************************************************************************//**
 * @brief Offset Compensation Indicator  bit.
***********************************************************************************************************************/
#define BLE_PRV_CPS_CP_MESURMNT_FLAGS_OFFSET_COMPENSATION_INDICATOR (1 << 4)


/* Cycling Power Vector Macros*/
/*******************************************************************************************************************//**
 * @brief Crank Revolution Data Present bit.
***********************************************************************************************************************/
#define BLE_PRV_CPS_CPV_FLAGS_CRANK_REVLUTN_DATA_PRSNT (1 << 0)

/*******************************************************************************************************************//**
 * @brief First Crank Measurement Angle Present bit.
***********************************************************************************************************************/
#define BLE_PRV_CPS_CPV_FLAGS_FIRST_CRANK_MESURMNT_ANGLE_PRSNT (1 << 1)

/*******************************************************************************************************************//**
 * @brief Instantaneous Force Magnitude Array Present bit.
***********************************************************************************************************************/
#define BLE_PRV_CPS_CPV_FLAGS_INSTANT_FORCE_MAGNITUDE_ARR_PRSNT (1 << 2)

/*******************************************************************************************************************//**
 * @brief Instantaneous Torque Magnitude Array Present bit.
***********************************************************************************************************************/
#define BLE_PRV_CPS_CPV_FLAGS_INSTANT_TORQUE_MAGNITUDE_ARR_PRSNT (1 << 3)

/*******************************************************************************************************************//**
 * @brief Instantaneous Measurement Direction bits.
***********************************************************************************************************************/
#define BLE_PRV_CPS_CPV_FLAGS_INSTANT_MESURENT_DIRECTN (((1 << 2) - 1) << 4)

/*******************************************************************************************************************//**
 * @brief Response code to be sent to every response for control point request.
***********************************************************************************************************************/
#define BLE_CPS_CYCLING_POWER_CONTROL_POINT_OP_CODES_RESPONSE_CODE (32)

#define CYCLIC_POWER_CONTROL_POINT_HEADER_LENGTH (0x03)
#define DATE_TIME_LEN (0x07)
#define BLE_CPS_CYCLING_POWER_CONTROL_POINT_IND_LEN (0x40)

/*******************************************************************************************************************//**
 * @brief Request Opcode not suported range
***********************************************************************************************************************/
#define BLE_CPS_CP_CONTROL_POINT_OP_CODES_RESERVED_FOR_FUTURE_USE_START1 (17)
#define BLE_CPS_CP_CONTROL_POINT_OP_CODES_RESERVED_FOR_FUTURE_USE_END1  (31)
#define BLE_CPS_CP_CONTROL_POINT_OP_CODES_RESERVED_FOR_FUTURE_USE_START2 (33)
#define BLE_CPS_CP_CONTROL_POINT_OP_CODES_RESERVED_FOR_FUTURE_USE_END2 (255)

#define BLE_CPS_PRV_CONTROL_POINT_EVENT_ID (11)


/***********************************************************************************************************************
Private global variables and functions
***********************************************************************************************************************/

static ble_cps_app_cb_t gs_cps_cb;

/*static bool gs_cp_control_point_in_progress;*/
static bool gs_invalid_param_received;
static bool gs_op_code_not_supported;
static bool gs_op_code_not_supported_event;



typedef struct {
    uint16_t conn_hdl;
    uint8_t opcode;
    uint8_t len;
    un_ble_cps_cp_control_point_request_parameter_t param;
} st_cps_info_in_progress_t;

static st_cps_info_in_progress_t gs_control_point_info;

/***********************************************************************************************************************
 * Function Name: set_cli_cnfg
 * Description  : Set Characteristic value notification configuration in local GATT database.
 * Arguments    : conn_hdl - handle to connection.
 *                attr_hadl - handle to the attribute
 *                cli_cnfg - configuration value
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t set_cli_cnfg(uint16_t conn_hdl, uint16_t attr_hdl, uint16_t cli_cnfg)
{
    uint8_t data[2];

    BT_PACK_LE_2_BYTE(data, &cli_cnfg);

    st_ble_gatt_value_t gatt_value = {
        .p_value   = data,
        .value_len = 2,
    };

    return R_BLE_GATTS_SetAttr(conn_hdl, attr_hdl, &gatt_value);
}

/***********************************************************************************************************************
 * Function Name: get_cli_cnfg
 * Description  : Get Characteristic value notification configuration from local GATT database.
 * Arguments    : conn_hdl - handle to connection.
 *                attr_hadl - handle to the attribute
 *                p_cli_cnfg - pointer to variable to store configuration value
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t get_cli_cnfg(uint16_t conn_hdl, uint16_t attr_hdl, uint16_t *p_cli_cnfg)
{
    ble_status_t ret;
    st_ble_gatt_value_t gatt_value;

    ret = R_BLE_GATTS_GetAttr(conn_hdl, attr_hdl, &gatt_value);

    if (BLE_SUCCESS == ret)
    {
        BT_UNPACK_LE_2_BYTE(p_cli_cnfg, gatt_value.p_value);
    }

    return ret;
}

/***********************************************************************************************************************
 * Function Name: encode_cycling_power_measurement
 * Description  : This function converts Cycling Power Measurement characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the Cycling Power Measurement  value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_cycling_power_measurement(const st_ble_cps_cycling_power_measurement_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 2;
    /*uint16_t value = 0x000;*/
    if (NULL == p_app_value)
    {
        return BLE_ERR_INVALID_PTR;
    }
    //memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    /* Packing instantaneous power*/
    BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->instantaneous_power);
    pos += 2;
    /* Packing pedal power balance measurement */
    if (p_app_value->flags.is_pedal_power_balance_present)
    {
        p_gatt_value->p_value[0] |= BLE_PRV_CPS_CP_MESURMNT_FLAGS_PEDAL_POWER_BALANCE_PRSNT;
        BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->pedal_power_balance);
    }
    if (p_app_value->flags.pedal_power_balance_ref)
    {
        p_gatt_value->p_value[0] |= BLE_PRV_CPS_CP_MESURMNT_FLAGS_PEDAL_POWER_BALANCE_REFERENCE;
    }

    /* Packing Accumulated Torque  */
    if (p_app_value->flags.is_accu_torque_present)
    {
        p_gatt_value->p_value[0] |= BLE_PRV_CPS_CP_MESURMNT_FLAGS_ACCUMULATED_TORQUE_PRSNT;
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->accumulated_torque);
        pos += 2;
    }

    /* Packing Wheel Revolution Data */
    if (p_app_value->flags.is_wheel_revlutn_data_prsnt)
    {
        p_gatt_value->p_value[0] |= BLE_PRV_CPS_CP_MESURMNT_FLAGS_WHEEL_REVOLUTION_DATA_PRSNT;
        BT_PACK_LE_4_BYTE(&p_gatt_value->p_value[pos], &p_app_value->wheel_revolution_data___cumulative_wheel_revolutions);
        pos += 4;
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->wheel_revolution_data___last_wheel_event_time);
        pos += 2;
    }

    /* Packing Crank Revolution Data */
    if (p_app_value->flags.is_crank_revlutn_data_prsnt)
    {
        p_gatt_value->p_value[0] |= BLE_PRV_CPS_CP_MESURMNT_FLAGS_CRANK_REVOLUTION_DATA_PRSNT;
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->crank_revolution_data__cumulative_crank_revolutions);
        pos += 2;
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->crank_revolution_data__last_crank_event_time);
        pos += 2;
    }

    /* Packing Extreme Force Magnitudes */
    if (p_app_value->flags.is_extreme_force_mag_prsnt)
    {
        p_gatt_value->p_value[0] |= BLE_PRV_CPS_CP_MESURMNT_FLAGS_EXTREME_FORCE_MAGNITUDES_PRSNT;
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->extreme_force_magnitudes___maximum_force_magnitude);
        pos += 2;
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->extreme_force_magnitudes___minimum_force_magnitude);
        pos += 2;
    }

    /* Packing Extreme Torque Magnitudes */
    if (p_app_value->flags.is_extreme_torque_mag_prsnt)
    {
        p_gatt_value->p_value[0] |= BLE_PRV_CPS_CP_MESURMNT_FLAGS_EXTREME_TORQUE_MAGNITUDES_PRSNT;
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->extreme_torque_magnitudes__maximum_torque_magnitude);
        pos += 2;
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->extreme_torque_magnitudes__maximum_torque_magnitude);
        pos += 2;
    }

    /* Packing Extreme Angles */
    if (p_app_value->flags.is_extreme_angles_prsnt)
    {
        p_gatt_value->p_value[1] |= BLE_PRV_CPS_CP_MESURMNT_FLAGS_EXTREME_ANGLES_PRSNT;
        p_gatt_value->p_value[pos++] = (uint8_t)(p_app_value->extreme_angles___maximum_angle & 0xFF);
        p_gatt_value->p_value[pos++] = (uint8_t)(((p_app_value->extreme_angles___maximum_angle >> 8) & 0x0F) | ((p_app_value->extreme_angles___minimum_angle << 4) & 0xF0));
        p_gatt_value->p_value[pos++] = (uint8_t)((p_app_value->extreme_angles___minimum_angle >> 4) & 0xFF);
    }

    /* Packing Top Dead Spot Angle */
    if (p_app_value->flags.is_top_dead_spot_angle_prsnt)
    {
        p_gatt_value->p_value[1] |= BLE_PRV_CPS_CP_MESURMNT_FLAGS_TOP_DEAD_SPOT_ANGLE_PRSNT;
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->top_dead_spot_angle);
        pos += 2;
    }

    /* Packing Bottom Dead Spot Angle */
    if (p_app_value->flags.is_bottom_dead_spot_angle_prsnt)
    {
        p_gatt_value->p_value[1] |= BLE_PRV_CPS_CP_MESURMNT_FLAGS_BOTTOM_DEAD_SPOT_ANGLE_PRSNT;
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->bottom_dead_spot_angle);
        pos += 2;
    }

    /* Packing Accumulated Energy */
    if (p_app_value->flags.is_accu_energy_prsnt)
    {
        p_gatt_value->p_value[1] |= BLE_PRV_CPS_CP_MESURMNT_FLAGS_ACCUMULATED_ENERGY_PRSNT;
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->accumulated_energy);
        pos += 2;
    }
    if (p_app_value->flags.accu_torque_source)
    {
        p_gatt_value->p_value[0] |= BLE_PRV_CPS_CP_MESURMNT_FLAGS_ACCUMULATED_TORQUE_SOURCE;
    }
    if (p_app_value->flags.offset_comp_indicator)
    {
        p_gatt_value->p_value[1] |= BLE_PRV_CPS_CP_MESURMNT_FLAGS_OFFSET_COMPENSATION_INDICATOR;
    }

    p_gatt_value->value_len = (uint16_t)pos;

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_cycling_power_vector
 * Description  : This function converts Cycling Power Vector characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the Cycling Power Vector  value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_cycling_power_vector(const st_ble_cps_cycling_power_vector_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 1;
    /*uint16_t value = 0x000;*/

    if (NULL == p_app_value)
    {
        return BLE_ERR_INVALID_PTR;
    }
    
    /* Packing pedal power balance measurement */
    if (p_app_value->flags.is_crank_revolution_data_prsnt)
    {
        p_gatt_value->p_value[0] |= BLE_PRV_CPS_CPV_FLAGS_CRANK_REVLUTN_DATA_PRSNT;
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->crank_revolution_data___cumulative_crank_revolutions);
        pos += 2;
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->crank_revolution_data___last_crank_event_time);
        pos += 2;
    }

    /* Packing First Crank Measurement */
    if (p_app_value->flags.is_first_crank_mesurmnt)
    {
        p_gatt_value->p_value[0] |= BLE_PRV_CPS_CPV_FLAGS_FIRST_CRANK_MESURMNT_ANGLE_PRSNT;
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->first_crank_measurement_angle);
        pos += 2;
    }

    /* Packing Instantaneous Force Magnitude */
    if (p_app_value->flags.is_inst_force_magn_arr__prsnt)
    {
        p_gatt_value->p_value[0] |= BLE_PRV_CPS_CPV_FLAGS_INSTANT_FORCE_MAGNITUDE_ARR_PRSNT;
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->instantaneous_force_magnitude_array);
        pos += 2;
    }

    /* Packing Instantaneous Torque Magnitude  */
    if (p_app_value->flags.is_inst_torque_magn_arr__prsnt)
    {
        p_gatt_value->p_value[0] |= BLE_PRV_CPS_CPV_FLAGS_INSTANT_TORQUE_MAGNITUDE_ARR_PRSNT;
        BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->instantaneous_torque_magnitude_array);
        pos += 2;
    }

    /* Packing Accumulated Torque source */
    p_gatt_value->p_value[0] = (uint8_t)(p_gatt_value->p_value[0] | ((p_app_value->flags.inst_mesurmnt_direction & 0x3) << 4));

    p_gatt_value->value_len = (uint16_t)pos;

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_cycling_power_control_point
 * Description  : This function converts Cycling Power Control Point characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the Cycling Power Control Point  value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_cycling_power_control_point(const st_ble_cps_cp_control_point_response_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 3;

    p_gatt_value->p_value[0] = BLE_CPS_CYCLING_POWER_CONTROL_POINT_OP_CODES_RESPONSE_CODE;

    if (gs_op_code_not_supported)
    {
        p_gatt_value->p_value[1] = p_app_value->opcode;
        p_gatt_value->p_value[2] = BLE_CPS_CYCLING_POWER_CONTROL_POINT_RESPONSE_VALUE_OP_CODE_NOT_SUPPORTED;
        p_gatt_value->value_len = CYCLIC_POWER_CONTROL_POINT_HEADER_LENGTH;
        gs_op_code_not_supported = false;
        return BLE_ERR_UNSUPPORTED;
    }
    p_gatt_value->p_value[1] = p_app_value->opcode;
    p_gatt_value->p_value[2] = p_app_value->rsp_value;

    switch (p_app_value->opcode)
    {

        case BLE_CPS_CYCLING_POWER_CONTROL_POINT_OP_CODES_SET_CUMULATIVE_VALUE:
        case BLE_CPS_CYCLING_POWER_CONTROL_POINT_OP_CODES_SET_CRANK_LENGTH:
        case BLE_CPS_CYCLING_POWER_CONTROL_POINT_OP_CODES_SET_CHAIN_LENGTH:
        case BLE_CPS_CYCLING_POWER_CONTROL_POINT_OP_CODES_SET_CHAIN_WEIGHT:
        case BLE_CPS_CYCLING_POWER_CONTROL_POINT_OP_CODES_SET_SPAN_LENGTH:
        case BLE_CPS_CYCLING_POWER_CONTROL_POINT_OP_CODES_UPDATE_SENSOR_LOCATION:
        case BLE_CPS_CYCLING_POWER_CONTROL_POINT_OP_CODES_MASK_CYCLING_POWER_MEASUREMENT_CHARACTERISTIC_CONTENT:
        {
            p_gatt_value->value_len = CYCLIC_POWER_CONTROL_POINT_HEADER_LENGTH;
        } break;

        case BLE_CPS_CYCLING_POWER_CONTROL_POINT_OP_CODES_START_OFFSET_COMPENSATION:
        {
            if (gs_invalid_param_received)
            {
                /*uint16_t resp_value_param = 0x00;*/
                p_gatt_value->p_value[2] = BLE_CPS_CYCLING_POWER_CONTROL_POINT_RESPONSE_VALUE_INVALID_PARAMETER;
                p_gatt_value->value_len = CYCLIC_POWER_CONTROL_POINT_HEADER_LENGTH ;
                //BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &resp_value_param);
                gs_invalid_param_received = false;
            }
            else
            {
                BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->param.offset_comp);
                p_gatt_value->value_len = CYCLIC_POWER_CONTROL_POINT_HEADER_LENGTH + 2;
            }
            
        } break;

        case BLE_CPS_CYCLING_POWER_CONTROL_POINT_OP_CODES_REQUEST_SUPPORTED_SENSOR_LOCATIONS:
        {
            memcpy(&p_gatt_value->p_value[pos], p_app_value->param.list_of_supported_locations, NUM_OF_SUPPORTED_SENSOR_LOCATIONS);
            p_gatt_value->value_len = CYCLIC_POWER_CONTROL_POINT_HEADER_LENGTH + NUM_OF_SUPPORTED_SENSOR_LOCATIONS;
        }break;

        case BLE_CPS_CYCLING_POWER_CONTROL_POINT_OP_CODES_REQUEST_CRANK_LENGTH:
        {
            BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->param.crank_length);
            p_gatt_value->value_len = CYCLIC_POWER_CONTROL_POINT_HEADER_LENGTH + 2;
        }break;

        case BLE_CPS_CYCLING_POWER_CONTROL_POINT_OP_CODES_REQUEST_CHAIN_LENGTH:
        {
            BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->param.chain_length);
            p_gatt_value->value_len = CYCLIC_POWER_CONTROL_POINT_HEADER_LENGTH + 2;
        }break;

        case BLE_CPS_CYCLING_POWER_CONTROL_POINT_OP_CODES_REQUEST_CHAIN_WEIGHT:
        {
            BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->param.chain_weight);
            p_gatt_value->value_len = CYCLIC_POWER_CONTROL_POINT_HEADER_LENGTH + 2;
        }break;

        case BLE_CPS_CYCLING_POWER_CONTROL_POINT_OP_CODES_REQUEST_SPAN_LENGTH:
        {
            BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->param.span_length);
            p_gatt_value->value_len = CYCLIC_POWER_CONTROL_POINT_HEADER_LENGTH + 2;
        }break;

        case BLE_CPS_CYCLING_POWER_CONTROL_POINT_OP_CODES_REQUEST_SAMPLING_RATE:
        {
            BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->param.sampling_rate);
            p_gatt_value->value_len = CYCLIC_POWER_CONTROL_POINT_HEADER_LENGTH + 1;
        }break;

        case BLE_CPS_CYCLING_POWER_CONTROL_POINT_OP_CODES_REQUEST_FACTORY_CALIBRATION_DATE:
        {
            p_gatt_value->p_value[pos + 0] = (uint8_t)((p_app_value->param.factory_calibration_date.year >> 0) & 0xFF);/* Casting year to uint8 type*/
            p_gatt_value->p_value[pos + 1] = (uint8_t)((p_app_value->param.factory_calibration_date.year >> 8) & 0xFF);/* Casting year to uint8 type*/
            p_gatt_value->p_value[pos + 2] = (uint8_t)(p_app_value->param.factory_calibration_date.month & 0xFF);/* Casting month to uint8 type*/
            p_gatt_value->p_value[pos + 3] = (uint8_t)(p_app_value->param.factory_calibration_date.day & 0xFF);/* Casting day to uint8 type*/
            p_gatt_value->p_value[pos + 4] = (uint8_t)(p_app_value->param.factory_calibration_date.hours & 0xFF);/* Casting hours to uint8 type*/
            p_gatt_value->p_value[pos + 5] = (uint8_t)(p_app_value->param.factory_calibration_date.minutes & 0xFF);/* Casting minutes to uint8 type*/
            p_gatt_value->p_value[pos + 6] = (uint8_t)(p_app_value->param.factory_calibration_date.seconds & 0xFF);/* Casting seconds to uint8 type*/

            p_gatt_value->value_len = 4 + DATE_TIME_LEN;
        }break;

        case BLE_CPS_CYCLING_POWER_CONTROL_POINT_OP_CODES_START_ENHANCED_OFFSET_COMPENSATION:
        {
            if (p_gatt_value->p_value[2] == BLE_CPS_CYCLING_POWER_CONTROL_POINT_RESPONSE_VALUE_OPERATION_FAILED)
            {
                p_gatt_value->p_value[pos] = 0x01;
                p_gatt_value->value_len = CYCLIC_POWER_CONTROL_POINT_HEADER_LENGTH + 1;
            }
            else
            {
                uint8_t length_manfc_data = 0;
                BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->param.eocr_response.cntxt_bit_cyclic_power_feature);
                pos += 2;

                BT_PACK_LE_2_BYTE(&p_gatt_value->p_value[pos], &p_app_value->param.eocr_response.company_id);
                pos += 2;

                BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->param.eocr_response.num_of_octets);
                length_manfc_data = p_app_value->param.eocr_response.num_of_octets;
                if (length_manfc_data > 0)
                {
                    memcpy(&p_gatt_value->p_value[pos], &p_app_value->param.eocr_response.manufacturer_data, length_manfc_data);
                    pos += length_manfc_data;
                }

                p_gatt_value->value_len = (uint16_t)(CYCLIC_POWER_CONTROL_POINT_HEADER_LENGTH + 5 + length_manfc_data);
            }

        }break;
        
        default:
        {
        } break;
    }

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: decode_cycling_power_control_point
 * Description  : This function converts Cycling Power Control Point characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the Cycling Power Control Point value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status
 **********************************************************************************************************************/
static ble_status_t decode_cycling_power_control_point(st_ble_cps_cp_control_point_request_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    switch (gs_control_point_info.opcode)
    {
        case BLE_CPS_CYCLING_POWER_CONTROL_POINT_OP_CODES_SET_CUMULATIVE_VALUE:
        {
            BT_UNPACK_LE_4_BYTE(&gs_control_point_info.param.cumultive_value, &p_gatt_value->p_value[1]);
            gs_control_point_info.len = 4;
        } break;
        case BLE_CPS_CYCLING_POWER_CONTROL_POINT_OP_CODES_UPDATE_SENSOR_LOCATION:
        {
            BT_UNPACK_LE_1_BYTE(&gs_control_point_info.param.sensor_location, &p_gatt_value->p_value[1]);
            gs_control_point_info.len = 1;
        } break;
       case BLE_CPS_CYCLING_POWER_CONTROL_POINT_OP_CODES_REQUEST_SUPPORTED_SENSOR_LOCATIONS:
        {
        } break;
        case BLE_CPS_CYCLING_POWER_CONTROL_POINT_OP_CODES_SET_CRANK_LENGTH:
        {
            BT_UNPACK_LE_2_BYTE(&gs_control_point_info.param.crank_length, &p_gatt_value->p_value[1]);
            gs_control_point_info.len = 2;
        } break;
        case BLE_CPS_CYCLING_POWER_CONTROL_POINT_OP_CODES_REQUEST_CRANK_LENGTH:
        {
        } break;
        case BLE_CPS_CYCLING_POWER_CONTROL_POINT_OP_CODES_SET_CHAIN_LENGTH:
        {
            BT_UNPACK_LE_2_BYTE(&gs_control_point_info.param.chain_length, &p_gatt_value->p_value[1]);
            gs_control_point_info.len = 2;
        } break;
        case BLE_CPS_CYCLING_POWER_CONTROL_POINT_OP_CODES_REQUEST_CHAIN_LENGTH:
        {
        } break;
        case BLE_CPS_CYCLING_POWER_CONTROL_POINT_OP_CODES_SET_CHAIN_WEIGHT:
        {
            BT_UNPACK_LE_2_BYTE(&gs_control_point_info.param.chain_weight, &p_gatt_value->p_value[1]);
            gs_control_point_info.len = 2; 
        } break;
        case BLE_CPS_CYCLING_POWER_CONTROL_POINT_OP_CODES_REQUEST_CHAIN_WEIGHT:
        {
        } break;
        case BLE_CPS_CYCLING_POWER_CONTROL_POINT_OP_CODES_SET_SPAN_LENGTH:
        {
            BT_UNPACK_LE_2_BYTE(&gs_control_point_info.param.span_length, &p_gatt_value->p_value[1]);
            gs_control_point_info.len = 2;
        } break;
        case BLE_CPS_CYCLING_POWER_CONTROL_POINT_OP_CODES_REQUEST_SPAN_LENGTH:
        {
        } break;
        case BLE_CPS_CYCLING_POWER_CONTROL_POINT_OP_CODES_START_OFFSET_COMPENSATION:
        {
            if (p_gatt_value->value_len > 1)
            {
                gs_invalid_param_received = true;
            }
        } break;
        case BLE_CPS_CYCLING_POWER_CONTROL_POINT_OP_CODES_MASK_CYCLING_POWER_MEASUREMENT_CHARACTERISTIC_CONTENT:
        {
            BT_UNPACK_LE_2_BYTE(&gs_control_point_info.param.content_settings_cp_mesurmnt, &p_gatt_value->p_value[1]);
            gs_control_point_info.len = 2;
        } break;
        default:
        {
            if (gs_control_point_info.opcode == 0x00 ||
               (gs_control_point_info.opcode >= BLE_CPS_CP_CONTROL_POINT_OP_CODES_RESERVED_FOR_FUTURE_USE_START1 &&
                gs_control_point_info.opcode <= BLE_CPS_CP_CONTROL_POINT_OP_CODES_RESERVED_FOR_FUTURE_USE_END1) ||
               (gs_control_point_info.opcode >= BLE_CPS_CP_CONTROL_POINT_OP_CODES_RESERVED_FOR_FUTURE_USE_START2
                #if BLE_CPS_CP_CONTROL_POINT_OP_CODES_RESERVED_FOR_FUTURE_USE_END2 != 0xFF
                && gs_control_point_info.opcode <= BLE_CPS_CP_CONTROL_POINT_OP_CODES_RESERVED_FOR_FUTURE_USE_END2
                #endif
                ))
            {
                gs_op_code_not_supported = true;
                if (!gs_op_code_not_supported_event)
                {
                    gs_op_code_not_supported_event = true;
                    return BLE_ERR_UNSUPPORTED;
                }
                else
                {
                    gs_op_code_not_supported_event = false;
                    return BLE_ERR_UNSUPPORTED;

                }

            }
        } break;
    }

    p_app_value->opcode = gs_control_point_info.opcode;
    p_app_value->req_param.cumultive_value = gs_control_point_info.param.cumultive_value;
    p_app_value->req_param.sensor_location = gs_control_point_info.param.sensor_location;
    p_app_value->req_param.crank_length    = gs_control_point_info.param.crank_length;
    p_app_value->req_param.chain_length    = gs_control_point_info.param.chain_length;
    p_app_value->req_param.chain_weight    = gs_control_point_info.param.chain_weight;
    p_app_value->req_param.span_length     = gs_control_point_info.param.span_length;
    p_app_value->req_param.content_settings_cp_mesurmnt = gs_control_point_info.param.content_settings_cp_mesurmnt;

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: evt_write_req_cycling_power_control_point
 * Description  : This function handles the Cycling Power Control Point characteristic write request event.
 * Arguments    : conn_hdl - connection handle
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : none
 **********************************************************************************************************************/
static void evt_write_req_cycling_power_control_point(uint16_t conn_hdl, st_ble_gatt_value_t *p_gatt_value)
{
    ble_status_t ret;
    st_ble_cps_cp_control_point_request_t app_value;

    /*gs_cp_control_point_in_progress = true;*/

    uint16_t cli_cnfg;
    get_cli_cnfg(conn_hdl, BLE_CPS_CP_CLI_CNFG_DESC_HDL, &cli_cnfg);
    if ((cli_cnfg & BLE_GATTS_CLI_CNFG_INDICATION) == 0)
    {
        R_BLE_GATTS_SendErrRsp(BLE_ERR_GATT_CCCD_IMPROPERLY_CFG);
        return;
    }

    gs_control_point_info.opcode   = p_gatt_value->p_value[0];
    gs_control_point_info.conn_hdl = conn_hdl;

    ret = decode_cycling_power_control_point(&app_value, p_gatt_value);

    st_ble_cps_evt_data_t evt_data = {
        .conn_hdl  = conn_hdl,
        .param_len = sizeof(app_value),
        .p_param   = &app_value,
    };

    gs_cps_cb(BLE_CPS_EVENT_CYCLING_POWER_CONTROL_POINT_WRITE_REQ, ret, &evt_data);
}


/***********************************************************************************************************************
 * Function Name: cps_gatt_db_cb
 * Description  : Callback function for Cycling Power GATT Server events.
 * Arguments    : conn_hdl - handle to the connection
 *                p_params - pointer to GATTS db parameter
 * Return Value : none
 **********************************************************************************************************************/
static void cps_gatts_db_cb(uint16_t conn_hdl, st_ble_gatts_db_params_t *p_params) // @suppress("Function length")
{
    switch (p_params->db_op)
    {
        /* TODO: Usually read request is not needed to notify to the application, if so please remove this case. */
        case BLE_GATTS_OP_CHAR_PEER_READ_REQ:
        {
            if (BLE_CPS_FEAT_VAL_HDL == p_params->attr_hdl)
            {
                st_ble_cps_evt_data_t evt_data = {
                    .conn_hdl  = conn_hdl,
                    .param_len = 0,
                    .p_param   = NULL,
                };
                gs_cps_cb(BLE_CPS_EVENT_CYCLING_POWER_FEATURE_READ_REQ, BLE_SUCCESS, &evt_data);
            }
            else if (BLE_CPS_SENSOR_LOC_VAL_HDL == p_params->attr_hdl)
            {
                st_ble_cps_evt_data_t evt_data = {
                    .conn_hdl  = conn_hdl,
                    .param_len = 0,
                    .p_param   = NULL,
                };
                gs_cps_cb(BLE_CPS_EVENT_SENSOR_LOCATION_READ_REQ, BLE_SUCCESS, &evt_data);
            }
            else
            {
                /* Do nothing. */
            }
        } break;

        case BLE_GATTS_OP_CHAR_PEER_WRITE_REQ:
        {
            if (BLE_CPS_CP_VAL_HDL == p_params->attr_hdl)
            {
                evt_write_req_cycling_power_control_point(conn_hdl, &p_params->value);
            }
        } break;

        case BLE_GATTS_OP_CHAR_PEER_CLI_CNFG_WRITE_REQ:
        {
            uint16_t cli_cnfg;

            st_ble_cps_evt_data_t evt_data = {
                .conn_hdl  = conn_hdl,
                .param_len = 0,
                .p_param   = NULL,
            };

            BT_UNPACK_LE_2_BYTE(&cli_cnfg, p_params->value.p_value);

            if (BLE_CPS_MEAS_CLI_CNFG_DESC_HDL == p_params->attr_hdl)
            {
                if (BLE_GATTS_CLI_CNFG_NOTIFICATION == cli_cnfg)
                {
                    gs_cps_cb(BLE_CPS_EVENT_CYCLING_POWER_MEASUREMENT_CLI_CNFG_ENABLED, BLE_SUCCESS, &evt_data);
                }
                else
                {
                    gs_cps_cb(BLE_CPS_EVENT_CYCLING_POWER_MEASUREMENT_CLI_CNFG_DISABLED, BLE_SUCCESS, &evt_data);
                }
            }
            else if (BLE_CPS_VECTOR_CLI_CNFG_DESC_HDL == p_params->attr_hdl)
            {
                if (BLE_GATTS_CLI_CNFG_NOTIFICATION == cli_cnfg)
                {
                    gs_cps_cb(BLE_CPS_EVENT_CYCLING_POWER_VECTOR_CLI_CNFG_ENABLED, BLE_SUCCESS, &evt_data);
                }
                else
                {
                    gs_cps_cb(BLE_CPS_EVENT_CYCLING_POWER_VECTOR_CLI_CNFG_DISABLED, BLE_SUCCESS, &evt_data);
                }
            }
            else if (BLE_CPS_CP_CLI_CNFG_DESC_HDL == p_params->attr_hdl)
            {
                if (BLE_GATTS_CLI_CNFG_INDICATION == cli_cnfg)
                {
                    gs_cps_cb(BLE_CPS_EVENT_CYCLING_POWER_CONTROL_POINT_CLI_CNFG_ENABLED, BLE_SUCCESS, &evt_data);
                }
                else
                {
                    gs_cps_cb(BLE_CPS_EVENT_CYCLING_POWER_CONTROL_POINT_CLI_CNFG_DISABLED, BLE_SUCCESS, &evt_data);
                }
            }
            else
            {
                /* Do nothing. */
            }
        } break;

        default:
        {
            /* Do nothing. */
        } break;
    }
}

/***********************************************************************************************************************
 * Function Name: cp_gatts_cb
 * Description  : Callback function for the GATT Server events.
 * Arguments    : type - event id
 *                result - ble status
 *                p_data - pointer to the event data
 * Return Value : none
 **********************************************************************************************************************/
static void cps_gatts_cb(uint16_t type, ble_status_t result, st_ble_gatts_evt_data_t *p_data)
{
    switch (type)
    {
        case BLE_GATTS_EVENT_DB_ACCESS_IND:
        {
            st_ble_gatts_db_access_evt_t *p_db_access_evt_param =
                (st_ble_gatts_db_access_evt_t *)p_data->p_param;

            cps_gatts_db_cb(p_data->conn_hdl, p_db_access_evt_param->p_params);
        } break;

        case BLE_GATTS_EVENT_HDL_VAL_CNF:
        {
            st_ble_gatts_cfm_evt_t *p_cfm_evt_param =
                (st_ble_gatts_cfm_evt_t *)p_data->p_param;

            if (BLE_CPS_CP_VAL_HDL == p_cfm_evt_param->attr_hdl)
            {
                st_ble_cps_evt_data_t evt_data = {
                    .conn_hdl  = p_data->conn_hdl,
                    .param_len = 0,
                    .p_param   = NULL,
                };
                gs_cps_cb(BLE_CPS_EVENT_CYCLING_POWER_CONTROL_POINT_HDL_VAL_CNF, result, &evt_data);
            }
        } break;

        default:
        {
            /* Do nothing. */
        } break;
    }
}

ble_status_t R_BLE_CPS_Init(const st_ble_cps_init_param_t *p_param) // @suppress("API function naming")
{
    if (NULL == p_param)
    {
        return BLE_ERR_INVALID_PTR;
    }

    if (NULL == p_param->cb)
    {
        return BLE_ERR_INVALID_ARG;
    }

    R_BLE_GATTS_RegisterCb(cps_gatts_cb, 1);

    gs_cps_cb = p_param->cb;

    return BLE_SUCCESS;
}

ble_status_t R_BLE_CPS_Connect(uint16_t conn_hdl, const st_ble_cps_connect_param_t *p_param) // @suppress("API function naming")
{
    if (BLE_GAP_INVALID_CONN_HDL == conn_hdl)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (NULL != p_param)
    {
        /* TODO: Add service specific connection settings here. */
        set_cli_cnfg(conn_hdl, BLE_CPS_MEAS_CLI_CNFG_DESC_HDL, p_param->cycling_power_measurement_cli_cnfg);
        set_cli_cnfg(conn_hdl, BLE_CPS_VECTOR_CLI_CNFG_DESC_HDL, p_param->cycling_power_vector_cli_cnfg);
        set_cli_cnfg(conn_hdl, BLE_CPS_CP_CLI_CNFG_DESC_HDL, p_param->cycling_power_control_point_cli_cnfg);
    }

    return BLE_SUCCESS;
}

ble_status_t R_BLE_CPS_Disconnect(uint16_t conn_hdl, st_ble_cps_disconnect_param_t *p_param) // @suppress("API function naming")
{
    if (BLE_GAP_INVALID_CONN_HDL == conn_hdl)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (NULL != p_param)
    {
        /* TODO: Add service specific disconnect settings here. */
        get_cli_cnfg(conn_hdl, BLE_CPS_MEAS_CLI_CNFG_DESC_HDL, &p_param->cycling_power_measurement_cli_cnfg);
        get_cli_cnfg(conn_hdl, BLE_CPS_VECTOR_CLI_CNFG_DESC_HDL, &p_param->cycling_power_vector_cli_cnfg);
        get_cli_cnfg(conn_hdl, BLE_CPS_CP_CLI_CNFG_DESC_HDL, &p_param->cycling_power_control_point_cli_cnfg);
    }

    return BLE_SUCCESS;
}

ble_status_t R_BLE_CPS_NotifyCyclingPowerMeasurement(uint16_t conn_hdl, const st_ble_cps_cycling_power_measurement_t *p_app_value) // @suppress("API function naming")
{
    ble_status_t ret;
    uint16_t cli_cnfg;

    if (NULL == p_app_value)
    {
        return BLE_ERR_INVALID_PTR;
    }

    ret = get_cli_cnfg(conn_hdl, BLE_CPS_MEAS_CLI_CNFG_DESC_HDL, &cli_cnfg);

    if (BLE_SUCCESS != ret)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if ((cli_cnfg & BLE_GATTS_CLI_CNFG_NOTIFICATION) == 0x0000)
    {
        return BLE_ERR_INVALID_STATE;
    }

    /* TODO: Add parameter check, if required. */

    uint8_t byte_value[BLE_CPS_MEAS_LEN] = { 0 };

    st_ble_gatt_hdl_value_pair_t ntf_data = {
        .attr_hdl        = BLE_CPS_MEAS_VAL_HDL,
        .value.p_value   = byte_value,
        .value.value_len = BLE_CPS_MEAS_LEN,
    };
    ret = encode_cycling_power_measurement(p_app_value, &ntf_data.value);
    if (BLE_SUCCESS != ret)
    {
        return BLE_ERR_INVALID_DATA;
    }

    return R_BLE_GATTS_Notification(conn_hdl, &ntf_data);
}

ble_status_t R_BLE_CPS_GetCyclingPowerFeature(uint32_t *p_app_value) // @suppress("API function naming")
{
    st_ble_gatt_value_t gatt_value;
    ble_status_t ret;

    if (NULL == p_app_value)
    {
        return BLE_ERR_INVALID_PTR;
    }

    ret = R_BLE_GATTS_GetAttr(BLE_GAP_INVALID_CONN_HDL, BLE_CPS_FEAT_VAL_HDL, &gatt_value);

    if (BLE_SUCCESS == ret)
    {
        BT_UNPACK_LE_4_BYTE(p_app_value, gatt_value.p_value);
    }

    return ret;
}

ble_status_t R_BLE_CPS_SetCyclingPowerFeature(uint32_t app_value) // @suppress("API function naming")
{
    uint8_t byte_value[BLE_CPS_FEAT_LEN] = { 0 };
    BT_PACK_LE_4_BYTE(byte_value, &app_value);

    st_ble_gatt_value_t gatt_value = {
        .p_value   = byte_value,
        .value_len = sizeof(app_value),
    };

    return R_BLE_GATTS_SetAttr(BLE_GAP_INVALID_CONN_HDL, BLE_CPS_FEAT_VAL_HDL, &gatt_value);
}

ble_status_t R_BLE_CPS_GetSensorLocation(uint8_t *p_app_value) // @suppress("API function naming")
{
    st_ble_gatt_value_t gatt_value;
    ble_status_t ret;

    if (NULL == p_app_value)
    {
        return BLE_ERR_INVALID_PTR;
    }

    ret = R_BLE_GATTS_GetAttr(BLE_GAP_INVALID_CONN_HDL, BLE_CPS_SENSOR_LOC_VAL_HDL, &gatt_value);

    if (BLE_SUCCESS == ret)
    {
        BT_UNPACK_LE_1_BYTE(p_app_value, gatt_value.p_value);
    }

    return ret;
}

ble_status_t R_BLE_CPS_SetSensorLocation(uint8_t app_value) // @suppress("API function naming")
{
    uint8_t byte_value[BLE_CPS_SENSOR_LOC_LEN] = { 0 };
    BT_PACK_LE_1_BYTE(byte_value, &app_value);

    st_ble_gatt_value_t gatt_value = {
        .p_value   = byte_value,
        .value_len = sizeof(app_value),
    };

    return R_BLE_GATTS_SetAttr(BLE_GAP_INVALID_CONN_HDL, BLE_CPS_SENSOR_LOC_VAL_HDL, &gatt_value);
}

ble_status_t R_BLE_CPS_NotifyCyclingPowerVector(uint16_t conn_hdl, const st_ble_cps_cycling_power_vector_t *p_app_value) // @suppress("API function naming")
{
    ble_status_t ret;
    uint16_t cli_cnfg;

    if (NULL == p_app_value)
    {
        return BLE_ERR_INVALID_PTR;
    }

    ret = get_cli_cnfg(conn_hdl, BLE_CPS_VECTOR_CLI_CNFG_DESC_HDL, &cli_cnfg);

    if (BLE_SUCCESS != ret)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if ((cli_cnfg & BLE_GATTS_CLI_CNFG_NOTIFICATION) == 0x0000)
    {
        return BLE_ERR_INVALID_STATE;
    }

    uint8_t byte_value[BLE_CPS_VECTOR_LEN] = { 0 };

    st_ble_gatt_hdl_value_pair_t ntf_data = {
        .attr_hdl        = BLE_CPS_VECTOR_VAL_HDL,
        .value.p_value   = byte_value,
        .value.value_len = BLE_CPS_VECTOR_LEN,
    };
    ret = encode_cycling_power_vector(p_app_value, &ntf_data.value);
    if (BLE_SUCCESS != ret)
    {
        return BLE_ERR_INVALID_DATA;
    }

    return R_BLE_GATTS_Notification(conn_hdl, &ntf_data);
}

ble_status_t R_BLE_CPS_IndicateCyclingPowerControlPoint(uint16_t conn_hdl, const st_ble_cps_cp_control_point_response_t *p_app_value) // @suppress("API function naming")
{
    ble_status_t ret;
    uint16_t cli_cnfg;

    if (NULL == p_app_value)
    {
        return BLE_ERR_INVALID_PTR;
    }

    ret = get_cli_cnfg(conn_hdl, BLE_CPS_CP_CLI_CNFG_DESC_HDL, &cli_cnfg);
    if (BLE_SUCCESS != ret)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if ((cli_cnfg & BLE_GATTS_CLI_CNFG_INDICATION) == 0x0000)
    {
        return BLE_ERR_INVALID_STATE;
    }

    uint8_t byte_value[BLE_CPS_CP_LEN] = { 0 };

    st_ble_gatt_hdl_value_pair_t ind_data = {
        .attr_hdl        = BLE_CPS_CP_VAL_HDL,
        .value.p_value   = byte_value,
        .value.value_len = BLE_CPS_CP_LEN,
    };
    ret = encode_cycling_power_control_point(p_app_value, &ind_data.value);
#if 1
    if ( !((BLE_SUCCESS == ret) || (BLE_ERR_UNSUPPORTED == ret)) )
    {
        return BLE_ERR_INVALID_DATA;
    }
#else
    if (BLE_SUCCESS != ret)
    {
        return BLE_ERR_INVALID_DATA;
    }
#endif

    return R_BLE_GATTS_Indication(conn_hdl, &ind_data);
}

uint32_t R_BLE_CPS_GetVersion(void) // @suppress("API function naming")
{
    uint32_t version;

    version = ((BLE_CPS_PRV_VERSION_MAJOR << 16) | (BLE_CPS_PRV_VERSION_MINOR << 8));

    return version;
}

