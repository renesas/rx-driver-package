/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_rscc.h
 * Version : 1.0
 * Description : This module implements Running Speed and Cadence Service Client.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 22.03.2019 1.00 First Release
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @file
 * @defgroup rscc Running Speed and Cadence Service Client
 * @{
 * @ingroup profile
 * @brief This file provides APIs to interface Running Speed and Cadence Service Client.
 **********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_ble_rx23w_if.h"

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
#ifndef R_BLE_RSCC_H
#define R_BLE_RSCC_H

/*******************************************************************************************************************//**
 * @brief Procedure Already in Progress error code.
***********************************************************************************************************************/
#define BLE_RSCC_PROCEDURE_ALREADY_IN_PROGRESS                                          (BLE_ERR_GROUP_GATT | 0x80)

/*******************************************************************************************************************//**
 * @brief Client Characteristic Configuration descriptor improperly configured error code.
***********************************************************************************************************************/
#define BLE_RSCC_CLIENT_CHARACTERISTIC_CONFIGURATION_DESCRIPTOR_IMPROPERLY_CONFIGURED   (BLE_ERR_GROUP_GATT | 0x81)

/*******************************************************************************************************************//**
 * @brief Write Request Rejected error code.
***********************************************************************************************************************/
#define BLE_RSCC_WRITE_REQUEST_REJECTED                                                 (BLE_ERR_GROUP_GATT | 0x82)

/*******************************************************************************************************************//**
 * @brief Cumulative_value length .
***********************************************************************************************************************/
#define BLE_RSCC_SC_CONTROL_POINT_CUMULATIVE_VALUE_LEN                                  (17)

/*******************************************************************************************************************//**
 * @brief Response Parameter length .
***********************************************************************************************************************/
#define BLE_RSCC_SC_CONTROL_POINT_RESPONSE_PARAMETER_LEN                                (17)

/*******************************************************************************************************************//**
 * @brief Max No of Supported Sensor Locations
***********************************************************************************************************************/
#define BLE_RSCC_MAX_SENSOR_LOCATIONS_SUPPORTED                                         (17)

/*******************************************************************************************************************//**
 * @brief Running Speed and Cadence Service Client event data.
***********************************************************************************************************************/
typedef struct
{
    uint16_t  conn_hdl;                        /**< Connection handle */
    uint16_t  param_len;                       /**< Event parameter length */
    void     *p_param;                         /**< Event parameter */
} st_ble_rscc_evt_data_t;

/*******************************************************************************************************************//**
 * @brief Running Speed and Cadence Service Client event callback.
***********************************************************************************************************************/
typedef void (*ble_rscc_app_cb_t)(uint16_t type, ble_status_t result, st_ble_rscc_evt_data_t *p_data);

/*******************************************************************************************************************//**
 * @brief Running Speed and Cadence Service Client event type.
***********************************************************************************************************************/
typedef enum 
{
    BLE_RSCC_EVENT_RSC_MEASUREMENT_HDL_VAL_NTF,  /**< RSC Measurement characteristic handle value notification event */
    BLE_RSCC_EVENT_RSC_FEATURE_READ_RSP,         /**< RSC Feature characteristic read response event */
    BLE_RSCC_EVENT_SENSOR_LOCATION_READ_RSP,     /**< Sensor Location characteristic read response event */
    BLE_RSCC_EVENT_SC_CONTROL_POINT_HDL_VAL_IND, /**< SC Control Point characteristic handle value indication event */
    BLE_RSCC_EVENT_SC_CONTROL_POINT_WRITE_RSP,   /**< SC Control Point characteristic write response event */
    BLE_RSCC_EVENT_CLI_CNFG_WRITE_RSP,           /**< Cli Cnfig write response */
    BLE_RSCC_EVENT_ERROR_RSP,                    /**< error response */
} e_ble_rscc_event_t;

/*******************************************************************************************************************//**
 * @brief Sensor Location enumeration.
***********************************************************************************************************************/
typedef enum 
{
    BLE_RSCC_SENSOR_LOCATION_SENSOR_LOCATION_OTHER             = 0, /**< Sensor Location - Other */
    BLE_RSCC_SENSOR_LOCATION_SENSOR_LOCATION_TOP_OF_SHOE       = 1, /**< Sensor Location - Top of Shoe */
    BLE_RSCC_SENSOR_LOCATION_SENSOR_LOCATION_IN_SHOE           = 2, /**< Sensor Location - In Shoe */
    BLE_RSCC_SENSOR_LOCATION_SENSOR_LOCATION_HIP               = 3, /**< Sensor Location - Hip */
    BLE_RSCC_SENSOR_LOCATION_SENSOR_LOCATION_FRONT_WHEEL       = 4, /**< Sensor Location - Front Wheel */
    BLE_RSCC_SENSOR_LOCATION_SENSOR_LOCATION_LEFT_CRANK        = 5, /**< Sensor Location - Left Crank */
    BLE_RSCC_SENSOR_LOCATION_SENSOR_LOCATION_RIGHT_CRANK       = 6, /**< Sensor Location - Right Crank */
    BLE_RSCC_SENSOR_LOCATION_SENSOR_LOCATION_LEFT_PEDAL        = 7, /**< Sensor Location - Left Pedal */
    BLE_RSCC_SENSOR_LOCATION_SENSOR_LOCATION_RIGHT_PEDAL       = 8, /**< Sensor Location - Right Pedal */
    BLE_RSCC_SENSOR_LOCATION_SENSOR_LOCATION_FRONT_HUB         = 9, /**< Sensor Location - Front Hub */
    BLE_RSCC_SENSOR_LOCATION_SENSOR_LOCATION_REAR_DROPOUT      = 10,/**< Sensor Location - Rear Dropout */
    BLE_RSCC_SENSOR_LOCATION_SENSOR_LOCATION_CHAINSTAY         = 11,/**< Sensor Location - Chainstay */
    BLE_RSCC_SENSOR_LOCATION_SENSOR_LOCATION_REAR_WHEEL        = 12,/**< Sensor Location - Rear Wheel */
    BLE_RSCC_SENSOR_LOCATION_SENSOR_LOCATION_REAR_HUB          = 13,/**< Sensor Location - Rear Hub */
    BLE_RSCC_SENSOR_LOCATION_SENSOR_LOCATION_CHEST             = 14,/**< Sensor Location - Chest */
    BLE_RSCC_SENSOR_LOCATION_SENSOR_LOCATION_SPIDER            = 15,/**< Sensor Location - Spider */
    BLE_RSCC_SENSOR_LOCATION_SENSOR_LOCATION_CHAIN_RING        = 16,/**< Sensor Location - Chain Ring */
} e_ble_rscc_sensor_location_t;

/*******************************************************************************************************************//**
 * @brief Op Code enumeration.
***********************************************************************************************************************/
typedef enum
{      
    BLE_RSCC_SC_CONTROL_POINT_OP_CODE_RESERVED_FOR_FUTURE_USE            = 0, /**< Reserved for Future Use */
    BLE_RSCC_SC_CONTROL_POINT_OP_CODE_SET_CUMULATIVE_VALUE               = 1, /**< Set Cumulative Value */
    BLE_RSCC_SC_CONTROL_POINT_OP_CODE_START_SENSOR_CALIBRATION           = 2, /**< Start Sensor Calibration */
    BLE_RSCC_SC_CONTROL_POINT_OP_CODE_UPDATE_SENSOR_LOCATION             = 3, /**< Update the Sensor Location  */
    BLE_RSCC_SC_CONTROL_POINT_OP_CODE_REQUEST_SUPPORTED_SENSOR_LOCATIONS = 4, /**< Send list of supported sensor location 
                                                                              values */
    BLE_RSCC_SC_CONTROL_POINT_OP_CODE_RESPONSE_CODE                      = 16,/**< Response Code */
} e_ble_rscc_sc_control_point_op_code_t;

/*******************************************************************************************************************//**
 * @brief Response Value enumeration.
***********************************************************************************************************************/
typedef enum 
{
    BLE_RSCC_SC_CONTROL_POINT_RESPONSE_VALUE_RESERVED_FOR_FUTURE_USE  = 0,  /**< Reserved for Future Use */
    BLE_RSCC_SC_CONTROL_POINT_RESPONSE_VALUE_SUCCESS                  = 1,  /**< Success */
    BLE_RSCC_SC_CONTROL_POINT_RESPONSE_VALUE_OP_CODE_NOT_SUPPORTED    = 2,  /**< Op code not supported */
    BLE_RSCC_SC_CONTROL_POINT_RESPONSE_VALUE_INVALID_PARAMETER        = 3,  /**< Invalid parameter */
    BLE_RSCC_SC_CONTROL_POINT_RESPONSE_VALUE_OPERATION_FAILED         = 4,  /**< Operation Failed  */
} e_ble_rscc_sc_control_point_response_value_t;

/*******************************************************************************************************************//**
 * @brief Running Speed and Cadence Service attribute handles.
***********************************************************************************************************************/
typedef struct
{
    st_ble_gatt_hdl_range_t service_range;                 /**< Running Speed and Cadence Service range */
    uint16_t                rsc_measurement_char_val_hdl;  /**< RSC Measurement characteristic value handle */
    uint16_t                rsc_measurement_cli_cnfg_hdl;  /**< RSC Measurement characteristic Client Characteristic 
                                                           Configuration descriptor handle */
    uint16_t                rsc_feature_char_val_hdl;      /**< RSC Feature characteristic value handle */
    uint16_t                sensor_location_char_val_hdl;  /**< Sensor Location characteristic value handle */
    uint16_t                sc_control_point_char_val_hdl; /**< SC Control Point characteristic value handle */
    uint16_t                sc_control_point_cli_cnfg_hdl; /**< SC Control Point characteristic Client Characteristic 
                                                           Configuration descriptor handle */
} st_ble_rscc_hdls_t;

/*******************************************************************************************************************//**
 * @brief Running Speed and Cadence Service initialization parameters.
***********************************************************************************************************************/
typedef struct 
{
    ble_rscc_app_cb_t cb;                                  /**< Running Speed and Cadence Service Client event handler */
} st_ble_rscc_init_param_t;

/*******************************************************************************************************************//**
 * @brief Running Speed and Cadence Service Client connection parameters.
***********************************************************************************************************************/
typedef struct 
{
    st_ble_rscc_hdls_t *p_hdls;                           /**< Running Speed and Cadence Service handles */
} st_ble_rscc_connect_param_t;

/*******************************************************************************************************************//**
 * @brief Running Speed and Cadence Service disconnection parameters.
***********************************************************************************************************************/
typedef struct 
{
    st_ble_rscc_hdls_t *p_hdls;                           /**< Running Speed and Cadence Service handles */
} st_ble_rscc_disconnect_param_t;

/*******************************************************************************************************************//**
 * @brief RSC Measurement characteristic parameters.
***********************************************************************************************************************/
typedef struct 
{
    bool     is_instantaneous_stride_length_present; /**< Instantaneous stride length field present or not */
    bool     is_total_distance_present;              /**< Total distance field present or not */
    bool     is_running;                             /**< walking or running */
    uint16_t instantaneous_speed;                    /**< Instantaneous Speed value */
    uint8_t  instantaneous_cadence;                  /**< Instantaneous Cadence value */
    uint32_t total_distance;                         /**< Total Distance (Cumulative) value */
    uint16_t instantaneous_stride_length;            /**< Instantaneous Stride Length value */
} st_ble_rscc_rsc_measurement_t;

/*******************************************************************************************************************//**
 * @brief RSC Feature characteristic parameters.
***********************************************************************************************************************/
typedef struct
{
    bool is_instantaneous_stride_length_measurement_supported; /**< Instantaneous stride length measurement supported or 
                                                               not */
    bool is_total_distance_measurement_supported;              /**< Total Distance measurement supported or not */
    bool is_walking_or_running_status_supported;               /**< Walking or running Status Bits supported or not */
    bool is_sensor_calibration_procedure_supported;            /**< Sensor Calibration Procedure supported or not */
    bool is_multiple_sensor_location_supported;                /**< Multiple Sensor Locations supported or not */
} st_ble_rscc_rsc_feature_t;

/*******************************************************************************************************************//**
 * @brief SC Control Point characteristic parameters.
***********************************************************************************************************************/
typedef struct 
{
    uint8_t  op_code;                                                              /**< Op Code */
    uint32_t cumulative_value;                                                     /**< Cumulative Value */
    uint8_t  sensor_location_value;                                                /**< Sensor Location Value */
    uint8_t  response_code;                                                        /**< Response Code */
    uint8_t  request_op_code;                                                      /**< Request Op Code */
    uint8_t  response_value;                                                       /**< Response Value*/
    uint8_t  response_parameter[BLE_RSCC_SC_CONTROL_POINT_RESPONSE_PARAMETER_LEN]; /**< Response Parameter value */
    uint8_t  no_of_supported_sensor_locations;                                   /**< No of sensor locations supported */
} st_ble_rscc_sc_control_point_t;

/***********************************************************************************************************************
Exported global variables (to be accessed by other files)
***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @brief Running Speed and Cadence Service UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_RSCC_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief RSC Measurement characteristic UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_RSCC_RSC_MEASUREMENT_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief RSC Feature characteristic UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_RSCC_RSC_FEATURE_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Sensor Location characteristic UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_RSCC_SENSOR_LOCATION_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief SC Control Point characteristic UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_RSCC_SC_CONTROL_POINT_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/***********************************************************************************************************************
Exported global functions (to be accessed by other files)
***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @brief     Initialize Running Speed and Cadence Service  Client.
 * @details   This function shall be called once at startup.
 * @param[in] p_param Pointer to Running Speed and Cadence Service Client initialization parameters.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_RSCC_Init(const st_ble_rscc_init_param_t *p_param);

/*******************************************************************************************************************//**
 * @brief     Perform Running Speed and Cadence Service Client connection settings.
 * @details   This function shall be called on each connection establishment.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_param  Pointer to Connection parameters.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_RSCC_Connect(uint16_t conn_hdl, const st_ble_rscc_connect_param_t *p_param);

/*******************************************************************************************************************//**
 * @brief     Retrieve Running Speed and Cadence Service Client connection specific settings before disconnection.
 * @details   This function shall be called on each disconnection.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_param  Pointer to Disconnection parameters.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_RSCC_Disconnect(uint16_t conn_hdl, st_ble_rscc_disconnect_param_t *p_param);

/*******************************************************************************************************************//**
 * @brief     Set RSC Measurement characteristic cli cnfg.
 * @param[in] conn_hdl Connection handle.
 * @param[in] cli_cnfg RSC Measurement characteristic cli cnfg to set.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_RSCC_SetRscMeasurementCliCnfg(uint16_t conn_hdl, uint16_t cli_cnfg);

/*******************************************************************************************************************//**
 * @brief      Read RSC Feature characteristic value from remote GATT database.
 * @param[in]  conn_hdl Connection handle.
 * @return     @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_RSCC_ReadRscFeature(uint16_t conn_hdl);

/*******************************************************************************************************************//**
 * @brief      Read Sensor Location characteristic value from remote GATT database.
 * @param[in]  conn_hdl Connection handle.
 * @return     @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_RSCC_ReadSensorLocation(uint16_t conn_hdl);

/*******************************************************************************************************************//**
 * @brief     Write SC Control Point characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] p_app_value Pointer to SC Control Point characteristic value to write.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_RSCC_WriteScControlPoint(uint16_t conn_hdl, const st_ble_rscc_sc_control_point_t *p_app_value);

/*******************************************************************************************************************//**
 * @brief     Set SC Control Point characteristic cli cnfg.
 * @param[in] conn_hdl Connection handle.
 * @param[in] cli_cnfg SC Control Point characteristic cli cnfg to set.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_RSCC_SetScControlPointCliCnfg(uint16_t conn_hdl, uint16_t cli_cnfg);

/***********************************************************************************************************************
 * @brief      Callback function for the Running Speed and Cadence Discovery events.
 * @param[out] conn_hdl Connection handle.
 * @param[out] idx      Service index used to distiguish the multiple same UUID service.
 * @param[out] type     Discovery event type
 * @param[out] p_param   Pointer to GATTC event data.
***********************************************************************************************************************/
void R_BLE_RSCC_ServDiscCb(uint16_t conn_hdl, uint8_t idx, uint16_t type, void *p_param);

/*******************************************************************************************************************//**
 * @brief     Return version of the RSCC service client.
 * @return    version
***********************************************************************************************************************/
uint32_t R_BLE_RSCC_GetVersion(void);

#endif /* R_BLE_RSCC_H */

/** @} */
