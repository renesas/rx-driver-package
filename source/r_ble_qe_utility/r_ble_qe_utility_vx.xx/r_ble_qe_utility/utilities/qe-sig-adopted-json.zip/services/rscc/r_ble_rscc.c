/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_rscc.c
 * Version : 1.0
 * Description : This module implements Running Speed and Cadence Service Client.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 22.03.2019 1.00 First Release
 ***********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <string.h>
#include "r_ble_rx23w_if.h"
#include "r_ble_rscc.h"
#include "discovery/r_ble_disc.h"

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/

/* Version number */
#define BLE_RSCC_PRV_VERSION_MAJOR                                                           (1)
#define BLE_RSCC_PRV_VERSION_MINOR                                                           (0)

/*******************************************************************************************************************//**
 * @brief RSC Measurement characteristic value length.
***********************************************************************************************************************/
#define BLE_RSCC_PRV_RSC_MEASUREMENT_LEN                                                     (10)

/*******************************************************************************************************************//**
 * @brief RSC Feature characteristic value length.
***********************************************************************************************************************/
#define BLE_RSCC_PRV_RSC_FEATURE_LEN                                                         (2)

/*******************************************************************************************************************//**
 * @brief Sensor Location characteristic value length.
***********************************************************************************************************************/
#define BLE_RSCC_PRV_SENSOR_LOCATION_LEN                                                     (1)

/*******************************************************************************************************************//**
 * @brief SC Control Point characteristic value length.
***********************************************************************************************************************/
#define BLE_RSCC_PRV_SC_CONTROL_POINT_LEN                                                    (20)

/*******************************************************************************************************************//**
 * @brief Procedure Already in Progress error code.
***********************************************************************************************************************/
#define BLE_RSCC_PRV_PROCEDURE_ALREADY_IN_PROGRESS                                           (BLE_ERR_GROUP_GATT | 0x80)
 
/*******************************************************************************************************************//**
 * @brief Client Characteristic Configuration descriptor improperly configured error code.
***********************************************************************************************************************/
#define BLE_RSCC_PRV_CLIENT_CHARACTERISTIC_CONFIGURATION_DESCRIPTOR_IMPROPERLY_CONFIGURED    (BLE_ERR_GROUP_GATT | 0x81)

/***********************************************************************************************************************
 * @brief Instantaneous Stride Length Present bit.
***********************************************************************************************************************/
#define BLE_RSCC_PRV_RSC_MEASUREMENT_FLAGS_INSTANTANEOUS_STRIDE_LENGTH_PRESENT               (1 << 0)

/*******************************************************************************************************************//**
 * @brief Total Distance Present bit.
***********************************************************************************************************************/
#define BLE_RSCC_PRV_RSC_MEASUREMENT_FLAGS_TOTAL_DISTANCE_PRESENT                            (1 << 1)

/*******************************************************************************************************************//**
 * @brief Walking or Running Status bits.
***********************************************************************************************************************/
#define BLE_RSCC_PRV_RSC_MEASUREMENT_FLAGS_WALKING_OR_RUNNING_STATUS_BITS                    (1 << 2)

/***********************************************************************************************************************
 * @brief Instantaneous Stride Length Measurement Supported bit.
***********************************************************************************************************************/
#define BLE_RSCC_PRV_RSC_FEATURE_INSTANTANEOUS_STRIDE_LENGTH_MEASUREMENT_SUPPORTED           (1 << 0)

/*******************************************************************************************************************//**
 * @brief Total Distance Measurement Supported bit.
***********************************************************************************************************************/
#define BLE_RSCC_PRV_RSC_FEATURE_TOTAL_DISTANCE_MEASUREMENT_SUPPORTED                        (1 << 1)

/***********************************************************************************************************************
 * @brief Walking or Running Status Supported bit.
***********************************************************************************************************************/
#define BLE_RSCC_PRV_RSC_FEATURE_WALKING_OR_RUNNING_STATUS_SUPPORTED                         (1 << 2)

/***********************************************************************************************************************
 * @brief Calibration Procedure Supported bit.
***********************************************************************************************************************/
#define BLE_RSCC_PRV_RSC_FEATURE_CALIBRATION_PROCEDURE_SUPPORTED                             (1 << 3)

/*******************************************************************************************************************//**
 * @brief Multiple Sensor Locations Supported bit.
***********************************************************************************************************************/
#define BLE_RSCC_PRV_RSC_FEATURE_MULTIPLE_SENSOR_LOCATIONS_SUPPORTED                         (1 << 4)

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/
typedef struct
{
    uint16_t           conn_hdl;
    st_ble_rscc_hdls_t hdls;
} st_rscc_peer_param_t;

/***********************************************************************************************************************
Exported global variables (to be accessed by other files)
***********************************************************************************************************************/
const uint8_t BLE_RSCC_UUID[BLE_GATT_16_BIT_UUID_SIZE]                  = { 0x14, 0x18 };
const uint8_t BLE_RSCC_RSC_MEASUREMENT_UUID[BLE_GATT_16_BIT_UUID_SIZE]  = { 0x53, 0x2A };
const uint8_t BLE_RSCC_RSC_MEASUREMENT_CLIENT_CHARACTERISTIC_CONFIGURATION_UUID[BLE_GATT_16_BIT_UUID_SIZE] =
                                                                          { 0x02, 0x29 };
const uint8_t BLE_RSCC_RSC_FEATURE_UUID[BLE_GATT_16_BIT_UUID_SIZE]      = { 0x54, 0x2A };
const uint8_t BLE_RSCC_SENSOR_LOCATION_UUID[BLE_GATT_16_BIT_UUID_SIZE]  = { 0x5D, 0x2A };
const uint8_t BLE_RSCC_SC_CONTROL_POINT_UUID[BLE_GATT_16_BIT_UUID_SIZE] = { 0x55, 0x2A };
const uint8_t BLE_RSCC_SC_CONTROL_POINT_CLIENT_CHARACTERISTIC_CONFIGURATION_UUID[BLE_GATT_16_BIT_UUID_SIZE] =
                                                                          { 0x02, 0x29 };

/***********************************************************************************************************************
Private global variables and functions
***********************************************************************************************************************/
static st_rscc_peer_param_t           gs_peer_params[7];
static ble_rscc_app_cb_t              gs_rscc_cb;

/***********************************************************************************************************************
 * Function Name: find_peer_param
 * Description  : This function finds the attribute handles for the given connection handle.
 * Arguments    : conn_hdl - handle to connection
 * Return Value : pointer to the attribute handles structure
 **********************************************************************************************************************/
static st_rscc_peer_param_t *find_peer_param(uint16_t conn_hdl)
{
    for (uint8_t i = 0; i < 7; i++)
    {
        if ((BLE_GAP_INVALID_CONN_HDL != gs_peer_params[i].conn_hdl) &&
            (gs_peer_params[i].conn_hdl == conn_hdl))
        {
            return &gs_peer_params[i];
        }
    }
    return NULL;
}

/***********************************************************************************************************************
 * Function Name: get_new_peer_param
 * Description  : This function finds the free attribute handle.
 * Arguments    : conn_hdl - handle to connection.
 * Return Value : pointer to the free attribute handles structure
 **********************************************************************************************************************/
static st_rscc_peer_param_t *get_new_peer_param(uint16_t conn_hdl)
{
    for (uint8_t i = 0; i < 7; i++)
    {
        if (BLE_GAP_INVALID_CONN_HDL == gs_peer_params[i].conn_hdl)
        {
            gs_peer_params[i].conn_hdl = conn_hdl;
            return &gs_peer_params[i];
        }
    }
    return NULL;
}

/***********************************************************************************************************************
 * Function Name: clear_peer_param
 * Description  : This function frees all the attribute handles.
 * Arguments    : p_peer - pointer to the attribute handle structure to be freed
 * Return Value : none
***********************************************************************************************************************/
static void clear_peer_param(st_rscc_peer_param_t *p_peer)
{
    if (NULL != p_peer)
    {
        p_peer->conn_hdl = BLE_GAP_INVALID_CONN_HDL;
        memset(&p_peer->hdls, 0x00, sizeof(p_peer->hdls));
    }
}

/***********************************************************************************************************************
 * Function Name: decode_rsc_measurement
 * Description  : This function converts RSC Measurement characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the RSC Measurement value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_rsc_measurement(st_ble_rscc_rsc_measurement_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t      pos = 1;
    ble_status_t ret = BLE_SUCCESS;

    if (BLE_RSCC_PRV_RSC_MEASUREMENT_LEN < p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Clear the data structure */
    memset(p_app_value, 0x00, sizeof(st_ble_rscc_rsc_measurement_t));

    /* Copy Instantaneous Speed and Instantaneous Cadence */
    BT_UNPACK_LE_2_BYTE(&p_app_value->instantaneous_speed, &p_gatt_value->p_value[pos]);
    pos += 2;

    BT_UNPACK_LE_1_BYTE(&p_app_value->instantaneous_cadence, &p_gatt_value->p_value[pos++]);
    
    if ((p_gatt_value->p_value[0] & BLE_RSCC_PRV_RSC_MEASUREMENT_FLAGS_INSTANTANEOUS_STRIDE_LENGTH_PRESENT))
    {
        p_app_value->is_instantaneous_stride_length_present = true;
        BT_UNPACK_LE_2_BYTE( &p_app_value->instantaneous_stride_length, &p_gatt_value->p_value[pos]);
        pos += 2;
    }
    else
    {
        p_app_value->is_instantaneous_stride_length_present = false;
    }

    if ((p_gatt_value->p_value[0] & BLE_RSCC_PRV_RSC_MEASUREMENT_FLAGS_TOTAL_DISTANCE_PRESENT))
    {
        p_app_value->is_total_distance_present = true;
        BT_UNPACK_LE_4_BYTE( &p_app_value->total_distance, &p_gatt_value->p_value[pos]);
        pos += 4;
    }
    else
    {
        p_app_value->is_total_distance_present = false;
    }

    if ((p_gatt_value->p_value[0] & BLE_RSCC_PRV_RSC_MEASUREMENT_FLAGS_WALKING_OR_RUNNING_STATUS_BITS))
    {
        p_app_value->is_running = true;
    }
    else
    {
        p_app_value->is_running = false;
    }

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: decode_rsc_feature
 * Description  : This function converts RSC Feature characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the RSC Feature value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_rsc_feature(st_ble_rscc_rsc_feature_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint16_t rsc_feature = 0;

    if (BLE_RSCC_PRV_RSC_FEATURE_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Clear the feature bit flags */
    memset(p_app_value, 0x00, sizeof(st_ble_rscc_rsc_feature_t));

    /* copy the feature supported bits */
    BT_UNPACK_LE_2_BYTE(&rsc_feature, p_gatt_value->p_value);

    /* Instantaneous Stride Length Measurement Supported bit */
    if (rsc_feature & BLE_RSCC_PRV_RSC_FEATURE_INSTANTANEOUS_STRIDE_LENGTH_MEASUREMENT_SUPPORTED)
    {
        p_app_value->is_instantaneous_stride_length_measurement_supported = true;
    }
    else
    {
        p_app_value->is_instantaneous_stride_length_measurement_supported = false;
    }

    /* Total Distance Measurement Supported bit */
    if (rsc_feature & BLE_RSCC_PRV_RSC_FEATURE_TOTAL_DISTANCE_MEASUREMENT_SUPPORTED)
    {
        p_app_value->is_total_distance_measurement_supported = true;
    }
    else
    {
        p_app_value->is_total_distance_measurement_supported = false;
    }

    /* Walking or Running Status Supported bit */
    if (rsc_feature & BLE_RSCC_PRV_RSC_FEATURE_WALKING_OR_RUNNING_STATUS_SUPPORTED)
    {
        p_app_value->is_walking_or_running_status_supported = true;
    }
    else
    {
        p_app_value->is_walking_or_running_status_supported = false;
    }

    /* Sensor Calibration Procedure Supported bit */
    if (rsc_feature & BLE_RSCC_PRV_RSC_FEATURE_CALIBRATION_PROCEDURE_SUPPORTED)
    {
        p_app_value->is_sensor_calibration_procedure_supported = true;
    }
    else
    {
        p_app_value->is_sensor_calibration_procedure_supported = false;
    }

    /* Multiple Sensor Location Supported bit */
    if (rsc_feature & BLE_RSCC_PRV_RSC_FEATURE_MULTIPLE_SENSOR_LOCATIONS_SUPPORTED)
    {
        p_app_value->is_multiple_sensor_location_supported = true;
    }
    else
    {
        p_app_value->is_multiple_sensor_location_supported = false;
    }

    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: encode_sc_control_point
 * Description  : This function converts SC Control Point characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the SC Control Point  value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_sc_control_point(const st_ble_rscc_sc_control_point_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;

    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    /* Copy the opcode */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->op_code);

    if (BLE_RSCC_SC_CONTROL_POINT_OP_CODE_SET_CUMULATIVE_VALUE == p_app_value->op_code)
    {
        /* copy the cumulative value */
        BT_PACK_LE_4_BYTE(&p_gatt_value->p_value[pos], &p_app_value->cumulative_value);
        pos += 4;
    }
    else if (BLE_RSCC_SC_CONTROL_POINT_OP_CODE_UPDATE_SENSOR_LOCATION == p_app_value->op_code)
    {
        /* Copy the sensor location value */
        BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->sensor_location_value);
    }
    else
    {
        /* Do nothing */
    }

    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}
/***********************************************************************************************************************
 * Function Name: decode_sc_control_point
 * Description  : This function converts SC Control Point characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the SC Control Point value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_sc_control_point(st_ble_rscc_sc_control_point_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint8_t pos = 0;
    uint8_t min_len = ((sizeof(p_app_value->response_code)) + (sizeof(p_app_value->request_op_code))
                      + (sizeof(p_app_value->response_value)));

    if ((p_gatt_value->value_len > BLE_RSCC_PRV_SC_CONTROL_POINT_LEN) || (p_gatt_value->value_len < min_len))
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Clear the data structure */
    memset(p_app_value, 0x00, sizeof(st_ble_rscc_sc_control_point_t));

    /* Copy the response code, request opcode and the response value */
    BT_UNPACK_LE_1_BYTE(&p_app_value->response_code, &p_gatt_value->p_value[pos++]);
    BT_UNPACK_LE_1_BYTE(&p_app_value->request_op_code, &p_gatt_value->p_value[pos++]);
    BT_UNPACK_LE_1_BYTE(&p_app_value->response_value, &p_gatt_value->p_value[pos++]);
    
    /* Copy the response parameter if present */
    if ((BLE_RSCC_SC_CONTROL_POINT_OP_CODE_REQUEST_SUPPORTED_SENSOR_LOCATIONS == p_app_value->request_op_code)
        && (BLE_RSCC_SC_CONTROL_POINT_RESPONSE_VALUE_SUCCESS == p_app_value->response_value) )
    {
        for (int32_t i = pos; i < (p_gatt_value->value_len); i++)
        {
            p_app_value->response_parameter[i] = p_gatt_value->p_value[i];
        }

        p_app_value->no_of_supported_sensor_locations = (p_gatt_value->value_len - pos);
    }
    
    return BLE_SUCCESS;
}

/***********************************************************************************************************************
 * Function Name: rscc_gattc_cb
 * Description  : Callback function for the Running Speed and Cadence GATTC events.
 * Arguments    : conn_hdl - handle to the connection
 *                result - ble status
 *              : p_data - pointer to GATTC event data
 * Return Value : none
***********************************************************************************************************************/
static void rscc_gattc_cb(uint16_t type, ble_status_t result, st_ble_gattc_evt_data_t *p_data) // @suppress("Function length")
{
    st_rscc_peer_param_t *p_peer = find_peer_param(p_data->conn_hdl);

    switch (type)
    {
        case BLE_GATTC_EVENT_CHAR_READ_RSP:
        {
            /* Type cast void pointer to st_ble_gattc_rd_char_evt_t pointer */
            st_ble_gattc_rd_char_evt_t *p_rd_char_evt_param = (st_ble_gattc_rd_char_evt_t *)p_data->p_param;

            if (p_rd_char_evt_param->read_data.attr_hdl == p_peer->hdls.rsc_feature_char_val_hdl)
            {
                ble_status_t ret;
                st_ble_rscc_rsc_feature_t app_value;

                ret = decode_rsc_feature(&app_value, &p_rd_char_evt_param->read_data.value);

                st_ble_rscc_evt_data_t evt_data = 
                {
                    .conn_hdl  = p_data->conn_hdl,
                    .param_len = sizeof(app_value),
                    .p_param   = &app_value,
                };
                gs_rscc_cb(BLE_RSCC_EVENT_RSC_FEATURE_READ_RSP, ret, &evt_data);
            }
            else if (p_rd_char_evt_param->read_data.attr_hdl == p_peer->hdls.sensor_location_char_val_hdl)
            {
                uint8_t app_value;
                
                BT_UNPACK_LE_1_BYTE(&app_value, p_rd_char_evt_param->read_data.value.p_value);

                st_ble_rscc_evt_data_t evt_data = 
                {
                    .conn_hdl  = p_data->conn_hdl,
                    .param_len = sizeof(app_value),
                    .p_param   = &app_value,
                };
                gs_rscc_cb(BLE_RSCC_EVENT_SENSOR_LOCATION_READ_RSP, result, &evt_data);
            }
            else
            {
                /* Do Nothing */
            }
        } 
        break;

        case BLE_GATTC_EVENT_CHAR_WRITE_RSP:
        {
            /* Type cast void pointer to st_ble_gattc_wr_char_evt_t pointer */
            st_ble_gattc_wr_char_evt_t *p_wr_char_evt_param = (st_ble_gattc_wr_char_evt_t *)p_data->p_param;

            st_ble_rscc_evt_data_t evt_data = 
            {
                .conn_hdl  = p_data->conn_hdl,
                .param_len = 0,
                .p_param   = NULL,
            };

            if (p_wr_char_evt_param->value_hdl == p_peer->hdls.sc_control_point_char_val_hdl)
            {
                gs_rscc_cb(BLE_RSCC_EVENT_SC_CONTROL_POINT_WRITE_RSP, result, &evt_data);
            }
            else if ((p_wr_char_evt_param->value_hdl == p_peer->hdls.rsc_measurement_cli_cnfg_hdl) ||
                     (p_wr_char_evt_param->value_hdl == p_peer->hdls.sc_control_point_cli_cnfg_hdl))
            {
                gs_rscc_cb(BLE_RSCC_EVENT_CLI_CNFG_WRITE_RSP, result, &evt_data);
            }
            else
            {
                /* Do Nothing */
            }

        } 
        break;

        case BLE_GATTC_EVENT_HDL_VAL_IND:
        {
            /* Type cast void pointer to st_ble_gattc_ind_evt_t pointer */
            st_ble_gattc_ind_evt_t *p_ind_evt_param = (st_ble_gattc_ind_evt_t *)p_data->p_param;

            if (p_ind_evt_param->data.attr_hdl == p_peer->hdls.sc_control_point_char_val_hdl)
            {
                st_ble_rscc_sc_control_point_t app_value;
                ble_status_t ret;

                ret = decode_sc_control_point(&app_value, &p_ind_evt_param->data.value);

                if (BLE_SUCCESS == ret)
                {
                    st_ble_rscc_evt_data_t evt_data = 
                    {
                        .conn_hdl  = p_data->conn_hdl,
                        .param_len = sizeof(app_value),
                        .p_param   = &app_value,
                    };
                    gs_rscc_cb(BLE_RSCC_EVENT_SC_CONTROL_POINT_HDL_VAL_IND, ret, &evt_data);
                }
            }
        } 
        break;

        case BLE_GATTC_EVENT_HDL_VAL_NTF:
        {
            /* Type cast void pointer to st_ble_gattc_ntf_evt_t pointer */
            st_ble_gattc_ntf_evt_t *p_ntf_evt_param = (st_ble_gattc_ntf_evt_t *)p_data->p_param;

            if (p_ntf_evt_param->data.attr_hdl == p_peer->hdls.rsc_measurement_char_val_hdl)
            {
                st_ble_rscc_rsc_measurement_t app_value;
                ble_status_t ret;

                ret = decode_rsc_measurement(&app_value, &p_ntf_evt_param->data.value);

                if (BLE_SUCCESS == ret)
                {
                    st_ble_rscc_evt_data_t evt_data =
                    {
                        .conn_hdl  = p_data->conn_hdl,
                        .param_len = sizeof(app_value),
                        .p_param   = &app_value,
                    };
                    gs_rscc_cb(BLE_RSCC_EVENT_RSC_MEASUREMENT_HDL_VAL_NTF, ret, &evt_data);
                }
            }
        } 
        break;

        case BLE_GATTC_EVENT_ERROR_RSP:
        {
            /* Type cast void pointer to st_ble_gattc_err_rsp_evt_t pointer */
            st_ble_gattc_err_rsp_evt_t *p_err_rsp_evt_param = (st_ble_gattc_err_rsp_evt_t *)p_data->p_param;

            st_ble_rscc_evt_data_t evt_data = 
            {
                .conn_hdl  = p_data->conn_hdl,
                .param_len = sizeof(st_ble_gattc_err_rsp_evt_t),
                .p_param   = p_err_rsp_evt_param,
            };

            if ((p_err_rsp_evt_param->attr_hdl == p_peer->hdls.rsc_feature_char_val_hdl) ||
                (p_err_rsp_evt_param->attr_hdl == p_peer->hdls.sensor_location_char_val_hdl) ||
                (p_err_rsp_evt_param->attr_hdl == p_peer->hdls.sc_control_point_char_val_hdl))
            {
                gs_rscc_cb(BLE_RSCC_EVENT_ERROR_RSP, result, &evt_data);
            }
        } 
        break;

        default:
        {
            /* Do nothing. */
        } 
        break;
    }
}

ble_status_t R_BLE_RSCC_Init(const st_ble_rscc_init_param_t *p_param) // @suppress("API function naming")
{
    if (NULL == p_param)
    {
        return BLE_ERR_INVALID_PTR;
    }

    if (NULL == p_param->cb)
    {
        return BLE_ERR_INVALID_ARG;
    }

    for (uint8_t i = 0; i < 7; i++)
    {
        clear_peer_param(&gs_peer_params[i]);
    }

    R_BLE_GATTC_RegisterCb(rscc_gattc_cb, 2);

    gs_rscc_cb = p_param->cb;

    return BLE_SUCCESS;
}

ble_status_t R_BLE_RSCC_Connect(uint16_t conn_hdl, const st_ble_rscc_connect_param_t *p_param) // @suppress("API function naming")
{
    st_rscc_peer_param_t *p_peer = get_new_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if ((NULL != p_param) && (NULL != p_param->p_hdls))
    {
        memcpy(&p_peer->hdls, p_param->p_hdls, sizeof(p_peer->hdls));
    }

    return BLE_SUCCESS;
}

ble_status_t R_BLE_RSCC_Disconnect(uint16_t conn_hdl, st_ble_rscc_disconnect_param_t *p_param) // @suppress("API function naming")
{
    st_rscc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if ((NULL != p_param) && (NULL != p_param->p_hdls))
    {
        memcpy(p_param->p_hdls, &p_peer->hdls, sizeof(*p_param->p_hdls));
    }

    clear_peer_param(p_peer);

    return BLE_SUCCESS;
}

ble_status_t R_BLE_RSCC_SetRscMeasurementCliCnfg(uint16_t conn_hdl, uint16_t cli_cnfg) // @suppress("API function naming")
{
    st_rscc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.rsc_measurement_cli_cnfg_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    if (0 != (cli_cnfg & 0xFFFC))
    {
        return BLE_ERR_INVALID_ARG;
    }

    uint8_t byte_value[2] = { 0 };

    BT_PACK_LE_2_BYTE(byte_value, &cli_cnfg);

    st_ble_gatt_hdl_value_pair_t gatt_value = 
    {
        .attr_hdl = p_peer->hdls.rsc_measurement_cli_cnfg_hdl,
        .value    = 
        {
            .p_value   = byte_value,
            .value_len = 2,
        }
    };

    return R_BLE_GATTC_WriteChar(conn_hdl, &gatt_value);
}

ble_status_t R_BLE_RSCC_ReadRscFeature(uint16_t conn_hdl) // @suppress("API function naming")
{
    st_rscc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.rsc_feature_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    return R_BLE_GATTC_ReadChar(conn_hdl, p_peer->hdls.rsc_feature_char_val_hdl);
}

ble_status_t R_BLE_RSCC_ReadSensorLocation(uint16_t conn_hdl) // @suppress("API function naming")
{
    st_rscc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.sensor_location_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    return R_BLE_GATTC_ReadChar(conn_hdl, p_peer->hdls.sensor_location_char_val_hdl);
}

ble_status_t R_BLE_RSCC_WriteScControlPoint(uint16_t conn_hdl, const st_ble_rscc_sc_control_point_t *p_app_value) // @suppress("API function naming")
{
    ble_status_t ret;
    st_rscc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (NULL == p_app_value)
    {
        return BLE_ERR_INVALID_PTR;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.sc_control_point_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    uint8_t byte_value[BLE_RSCC_PRV_SC_CONTROL_POINT_LEN];
    
    st_ble_gatt_hdl_value_pair_t write_value = 
    {
        .attr_hdl  = p_peer->hdls.sc_control_point_char_val_hdl,
        .value     = 
        {
            .p_value   = byte_value,
            .value_len = BLE_RSCC_PRV_SC_CONTROL_POINT_LEN,
        }
    };

    ret = encode_sc_control_point(p_app_value, &write_value.value);
    if (BLE_SUCCESS != ret)
    {
        ret = BLE_ERR_INVALID_DATA;
    }
    else
    {
        ret = R_BLE_GATTC_WriteChar(conn_hdl, &write_value);
    }

    return ret;
}

ble_status_t R_BLE_RSCC_SetScControlPointCliCnfg(uint16_t conn_hdl, uint16_t cli_cnfg) // @suppress("API function naming")
{
    st_rscc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.sc_control_point_cli_cnfg_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    if (0 != (cli_cnfg & 0xFFFC))
    {
        return BLE_ERR_INVALID_ARG;
    }

    uint8_t byte_value[2] = { 0 };

    BT_PACK_LE_2_BYTE(byte_value, &cli_cnfg);

    st_ble_gatt_hdl_value_pair_t gatt_value = 
    {
        .attr_hdl = p_peer->hdls.sc_control_point_cli_cnfg_hdl,
        .value    = 
        {
            .p_value   = byte_value,
            .value_len = 2,
        }
    };

    return R_BLE_GATTC_WriteChar(conn_hdl, &gatt_value);
}

void R_BLE_RSCC_ServDiscCb(uint16_t conn_hdl, uint8_t idx, uint16_t type, void *p_param) // @suppress("API function naming")
{
    st_rscc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    switch (type)
    {
        case BLE_DISC_PRIM_SERV_FOUND:
        {
            /* Type cast void pointer to st_disc_serv_param_t pointer */
            st_disc_serv_param_t *p_serv_param = (st_disc_serv_param_t *)p_param;
            memcpy(&p_peer->hdls.service_range, &p_serv_param->value.serv_16.range, sizeof(p_peer->hdls.service_range));
        } 
        break;

        case BLE_DISC_CHAR_FOUND:
        {
            /* Type cast void pointer to st_disc_char_param_t pointer */
            st_disc_char_param_t *p_char_param = (st_disc_char_param_t *)p_param;

            if (BLE_GATT_16_BIT_UUID_FORMAT == p_char_param->uuid_type)
            {
                uint8_t uuid_16[BLE_GATT_16_BIT_UUID_SIZE];

                BT_PACK_LE_2_BYTE(uuid_16, &p_char_param->value.char_16.uuid_16);

                if (0 == memcmp(uuid_16, BLE_RSCC_RSC_MEASUREMENT_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.rsc_measurement_char_val_hdl = p_char_param->value.char_16.value_hdl;

                    for (uint8_t i = 0; i < p_char_param->num_of_descs; i++)
                    {
                        BT_PACK_LE_2_BYTE(uuid_16, &p_char_param->descs[i].value.desc_16.uuid_16);

                        if (0 == memcmp(uuid_16, BLE_RSCC_RSC_MEASUREMENT_CLIENT_CHARACTERISTIC_CONFIGURATION_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                        {
                            p_peer->hdls.rsc_measurement_cli_cnfg_hdl = p_char_param->descs[i].value.desc_16.desc_hdl;
                        }
                    }
                }
                else if (0 == memcmp(uuid_16, BLE_RSCC_RSC_FEATURE_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.rsc_feature_char_val_hdl = p_char_param->value.char_16.value_hdl;

                }
                else if (0 == memcmp(uuid_16, BLE_RSCC_SENSOR_LOCATION_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.sensor_location_char_val_hdl = p_char_param->value.char_16.value_hdl;

                }
                else if (0 == memcmp(uuid_16, BLE_RSCC_SC_CONTROL_POINT_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.sc_control_point_char_val_hdl = p_char_param->value.char_16.value_hdl;

                    for (uint8_t i = 0; i < p_char_param->num_of_descs; i++)
                    {
                        BT_PACK_LE_2_BYTE(uuid_16, &p_char_param->descs[i].value.desc_16.uuid_16);

                        if (0 == memcmp(uuid_16, BLE_RSCC_SC_CONTROL_POINT_CLIENT_CHARACTERISTIC_CONFIGURATION_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                        {
                            p_peer->hdls.sc_control_point_cli_cnfg_hdl = p_char_param->descs[i].value.desc_16.desc_hdl;
                        }
                    }
                }
            }
        } 
        break;

        default:
        {
            /* Do nothing. */
        } 
        break;
    }
}

uint32_t R_BLE_RSCC_GetVersion(void) // @suppress("API function naming")
{
    uint32_t version;

    version = ((BLE_RSCC_PRV_VERSION_MAJOR << 16) | (BLE_RSCC_PRV_VERSION_MINOR << 8));

    return version;
}
