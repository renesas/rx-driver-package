/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_rscc.c
 * Version : 1.0
 * Description : The source file for Running Speed and Cadence Service client.
 **********************************************************************************************************************/
 /***********************************************************************************************************************
  * History : DD.MM.YYYY Version Description
  *         : 20.12.2019 1.00 First Release
  ***********************************************************************************************************************/

/******************************************************************************************************************//**
 @file
 @defgroup rscc Running Speed and Cadence Service Client
 @{
 @ingroup profile
 @brief   This is the client for the Running Speed and Cadence Service .
*********************************************************************************************************************/
#include "r_ble_rscc.h"
#include "profile_cmn/r_ble_servc_if.h"
#include "discovery/r_ble_disc.h"
#include <string.h>

#ifndef UNUSED_ARG
#define UNUSED_ARG(arg)         (void)(arg)
#endif /* UNUSED_ARG */

/*******************************************************************************************************************//**
 * @brief RSC Measurement characteristic value length.
***********************************************************************************************************************/
#define BLE_RSCC_PRV_RSC_MEASUREMENT_LEN                                                     (10)

/*******************************************************************************************************************//**
 * @brief RSC Feature characteristic value length.
***********************************************************************************************************************/
#define BLE_RSCC_PRV_RSC_FEATURE_LEN                                                         (2)

/*******************************************************************************************************************//**
 * @brief Sensor Location characteristic value length.
***********************************************************************************************************************/
#define BLE_RSCC_PRV_SENSOR_LOCATION_LEN                                                     (1)

/*******************************************************************************************************************//**
 * @brief SC Control Point characteristic value length.
***********************************************************************************************************************/
#define BLE_RSCC_PRV_SC_CONTROL_POINT_LEN                                                    (20)

/***********************************************************************************************************************
* @brief Instantaneous Stride Length Present bit.
***********************************************************************************************************************/
#define BLE_RSCC_PRV_RSC_MEASUREMENT_FLAGS_INSTANTANEOUS_STRIDE_LENGTH_PRESENT               (1 << 0)

/*******************************************************************************************************************//**
 * @brief Total Distance Present bit.
***********************************************************************************************************************/
#define BLE_RSCC_PRV_RSC_MEASUREMENT_FLAGS_TOTAL_DISTANCE_PRESENT                            (1 << 1)

/*******************************************************************************************************************//**
 * @brief Walking or Running Status bits.
***********************************************************************************************************************/
#define BLE_RSCC_PRV_RSC_MEASUREMENT_FLAGS_WALKING_OR_RUNNING_STATUS_BITS                    (1 << 2)

/***********************************************************************************************************************
  * @brief Instantaneous Stride Length Measurement Supported bit.
***********************************************************************************************************************/
#define BLE_RSCC_PRV_RSC_FEATURE_INSTANTANEOUS_STRIDE_LENGTH_MEASUREMENT_SUPPORTED           (1 << 0)

/*******************************************************************************************************************//**
 * @brief Total Distance Measurement Supported bit.
***********************************************************************************************************************/
#define BLE_RSCC_PRV_RSC_FEATURE_TOTAL_DISTANCE_MEASUREMENT_SUPPORTED                        (1 << 1)

/***********************************************************************************************************************
 * @brief Walking or Running Status Supported bit.
***********************************************************************************************************************/
#define BLE_RSCC_PRV_RSC_FEATURE_WALKING_OR_RUNNING_STATUS_SUPPORTED                         (1 << 2)

/***********************************************************************************************************************
 * @brief Calibration Procedure Supported bit.
***********************************************************************************************************************/
#define BLE_RSCC_PRV_RSC_FEATURE_CALIBRATION_PROCEDURE_SUPPORTED                             (1 << 3)

/*******************************************************************************************************************//**
 * @brief Multiple Sensor Locations Supported bit.
***********************************************************************************************************************/
#define BLE_RSCC_PRV_RSC_FEATURE_MULTIPLE_SENSOR_LOCATIONS_SUPPORTED                         (1 << 4)


static st_ble_servc_info_t gs_client_info;

/*----------------------------------------------------------------------------------------------------------------------
    RSC Measurement Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* RSC Measurement characteristic descriptors attribute handles */
static uint16_t gs_rsc_meas_cli_cnfg_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_rsc_measurement_cli_cnfg =
{
    .uuid_16     = BLE_RSCC_RSC_MEASUREMENT_CLI_CNFG_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint16_t),
    .db_size     = BLE_RSCC_RSC_MEASUREMENT_CLI_CNFG_LEN,
    .desc_idx    = BLE_RSCC_RSC_MEASUREMENT_CLI_CNFG_IDX,
    .p_attr_hdls = gs_rsc_meas_cli_cnfg_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_RSCC_WriteRscMeasCliCnfg(uint16_t conn_hdl, const uint16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_rsc_measurement_cli_cnfg, conn_hdl, p_value);
}

/* End of function R_BLE_RSCC_WriteRscMeasCliCnfg */

ble_status_t R_BLE_RSCC_ReadRscMeasCliCnfg(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_rsc_measurement_cli_cnfg, conn_hdl);
}

/* End of function R_BLE_RSCC_ReadRscMeasCliCnfg */

/*----------------------------------------------------------------------------------------------------------------------
    RSC Measurement Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* RSC Measurement characteristic 128 bit UUID */

/* RSC Measurement characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_rsc_measurement_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];


/***********************************************************************************************************************
 * Function Name: decode_st_ble_rscc_rsc_meas_t
 * Description  : This function converts RSC Measurement characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the RSC Measurement value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_rscc_rsc_meas_t(st_ble_rscc_rsc_measurement_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t      pos = 1;

    if (BLE_RSCC_PRV_RSC_MEASUREMENT_LEN < p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Clear the data structure */
    memset(p_app_value, 0x00, sizeof(st_ble_rscc_rsc_measurement_t));

    /* Copy Instantaneous Speed and Instantaneous Cadence */
    BT_UNPACK_LE_2_BYTE(&p_app_value->instantaneous_speed, &p_gatt_value->p_value[pos]);
    pos += 2; /* Copy 2 bytes from p_gatt_value to p_app_value */

    BT_UNPACK_LE_1_BYTE(&p_app_value->instantaneous_cadence, &p_gatt_value->p_value[pos++]);

    if ((p_gatt_value->p_value[0] & BLE_RSCC_PRV_RSC_MEASUREMENT_FLAGS_INSTANTANEOUS_STRIDE_LENGTH_PRESENT))
    {
        p_app_value->is_instantaneous_stride_length_present = true;
        BT_UNPACK_LE_2_BYTE(&p_app_value->instantaneous_stride_length, &p_gatt_value->p_value[pos]);
        pos += 2;  /* Copy 2 bytes from p_gatt_value to p_app_value */
    }
    else
    {
        p_app_value->is_instantaneous_stride_length_present = false;
    }

    if ((p_gatt_value->p_value[0] & BLE_RSCC_PRV_RSC_MEASUREMENT_FLAGS_TOTAL_DISTANCE_PRESENT))
    {
        p_app_value->is_total_distance_present = true;
        BT_UNPACK_LE_4_BYTE(&p_app_value->total_distance, &p_gatt_value->p_value[pos]);
        pos += 4;  /* Copy 4 bytes from p_gatt_value to p_app_value */
    }
    else
    {
        p_app_value->is_total_distance_present = false;
    }

    if ((p_gatt_value->p_value[0] & BLE_RSCC_PRV_RSC_MEASUREMENT_FLAGS_WALKING_OR_RUNNING_STATUS_BITS))
    {
        p_app_value->is_walking_or_running_status_bits = true;
    }
    else
    {
        p_app_value->is_walking_or_running_status_bits = false;
    }
    return BLE_SUCCESS;
}

/* End of function decode_st_ble_rscc_rsc_meas_t */

/***********************************************************************************************************************
 * Function Name: encode_st_ble_rscc_rsc_meas_t
 * Description  : This function converts RSC Measurement characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the RSC Measurement  value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_rscc_rsc_meas_t(const st_ble_rscc_rsc_measurement_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    UNUSED_ARG(p_app_value);
    UNUSED_ARG(p_gatt_value);

    /* Do Nothing as flow is not hitting here*/
    return BLE_SUCCESS;
}

/* End of function encode_st_ble_rscc_rsc_meas_t */

/* RSC Measurement characteristic descriptor definition */
static const st_ble_servc_desc_info_t *gspp_rsc_measurement_descs[] =
{
    &gs_rsc_measurement_cli_cnfg,
};

/* RSC Measurement characteristic definition */
const st_ble_servc_char_info_t gs_rsc_measurement_char =
{
    .uuid_16      = BLE_RSCC_RSC_MEASUREMENT_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_rscc_rsc_measurement_t),
    .db_size      = BLE_RSCC_RSC_MEASUREMENT_LEN,
    .char_idx     = BLE_RSCC_RSC_MEASUREMENT_IDX,
    .p_attr_hdls  = gs_rsc_measurement_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_rscc_rsc_meas_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_rscc_rsc_meas_t,
    .num_of_descs = ARRAY_SIZE(gspp_rsc_measurement_descs),
    .pp_descs     = gspp_rsc_measurement_descs,
};

void R_BLE_RSCC_GetRscMeasAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_rscc_rsc_measurement_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx                 = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range             = gs_rsc_measurement_char_ranges[conn_idx];
    p_hdl->cli_cnfg_desc_hdl = gs_rsc_meas_cli_cnfg_desc_hdls[conn_idx];
}
/* End of function R_BLE_RSCC_GetRscMeasAttrHdl */

/*----------------------------------------------------------------------------------------------------------------------
    RSC Feature Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* RSC Feature characteristic 128 bit UUID */

/* RSC Feature characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_rsc_feature_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

/***********************************************************************************************************************
 * Function Name: decode_st_ble_rscc_rsc_feat_t
 * Description  : This function converts RSC Feature characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the RSC Feature value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_st_ble_rscc_rsc_feat_t(st_ble_rscc_rsc_feature_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint16_t rsc_feature = 0;

    if (BLE_RSCC_PRV_RSC_FEATURE_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Clear the feature bit flags */
    memset(p_app_value, 0x00, sizeof(st_ble_rscc_rsc_feature_t));

    /* copy the feature supported bits */
    BT_UNPACK_LE_2_BYTE(&rsc_feature, p_gatt_value->p_value);

    /* Instantaneous Stride Length Measurement Supported bit */
    if (rsc_feature & BLE_RSCC_PRV_RSC_FEATURE_INSTANTANEOUS_STRIDE_LENGTH_MEASUREMENT_SUPPORTED)
    {
        p_app_value->is_instantaneous_stride_length_measurement_supported = true;
    }
    else
    {
        p_app_value->is_instantaneous_stride_length_measurement_supported = false;
    }

    /* Total Distance Measurement Supported bit */
    if (rsc_feature & BLE_RSCC_PRV_RSC_FEATURE_TOTAL_DISTANCE_MEASUREMENT_SUPPORTED)
    {
        p_app_value->is_total_distance_measurement_supported = true;
    }
    else
    {
        p_app_value->is_total_distance_measurement_supported = false;
    }

    /* Walking or Running Status Supported bit */
    if (rsc_feature & BLE_RSCC_PRV_RSC_FEATURE_WALKING_OR_RUNNING_STATUS_SUPPORTED)
    {
        p_app_value->is_walking_or_running_status_supported = true;
    }
    else
    {
        p_app_value->is_walking_or_running_status_supported = false;
    }

    /* Sensor Calibration Procedure Supported bit */
    if (rsc_feature & BLE_RSCC_PRV_RSC_FEATURE_CALIBRATION_PROCEDURE_SUPPORTED)
    {
        p_app_value->is_calibration_procedure_supported = true;
    }
    else
    {
        p_app_value->is_calibration_procedure_supported = false;
    }

    /* Multiple Sensor Location Supported bit */
    if (rsc_feature & BLE_RSCC_PRV_RSC_FEATURE_MULTIPLE_SENSOR_LOCATIONS_SUPPORTED)
    {
        p_app_value->is_multiple_sensor_locations_supported = true;
    }
    else
    {
        p_app_value->is_multiple_sensor_locations_supported = false;
    }
    return BLE_SUCCESS;
}

/* End of function decode_st_ble_rscc_rsc_feat_t */

/***********************************************************************************************************************
 * Function Name: encode_st_ble_rscc_rsc_feat_t
 * Description  : This function converts RSC Feature characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the RSC Feature  value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_st_ble_rscc_rsc_feat_t(const st_ble_rscc_rsc_feature_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint16_t rsc_feature = 0;

    /* Clear the byte array */
    memset(p_gatt_value, 0x00, p_gatt_value->value_len);

    /* Instantaneous Stride Length Measurement Supported bit */
    if (p_app_value->is_instantaneous_stride_length_measurement_supported)
    {
        rsc_feature |= BLE_RSCC_PRV_RSC_FEATURE_INSTANTANEOUS_STRIDE_LENGTH_MEASUREMENT_SUPPORTED;
    }

    /* Total Distance Measurement Supported bit */
    if (p_app_value->is_total_distance_measurement_supported)
    {
        rsc_feature |= BLE_RSCC_PRV_RSC_FEATURE_TOTAL_DISTANCE_MEASUREMENT_SUPPORTED;
    }

    /* Walking or Running Status Supported bit */
    if (p_app_value->is_walking_or_running_status_supported)
    {
        rsc_feature |= BLE_RSCC_PRV_RSC_FEATURE_WALKING_OR_RUNNING_STATUS_SUPPORTED;
    }

    /* Sensor Calibration Procedure Supported bit */
    if (p_app_value->is_calibration_procedure_supported)
    {
        rsc_feature |= BLE_RSCC_PRV_RSC_FEATURE_CALIBRATION_PROCEDURE_SUPPORTED;
    }

    /* Multiple Sensor Location Supported bit */
    if (p_app_value->is_multiple_sensor_locations_supported)
    {
        rsc_feature |= BLE_RSCC_PRV_RSC_FEATURE_MULTIPLE_SENSOR_LOCATIONS_SUPPORTED;
    }

    BT_PACK_LE_2_BYTE(p_gatt_value->p_value, &rsc_feature);

    p_gatt_value->value_len = BLE_RSCC_RSC_FEATURE_LEN;
    return BLE_SUCCESS;
}

/* End of function encode_st_ble_rscc_rsc_feat_t */

/* RSC Feature characteristic definition */
const st_ble_servc_char_info_t gs_rsc_feature_char =
{
    .uuid_16      = BLE_RSCC_RSC_FEATURE_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_rscc_rsc_feature_t),
    .db_size      = BLE_RSCC_RSC_FEATURE_LEN,
    .char_idx     = BLE_RSCC_RSC_FEATURE_IDX,
    .p_attr_hdls  = gs_rsc_feature_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_rscc_rsc_feat_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_rscc_rsc_feat_t,
};

ble_status_t R_BLE_RSCC_ReadRscFeat(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_rsc_feature_char, conn_hdl);
}
/* End of function R_BLE_RSCC_ReadRscFeature */


void R_BLE_RSCC_GetRscFeatAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_rscc_rsc_feature_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx     = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_rsc_feature_char_ranges[conn_idx];
}
/* End of function R_BLE_RSCC_GetRscFeatureAttrHdl */

/*----------------------------------------------------------------------------------------------------------------------
    Sensor Location Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Sensor Location characteristic 128 bit UUID */

/* Sensor Location characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_sensor_location_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

/* Sensor Location characteristic definition */
static const st_ble_servc_char_info_t gs_sensor_location_char =
{
    .uuid_16      = BLE_RSCC_SENSOR_LOCATION_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(uint8_t),
    .db_size      = BLE_RSCC_SENSOR_LOCATION_LEN,
    .char_idx     = BLE_RSCC_SENSOR_LOCATION_IDX,
    .p_attr_hdls  = gs_sensor_location_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_uint8_t,
    .encode       = (ble_servc_attr_encode_t)encode_uint8_t,
};

ble_status_t R_BLE_RSCC_ReadSenLoc(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_sensor_location_char, conn_hdl);
}

/* End of function R_BLE_RSCC_ReadSensorLocation */

void R_BLE_RSCC_GetSenLocAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_rscc_sensor_location_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx     = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_sensor_location_char_ranges[conn_idx];
}
/* End of function R_BLE_RSCC_GetSenLocAttrHdl */

/*----------------------------------------------------------------------------------------------------------------------
    SC Control Point Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* SC Control Point characteristic descriptors attribute handles */
static uint16_t gs_sc_cp_cli_cnfg_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_sc_control_point_cli_cnfg =
{
    .uuid_16     = BLE_RSCC_SC_CONTROL_POINT_CLI_CNFG_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint16_t),
    .db_size     = BLE_RSCC_SC_CONTROL_POINT_CLI_CNFG_LEN,
    .desc_idx    = BLE_RSCC_SC_CONTROL_POINT_CLI_CNFG_IDX,
    .p_attr_hdls = gs_sc_cp_cli_cnfg_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_RSCC_WriteScCPCliCnfg(uint16_t conn_hdl, const uint16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_sc_control_point_cli_cnfg, conn_hdl, p_value);
}
/* End of function R_BLE_RSCC_WriteScCPCliCnfg */

ble_status_t R_BLE_RSCC_ReadScCPCliCnfg(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_sc_control_point_cli_cnfg, conn_hdl);
}
/* End of function R_BLE_RSCC_ReadScCPCliCnfg */

/*----------------------------------------------------------------------------------------------------------------------
    SC Control Point Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* SC Control Point characteristic 128 bit UUID */

/* SC Control Point characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_sc_control_point_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

static ble_status_t decode_st_ble_rscc_sc_cp_t(st_ble_rscc_sc_control_point_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos     = 0;
    uint8_t  min_len = ((sizeof(p_app_value->response_code)) + (sizeof(p_app_value->request_op_code))
        + (sizeof(p_app_value->response_value)));

    if ((p_gatt_value->value_len > BLE_RSCC_PRV_SC_CONTROL_POINT_LEN) || (p_gatt_value->value_len < min_len))
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Clear the data structure */
    memset(p_app_value, 0x00, sizeof(st_ble_rscc_sc_control_point_t));

    /* Copy the response code, request opcode and the response value */
    BT_UNPACK_LE_1_BYTE(&p_app_value->response_code, &p_gatt_value->p_value[pos++]);
    BT_UNPACK_LE_1_BYTE(&p_app_value->request_op_code, &p_gatt_value->p_value[pos++]);
    BT_UNPACK_LE_1_BYTE(&p_app_value->response_value, &p_gatt_value->p_value[pos++]);

    /* Copy the response parameter if present */
    if ((BLE_RSCC_SC_CONTROL_POINT_OP_CODE_REQUEST_SUPPORTED_SENSOR_LOCATIONS == p_app_value->request_op_code)
        && (BLE_RSCC_SC_CONTROL_POINT_RESPONSE_VALUE_SUCCESS__RESPONSE_PARAMETER__NONE_EXCEPT_FOR_OP_CODE_0X04_SEE_NOTE_BELOW_ == p_app_value->response_value))
    {
        for (uint32_t i = pos; i < (p_gatt_value->value_len); i++)
        {
            p_app_value->response_parameter[i] = p_gatt_value->p_value[i];
        }

        p_app_value->no_of_supported_sensor_locations = (uint8_t)(p_gatt_value->value_len - pos);
    }
    return BLE_SUCCESS;
}
/* End of function decode_st_ble_rscc_sc_cp_t */

/***********************************************************************************************************************
 * Function Name: encode_st_ble_rscc_sc_cp_t
 * Description  : This function converts SC Control Point characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the SC Control Point  value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/

static ble_status_t encode_st_ble_rscc_sc_cp_t(const st_ble_rscc_sc_control_point_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    uint32_t pos = 0;
    memset(p_gatt_value->p_value, 0x00, p_gatt_value->value_len);

    /* Copy the opcode */
    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->op_code);

    if (BLE_RSCC_SC_CONTROL_POINT_OP_CODE_SET_CUMULATIVE_VALUE == p_app_value->op_code)
    {
        /* copy the cumulative value */
        BT_PACK_LE_4_BYTE(&p_gatt_value->p_value[pos], &p_app_value->cumulative_value);
        pos += 4;
    }
    else if (BLE_RSCC_SC_CONTROL_POINT_OP_CODE_UPDATE_SENSOR_LOCATION == p_app_value->op_code)
    {
        /* Copy the sensor location value */
        BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos++], &p_app_value->sensor_location_value);
    }
    else
    {
        /* Do nothing */
    }

    p_gatt_value->value_len = (uint16_t)pos;

    return BLE_SUCCESS;
}

/* End of function encode_st_ble_rscc_sc_cp_t */

/* SC Control Point characteristic descriptor definition */
static const st_ble_servc_desc_info_t *gspp_sc_control_point_descs[] =
{
    &gs_sc_control_point_cli_cnfg,
};

/* SC Control Point characteristic definition */
static const st_ble_servc_char_info_t gs_sc_control_point_char =
{
    .uuid_16      = BLE_RSCC_SC_CONTROL_POINT_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_rscc_sc_control_point_t),
    .db_size      = BLE_RSCC_SC_CONTROL_POINT_LEN,
    .char_idx     = BLE_RSCC_SC_CONTROL_POINT_IDX,
    .p_attr_hdls  = gs_sc_control_point_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_rscc_sc_cp_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_rscc_sc_cp_t,
    .num_of_descs = ARRAY_SIZE(gspp_sc_control_point_descs),
    .pp_descs     = gspp_sc_control_point_descs,
};

ble_status_t R_BLE_RSCC_WriteScCP(uint16_t conn_hdl, const st_ble_rscc_sc_control_point_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteChar(&gs_sc_control_point_char, conn_hdl, p_value);
}
/* End of function R_BLE_RSCC_WriteScControlPoint */

void R_BLE_RSCC_GetScCPAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_rscc_sc_control_point_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx                  = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range              = gs_sc_control_point_char_ranges[conn_idx];
    p_hdl->cli_cnfg_desc_hdl  = gs_sc_cp_cli_cnfg_desc_hdls[conn_idx];
}

/* End of function R_BLE_RSCC_GetScCPAttrHdl */

/*----------------------------------------------------------------------------------------------------------------------
    Running Speed and Cadence Service client
----------------------------------------------------------------------------------------------------------------------*/

/* Running Speed and Cadence Service client attribute handles */
static st_ble_gatt_hdl_range_t gs_rscc_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

const st_ble_servc_char_info_t *gspp_rscc_chars[] =
{
    &gs_rsc_measurement_char,
    &gs_rsc_feature_char,
    &gs_sensor_location_char,
    &gs_sc_control_point_char,
};

static st_ble_servc_info_t gs_client_info =
{
    .pp_chars     = gspp_rscc_chars,
    .num_of_chars = ARRAY_SIZE(gspp_rscc_chars),
    .p_attr_hdls  = gs_rscc_ranges,
};

ble_status_t R_BLE_RSCC_Init(ble_servc_app_cb_t cb) // @suppress("API function naming")
{
    if (NULL == cb)
    {
        return BLE_ERR_INVALID_PTR;
    }

    gs_client_info.cb = cb;

    return R_BLE_SERVC_RegisterClient(&gs_client_info);
}

/* End of function R_BLE_RSCC_Init */

void R_BLE_RSCC_ServDiscCb(uint16_t conn_hdl, uint8_t serv_idx, uint16_t type, void *p_param) // @suppress("API function naming")
{
    R_BLE_SERVC_ServDiscCb(&gs_client_info, conn_hdl, serv_idx, type, p_param);
}

/* End of function R_BLE_RSCC_ServDiscCb */

void R_BLE_RSCC_GetServAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_gatt_hdl_range_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    *p_hdl   = gs_rscc_ranges[conn_idx];
}

/* End of function R_BLE_RSCC_GetServAttrHdl */
