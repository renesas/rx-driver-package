/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_htc.h
 * Version : 1.0
 * Description : The header file for Health Thermometer client.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 31.12.2999 1.00 First Release
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @file
 * @defgroup htc Health Thermometer Service Client
 * @{
 * @ingroup profile
 * @brief   This is the client for the Health Thermometer Service.
 **********************************************************************************************************************/

#include "profile_cmn/r_ble_servc_if.h"

#ifndef R_BLE_HTC_H
#define R_BLE_HTC_H


/*******************************************************************************************************************//**
 * @brief Temperature Measurement characteristic value length.
 ***********************************************************************************************************************/
#define BLE_HTC_TEMP_MEAS_LEN                             (13)

/*******************************************************************************************************************//**
 * @brief Temperature Type characteristic value length.
 ***********************************************************************************************************************/
#define BLE_HTC_TEMP_TYPE_LEN                                    (1)

/*******************************************************************************************************************//**
 * @brief Intermediate Temperature characteristic value length.
 ***********************************************************************************************************************/
#define BLE_HTC_INTERMEDIATE_TEMPERATURE_LEN                            (13)

/*******************************************************************************************************************//**
 * @brief Measurement Interval characteristic value length.
 ***********************************************************************************************************************/
#define BLE_HTC_MEAS_INTERVAL_LEN                                (2)

/*******************************************************************************************************************//**
 * @brief Temperature Units Flag bit.
***********************************************************************************************************************/
#define BLE_PRV_HTC_TEMP_MEAS_FLAGS_TEMPERATURE_UNITS_FLAG (1 << 0)

/*******************************************************************************************************************//**
 * @brief Time Stamp Flag bit.
***********************************************************************************************************************/
#define BLE_PRV_HTC_TEMP_MEAS_FLAGS_TIME_STAMP_FLAG (1 << 1)

/*******************************************************************************************************************//**
 * @brief Temperature Type Flag bit.
***********************************************************************************************************************/
#define BLE_PRV_HTC_TEMP_MEAS_FLAGS_TEMP_TYPE_FLAG (1 << 2)


/*----------------------------------------------------------------------------------------------------------------------
    Temperature Measurement Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_HTC_TEMP_MEAS_UUID (0x2A1C)
#define BLE_HTC_TEMP_MEAS_CLI_CNFG_UUID (0x2902)
#define BLE_HTC_TEMP_MEAS_CLI_CNFG_LEN (2)

      
/***************************************************************************//**
 * @brief Temperature Measurement Flags value structure.
*******************************************************************************/
#ifndef R_BLE_HTS_H
typedef struct {
    bool temperature_units_flag; /**< Temperature Units Flag */
    bool time_stamp_flag; /**< Time Stamp Flag */
    bool temperature_type_flag; /**< Temperature Type Flag */
} st_ble_temp_meas_flags_t;
#endif /* R_BLE_HTS_H */

/***************************************************************************//**
 * @brief Temperature Measurement value structure.
*******************************************************************************/
typedef struct {
    st_ble_temp_meas_flags_t flags; /**< Flags */
    st_ble_ieee11073_float_t temp_meas_value; /**< Temperature Measurement Value. Celsius or Fahrenheit will be defined in flag field. */
    st_ble_date_time_t time_stamp; /**< Time Stamp */
    uint8_t temperature_type; /**< Temperature Type */
} st_ble_htc_temp_meas_t;

/***************************************************************************//**
 * @brief Temperature Measurement attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
    uint16_t cli_cnfg_desc_hdl;
} st_ble_htc_temp_meas_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Temperature Measurement characteristic Client Characteristic Configuration descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_HTC_ReadTempMeasCliCnfg(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Temperature Measurement characteristic Client Characteristic Configuration descriptor value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value Temperature Measurement characteristic Client Characteristic Configuration descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_HTC_WriteTempMeasCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief      Get Temperature Measurement attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_HTC_GetTempMeasAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_htc_temp_meas_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Temperature Type Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_HTC_TEMP_TYPE_UUID (0x2A1D)
#define BLE_HTC_TEMP_TYPE_LEN (1)
/***************************************************************************//**
 * @brief Temperature Type Temperature Text Description enumeration.
*******************************************************************************/
typedef enum {
    BLE_HTC_TEMP_TYPE_TEMPERATURE_TEXT_DESCRIPTION_ARMPIT = 1, /**< Armpit */
    BLE_HTC_TEMP_TYPE_TEMPERATURE_TEXT_DESCRIPTION_BODY = 2, /**< Body (general) */
    BLE_HTC_TEMP_TYPE_TEMPERATURE_TEXT_DESCRIPTION_EAR = 3, /**< Ear (usually ear lobe) */
    BLE_HTC_TEMP_TYPE_TEMPERATURE_TEXT_DESCRIPTION_FINGER = 4, /**< Finger */
    BLE_HTC_TEMP_TYPE_TEMPERATURE_TEXT_DESCRIPTION_GASTRO_INTESTINAL_TRACT = 5, /**< Gastro-intestinal Tract */
    BLE_HTC_TEMP_TYPE_TEMPERATURE_TEXT_DESCRIPTION_MOUTH = 6, /**< Mouth */
    BLE_HTC_TEMP_TYPE_TEMPERATURE_TEXT_DESCRIPTION_RECTUM = 7, /**< Rectum */
    BLE_HTC_TEMP_TYPE_TEMPERATURE_TEXT_DESCRIPTION_TOE = 8, /**< Toe */
    BLE_HTC_TEMP_TYPE_TEMPERATURE_TEXT_DESCRIPTION_TYMPANUM = 9, /**< Tympanum (ear drum) */
} e_ble_htc_temp_type_temperature_text_description_t;

/***************************************************************************//**
 * @brief Temperature Type attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
} st_ble_htc_temp_type_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Temperature Type characteristic value from the remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_HTC_ReadTempType(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief      Get Temperature Type attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_HTC_GetTempTypeAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_htc_temp_type_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Intermediate Temperature Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_HTC_INTERMEDIATE_TEMPERATURE_UUID (0x2A1E)
#define BLE_HTC_INTERMEDIATE_TEMPERATURE_LEN (13)
#define BLE_HTC_INTERMEDIATE_TEMPERATURE_CLI_CNFG_UUID (0x2902)
#define BLE_HTC_INTERMEDIATE_TEMPERATURE_CLI_CNFG_LEN (2)

/*******************************************************************************************************************//**
 * @brief Intermediate Temperature characteristic parameters.
 ***********************************************************************************************************************/
typedef struct {
    st_ble_htc_temp_meas_t temp_meas;
} st_ble_htc_intermediate_temperature_t;

/***************************************************************************//**
 * @brief Intermediate Temperature attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
    uint16_t cli_cnfg_desc_hdl;
} st_ble_htc_intermediate_temperature_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Intermediate Temperature characteristic Client Characteristic Configuration descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_HTC_ReadIntermediateTemperatureCliCnfg(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Intermediate Temperature characteristic Client Characteristic Configuration descriptor value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value Intermediate Temperature characteristic Client Characteristic Configuration descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_HTC_WriteIntermediateTemperatureCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief      Get Intermediate Temperature attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_HTC_GetIntermediateTemperatureAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_htc_intermediate_temperature_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Measurement Interval Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_HTC_MEAS_INTERVAL_UUID (0x2A21)
#define BLE_HTC_MEAS_INTERVAL_LEN (2)
#define BLE_HTC_MEAS_INTERVAL_CLI_CNFG_UUID (0x2902)
#define BLE_HTC_MEAS_INTERVAL_CLI_CNFG_LEN (2)
#define BLE_HTC_MEAS_INTERVAL_VALID_RANGE_UUID (0x2906)
#define BLE_HTC_MEAS_INTERVAL_VALID_RANGE_LEN (4)


/***************************************************************************//**
 * @brief Valid Range value structure.
*******************************************************************************/
#ifndef R_BLE_HTS_H
typedef struct {
    uint16_t lower_inclusive_value; /**< Lower inclusive value */
    uint16_t upper_inclusive_value; /**< Upper inclusive value */
} st_ble_meas_interval_valid_range_t;
#endif /* R_BLE_HTS_H */

/***************************************************************************//**
 * @brief Measurement Interval attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
    uint16_t cli_cnfg_desc_hdl;
    uint16_t valid_range_desc_hdl;
} st_ble_htc_meas_interval_attr_hdl_t;

/***************************************************************************//**
 * @brief     Read Measurement Interval characteristic Client Characteristic Configuration descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_HTC_ReadMeasIntervalCliCnfg(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Measurement Interval characteristic Client Characteristic Configuration descriptor value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value Measurement Interval characteristic Client Characteristic Configuration descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_HTC_WriteMeasIntervalCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief     Read Measurement Interval characteristic Valid Range descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_HTC_ReadMeasIntervalValidRange(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Read Measurement Interval characteristic value from the remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_HTC_ReadMeasInterval(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief     Write Measurement Interval characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] p_value Measurement Interval characteristic value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_HTC_WriteMeasInterval(uint16_t conn_hdl, const uint16_t *p_value);
;
/***************************************************************************//**
 * @brief      Get Measurement Interval attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_HTC_GetMeasIntervalAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_htc_meas_interval_attr_hdl_t *p_hdl);


/*----------------------------------------------------------------------------------------------------------------------
    Health Thermometer Service Client
----------------------------------------------------------------------------------------------------------------------*/

/***************************************************************************//**
 * @brief The value is considered invalid and outside of the range allowed by the charateristic.
*******************************************************************************/
#define BLE_HTC_OUT_OF_RANGE_ERROR (BLE_ERR_GROUP_GATT | 0x80)

/***************************************************************************//**
 * @brief Health Thermometer Service client event data.
*******************************************************************************/
typedef struct {
    uint16_t    conn_hdl;  /**< Connection handle */
    uint16_t    param_len; /**< Event parameter length */
    const void *p_param;   /**< Event parameter */
} st_ble_htc_evt_data_t;

/***************************************************************************//**
 * @brief Health Thermometer Service characteristic ID.
*******************************************************************************/
typedef enum {
    BLE_HTC_TEMP_MEAS_IDX,
    BLE_HTC_TEMP_MEAS_CLI_CNFG_IDX,
    BLE_HTC_TEMP_TYPE_IDX,
    BLE_HTC_INTERMEDIATE_TEMPERATURE_IDX,
    BLE_HTC_INTERMEDIATE_TEMPERATURE_CLI_CNFG_IDX,
    BLE_HTC_MEAS_INTERVAL_IDX,
    BLE_HTC_MEAS_INTERVAL_CLI_CNFG_IDX,
    BLE_HTC_MEAS_INTERVAL_VALID_RANGE_IDX,
} e_ble_htc_char_idx_t;

/***************************************************************************//**
 * @brief Health Thermometer Service client event type.
*******************************************************************************/
typedef enum {
    /* Temperature Measurement */
    BLE_HTC_EVENT_TEMP_MEAS_HDL_VAL_IND = BLE_SERVC_ATTR_EVENT(BLE_HTC_TEMP_MEAS_IDX, BLE_SERVC_HDL_VAL_IND),
    BLE_HTC_EVENT_TEMP_MEAS_CLI_CNFG_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_HTC_TEMP_MEAS_CLI_CNFG_IDX, BLE_SERVC_READ_RSP),
    BLE_HTC_EVENT_TEMP_MEAS_CLI_CNFG_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_HTC_TEMP_MEAS_CLI_CNFG_IDX, BLE_SERVC_WRITE_RSP),
    /* Temperature Type */
    BLE_HTC_EVENT_TEMP_TYPE_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_HTC_TEMP_TYPE_IDX, BLE_SERVC_READ_RSP),
    /* Intermediate Temperature */
    BLE_HTC_EVENT_INTERMEDIATE_TEMPERATURE_HDL_VAL_NTF = BLE_SERVC_ATTR_EVENT(BLE_HTC_INTERMEDIATE_TEMPERATURE_IDX, BLE_SERVC_HDL_VAL_NTF),
    BLE_HTC_EVENT_INTERMEDIATE_TEMPERATURE_CLI_CNFG_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_HTC_INTERMEDIATE_TEMPERATURE_CLI_CNFG_IDX, BLE_SERVC_READ_RSP),
    BLE_HTC_EVENT_INTERMEDIATE_TEMPERATURE_CLI_CNFG_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_HTC_INTERMEDIATE_TEMPERATURE_CLI_CNFG_IDX, BLE_SERVC_WRITE_RSP),
    /* Measurement Interval */
    BLE_HTC_EVENT_MEAS_INTERVAL_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_HTC_MEAS_INTERVAL_IDX, BLE_SERVC_READ_RSP),
    BLE_HTC_EVENT_MEAS_INTERVAL_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_HTC_MEAS_INTERVAL_IDX, BLE_SERVC_WRITE_RSP),
    BLE_HTC_EVENT_MEAS_INTERVAL_HDL_VAL_IND = BLE_SERVC_ATTR_EVENT(BLE_HTC_MEAS_INTERVAL_IDX, BLE_SERVC_HDL_VAL_IND),
    BLE_HTC_EVENT_MEAS_INTERVAL_CLI_CNFG_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_HTC_MEAS_INTERVAL_CLI_CNFG_IDX, BLE_SERVC_READ_RSP),
    BLE_HTC_EVENT_MEAS_INTERVAL_CLI_CNFG_WRITE_RSP = BLE_SERVC_ATTR_EVENT(BLE_HTC_MEAS_INTERVAL_CLI_CNFG_IDX, BLE_SERVC_WRITE_RSP),
    BLE_HTC_EVENT_MEAS_INTERVAL_VALID_RANGE_READ_RSP = BLE_SERVC_ATTR_EVENT(BLE_HTC_MEAS_INTERVAL_VALID_RANGE_IDX, BLE_SERVC_READ_RSP),
} e_ble_htc_event_t;

/***************************************************************************//**
 * @brief     Initialize Health Thermometer Service client.
 * @param[in] cb Client callback.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_HTC_Init(ble_servc_app_cb_t cb);

/***************************************************************************//**
 * @brief     Health Thermometer Service client discovery callback.
 * @param[in] conn_hdl Connection handle
 * @param[in] serv_idx Service instance index.
 * @param[in] type     Service discovery event type.
 * @param[out] p_param  Service discovery event parameter.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_HTC_ServDiscCb(uint16_t conn_hdl, uint8_t serv_idx, uint16_t type, void *p_param);

/***************************************************************************//**
 * @brief     Get Health Thermometer Service client attribute handle.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
*******************************************************************************/
void R_BLE_HTC_GetServAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_gatt_hdl_range_t *p_hdl);

#endif /* R_BLE_HTC_H */

/** @} */
