/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_anc.h
 * Version : 1.0
 * Description : The header file for Alert Notification Service client.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 20.12.2019 1.00 First Release
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @file
 * @defgroup anc Alert Notification Service Client
 * @{
 * @ingroup profile
 * @brief   This is the client for the Alert Notification Service Service.
 **********************************************************************************************************************/
#include "profile_cmn/r_ble_servc_if.h"

#ifndef R_BLE_ANC_H
#define R_BLE_ANC_H

/*******************************************************************************************************************//**
  * @brief New Alert Text length.
 ***********************************************************************************************************************/
#define BLE_ANC_NEW_ALERT_TEXT_LEN                          (18)

/*----------------------------------------------------------------------------------------------------------------------
    Supported New Alert Category Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_ANC_SUPPORTED_NEW_ALERT_CATEGORY_UUID           (0x2A47)
#define BLE_ANC_SUPPORTED_NEW_ALERT_CATEGORY_LEN            (2)

/***************************************************************************//**
 * @brief Supported New Alert Category value structure.
*******************************************************************************/
typedef struct 
{
    bool is_simple_alert;                   /**< is simple alert */
    bool is_email;                          /**< Is email */
    bool is_news;                           /**< is news */
    bool is_call;                           /**< is call */
    bool is_sms_mms;                        /**< is sms mms */
    bool is_missed_call;                    /**< is missed call */
    bool is_voice_mail;                     /**< is voice mail */
    bool is_schedule;                       /**< is schedule */
    bool is_high_prioritized_alert;         /**< is high prioritized alert */
    bool is_instant_message;                /**< is instant message */
} st_ble_anc_supported_new_alert_category_t;

/***************************************************************************//**
 * @brief Supported New Alert Category attribute handle value.
*******************************************************************************/
typedef struct 
{
    st_ble_gatt_hdl_range_t range;
} st_ble_anc_supported_new_alert_category_attr_hdl_t;

/***************************************************************************//**
 * @brief               Read Supported New Alert Category characteristic value from the remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @return              @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ANC_ReadSupported_new_alert_category(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief               Get Supported New Alert Category attribute handles.
 * @param[in]  p_addr   The pointer to Bluetooth device address for the attribute handles.
 * @param[out] p_hdl    The pointer to store  supported new alert category attribute handles.
 * @return              @ref ble_status_t
*******************************************************************************/
void R_BLE_ANC_GetSupported_new_alert_categoryAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_anc_supported_new_alert_category_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    New Alert Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_ANC_NEW_ALERT_UUID              (0x2A46)
#define BLE_ANC_NEW_ALERT_LEN               (2)
#define BLE_ANC_NEW_ALERT_CLI_CNFG_UUID     (0x2902)
#define BLE_ANC_NEW_ALERT_CLI_CNFG_LEN      (2)

/***************************************************************************//**
 * @brief New Alert value structure.
*******************************************************************************/
typedef struct 
{
    uint8_t category_id;                                              /**< Category ID */
    uint8_t number_of_new_alert;                                      /**< Number of New Alert */
    uint8_t text_string_information[BLE_ANC_NEW_ALERT_TEXT_LEN];      /**< Text String Information */
} st_ble_anc_new_alert_t;

/***************************************************************************//**
 * @brief New Alert attribute handle value.
*******************************************************************************/
typedef struct
{
    st_ble_gatt_hdl_range_t range;
    uint16_t cli_cnfg_desc_hdl;
} st_ble_anc_new_alert_attr_hdl_t;

/***************************************************************************//**
 * @brief        Read New Alert characteristic Client Characteristic Configuration descriptor value from the remote GATT database.
 * @param[in]    conn_hdl Connection handle.
 * @return       @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ANC_ReadNew_alertCliCnfg(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief                  Write New Alert characteristic Client Characteristic Configuration descriptor value to remote GATT database.
 * @param[in]   conn_hdl   Connection handle.
 * @param[in]   p_value    The pointer to New Alert characteristic Client Characteristic Configuration descriptor value to write.
 * @return                 @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ANC_WriteNew_alertCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief              Get New Alert attribute handles.
 * @param[in]  p_addr  The pointer to Bluetooth device address for the attribute handles.
 * @param[out] p_hdl   The pointer to store the retrieved new alert attribute handles.
 * @return             @ref ble_status_t
*******************************************************************************/
void R_BLE_ANC_GetNew_alertAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_anc_new_alert_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Supported Unread Alert Category Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_ANC_SUPPORTED_UNREAD_ALERT_CATEGORY_UUID  (0x2A48)
#define BLE_ANC_SUPPORTED_UNREAD_ALERT_CATEGORY_LEN   (2)

/***************************************************************************//**
 * @brief Supported Unread Alert Category value structure.
*******************************************************************************/
typedef struct 
{
    bool is_simple_alert;                  /**< is simple alert */
    bool is_email;                         /**< Is email */
    bool is_news;                          /**< is news */
    bool is_call;                          /**< is call */
    bool is_sms_mms;                       /**< is sms mms */
    bool is_missed_call;                   /**< is missed call */
    bool is_voice_mail;                    /**< is voice mail */
    bool is_schedule;                      /**< is schedule */
    bool is_high_prioritized_alert;        /**< is high prioritized alert */
    bool is_instant_message;               /**< is instant message */
} st_ble_anc_supported_unread_alert_category_t;

/***************************************************************************//**
 * @brief Supported Unread Alert Category attribute handle value.
*******************************************************************************/
typedef struct 
{
    st_ble_gatt_hdl_range_t range;
} st_ble_anc_supported_unread_alert_category_attr_hdl_t;

/*********************************************************************************//**
 * @brief               Read Supported Unread Alert Category characteristic value from the remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @return              @ref ble_status_t
***************************************************************************************/
ble_status_t R_BLE_ANC_ReadSupported_unread_alert_category(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief               Get Supported Unread Alert Category attribute handles.
 * @param[in]  p_addr   The pointer to Bluetooth device address for the attribute handles.
 * @param[out] p_hdl    The pointer to store the retrieved supported unread alert category attribute handles.
 * @return              @ref ble_status_t
*******************************************************************************/
void R_BLE_ANC_GetSupported_unread_alert_categoryAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_anc_supported_unread_alert_category_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Unread Alert Status Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_ANC_UNREAD_ALERT_STATUS_UUID           (0x2A45)
#define BLE_ANC_UNREAD_ALERT_STATUS_LEN            (2)
#define BLE_ANC_UNREAD_ALERT_STATUS_CLI_CNFG_UUID  (0x2902)
#define BLE_ANC_UNREAD_ALERT_STATUS_CLI_CNFG_LEN   (2)

/***************************************************************************//**
 * @brief Unread Alert Status value structure.
*******************************************************************************/
typedef struct 
{
    uint8_t category_id;        /**< Category ID */
    uint8_t unread_count;       /**< Unread count */
} st_ble_anc_unread_alert_status_t;

/***************************************************************************//**
 * @brief Unread Alert Status attribute handle value.
*******************************************************************************/
typedef struct 
{
    st_ble_gatt_hdl_range_t range;
    uint16_t cli_cnfg_desc_hdl;
} st_ble_anc_unread_alert_status_attr_hdl_t;

/***************************************************************************//**
 * @brief                Read Unread Alert Status characteristic Client Characteristic Configuration descriptor value from the remote GATT database.
 * @param[in] conn_hdl   Connection handle.
 * @return               @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ANC_ReadUnread_alert_statusCliCnfg(uint16_t conn_hdl);

/***************************************************************************//**
 * @brief                Write Unread Alert Status characteristic Client Characteristic Configuration descriptor value to remote GATT database.
 * @param[in] conn_hdl   Connection handle.
 * @param[in] p_value    The pointer to Unread Alert Status characteristic Client Characteristic Configuration descriptor value to write.
 * @return               @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ANC_WriteUnread_alert_statusCliCnfg(uint16_t conn_hdl, const uint16_t *p_value);

/***************************************************************************//**
 * @brief              Get Unread Alert Status attribute handles.
 * @param[in]  p_addr  The pointer to Bluetooth device address for the attribute handles.
 * @param[out] p_hdl   The pointer to store the retrieved unread alert status attribute handles.
 * @return             @ref ble_status_t
*******************************************************************************/
void R_BLE_ANC_GetUnread_alert_statusAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_anc_unread_alert_status_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Alert Notification Control Point Characteristic
----------------------------------------------------------------------------------------------------------------------*/
#define BLE_ANC_ALERT_NOTIFICATION_CONTROL_POINT_UUID      (0x2A44)
#define BLE_ANC_ALERT_NOTIFICATION_CONTROL_POINT_LEN       (2)

/***************************************************************************//**
 * @brief Alert Notification Control Point Command ID enumeration.
*******************************************************************************/
typedef enum 
{
    BLE_ANC_ALERT_NOTIFICATION_CONTROL_POINT_COMMAND_ID_ENABLE_NEW_INCOMING_ALERT_NOTIFICATION           = 0, /**< Enable New Incoming Alert Notification */
    BLE_ANC_ALERT_NOTIFICATION_CONTROL_POINT_COMMAND_ID_ENABLE_UNREAD_CATEGORY_STATUS_NOTIFICATION       = 1, /**< Enable Unread Category Status Notification */
    BLE_ANC_ALERT_NOTIFICATION_CONTROL_POINT_COMMAND_ID_DISABLE_NEW_INCOMING_ALERT_NOTIFICATION          = 2, /**< Disable New Incoming Alert Notification */
    BLE_ANC_ALERT_NOTIFICATION_CONTROL_POINT_COMMAND_ID_DISABLE_UNREAD_CATEGORY_STATUS_NOTIFICATION      = 3, /**< Disable Unread Category Status Notification */
    BLE_ANC_ALERT_NOTIFICATION_CONTROL_POINT_COMMAND_ID_NOTIFY_NEW_INCOMING_ALERT_IMMEDIATELY            = 4, /**< Notify New Incoming Alert immediately */
    BLE_ANC_ALERT_NOTIFICATION_CONTROL_POINT_COMMAND_ID_NOTIFY_UNREAD_CATEGORY_STATUS_IMMEDIATELY        = 5, /**< Notify Unread Category Status immediately */
} e_ble_anc_alert_notification_control_point_command_id_t;

/***************************************************************************//**
 * @brief Alert Notification Control Point Category ID enumeration.
*******************************************************************************/
typedef enum {
    BLE_ANC_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_SIMPLE_ALERT__GENERAL_TEXT_ALERT_OR_NON_TEST_ALERT                         = 0,   /**< Simple Alert: General or non */
    BLE_ANC_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_EMAIL__ALERT_WHEN_EMAIL_MESSAGES_ARRIVES                                   = 1,   /**< Email: Alert when Email messages arrives */
    BLE_ANC_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_NEWS_NEWS_FEEDS_SUCH_AS_RSS_ATOM                                           = 2,   /**< News: News feeds such as RSS, Atom */
    BLE_ANC_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_CALL_INCOMING_CALL                                                         = 3,   /**< Call: Incoming call  */
    BLE_ANC_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_MISSED_CALL_MISSED_CALL                                                    = 4,   /**< Missed call: Missed Call */
    BLE_ANC_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_SMS_MMS__SMS_MMS_MESSAGES_ARRIVES                                          = 5,   /**< SMS/MMS: SMS/MMS message arrives */
    BLE_ANC_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_VOICE_MAIL__VOICE_MAIL                                                     = 6,   /**< Voice mail: Voice mail */
    BLE_ANC_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_SCHEDULE__ALERT_OCCURED_ON_CALENDAR_PLANNER                                = 7,   /**< Schedule: Alert occurred on calendar, planner */
    BLE_ANC_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_HIGH_PRIORITIDED_ALERT__ALERT_THAT_SHOULD_BE_HANDLED_AS_HIGH_PRIORITY      = 8,   /**< High Prioritized Alert: Alert that should be handled as high priority */
    BLE_ANC_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_INSTANT_MESSAGE_ALERT_FOR_INCOMING_INSTANT_MESSAGES                        = 9,   /**< Instant Message: Alert for incoming instant messages */
    BLE_ANC_ALERT_NOTIFICATION_CONTROL_POINT_CATEGORY_ID_ALL                                                                        = 255, /**< Category ID: All category(0xff) */
} e_ble_anc_alert_notification_control_point_category_id_t;

/***************************************************************************//**
 * @brief Alert Notification Control Point value structure.
*******************************************************************************/
typedef struct 
{
    uint8_t command_id;      /**< Command ID */
    uint8_t category_id;     /**< Category ID */
} st_ble_anc_alert_notification_control_point_t;

/***************************************************************************//**
 * @brief Alert Notification Control Point attribute handle value.
*******************************************************************************/
typedef struct 
{
    st_ble_gatt_hdl_range_t range;
} st_ble_anc_alert_notification_control_point_attr_hdl_t;

/***************************************************************************//**
 * @brief                Write Alert Notification Control Point characteristic value to remote GATT database.
 * @param[in] conn_hdl   Connection handle.
 * @param[in] p_value    The pointer to Alert Notification Control Point characteristic value to write.
 * @return               @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ANC_WriteAlertNotificationControlPoint(uint16_t conn_hdl, const st_ble_anc_alert_notification_control_point_t *p_value);

/***************************************************************************//**
 * @brief              Get Alert Notification Control Point attribute handles.
 * @param[in]  p_addr  The pointer to Bluetooth device address for the attribute handles.
 * @param[out] p_hdl   The pointer to store the retrieved control point attribute handles.
 * @return             @ref ble_status_t
*******************************************************************************/
void R_BLE_ANC_GetAlertNotificationControlPointAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_anc_alert_notification_control_point_attr_hdl_t *p_hdl);

/*----------------------------------------------------------------------------------------------------------------------
    Alert Notification Service Client
----------------------------------------------------------------------------------------------------------------------*/

/***************************************************************************//**
 * @brief command not supported
*******************************************************************************/
#define BLE_ANC_COMMAND_NOT_SUPPORTED_ERROR    (BLE_ERR_GROUP_GATT | 0xA0)

/***************************************************************************//**
 * @brief Alert Notification Service client event data.
*******************************************************************************/
typedef struct 
{
    uint16_t    conn_hdl;    /**< Connection handle */
    uint16_t    param_len;   /**< Event parameter length */
    const void *p_param;     /**< Event parameter */
} st_ble_anc_evt_data_t;

/***************************************************************************//**
 * @brief Alert Notification Service characteristic ID.
*******************************************************************************/
typedef enum 
{
    BLE_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IDX,
    BLE_ANC_NEW_ALERT_IDX,
    BLE_ANC_NEW_ALERT_CLI_CNFG_IDX,
    BLE_ANC_SUPPORTED_UNREAD_ALERT_CATEGORY_IDX,
    BLE_ANC_UNREAD_ALERT_STATUS_IDX,
    BLE_ANC_UNREAD_ALERT_STATUS_CLI_CNFG_IDX,
    BLE_ANC_ALERT_NOTIFICATION_CONTROL_POINT_IDX,
} e_ble_anc_char_idx_t;

/***************************************************************************//**
 * @brief Alert Notification Service client event type.
*******************************************************************************/
typedef enum
{
    /* Supported New Alert Category */
    BLE_ANC_EVENT_SUPPORTED_NEW_ALERT_CATEGORY_READ_RSP       = BLE_SERVC_ATTR_EVENT(BLE_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IDX, BLE_SERVC_READ_RSP),

    /* New Alert */
    BLE_ANC_EVENT_NEW_ALERT_HDL_VAL_NTF                       = BLE_SERVC_ATTR_EVENT(BLE_ANC_NEW_ALERT_IDX, BLE_SERVC_HDL_VAL_NTF),
    BLE_ANC_EVENT_NEW_ALERT_CLI_CNFG_READ_RSP                 = BLE_SERVC_ATTR_EVENT(BLE_ANC_NEW_ALERT_CLI_CNFG_IDX, BLE_SERVC_READ_RSP),
    BLE_ANC_EVENT_NEW_ALERT_CLI_CNFG_WRITE_RSP                = BLE_SERVC_ATTR_EVENT(BLE_ANC_NEW_ALERT_CLI_CNFG_IDX, BLE_SERVC_WRITE_RSP),

    /* Supported Unread Alert Category */
    BLE_ANC_EVENT_SUPPORTED_UNREAD_ALERT_CATEGORY_READ_RSP    = BLE_SERVC_ATTR_EVENT(BLE_ANC_SUPPORTED_UNREAD_ALERT_CATEGORY_IDX, BLE_SERVC_READ_RSP),

    /* Unread Alert Status */
    BLE_ANC_EVENT_UNREAD_ALERT_STATUS_HDL_VAL_NTF             = BLE_SERVC_ATTR_EVENT(BLE_ANC_UNREAD_ALERT_STATUS_IDX, BLE_SERVC_HDL_VAL_NTF),
    BLE_ANC_EVENT_UNREAD_ALERT_STATUS_CLI_CNFG_READ_RSP       = BLE_SERVC_ATTR_EVENT(BLE_ANC_UNREAD_ALERT_STATUS_CLI_CNFG_IDX, BLE_SERVC_READ_RSP),
    BLE_ANC_EVENT_UNREAD_ALERT_STATUS_CLI_CNFG_WRITE_RSP      = BLE_SERVC_ATTR_EVENT(BLE_ANC_UNREAD_ALERT_STATUS_CLI_CNFG_IDX, BLE_SERVC_WRITE_RSP),

    /* Alert Notification Control Point */
    BLE_ANC_EVENT_ALERT_NOTIFICATION_CONTROL_POINT_WRITE_RSP  = BLE_SERVC_ATTR_EVENT(BLE_ANC_ALERT_NOTIFICATION_CONTROL_POINT_IDX, BLE_SERVC_WRITE_RSP),
} e_ble_anc_event_t;

/***************************************************************************//**
 * @brief          Initialize Alert Notification Service client.
 * @param[in] cb   Client callback.
 * @return         @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_ANC_Init(ble_servc_app_cb_t cb);

/***************************************************************************//**
 * @brief               Alert Notification Service client discovery callback.
 * @param[in] conn_hdl  Connection handle
 * @param[in] serv_idx  Service instance index.
 * @param[in] type      Service discovery event type.
 * @param[out] p_param  The pointer to Service discovery event parameter.
 * @return              @ref ble_status_t
*******************************************************************************/
void R_BLE_ANC_ServDiscCb(uint16_t conn_hdl, uint8_t serv_idx, uint16_t type, void *p_param);

/***************************************************************************//**
 * @brief               Get Alert Notification Service client attribute handle.
 * @param[in]  p_addr   The pointer to Bluetooth device address for the attribute handles.
 * @param[out] p_hdl    The pointer to store the retrieved attribute handles.
*******************************************************************************/
void R_BLE_ANC_GetServAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_gatt_hdl_range_t *p_hdl);

#endif /* R_BLE_ANC_H */

/** @} */
