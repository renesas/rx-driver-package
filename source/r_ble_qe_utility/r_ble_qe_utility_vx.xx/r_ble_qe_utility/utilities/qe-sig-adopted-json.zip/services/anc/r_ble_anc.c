/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_anc.c
 * Version : 1.0
 * Description : This module implements Alert Notification Service Client.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 24.05.2019 1.00 First Release
 ***********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <string.h>
#include "r_ble_rx23w_if.h"
#include "r_ble_anc.h"
#include "discovery/r_ble_disc.h"

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
#define BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_SIMPLE_ALERT                                        ( 1 << 0 )
#define BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_EMAIL                                               ( 1 << 1 )
#define BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_NEWS                                                ( 1 << 2 )
#define BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_CALL                                                ( 1 << 3 )
#define BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_MISSED_CALL                                         ( 1 << 4 )
#define BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_SMS_MMS                                             ( 1 << 5 )
#define BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_VOICE_MAIL                                          ( 1 << 6 )
#define BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_SCHEDULE                                            ( 1 << 7 )
#define BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_HIGH_PRIORITIZED_ALERT                              ( 1 << 8 )
#define BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_INSTANT_MESSAGE                                     ( 1 << 9 )

#define BLE_ANC_PRV_ANC_SUPPORTED                                                                           (true)
#define BLE_ANC_PRV_ANC_NOTSUPPORTED                                                                        (false)

/* Version number */
#define BLE_ANC_PRV_VERSION_MAJOR                                                                           (1)
#define BLE_ANC_PRV_VERSION_MINOR                                                                           (0)

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/
typedef struct
{
    uint16_t conn_hdl;
    st_ble_anc_hdls_t hdls;
} st_anc_peer_param_t;

/***********************************************************************************************************************
Exported global variables (to be accessed by other files)
***********************************************************************************************************************/
const uint8_t BLE_ANC_UUID[BLE_GATT_16_BIT_UUID_SIZE]                                                 = { 0x11, 0x18 };
const uint8_t BLE_ANC_SUPPORTED_NEW_ALERT_CATEGORY_UUID[BLE_GATT_16_BIT_UUID_SIZE]                    = { 0x47, 0x2A };
const uint8_t BLE_ANC_NEW_ALERT_UUID[BLE_GATT_16_BIT_UUID_SIZE]                                       = { 0x46, 0x2A };
const uint8_t BLE_ANC_NEW_ALERT_CLIENT_CHARACTERISTIC_CONFIGURATION_UUID[BLE_GATT_16_BIT_UUID_SIZE]   = { 0x02, 0x29 };
const uint8_t BLE_ANC_SUPPORTED_UNREAD_ALERT_CATEGORY_UUID[BLE_GATT_16_BIT_UUID_SIZE]                 = { 0x48, 0x2A };
const uint8_t BLE_ANC_UNREAD_ALERT_STATUS_UUID[BLE_GATT_16_BIT_UUID_SIZE]                             = { 0x45, 0x2A };
const uint8_t BLE_ANC_UNREAD_ALERT_STATUS_CLIENT_CHARACTERISTIC_CONFIGURATION_UUID[BLE_GATT_16_BIT_UUID_SIZE]    = 
                                                                                                        { 0x02, 0x29 };
const uint8_t BLE_ANC_ALERT_NOTIFICATION_CONTROL_POINT_UUID[BLE_GATT_16_BIT_UUID_SIZE]                = { 0x44, 0x2A };

/***********************************************************************************************************************
Private global variables and functions
***********************************************************************************************************************/
static st_anc_peer_param_t gs_peer_params[7];
static ble_anc_app_cb_t gs_anc_cb;

/***********************************************************************************************************************
 * Function Name: find_peer_param
 * Description  : This function finds the attribute handles for the given connection handle.
 * Arguments    : conn_hdl - handle to connection
 * Return Value : pointer to the attribute handles structure
 **********************************************************************************************************************/
static st_anc_peer_param_t *find_peer_param(uint16_t conn_hdl)
{
    for (uint8_t i = 0; i < 7; i++)
    {
        if ((BLE_GAP_INVALID_CONN_HDL != gs_peer_params[i].conn_hdl) &&
            (gs_peer_params[i].conn_hdl == conn_hdl))
        {
            return &gs_peer_params[i];
        }
    }
    return NULL;
}
/* End of function find_peer_param */

/***********************************************************************************************************************
 * Function Name: get_new_peer_param
 * Description  : This function finds the free attribute handle.
 * Arguments    : conn_hdl - handle to connection.
 * Return Value : pointer to the free attribute handles structure
 **********************************************************************************************************************/
static st_anc_peer_param_t *get_new_peer_param(uint16_t conn_hdl)
{
    for (uint8_t i = 0; i < 7; i++)
    {
        if (BLE_GAP_INVALID_CONN_HDL == gs_peer_params[i].conn_hdl)
        {
            gs_peer_params[i].conn_hdl = conn_hdl;
            return &gs_peer_params[i];
        }
    }
    return NULL;
}
/* End of function get_new_peer_param */

/***********************************************************************************************************************
 * Function Name: clear_peer_param
 * Description  : This function frees all the attribute handles.
 * Arguments    : p_peer - pointer to the attribute handle structure to be freed
 * Return Value : none
***********************************************************************************************************************/
static void clear_peer_param(st_anc_peer_param_t *p_peer)
{
    if (NULL != p_peer)
    {
        p_peer->conn_hdl = BLE_GAP_INVALID_CONN_HDL;
        memset(&p_peer->hdls, 0x00, sizeof(p_peer->hdls));
    }
}
/* End of function clear_peer_param */

/***********************************************************************************************************************
 * Function Name: decode_supported_new_alert_category
 * Description  : This function converts Supported New Alert Category characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the Supported New Alert Category value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_supported_new_alert_category(st_ble_anc_supported_new_alert_category_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{

    uint16_t flag = 0;
    
    BT_UNPACK_LE_2_BYTE(&flag, &p_gatt_value->p_value[0]);
   
    /* check the length */
    if (BLE_ANC_SUPPORTED_NEW_ALERT_CATEGORY_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Clear the feature bit flags */
    memset((uint8_t*)p_app_value, 0x00, sizeof(st_ble_anc_supported_new_alert_category_t));

    /* Simple alert supported bit */
    if ((flag & BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_SIMPLE_ALERT))
    {
        p_app_value->is_simple_alert = BLE_ANC_PRV_ANC_SUPPORTED;
    }
    else
    {
        p_app_value->is_simple_alert = BLE_ANC_PRV_ANC_NOTSUPPORTED;
    }

    /* Email field supported bit */
    if ((flag & BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_EMAIL))
    {
        p_app_value->is_email = BLE_ANC_PRV_ANC_SUPPORTED;
    }
    else
    {
        p_app_value->is_email = BLE_ANC_PRV_ANC_NOTSUPPORTED;
    }

    /* News field supported bit */
    if ((flag & BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_NEWS))
    {
        p_app_value->is_news = BLE_ANC_PRV_ANC_SUPPORTED;
    }
    else
    {
        p_app_value->is_news = BLE_ANC_PRV_ANC_NOTSUPPORTED;
    }

    /* Call field supported bit */
    if ((flag & BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_CALL))
    {
        p_app_value->is_call = BLE_ANC_PRV_ANC_SUPPORTED;
    }
    else
    {
        p_app_value->is_call = BLE_ANC_PRV_ANC_NOTSUPPORTED;
    }

    /* Missed Call field supported bit */
    if ((flag & BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_MISSED_CALL))
    {
        p_app_value->is_missed_call = BLE_ANC_PRV_ANC_SUPPORTED;
    }
    else
    {
        p_app_value->is_missed_call = BLE_ANC_PRV_ANC_NOTSUPPORTED;
    }

    /* SMS MMS field supported bit */
    if ((flag & BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_SMS_MMS))
    {
        p_app_value->is_sms_mms = BLE_ANC_PRV_ANC_SUPPORTED;
    }
    else
    {
        p_app_value->is_sms_mms = BLE_ANC_PRV_ANC_NOTSUPPORTED;
    }

    /* Voice Mail field supported bit */
    if ((flag & BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_VOICE_MAIL))
    {
        p_app_value->is_voice_mail = BLE_ANC_PRV_ANC_SUPPORTED;
    }
    else
    {
        p_app_value->is_voice_mail = BLE_ANC_PRV_ANC_NOTSUPPORTED;
    }

    /* Schedule field supported bit */
    if ((flag & BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_SCHEDULE))
    {
        p_app_value->is_schedule = BLE_ANC_PRV_ANC_SUPPORTED;
    }
    else
    {
        p_app_value->is_schedule = BLE_ANC_PRV_ANC_NOTSUPPORTED;
    }

    /* High Prioritized Alert field supported bit */
    if ((flag & BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_HIGH_PRIORITIZED_ALERT))
    {
        p_app_value->is_high_prioritized_alert = BLE_ANC_PRV_ANC_SUPPORTED;
    }
    else
    {
        p_app_value->is_high_prioritized_alert = BLE_ANC_PRV_ANC_NOTSUPPORTED;
    }

    /* Instant Message field supported bit */
    if ((flag & BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_INSTANT_MESSAGE))
    {
        p_app_value->is_instant_message = BLE_ANC_PRV_ANC_SUPPORTED;
    }
    else
    {
        p_app_value->is_instant_message = BLE_ANC_PRV_ANC_NOTSUPPORTED;
    }

    return BLE_SUCCESS;
}
/* End of function decode_supported_new_alert_category */

/***********************************************************************************************************************
 * Function Name: decode_new_alert
 * Description  : This function converts New Alert characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the New Alert value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_new_alert(st_ble_anc_new_alert_t *p_app_value,  st_ble_gatt_value_t *p_gatt_value)
{
    /*Convert byte sequence to app data*/
    uint8_t pos = 0;

    memset(p_app_value, 0x00, sizeof(st_ble_anc_new_alert_t));

    BT_UNPACK_LE_1_BYTE(&p_app_value->category_id, &p_gatt_value->p_value[pos]);
    pos += 1;

    BT_UNPACK_LE_1_BYTE(&p_app_value->number_of_new_alert, &p_gatt_value->p_value[pos]);
    pos += 1;

    for (uint8_t i = 0; i < BLE_ANC_NEW_ALERT_TEXT_LEN; i++)
    {
        BT_UNPACK_LE_1_BYTE(&p_app_value->text_string_information[i], &p_gatt_value->p_value[pos]);
        pos += 1;
    }

    return BLE_SUCCESS;
}
/* End of function decode_new_alert */

/***********************************************************************************************************************
 * Function Name: decode_supported_unread_alert_category
 * Description  : This function converts Supported Unread Alert Category characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the Supported Unread Alert Category value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_supported_unread_alert_category(st_ble_anc_supported_unread_alert_category_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint16_t flag = 0;
  
    BT_UNPACK_LE_2_BYTE(&flag, &p_gatt_value->p_value[0]);

    /* check the length */
    if (BLE_ANC_SUPPORTED_UNREAD_ALERT_CATEGORY_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Clear the feature bit flags */
    memset((uint8_t*)p_app_value, 0x00, sizeof(st_ble_anc_supported_unread_alert_category_t));

    /* simple alert supported bit */
    if ((flag & BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_SIMPLE_ALERT))
    {
        p_app_value->is_simple_alert = BLE_ANC_PRV_ANC_SUPPORTED;
    }
    else
    {
        p_app_value->is_simple_alert = BLE_ANC_PRV_ANC_NOTSUPPORTED;
    }

    /* Email field supported bit */
    if ((flag & BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_EMAIL))
    {
        p_app_value->is_email = BLE_ANC_PRV_ANC_SUPPORTED;
    }
    else
    {
        p_app_value->is_email = BLE_ANC_PRV_ANC_NOTSUPPORTED;
    }

    /* NEWS field supported bit */
    if ((flag & BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_NEWS))
    {
        p_app_value->is_news = BLE_ANC_PRV_ANC_SUPPORTED;
    }
    else
    {
        p_app_value->is_news = BLE_ANC_PRV_ANC_NOTSUPPORTED;
    }

    /* CALL field supported bit */
    if ((flag & BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_CALL))
    {
        p_app_value->is_call = BLE_ANC_PRV_ANC_SUPPORTED;
    }
    else
    {
        p_app_value->is_call = BLE_ANC_PRV_ANC_NOTSUPPORTED;
    }

    /* MISSED_CALL field supported bit */
    if ((flag & BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_MISSED_CALL))
    {
        p_app_value->is_missed_call = BLE_ANC_PRV_ANC_SUPPORTED;
    }
    else
    {
        p_app_value->is_missed_call = BLE_ANC_PRV_ANC_NOTSUPPORTED;
    }

    /* SMS_MMS field supported bit */
    if ((flag & BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_SMS_MMS))
    {
        p_app_value->is_sms_mms = BLE_ANC_PRV_ANC_SUPPORTED;
    }
    else
    {
        p_app_value->is_sms_mms = BLE_ANC_PRV_ANC_NOTSUPPORTED;
    }

    /* VOICE_MAIL field supported bit */
    if ((flag & BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_VOICE_MAIL))
    {
        p_app_value->is_voice_mail = BLE_ANC_PRV_ANC_SUPPORTED;
    }
    else
    {
        p_app_value->is_voice_mail = BLE_ANC_PRV_ANC_NOTSUPPORTED;
    }

    /* SCHEDULE field supported bit */
    if ((flag & BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_SCHEDULE))
    {
        p_app_value->is_schedule = BLE_ANC_PRV_ANC_SUPPORTED;
    }
    else
    {
        p_app_value->is_schedule = BLE_ANC_PRV_ANC_NOTSUPPORTED;
    }

    /* HIGH_PRIORITIZED_ALERT field supported bit */
    if ((flag & BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_HIGH_PRIORITIZED_ALERT))
    {
        p_app_value->is_high_prioritized_alert = BLE_ANC_PRV_ANC_SUPPORTED;
    }
    else
    {
        p_app_value->is_high_prioritized_alert = BLE_ANC_PRV_ANC_NOTSUPPORTED;
    }

    /* INSTANT_MESSAGE field supported bit */
    if ((flag & BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_INSTANT_MESSAGE))
    {
        p_app_value->is_instant_message = BLE_ANC_PRV_ANC_SUPPORTED;
    }
    else
    {
        p_app_value->is_instant_message = BLE_ANC_PRV_ANC_NOTSUPPORTED;
    }

    return BLE_SUCCESS;
}
/* End of function decode_supported_unread_alert_category */

/***********************************************************************************************************************
 * Function Name: decode_unread_alert_status
 * Description  : This function converts Unread Alert Status characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the Unread Alert Status value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_unread_alert_status(st_ble_anc_unread_alert_status_t *p_app_value,  st_ble_gatt_value_t *p_gatt_value)
{
    /*Convert byte sequence to application data*/
    uint8_t pos = 0;

    if (BLE_ANC_UNREAD_ALERT_STATUS_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    memset(p_app_value, 0x00, sizeof(st_ble_anc_unread_alert_status_t));

    BT_UNPACK_LE_1_BYTE(&p_app_value->category_id, &p_gatt_value->p_value[pos]);
    pos += 1;

    BT_UNPACK_LE_1_BYTE(&p_app_value->unread_count, &p_gatt_value->p_value[pos]);
    pos += 1;

    return BLE_SUCCESS;

}
/* End of function decode_unread_alert_status */


/***********************************************************************************************************************
 * Function Name: encode_alert_notification_control_point
 * Description  : This function converts Alert Notification Control Point characteristic value representation in
 *                application layer (struct) to a characteristic value representation in GATT (uint8_t[]).
 * Arguments    : p_app_value - pointer to the Alert Notification Control Point  value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t encode_alert_notification_control_point(const st_ble_anc_alert_notification_control_point_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    /*Convert app data to byte sequence*/
    uint8_t pos = 0;

    memset(p_gatt_value, 0x00, p_gatt_value->value_len);

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->command_id);
    pos += 1;

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->category_id);
    pos += 1;
    
    p_gatt_value->value_len = pos;

    return BLE_SUCCESS;
}
/* End of function encode_alert_notification_control_point */


/***********************************************************************************************************************
 * Function Name: anc_gattc_cb
 * Description  : Callback function for the Alert Notification Service GATTC events.
 * Arguments    : conn_hdl - handle to the connection
 *                result - ble status
 *              : p_data - pointer to GATTC event data
 * Return Value : none
***********************************************************************************************************************/
static void anc_gattc_cb(uint16_t type, ble_status_t result, st_ble_gattc_evt_data_t *p_data) // @suppress("Function length")
{
    st_anc_peer_param_t *p_peer = find_peer_param(p_data->conn_hdl);

    switch (type)
    {
        case BLE_GATTC_EVENT_CHAR_READ_RSP:
        {
            st_ble_gattc_rd_char_evt_t *p_rd_char_evt_param =
                (st_ble_gattc_rd_char_evt_t *)p_data->p_param;

            if (p_rd_char_evt_param->read_data.attr_hdl == p_peer->hdls.supported_new_alert_category_char_val_hdl)
            {
                ble_status_t ret;
                st_ble_anc_supported_new_alert_category_t app_value;
                ret = decode_supported_new_alert_category(&app_value, &p_rd_char_evt_param->read_data.value);

                st_ble_anc_evt_data_t evt_data = 
                {
                    .conn_hdl  = p_data->conn_hdl,
                    .param_len = sizeof(app_value),
                    .p_param   = &app_value,
                };
                gs_anc_cb(BLE_ANC_EVENT_SUPPORTED_NEW_ALERT_CATEGORY_READ_RSP, ret, &evt_data);
            }
            else if (p_rd_char_evt_param->read_data.attr_hdl == p_peer->hdls.supported_unread_alert_category_char_val_hdl)
            {
                ble_status_t ret;
                st_ble_anc_supported_unread_alert_category_t app_value;
                ret = decode_supported_unread_alert_category(&app_value, &p_rd_char_evt_param->read_data.value);

                st_ble_anc_evt_data_t evt_data =
                {
                    .conn_hdl  = p_data->conn_hdl,
                    .param_len = sizeof(app_value),
                    .p_param   = &app_value,
                };
                gs_anc_cb(BLE_ANC_EVENT_SUPPORTED_UNREAD_ALERT_CATEGORY_READ_RSP, ret, &evt_data);
            }
            else
            {
                /* Do Nothing */
            }
        } break;

        case BLE_GATTC_EVENT_CHAR_WRITE_RSP:
        {
            st_ble_gattc_wr_char_evt_t *p_wr_char_evt_param =
                (st_ble_gattc_wr_char_evt_t *)p_data->p_param;

            st_ble_anc_evt_data_t evt_data =
            {
                .conn_hdl  = p_data->conn_hdl,
                .param_len = 0,
                .p_param   = NULL,
            };

            if (p_wr_char_evt_param->value_hdl == p_peer->hdls.alert_notification_control_point_char_val_hdl)
            {
                gs_anc_cb(BLE_ANC_EVENT_ALERT_NOTIFICATION_CONTROL_POINT_WRITE_RSP, result, &evt_data);
            }
            else if ((p_wr_char_evt_param->value_hdl == p_peer->hdls.new_alert_cli_cnfg_hdl) ||
                     (p_wr_char_evt_param->value_hdl == p_peer->hdls.unread_alert_status_cli_cnfg_hdl))
            {
                gs_anc_cb(BLE_ANC_EVENT_CLI_CNFG_WRITE_RSP, result, &evt_data);
            }
            else
            {
                /* Do Nothing */
            }

        } break;

        case BLE_GATTC_EVENT_HDL_VAL_NTF:
        {
            st_ble_gattc_ntf_evt_t *p_ntf_evt_param =
                (st_ble_gattc_ntf_evt_t *)p_data->p_param;
            if (p_ntf_evt_param->data.attr_hdl == p_peer->hdls.new_alert_char_val_hdl)
            {
                ble_status_t ret;
                st_ble_anc_new_alert_t app_value;
                ret = decode_new_alert(&app_value, &p_ntf_evt_param->data.value);

                st_ble_anc_evt_data_t evt_data = 
                {
                    .conn_hdl  = p_data->conn_hdl,
                    .param_len = sizeof(app_value),
                    .p_param   = &app_value,
                };
                gs_anc_cb(BLE_ANC_EVENT_NEW_ALERT_HDL_VAL_NTF, ret, &evt_data);
            }
            else if (p_ntf_evt_param->data.attr_hdl == p_peer->hdls.unread_alert_status_char_val_hdl)
            {
                ble_status_t ret;
                st_ble_anc_unread_alert_status_t app_value;
                ret = decode_unread_alert_status(&app_value, &p_ntf_evt_param->data.value);

                st_ble_anc_evt_data_t evt_data =
                {
                    .conn_hdl  = p_data->conn_hdl,
                    .param_len = sizeof(app_value),
                    .p_param   = &app_value,
                };
                gs_anc_cb(BLE_ANC_EVENT_UNREAD_ALERT_STATUS_HDL_VAL_NTF, ret, &evt_data);
            }
            else
            {
                /* Do Nothing */
            }
        } break;

        case BLE_GATTC_EVENT_ERROR_RSP:
        {
            st_ble_gattc_err_rsp_evt_t *p_err_rsp_evt_param =
                (st_ble_gattc_err_rsp_evt_t *)p_data->p_param;

            st_ble_anc_evt_data_t evt_data = 
            {
                .conn_hdl  = p_data->conn_hdl,
                .param_len = sizeof(st_ble_gattc_err_rsp_evt_t),
                .p_param   = p_err_rsp_evt_param,
            };

            if ((p_err_rsp_evt_param->attr_hdl == p_peer->hdls.supported_new_alert_category_char_val_hdl) ||
                (p_err_rsp_evt_param->attr_hdl == p_peer->hdls.supported_unread_alert_category_char_val_hdl) ||
                (p_err_rsp_evt_param->attr_hdl == p_peer->hdls.alert_notification_control_point_char_val_hdl))
            {
                gs_anc_cb(BLE_ANC_EVENT_ERROR_RSP, result, &evt_data);
            }
        } break;

        default:
        {
            /* DO NOTHING*/

        } break;
    }
}
/* End of function anc_gattc_cb */

ble_status_t R_BLE_ANC_Init(const st_ble_anc_init_param_t *p_param) // @suppress("API function naming")
{
    if (NULL == p_param)
    {
        return BLE_ERR_INVALID_PTR;
    }

    if (NULL == p_param->cb)
    {
        return BLE_ERR_INVALID_ARG;
    }

    for (uint8_t i = 0; i < 7; i++)
    {
        clear_peer_param(&gs_peer_params[i]);
    }

    R_BLE_GATTC_RegisterCb(anc_gattc_cb, 2);

    gs_anc_cb = p_param->cb;

    return BLE_SUCCESS;
}

ble_status_t R_BLE_ANC_Connect(uint16_t conn_hdl, const st_ble_anc_connect_param_t *p_param) // @suppress("API function naming")
{
    st_anc_peer_param_t *p_peer = get_new_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if ((NULL != p_param) && (NULL != p_param->p_hdls))
    {
        memcpy(&p_peer->hdls, p_param->p_hdls, sizeof(p_peer->hdls));
    }

    /* TODO: Add service specific connection settings here. */

    return BLE_SUCCESS;
}

ble_status_t R_BLE_ANC_Disconnect(uint16_t conn_hdl, st_ble_anc_disconnect_param_t *p_param) // @suppress("API function naming")
{
    st_anc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if ((NULL != p_param) && (NULL != p_param->p_hdls))
    {
        memcpy(p_param->p_hdls, &p_peer->hdls, sizeof(*p_param->p_hdls));
    }

    clear_peer_param(p_peer);

    return BLE_SUCCESS;
}

ble_status_t R_BLE_ANC_ReadSupportedNewAlertCategory(uint16_t conn_hdl) // @suppress("API function naming")
{
    st_anc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.supported_new_alert_category_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    return R_BLE_GATTC_ReadChar(conn_hdl, p_peer->hdls.supported_new_alert_category_char_val_hdl);
}

ble_status_t R_BLE_ANC_SetNewAlertCliCnfg(uint16_t conn_hdl, uint16_t cli_cnfg) // @suppress("API function naming")
{
    st_anc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.new_alert_cli_cnfg_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    if (0 != (cli_cnfg & 0xFFFC))
    {
        return BLE_ERR_INVALID_ARG;
    }

    uint8_t byte_value[2] = { 0 };
    BT_PACK_LE_2_BYTE(byte_value, &cli_cnfg);

    st_ble_gatt_hdl_value_pair_t gatt_value = 
    {
        .attr_hdl = p_peer->hdls.new_alert_cli_cnfg_hdl,
        .value = 
        {
            .p_value   = byte_value,
            .value_len = 2,
        }
    };

    return R_BLE_GATTC_WriteChar(conn_hdl, &gatt_value);
}


ble_status_t R_BLE_ANC_ReadSupportedUnreadAlertCategory(uint16_t conn_hdl) // @suppress("API function naming")
{
    st_anc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.supported_unread_alert_category_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    return R_BLE_GATTC_ReadChar(conn_hdl, p_peer->hdls.supported_unread_alert_category_char_val_hdl);
}



ble_status_t R_BLE_ANC_SetUnreadAlertStatusCliCnfg(uint16_t conn_hdl, uint16_t cli_cnfg) // @suppress("API function naming")
{
    st_anc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.unread_alert_status_cli_cnfg_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    if (0 != (cli_cnfg & 0xFFFC))
    {
        return BLE_ERR_INVALID_ARG;
    }

    uint8_t byte_value[2] = { 0 };
    BT_PACK_LE_2_BYTE(byte_value, &cli_cnfg);

    st_ble_gatt_hdl_value_pair_t gatt_value = 
    {
        .attr_hdl = p_peer->hdls.unread_alert_status_cli_cnfg_hdl,
        .value = 
        {
            .p_value   = byte_value,
            .value_len = 2,
        }
    };

    return R_BLE_GATTC_WriteChar(conn_hdl, &gatt_value);
}

ble_status_t R_BLE_ANC_WriteAlertNotificationControlPoint(uint16_t conn_hdl, const st_ble_anc_alert_notification_control_point_t *p_app_value) // @suppress("API function naming")
{
    ble_status_t ret;
    st_anc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (NULL == p_app_value)
    {
        return BLE_ERR_INVALID_PTR;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls.alert_notification_control_point_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    uint8_t byte_value[BLE_ANC_ALERT_NOTIFICATION_CONTROL_POINT_LEN];

    st_ble_gatt_hdl_value_pair_t write_value = 
    {
        .attr_hdl  = p_peer->hdls.alert_notification_control_point_char_val_hdl,
        .value = 
        {
            .p_value   = byte_value,
            .value_len = BLE_ANC_ALERT_NOTIFICATION_CONTROL_POINT_LEN,
        }
    };
    ret = encode_alert_notification_control_point(p_app_value, &write_value.value);
    if (BLE_SUCCESS != ret)
    {
        return BLE_ERR_INVALID_DATA;
    }

    return R_BLE_GATTC_WriteChar(conn_hdl, &write_value);
}


void R_BLE_ANC_ServDiscCb(uint16_t conn_hdl, uint8_t idx, uint16_t type, void *p_param) // @suppress("API function naming")
{
    st_anc_peer_param_t *p_peer = find_peer_param(conn_hdl);

    switch (type)
    {
        case BLE_DISC_PRIM_SERV_FOUND:
        {
            st_disc_serv_param_t *p_serv_param = (st_disc_serv_param_t *)p_param;
            memcpy(&p_peer->hdls.service_range, &p_serv_param->value.serv_16.range, sizeof(p_peer->hdls.service_range));
        } break;

        case BLE_DISC_CHAR_FOUND:
        {
            st_disc_char_param_t *p_char_param = (st_disc_char_param_t *)p_param;

            if (BLE_GATT_16_BIT_UUID_FORMAT == p_char_param->uuid_type)
            {
                uint8_t uuid_16[BLE_GATT_16_BIT_UUID_SIZE];
                BT_PACK_LE_2_BYTE(uuid_16, &p_char_param->value.char_16.uuid_16);

                if (0 == memcmp(uuid_16, BLE_ANC_SUPPORTED_NEW_ALERT_CATEGORY_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.supported_new_alert_category_char_val_hdl = p_char_param->value.char_16.value_hdl;

                }
                else if (0 == memcmp(uuid_16, BLE_ANC_NEW_ALERT_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.new_alert_char_val_hdl = p_char_param->value.char_16.value_hdl;

                    for (uint8_t i = 0; i < p_char_param->num_of_descs; i++)
                    {
                        BT_PACK_LE_2_BYTE(uuid_16, &p_char_param->descs[i].value.desc_16.uuid_16);

                        if (0 == memcmp(uuid_16, BLE_ANC_NEW_ALERT_CLIENT_CHARACTERISTIC_CONFIGURATION_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                        {
                            p_peer->hdls.new_alert_cli_cnfg_hdl = p_char_param->descs[i].value.desc_16.desc_hdl;
                        }
                    }
                }
                else if (0 == memcmp(uuid_16, BLE_ANC_SUPPORTED_UNREAD_ALERT_CATEGORY_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.supported_unread_alert_category_char_val_hdl = p_char_param->value.char_16.value_hdl;

                }
                else if (0 == memcmp(uuid_16, BLE_ANC_UNREAD_ALERT_STATUS_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.unread_alert_status_char_val_hdl = p_char_param->value.char_16.value_hdl;

                    for (uint8_t i = 0; i < p_char_param->num_of_descs; i++)
                    {
                        BT_PACK_LE_2_BYTE(uuid_16, &p_char_param->descs[i].value.desc_16.uuid_16);

                        if (0 == memcmp(uuid_16, BLE_ANC_UNREAD_ALERT_STATUS_CLIENT_CHARACTERISTIC_CONFIGURATION_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                        {
                            p_peer->hdls.unread_alert_status_cli_cnfg_hdl = p_char_param->descs[i].value.desc_16.desc_hdl;
                        }
                    }
                }
                else if (0 == memcmp(uuid_16, BLE_ANC_ALERT_NOTIFICATION_CONTROL_POINT_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls.alert_notification_control_point_char_val_hdl = p_char_param->value.char_16.value_hdl;

                }
            }
        } break;

        default:
        {
            /* Do nothing. */
        } break;
    }
}

uint32_t R_BLE_ANC_GetVersion(void) // @suppress("API function naming")
{
    uint32_t version;

    version = ((BLE_ANC_PRV_VERSION_MAJOR << 16) | (BLE_ANC_PRV_VERSION_MINOR << 8));

    return version;
}

