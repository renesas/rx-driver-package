/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_anc.c
 * Version : 1.0
 * Description : The source file for Alert Notification Service client.
 **********************************************************************************************************************/

 /***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 20.12.2019 1.00 First Release
 ***********************************************************************************************************************/

#include <string.h>
#include "r_ble_anc.h"
#include "profile_cmn/r_ble_servc_if.h"

/***********************************************************************************************************************
 Macro definitions
***********************************************************************************************************************/
#ifndef UNUSED_ARG
#define UNUSED_ARG(arg)         (void)(arg)
#endif /* UNUSED_ARG */

/*******************************************************************************************************************//**
 * @brief Is Simple Alert Present bit.
***********************************************************************************************************************/
#define BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_SIMPLE_ALERT                                        ( 1 << 0 )

/*******************************************************************************************************************//**
 * @brief Is Email Alert Present bit.
***********************************************************************************************************************/
#define BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_EMAIL                                               ( 1 << 1 )

/*******************************************************************************************************************//**
 * @brief Is News Alert Present bit.
***********************************************************************************************************************/
#define BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_NEWS                                                ( 1 << 2 )

/*******************************************************************************************************************//**
 * @brief Is Call Alert Present bit.
***********************************************************************************************************************/
#define BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_CALL                                                ( 1 << 3 )

/*******************************************************************************************************************//**
 * @brief Is Missed Call Alert Present bit.
***********************************************************************************************************************/
#define BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_MISSED_CALL                                         ( 1 << 4 )

/*******************************************************************************************************************//**
 * @brief Is Sms Mms  Alert Present bit.
***********************************************************************************************************************/
#define BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_SMS_MMS                                             ( 1 << 5 )

/*******************************************************************************************************************//**
 * @brief Is Voice Mail Alert Present bit.
***********************************************************************************************************************/
#define BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_VOICE_MAIL                                          ( 1 << 6 )

/*******************************************************************************************************************//**
 * @brief Is Schedule Alert Present bit.
***********************************************************************************************************************/
#define BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_SCHEDULE                                            ( 1 << 7 )

/*******************************************************************************************************************//**
 * @brief Is High Prioritized Alert Present bit.
***********************************************************************************************************************/
#define BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_HIGH_PRIORITIZED_ALERT                              ( 1 << 8 )

/*******************************************************************************************************************//**
 * @brief Is Instant Message Alert Present bit.
***********************************************************************************************************************/
#define BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_INSTANT_MESSAGE                                     ( 1 << 9 )

/*******************************************************************************************************************//**
 * @brief Is Supported flag.
***********************************************************************************************************************/
#define BLE_ANC_PRV_ANC_SUPPORTED                                                                           (true)

/*******************************************************************************************************************//**
 * @brief Is Not Supported flag.
***********************************************************************************************************************/
#define BLE_ANC_PRV_ANC_NOTSUPPORTED                                                                        (false)

/***********************************************************************************************************************
Private global variables and functions
***********************************************************************************************************************/
static st_ble_servc_info_t                                                                                  gs_client_info;

static ble_status_t decode_st_ble_anc_supnw_atcat_t(st_ble_anc_supported_new_alert_category_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint16_t flag = 0;
    BT_UNPACK_LE_2_BYTE(&flag, &p_gatt_value->p_value[0]);

    /* check the length */
    if (BLE_ANC_SUPPORTED_NEW_ALERT_CATEGORY_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Clear the feature bit flags */
    memset((uint8_t*)p_app_value, 0x00, sizeof(st_ble_anc_supported_new_alert_category_t));

    /* Simple alert supported bit */
    if ((flag & BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_SIMPLE_ALERT))
    {
        p_app_value->is_simple_alert = BLE_ANC_PRV_ANC_SUPPORTED;
    }
    else
    {
        p_app_value->is_simple_alert = BLE_ANC_PRV_ANC_NOTSUPPORTED;
    }

    /* Email field supported bit */
    if ((flag & BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_EMAIL))
    {
        p_app_value->is_email = BLE_ANC_PRV_ANC_SUPPORTED;
    }
    else
    {
        p_app_value->is_email = BLE_ANC_PRV_ANC_NOTSUPPORTED;
    }

    /* News field supported bit */
    if ((flag & BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_NEWS))
    {
        p_app_value->is_news = BLE_ANC_PRV_ANC_SUPPORTED;
    }
    else
    {
        p_app_value->is_news = BLE_ANC_PRV_ANC_NOTSUPPORTED;
    }

    /* Call field supported bit */
    if ((flag & BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_CALL))
    {
        p_app_value->is_call = BLE_ANC_PRV_ANC_SUPPORTED;
    }
    else
    {
        p_app_value->is_call = BLE_ANC_PRV_ANC_NOTSUPPORTED;
    }

    /* Missed Call field supported bit */
    if ((flag & BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_MISSED_CALL))
    {
        p_app_value->is_missed_call = BLE_ANC_PRV_ANC_SUPPORTED;
    }
    else
    {
        p_app_value->is_missed_call = BLE_ANC_PRV_ANC_NOTSUPPORTED;
    }

    /* SMS MMS field supported bit */
    if ((flag & BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_SMS_MMS))
    {
        p_app_value->is_sms_mms = BLE_ANC_PRV_ANC_SUPPORTED;
    }
    else
    {
        p_app_value->is_sms_mms = BLE_ANC_PRV_ANC_NOTSUPPORTED;
    }

    /* Voice Mail field supported bit */
    if ((flag & BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_VOICE_MAIL))
    {
        p_app_value->is_voice_mail = BLE_ANC_PRV_ANC_SUPPORTED;
    }
    else
    {
        p_app_value->is_voice_mail = BLE_ANC_PRV_ANC_NOTSUPPORTED;
    }

    /* Schedule field supported bit */
    if ((flag & BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_SCHEDULE))
    {
        p_app_value->is_schedule = BLE_ANC_PRV_ANC_SUPPORTED;
    }
    else
    {
        p_app_value->is_schedule = BLE_ANC_PRV_ANC_NOTSUPPORTED;
    }

    /* High Prioritized Alert field supported bit */
    if ((flag & BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_HIGH_PRIORITIZED_ALERT))
    {
        p_app_value->is_high_prioritized_alert = BLE_ANC_PRV_ANC_SUPPORTED;
    }
    else
    {
        p_app_value->is_high_prioritized_alert = BLE_ANC_PRV_ANC_NOTSUPPORTED;
    }

    /* Instant Message field supported bit */
    if ((flag & BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_INSTANT_MESSAGE))
    {
        p_app_value->is_instant_message = BLE_ANC_PRV_ANC_SUPPORTED;
    }
    else
    {
        p_app_value->is_instant_message = BLE_ANC_PRV_ANC_NOTSUPPORTED;
    }

    return BLE_SUCCESS;
}

/* End of function decode_st_ble_anc_supnw_atcat_t */

static ble_status_t encode_st_ble_anc_supnw_atcat_t(const st_ble_anc_supported_new_alert_category_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    UNUSED_ARG(p_app_value);
    UNUSED_ARG(p_gatt_value);

    /* Do nothing as flow is not hitting this function */
      return BLE_SUCCESS;
}

/* End of function encode_st_ble_anc_supnw_atcat_t */

/*----------------------------------------------------------------------------------------------------------------------
    Supported New Alert Category Characteristic
----------------------------------------------------------------------------------------------------------------------*/
/* Supported New Alert Category characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_supported_new_alert_category_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

/* Supported New Alert Category characteristic definition */
const st_ble_servc_char_info_t gs_supported_new_alert_category_char = 
{
    .uuid_16      = BLE_ANC_SUPPORTED_NEW_ALERT_CATEGORY_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_anc_supported_new_alert_category_t),
    .db_size      = BLE_ANC_SUPPORTED_NEW_ALERT_CATEGORY_LEN,
    .char_idx     = BLE_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IDX,
    .p_attr_hdls  = gs_supported_new_alert_category_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_anc_supnw_atcat_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_anc_supnw_atcat_t,
};

ble_status_t R_BLE_ANC_ReadSupported_new_alert_category(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_supported_new_alert_category_char, conn_hdl);
}

void R_BLE_ANC_GetSupported_new_alert_categoryAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_anc_supported_new_alert_category_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx     = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_supported_new_alert_category_char_ranges[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    New Alert Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* New Alert characteristic descriptors attribute handles */
static uint16_t gs_new_alert_cli_cnfg_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_new_alert_cli_cnfg =
{
    .uuid_16     = BLE_ANC_NEW_ALERT_CLI_CNFG_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint16_t),
    .db_size     = BLE_ANC_NEW_ALERT_CLI_CNFG_LEN,
    .desc_idx    = BLE_ANC_NEW_ALERT_CLI_CNFG_IDX,
    .p_attr_hdls = gs_new_alert_cli_cnfg_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_ANC_WriteNew_alertCliCnfg(uint16_t conn_hdl, const uint16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_new_alert_cli_cnfg, conn_hdl, p_value);
}

ble_status_t R_BLE_ANC_ReadNew_alertCliCnfg(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_new_alert_cli_cnfg, conn_hdl);
}


static ble_status_t decode_st_ble_anc_new_alert_t(st_ble_anc_new_alert_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    /*Convert byte sequence to app data*/
    uint32_t pos = 0;
    memset(p_app_value, 0x00, sizeof(st_ble_anc_new_alert_t));

    BT_UNPACK_LE_1_BYTE(&p_app_value->category_id, &p_gatt_value->p_value[pos]);
    pos += 1;

    BT_UNPACK_LE_1_BYTE(&p_app_value->number_of_new_alert, &p_gatt_value->p_value[pos]);
    pos += 1;

    for (uint8_t i = 0; i < BLE_ANC_NEW_ALERT_TEXT_LEN; i++)
    {
        BT_UNPACK_LE_1_BYTE(&p_app_value->text_string_information[i], &p_gatt_value->p_value[pos]);
        pos += 1;
    }

    return BLE_SUCCESS;
}

/* End of function decode_st_ble_anc_new_alert_t */

static ble_status_t encode_st_ble_anc_new_alert_t(const st_ble_anc_new_alert_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    UNUSED_ARG(p_app_value);
    UNUSED_ARG(p_gatt_value);

    /* Do nothing as flow is not hitting this function */
    return BLE_SUCCESS;
}

/* End of function encode_st_ble_anc_new_alert_t */

/*----------------------------------------------------------------------------------------------------------------------
    New Alert Characteristic
----------------------------------------------------------------------------------------------------------------------*/
/* New Alert characteristic descriptor definition */
static const st_ble_servc_desc_info_t *gspp_new_alert_descs[] = 
{
    &gs_new_alert_cli_cnfg,
};

/* New Alert characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_new_alert_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

/* New Alert characteristic definition */
const st_ble_servc_char_info_t gs_new_alert_char = 
{
    .uuid_16      = BLE_ANC_NEW_ALERT_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_anc_new_alert_t),
    .db_size      = BLE_ANC_NEW_ALERT_LEN,
    .char_idx     = BLE_ANC_NEW_ALERT_IDX,
    .p_attr_hdls  = gs_new_alert_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_anc_new_alert_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_anc_new_alert_t,
    .num_of_descs = ARRAY_SIZE(gspp_new_alert_descs),
    .pp_descs     = gspp_new_alert_descs,
};

void R_BLE_ANC_GetNew_alertAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_anc_new_alert_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx                  = R_BLE_SERVC_GetConnIdx(p_addr);
    p_hdl->range              = gs_new_alert_char_ranges[conn_idx];
    p_hdl->cli_cnfg_desc_hdl  = gs_new_alert_cli_cnfg_desc_hdls[conn_idx];
}

static ble_status_t decode_st_ble_anc_su_un_atcat_t(st_ble_anc_supported_unread_alert_category_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    uint16_t flag = 0;

    BT_UNPACK_LE_2_BYTE(&flag, &p_gatt_value->p_value[0]);

    /* check the length */
    if (BLE_ANC_SUPPORTED_UNREAD_ALERT_CATEGORY_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    /* Clear the feature bit flags */
    memset((uint8_t*)p_app_value, 0x00, sizeof(st_ble_anc_supported_unread_alert_category_t));

    /* simple alert supported bit */
    if ((flag & BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_SIMPLE_ALERT))
    {
        p_app_value->is_simple_alert = BLE_ANC_PRV_ANC_SUPPORTED;
    }
    else
    {
        p_app_value->is_simple_alert = BLE_ANC_PRV_ANC_NOTSUPPORTED;
    }

    /* Email field supported bit */
    if ((flag & BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_EMAIL))
    {
        p_app_value->is_email = BLE_ANC_PRV_ANC_SUPPORTED;
    }
    else
    {
        p_app_value->is_email = BLE_ANC_PRV_ANC_NOTSUPPORTED;
    }

    /* NEWS field supported bit */
    if ((flag & BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_NEWS))
    {
        p_app_value->is_news = BLE_ANC_PRV_ANC_SUPPORTED;
    }
    else
    {
        p_app_value->is_news = BLE_ANC_PRV_ANC_NOTSUPPORTED;
    }

    /* CALL field supported bit */
    if ((flag & BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_CALL))
    {
        p_app_value->is_call = BLE_ANC_PRV_ANC_SUPPORTED;
    }
    else
    {
        p_app_value->is_call = BLE_ANC_PRV_ANC_NOTSUPPORTED;
    }

    /* MISSED_CALL field supported bit */
    if ((flag & BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_MISSED_CALL))
    {
        p_app_value->is_missed_call = BLE_ANC_PRV_ANC_SUPPORTED;
    }
    else
    {
        p_app_value->is_missed_call = BLE_ANC_PRV_ANC_NOTSUPPORTED;
    }

    /* SMS_MMS field supported bit */
    if ((flag & BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_SMS_MMS))
    {
        p_app_value->is_sms_mms = BLE_ANC_PRV_ANC_SUPPORTED;
    }
    else
    {
        p_app_value->is_sms_mms = BLE_ANC_PRV_ANC_NOTSUPPORTED;
    }

    /* VOICE_MAIL field supported bit */
    if ((flag & BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_VOICE_MAIL))
    {
        p_app_value->is_voice_mail = BLE_ANC_PRV_ANC_SUPPORTED;
    }
    else
    {
        p_app_value->is_voice_mail = BLE_ANC_PRV_ANC_NOTSUPPORTED;
    }

    /* SCHEDULE field supported bit */
    if ((flag & BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_SCHEDULE))
    {
        p_app_value->is_schedule = BLE_ANC_PRV_ANC_SUPPORTED;
    }
    else
    {
        p_app_value->is_schedule = BLE_ANC_PRV_ANC_NOTSUPPORTED;
    }

    /* HIGH_PRIORITIZED_ALERT field supported bit */
    if ((flag & BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_HIGH_PRIORITIZED_ALERT))
    {
        p_app_value->is_high_prioritized_alert = BLE_ANC_PRV_ANC_SUPPORTED;
    }
    else
    {
        p_app_value->is_high_prioritized_alert = BLE_ANC_PRV_ANC_NOTSUPPORTED;
    }

    /* INSTANT_MESSAGE field supported bit */
    if ((flag & BLE_ANC_PRV_ANC_SUPPORTED_NEW_ALERT_CATEGORY_IS_INSTANT_MESSAGE))
    {
        p_app_value->is_instant_message = BLE_ANC_PRV_ANC_SUPPORTED;
    }
    else
    {
        p_app_value->is_instant_message = BLE_ANC_PRV_ANC_NOTSUPPORTED;
    }

    return BLE_SUCCESS;
}

/* End of function decode_st_ble_anc_su_un_atcat_t */

static ble_status_t encode_st_ble_anc_su_un_atcat_t(const st_ble_anc_supported_unread_alert_category_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    UNUSED_ARG(p_app_value);
    UNUSED_ARG(p_gatt_value);

    /* Do nothing as flow is not hitting this function */
    return BLE_SUCCESS;
}

/* End of function encode_st_ble_anc_su_un_atcat_t */
/*----------------------------------------------------------------------------------------------------------------------
    Supported Unread Alert Category Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Supported Unread Alert Category characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_supported_unread_alert_category_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

/* Supported Unread Alert Category characteristic definition */
const st_ble_servc_char_info_t gs_supported_unread_alert_category_char = 
{
    .uuid_16      = BLE_ANC_SUPPORTED_UNREAD_ALERT_CATEGORY_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_anc_supported_unread_alert_category_t),
    .db_size      = BLE_ANC_SUPPORTED_UNREAD_ALERT_CATEGORY_LEN,
    .char_idx     = BLE_ANC_SUPPORTED_UNREAD_ALERT_CATEGORY_IDX,
    .p_attr_hdls  = gs_supported_unread_alert_category_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_anc_su_un_atcat_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_anc_su_un_atcat_t,
};

ble_status_t R_BLE_ANC_ReadSupported_unread_alert_category(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_supported_unread_alert_category_char, conn_hdl);
}

void R_BLE_ANC_GetSupported_unread_alert_categoryAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_anc_supported_unread_alert_category_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx     = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_supported_unread_alert_category_char_ranges[conn_idx];
}


/*----------------------------------------------------------------------------------------------------------------------
    Unread Alert Status Client Characteristic Configuration descriptor
----------------------------------------------------------------------------------------------------------------------*/

/* Unread Alert Status characteristic descriptors attribute handles */
static uint16_t gs_unread_alert_status_cli_cnfg_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];

static const st_ble_servc_desc_info_t gs_unread_alert_status_cli_cnfg =
{
    .uuid_16     = BLE_ANC_UNREAD_ALERT_STATUS_CLI_CNFG_UUID,
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size    = sizeof(uint16_t),
    .db_size     = BLE_ANC_UNREAD_ALERT_STATUS_CLI_CNFG_LEN,
    .desc_idx    = BLE_ANC_UNREAD_ALERT_STATUS_CLI_CNFG_IDX,
    .p_attr_hdls = gs_unread_alert_status_cli_cnfg_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_uint16_t,
    .encode      = (ble_servc_attr_encode_t)encode_uint16_t,
};

ble_status_t R_BLE_ANC_WriteUnread_alert_statusCliCnfg(uint16_t conn_hdl, const uint16_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_unread_alert_status_cli_cnfg, conn_hdl, p_value);
}

ble_status_t R_BLE_ANC_ReadUnread_alert_statusCliCnfg(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_unread_alert_status_cli_cnfg, conn_hdl);
}

static ble_status_t decode_st_ble_anc_und_altst_t(st_ble_anc_unread_alert_status_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    /*Convert byte sequence to application data*/
    uint32_t pos = 0;

    if (BLE_ANC_UNREAD_ALERT_STATUS_LEN != p_gatt_value->value_len)
    {
        return BLE_ERR_INVALID_DATA;
    }

    memset(p_app_value, 0x00, sizeof(st_ble_anc_unread_alert_status_t));

    BT_UNPACK_LE_1_BYTE(&p_app_value->category_id, &p_gatt_value->p_value[pos]);
    pos += 1;

    BT_UNPACK_LE_1_BYTE(&p_app_value->unread_count, &p_gatt_value->p_value[pos]);
    pos += 1;

    return BLE_SUCCESS;
}

/* End of function decode_st_ble_anc_und_altst_t */

static ble_status_t encode_st_ble_anc_und_altst_t(const st_ble_anc_unread_alert_status_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    UNUSED_ARG(p_app_value);
    UNUSED_ARG(p_gatt_value);

    /* Do nothing as flow is not hitting here */
     return BLE_SUCCESS;
}

/* End of function encode_st_ble_ans_und_altst_t */
/*----------------------------------------------------------------------------------------------------------------------
    Unread Alert Status Characteristic
----------------------------------------------------------------------------------------------------------------------*/

/* Unread Alert Status characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_unread_alert_status_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

/* Unread Alert Status characteristic descriptor definition */
static const st_ble_servc_desc_info_t *gspp_unread_alert_status_descs[] = 
{
    &gs_unread_alert_status_cli_cnfg,
};

/* Unread Alert Status characteristic definition */
const st_ble_servc_char_info_t gs_unread_alert_status_char = 
{
    .uuid_16      = BLE_ANC_UNREAD_ALERT_STATUS_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_anc_unread_alert_status_t),
    .db_size      = BLE_ANC_UNREAD_ALERT_STATUS_LEN,
    .char_idx     = BLE_ANC_UNREAD_ALERT_STATUS_IDX,
    .p_attr_hdls  = gs_unread_alert_status_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_anc_und_altst_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_anc_und_altst_t,
    .num_of_descs = ARRAY_SIZE(gspp_unread_alert_status_descs),
    .pp_descs     = gspp_unread_alert_status_descs,
};

void R_BLE_ANC_GetUnread_alert_statusAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_anc_unread_alert_status_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx                 = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range             = gs_unread_alert_status_char_ranges[conn_idx];
    p_hdl->cli_cnfg_desc_hdl = gs_unread_alert_status_cli_cnfg_desc_hdls[conn_idx];
}

static ble_status_t decode_st_ble_anc_alt_ntfy_cp_t(st_ble_anc_alert_notification_control_point_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    UNUSED_ARG(p_app_value);
    UNUSED_ARG(p_gatt_value);

    /* Do nothing as flow is not hitting here */
    return BLE_SUCCESS;
}

/* End of function decode_st_ble_anc_alt_ntfy_cp_t */
static ble_status_t encode_st_ble_anc_alt_ntfy_cp_t(const st_ble_anc_alert_notification_control_point_t *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    /*Convert app data to byte sequence*/
    uint32_t pos = 0;

    memset(p_gatt_value, 0x00, p_gatt_value->value_len);

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->command_id);
    pos += 1;

    BT_PACK_LE_1_BYTE(&p_gatt_value->p_value[pos], &p_app_value->category_id);
    pos += 1;

    p_gatt_value->value_len = (uint16_t)pos;

    return BLE_SUCCESS;
}

/* End of function encode_st_ble_anc_alt_ntfy_cp_t */

/*----------------------------------------------------------------------------------------------------------------------
    Alert Notification Control Point Characteristic
----------------------------------------------------------------------------------------------------------------------*/


/* Alert Notification Control Point characteristic 128 bit UUID */

/* Alert Notification Control Point characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_alert_notification_control_point_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

/* Alert Notification Control Point characteristic definition */
const st_ble_servc_char_info_t gs_alert_notification_control_point_char =
{
    .uuid_16      = BLE_ANC_ALERT_NOTIFICATION_CONTROL_POINT_UUID,
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    .app_size     = sizeof(st_ble_anc_alert_notification_control_point_t),
    .db_size      = BLE_ANC_ALERT_NOTIFICATION_CONTROL_POINT_LEN,
    .char_idx     = BLE_ANC_ALERT_NOTIFICATION_CONTROL_POINT_IDX,
    .p_attr_hdls  = gs_alert_notification_control_point_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_st_ble_anc_alt_ntfy_cp_t,
    .encode       = (ble_servc_attr_encode_t)encode_st_ble_anc_alt_ntfy_cp_t,
};

ble_status_t R_BLE_ANC_WriteAlertNotificationControlPoint(uint16_t conn_hdl, const st_ble_anc_alert_notification_control_point_t *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteChar(&gs_alert_notification_control_point_char, conn_hdl, p_value);
}

void R_BLE_ANC_GetAlertNotificationControlPointAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_anc_alert_notification_control_point_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx     = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_alert_notification_control_point_char_ranges[conn_idx];
}

/*----------------------------------------------------------------------------------------------------------------------
    Alert Notification Service client
----------------------------------------------------------------------------------------------------------------------*/

/* Alert Notification Service client attribute handles */
static st_ble_gatt_hdl_range_t gs_anc_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

const st_ble_servc_char_info_t *gspp_anc_chars[] = 
{
    &gs_supported_new_alert_category_char,
    &gs_new_alert_char,
    &gs_supported_unread_alert_category_char,
    &gs_unread_alert_status_char,
    &gs_alert_notification_control_point_char,
};

static st_ble_servc_info_t gs_client_info = 
{
    .pp_chars     = gspp_anc_chars,
    .num_of_chars = ARRAY_SIZE(gspp_anc_chars),
    .p_attr_hdls  = gs_anc_ranges,
};

ble_status_t R_BLE_ANC_Init(ble_servc_app_cb_t cb) // @suppress("API function naming")
{
    if (NULL == cb)
    {
        return BLE_ERR_INVALID_PTR;
    }

    gs_client_info.cb = cb;

    return R_BLE_SERVC_RegisterClient(&gs_client_info);
}
/* End of function R_BLE_ANC_Init */

void R_BLE_ANC_ServDiscCb(uint16_t conn_hdl, uint8_t serv_idx, uint16_t type, void *p_param) // @suppress("API function naming")
{
    R_BLE_SERVC_ServDiscCb(&gs_client_info, conn_hdl, serv_idx, type, p_param);
}

void R_BLE_ANC_GetServAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_gatt_hdl_range_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    *p_hdl   = gs_anc_ranges[conn_idx];
}
