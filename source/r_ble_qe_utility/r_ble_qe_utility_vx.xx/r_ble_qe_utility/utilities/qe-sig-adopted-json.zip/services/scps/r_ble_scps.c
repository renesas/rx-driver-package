/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2018 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_scps.c
 * Version : 1.0
 * Description : This module implements Scan Parameters Service Server.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 31.12.2999 1.00 First Release
 ***********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <string.h>
#include "r_ble_rx23w_if.h"
#include "r_ble_scps.h"
#include "gatt_db.h"

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/

/* Version number */
#define BLE_SCPS_PRV_VERSION_MAJOR (1)
#define BLE_SCPS_PRV_VERSION_MINOR (0)

/***********************************************************************************************************************
Private global variables and functions
***********************************************************************************************************************/

static ble_scps_app_cb_t gs_scps_cb;

/***********************************************************************************************************************
 * Function Name: set_cli_cnfg
 * Description  : Set Characteristic value notification configuration in local GATT database.
 * Arguments    : conn_hdl - handle to connection.
 *                attr_hadl - handle to the attribute
 *                cli_cnfg - configuration value
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t set_cli_cnfg(uint16_t conn_hdl, uint16_t attr_hdl, uint16_t cli_cnfg)
{
    uint8_t data[2];

    BT_PACK_LE_2_BYTE(data, &cli_cnfg);

    st_ble_gatt_value_t gatt_value = {
        .p_value   = data,
        .value_len = 2,
    };

    return R_BLE_GATTS_SetAttr(conn_hdl, attr_hdl, &gatt_value);
}

/***********************************************************************************************************************
 * Function Name: get_cli_cnfg
 * Description  : Get Characteristic value notification configuration from local GATT database.
 * Arguments    : conn_hdl - handle to connection.
 *                attr_hadl - handle to the attribute
 *                p_cli_cnfg - pointer to variable to store configuration value
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t get_cli_cnfg(uint16_t conn_hdl, uint16_t attr_hdl, uint16_t *p_cli_cnfg)
{
    ble_status_t ret;
    st_ble_gatt_value_t gatt_value;

    ret = R_BLE_GATTS_GetAttr(conn_hdl, attr_hdl, &gatt_value);

    if (BLE_SUCCESS == ret)
    {
        BT_UNPACK_LE_2_BYTE(p_cli_cnfg, gatt_value.p_value);
    }

    return ret;
}

/***********************************************************************************************************************
 * Function Name: decode_scan_interval_window
 * Description  : This function converts Scan Interval Window characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the Scan Interval Window value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : none
 **********************************************************************************************************************/
static void decode_scan_interval_window(st_ble_scps_scan_interval_window_t *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    /* Convert byte sequence to app data. */
    if(p_gatt_value->value_len == 4)
    {
        BT_UNPACK_LE_2_BYTE(p_app_value->le_scan_interval, &p_gatt_value->p_value[0]);
        BT_UNPACK_LE_2_BYTE(p_app_value->le_scan_window, &p_gatt_value->p_value[2]);
    }
}

/***********************************************************************************************************************
 * Function Name: evt_write_cmd_scan_interval_window
 * Description  : This function handles the Scan Interval Window characteristic write request event.
 * Arguments    : conn_hdl - connection handle
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : none
 **********************************************************************************************************************/
static void evt_write_cmd_scan_interval_window(uint16_t conn_hdl, st_ble_gatt_value_t *p_gatt_value)
{
    st_ble_scps_scan_interval_window_t app_value;

    decode_scan_interval_window(&app_value, p_gatt_value);

    st_ble_scps_evt_data_t evt_data = {
        .conn_hdl  = conn_hdl,
        .param_len = sizeof(app_value),
        .p_param   = &app_value,
    };

    gs_scps_cb(BLE_SCPS_EVENT_SCAN_INTERVAL_WINDOW_WRITE_CMD, BLE_SUCCESS, &evt_data);
}

/***********************************************************************************************************************
 * Function Name: scps_gatt_db_cb
 * Description  : Callback function for Scan Parameters GATT Server events.
 * Arguments    : conn_hdl - handle to the connection
 *                p_params - pointer to GATTS db parameter
 * Return Value : none
 **********************************************************************************************************************/
static void scps_gatts_db_cb(uint16_t conn_hdl, st_ble_gatts_db_params_t *p_params) // @suppress("Function length")
{
    switch (p_params->db_op)
    {
        case BLE_GATTS_OP_CHAR_PEER_WRITE_CMD:
        {
            if (BLE_SCPS_SCAN_INTERVAL_WINDOW_VAL_HDL == p_params->attr_hdl)
            {
                evt_write_cmd_scan_interval_window(conn_hdl, &p_params->value);
            }
        } break;

        case BLE_GATTS_OP_CHAR_PEER_CLI_CNFG_WRITE_REQ:
        {
            uint16_t cli_cnfg;

            st_ble_scps_evt_data_t evt_data = {
                .conn_hdl  = conn_hdl,
                .param_len = 0,
                .p_param   = NULL,
            };

            BT_UNPACK_LE_2_BYTE(&cli_cnfg, p_params->value.p_value);

            if (BLE_SCPS_SCAN_REFRESH_CLI_CNFG_DESC_HDL == p_params->attr_hdl)
            {
                if (BLE_GATTS_CLI_CNFG_NOTIFICATION == cli_cnfg)
                {
                    gs_scps_cb(BLE_SCPS_EVENT_SCAN_REFRESH_CLI_CNFG_ENABLED, BLE_SUCCESS, &evt_data);
                }
                else
                {
                    gs_scps_cb(BLE_SCPS_EVENT_SCAN_REFRESH_CLI_CNFG_DISABLED, BLE_SUCCESS, &evt_data);
                }
            }
        } break;

        default:
        {
            /* Do nothing. */
        } break;
    }
}

/***********************************************************************************************************************
 * Function Name: scp_gatts_cb
 * Description  : Callback function for the GATT Server events.
 * Arguments    : type - event id
 *                result - ble status
 *                p_data - pointer to the event data
 * Return Value : none
 **********************************************************************************************************************/
static void scps_gatts_cb(uint16_t type, ble_status_t result, st_ble_gatts_evt_data_t *p_data)
{
    switch (type)
    {
        case BLE_GATTS_EVENT_DB_ACCESS_IND:
        {
            st_ble_gatts_db_access_evt_t *p_db_access_evt_param =
                (st_ble_gatts_db_access_evt_t *)p_data->p_param;

            scps_gatts_db_cb(p_data->conn_hdl, p_db_access_evt_param->p_params);
        } break;

        default:
        {
            /* Do nothing. */
        } break;
    }
}

ble_status_t R_BLE_SCPS_Init(const st_ble_scps_init_param_t *p_param) // @suppress("API function naming")
{
    if (NULL == p_param)
    {
        return BLE_ERR_INVALID_PTR;
    }

    if (NULL == p_param->cb)
    {
        return BLE_ERR_INVALID_ARG;
    }

    R_BLE_GATTS_RegisterCb(scps_gatts_cb, 0);

    gs_scps_cb = p_param->cb;

    return BLE_SUCCESS;
}

ble_status_t R_BLE_SCPS_Connect(uint16_t conn_hdl, const st_ble_scps_connect_param_t *p_param) // @suppress("API function naming")
{
    if (BLE_GAP_INVALID_CONN_HDL == conn_hdl)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (NULL != p_param)
    {
        set_cli_cnfg(conn_hdl, BLE_SCPS_SCAN_REFRESH_CLI_CNFG_DESC_HDL, p_param->scan_refresh_cli_cnfg);
    }

    return BLE_SUCCESS;
}

ble_status_t R_BLE_SCPS_Disconnect(uint16_t conn_hdl, st_ble_scps_disconnect_param_t *p_param) // @suppress("API function naming")
{
    if (conn_hdl == BLE_GAP_INVALID_CONN_HDL)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (NULL != p_param)
    {
        get_cli_cnfg(conn_hdl, BLE_SCPS_SCAN_REFRESH_CLI_CNFG_DESC_HDL, &p_param->scan_refresh_cli_cnfg);
    }

    return BLE_SUCCESS;
}

ble_status_t R_BLE_SCPS_NotifyScanRefresh(uint16_t conn_hdl) // @suppress("API function naming")
{
    ble_status_t ret;
    uint16_t cli_cnfg;

    ret = get_cli_cnfg(conn_hdl, BLE_SCPS_SCAN_REFRESH_CLI_CNFG_DESC_HDL, &cli_cnfg);

    if (BLE_SUCCESS != ret)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if ((cli_cnfg & BLE_GATTS_CLI_CNFG_NOTIFICATION) == 0x0000)
    {
        return BLE_ERR_INVALID_STATE;
    }

    uint8_t byte_value[BLE_SCPS_SCAN_REFRESH_LEN] = { 0 };

    st_ble_gatt_hdl_value_pair_t ntf_data = {
        .attr_hdl        = BLE_SCPS_SCAN_REFRESH_VAL_HDL,
        .value.p_value   = byte_value,
        .value.value_len = BLE_SCPS_SCAN_REFRESH_LEN,
    };

    return R_BLE_GATTS_Notification(conn_hdl, &ntf_data);
}


uint32_t R_BLE_SCPS_GetVersion(void) // @suppress("API function naming")
{
    uint32_t version;

    version = ((BLE_SCPS_PRV_VERSION_MAJOR << 16) | (BLE_SCPS_PRV_VERSION_MINOR << 8));

    return version;
}

