/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2018 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_scps.h
 * Version : 1.0
 * Description : This module implements Scan Parameters Service Server.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 31.12.2999 1.00 First Release
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @file
 * @defgroup scps Scan Parameters Service Server 
 * @{
 * @ingroup profile
 * @brief   This service enables a GATT Client to store the LE scan parameters it is using on a GATT Server device so that the GATT Server can utilize the information to adjust behavior to optimize power consumption and/or reconnection latency 
 **********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "profile_cmn/r_ble_serv_common.h"

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
#ifndef R_BLE_SCPS
#define R_BLE_SCPS

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @brief Scan Parameters Service event data.
***********************************************************************************************************************/
typedef struct
{
    uint16_t  conn_hdl;  /**< Connection handle */
    uint16_t  param_len; /**< Event parameter length */
    void     *p_param;    /**< Event parameter */
} st_ble_scps_evt_data_t;

/*******************************************************************************************************************//**
 * @brief Scan Parameters Service event callback.
***********************************************************************************************************************/
typedef void (*ble_scps_app_cb_t)(uint16_t type, ble_status_t result, st_ble_scps_evt_data_t *data);

/*******************************************************************************************************************//**
 * @brief Scan Parameters Service event type.
***********************************************************************************************************************/
typedef enum {
    BLE_SCPS_EVENT_SCAN_REFRESH_CLI_CNFG_ENABLED, /**< Scan Refresh characteristic cli cnfg enabled event */
    BLE_SCPS_EVENT_SCAN_REFRESH_CLI_CNFG_DISABLED, /**< Scan Refresh characteristic cli cnfg disabled event */
    BLE_SCPS_EVENT_SCAN_INTERVAL_WINDOW_WRITE_CMD, /**< Scan Interval Window characteristic write command event */
} e_ble_scps_event_t;

/*******************************************************************************************************************//**
 * @brief Scan Refresh Value enumeration.
***********************************************************************************************************************/
typedef enum {
    BLE_SCPS_SCAN_REFRESH_SCAN_REFRESH_VALUE_SERVER_REQUIRES_REFRESH = 0, /**< TODO */
} e_ble_scps_scan_refresh_t;

/*******************************************************************************************************************//**
 * @brief Scan Parameters Service initialization parameters.
***********************************************************************************************************************/
typedef struct {
    ble_scps_app_cb_t cb; /**< Scan Parameters Service event callback */
} st_ble_scps_init_param_t;

/*******************************************************************************************************************//**
 * @brief Scan Parameters Service connection parameters.
***********************************************************************************************************************/
typedef struct {
    uint16_t scan_refresh_cli_cnfg; /**< Scan Refresh characteristic cli cnfg */
} st_ble_scps_connect_param_t;

/*******************************************************************************************************************//**
 * @brief Scan Parameters Service disconnection parameters.
***********************************************************************************************************************/
typedef struct {
    uint16_t scan_refresh_cli_cnfg; /**< Scan Refresh characteristic cli cnfg */
} st_ble_scps_disconnect_param_t;

/*******************************************************************************************************************//**
 * @brief Scan Interval Window characteristic parameters.
***********************************************************************************************************************/
typedef struct {
    uint16_t le_scan_interval; /**< LE_Scan_Interval value */
    uint16_t le_scan_window; /**< LE_Scan_Window value */
} st_ble_scps_scan_interval_window_t;

/*******************************************************************************************************************//**
 * @brief Scan Refresh characteristic parameters.
***********************************************************************************************************************/
typedef struct {
    uint8_t scan_refresh_value; /**< Scan Refresh Value value */
} st_ble_scps_scan_refresh_t;

/*******************************************************************************************************************//**
 * @brief Scan Refresh Client Characteristic Configuration descriptor parameters.
***********************************************************************************************************************/
typedef struct {
    uint8_t value[1];  /**< Scan Refresh characteristic value */
} st_ble_scps_scan_refresh_client_characteristic_configuration_t;


/***********************************************************************************************************************
Exported global functions (to be accessed by other files)
***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @brief     Initialize Scan Parameters Service.
 * @details   This function shall be called once at startup.
 * @param[in] param Scan Parameters Service initialization parameters.
 * @return
***********************************************************************************************************************/
ble_status_t R_BLE_SCPS_Init(const st_ble_scps_init_param_t *param);

/*******************************************************************************************************************//**
 * @brief     Perform Scan Parameters Service connection settings.
 * @details   This function shall be called on each connection establishment.
 * @param[in] conn_hdl Connection handle.
 * @param[in] param    Connection parameters.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_SCPS_Connect(uint16_t conn_hdl, const st_ble_scps_connect_param_t *param);

/*******************************************************************************************************************//**
 * @brief     Retrieve Scan Parameters Service connection specific settings before disconnection.
 * @details   This function shall be called on each disconnection.
 * @param[in] conn_hdl Connection handle.
 * @param[in] param    Disconnection parameters.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_SCPS_Disconnect(uint16_t conn_hdl, st_ble_scps_disconnect_param_t *param);

/*******************************************************************************************************************//**
 * @brief     Send Scan Refresh notification.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] app_value Scan Refresh value to send.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_SCPS_NotifyScanRefresh(uint16_t conn_hdl);

/*******************************************************************************************************************//**
 * @brief     Return version of the SCPC service server.
 * @return    version
***********************************************************************************************************************/
uint32_t R_BLE_SCPS_GetVersion(void);

#endif /* R_BLE_SCPS */

/** @} */
