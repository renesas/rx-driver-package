/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2018 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_hidc.h
 * Version : 1.0
 * Description : This module implements Human Interface Device Service Client.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 31.12.2999 1.00 First Release
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @file
 * @defgroup hidc Human Interface Device Service Client
 * @{
 * @ingroup profile
 * @brief This file provides APIs to interface Human Interface Device Service Client.
 **********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_ble_rx23w_if.h"
#include "discovery/r_ble_disc.h"

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
#ifndef R_BLE_HIDC
#define R_BLE_HIDC

/*******************************************************************************************************************//**
 * @brief Protocol Mode characteristic value length.
***********************************************************************************************************************/
#define BLE_HIDC_PROTOCOL_MODE_LEN (1)
/*******************************************************************************************************************//**
 * @brief Report characteristic value length.
***********************************************************************************************************************/
#define BLE_HIDC_REPORT_LEN (64)
/*******************************************************************************************************************//**
 * @brief Report Map characteristic value length.
***********************************************************************************************************************/
#define BLE_HIDC_REPORT_MAP_LEN (512)
/*******************************************************************************************************************//**
 * @brief Boot Keyboard Input Report characteristic value length.
***********************************************************************************************************************/
#define BLE_HIDC_BOOT_KEYBOARD_INPUT_REPORT_LEN (8)
/*******************************************************************************************************************//**
 * @brief Boot Keyboard Output Report characteristic value length.
***********************************************************************************************************************/
#define BLE_HIDC_BOOT_KEYBOARD_OUTPUT_REPORT_LEN (8)
/*******************************************************************************************************************//**
 * @brief Boot Mouse Input Report characteristic value length.
***********************************************************************************************************************/
#define BLE_HIDC_BOOT_MOUSE_INPUT_REPORT_LEN (8)
/*******************************************************************************************************************//**
 * @brief HID Information characteristic value length.
***********************************************************************************************************************/
#define BLE_HIDC_HID_INFORMATION_LEN (4)
/*******************************************************************************************************************//**
 * @brief HID Control Point characteristic value length.
***********************************************************************************************************************/
#define BLE_HIDC_HID_CONTROL_POINT_LEN (1)

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @brief Human Interface Device Service Client event data.
***********************************************************************************************************************/
typedef struct
{
    uint16_t  conn_hdl;  /**< Connection handle */
    uint16_t  param_len; /**< Event parameter length */
    void     * p_param;   /**< Event parameter */
} st_ble_hidc_evt_data_t;

/*******************************************************************************************************************//**
 * @brief Human Interface Device Service Client event callback.
***********************************************************************************************************************/
typedef void (*ble_hidc_app_cb_t)(uint16_t type, ble_status_t result, uint8_t idx, void * p_data);

/*******************************************************************************************************************//**
 * @brief Human Interface Device Service Client event type.
***********************************************************************************************************************/
typedef enum {
    BLE_HIDC_EVENT_PROTOCOL_MODE_READ_RSP, /**< Protocol Mode characteristic read response event */
    BLE_HIDC_EVENT_REPORT_HDL_VAL_NTF, /**< Report characteristic handle value notification event */
    BLE_HIDC_EVENT_REPORT_WRITE_RSP, /**< Report characteristic write response event */
    BLE_HIDC_EVENT_REPORT_READ_RSP, /**< Report characteristic read response event */
    BLE_HIDC_EVENT_REPORT_REPORT_REFERENCE_WRITE_RSP, /**< Report characteristic Report Reference write response event */
    BLE_HIDC_EVENT_REPORT_REPORT_REFERENCE_READ_RSP, /**< Report characteristic Report Reference read response event */
    BLE_HIDC_EVENT_REPORT_CLI_CNFG_READ_RSP, /**< Report characteristic Client Configuration read response event */
    BLE_HIDC_EVENT_REPORT_MAP_READ_RSP, /**< Report Map characteristic read response event */
    BLE_HIDC_EVENT_REPORT_MAP_READ_LONG_RSP, /**< Report Map characteristic read long response event */
    BLE_HIDC_EVENT_REPORT_MAP_EXTERNAL_REPORT_REFERENCE_READ_RSP, /**< Report Map characteristic External Report Reference read response event */
    BLE_HIDC_EVENT_BOOT_KEYBOARD_INPUT_REPORT_HDL_VAL_NTF, /**< Boot Keyboard Input Report characteristic handle value notification event */
    BLE_HIDC_EVENT_BOOT_KEYBOARD_INPUT_REPORT_WRITE_RSP, /**< Boot Keyboard Input Report characteristic write response event */
    BLE_HIDC_EVENT_BOOT_KEYBOARD_INPUT_REPORT_READ_RSP, /**< Boot Keyboard Input Report characteristic read response event */
    BLE_HIDC_EVENT_BOOT_KEYBOARD_INPUT_REPORT_CLI_CNFG_READ_RSP, /**< Boot Keyboard Input Report characteristic Client Configuration read response event */
    BLE_HIDC_EVENT_BOOT_KEYBOARD_OUTPUT_REPORT_WRITE_RSP, /**< Boot Keyboard Output Report characteristic write response event */
    BLE_HIDC_EVENT_BOOT_KEYBOARD_OUTPUT_REPORT_READ_RSP, /**< Boot Keyboard Output Report characteristic read response event */
    BLE_HIDC_EVENT_BOOT_MOUSE_INPUT_REPORT_HDL_VAL_NTF, /**< Boot Mouse Input Report characteristic handle value notification event */
    BLE_HIDC_EVENT_BOOT_MOUSE_INPUT_REPORT_WRITE_RSP, /**< Boot Mouse Input Report characteristic write response event */
    BLE_HIDC_EVENT_BOOT_MOUSE_INPUT_REPORT_READ_RSP, /**< Boot Mouse Input Report characteristic read response event */
    BLE_HIDC_EVENT_BOOT_MOUSE_INPUT_REPORT_CLI_CNFG_READ_RSP, /**< Boot Mouse Input Report characteristic Client Configuration read response event */
    BLE_HIDC_EVENT_HID_INFORMATION_READ_RSP, /**< HID Information characteristic read response event */
    BLE_HIDC_EVENT_CLI_CNFG_WRITE_RSP, /**< Client Configuration write response */
    BLE_HIDC_EVENT_ERROR_RSP, /**< error response */
} e_ble_hidc_event_t;

/*******************************************************************************************************************//**
 * @brief Human Interface Device Service Client Host mode
***********************************************************************************************************************/
typedef enum {
    BLE_HIDC_BOOT_HOST_MODE = 0, /**< Protocol Mode characteristic value Report host */
    BLE_HIDC_REPORT_HOST_MODE = 1, /**< Protocol Mode characteristic value Boot host */
} e_ble_hidc_host_mode_t;

/*******************************************************************************************************************//**
 * @brief Report characteristic attribute handles.
***********************************************************************************************************************/
typedef struct {
    uint16_t char_val_hdl;
    uint16_t cli_cnfg_hdl;
    uint16_t report_reference_hdl;
} st_ble_hidc_report_hdl_t;

/*******************************************************************************************************************//**
 * @brief Human Interface Device Service attribute handles.
***********************************************************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t service_range; /**< Human Interface Device Service range */
    uint16_t protocol_mode_char_val_hdl; /**< Protocol Mode characteristic value handle */
    st_ble_hidc_report_hdl_t report_hdl[BLE_DISC_CHAR_MAX_NUM]; /**< Report characteristic handles */
    uint16_t report_map_char_val_hdl; /**< Report Map characteristic value handle */
    uint16_t report_map_external_report_reference_hdl; /**< Report Map characteristic External Report Reference descriptor handle */
    uint16_t boot_keyboard_input_report_char_val_hdl; /**< Boot Keyboard Input Report characteristic value handle */
    uint16_t boot_keyboard_input_report_cli_cnfg_hdl; /**< Boot Keyboard Input Report characteristic Client Characteristic Configuration descriptor handle */
    uint16_t boot_keyboard_output_report_char_val_hdl; /**< Boot Keyboard Output Report characteristic value handle */
    uint16_t boot_mouse_input_report_char_val_hdl; /**< Boot Mouse Input Report characteristic value handle */
    uint16_t boot_mouse_input_report_cli_cnfg_hdl; /**< Boot Mouse Input Report characteristic Client Characteristic Configuration descriptor handle */
    uint16_t hid_information_char_val_hdl; /**< HID Information characteristic value handle */
    uint16_t hid_control_point_char_val_hdl; /**< HID Control Point characteristic value handle */
} st_ble_hidc_hdls_t;

/*******************************************************************************************************************//**
 * @brief Human Interface Device Service initialization parameters.
***********************************************************************************************************************/
typedef struct {
    ble_hidc_app_cb_t cb; /**< Human Interface Device Service Client event handler */
} st_ble_hidc_init_param_t;

/*******************************************************************************************************************//**
 * @brief Human Interface Device Service Client connection parameters.
***********************************************************************************************************************/
typedef struct {
    st_ble_hidc_hdls_t * p_hdls; /**< Human Interface Device Service handles */
} st_ble_hidc_connect_param_t;

/*******************************************************************************************************************//**
 * @brief Human Interface Device Service disconnection parameters.
***********************************************************************************************************************/
typedef struct {
    st_ble_hidc_hdls_t * p_hdls; /**< Human Interface Device Service handles */
} st_ble_hidc_disconnect_param_t;

/*******************************************************************************************************************//**
 * @brief Report characteristic callback parameters.
***********************************************************************************************************************/
typedef struct {
    uint8_t report_id;  /**< Report characteristic id*/
    void * value;  /**< Report characteristic value */
} st_ble_hidc_report_value_t;

/*******************************************************************************************************************//**
 * @brief Report Reference descriptor parameters.
***********************************************************************************************************************/
typedef struct {
    uint8_t report_id;  /**< Report Reference descriptor report id value */
    uint8_t report_type;  /**< Report Reference descriptor report type value */
} st_ble_hidc_report_report_reference_t;

/*******************************************************************************************************************//**
 * @brief Report Map characteristic parameters.
***********************************************************************************************************************/
typedef struct {
    uint8_t value[512];  /**< Report Map characteristic value */
} st_ble_hidc_report_map_t;

/*******************************************************************************************************************//**
 * @brief HID Information characteristic parameters.
***********************************************************************************************************************/
typedef struct {
    uint16_t bcdhid;  /**< HID Information characteristic bcdHID value */
    uint8_t bcountrycode;  /**< HID Information characteristic bCountryCode value */
    uint8_t flags;  /**< HID Information characteristic Flags value */
} st_ble_hidc_hid_information_t;

/***********************************************************************************************************************
Exported global variables (to be accessed by other files)
***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @brief Human Interface Device Service UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_HIDC_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Protocol Mode characteristic UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_HIDC_PROTOCOL_MODE_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Report characteristic UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_HIDC_REPORT_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Report characteristic UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_HIDC_REPORT_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Report characteristic UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_HIDC_REPORT_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Report Map characteristic UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_HIDC_REPORT_MAP_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Boot Keyboard Input Report characteristic UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_HIDC_BOOT_KEYBOARD_INPUT_REPORT_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Boot Keyboard Output Report characteristic UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_HIDC_BOOT_KEYBOARD_OUTPUT_REPORT_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief Boot Mouse Input Report characteristic UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_HIDC_BOOT_MOUSE_INPUT_REPORT_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief HID Information characteristic UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_HIDC_HID_INFORMATION_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/*******************************************************************************************************************//**
 * @brief HID Control Point characteristic UUID.
***********************************************************************************************************************/
extern const uint8_t BLE_HIDC_HID_CONTROL_POINT_UUID[BLE_GATT_16_BIT_UUID_SIZE];

/***********************************************************************************************************************
Exported global functions (to be accessed by other files)
***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @brief     Initialize Human Interface Device Service  Client.
 * @details   This function shall be called once at startup.
 * @param[in] param Human Interface Device Service Client initialization parameters.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_HIDC_Init(const st_ble_hidc_init_param_t * p_param);

/*******************************************************************************************************************//**
 * @brief     Perform Human Interface Device Service Client connection settings.
 * @details   This function shall be called on each connection establishment.
 * @param[in] conn_hdl Connection handle.
 * @param[in] idx      Service index used to distinguish the multiple same UUID service.
 * @param[in] param    Connection parameters.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_HIDC_Connect(uint16_t conn_hdl, uint8_t idx, const st_ble_hidc_connect_param_t * p_param);

/*******************************************************************************************************************//**
 * @brief     Retrieve Human Interface Device Service Client connection specific settings before disconnection.
 * @details   This function shall be called on each disconnection.
 * @param[in] conn_hdl Connection handle.
 * @param[in] idx      Service index used to distinguish the multiple same UUID service.
 * @param[in] param    Disconnection parameters.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_HIDC_Disconnect(uint16_t conn_hdl, uint8_t idx, st_ble_hidc_disconnect_param_t * p_param);

/*******************************************************************************************************************//**
 * @brief      Read Protocol Mode characteristic value from remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] idx       Service index used to distinguish the multiple same UUID service.
 * @return     @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_HIDC_ReadProtocolMode(uint16_t conn_hdl, uint8_t idx);

/*******************************************************************************************************************//**
 * @brief     Write Protocol Mode characteristic value without response to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] idx       Service index used to distinguish the multiple same UUID service.
 * @param[in] app_value Protocol Mode characteristic value to write.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_HIDC_WriteWithoutRspProtocolMode(uint16_t conn_hdl, uint8_t idx, uint8_t app_value);

/*******************************************************************************************************************//**
 * @brief      Read Report characteristic value from remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] idx       Service index used to distinguish the multiple same UUID service.
 * @param[in] report_id Report index used to distinguish the multiple same UUID characteristic.
 * @return     @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_HIDC_ReadReport(uint16_t conn_hdl, uint8_t idx, uint8_t report_id);

/*******************************************************************************************************************//**
 * @brief     Write Report characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] idx       Service index used to distinguish the multiple same UUID service.
 * @param[in] report_id Report index used to distinguish the multiple same UUID characteristic.
 * @param[in] app_value Report characteristic value to write.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_HIDC_WriteReport(uint16_t conn_hdl, uint8_t idx, uint8_t report_id, const st_ble_gatt_value_t * p_app_value);

/*******************************************************************************************************************//**
 * @brief     Set Report characteristic cli cnfg.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] idx       Service index used to distinguish the multiple same UUID service.
 * @param[in] report_id Report index used to distinguish the multiple same UUID characteristic.
 * @param[in] cli_cnfg  Report characteristic cli cnfg to set.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_HIDC_SetReportCliCnfg(uint16_t conn_hdl, uint8_t idx, uint8_t report_id, uint16_t cli_cnfg);

/*******************************************************************************************************************//**
 * @brief     Read Report characteristic cli cnfg.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] idx       Service index used to distinguish the multiple same UUID service.
 * @param[in] report_id Report index used to distinguish the multiple same UUID characteristic.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_HIDC_ReadReportCliCnfg(uint16_t conn_hdl, uint8_t idx, uint8_t report_id);

/*******************************************************************************************************************//**
 * @brief      Read Report characteristic Report Reference descriptor value from remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] idx       Service index used to distinguish the multiple same UUID service.
 * @param[in] report_id Report index used to distinguish the multiple same UUID characterisitc.
 * @return     @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_HIDC_ReadReportReportReference(uint16_t conn_hdl, uint8_t idx, uint8_t report_id);

/*******************************************************************************************************************//**
 * @brief      Read Report Map characteristic value from remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] idx       Service index used to distinguish the multiple same UUID service.
 * @return     @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_HIDC_ReadReportMap(uint16_t conn_hdl, uint8_t idx);

/*******************************************************************************************************************//**
 * @brief      Read Report Map characteristic long value from remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] idx       Service index used to distinguish the multiple same UUID service.
 * @return     @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_HIDC_ReadLongReportMap(uint16_t conn_hdl, uint8_t idx);

/*******************************************************************************************************************//**
 * @brief      Read Report Map characteristic External Report Reference descriptor value from remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] idx       Service index used to distinguish the multiple same UUID service.
 * @return     @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_HIDC_ReadReportMapExternalReportReference(uint16_t conn_hdl, uint8_t idx);

/*******************************************************************************************************************//**
 * @brief      Read Boot Keyboard Input Report characteristic value from remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] idx       Service index used to distinguish the multiple same UUID service.
 * @return     @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_HIDC_ReadBootKeyboardInputReport(uint16_t conn_hdl, uint8_t idx);

/*******************************************************************************************************************//**
 * @brief     Write Boot Keyboard Input Report characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] idx       Service index used to distinguish the multiple same UUID service.
 * @param[in] app_value Boot Keyboard Input Report characteristic value to write.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_HIDC_WriteBootKeyboardInputReport(uint16_t conn_hdl, uint8_t idx, const st_ble_gatt_value_t * p_app_value);

/*******************************************************************************************************************//**
 * @brief     Set Boot Keyboard Input Report characteristic cli cnfg.
 * @param[in] conn_hdl Connection handle.
 * @param[in] idx       Service index used to distinguish the multiple same UUID service.
 * @param[in] cli_cnfg Boot Keyboard Input Report characteristic cli cnfg to set.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_HIDC_SetBootKeyboardInputReportCliCnfg(uint16_t conn_hdl, uint8_t idx, uint16_t cli_cnfg);

/*******************************************************************************************************************//**
 * @brief     Read Boot Keyboard Input Report characteristic cli cnfg.
 * @param[in] conn_hdl Connection handle.
 * @param[in] idx       Service index used to distinguish the multiple same UUID service.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_HIDC_ReadBootKeyboardInputReportCliCnfg(uint16_t conn_hdl, uint8_t idx);

/*******************************************************************************************************************//**
 * @brief      Read Boot Keyboard Output Report characteristic value from remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] idx       Service index used to distinguish the multiple same UUID service.
 * @return     @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_HIDC_ReadBootKeyboardOutputReport(uint16_t conn_hdl, uint8_t idx);

/*******************************************************************************************************************//**
 * @brief     Write Boot Keyboard Output Report characteristic value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] idx       Service index used to distinguish the multiple same UUID service.
 * @param[in] app_value Boot Keyboard Output Report characteristic value to write.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_HIDC_WriteBootKeyboardOutputReport(uint16_t conn_hdl, uint8_t idx, const st_ble_gatt_value_t * p_app_value);

/*******************************************************************************************************************//**
 * @brief     Write Boot Keyboard Output Report characteristic value without response to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] idx       Service index used to distinguish the multiple same UUID service.
 * @param[in] app_value Boot Keyboard Output Report characteristic value to write.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_HIDC_WriteWithoutRspBootKeyboardOutputReport(uint16_t conn_hdl, uint8_t idx, const st_ble_gatt_value_t * p_app_value);

/*******************************************************************************************************************//**
 * @brief      Read Boot Mouse Input Report characteristic value from remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] idx       Service index used to distinguish the multiple same UUID service.
 * @return     @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_HIDC_ReadBootMouseInputReport(uint16_t conn_hdl, uint8_t idx);

/*******************************************************************************************************************//**
 * @brief     Write Boot Mouse Input Report characteristic value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] idx       Service index used to distinguish the multiple same UUID service.
 * @param[in] app_value Boot Mouse Input Report characteristic value to write.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_HIDC_WriteBootMouseInputReport(uint16_t conn_hdl, uint8_t idx, const st_ble_gatt_value_t * p_app_value);

/*******************************************************************************************************************//**
 * @brief     Set Boot Mouse Input Report characteristic cli cnfg.
 * @param[in] conn_hdl Connection handle.
 * @param[in] idx       Service index used to distinguish the multiple same UUID service.
 * @param[in] cli_cnfg Boot Mouse Input Report characteristic client configuration to set.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_HIDC_SetBootMouseInputReportCliCnfg(uint16_t conn_hdl, uint8_t idx, uint16_t cli_cnfg);

/*******************************************************************************************************************//**
 * @brief     Read Boot Mouse Input Report characteristic cli cnfg.
 * @param[in] conn_hdl Connection handle.
 * @param[in] idx       Service index used to distinguish the multiple same UUID service.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_HIDC_ReadBootMouseInputReportCliCnfg(uint16_t conn_hdl, uint8_t idx);

/*******************************************************************************************************************//**
 * @brief      Read HID Information characteristic value from remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] idx       Service index used to distinguish the multiple same UUID service.
 * @return     @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_HIDC_ReadHidInformation(uint16_t conn_hdl, uint8_t idx);

/*******************************************************************************************************************//**
 * @brief     Write HID Control Point characteristic value without response to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] idx       Service index used to distinguish the multiple same UUID service.
 * @param[in] app_value HID Control Point characteristic value to write.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_HIDC_WriteWithoutRspHidControlPoint(uint16_t conn_hdl, uint8_t idx, uint8_t app_value);

/***********************************************************************************************************************
 * @brief      Callback function for the Human Interface Device Discovery events.
 * @param[out] conn_hdl Connection handle.
 * @param[out] idx      Service index used to distinguish the multiple same UUID service.
 * @param[out] type     Discovery event type
 * @param[out] p_data   Pointer to GATTC event data.
***********************************************************************************************************************/
void R_BLE_HIDC_ServDiscCb(uint16_t conn_hdl, uint8_t idx, uint16_t type, void * p_param);

/*******************************************************************************************************************//**
 * @brief     Return version of the HIDC service client.
 * @return    version
***********************************************************************************************************************/
uint32_t R_BLE_HIDC_GetVersion(void);

#endif /* R_BLE_HIDC */

/** @} */
