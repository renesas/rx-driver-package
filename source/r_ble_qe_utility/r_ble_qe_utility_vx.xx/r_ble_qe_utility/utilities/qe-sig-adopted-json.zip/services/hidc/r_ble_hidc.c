/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2018 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_hidc.c
 * Version : 1.0
 * Description : This module implements Human Interface Device Service Client.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 31.12.2999 1.00 First Release
 ***********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <string.h>
#include "profile_cmn/r_ble_serv_common.h"
#include "r_ble_hidc.h"
#include "discovery/r_ble_disc.h"

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/

/* Version number */
#define BLE_HIDC_PRV_VERSION_MAJOR (1)
#define BLE_HIDC_PRV_VERSION_MINOR (0)

#define BLE_HIDC_PEER_NUM          (2)

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/
typedef struct
{
    uint16_t conn_hdl;
    st_ble_hidc_hdls_t hdls[BLE_DISC_PRIM_SERV_MAX_NUM];
} st_hidc_peer_param_t;

/***********************************************************************************************************************
Exported global variables (to be accessed by other files)
***********************************************************************************************************************/
const uint8_t BLE_HIDC_UUID[BLE_GATT_16_BIT_UUID_SIZE] = { 0x12, 0x18 };
const uint8_t BLE_HIDC_PROTOCOL_MODE_UUID[BLE_GATT_16_BIT_UUID_SIZE] = { 0x4E, 0x2A };
const uint8_t BLE_HIDC_REPORT_UUID[BLE_GATT_16_BIT_UUID_SIZE] = { 0x4D, 0x2A };
const uint8_t BLE_HIDC_REPORT_CLIENT_CHARACTERISTIC_CONFIGURATION_UUID[BLE_GATT_16_BIT_UUID_SIZE] = { 0x02, 0x29 };
const uint8_t BLE_HIDC_REPORT_REPORT_REFERENCE_UUID[BLE_GATT_16_BIT_UUID_SIZE] = { 0x08, 0x29 };
const uint8_t BLE_HIDC_REPORT_MAP_UUID[BLE_GATT_16_BIT_UUID_SIZE] = { 0x4B, 0x2A };
const uint8_t BLE_HIDC_REPORT_MAP_EXTERNAL_REPORT_REFERENCE_UUID[BLE_GATT_16_BIT_UUID_SIZE] = { 0x07, 0x29 };
const uint8_t BLE_HIDC_BOOT_KEYBOARD_INPUT_REPORT_UUID[BLE_GATT_16_BIT_UUID_SIZE] = { 0x22, 0x2A };
const uint8_t BLE_HIDC_BOOT_KEYBOARD_INPUT_REPORT_CLIENT_CHARACTERISTIC_CONFIGURATION_UUID[BLE_GATT_16_BIT_UUID_SIZE] = { 0x02, 0x29 };
const uint8_t BLE_HIDC_BOOT_KEYBOARD_OUTPUT_REPORT_UUID[BLE_GATT_16_BIT_UUID_SIZE] = { 0x32, 0x2A };
const uint8_t BLE_HIDC_BOOT_MOUSE_INPUT_REPORT_UUID[BLE_GATT_16_BIT_UUID_SIZE] = { 0x33, 0x2A };
const uint8_t BLE_HIDC_BOOT_MOUSE_INPUT_REPORT_CLIENT_CHARACTERISTIC_CONFIGURATION_UUID[BLE_GATT_16_BIT_UUID_SIZE] = { 0x02, 0x29 };
const uint8_t BLE_HIDC_HID_INFORMATION_UUID[BLE_GATT_16_BIT_UUID_SIZE] = { 0x4A, 0x2A };
const uint8_t BLE_HIDC_HID_CONTROL_POINT_UUID[BLE_GATT_16_BIT_UUID_SIZE] = { 0x4C, 0x2A };

/***********************************************************************************************************************
Private global variables and functions
***********************************************************************************************************************/
static st_hidc_peer_param_t gs_peer_params[BLE_HIDC_PEER_NUM];
static ble_hidc_app_cb_t gs_hidc_cb;

static uint8_t gs_host_mode = BLE_HIDC_REPORT_HOST_MODE;


/***********************************************************************************************************************
 * Function Name: find_peer_param
 * Description  : This function finds the attribute handles for the given connection handle.
 * Arguments    : conn_hdl - handle to connection
 * Return Value : pointer to the attribute handles structure
 **********************************************************************************************************************/
static st_hidc_peer_param_t * find_peer_param(uint16_t conn_hdl)
{
    for (uint8_t i = 0; i < BLE_HIDC_PEER_NUM; i++)
    {
        if ((BLE_GAP_INVALID_CONN_HDL != gs_peer_params[i].conn_hdl) &&
            (gs_peer_params[i].conn_hdl == conn_hdl))
        {
            return &gs_peer_params[i];
        }
    }
    return NULL;
}

/***********************************************************************************************************************
 * Function Name: get_new_peer_param
 * Description  : This function finds the free attribute handle.
 * Arguments    : conn_hdl - handle to connection.
 * Return Value : pointer to the free attribute handles structure
 **********************************************************************************************************************/
static st_hidc_peer_param_t * get_new_peer_param(uint16_t conn_hdl)
{
    for (uint8_t i = 0; i < BLE_HIDC_PEER_NUM; i++)
    {
        if (BLE_GAP_INVALID_CONN_HDL == gs_peer_params[i].conn_hdl)
        {
            gs_peer_params[i].conn_hdl = conn_hdl;
            return &gs_peer_params[i];
        }
    }
    return NULL;
}

/***********************************************************************************************************************
 * Function Name: clear_peer_param
 * Description  : This function frees all the attribute handles.
 * Arguments    : p_peer - pointer to the attribute handle structure to be freed
 * Return Value : none
***********************************************************************************************************************/
static void clear_peer_param(st_hidc_peer_param_t * p_peer, uint8_t idx)
{
    if (NULL != p_peer)
    {
        memset(&p_peer->hdls[idx], 0x00, sizeof(p_peer->hdls[idx]));
        for (uint8_t i = 0; i < BLE_DISC_PRIM_SERV_MAX_NUM; i++)
        {
            if (0 != p_peer->hdls[i].service_range.start_hdl)
            {
                return;
            }
        }
        p_peer->conn_hdl = BLE_GAP_INVALID_CONN_HDL;
    }
}

/***********************************************************************************************************************
 * Function Name: decode_report_report_reference
 * Description  : This function converts Report descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the Report value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_report_report_reference(st_ble_hidc_report_report_reference_t * p_app_value, const st_ble_gatt_value_t * p_gatt_value)
{
    if(2 == p_gatt_value->value_len)
    {
        BT_PACK_LE_1_BYTE(&p_app_value->report_id, &p_gatt_value->p_value[0]);
        BT_PACK_LE_1_BYTE(&p_app_value->report_type, &p_gatt_value->p_value[1]);
        return BLE_SUCCESS;
    }
    return BLE_ERR_INVALID_DATA;
}

/***********************************************************************************************************************
 * Function Name: decode_report_map
 * Description  : This function converts Report Map characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the Report Map value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_report_map(st_ble_gatt_value_t * p_app_value, const st_ble_gatt_value_t * p_gatt_value)
{
    if(p_gatt_value->value_len < p_app_value->value_len)
    {
        p_app_value->value_len = p_gatt_value->value_len;
    }
    for(uint8_t i = 0; i < p_app_value->value_len; i++)
    {
        p_app_value->p_value[i] = p_gatt_value->p_value[i];
    }
    return BLE_SUCCESS;
}


/***********************************************************************************************************************
 * Function Name: decode_hid_information
 * Description  : This function converts HID Information characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the HID Information value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t decode_hid_information(st_ble_hidc_hid_information_t * p_app_value, const st_ble_gatt_value_t * p_gatt_value)
{
    if(4 == p_gatt_value->value_len)
    {
        BT_UNPACK_LE_2_BYTE(&p_app_value->bcdhid, &p_gatt_value->p_value[0]);
        BT_UNPACK_LE_1_BYTE(&p_app_value->bcountrycode, &p_gatt_value->p_value[2]);
        BT_UNPACK_LE_1_BYTE(&p_app_value->flags, &p_gatt_value->p_value[3]);
        return BLE_SUCCESS;
    }
    return BLE_ERR_INVALID_DATA;
}

/***********************************************************************************************************************
 * Function Name: hidc_gattc_cb
 * Description  : Callback function for the Human Interface Device GATTC events.
 * Arguments    : conn_hdl - handle to the connection
 *                result - ble status
 *              : p_data - pointer to GATTC event data
 * Return Value : none
***********************************************************************************************************************/
static void hidc_gattc_cb(uint16_t type, ble_status_t result, st_ble_gattc_evt_data_t * p_data) // @suppress("Function length")
{
    static uint8_t long_report_map_val[BLE_HIDC_REPORT_MAP_LEN];
    static uint16_t read_pos = 0;
    static uint8_t read_long_idx = 0;
    static uint8_t read_long_flag = 0;

    st_hidc_peer_param_t * p_peer = find_peer_param(p_data->conn_hdl);
    uint8_t idx;
    uint8_t report_id;

    switch (type)
    {
        case BLE_GATTC_EVENT_CHAR_READ_RSP:
        {
            st_ble_gattc_rd_char_evt_t * p_rd_char_evt_param =
                (st_ble_gattc_rd_char_evt_t *)p_data->p_param;
            for(idx = 0; idx < BLE_DISC_PRIM_SERV_MAX_NUM; idx++)
            {
                if (p_rd_char_evt_param->read_data.attr_hdl == p_peer->hdls[idx].protocol_mode_char_val_hdl)
                {
                    uint8_t app_value;
                    BT_UNPACK_LE_1_BYTE(&app_value, p_rd_char_evt_param->read_data.value.p_value);

                    st_ble_hidc_evt_data_t evt_data = {
                            .conn_hdl  = p_data->conn_hdl,
                            .param_len = sizeof(app_value),
                            .p_param   = &app_value,
                    };
                    gs_hidc_cb(BLE_HIDC_EVENT_PROTOCOL_MODE_READ_RSP, result, idx, &evt_data);
                    break;
                }

                else if (p_rd_char_evt_param->read_data.attr_hdl == p_peer->hdls[idx].report_map_char_val_hdl)
                {
                    ble_status_t ret;
                    uint8_t report_value[BLE_HIDC_REPORT_MAP_LEN];
                    st_ble_gatt_value_t app_value = {
                        .value_len = BLE_HIDC_REPORT_MAP_LEN,
                        .p_value = report_value,
                    };
                    ret = decode_report_map(&app_value, &p_rd_char_evt_param->read_data.value);

                    st_ble_hidc_evt_data_t evt_data = {
                            .conn_hdl  = p_data->conn_hdl,
                            .param_len = app_value.value_len,
                            .p_param   = app_value.p_value,
                    };
                    gs_hidc_cb(BLE_HIDC_EVENT_REPORT_MAP_READ_RSP, ret, idx, &evt_data);
                    break;
                }
                else if (p_rd_char_evt_param->read_data.attr_hdl == p_peer->hdls[idx].boot_keyboard_input_report_char_val_hdl)
                {
                    uint8_t app_value[BLE_HIDC_BOOT_KEYBOARD_INPUT_REPORT_LEN];
                    memcpy(app_value, p_rd_char_evt_param->read_data.value.p_value, p_rd_char_evt_param->read_data.value.value_len);

                    st_ble_hidc_evt_data_t evt_data = {
                            .conn_hdl  = p_data->conn_hdl,
                            .param_len = p_rd_char_evt_param->read_data.value.value_len,
                            .p_param   = app_value,
                    };
                    gs_hidc_cb(BLE_HIDC_EVENT_BOOT_KEYBOARD_INPUT_REPORT_READ_RSP, result, idx, &evt_data);
                    break;
                }
                else if (p_rd_char_evt_param->read_data.attr_hdl == p_peer->hdls[idx].boot_keyboard_input_report_cli_cnfg_hdl)
                {
                    uint16_t app_value;
                    BT_UNPACK_LE_2_BYTE(&app_value, p_rd_char_evt_param->read_data.value.p_value);;

                    st_ble_hidc_evt_data_t evt_data = {
                            .conn_hdl = p_data->conn_hdl,
                            .param_len = sizeof(app_value),
                            .p_param = &app_value,
                    };
                    gs_hidc_cb(BLE_HIDC_EVENT_BOOT_KEYBOARD_INPUT_REPORT_CLI_CNFG_READ_RSP, result, idx, &evt_data);
                    break;
                }
                else if (p_rd_char_evt_param->read_data.attr_hdl == p_peer->hdls[idx].boot_keyboard_output_report_char_val_hdl)
                {
                    uint8_t app_value[BLE_HIDC_BOOT_KEYBOARD_OUTPUT_REPORT_LEN];
                    memcpy(app_value, p_rd_char_evt_param->read_data.value.p_value, p_rd_char_evt_param->read_data.value.value_len);

                    st_ble_hidc_evt_data_t evt_data = {
                            .conn_hdl  = p_data->conn_hdl,
                            .param_len = p_rd_char_evt_param->read_data.value.value_len,
                            .p_param   = app_value,
                    };
                    gs_hidc_cb(BLE_HIDC_EVENT_BOOT_KEYBOARD_OUTPUT_REPORT_READ_RSP, result, idx, &evt_data);
                    break;
                }
                else if (p_rd_char_evt_param->read_data.attr_hdl == p_peer->hdls[idx].boot_mouse_input_report_char_val_hdl)
                {
                    uint8_t app_value[BLE_HIDC_BOOT_MOUSE_INPUT_REPORT_LEN];
                    memcpy(app_value, p_rd_char_evt_param->read_data.value.p_value, p_rd_char_evt_param->read_data.value.value_len);

                    st_ble_hidc_evt_data_t evt_data = {
                            .conn_hdl  = p_data->conn_hdl,
                            .param_len = p_rd_char_evt_param->read_data.value.value_len,
                            .p_param   = app_value,
                    };
                    gs_hidc_cb(BLE_HIDC_EVENT_BOOT_MOUSE_INPUT_REPORT_READ_RSP, result, idx, &evt_data);
                    break;
                }
                else if (p_rd_char_evt_param->read_data.attr_hdl == p_peer->hdls[idx].boot_mouse_input_report_cli_cnfg_hdl)
                {
                    uint16_t app_value;
                    BT_UNPACK_LE_2_BYTE(&app_value, p_rd_char_evt_param->read_data.value.p_value);;
                    
                    st_ble_hidc_evt_data_t evt_data = {
                            .conn_hdl = p_data->conn_hdl,
                            .param_len = sizeof(app_value),
                            .p_param = &app_value,
                    };
                    gs_hidc_cb(BLE_HIDC_EVENT_BOOT_MOUSE_INPUT_REPORT_CLI_CNFG_READ_RSP, result, idx, &evt_data);
                    break;
                }
                else if (p_rd_char_evt_param->read_data.attr_hdl == p_peer->hdls[idx].hid_information_char_val_hdl)
                {
                    ble_status_t ret;
                    st_ble_hidc_hid_information_t app_value;
                    ret = decode_hid_information(&app_value, &p_rd_char_evt_param->read_data.value);

                    st_ble_hidc_evt_data_t evt_data = {
                            .conn_hdl  = p_data->conn_hdl,
                            .param_len = sizeof(app_value),
                            .p_param   = &app_value,
                    };
                    gs_hidc_cb(BLE_HIDC_EVENT_HID_INFORMATION_READ_RSP, ret, idx, &evt_data);
                    break;
                }

                else if (p_rd_char_evt_param->read_data.attr_hdl == p_peer->hdls[idx].report_map_external_report_reference_hdl)
                {
                    uint16_t app_value;
                    BT_UNPACK_LE_2_BYTE(&app_value, p_rd_char_evt_param->read_data.value.p_value);

                    st_ble_hidc_evt_data_t evt_data = {
                            .conn_hdl  = p_data->conn_hdl,
                            .param_len = sizeof(app_value),
                            .p_param   = &app_value,
                    };
                    gs_hidc_cb(BLE_HIDC_EVENT_REPORT_MAP_EXTERNAL_REPORT_REFERENCE_READ_RSP, result, idx, &evt_data);
                    break;
                }
                for(report_id = 0; report_id < BLE_DISC_CHAR_MAX_NUM; report_id++)
                {
                    if (p_rd_char_evt_param->read_data.attr_hdl == p_peer->hdls[idx].report_hdl[report_id].char_val_hdl)
                    {
                        uint8_t app_value[BLE_HIDC_REPORT_LEN];
                        memcpy(app_value, p_rd_char_evt_param->read_data.value.p_value, p_rd_char_evt_param->read_data.value.value_len);

                        st_ble_hidc_report_value_t report_value = {
                            .report_id = report_id,
                            .value = app_value,
                        };
                        st_ble_hidc_evt_data_t report_data = {
                                .conn_hdl  = p_data->conn_hdl,
                                .param_len = p_rd_char_evt_param->read_data.value.value_len,
                                .p_param = &report_value
                        };
                        gs_hidc_cb(BLE_HIDC_EVENT_REPORT_READ_RSP, result, idx, &report_data);
                        break;
                    }
                    else if (p_rd_char_evt_param->read_data.attr_hdl == p_peer->hdls[idx].report_hdl[report_id].report_reference_hdl)
                    {
                        ble_status_t ret;
                        st_ble_hidc_report_report_reference_t app_value;
                        ret = decode_report_report_reference(&app_value, &p_rd_char_evt_param->read_data.value);
                        st_ble_hidc_report_value_t report_value = {
                            .report_id = report_id,
                            .value = &app_value,
                        };
                        st_ble_hidc_evt_data_t report_data = {
                                .conn_hdl  = p_data->conn_hdl,
                                .param_len = sizeof(report_value),
                                .p_param   = &report_value,
                        };
                        gs_hidc_cb(BLE_HIDC_EVENT_REPORT_REPORT_REFERENCE_READ_RSP, ret, idx, &report_data);
                        break;
                    }
                    else if (p_rd_char_evt_param->read_data.attr_hdl == p_peer->hdls[idx].report_hdl[report_id].cli_cnfg_hdl)
                    {
                        uint16_t app_value;
                        BT_UNPACK_LE_2_BYTE(&app_value, p_rd_char_evt_param->read_data.value.p_value);;
                        st_ble_hidc_report_value_t report_value = {
                            .report_id = report_id,
                            .value = &app_value,
                        };
                        st_ble_hidc_evt_data_t report_data = {
                                .conn_hdl = p_data->conn_hdl,
                                .param_len = sizeof(report_value),
                                .p_param = &report_value,
                        };
                        gs_hidc_cb(BLE_HIDC_EVENT_REPORT_CLI_CNFG_READ_RSP, result, idx, &report_data);
                        break;
                    }

                }
            }
        } break;

        case BLE_GATTC_EVENT_CHAR_WRITE_RSP:
        {
            st_ble_gattc_wr_char_evt_t * p_wr_char_evt_param =
                (st_ble_gattc_wr_char_evt_t *)p_data->p_param;

            st_ble_hidc_evt_data_t evt_data = {
                .conn_hdl  = p_data->conn_hdl,
                .param_len = 0,
                .p_param   = NULL,
            };

            for(idx = 0; idx < BLE_DISC_PRIM_SERV_MAX_NUM; idx++)
            {
                if (p_wr_char_evt_param->value_hdl == p_peer->hdls[idx].boot_keyboard_input_report_char_val_hdl)
                {
                    gs_hidc_cb(BLE_HIDC_EVENT_BOOT_KEYBOARD_INPUT_REPORT_WRITE_RSP, result, idx, &evt_data);
                }
                else if (p_wr_char_evt_param->value_hdl == p_peer->hdls[idx].boot_keyboard_output_report_char_val_hdl)
                {
                    gs_hidc_cb(BLE_HIDC_EVENT_BOOT_KEYBOARD_OUTPUT_REPORT_WRITE_RSP, result, idx, &evt_data);
                }
                else if (p_wr_char_evt_param->value_hdl == p_peer->hdls[idx].boot_mouse_input_report_char_val_hdl)
                {
                    gs_hidc_cb(BLE_HIDC_EVENT_BOOT_MOUSE_INPUT_REPORT_WRITE_RSP, result, idx, &evt_data);
                }
                else if ((p_wr_char_evt_param->value_hdl == p_peer->hdls[idx].boot_keyboard_input_report_cli_cnfg_hdl) ||
                        (p_wr_char_evt_param->value_hdl == p_peer->hdls[idx].boot_mouse_input_report_cli_cnfg_hdl))
                {
                    gs_hidc_cb(BLE_HIDC_EVENT_CLI_CNFG_WRITE_RSP, result, idx, &evt_data);
                }
                for(report_id = 0; report_id < BLE_DISC_CHAR_MAX_NUM; report_id++)
                {
                    if (p_wr_char_evt_param->value_hdl == p_peer->hdls[idx].report_hdl[report_id].char_val_hdl)
                    {
                        st_ble_hidc_report_value_t report_value = {
                            .report_id = report_id,
                            .value = NULL
                        };
                        st_ble_hidc_evt_data_t report_data = {
                            .conn_hdl  = p_data->conn_hdl,
                            .param_len = sizeof(report_value),
                            .p_param   = &report_value,
                        };
                        gs_hidc_cb(BLE_HIDC_EVENT_REPORT_WRITE_RSP, result, idx, &report_data);
                        break;
                    }
                    else if (p_wr_char_evt_param->value_hdl == p_peer->hdls[idx].report_hdl[report_id].cli_cnfg_hdl)
                    {
                        st_ble_hidc_evt_data_t report_data = {
                            .conn_hdl  = p_data->conn_hdl,
                            .param_len = 0,
                            .p_param   = NULL,
                        };
                        gs_hidc_cb(BLE_HIDC_EVENT_CLI_CNFG_WRITE_RSP, result, idx, &report_data);
                        break;
                    }
                }
            }

        } break;

        case BLE_GATTC_EVENT_HDL_VAL_NTF:
        {
            st_ble_gattc_ntf_evt_t * p_ntf_evt_param =
                    (st_ble_gattc_ntf_evt_t *)p_data->p_param;

            for(idx = 0; idx < BLE_DISC_PRIM_SERV_MAX_NUM; idx++)
            {
                if (p_ntf_evt_param->data.attr_hdl == p_peer->hdls[idx].boot_keyboard_input_report_char_val_hdl)
                {
                    if (BLE_HIDC_BOOT_HOST_MODE == gs_host_mode)
                    {
                        uint8_t app_value[BLE_HIDC_BOOT_KEYBOARD_INPUT_REPORT_LEN];
                        memcpy(app_value, p_ntf_evt_param->data.value.p_value, p_ntf_evt_param->data.value.value_len);

                        st_ble_hidc_evt_data_t evt_data = {
                                .conn_hdl = p_data->conn_hdl,
                                .param_len = p_ntf_evt_param->data.value.value_len,
                                .p_param = &app_value,
                        };
                        gs_hidc_cb(BLE_HIDC_EVENT_BOOT_KEYBOARD_INPUT_REPORT_HDL_VAL_NTF, result, idx, &evt_data);
                    }
                }
                else if (p_ntf_evt_param->data.attr_hdl == p_peer->hdls[idx].boot_mouse_input_report_char_val_hdl)
                {
                    if (BLE_HIDC_BOOT_HOST_MODE == gs_host_mode)
                    {
                        uint8_t app_value[BLE_HIDC_BOOT_MOUSE_INPUT_REPORT_LEN];
                        memcpy(app_value, p_ntf_evt_param->data.value.p_value, p_ntf_evt_param->data.value.value_len);

                        st_ble_hidc_evt_data_t evt_data = {
                                .conn_hdl = p_data->conn_hdl,
                                .param_len = p_ntf_evt_param->data.value.value_len,
                                .p_param = &app_value,
                        };
                        gs_hidc_cb(BLE_HIDC_EVENT_BOOT_MOUSE_INPUT_REPORT_HDL_VAL_NTF, result, idx, &evt_data);
                    }
                }
                for(report_id = 0; report_id < BLE_DISC_CHAR_MAX_NUM; report_id++)
                {
                    if (p_ntf_evt_param->data.attr_hdl == p_peer->hdls[idx].report_hdl[report_id].char_val_hdl)
                    {
                        if (BLE_HIDC_REPORT_HOST_MODE == gs_host_mode)
                        {
                            uint8_t app_value[BLE_HIDC_REPORT_LEN];
                            memcpy(app_value, p_ntf_evt_param->data.value.p_value, p_ntf_evt_param->data.value.value_len);

                            st_ble_hidc_report_value_t report_value = {
                                .report_id = report_id,
                                .value = app_value
                            };

                            st_ble_hidc_evt_data_t report_data = {
                                    .conn_hdl = p_data->conn_hdl,
                                    .param_len = p_ntf_evt_param->data.value.value_len,
                                    .p_param = &report_value,
                            };
                            gs_hidc_cb(BLE_HIDC_EVENT_REPORT_HDL_VAL_NTF, result, idx, &report_data);
                        }
                    }
                }
            }
        } break;

        case BLE_GATTC_EVENT_CHAR_PART_READ_RSP:
        {
            st_ble_gattc_rd_char_evt_t * p_rd_char_evt_param =
                (st_ble_gattc_rd_char_evt_t *)p_data->p_param;
            for (idx = 0; idx < BLE_DISC_PRIM_SERV_MAX_NUM; idx++)
            {
                if (p_rd_char_evt_param->read_data.attr_hdl == p_peer->hdls[idx].report_map_char_val_hdl)
                {
                    /*ble_status_t ret;*/
                    st_ble_gatt_value_t app_value = {
                        .value_len = p_rd_char_evt_param->read_data.value.value_len,
                        .p_value = &long_report_map_val[read_pos],
                    };
                    decode_report_map(&app_value, &p_rd_char_evt_param->read_data.value);

                    read_pos = (uint16_t)(read_pos + p_rd_char_evt_param->read_data.value.value_len);
                    read_long_flag = 1;
                    read_long_idx = idx;
                }
                
            }
        } break;

        case BLE_GATTC_EVENT_LONG_CHAR_READ_COMP:
        {
            if(1 == read_long_flag)
            {
                st_ble_hidc_evt_data_t evt_data = {
                    .conn_hdl = p_data->conn_hdl,
                    .param_len = read_pos,
                    .p_param = long_report_map_val,
                };
                gs_hidc_cb(BLE_HIDC_EVENT_REPORT_MAP_READ_LONG_RSP, BLE_SUCCESS, read_long_idx, &evt_data);
                read_pos = 0;
                read_long_flag = 0;
                read_long_idx = 0;
            }
        } break;

        case BLE_GATTC_EVENT_ERROR_RSP:
        {
            st_ble_gattc_err_rsp_evt_t * p_err_rsp_evt_param =
                (st_ble_gattc_err_rsp_evt_t *)p_data->p_param;

            st_ble_hidc_evt_data_t evt_data = {
                .conn_hdl  = p_data->conn_hdl,
                .param_len = sizeof(st_ble_gattc_err_rsp_evt_t),
                .p_param   = p_err_rsp_evt_param,
            };

            for(idx = 0; idx < BLE_DISC_PRIM_SERV_MAX_NUM; idx++)
            {
                if ((p_err_rsp_evt_param->attr_hdl == p_peer->hdls[idx].protocol_mode_char_val_hdl) ||
                        (p_err_rsp_evt_param->attr_hdl == p_peer->hdls[idx].report_map_char_val_hdl) ||
                        (p_err_rsp_evt_param->attr_hdl == p_peer->hdls[idx].boot_keyboard_input_report_char_val_hdl) ||
                        (p_err_rsp_evt_param->attr_hdl == p_peer->hdls[idx].boot_keyboard_output_report_char_val_hdl) ||
                        (p_err_rsp_evt_param->attr_hdl == p_peer->hdls[idx].boot_mouse_input_report_char_val_hdl) ||
                        (p_err_rsp_evt_param->attr_hdl == p_peer->hdls[idx].hid_information_char_val_hdl))
                {
                    gs_hidc_cb(BLE_HIDC_EVENT_ERROR_RSP, result, idx, &evt_data);
                }
                for(report_id = 0; report_id < BLE_DISC_CHAR_MAX_NUM; report_id++)
                {
                    if(p_err_rsp_evt_param->attr_hdl == p_peer->hdls[idx].report_hdl[report_id].char_val_hdl)
                    {
                        st_ble_hidc_report_value_t report_value = {
                            .report_id = report_id,
                            .value = p_err_rsp_evt_param
                        };
                        st_ble_hidc_evt_data_t report_data = {
                                .conn_hdl  = p_data->conn_hdl,
                                .param_len = sizeof(report_value),
                                .p_param   = &report_value,
                        };
                        gs_hidc_cb(BLE_HIDC_EVENT_ERROR_RSP, result, idx, &report_data);
                    }
                }
            }
        } break;

        default:
        {
            /* Do nothing. */
        } break;
    }
}

ble_status_t R_BLE_HIDC_Init(const st_ble_hidc_init_param_t * p_param) // @suppress("API function naming") // @suppress("Function declaration")
{
    if (NULL == p_param)
    {
        return BLE_ERR_INVALID_PTR;
    }

    if (NULL == p_param->cb)
    {
        return BLE_ERR_INVALID_ARG;
    }

    for (uint8_t i = 0; i < BLE_HIDC_PEER_NUM; i++)
    {
        for (uint8_t idx = 0; idx < BLE_DISC_PRIM_SERV_MAX_NUM; idx++)
        {
            clear_peer_param(&gs_peer_params[i], idx);
        }
    }

    R_BLE_GATTC_RegisterCb(hidc_gattc_cb, 2);

    gs_hidc_cb = p_param->cb;

    return BLE_SUCCESS;
}

ble_status_t R_BLE_HIDC_Connect(uint16_t conn_hdl, uint8_t idx, const st_ble_hidc_connect_param_t * p_param)
{
    st_hidc_peer_param_t * p_peer = get_new_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if(idx >= BLE_DISC_PRIM_SERV_MAX_NUM)
    {
        return BLE_ERR_INVALID_ARG;
    }

    if ((NULL != p_param) && (NULL != p_param->p_hdls))
    {
        memcpy(&p_peer->hdls[idx], p_param->p_hdls, sizeof(*p_param->p_hdls));
    }

    return BLE_SUCCESS;
}

ble_status_t R_BLE_HIDC_Disconnect(uint16_t conn_hdl, uint8_t idx, st_ble_hidc_disconnect_param_t * p_param)
{
    st_hidc_peer_param_t * p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if(idx >= BLE_DISC_PRIM_SERV_MAX_NUM)
    {
        return BLE_ERR_INVALID_ARG;
    }

    if ((NULL != p_param) && (NULL != p_param->p_hdls))
    {
        memcpy(p_param->p_hdls, &p_peer->hdls[idx], sizeof(*p_param->p_hdls));
    }

    clear_peer_param(p_peer, idx);

    return BLE_SUCCESS;
}

ble_status_t R_BLE_HIDC_ReadProtocolMode(uint16_t conn_hdl, uint8_t idx)
{
    st_hidc_peer_param_t * p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if(idx >= BLE_DISC_PRIM_SERV_MAX_NUM)
    {
        return BLE_ERR_INVALID_ARG;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls[idx].protocol_mode_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    return R_BLE_GATTC_ReadChar(conn_hdl, p_peer->hdls[idx].protocol_mode_char_val_hdl);
}

ble_status_t R_BLE_HIDC_WriteWithoutRspProtocolMode(uint16_t conn_hdl, uint8_t idx, uint8_t app_value)
{
    st_hidc_peer_param_t * p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if(idx >= BLE_DISC_PRIM_SERV_MAX_NUM)
    {
        return BLE_ERR_INVALID_ARG;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls[idx].protocol_mode_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    gs_host_mode = app_value;

    uint8_t byte_value[BLE_HIDC_PROTOCOL_MODE_LEN] = { 0 };
    BT_PACK_LE_1_BYTE(byte_value, &app_value);

    st_ble_gatt_hdl_value_pair_t wwr_value = {
        .attr_hdl  = p_peer->hdls[idx].protocol_mode_char_val_hdl,
        .value = {
            .p_value   = byte_value,
            .value_len = BLE_HIDC_PROTOCOL_MODE_LEN,
        }
    };

    return R_BLE_GATTC_WriteCharWithoutRsp(conn_hdl, &wwr_value);
}

ble_status_t R_BLE_HIDC_ReadReport(uint16_t conn_hdl, uint8_t idx, uint8_t report_id)
{
    st_hidc_peer_param_t * p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if((idx >= BLE_DISC_PRIM_SERV_MAX_NUM) || (report_id >= BLE_DISC_CHAR_MAX_NUM))
    {
        return BLE_ERR_INVALID_ARG;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls[idx].report_hdl[report_id].char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    return R_BLE_GATTC_ReadChar(conn_hdl, p_peer->hdls[idx].report_hdl[report_id].char_val_hdl);
}


ble_status_t R_BLE_HIDC_WriteReport(uint16_t conn_hdl, uint8_t idx, uint8_t report_id, const st_ble_gatt_value_t * p_app_value)
{
    st_hidc_peer_param_t * p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if((idx >= BLE_DISC_PRIM_SERV_MAX_NUM) || (report_id >= BLE_DISC_CHAR_MAX_NUM))
    {
        return BLE_ERR_INVALID_ARG;
    }

    if (NULL == p_app_value)
    {
        return BLE_ERR_INVALID_PTR;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls[idx].report_hdl[report_id].char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    st_ble_gatt_hdl_value_pair_t write_value = {
        .attr_hdl  = p_peer->hdls[idx].report_hdl[report_id].char_val_hdl,
        .value = *p_app_value,
    };

    return R_BLE_GATTC_WriteChar(conn_hdl, &write_value);
}

ble_status_t R_BLE_HIDC_SetReportCliCnfg(uint16_t conn_hdl, uint8_t idx, uint8_t report_id, uint16_t cli_cnfg)
{
    st_hidc_peer_param_t * p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if((idx >= BLE_DISC_PRIM_SERV_MAX_NUM) || (report_id >= BLE_DISC_CHAR_MAX_NUM))
    {
        return BLE_ERR_INVALID_ARG;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls[idx].report_hdl[report_id].cli_cnfg_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    if (0 != (cli_cnfg & 0xFFFC))
    {
        return BLE_ERR_INVALID_ARG;
    }

    uint8_t byte_value[2] = { 0 };
    BT_PACK_LE_2_BYTE(byte_value, &cli_cnfg);

    st_ble_gatt_hdl_value_pair_t gatt_value = {
        .attr_hdl = p_peer->hdls[idx].report_hdl[report_id].cli_cnfg_hdl,
        .value = {
            .p_value   = byte_value,
            .value_len = 2,
        }
    };

    return R_BLE_GATTC_WriteChar(conn_hdl, &gatt_value);
}

ble_status_t R_BLE_HIDC_ReadReportCliCnfg(uint16_t conn_hdl, uint8_t idx, uint8_t report_id)
{
    st_hidc_peer_param_t * p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if ((idx >= BLE_DISC_PRIM_SERV_MAX_NUM) || (report_id >= BLE_DISC_CHAR_MAX_NUM))
    {
        return BLE_ERR_INVALID_ARG;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls[idx].report_hdl[report_id].cli_cnfg_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    return R_BLE_GATTC_ReadChar(conn_hdl, p_peer->hdls[idx].report_hdl[report_id].cli_cnfg_hdl);
}

ble_status_t R_BLE_HIDC_ReadReportReportReference(uint16_t conn_hdl, uint8_t idx, uint8_t report_id)
{
    st_hidc_peer_param_t * p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if((idx >= BLE_DISC_PRIM_SERV_MAX_NUM) || (report_id >= BLE_DISC_CHAR_MAX_NUM))
    {
        return BLE_ERR_INVALID_ARG;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls[idx].report_hdl[report_id].report_reference_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    return R_BLE_GATTC_ReadChar(conn_hdl, p_peer->hdls[idx].report_hdl[report_id].report_reference_hdl);
}

ble_status_t R_BLE_HIDC_ReadReportMap(uint16_t conn_hdl, uint8_t idx)
{
    st_hidc_peer_param_t * p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if(idx >= BLE_DISC_PRIM_SERV_MAX_NUM)
    {
        return BLE_ERR_INVALID_ARG;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls[idx].report_map_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    return R_BLE_GATTC_ReadChar(conn_hdl, p_peer->hdls[idx].report_map_char_val_hdl);
}

ble_status_t R_BLE_HIDC_ReadLongReportMap(uint16_t conn_hdl, uint8_t idx)
{
    st_hidc_peer_param_t * p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (idx >= BLE_DISC_PRIM_SERV_MAX_NUM)
    {
        return BLE_ERR_INVALID_ARG;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls[idx].report_map_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    return R_BLE_GATTC_ReadLongChar(conn_hdl, p_peer->hdls[idx].report_map_char_val_hdl, 0);
}

ble_status_t R_BLE_HIDC_ReadReportMapExternalReportReference(uint16_t conn_hdl, uint8_t idx)
{
    st_hidc_peer_param_t * p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if(idx >= BLE_DISC_PRIM_SERV_MAX_NUM)
    {
        return BLE_ERR_INVALID_ARG;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls[idx].report_map_external_report_reference_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    return R_BLE_GATTC_ReadChar(conn_hdl, p_peer->hdls[idx].report_map_external_report_reference_hdl);
}

ble_status_t R_BLE_HIDC_ReadBootKeyboardInputReport(uint16_t conn_hdl, uint8_t idx)
{
    st_hidc_peer_param_t * p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if(idx >= BLE_DISC_PRIM_SERV_MAX_NUM)
    {
        return BLE_ERR_INVALID_ARG;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls[idx].boot_keyboard_input_report_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    return R_BLE_GATTC_ReadChar(conn_hdl, p_peer->hdls[idx].boot_keyboard_input_report_char_val_hdl);
}

ble_status_t R_BLE_HIDC_WriteBootKeyboardInputReport(uint16_t conn_hdl, uint8_t idx, const st_ble_gatt_value_t * p_app_value)
{
    st_hidc_peer_param_t * p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if(idx >= BLE_DISC_PRIM_SERV_MAX_NUM)
    {
        return BLE_ERR_INVALID_ARG;
    }

    if (NULL == p_app_value)
    {
        return BLE_ERR_INVALID_PTR;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls[idx].boot_keyboard_input_report_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    st_ble_gatt_hdl_value_pair_t write_value = {
        .attr_hdl  = p_peer->hdls[idx].boot_keyboard_input_report_char_val_hdl,
        .value = *p_app_value,
    };

    return R_BLE_GATTC_WriteChar(conn_hdl, &write_value);
}

ble_status_t R_BLE_HIDC_SetBootKeyboardInputReportCliCnfg(uint16_t conn_hdl, uint8_t idx, uint16_t cli_cnfg)
{
    st_hidc_peer_param_t * p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if(idx >= BLE_DISC_PRIM_SERV_MAX_NUM)
    {
        return BLE_ERR_INVALID_ARG;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls[idx].boot_keyboard_input_report_cli_cnfg_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    if (0 != (cli_cnfg & 0xFFFC))
    {
        return BLE_ERR_INVALID_ARG;
    }

    uint8_t byte_value[2] = { 0 };
    BT_PACK_LE_2_BYTE(byte_value, &cli_cnfg);

    st_ble_gatt_hdl_value_pair_t gatt_value = {
        .attr_hdl = p_peer->hdls[idx].boot_keyboard_input_report_cli_cnfg_hdl,
        .value = {
            .p_value   = byte_value,
            .value_len = 2,
        }
    };

    return R_BLE_GATTC_WriteChar(conn_hdl, &gatt_value);
}

ble_status_t R_BLE_HIDC_ReadBootKeyboardInputReportCliCnfg(uint16_t conn_hdl, uint8_t idx)
{
    st_hidc_peer_param_t * p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (idx >= BLE_DISC_PRIM_SERV_MAX_NUM)
    {
        return BLE_ERR_INVALID_ARG;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls[idx].boot_keyboard_input_report_cli_cnfg_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    return R_BLE_GATTC_ReadChar(conn_hdl, p_peer->hdls[idx].boot_keyboard_input_report_cli_cnfg_hdl);
}

ble_status_t R_BLE_HIDC_ReadBootKeyboardOutputReport(uint16_t conn_hdl, uint8_t idx)
{
    st_hidc_peer_param_t * p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if(idx >= BLE_DISC_PRIM_SERV_MAX_NUM)
    {
        return BLE_ERR_INVALID_ARG;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls[idx].boot_keyboard_output_report_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    return R_BLE_GATTC_ReadChar(conn_hdl, p_peer->hdls[idx].boot_keyboard_output_report_char_val_hdl);
}

ble_status_t R_BLE_HIDC_WriteBootKeyboardOutputReport(uint16_t conn_hdl, uint8_t idx, const st_ble_gatt_value_t * p_app_value)
{
    st_hidc_peer_param_t * p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if(idx >= BLE_DISC_PRIM_SERV_MAX_NUM)
    {
        return BLE_ERR_INVALID_ARG;
    }

    if (NULL == p_app_value)
    {
        return BLE_ERR_INVALID_PTR;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls[idx].boot_keyboard_output_report_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    st_ble_gatt_hdl_value_pair_t write_value = {
        .attr_hdl  = p_peer->hdls[idx].boot_keyboard_output_report_char_val_hdl,
        .value = *p_app_value,
    };

    return R_BLE_GATTC_WriteChar(conn_hdl, &write_value);
}

ble_status_t R_BLE_HIDC_WriteWithoutRspBootKeyboardOutputReport(uint16_t conn_hdl, uint8_t idx, const st_ble_gatt_value_t * p_app_value)
{
    st_hidc_peer_param_t * p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if(idx >= BLE_DISC_PRIM_SERV_MAX_NUM)
    {
        return BLE_ERR_INVALID_ARG;
    }

    if (NULL == p_app_value)
    {
        return BLE_ERR_INVALID_PTR;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls[idx].boot_keyboard_output_report_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    st_ble_gatt_hdl_value_pair_t wwr_value = {
        .attr_hdl  = p_peer->hdls[idx].boot_keyboard_output_report_char_val_hdl,
        .value = *p_app_value,
    };

    return R_BLE_GATTC_WriteCharWithoutRsp(conn_hdl, &wwr_value);
}

ble_status_t R_BLE_HIDC_ReadBootMouseInputReport(uint16_t conn_hdl, uint8_t idx)
{
    st_hidc_peer_param_t * p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if(idx >= BLE_DISC_PRIM_SERV_MAX_NUM)
    {
        return BLE_ERR_INVALID_ARG;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls[idx].boot_mouse_input_report_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    return R_BLE_GATTC_ReadChar(conn_hdl, p_peer->hdls[idx].boot_mouse_input_report_char_val_hdl);
}

ble_status_t R_BLE_HIDC_WriteBootMouseInputReport(uint16_t conn_hdl, uint8_t idx, const st_ble_gatt_value_t * p_app_value)
{
    st_hidc_peer_param_t * p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if(idx >= BLE_DISC_PRIM_SERV_MAX_NUM)
    {
        return BLE_ERR_INVALID_ARG;
    }

    if (NULL == p_app_value)
    {
        return BLE_ERR_INVALID_PTR;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls[idx].boot_mouse_input_report_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    st_ble_gatt_hdl_value_pair_t write_value = {
        .attr_hdl  = p_peer->hdls[idx].boot_mouse_input_report_char_val_hdl,
        .value = *p_app_value,
    };

    return R_BLE_GATTC_WriteChar(conn_hdl, &write_value);
}

ble_status_t R_BLE_HIDC_SetBootMouseInputReportCliCnfg(uint16_t conn_hdl, uint8_t idx, uint16_t cli_cnfg)
{
    st_hidc_peer_param_t * p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if(idx >= BLE_DISC_PRIM_SERV_MAX_NUM)
    {
        return BLE_ERR_INVALID_ARG;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls[idx].boot_mouse_input_report_cli_cnfg_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    if (0 != (cli_cnfg & 0xFFFC))
    {
        return BLE_ERR_INVALID_ARG;
    }

    uint8_t byte_value[2] = { 0 };
    BT_PACK_LE_2_BYTE(byte_value, &cli_cnfg);

    st_ble_gatt_hdl_value_pair_t gatt_value = {
        .attr_hdl = p_peer->hdls[idx].boot_mouse_input_report_cli_cnfg_hdl,
        .value = {
            .p_value   = byte_value,
            .value_len = 2,
        }
    };

    return R_BLE_GATTC_WriteChar(conn_hdl, &gatt_value);
}

ble_status_t R_BLE_HIDC_ReadBootMouseInputReportCliCnfg(uint16_t conn_hdl, uint8_t idx)
{
    st_hidc_peer_param_t * p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if (idx >= BLE_DISC_PRIM_SERV_MAX_NUM)
    {
        return BLE_ERR_INVALID_ARG;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls[idx].boot_mouse_input_report_cli_cnfg_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    return R_BLE_GATTC_ReadChar(conn_hdl, p_peer->hdls[idx].boot_mouse_input_report_cli_cnfg_hdl);
}

ble_status_t R_BLE_HIDC_ReadHidInformation(uint16_t conn_hdl, uint8_t idx)
{
    st_hidc_peer_param_t * p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if(idx >= BLE_DISC_PRIM_SERV_MAX_NUM)
    {
        return BLE_ERR_INVALID_ARG;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls[idx].hid_information_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    return R_BLE_GATTC_ReadChar(conn_hdl, p_peer->hdls[idx].hid_information_char_val_hdl);
}

ble_status_t R_BLE_HIDC_WriteWithoutRspHidControlPoint(uint16_t conn_hdl, uint8_t idx, uint8_t app_value)
{
    st_hidc_peer_param_t * p_peer = find_peer_param(conn_hdl);

    if (NULL == p_peer)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if(idx >= BLE_DISC_PRIM_SERV_MAX_NUM)
    {
        return BLE_ERR_INVALID_ARG;
    }

    if (BLE_GATT_INVALID_ATTR_HDL_VAL == p_peer->hdls[idx].hid_control_point_char_val_hdl)
    {
        return BLE_ERR_INVALID_STATE;
    }

    uint8_t byte_value[BLE_HIDC_HID_CONTROL_POINT_LEN] = { 0 };
    BT_PACK_LE_1_BYTE(byte_value, &app_value);

    st_ble_gatt_hdl_value_pair_t wwr_value = {
        .attr_hdl  = p_peer->hdls[idx].hid_control_point_char_val_hdl,
        .value = {
            .p_value   = byte_value,
            .value_len = BLE_HIDC_HID_CONTROL_POINT_LEN,
        }
    };

    return R_BLE_GATTC_WriteCharWithoutRsp(conn_hdl, &wwr_value);
}

void R_BLE_HIDC_ServDiscCb(uint16_t conn_hdl, uint8_t idx, uint16_t type, void * p_param)
{
    st_hidc_peer_param_t * p_peer = find_peer_param(conn_hdl);
    static uint8_t prev_idx = 0;
    static uint8_t report_id = 0;
    if (prev_idx != idx)
    {
        report_id = 0;
    }
    prev_idx = idx;

    switch (type)
    {
        case BLE_DISC_PRIM_SERV_FOUND:
        {
            st_disc_serv_param_t * p_serv_param = (st_disc_serv_param_t *)p_param;
            memcpy(&p_peer->hdls[idx].service_range, &p_serv_param->value.serv_16.range, sizeof(p_peer->hdls[idx].service_range));
        } break;

        case BLE_DISC_CHAR_FOUND:
        {
            st_disc_char_param_t * p_char_param = (st_disc_char_param_t *)p_param;

            if (BLE_GATT_16_BIT_UUID_FORMAT == p_char_param->uuid_type)
            {
                uint8_t uuid_16[BLE_GATT_16_BIT_UUID_SIZE];
                BT_PACK_LE_2_BYTE(uuid_16, &p_char_param->value.char_16.uuid_16);
                if (0 == memcmp(uuid_16, BLE_HIDC_PROTOCOL_MODE_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls[idx].protocol_mode_char_val_hdl = p_char_param->value.char_16.value_hdl;
                }
                else if (0 == memcmp(uuid_16, BLE_HIDC_REPORT_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls[idx].report_hdl[report_id].char_val_hdl = p_char_param->value.char_16.value_hdl;
                    for (uint8_t i = 0; i < p_char_param->num_of_descs; i++)
                    {
                        BT_PACK_LE_2_BYTE(uuid_16, &p_char_param->descs[i].value.desc_16.uuid_16);
                        if (0 == memcmp(uuid_16, BLE_HIDC_REPORT_CLIENT_CHARACTERISTIC_CONFIGURATION_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                        {
                            p_peer->hdls[idx].report_hdl[report_id].cli_cnfg_hdl = p_char_param->descs[i].value.desc_16.desc_hdl;
                        }
                        else if (0 == memcmp(uuid_16, BLE_HIDC_REPORT_REPORT_REFERENCE_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                        {
                            p_peer->hdls[idx].report_hdl[report_id].report_reference_hdl = p_char_param->descs[i].value.desc_16.desc_hdl;
                        }
                    }
                    report_id++;
                }
                else if (0 == memcmp(uuid_16, BLE_HIDC_REPORT_MAP_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls[idx].report_map_char_val_hdl = p_char_param->value.char_16.value_hdl;
                    for (uint8_t i = 0; i < p_char_param->num_of_descs; i++)
                    {
                        BT_PACK_LE_2_BYTE(uuid_16, &p_char_param->descs[i].value.desc_16.uuid_16);
                        if (0 == memcmp(uuid_16, BLE_HIDC_REPORT_MAP_EXTERNAL_REPORT_REFERENCE_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                        {
                            p_peer->hdls[idx].report_map_external_report_reference_hdl = p_char_param->descs[i].value.desc_16.desc_hdl;
                        }
                    }
                }
                else if (0 == memcmp(uuid_16, BLE_HIDC_BOOT_KEYBOARD_INPUT_REPORT_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls[idx].boot_keyboard_input_report_char_val_hdl = p_char_param->value.char_16.value_hdl;
                    for (uint8_t i = 0; i < p_char_param->num_of_descs; i++)
                    {
                        BT_PACK_LE_2_BYTE(uuid_16, &p_char_param->descs[i].value.desc_16.uuid_16);
                        if (0 == memcmp(uuid_16, BLE_HIDC_BOOT_KEYBOARD_INPUT_REPORT_CLIENT_CHARACTERISTIC_CONFIGURATION_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                        {
                            p_peer->hdls[idx].boot_keyboard_input_report_cli_cnfg_hdl = p_char_param->descs[i].value.desc_16.desc_hdl;
                        }
                    }
                }
                else if (0 == memcmp(uuid_16, BLE_HIDC_BOOT_KEYBOARD_OUTPUT_REPORT_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls[idx].boot_keyboard_output_report_char_val_hdl = p_char_param->value.char_16.value_hdl;
                }
                else if (0 == memcmp(uuid_16, BLE_HIDC_BOOT_MOUSE_INPUT_REPORT_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls[idx].boot_mouse_input_report_char_val_hdl = p_char_param->value.char_16.value_hdl;
                    for (uint8_t i = 0; i < p_char_param->num_of_descs; i++)
                    {
                        BT_PACK_LE_2_BYTE(uuid_16, &p_char_param->descs[i].value.desc_16.uuid_16);
                        if (0 == memcmp(uuid_16, BLE_HIDC_BOOT_MOUSE_INPUT_REPORT_CLIENT_CHARACTERISTIC_CONFIGURATION_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                        {
                            p_peer->hdls[idx].boot_mouse_input_report_cli_cnfg_hdl = p_char_param->descs[i].value.desc_16.desc_hdl;
                        }
                    }
                }
                else if (0 == memcmp(uuid_16, BLE_HIDC_HID_INFORMATION_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls[idx].hid_information_char_val_hdl = p_char_param->value.char_16.value_hdl;
                }
                else if (0 == memcmp(uuid_16, BLE_HIDC_HID_CONTROL_POINT_UUID, BLE_GATT_16_BIT_UUID_SIZE))
                {
                    p_peer->hdls[idx].hid_control_point_char_val_hdl = p_char_param->value.char_16.value_hdl;
                }
            }
        } break;
        default:
        {
            /* Do nothing. */
        } break;
    }
}

uint32_t R_BLE_HIDC_GetVersion(void)
{
    uint32_t version;

    version = ((BLE_HIDC_PRV_VERSION_MAJOR << 16) | (BLE_HIDC_PRV_VERSION_MINOR << 8));

    return version;
}

