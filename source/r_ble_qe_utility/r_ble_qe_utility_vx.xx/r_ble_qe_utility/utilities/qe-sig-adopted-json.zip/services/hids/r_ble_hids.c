/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2018 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_hids.c
 * Version : 1.0
 * Description : This module implements Human Interface Device Service Server.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 31.12.2999 1.00 First Release
 ***********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include <string.h>
#include "r_ble_rx23w_if.h"
#include "r_ble_hids.h"
#include "gatt_db.h"

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/

/* Version number */
#define BLE_HIDS_PRV_VERSION_MAJOR (1)
#define BLE_HIDS_PRV_VERSION_MINOR (0)

/***********************************************************************************************************************
Private global variables and functions
***********************************************************************************************************************/

static ble_hids_app_cb_t gs_hids_cb;



/***********************************************************************************************************************
 * Function Name: set_cli_cnfg
 * Description  : Set Characteristic value notification configuration in local GATT database.
 * Arguments    : conn_hdl - handle to connection.
 *                attr_hadl - handle to the attribute
 *                cli_cnfg - configuration value
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t set_cli_cnfg(uint16_t conn_hdl, uint16_t attr_hdl, uint16_t cli_cnfg)
{
    uint8_t data[2];

    BT_PACK_LE_2_BYTE(data, &cli_cnfg);

    st_ble_gatt_value_t gatt_value = {
        .p_value   = data,
        .value_len = 2,
    };

    return R_BLE_GATTS_SetAttr(conn_hdl, attr_hdl, &gatt_value);
}

/***********************************************************************************************************************
 * Function Name: get_cli_cnfg
 * Description  : Get Characteristic value notification configuration from local GATT database.
 * Arguments    : conn_hdl - handle to connection.
 *                attr_hadl - handle to the attribute
 *                p_cli_cnfg - pointer to variable to store configuration value
 * Return Value : ble_status_t
 **********************************************************************************************************************/
static ble_status_t get_cli_cnfg(uint16_t conn_hdl, uint16_t attr_hdl, uint16_t * p_cli_cnfg)
{
    ble_status_t ret;
    st_ble_gatt_value_t gatt_value;

    ret = R_BLE_GATTS_GetAttr(conn_hdl, attr_hdl, &gatt_value);

    if (BLE_SUCCESS == ret)
    {
        BT_UNPACK_LE_2_BYTE(p_cli_cnfg, gatt_value.p_value);
    }

    return ret;
}

/***********************************************************************************************************************
 * Function Name: decode_report_map
 * Description  : This function converts Report Map characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the Report_Map value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : none
 **********************************************************************************************************************/
static void decode_report_map(st_ble_gatt_value_t * p_app_value, const st_ble_gatt_value_t * p_gatt_value)
{
    if(p_gatt_value->value_len < p_app_value->value_len)
    {
        p_app_value->value_len = p_gatt_value->value_len;
    }
    for(uint8_t i = 0; i<p_app_value->value_len; i++)
    {
        p_app_value->p_value[i] = p_gatt_value->p_value[p_app_value->value_len - (i + 1)];
    }
}

/***********************************************************************************************************************
 * Function Name: decode_report
 * Description  : This function converts Report descriptor value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the Report value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : none
 **********************************************************************************************************************/
static void decode_report_report_reference(st_ble_hids_report_report_reference_t * p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    if(2 == p_gatt_value->value_len)
    {
        BT_PACK_LE_1_BYTE(&p_app_value->report_id, &p_gatt_value->p_value[0]);
        BT_PACK_LE_1_BYTE(&p_app_value->report_type, &p_gatt_value->p_value[1]);
    }
}

/***********************************************************************************************************************
 * Function Name: decode_hid_information
 * Description  : This function converts HID Information characteristic value representation in
 *                GATT (uint8_t[]) to representation in application layer (struct).
 * Arguments    : p_app_value - pointer to the HID Information value in the application layer
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : none
 **********************************************************************************************************************/
static void decode_hid_information(st_ble_hids_hid_information_t * p_app_value, const st_ble_gatt_value_t * p_gatt_value)
{
    if(4 == p_gatt_value->value_len)
    {
        BT_UNPACK_LE_2_BYTE(&p_app_value->bcdhid, &p_gatt_value->p_value[0]);
        BT_UNPACK_LE_1_BYTE(&p_app_value->bcountrycode, &p_gatt_value->p_value[2]);
        BT_UNPACK_LE_1_BYTE(&p_app_value->flags, &p_gatt_value->p_value[3]);
    }
}

static uint8_t get_report_type(uint8_t idx, uint8_t report_id){
    st_ble_hids_report_report_reference_t report_reference;

    R_BLE_HIDS_GetReportReportReference(idx, report_id, &report_reference);

    return report_reference.report_type;
}

/***********************************************************************************************************************
 * Function Name: evt_write_req_report
 * Description  : This function handles the Report characteristic write request event.
 * Arguments    : conn_hdl - connection handle
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : none
 **********************************************************************************************************************/
static void evt_write_req_report(uint16_t conn_hdl, st_ble_gatt_value_t * p_gatt_value)
{
    st_ble_hids_evt_data_t evt_data = {
        .conn_hdl  = conn_hdl,
        .param_len = p_gatt_value->value_len,
        .p_param   = p_gatt_value->p_value,
    };

    gs_hids_cb(BLE_HIDS_EVENT_REPORT_WRITE_REQ, BLE_SUCCESS, &evt_data);
}

/***********************************************************************************************************************
 * Function Name: evt_write_req_boot_keyboard_input_report
 * Description  : This function handles the Boot Keyboard Input Report characteristic write request event.
 * Arguments    : conn_hdl - connection handle
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : none
 **********************************************************************************************************************/
static void evt_write_req_boot_keyboard_input_report(uint16_t conn_hdl, st_ble_gatt_value_t * p_gatt_value)
{
    st_ble_hids_evt_data_t evt_data = {
        .conn_hdl  = conn_hdl,
        .param_len = p_gatt_value->value_len,
        .p_param   = p_gatt_value->p_value,
    };

    gs_hids_cb(BLE_HIDS_EVENT_BOOT_KEYBOARD_INPUT_REPORT_WRITE_REQ, BLE_SUCCESS, &evt_data);
}

/***********************************************************************************************************************
 * Function Name: evt_write_req_boot_keyboard_output_report
 * Description  : This function handles the Boot Keyboard Output Report characteristic write request event.
 * Arguments    : conn_hdl - connection handle
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : none
 **********************************************************************************************************************/
static void evt_write_req_boot_keyboard_output_report(uint16_t conn_hdl, st_ble_gatt_value_t * p_gatt_value)
{
    st_ble_hids_evt_data_t evt_data = {
        .conn_hdl  = conn_hdl,
        .param_len = p_gatt_value->value_len,
        .p_param   = p_gatt_value->p_value,
    };

    gs_hids_cb(BLE_HIDS_EVENT_BOOT_KEYBOARD_OUTPUT_REPORT_WRITE_REQ, BLE_SUCCESS, &evt_data);
}

/***********************************************************************************************************************
 * Function Name: evt_write_req_boot_mouse_input_report
 * Description  : This function handles the Boot Mouse Input Report characteristic write request event.
 * Arguments    : conn_hdl - connection handle
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : none
 **********************************************************************************************************************/
static void evt_write_req_boot_mouse_input_report(uint16_t conn_hdl, st_ble_gatt_value_t * p_gatt_value)
{
    st_ble_hids_evt_data_t evt_data = {
        .conn_hdl  = conn_hdl,
        .param_len = p_gatt_value->value_len,
        .p_param   = p_gatt_value->p_value,
    };

    gs_hids_cb(BLE_HIDS_EVENT_BOOT_MOUSE_INPUT_REPORT_WRITE_REQ, BLE_SUCCESS, &evt_data);
}

/***********************************************************************************************************************
 * Function Name: evt_write_cmd_protocol_mode
 * Description  : This function handles the Protocol Mode characteristic write request event.
 * Arguments    : conn_hdl - connection handle
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : none
 **********************************************************************************************************************/
static void evt_write_cmd_protocol_mode(uint16_t conn_hdl, st_ble_gatt_value_t * p_gatt_value)
{
    uint8_t app_value;

    BT_UNPACK_LE_1_BYTE(&app_value, p_gatt_value->p_value);

    st_ble_hids_evt_data_t evt_data = {
        .conn_hdl  = conn_hdl,
        .param_len = sizeof(app_value),
        .p_param   = &app_value,
    };

    gs_hids_cb(BLE_HIDS_EVENT_PROTOCOL_MODE_WRITE_CMD, BLE_SUCCESS, &evt_data);
}

/***********************************************************************************************************************
 * Function Name: evt_write_cmd_boot_keyboard_output_report
 * Description  : This function handles the Boot Keyboard Output Report characteristic write request event.
 * Arguments    : conn_hdl - connection handle
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : none
 **********************************************************************************************************************/
static void evt_write_cmd_boot_keyboard_output_report(uint16_t conn_hdl, st_ble_gatt_value_t * p_gatt_value)
{
    st_ble_hids_evt_data_t evt_data = {
        .conn_hdl  = conn_hdl,
        .param_len = p_gatt_value->value_len,
        .p_param   = p_gatt_value->p_value,
    };

    gs_hids_cb(BLE_HIDS_EVENT_BOOT_KEYBOARD_OUTPUT_REPORT_WRITE_CMD, BLE_SUCCESS, &evt_data);
}

/***********************************************************************************************************************
 * Function Name: evt_write_cmd_hid_control_point
 * Description  : This function handles the HID Control Point characteristic write request event.
 * Arguments    : conn_hdl - connection handle
 *                p_gatt_value - pointer to the characteristic value in the GATT database
 * Return Value : none
 **********************************************************************************************************************/
static void evt_write_cmd_hid_control_point(uint16_t conn_hdl, st_ble_gatt_value_t * p_gatt_value)
{
    uint8_t app_value;

    BT_UNPACK_LE_1_BYTE(&app_value, p_gatt_value->p_value);

    st_ble_hids_evt_data_t evt_data = {
        .conn_hdl  = conn_hdl,
        .param_len = sizeof(app_value),
        .p_param   = &app_value,
    };

    gs_hids_cb(BLE_HIDS_EVENT_HID_CONTROL_POINT_WRITE_CMD, BLE_SUCCESS, &evt_data);
}

/***********************************************************************************************************************
 * Function Name: hids_gatt_db_cb
 * Description  : Callback function for Human Interface Device GATT Server events.
 * Arguments    : conn_hdl - handle to the connection
 *                p_params - pointer to GATTS db parameter
 * Return Value : none
 **********************************************************************************************************************/
static void hids_gatts_db_cb(uint16_t conn_hdl, st_ble_gatts_db_params_t * p_params) // @suppress("Function length")
{
    switch (p_params->db_op)
    {
        case BLE_GATTS_OP_CHAR_PEER_READ_REQ:
        {
            for(uint8_t i = 0; i < BLE_HIDS_SERVICE_NUM; i++)
            {
                if (gs_service_hdl_db[i].protocol_mode_val_hdl == p_params->attr_hdl)
                {
                    st_ble_hids_evt_data_t evt_data = {
                        .conn_hdl  = conn_hdl,
                        .param_len = 0,
                        .p_param   = NULL,
                    };
                    gs_hids_cb(BLE_HIDS_EVENT_PROTOCOL_MODE_READ_REQ, BLE_SUCCESS, &evt_data);
                }
                else if (gs_service_hdl_db[i].boot_keyboard_input_report_hdl->val_hdl == p_params->attr_hdl)
                {
                    st_ble_hids_evt_data_t evt_data = {
                        .conn_hdl  = conn_hdl,
                        .param_len = 0,
                        .p_param   = NULL,
                    };
                    gs_hids_cb(BLE_HIDS_EVENT_BOOT_KEYBOARD_INPUT_REPORT_READ_REQ, BLE_SUCCESS, &evt_data);
                }
                else if (gs_service_hdl_db[i].boot_keyboard_output_report_hdl->val_hdl == p_params->attr_hdl)
                {
                    st_ble_hids_evt_data_t evt_data = {
                        .conn_hdl  = conn_hdl,
                        .param_len = 0,
                        .p_param   = NULL,
                    };
                    gs_hids_cb(BLE_HIDS_EVENT_BOOT_KEYBOARD_OUTPUT_REPORT_READ_REQ, BLE_SUCCESS, &evt_data);
                }
                else if (gs_service_hdl_db[i].boot_mouse_input_report_hdl->val_hdl == p_params->attr_hdl)
                {
                    st_ble_hids_evt_data_t evt_data = {
                        .conn_hdl  = conn_hdl,
                        .param_len = 0,
                        .p_param   = NULL,
                    };
                    gs_hids_cb(BLE_HIDS_EVENT_BOOT_MOUSE_INPUT_REPORT_READ_REQ, BLE_SUCCESS, &evt_data);
                }
                else
                {
                    for(uint8_t j = 0; j < BLE_HIDS_REPORT_NUM; j++)
                    {
                        if(gs_service_hdl_db[i].report_hdl[j].val_hdl == p_params->attr_hdl)
                        {
                            st_ble_hids_evt_data_t evt_data = {
                                    .conn_hdl  = conn_hdl,
                                    .param_len = 0,
                                    .p_param   = NULL,
                            };
                            gs_hids_cb(BLE_HIDS_EVENT_REPORT_READ_REQ, BLE_SUCCESS, &evt_data);
                        }
                    }
                }
            }
        } break;

        case BLE_GATTS_OP_CHAR_PEER_WRITE_REQ:
        {
            for(uint8_t i = 0; i < BLE_HIDS_SERVICE_NUM; i++)
            {
                if (gs_service_hdl_db[i].boot_keyboard_input_report_hdl->val_hdl == p_params->attr_hdl)
                {
                    evt_write_req_boot_keyboard_input_report(conn_hdl, &p_params->value);
                }
                else if (gs_service_hdl_db[i].boot_keyboard_output_report_hdl->val_hdl == p_params->attr_hdl)
                {
                    evt_write_req_boot_keyboard_output_report(conn_hdl, &p_params->value);
                }
                else if (gs_service_hdl_db[i].boot_mouse_input_report_hdl->val_hdl == p_params->attr_hdl)
                {
                    evt_write_req_boot_mouse_input_report(conn_hdl, &p_params->value);
                }
                else
                {
                    for(uint8_t j = 0; j < BLE_HIDS_REPORT_NUM; j++)
                    {
                        if(gs_service_hdl_db[i].report_hdl[j].val_hdl == p_params->attr_hdl)
                        {
                            evt_write_req_report(conn_hdl, &p_params->value);
                        }
                    }
                }
            }
        } break;

        case BLE_GATTS_OP_CHAR_PEER_WRITE_CMD:
        {
            for(uint8_t i = 0; i < BLE_HIDS_SERVICE_NUM; i++)
            {
                if (gs_service_hdl_db[i].protocol_mode_val_hdl == p_params->attr_hdl)
                {
                    evt_write_cmd_protocol_mode(conn_hdl, &p_params->value);
                }
                else if (gs_service_hdl_db[i].boot_keyboard_output_report_hdl->val_hdl == p_params->attr_hdl)
                {
                    evt_write_cmd_boot_keyboard_output_report(conn_hdl, &p_params->value);
                }
                else if (gs_service_hdl_db[i].hid_control_val_hdl == p_params->attr_hdl)
                {
                    evt_write_cmd_hid_control_point(conn_hdl, &p_params->value);
                }
                else
                {
                    /* Do nothing. */
                }
            }
        } break;

        case BLE_GATTS_OP_CHAR_PEER_CLI_CNFG_WRITE_REQ:
        {
            uint16_t cli_cnfg;

            st_ble_hids_evt_data_t evt_data = {
                .conn_hdl  = conn_hdl,
                .param_len = 0,
                .p_param   = NULL,
            };

            BT_UNPACK_LE_2_BYTE(&cli_cnfg, p_params->value.p_value);

            for(uint8_t i = 0; i < BLE_HIDS_SERVICE_NUM; i++)
            {
                if (gs_service_hdl_db[i].boot_keyboard_input_report_hdl->cli_cnfg_hdl == p_params->attr_hdl)
                {
                    if (BLE_GATTS_CLI_CNFG_NOTIFICATION == cli_cnfg)
                    {
                        gs_hids_cb(BLE_HIDS_EVENT_BOOT_KEYBOARD_INPUT_REPORT_CLI_CNFG_ENABLED, BLE_SUCCESS, &evt_data);
                    }
                    else
                    {
                        gs_hids_cb(BLE_HIDS_EVENT_BOOT_KEYBOARD_INPUT_REPORT_CLI_CNFG_DISABLED, BLE_SUCCESS, &evt_data);
                    }
                }
                else if (gs_service_hdl_db[i].boot_mouse_input_report_hdl->cli_cnfg_hdl == p_params->attr_hdl)
                {
                    if (BLE_GATTS_CLI_CNFG_NOTIFICATION == cli_cnfg)
                    {
                        gs_hids_cb(BLE_HIDS_EVENT_BOOT_MOUSE_INPUT_REPORT_CLI_CNFG_ENABLED, BLE_SUCCESS, &evt_data);
                    }
                    else
                    {
                        gs_hids_cb(BLE_HIDS_EVENT_BOOT_MOUSE_INPUT_REPORT_CLI_CNFG_DISABLED, BLE_SUCCESS, &evt_data);
                    }
                }
                else
                {
                    for(uint8_t j = 0; j < BLE_HIDS_REPORT_NUM; j++)
                    {
                        if(gs_service_hdl_db[i].report_hdl[j].val_hdl == p_params->attr_hdl)
                        {
                            st_ble_hids_evt_data_t evt_data = {
                                    .conn_hdl  = conn_hdl,
                                    .param_len = 0,
                                    .p_param   = NULL,
                            };
                            gs_hids_cb(BLE_HIDS_EVENT_REPORT_READ_REQ, BLE_SUCCESS, &evt_data);
                        }
                    }
                }
            }
        } break;

        default:
        {
            /* Do nothing. */
        } break;
    }
}

/***********************************************************************************************************************
 * Function Name: hid_gatts_cb
 * Description  : Callback function for the GATT Server events.
 * Arguments    : type - event id
 *                result - ble status
 *                p_data - pointer to the event data
 * Return Value : none
 **********************************************************************************************************************/
static void hids_gatts_cb(uint16_t type, ble_status_t result, st_ble_gatts_evt_data_t * p_data)
{
    switch (type)
    {
        case BLE_GATTS_EVENT_DB_ACCESS_IND:
        {
            st_ble_gatts_db_access_evt_t * p_db_access_evt_param =
                (st_ble_gatts_db_access_evt_t *)p_data->p_param;

            hids_gatts_db_cb(p_data->conn_hdl, p_db_access_evt_param->p_params);
        } break;

        default:
        {
            /* Do nothing. */
        } break;
    }
}

ble_status_t R_BLE_HIDS_Init(const st_ble_hids_init_param_t * p_param) // @suppress("API function naming") // @suppress("Function declaration")
{
    if (NULL == p_param)
    {
        return BLE_ERR_INVALID_PTR;
    }

    if (NULL == p_param->cb)
    {
        return BLE_ERR_INVALID_ARG;
    }

    R_BLE_GATTS_RegisterCb(hids_gatts_cb, 1);

    gs_hids_cb = p_param->cb;

    return BLE_SUCCESS;
}

ble_status_t R_BLE_HIDS_Connect(uint16_t conn_hdl, uint8_t idx, const st_ble_hids_connect_param_t * p_param) // @suppress("API function naming")
{
    uint8_t init_protocol_mode = BLE_HIDS_PROTOCOL_MODE_PROTOCOL_MODE_VALUE_REPORT_PROTOCOL_MODE;

    if (BLE_GAP_INVALID_CONN_HDL == conn_hdl)
    {
        return BLE_ERR_INVALID_HDL;
    }
    if(BLE_HIDS_SERVICE_NUM <= idx)
    {
        return BLE_ERR_INVALID_ARG;
    }

    if (NULL != p_param)
    {
        for(uint8_t i = 0; i < BLE_HIDS_REPORT_NUM; i++)
        {
            if(BLE_HIDS_REPORT_TYPE_INPUT == get_report_type(idx, i))
            {
                set_cli_cnfg(conn_hdl, gs_service_hdl_db[idx].report_hdl[i].cli_cnfg_hdl, p_param->report_cli_cnfg[i]);
            }
        }
            set_cli_cnfg(conn_hdl, gs_service_hdl_db[idx].boot_keyboard_input_report_hdl->cli_cnfg_hdl, p_param->boot_keyboard_input_report_cli_cnfg);
            set_cli_cnfg(conn_hdl, gs_service_hdl_db[idx].boot_mouse_input_report_hdl->cli_cnfg_hdl, p_param->boot_mouse_input_report_cli_cnfg);
    }

        /** The Protocol Mode characteristic value shall be reset to the default value following connection establishment. */
        R_BLE_HIDS_SetProtocolMode(idx, &init_protocol_mode);

    return BLE_SUCCESS;
}

ble_status_t R_BLE_HIDS_Disconnect(uint16_t conn_hdl, uint8_t idx, st_ble_hids_disconnect_param_t * p_param) // @suppress("API function naming")
{
    if (BLE_GAP_INVALID_CONN_HDL == conn_hdl)
    {
        return BLE_ERR_INVALID_HDL;
    }
    if(BLE_HIDS_SERVICE_NUM <= idx)
    {
        return BLE_ERR_INVALID_ARG;
    }

    if (NULL != p_param)
    {
        for(uint8_t i = 0; i < BLE_HIDS_REPORT_NUM; i++)
        {
            if(BLE_HIDS_REPORT_TYPE_INPUT == get_report_type(idx, i))
            {
                get_cli_cnfg(conn_hdl, gs_service_hdl_db[idx].report_hdl[i].cli_cnfg_hdl, &p_param->report_cli_cnfg[i]);
            }
        }
            get_cli_cnfg(conn_hdl, gs_service_hdl_db[idx].boot_keyboard_input_report_hdl->cli_cnfg_hdl, &p_param->boot_keyboard_input_report_cli_cnfg);
            get_cli_cnfg(conn_hdl, gs_service_hdl_db[idx].boot_mouse_input_report_hdl->cli_cnfg_hdl, &p_param->boot_mouse_input_report_cli_cnfg);
    }

    return BLE_SUCCESS;
}

ble_status_t R_BLE_HIDS_GetProtocolMode(uint8_t idx, uint8_t * p_app_value) // @suppress("API function naming")
{
    st_ble_gatt_value_t gatt_value;
    ble_status_t ret;

    if(NULL == p_app_value)
    {
        return BLE_ERR_INVALID_PTR;
    }
    if(BLE_HIDS_SERVICE_NUM <= idx)
    {
        return BLE_ERR_INVALID_ARG;
    }

    ret = R_BLE_GATTS_GetAttr(BLE_GAP_INVALID_CONN_HDL, gs_service_hdl_db[idx].protocol_mode_val_hdl, &gatt_value);

    if (BLE_SUCCESS == ret)
    {
        BT_UNPACK_LE_1_BYTE(p_app_value, gatt_value.p_value);
    }

    return ret;
}

ble_status_t R_BLE_HIDS_SetProtocolMode(uint8_t idx, const uint8_t * p_app_value) // @suppress("API function naming")
{
    uint8_t byte_value[BLE_HIDS_PROTOCOL_MODE_LEN] = { 0 };
    BT_PACK_LE_1_BYTE(byte_value, p_app_value);

    if (NULL == p_app_value)
    {
        return BLE_ERR_INVALID_PTR;
    }
    if(BLE_HIDS_SERVICE_NUM <= idx)
    {
        return BLE_ERR_INVALID_ARG;
    }

    st_ble_gatt_value_t gatt_value = {
        .p_value   = byte_value,
        .value_len = sizeof(*p_app_value),
    };

    return R_BLE_GATTS_SetAttr(BLE_GAP_INVALID_CONN_HDL, gs_service_hdl_db[idx].protocol_mode_val_hdl, &gatt_value);
}

ble_status_t R_BLE_HIDS_SetReport(uint8_t idx, uint8_t report_id, st_ble_gatt_value_t * p_app_value) // @suppress("API function naming")
{
    if ((NULL == p_app_value) || (NULL == p_app_value->p_value))
    {
        return BLE_ERR_INVALID_PTR;
    }
    if((BLE_HIDS_REPORT_LEN < p_app_value->value_len) || (BLE_HIDS_REPORT_NUM <= report_id) || (BLE_HIDS_SERVICE_NUM <= idx))
    {
        return BLE_ERR_INVALID_ARG;
    }

    return R_BLE_GATTS_SetAttr(BLE_GAP_INVALID_CONN_HDL, gs_service_hdl_db[idx].report_hdl[report_id].val_hdl, p_app_value);
}

ble_status_t R_BLE_HIDS_NotifyReport(uint16_t conn_hdl, uint8_t idx, uint8_t report_id, const st_ble_gatt_value_t * p_app_value) // @suppress("API function naming")
{
    ble_status_t ret;
    uint16_t cli_cnfg;

    if((NULL == p_app_value) || (NULL == p_app_value->p_value))
    {
        return BLE_ERR_INVALID_PTR;
    }
    if((BLE_HIDS_REPORT_LEN < p_app_value->value_len) || (BLE_HIDS_REPORT_NUM <= report_id) || (BLE_HIDS_SERVICE_NUM <= idx))
    {
        return BLE_ERR_INVALID_ARG;
    }
    if(BLE_HIDS_REPORT_TYPE_INPUT != get_report_type(idx, report_id))
    {
        return BLE_ERR_INVALID_OPERATION;
    }

    ret = get_cli_cnfg(conn_hdl, gs_service_hdl_db[idx].report_hdl[report_id].cli_cnfg_hdl, &cli_cnfg);

    if (BLE_SUCCESS != ret)
    {
        return BLE_ERR_INVALID_HDL;
    }
    if ((cli_cnfg & BLE_GATTS_CLI_CNFG_NOTIFICATION) == 0x0000)
    {
        return BLE_ERR_INVALID_HDL;
    }

    st_ble_gatt_hdl_value_pair_t ntf_data = {
        .attr_hdl        = gs_service_hdl_db[idx].report_hdl[report_id].val_hdl,
        .value.p_value   = p_app_value->p_value,
        .value.value_len = p_app_value->value_len,
    };

    return R_BLE_GATTS_Notification(conn_hdl, &ntf_data);
}

ble_status_t R_BLE_HIDS_GetReportReportReference(uint8_t idx, uint8_t report_id, st_ble_hids_report_report_reference_t * p_app_value)
{
    st_ble_gatt_value_t gatt_value;
    ble_status_t ret;

    if(NULL == p_app_value)
    {
        return BLE_ERR_INVALID_PTR;
    }
    if((BLE_HIDS_SERVICE_NUM <= idx) || (BLE_HIDS_REPORT_NUM <= report_id))
    {
        return BLE_ERR_INVALID_ARG;
    }

    ret = R_BLE_GATTS_GetAttr(BLE_GAP_INVALID_CONN_HDL, gs_service_hdl_db[idx].report_hdl[report_id].report_reference_hdl, &gatt_value);

    if (BLE_SUCCESS == ret)
    {
        decode_report_report_reference(p_app_value, &gatt_value);
    }

    return (ret);
}

ble_status_t R_BLE_HIDS_GetReportMap(uint8_t idx, st_ble_gatt_value_t * p_app_value) // @suppress("API function naming")
{
    st_ble_gatt_value_t gatt_value;
    ble_status_t ret;

    if(NULL == p_app_value)
    {
        return BLE_ERR_INVALID_PTR;
    }
    if(BLE_HIDS_SERVICE_NUM <= idx)
    {
        return BLE_ERR_INVALID_ARG;
    }

    ret = R_BLE_GATTS_GetAttr(BLE_GAP_INVALID_CONN_HDL, gs_service_hdl_db[idx].report_map_val_hdl, &gatt_value);

    if (BLE_SUCCESS == ret)
    {
        if(gatt_value.value_len > BLE_HIDS_REPORT_MAP_LEN)
        {
            return BLE_ERR_INVALID_ARG;
        }
        decode_report_map(p_app_value, &gatt_value);
    }

    return ret;
}

ble_status_t R_BLE_HIDS_GetReportMapExternalReportReference(uint8_t idx, uint16_t * p_app_value) // @suppress("API function naming")
{
    st_ble_gatt_value_t gatt_value;
    ble_status_t ret;

    if(NULL == p_app_value)
    {
        return BLE_ERR_INVALID_PTR;
    }
    if(BLE_HIDS_SERVICE_NUM <= idx)
    {
        return BLE_ERR_INVALID_ARG;
    }

    ret = R_BLE_GATTS_GetAttr(BLE_GAP_INVALID_CONN_HDL, gs_service_hdl_db[idx].external_report_reference_hdl, &gatt_value);

    if (BLE_SUCCESS == ret)
    {
        BT_UNPACK_LE_2_BYTE(p_app_value, gatt_value.p_value);
    }
    return ret;
}

ble_status_t R_BLE_HIDS_SetBootKeyboardInputReport(uint8_t idx, st_ble_gatt_value_t * p_app_value) // @suppress("API function naming")
{
    if ((NULL == p_app_value) || (NULL == p_app_value->p_value))
    {
        return BLE_ERR_INVALID_PTR;
    }
    if((BLE_HIDS_BOOT_KEYBOARD_INPUT_REPORT_LEN < p_app_value->value_len) || (BLE_HIDS_SERVICE_NUM <= idx))
    {
        return BLE_ERR_INVALID_ARG;
    }

    return R_BLE_GATTS_SetAttr(BLE_GAP_INVALID_CONN_HDL, gs_service_hdl_db[idx].boot_keyboard_input_report_hdl->val_hdl, p_app_value);
}

ble_status_t R_BLE_HIDS_NotifyBootKeyboardInputReport(uint16_t conn_hdl, uint8_t idx, const st_ble_gatt_value_t * p_app_value) // @suppress("API function naming")
{
    ble_status_t ret;
    uint16_t cli_cnfg;

    if((NULL == p_app_value) || (NULL == p_app_value->p_value))
    {
        return BLE_ERR_INVALID_PTR;
    }
    if((BLE_HIDS_BOOT_KEYBOARD_INPUT_REPORT_LEN < p_app_value->value_len) || (BLE_HIDS_SERVICE_NUM <= idx))
    {
        return BLE_ERR_INVALID_ARG;
    }

    ret = get_cli_cnfg(conn_hdl, gs_service_hdl_db[idx].boot_keyboard_input_report_hdl->cli_cnfg_hdl, &cli_cnfg);

    if (BLE_SUCCESS != ret)
    {
        return BLE_ERR_INVALID_HDL;
    }

    if ((cli_cnfg & BLE_GATTS_CLI_CNFG_NOTIFICATION) == 0x0000)
    {
        return BLE_ERR_INVALID_STATE;
    }

    st_ble_gatt_hdl_value_pair_t ntf_data = {
        .attr_hdl        = gs_service_hdl_db[idx].boot_keyboard_input_report_hdl->val_hdl,
        .value.p_value   = p_app_value->p_value,
        .value.value_len = p_app_value->value_len,
    };

    return R_BLE_GATTS_Notification(conn_hdl, &ntf_data);
}

ble_status_t R_BLE_HIDS_SetBootKeyboardOutputReport(uint8_t idx, st_ble_gatt_value_t * p_app_value) // @suppress("API function naming")
{
    if((NULL == p_app_value) || (NULL == p_app_value->p_value))
    {
        return BLE_ERR_INVALID_PTR;
    }
    if((BLE_HIDS_BOOT_KEYBOARD_OUTPUT_REPORT_LEN < p_app_value->value_len) || (BLE_HIDS_SERVICE_NUM <= idx))
    {
        return BLE_ERR_INVALID_ARG;
    }

    return R_BLE_GATTS_SetAttr(BLE_GAP_INVALID_CONN_HDL, gs_service_hdl_db[idx].boot_keyboard_output_report_hdl->val_hdl, p_app_value);
}

ble_status_t R_BLE_HIDS_SetBootMouseInputReport(uint8_t idx, st_ble_gatt_value_t * p_app_value) // @suppress("API function naming")
{
    if((NULL == p_app_value) || (NULL == p_app_value->p_value))
    {
        return BLE_ERR_INVALID_PTR;
    }
    if((BLE_HIDS_BOOT_MOUSE_INPUT_REPORT_LEN < p_app_value->value_len) || (BLE_HIDS_SERVICE_NUM <= idx))
    {
        return BLE_ERR_INVALID_ARG;
    }
    return R_BLE_GATTS_SetAttr(BLE_GAP_INVALID_CONN_HDL, gs_service_hdl_db[idx].boot_mouse_input_report_hdl->val_hdl, p_app_value);
}

ble_status_t R_BLE_HIDS_NotifyBootMouseInputReport(uint16_t conn_hdl, uint8_t idx, const st_ble_gatt_value_t * p_app_value) // @suppress("API function naming")
{
    ble_status_t ret;
    uint16_t cli_cnfg;

    if((NULL == p_app_value) || (NULL == p_app_value->p_value))
    {
        return BLE_ERR_INVALID_PTR;
    }
    if((BLE_HIDS_BOOT_MOUSE_INPUT_REPORT_LEN < p_app_value->value_len) || (BLE_HIDS_SERVICE_NUM <= idx))
    {
        return BLE_ERR_INVALID_ARG;
    }

    ret = get_cli_cnfg(conn_hdl, gs_service_hdl_db[idx].boot_mouse_input_report_hdl->cli_cnfg_hdl, &cli_cnfg);

    if (BLE_SUCCESS != ret)
    {
        return BLE_ERR_INVALID_HDL;
    }
    if ((cli_cnfg & BLE_GATTS_CLI_CNFG_NOTIFICATION) == 0x0000)
    {
        return BLE_ERR_INVALID_STATE;
    }

    st_ble_gatt_hdl_value_pair_t ntf_data = {
        .attr_hdl        = gs_service_hdl_db[idx].boot_mouse_input_report_hdl->val_hdl,
        .value.p_value   = p_app_value->p_value,
        .value.value_len = p_app_value->value_len,
    };

    return R_BLE_GATTS_Notification(conn_hdl, &ntf_data);
}

ble_status_t R_BLE_HIDS_GetHidInformation(uint8_t idx, st_ble_hids_hid_information_t * p_app_value) // @suppress("API function naming")
{
    st_ble_gatt_value_t gatt_value;
    ble_status_t ret;

    if(NULL == p_app_value)
    {
        return BLE_ERR_INVALID_PTR;
    }
    if(BLE_HIDS_SERVICE_NUM <= idx)
    {
        return BLE_ERR_INVALID_ARG;
    }

    ret = R_BLE_GATTS_GetAttr(BLE_GAP_INVALID_CONN_HDL, gs_service_hdl_db[idx].hid_information_val_hdl, &gatt_value);

    if (BLE_SUCCESS == ret)
    {
        decode_hid_information(p_app_value, &gatt_value);
    }

    return ret;
}

uint32_t R_BLE_HIDS_GetVersion(void) // @suppress("API function naming")
{
    uint32_t version;

    version = ((BLE_HIDS_PRV_VERSION_MAJOR << 16) | (BLE_HIDS_PRV_VERSION_MINOR << 8));

    return version;
}

