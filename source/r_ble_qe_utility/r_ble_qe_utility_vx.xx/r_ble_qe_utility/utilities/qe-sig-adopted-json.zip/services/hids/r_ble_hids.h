/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2018 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_hids.h
 * Version : 1.0
 * Description : This module implements Human Interface Device Service Server.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 31.12.2999 1.00 First Release
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @file
 * @defgroup hids Human Interface Device Service Server 
 * @{
 * @ingroup profile
 * @brief   This service exposes the HID reports and other HID data intended for HID Hosts and HID Devices.
 **********************************************************************************************************************/

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "profile_cmn/r_ble_serv_common.h"

#include "r_ble_hids_record.h"

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
#ifndef R_BLE_HIDS
#define R_BLE_HIDS

/*******************************************************************************************************************//**
 * @brief RemoteWake bit.
***********************************************************************************************************************/
#define BLE_HIDS_HID_INFORMATION_FLAGS_REMOTEWAKE (1 << 0)
            
/*******************************************************************************************************************//**
 * @brief NormallyConnectable bit.
***********************************************************************************************************************/
#define BLE_HIDS_HID_INFORMATION_FLAGS_NORMALLYCONNECTABLE (1 << 1)
            
/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @brief Human Interface Device Service event data.
***********************************************************************************************************************/
typedef struct
{
    uint16_t  conn_hdl;  /**< Connection handle */
    uint16_t  param_len; /**< Event parameter length */
    void     * p_param;    /**< Event parameter */
} st_ble_hids_evt_data_t;

/*******************************************************************************************************************//**
 * @brief Human Interface Device Service event callback.
***********************************************************************************************************************/
typedef void (*ble_hids_app_cb_t)(uint16_t type, ble_status_t result, st_ble_hids_evt_data_t * data);

/*******************************************************************************************************************//**
 * @brief Human Interface Device Service event type.
***********************************************************************************************************************/
typedef enum {
    BLE_HIDS_EVENT_REPORT_CLI_CNFG_ENABLED, /**< Report characteristic cli cnfg enabled event */
    BLE_HIDS_EVENT_REPORT_CLI_CNFG_DISABLED, /**< Report characteristic cli cnfg disabled event */
    BLE_HIDS_EVENT_BOOT_KEYBOARD_INPUT_REPORT_CLI_CNFG_ENABLED, /**< Boot Keyboard Input Report characteristic cli cnfg enabled event */
    BLE_HIDS_EVENT_BOOT_KEYBOARD_INPUT_REPORT_CLI_CNFG_DISABLED, /**< Boot Keyboard Input Report characteristic cli cnfg disabled event */
    BLE_HIDS_EVENT_BOOT_MOUSE_INPUT_REPORT_CLI_CNFG_ENABLED, /**< Boot Mouse Input Report characteristic cli cnfg enabled event */
    BLE_HIDS_EVENT_BOOT_MOUSE_INPUT_REPORT_CLI_CNFG_DISABLED, /**< Boot Mouse Input Report characteristic cli cnfg disabled event */
    BLE_HIDS_EVENT_REPORT_WRITE_REQ, /**< Report characteristic write request event */
    BLE_HIDS_EVENT_BOOT_KEYBOARD_INPUT_REPORT_WRITE_REQ, /**< Boot Keyboard Input Report characteristic write request event */
    BLE_HIDS_EVENT_BOOT_KEYBOARD_OUTPUT_REPORT_WRITE_REQ, /**< Boot Keyboard Output Report characteristic write request event */
    BLE_HIDS_EVENT_BOOT_MOUSE_INPUT_REPORT_WRITE_REQ, /**< Boot Mouse Input Report characteristic write request event */
    BLE_HIDS_EVENT_PROTOCOL_MODE_WRITE_CMD, /**< Protocol Mode characteristic write command event */
    BLE_HIDS_EVENT_BOOT_KEYBOARD_OUTPUT_REPORT_WRITE_CMD, /**< Boot Keyboard Output Report characteristic write command event */
    BLE_HIDS_EVENT_HID_CONTROL_POINT_WRITE_CMD, /**< HID Control Point characteristic write command event */
    BLE_HIDS_EVENT_PROTOCOL_MODE_READ_REQ, /**< Protocol Mode characteristic read request event */
    BLE_HIDS_EVENT_REPORT_READ_REQ, /**< Report characteristic read request event */
    BLE_HIDS_EVENT_REPORT_MAP_READ_REQ, /**< Report Map characteristic read request event */
    BLE_HIDS_EVENT_BOOT_KEYBOARD_INPUT_REPORT_READ_REQ, /**< Boot Keyboard Input Report characteristic read request event */
    BLE_HIDS_EVENT_BOOT_KEYBOARD_OUTPUT_REPORT_READ_REQ, /**< Boot Keyboard Output Report characteristic read request event */
    BLE_HIDS_EVENT_BOOT_MOUSE_INPUT_REPORT_READ_REQ, /**< Boot Mouse Input Report characteristic read request event */
    BLE_HIDS_EVENT_HID_INFORMATION_READ_REQ, /**< HID Information characteristic read request event */
} e_ble_hids_event_t;

/*******************************************************************************************************************//**
 * @brief Human Interface Device Service connection parameters.
***********************************************************************************************************************/
typedef struct {
    uint16_t report_cli_cnfg[BLE_HIDS_REPORT_NUM]; /**< Report characteristic cli cnfg */
    uint16_t boot_keyboard_input_report_cli_cnfg; /**< Boot Keyboard Input Report characteristic cli cnfg */
    uint16_t boot_mouse_input_report_cli_cnfg; /**< Boot Mouse Input Report characteristic cli cnfg */
} st_ble_hids_connect_param_t;

/*******************************************************************************************************************//**
 * @brief Human Interface Device Service disconnection parameters.
***********************************************************************************************************************/
typedef struct {
    uint16_t report_cli_cnfg[BLE_HIDS_REPORT_NUM]; /**< Report characteristic cli cnfg */
    uint16_t boot_keyboard_input_report_cli_cnfg; /**< Boot Keyboard Input Report characteristic cli cnfg */
    uint16_t boot_mouse_input_report_cli_cnfg; /**< Boot Mouse Input Report characteristic cli cnfg */
} st_ble_hids_disconnect_param_t;

/*******************************************************************************************************************//**
 * @brief Protocol Mode Value enumeration.
***********************************************************************************************************************/
typedef enum {
    BLE_HIDS_PROTOCOL_MODE_PROTOCOL_MODE_VALUE_BOOT_PROTOCOL_MODE = 0, /**< Boot Protocol Mode */
    BLE_HIDS_PROTOCOL_MODE_PROTOCOL_MODE_VALUE_REPORT_PROTOCOL_MODE = 1, /**< Report Protocol Mode */
} e_ble_hids_protocol_mode_t;

/*******************************************************************************************************************//**
 * @brief HID Control Point Command enumeration.
***********************************************************************************************************************/
typedef enum {
    BLE_HIDS_HID_CONTROL_POINT_HID_CONTROL_POINT_COMMAND_SUSPEND = 0, /**< entering Suspend State */
    BLE_HIDS_HID_CONTROL_POINT_HID_CONTROL_POINT_COMMAND_EXIT_SUSPEND = 1, /**< exiting Suspend State */
} e_ble_hids_hid_control_point_t;

/*******************************************************************************************************************//**
 * @brief Human Interface Device Service initialization parameters.
***********************************************************************************************************************/
typedef struct {
    ble_hids_app_cb_t cb; /**< Human Interface Device Service event callback */
} st_ble_hids_init_param_t;

/*******************************************************************************************************************//**
 * @brief Report characteristic parameters.
***********************************************************************************************************************/
typedef struct {
    uint8_t report_value[64]; /**< Report Value value */
} st_ble_hids_report_t;

/*******************************************************************************************************************//**
 * @brief Report Report Reference descriptor parameters.
***********************************************************************************************************************/
typedef struct {
    uint8_t report_id;  /**< Report ID value */
    uint8_t report_type; /**< Report Type value */
} st_ble_hids_report_report_reference_t;

/*******************************************************************************************************************//**
 * @brief Report Map characteristic parameters.
***********************************************************************************************************************/
typedef struct {
    uint8_t report_map_value[512]; /**< Report Map Value value */
} st_ble_hids_report_map_t;

/*******************************************************************************************************************//**
 * @brief Boot Keyboard Input Report characteristic parameters.
***********************************************************************************************************************/
typedef struct {
    uint8_t boot_keyboard_input_report_value[8]; /**< Boot Keyboard Input Report Value value */
} st_ble_hids_boot_keyboard_input_report_t;

/*******************************************************************************************************************//**
 * @brief Boot Keyboard Output Report characteristic parameters.
***********************************************************************************************************************/
typedef struct {
    uint8_t boot_keyboard_output_report_value[8]; /**< Boot Keyboard Output Report Value value */
} st_ble_hids_boot_keyboard_output_report_t;

/*******************************************************************************************************************//**
 * @brief Boot Mouse Input Report characteristic parameters.
***********************************************************************************************************************/
typedef struct {
    uint8_t boot_mouse_input_report_value[8]; /**< Boot Mouse Input Report Value value */
} st_ble_hids_boot_mouse_input_report_t;

/*******************************************************************************************************************//**
 * @brief HID Information characteristic parameters.
***********************************************************************************************************************/
typedef struct {
    uint16_t bcdhid; /**< bcdHID value */
    uint8_t bcountrycode; /**< bCountryCode value */
    uint8_t flags; /**< Flags value */
} st_ble_hids_hid_information_t;


/***********************************************************************************************************************
Exported global functions (to be accessed by other files)
***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @brief     Initialize Human Interface Device Service.
 * @details   This function shall be called once at startup.
 * @param[in] param Human Interface Device Service initialization parameters.
 * @return
***********************************************************************************************************************/
ble_status_t R_BLE_HIDS_Init(const st_ble_hids_init_param_t * p_param);

/*******************************************************************************************************************//**
 * @brief     Perform Human Interface Device Service connection settings.
 * @details   This function shall be called on each connection establishment.
 * @param[in] conn_hdl Connection handle.
 * @param[in] idx      Service index used to distinguish the multiple same UUID service.
 * @param[in] p_param    Connection parameters.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_HIDS_Connect(uint16_t conn_hdl, uint8_t idx, const st_ble_hids_connect_param_t * p_param);

/*******************************************************************************************************************//**
 * @brief     Retrieve Human Interface Device Service connection specific settings before disconnection.
 * @details   This function shall be called on each disconnection.
 * @param[in] conn_hdl Connection handle.
 * @param[in] idx      Service index used to distinguish the multiple same UUID service.
 * @param[in] p_param    Disconnection parameters.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_HIDS_Disconnect(uint16_t conn_hdl, uint8_t idx, st_ble_hids_disconnect_param_t * p_param);

/*******************************************************************************************************************//**
 * @brief      Get Protocol Mode characteristic value from local GATT database.
 * @param[in]  idx       Service index used to distinguish the multiple same UUID service.
 * @param[out] p_app_value Retrieved Protocol Mode characteristic value.
 * @return     @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_HIDS_GetProtocolMode(uint8_t idx, uint8_t * p_app_value);

/*******************************************************************************************************************//**
 * @brief     Set Protocol Mode characteristic value to local GATT database.
 * @param[in] idx       Service index used to distinguish the multiple same UUID service.
 * @param[in] p_app_value Protocol Mode characteristic value to set.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_HIDS_SetProtocolMode(uint8_t idx, const uint8_t * p_app_value);

/*******************************************************************************************************************//**
 * @brief     Set Report characteristic value to local GATT database.
 * @param[in] idx       Service index used to distinguish the multiple same UUID service.
 * @param[in] report_id Report index used to distinguish the multiple same UUID characteristic.
 * @param[in] app_value Report characteristic value to set.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_HIDS_SetReport(uint8_t idx, uint8_t report_id, st_ble_gatt_value_t * p_app_value);

/*******************************************************************************************************************//**
 * @brief     Send Report notification.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] idx       Service index used to distinguish the multiple same UUID service.
 * @param[in] report_id Report index used to distinguish the multiple same UUID characteristic.
 * @param[in] p_app_value Report value to send.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_HIDS_NotifyReport(uint16_t conn_hdl, uint8_t idx, uint8_t report_id, const st_ble_gatt_value_t * p_app_value);

/*******************************************************************************************************************//**
 * @brief     Get Report characteristic Report Reference descriptor value from local GATT database.
 * @param[in]  idx       Service index used to distinguish the multiple same UUID service.
 * @param[in]  report_id Report index used to distinguish the multiple same UUID characteristic.
 * @param[out] p_app_value Retrieved Report characteristic Report Reference value.
 * @return     @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_HIDS_GetReportReportReference(uint8_t idx, uint8_t report_id, st_ble_hids_report_report_reference_t * p_app_value);

/*******************************************************************************************************************//**
 * @brief      Get Report Map characteristic value from local GATT database.
 * @param[in]  idx       Service index used to distinguish the multiple same UUID service.
 * @param[out] p_app_value Retrieved Report Map characteristic value.
 * @return     @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_HIDS_GetReportMap(uint8_t idx, st_ble_gatt_value_t * p_app_value);

/*******************************************************************************************************************//**
 * @brief      Get Report Map characteristic External Report Reference descriptor value from local GATT database.
 * @param[in]  idx         Service index used to distinguish the multiple same UUID service.
 * @param[out] p_app_value Retrieved Report Map characteristic External Report Reference value.
 * @return     @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_HIDS_GetReportMapExternalReportReference(uint8_t idx, uint16_t * p_app_value);

/*******************************************************************************************************************//**
 * @brief     Set Boot Keyboard Input Report characteristic value to local GATT database.
 * @param[in] idx       Service index used to distinguish the multiple same UUID service.
 * @param[in] p_app_value Boot Keyboard Input Report characteristic value to set.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_HIDS_SetBootKeyboardInputReport(uint8_t idx, st_ble_gatt_value_t * p_app_value);

/*******************************************************************************************************************//**
 * @brief     Send Boot Keyboard Input Report notification.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] idx       Service index used to distinguish the multiple same UUID service.
 * @param[in] p_app_value Boot Keyboard Input Report value to send.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_HIDS_NotifyBootKeyboardInputReport(uint16_t conn_hdl, uint8_t idx, const st_ble_gatt_value_t * p_app_value);

/*******************************************************************************************************************//**
 * @brief     Set Boot Keyboard Output Report characteristic value to local GATT database.
 * @param[in] idx       Service index used to distinguish the multiple same UUID service.
 * @param[in] p_app_value Boot Keyboard Output Report characteristic value to set.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_HIDS_SetBootKeyboardOutputReport(uint8_t idx, st_ble_gatt_value_t * p_app_value) ;

/*******************************************************************************************************************//**
 * @brief     Set Boot Mouse Input Report characteristic value to local GATT database.
 * @param[in] idx       Service index used to distinguish the multiple same UUID service.
 * @param[in] p_app_value Boot Mouse Input Report characteristic value to set.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_HIDS_SetBootMouseInputReport(uint8_t idx, st_ble_gatt_value_t * p_app_value);

/*******************************************************************************************************************//**
 * @brief     Send Boot Mouse Input Report notification.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] idx       Service index used to distinguish the multiple same UUID service.
 * @param[in] p_app_value Boot Mouse Input Report value to send.
 * @return    @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_HIDS_NotifyBootMouseInputReport(uint16_t conn_hdl, uint8_t idx, const st_ble_gatt_value_t * p_app_value);

/*******************************************************************************************************************//**
 * @brief      Get HID Information characteristic value from local GATT database.
 * @param[in]  idx       Service index used to distinguish the multiple same UUID service.
 * @param[out] p_app_value Retrieved HID Information characteristic value.
 * @return     @ref ble_status_t
***********************************************************************************************************************/
ble_status_t R_BLE_HIDS_GetHidInformation(uint8_t idx, st_ble_hids_hid_information_t * p_app_value);

/*******************************************************************************************************************//**
 * @brief     Return version of the HIDC service server.
 * @return    version
***********************************************************************************************************************/
uint32_t R_BLE_HIDS_GetVersion(void);


#endif /* R_BLE_HIDS */

/** @} */
