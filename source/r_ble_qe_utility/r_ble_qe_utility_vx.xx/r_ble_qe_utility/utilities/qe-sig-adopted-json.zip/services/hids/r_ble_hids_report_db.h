/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2018 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

#include "r_ble_rx23w_if.h"
#include "services/common/r_ble_profile_cmn.h"

#include "gatt_db.h"


#ifndef R_BLE_HIDS_REPORT_DB_H
#define R_BLE_HIDS_REPORT_DB_H

#define BLE_HIDS_REPORT_NO_CLI_CNFG (0)

#define BLE_HIDS_SERVICE_NUM (1)
#define BLE_HIDS_REPORT_NUM (3)


typedef enum{
    BLE_HIDS_REPORT_TYPE_INPUT = 0x01,
    BLE_HIDS_REPORT_TYPE_OUTPUT,
    BLE_HIDS_REPORT_TYPE_FEATURE
}e_ble_hids_report_type_t;

typedef struct {
    uint8_t val_hdl;
    uint8_t cli_cnfg_hdl;
    uint8_t report_reference_hdl;
}st_ble_hids_report_hdl_t;

typedef struct {
    uint8_t val_hdl;
    uint8_t cli_cnfg_hdl;
}st_ble_hids_boot_report_hdl_t;

typedef struct {
        uint8_t protocol_mode_val_hdl;
        st_ble_hids_report_hdl_t * report_hdl;
        uint8_t report_map_val_hdl;
        uint8_t external_report_reference_hdl;
        st_ble_hids_boot_report_hdl_t * boot_keyboard_input_report_hdl;
        st_ble_hids_boot_report_hdl_t * boot_keyboard_output_report_hdl;
        st_ble_hids_boot_report_hdl_t * boot_mouse_input_report_hdl;
        uint8_t hid_information_val_hdl;
        uint8_t hid_control_val_hdl;
} st_hids_service_hdl_t;

#if 0
static st_ble_hids_boot_report_hdl_t gs_boot_report_hdl_db_1[3] = {
        {
            .val_hdl        = BLE_HIDS_BOOT_KEYBOARD_INPUT_REPORT_VAL_HDL_1,
            .cli_cnfg_hdl   = BLE_HIDS_BOOT_KEYBOARD_INPUT_REPORT_CLI_CNFG_HDL_1,
        },
        {
            .val_hdl        = BLE_HIDS_BOOT_KEYBOARD_OUTPUT_REPORT_VAL_HDL_1,
            .cli_cnfg_hdl   = BLE_HIDS_REPORT_NO_CLI_CNFG,
        },
        {
            .val_hdl        = BLE_HIDS_BOOT_MOUSE_INPUT_REPORT_VAL_HDL_1,
            .cli_cnfg_hdl   = BLE_HIDS_BOOT_MOUSE_INPUT_REPORT_CLI_CNFG_HDL_1,
        },
};

static st_ble_hids_boot_report_hdl_t gs_boot_report_hdl_db_2[3] = {
        {
            .val_hdl        = BLE_HIDS_BOOT_KEYBOARD_INPUT_REPORT_VAL_HDL_2,
            .cli_cnfg_hdl   = BLE_HIDS_BOOT_KEYBOARD_INPUT_REPORT_CLI_CNFG_HDL_2,
        },
        {
            .val_hdl        = BLE_HIDS_BOOT_KEYBOARD_OUTPUT_REPORT_VAL_HDL_2,
            .cli_cnfg_hdl   = BLE_HIDS_REPORT_NO_CLI_CNFG,
        },
        {
            .val_hdl        = BLE_HIDS_BOOT_MOUSE_INPUT_REPORT_VAL_HDL_2,
            .cli_cnfg_hdl   = BLE_HIDS_BOOT_MOUSE_INPUT_REPORT_CLI_CNFG_HDL_2,
        },
};

static st_ble_hids_report_hdl_t gs_report_hdl_db_1[BLE_HIDS_REPORT_NUM] = {
        {
            .val_hdl                = BLE_HIDS_REPORT_VAL_HDL_1,
            .cli_cnfg_hdl           = BLE_HIDS_REPORT_CLI_CNFG_HDL_1,
            .report_reference_hdl   = BLE_HIDS_REPORT_REPORT_REFERENCE_HDL_1,
        },
        {
            .val_hdl                = BLE_HIDS_REPORT_VAL_HDL_2,
            .cli_cnfg_hdl           = BLE_HIDS_REPORT_NO_CLI_CNFG,
            .report_reference_hdl   = BLE_HIDS_REPORT_REPORT_REFERENCE_HDL_2,
        },
        {
            .val_hdl                = BLE_HIDS_REPORT_VAL_HDL_3,
            .cli_cnfg_hdl           = BLE_HIDS_REPORT_NO_CLI_CNFG,
            .report_reference_hdl   = BLE_HIDS_REPORT_REPORT_REFERENCE_HDL_3,
        },
};

static st_ble_hids_report_hdl_t gs_report_hdl_db_2[BLE_HIDS_REPORT_NUM] = {
        {
            .val_hdl                = BLE_HIDS_REPORT_VAL_HDL_4,
            .cli_cnfg_hdl           = BLE_HIDS_REPORT_CLI_CNFG_HDL_4,
            .report_reference_hdl   = BLE_HIDS_REPORT_REPORT_REFERENCE_HDL_4,
        },
        {
            .val_hdl                = BLE_HIDS_REPORT_VAL_HDL_5,
            .cli_cnfg_hdl           = BLE_HIDS_REPORT_NO_CLI_CNFG,
            .report_reference_hdl   = BLE_HIDS_REPORT_REPORT_REFERENCE_HDL_5,
        },
        {
            .val_hdl                = BLE_HIDS_REPORT_VAL_HDL_6,
            .cli_cnfg_hdl           = BLE_HIDS_REPORT_NO_CLI_CNFG,
            .report_reference_hdl   = BLE_HIDS_REPORT_REPORT_REFERENCE_HDL_6,
        },
};

static st_hids_service_hdl_t gs_service_hdl_db[BLE_HIDS_SERVICE_NUM] = {
        {
            .protocol_mode_val_hdl              = BLE_HIDS_PROTOCOL_MODE_VAL_HDL_1,
            .report_hdl                         = gs_report_hdl_db_1,
            .report_map_val_hdl                 = BLE_HIDS_REPORT_MAP_VAL_HDL_1,
            .external_report_reference_hdl      = BLE_HIDS_REPORT_MAP_EXTERNAL_REPORT_REFERENCE_HDL_1,
            .boot_keyboard_input_report_hdl     = &gs_boot_report_hdl_db_1[0],
            .boot_keyboard_output_report_hdl    = &gs_boot_report_hdl_db_1[1],
            .boot_mouse_input_report_hdl        = &gs_boot_report_hdl_db_1[2],
            .hid_information_val_hdl            = BLE_HIDS_HID_INFORMATION_VAL_HDL_1,
            .hid_control_val_hdl                = BLE_HIDS_HID_CONTROL_POINT_VAL_HDL_1
        },
        {
            .protocol_mode_val_hdl              = BLE_HIDS_PROTOCOL_MODE_VAL_HDL_2,
            .report_hdl                         = gs_report_hdl_db_2,
            .report_map_val_hdl                 = BLE_HIDS_REPORT_MAP_VAL_HDL_2,
            .external_report_reference_hdl      = BLE_HIDS_REPORT_MAP_EXTERNAL_REPORT_REFERENCE_HDL_2,
            .boot_keyboard_input_report_hdl     = &gs_boot_report_hdl_db_2[0],
            .boot_keyboard_output_report_hdl    = &gs_boot_report_hdl_db_2[1],
            .boot_mouse_input_report_hdl        = &gs_boot_report_hdl_db_2[2],
            .hid_information_val_hdl            = BLE_HIDS_HID_INFORMATION_VAL_HDL_2,
            .hid_control_val_hdl                = BLE_HIDS_HID_CONTROL_POINT_VAL_HDL_2
        },
};
#endif

static st_ble_hids_boot_report_hdl_t gs_boot_report_hdl_db[3] = {
        {
            .val_hdl        = BLE_HIDS_BOOT_KEYBOARD_INPUT_REPORT_VAL_HDL,
            .cli_cnfg_hdl   = BLE_HIDS_BOOT_KEYBOARD_INPUT_REPORT_CLI_CNFG_HDL,
        },
        {
            .val_hdl        = BLE_HIDS_BOOT_KEYBOARD_OUTPUT_REPORT_VAL_HDL,
            .cli_cnfg_hdl   = BLE_HIDS_REPORT_NO_CLI_CNFG,
        },
        {
            .val_hdl        = BLE_HIDS_BOOT_MOUSE_INPUT_REPORT_VAL_HDL,
            .cli_cnfg_hdl   = BLE_HIDS_BOOT_MOUSE_INPUT_REPORT_CLI_CNFG_HDL,
        },
};

static st_ble_hids_report_hdl_t gs_report_hdl_db[BLE_HIDS_REPORT_NUM] = {
        {
            .val_hdl = BLE_HIDS_REPORT_VAL_HDL_1,
            .cli_cnfg_hdl = BLE_HIDS_REPORT_CLI_CNFG_HDL_1,
            .report_reference_hdl = BLE_HIDS_REPORT_REPORT_REFERENCE_HDL_1,
        },
        {
            .val_hdl = BLE_HIDS_REPORT_VAL_HDL_2,
            .cli_cnfg_hdl = BLE_HIDS_REPORT_NO_CLI_CNFG,
            .report_reference_hdl = BLE_HIDS_REPORT_REPORT_REFERENCE_HDL_2,
        },
        {
            .val_hdl = BLE_HIDS_REPORT_VAL_HDL_3,
            .cli_cnfg_hdl = BLE_HIDS_REPORT_NO_CLI_CNFG,
            .report_reference_hdl = BLE_HIDS_REPORT_REPORT_REFERENCE_HDL_3,
        },
};


static st_hids_service_hdl_t gs_service_hdl_db[BLE_HIDS_SERVICE_NUM] = {
        {
            .protocol_mode_val_hdl              = BLE_HIDS_PROTOCOL_MODE_VAL_HDL,
            .report_hdl                         = gs_report_hdl_db,
            .report_map_val_hdl                 = BLE_HIDS_REPORT_MAP_VAL_HDL,
            .external_report_reference_hdl      = BLE_HIDS_REPORT_MAP_EXTERNAL_REPORT_REFERENCE_HDL,
            .boot_keyboard_input_report_hdl     = &gs_boot_report_hdl_db[0],
            .boot_keyboard_output_report_hdl    = &gs_boot_report_hdl_db[1],
            .boot_mouse_input_report_hdl        = &gs_boot_report_hdl_db[2],
            .hid_information_val_hdl            = BLE_HIDS_HID_INFORMATION_VAL_HDL,
            .hid_control_val_hdl                = BLE_HIDS_HID_CONTROL_POINT_VAL_HDL
        },
};

#endif /* R_BLE_HIDS_REPORT_DB_H */

