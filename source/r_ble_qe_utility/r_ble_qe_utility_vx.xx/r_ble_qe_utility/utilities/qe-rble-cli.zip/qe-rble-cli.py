# QE set following variable
# qe_rble_path : rble folder path (full path)
# qe_input_json_type : "ProfileDefinition" or "ServiceDefinition" or "GATTDB"
# qe_input_json_file_path : json file path (full path). for pfgen this is server profile definition file.
# qe_input_json_file_path2 : json file path (full path). for pfgen this is client profile definition file.
# qe_output_type : ("server" or "client") for ServiceDefinition,  ("peripheral" or "central") for ProfileDefinition
# qe_output_path : output folder path (full path)

sys.path.append(qe_rble_path + "\\pkg_resources-0.3.0\\pkg_resources\\_vendor")
sys.path.append(qe_rble_path + "\\Jinja2-2.10")
sys.path.append(qe_rble_path + "\\pkg_resources-0.3.0")
sys.path.append(qe_rble_path + "\\MarkupSafe-1.1.0")
sys.path.append(qe_rble_path + "\\json5-0.6.1")
sys.path.append(qe_rble_path + "\\rble-cli\\rble_cli\\svgen")
sys.path.append(qe_rble_path + "\\rble-cli\\rble_cli\\dbgen")
sys.path.append(qe_rble_path + "\\rble-cli\\rble_cli\\pfgen")

import os
os.environ['RBLE_SDK_PATH'] = qe_rble_path

if qe_input_json_type == "GATTDB":
  import dbgen
  dbgen.main([qe_input_json_file_path, "--qe", "--out", qe_output_path])
elif qe_input_json_type == "ProfileDefinition":
  import pfgen
  pfgen.main([qe_output_type, qe_input_json_file_path, qe_input_json_file_path2, "--qe", "--out", qe_output_path])
else:
  import svgen
  svgen.main([qe_output_type, qe_input_json_file_path, "--qe", "--out", qe_output_path])

