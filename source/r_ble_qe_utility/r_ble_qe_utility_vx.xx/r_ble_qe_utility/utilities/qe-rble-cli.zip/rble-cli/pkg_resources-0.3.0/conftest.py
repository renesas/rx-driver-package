collect_ignore = [
	'pkg_resources/_vendor',
]
