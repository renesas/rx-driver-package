.. image:: https://img.shields.io/pypi/v/pkg_resources.svg
   :target: https://pypi.org/project/pkg_resources

.. image:: https://img.shields.io/pypi/pyversions/pkg_resources.svg

.. image:: https://img.shields.io/travis/pypa/pkg_resources/master.svg
   :target: https://travis-ci.org/pypa/pkg_resources

.. .. image:: https://img.shields.io/appveyor/ci/pypa/pkg_resources/master.svg
..    :target: https://ci.appveyor.com/project/pypa/pkg_resources/branch/master

.. .. image:: https://readthedocs.org/projects/pkg_resources/badge/?version=latest
..    :target: https://pkg_resources.readthedocs.io/en/latest/?badge=latest
