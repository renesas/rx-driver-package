Welcome to pkg_resources documentation!
=======================================

.. toctree::
   :maxdepth: 1

   history


.. automodule:: pkg_resources
    :members:
    :undoc-members:
    :show-inheritance:


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

