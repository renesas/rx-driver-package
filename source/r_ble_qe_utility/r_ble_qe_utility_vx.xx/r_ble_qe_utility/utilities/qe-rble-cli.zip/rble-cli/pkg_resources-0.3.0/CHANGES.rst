v0.3.0
======

No longer rely on vendored packages. Still supply them.

v0.2.0
======

Refresh with pkg_resources from Setuptools 38.5.2.

v0.1.0
======

Provisional first release based on pkg_resources as found
Setuptools 23.0.0. Published for experimental purposes
only. Install directly at your own risk.
