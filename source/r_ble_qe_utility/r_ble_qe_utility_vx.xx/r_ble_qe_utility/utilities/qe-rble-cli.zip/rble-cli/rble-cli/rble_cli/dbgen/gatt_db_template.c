/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019-2020 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/**
 *  GATT DATABASE QUICK REFERENCE TABLE:
 *  Abbreviations used for PROPERTIES:
 *      BC = Broadcast
 *      RD = Read
 *      WW = Write Without Response
 *      WR = Write
 *      NT = Notification
 *      IN = Indication
 *      RW = Reliable Write
 * 
 *  HANDLE | ATT_TYPE          | PROPERTIES  | ATT_VALUE                        | DEFINITION
 {%- for attr in comment_table %}
 {%- if 'services' == attr.type %}
 *  ============================================================================================
 *  {{ attr.name }}
 *  ============================================================================================
 *  {{ "0x%04X" | format(attr.attr_hdl) }} | 0x28,0x00         | RD          | {{ attr.uuid }} | {{ attr.name }} Declaration
 {%- endif %}
 {%- if 'included' == attr.type %}
 *  -------+-------------------+-------------+----------------------------------+---------------
 *  {{ "0x%04X" | format(attr.attr_hdl) }} | 0x28,0x02         | RD          | {{ attr.dec }} | {{ attr.name }} Included Declaration
 {%- endif %}
 {%- if 'characteristics' == attr.type %}
 *  -------+-------------------+-------------+----------------------------------+---------------
 *  {{ "0x%04X" | format(attr.attr_hdl) }} | 0x28,0x03         | RD          | {{ attr.dec }} | {{ attr.name }} characteristic Declaration
 *  -------+-------------------+-------------+----------------------------------+---------------
 *  {{ "0x%04X" | format(attr.attr_hdl + 1) }} | {{ attr.uuid }} | {{ attr.prop }} | {{ attr.value }} | {{ attr.name }} characteristic value
 {%- endif %}
 {%- if 'descriptors' == attr.type %}
 *  -------+-------------------+-------------+----------------------------------+---------------
 *  {{ "0x%04X" | format(attr.attr_hdl) }} | {{ attr.uuid }} | {{ attr.prop }} | {{ attr.value }} | {{ attr.name }} descriptor
 {%- endif %}
 {%- endfor %}
 *  ============================================================================================
 
 */

/*******************************************************************************
* Includes   <System Includes> , "Project Includes"
*******************************************************************************/
#include <stdio.h>
#include "gatt_db.h"

/*****************************************************************************
* Global definition
******************************************************************************/
static const uint8_t gs_gatt_const_uuid_arr[] =
{
{%- for uuid in uuid_table %}
    /* {{ uuid.name }} : {{ uuid.offset }} */
    {{ uuid.uuid | join(', ') }},{{"\n"}}
{%- endfor %}
};{{"\n"}}
static uint8_t gs_gatt_value_arr[] =
{
{%- for value in value_table %}
    /* {{ value.name }} */
    {{ value.value | join(', ') }},{{"\n"}}
{%- endfor %}
};{{"\n"}}
{%- if const_table | length == 0 %}
static const uint8_t gs_gatt_const_value_arr[] = { 0x00 };{{"\n"}}
{%- else %}
static const uint8_t gs_gatt_const_value_arr[] =
{
{%- for attr in const_table %}
  {%- if attr.type == 'Characteristic' %}
    /* {{ attr.name }} */
    {{ "0x%02X" | format(attr.properties) }},       // Properties
    {{ attr.start_hdl | join(', ') }}, // Attr Handle
    {{ attr.uuid | join(', ') }}, // UUID{{"\n"}}
  {%- else %}
    /* Included Service : {{ attr.name }} */
    {{ attr.start_hdl | join(', ') }}, // Start Handle
    {{ attr.end_hdl | join(', ') }}, // End Handle
{#- check 16bit UUID service -#}
    {%- if attr.uuid_len == 2 %}
    {{ attr.uuid | join(', ') }}, // UUID
    {%- endif %}{{"\n"}}
  {%- endif %}
{%- endfor %}
};{{"\n"}}
{%- endif %}
{%- if const_peer_table | length == 0 %}
static const uint8_t gs_gatt_db_const_peer_specific_val_arr[] = { 0x00 };{{"\n"}}
{%- else %}
static const uint8_t gs_gatt_db_const_peer_specific_val_arr[] =
{
{%- for attr in const_peer_table %}
    /* {{ attr.name }} */
    {{ attr.value | join(', ') }},{{"\n"}}
{%- endfor %}
};{{"\n"}}
{%- endif %}
{%- if peer_table_size == 0 %}
static uint8_t gs_gatt_db_peer_specific_val_arr[] = { 0x00 };{{"\n"}}
{%- else %}
static uint8_t gs_gatt_db_peer_specific_val_arr[sizeof(gs_gatt_db_const_peer_specific_val_arr)*(BLE_CFG_RF_CONN_MAX+1)];{{"\n"}}
{%- endif %}
static const st_ble_gatts_db_uuid_cfg_t gs_gatt_type_table[] =
{
{%- for attr in type_table %}
    /* {{ loop.index0 }} : {{ attr.name }} */
    {
        /* UUID Offset */
        {{ attr.uuid_offset }},
        /* First Occurrence for Type */
        {{ "0x%04X" | format(attr.first_type) }},
        /* Last Occurrence for Type */
        {{ "0x%04X" | format(attr.last_type) }},
    },{{"\n"}}
{%- endfor %}
};{{"\n"}}
static const st_ble_gatts_db_attr_cfg_t gs_gatt_db_attr_table[] =
{
{%- for attr in attr_table %}
    /* Handle : {{ "0x%04X" | format(loop.index0) }} */
    /* {{ attr.name }} */
    {
        /* Properties */
        {{ attr.properties | join(' | ') }},
        /* Auxiliary Properties */
        {{ attr.aux_properties | join(' | ') }},
        /* Value Size */
        {{ attr.db_size }},
        /* Next Attribute Type Index */
        {{ "0x%04X" | format(attr.next_hdl) }},
        /* UUID Offset */
        {{ attr.uuid_offset }},
        /* Value */
        {{ attr.value }},
    },{{"\n"}}
{%- endfor %}
};{{"\n"}}
static const st_ble_gatts_db_char_cfg_t gs_gatt_characteristic[] =
{
{%- for char in char_table %}
    /* {{ loop.index0 }} : {{ char.name }} */
    {
        /* Number of Attributes */
        {
            {{ char.num_of_attrs }},
        },
        /* Start Handle */
        {{ "0x%04X" | format(char.start_hdl) }},
        /* Service Index */
        {{ char.serv_idx }},
    },{{"\n"}}
{%- endfor %}
};{{"\n"}}
static const st_ble_gatts_db_serv_cfg_t gs_gatt_service[] =
{
{%- for serv in serv_table %}
    /* {{ serv.name }} */
    {
        /* Num of Services */
        {
            1,
        },
        /* Description */
        {{ serv.security | join(' | ' ) }},
        /* Service Start Handle */
        {{ "0x%04X" | format(serv.start_hdl) }},
        /* Service End Handle */
        {{ "0x%04X" | format(serv.end_hdl) }},
        /* Characteristic Start Index */
        {{ serv.char_start_idx }},
        /* Characteristic End Index */
        {{ serv.char_end_idx }},
    },{{"\n"}}
{%- endfor %}
};{{"\n"}}
st_ble_gatts_db_cfg_t g_gatt_db_table =
{
    gs_gatt_const_uuid_arr,
    gs_gatt_value_arr,
    gs_gatt_const_value_arr,
    gs_gatt_db_peer_specific_val_arr,
    gs_gatt_db_const_peer_specific_val_arr,
    gs_gatt_type_table,
    gs_gatt_db_attr_table,
    gs_gatt_characteristic,
    gs_gatt_service,
    ARRAY_SIZE(gs_gatt_service),
    ARRAY_SIZE(gs_gatt_characteristic),
    ARRAY_SIZE(gs_gatt_type_table),
    ARRAY_SIZE(gs_gatt_db_const_peer_specific_val_arr),
};
