import setuptools

with open("README.md", "r") as f:
    long_description = f.read()

setuptools.setup(
    name="rble-cli",
    version="0.5.0",
    author="Renesas Electronics Corporation",
    author_email="",
    description="Renesas Bluetooth Low Energy command line tools",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="",
    packages=setuptools.find_packages(),
    entry_points={
        'rble_cli.registered_commands': [
            'pfgen=rble_cli.pfgen.pfgen:main',
            'svgen=rble_cli.svgen.svgen:main',
            'dbgen=rble_cli.dbgen.dbgen:main',
        ],
        'console_scripts': [
            'rble-cli=rble_cli.__main__:main'
        ],
    },
    install_requires=[
        'jinja2>=2.10',
    ],
    package_data = {
        '':['*.c','*.h', '*.json']
    }
)