import sys
from rble_cli.cli import dispatch

def main():
    return dispatch(sys.argv[1:])

if __name__ == '__main__':
    sys.exit(main())
