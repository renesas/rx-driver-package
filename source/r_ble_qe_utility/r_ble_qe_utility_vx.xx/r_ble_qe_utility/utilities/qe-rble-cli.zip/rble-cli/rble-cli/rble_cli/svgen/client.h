{%- macro print_struct(attr) -%}
  {%- for f in attr.fields recursive %}
    {%- if f.fields | length > 0 %}
      {{ loop(f.fields) }}
/***************************************************************************//**
 * @brief {{ attr.full_name }} {{ f.name }} value structure.
*******************************************************************************/
typedef struct {
      {%- for ff in f.fields %}
    {{ ff.type_def() }}; /**< {{ ff.description }} */
      {%- endfor %}
} {{ f.type_name() }};{{"\n"}}
    {%- endif %}
  {%- endfor %}
/***************************************************************************//**
 * @brief {{ attr.full_name }} value structure.
*******************************************************************************/
typedef struct {
  {%- for f in attr.fields %}
    {{ f.type_def() }}; /**< {{ f.description }} */
  {%- endfor %}
} {{ attr.type_name() }};{{"\n"}}
{%- endmacro -%}
{%- macro print_enum(attr) -%}
  {%- for f in attr.fields recursive %}
    {%- if f.fields %}
      {{ loop(f.fields) }}
    {%- endif %}
    {%- if f.enumerations %}
/***************************************************************************//**
 * @brief {{ attr.full_name }} {{ f.name }} enumeration.
*******************************************************************************/
typedef enum {
      {%- for e in f.enumerations %}
    {{ e.enum_def() }} = {{ e.key }}, /**< {{ e.description }} */
      {%- endfor %}
} {{ f.enum_name() }};{{"\n"}}
    {%- endif %}
  {%- endfor %}
{%- endmacro -%}
/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_{{ s.name }}.h
 * Version : 1.0
 * Description : The header file for {{ s.full_name }} client.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 31.12.2999 1.00 First Release
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @file
 * @defgroup {{ s.name }} {{ s.full_name }} Client
 * @{
 * @ingroup profile
 * @brief   This is the client for the {{ s.full_name }} Service.
 **********************************************************************************************************************/
#include "r_ble_rx23w_if.h"

#include "profile_cmn/r_ble_profile_cmn.h"
#include "profile_cmn/r_ble_servc_if.h"

#ifndef R_BLE_{{ s.name.upper() }}_H
#define R_BLE_{{ s.name.upper() }}_H{{"\n"}}

{%- for c in s.characteristics %}
/*----------------------------------------------------------------------------------------------------------------------
    {{ c.full_name }} Characteristic
----------------------------------------------------------------------------------------------------------------------*/
  {%- if c.uuid is not number %}
extern const uint8_t {{ c.macro_name('uuid') }}[BLE_GATT_128_BIT_UUID_SIZE];
  {%- else %}
#define {{ c.macro_name('uuid') }} ({{ "0x%04X" | format(c.uuid) }})
  {%- endif %}
#define {{ c.macro_name('len') }} ({{ c.db_size }})
    {%- for d in c.descriptors %}
#define {{ d.macro_name('uuid') }} ({{ "0x%04X" | format(d.uuid) }})
#define {{ d.macro_name('len') }} ({{ d.db_size }})
    {%- endfor %}
  {%- for d in c.descriptors %}
{{ print_enum(d) }}{%- if not d.is_default_type() %}{{ print_struct(d) }}{%- endif %}
  {%- endfor -%}
{{ print_enum(c) }}{%- if not c.is_default_type() %}{{ print_struct(c) }}{%- endif %}
/***************************************************************************//**
 * @brief {{ c.full_name }} attribute handle value.
*******************************************************************************/
typedef struct {
    st_ble_gatt_hdl_range_t range;
    {%- for d in c.descriptors %}
    uint16_t {{ snake(d.name) }}_desc_hdl;
    {%- endfor %}
} st_ble_{{ s.name }}_{{ snake(c.name) }}_attr_hdl_t;{{"\n"}}
    {%- for d in c.descriptors %}
        {%- if 'Read' in d.properties %}
/***************************************************************************//**
 * @brief     Read {{ c.full_name }} characteristic {{ d.full_name }} descriptor value from the remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t {{ d.api_name('read') }}(uint16_t conn_hdl);{{"\n"}}
        {%- endif %}
        {%- if 'Write' in d.properties %}
/***************************************************************************//**
 * @brief     Write {{ c.full_name }} characteristic {{ d.full_name }} descriptor value to remote GATT database.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value {{ c.full_name }} characteristic {{ d.full_name }} descriptor value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t {{ d.api_name('write') }}(uint16_t conn_hdl, const {{ d.type_name() }} *p_value);{{"\n"}}
        {%- endif %}
    {%- endfor %}

    {%- if 'Read' in c.properties %}
/***************************************************************************//**
 * @brief     Read {{ c.full_name }} characteristic value from the remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_{{ s.name.upper() }}_Read{{ pascal(c.name) }}(uint16_t conn_hdl);{{"\n"}}
    {%- endif %}
    {%- if 'Write' in c.properties %}
/***************************************************************************//**
 * @brief     Write {{ c.full_name }} characteristic value to remote GATT database.
 * @param[in] conn_hdl  Connection handle.
 * @param[in] p_value {{ c.full_name }} characteristic value to write.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_{{ s.name.upper() }}_Write{{ pascal(c.name) }}(uint16_t conn_hdl, const {{ c.type_name() }} *p_value);{{"\n"}};
    {%- endif %}
/***************************************************************************//**
 * @brief      Get {{ c.full_name }} attribute handles.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
 * @return    @ref ble_status_t
*******************************************************************************/
void {{ c.api_name('get') }}AttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_{{ s.name }}_{{ snake(c.name) }}_attr_hdl_t *p_hdl);{{"\n"}}
{%- endfor %}

/*----------------------------------------------------------------------------------------------------------------------
    {{ s.full_name }} Client
----------------------------------------------------------------------------------------------------------------------*/{{"\n"}}
{%- for err_code in s.error_codes %}
/***************************************************************************//**
 * @brief {{ err_code.description }}
*******************************************************************************/
#define {{ err_code.err_code_def() }} (BLE_ERR_GROUP_GATT | {{ err_code.code }}){{"\n"}}
{%- endfor %}
/***************************************************************************//**
 * @brief {{ s.full_name }} client event data.
*******************************************************************************/
typedef struct {
    uint16_t    conn_hdl;  /**< Connection handle */
    uint16_t    param_len; /**< Event parameter length */
    const void *p_param;   /**< Event parameter */
} st_ble_{{ s.name.lower() }}_evt_data_t;

/***************************************************************************//**
 * @brief {{ s.full_name }} characteristic ID.
*******************************************************************************/
typedef enum {
{%- for c in s.characteristics %}
    {{ c.macro_name('IDX') }},
    {%- for d in c.descriptors %}
    {{ d.macro_name('IDX') }},
    {%- endfor %}
{%- endfor %}
} e_ble_{{ s.name.lower() }}_char_idx_t;

/***************************************************************************//**
 * @brief {{ s.full_name }} client event type.
*******************************************************************************/
typedef enum {
{%- for c in s.characteristics %}
    /* {{ c.full_name }} */
    {%- if 'Read' in c.properties %}
    {{ c.evt_name('read_rsp') }} = BLE_SERVC_ATTR_EVENT({{ c.macro_name('IDX') }}, BLE_SERVC_READ_RSP),
    {%- endif %}
    {%- if 'Write' in c.properties %}
    {{ c.evt_name('write_rsp') }} = BLE_SERVC_ATTR_EVENT({{ c.macro_name('IDX') }}, BLE_SERVC_WRITE_RSP),
    {%- endif %}
    {%- if 'Notify' in c.properties %}
    {{ c.evt_name('hdl_val_ntf') }} = BLE_SERVC_ATTR_EVENT({{ c.macro_name('IDX') }}, BLE_SERVC_HDL_VAL_NTF),
    {%- endif %}
    {%- if 'Indicate' in c.properties %}
    {{ c.evt_name('hdl_val_ind') }} = BLE_SERVC_ATTR_EVENT({{ c.macro_name('IDX') }}, BLE_SERVC_HDL_VAL_IND),
    {%- endif %}
    {%- for d in c.descriptors %}
        {%- if 'Read' in d.properties %}
    {{ d.evt_name('read_rsp') }} = BLE_SERVC_ATTR_EVENT({{ d.macro_name('IDX') }}, BLE_SERVC_READ_RSP),
        {%- endif %}
        {%- if 'Write' in d.properties %}
    {{ d.evt_name('write_rsp') }} = BLE_SERVC_ATTR_EVENT({{ d.macro_name('IDX') }}, BLE_SERVC_WRITE_RSP),
        {%- endif %}
    {%- endfor %}
{%- endfor %}
} e_ble_{{ s.name.lower() }}_event_t;

/***************************************************************************//**
 * @brief     Initialize {{ s.full_name }} client.
 * @param[in] cb Client callback.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_{{ s.name.upper() }}_Init(ble_servc_app_cb_t cb);

/***************************************************************************//**
 * @brief     {{ s.full_name }} client discovery callback.
 * @param[in] conn_hdl Connection handle
 * @param[in] serv_idx Service instance index.
 * @param[in] type     Service discovery event type.
 * @param[out] p_param  Service discovery event parameter.
 * @return    @ref ble_status_t
*******************************************************************************/
void R_BLE_{{ s.name.upper() }}_ServDiscCb(uint16_t conn_hdl, uint8_t serv_idx, uint16_t type, void *p_param);

/***************************************************************************//**
 * @brief     Get {{ s.full_name }} client attribute handle.
 * @param[in]  p_addr Bluetooth device address for the attribute handles.
 * @param[out] p_hdl  The pointer to store the retrieved attribute handles.
*******************************************************************************/
void R_BLE_{{ s.name.upper() }}_GetServAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_gatt_hdl_range_t *p_hdl);

#endif /* R_BLE_{{ s.name.upper() }}_H */

/** @} */{{"\n"}}
