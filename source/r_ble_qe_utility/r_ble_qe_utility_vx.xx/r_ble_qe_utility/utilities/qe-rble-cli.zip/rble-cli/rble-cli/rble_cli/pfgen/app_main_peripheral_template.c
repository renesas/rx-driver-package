/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019-2020 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/******************************************************************************
* File Name    : app_main.c
* Device(s)    : RX23W
* Tool-Chain   : e2Studio, Renesas RX v2.08
* Description  : This is a application file for peripheral role.
*******************************************************************************/

/******************************************************************************
 Includes   <System Includes> , "Project Includes"
*******************************************************************************/
#include <string.h>
#include "r_ble_rx23w_if.h"
#include "abs/r_ble_abs_api.h"
#include "timer/r_ble_timer.h"
{%- if cjson %}
#include "discovery/r_ble_disc.h"
{%- endif %}
#include "gatt_db.h"
#include "profile_cmn/r_ble_servs_if.h"
#include "profile_cmn/r_ble_servc_if.h"
{%- for s in cjson %}
#include "r_ble_{{ s.abbreviation }}c.h"
{%- endfor %}
{%- for s in sjson %}
#include "r_ble_{{ s.abbreviation }}s.h"
{%- endfor %}

#if (BSP_CFG_RTOS_USED == 1)
#include "rtos/r_ble_rtos.h"
#include "FreeRTOS.h"
#include "task.h"
#include "../frtos_skeleton/task_function.h"
#endif

#define BLE_LOG_TAG "app_main"
#include "logger/r_ble_logger.h"

/******************************************************************************
 User file includes
*******************************************************************************/
${}
<#usercode("file includes")/>

/******************************************************************************
 User macro definitions
*******************************************************************************/
/* Queue for Prepare Write Operation. Change if needed. */
#define BLE_GATTS_QUEUE_ELEMENTS_SIZE       (14)
#define BLE_GATTS_QUEUE_BUFFER_LEN          (245)
#define BLE_GATTS_QUEUE_NUM                 (1)

${}
<#usercode("macro definitions")/>

/******************************************************************************
 Generated function prototype declarations
*******************************************************************************/
/* Internal functions */
static void gap_cb(uint16_t type, ble_status_t result, st_ble_evt_data_t *p_data);
static void gatts_cb(uint16_t type, ble_status_t result, st_ble_gatts_evt_data_t *p_data);
static void gattc_cb(uint16_t type, ble_status_t result, st_ble_gattc_evt_data_t *p_data);
static void vs_cb(uint16_t type, ble_status_t result, st_ble_vs_evt_data_t *p_data);
{%- if cjson %}
static void disc_comp_cb(uint16_t conn_hdl);
{%- endif %}
{%- for s in sjson %}
{%- if s.abbreviation in old_serv_s_list %}
static void {{s.abbreviation}}s_cb(uint16_t type, ble_status_t result, st_ble_{{s.abbreviation}}s_evt_data_t *p_data);
{%- endif %}
{%- endfor %}
{%- for s in cjson %}
{%- if s.abbreviation in old_serv_c_list %}
{%- if s.abbreviation == "hid" %}
static void {{s.abbreviation}}c_cb(uint16_t type, ble_status_t result, uint8_t idx , void *p_data);
{%- else %}
static void {{s.abbreviation}}c_cb(uint16_t type, ble_status_t result, st_ble_{{s.abbreviation}}c_evt_data_t *p_data);
{%- endif %}{%- endif %}{%- endfor %}
static ble_status_t ble_init(void);
void app_main(void);

/******************************************************************************
 User function prototype declarations
*******************************************************************************/
${}
<#usercode("function prototype declarations")/>

/******************************************************************************
 Generated global variables
*******************************************************************************/
{%- for s in cjson %}
/* {{ s.name }} UUID */
static uint8_t {{ s.abbreviation.upper() }}C_UUID[] = { {{ s.uuid | join(', ') }} };
{%- endfor %}

{%- if cjson %}
/* Service discovery parameters */
static st_ble_disc_entry_t gs_disc_entries[] =
{
{%- for s in cjson %}
    {
        .p_uuid     = {{ s.abbreviation.upper() }}C_UUID,
        .uuid_type  = BLE_GATT_{{ uuid_length(s.uuid) }}_BIT_UUID_FORMAT,
        .serv_cb    = R_BLE_{{ s.abbreviation.upper() }}C_ServDiscCb,
    },
{%- endfor %}
};
{%- endif %}

{%- if absjson.advertise[0].adv_data %}
/* Advertising Data */
static uint8_t gs_adv_data[] =
{   
{%- for data in absjson.advertise[0].adv_data %}
    /* {{ data.name }} */
    {{ "0x%02X" | format(data.size) }}, /**< Data Size */
    {{ data.type }}, /**< Data Type */
{%- if data.name == "Flags" %}
    ( {{ ' | '.join(data.value) }} ), /**< Data Value */
{%- else %}
    {{ abs_value(data.size - 1, data.value) }}, /**< Data Value */
{%- endif %}
{% endfor %}};
{%- endif %}
{%- if absjson.advertise[0].sres_data %}

/* Scan Response Data */
static uint8_t gs_sres_data[] =
{   
{%- for data in absjson.advertise[0].sres_data %}
    /* {{ data.name }} */
    {{ "0x%02X" | format(data.size) }}, /**< Data Size */
    {{ data.type }}, /**< Data Type */
    {{ abs_value(data.size - 1, data.value) }}, /**< Data Value */
{% endfor %}};
{%- endif %}

/* Advertising parameters */
static st_ble_abs_legacy_adv_param_t gs_adv_param =
{
{%- if 0 != absjson.advertise[0].fast_period %}
    .fast_adv_intv      = {{ "0x%08X" | format(absjson.advertise[0].fast_adv_intv) }}, ///< Fast advertising interval. {{ "{:,}".format(absjson.advertise[0].fast_adv_intv * 0.625) }}(ms)
    .fast_period        = {{ "0x%04X" | format(absjson.advertise[0].fast_period) }},     ///< Fast advertising period. {{ "{:,}".format(absjson.advertise[0].fast_period * 10) }}(ms)
{%- endif %}
    .slow_adv_intv      = {{ "0x%08X" | format(absjson.advertise[0].slow_adv_intv) }}, ///< Slow advertising interval. {{ "{:,}".format(absjson.advertise[0].slow_adv_intv * 0.625) }}(ms)
    .slow_period        = {{ "0x%04X" | format(absjson.advertise[0].slow_period) }},      ///< Slow advertising period. {{ "{:,}".format(absjson.advertise[0].slow_period * 10) }}(ms)
{%- if absjson.advertise[0].adv_data %}
    .p_adv_data         = gs_adv_data,             ///< Advertising data. If p_advertising_data is specified as NULL, advertising data is not set.
    .adv_data_length    = ARRAY_SIZE(gs_adv_data), ///< Advertising data length (in bytes).
{%- endif %}
{%- if absjson.advertise[0].sres_data %}
    .p_sres_data        = gs_sres_data,             ///< Scan response data. If p_scan_response_data is specified as NULL, scan response data is not set.
    .sres_data_length   = ARRAY_SIZE(gs_sres_data), ///< Scan response data length (in bytes).
{%- endif %}
    .filter             = BLE_ABS_ADV_ALLOW_CONN_ANY, ///< Advertising Filter Policy.
    .adv_ch_map         = ( {{ ' | '.join(absjson.advertise[0].adv_ch_map) }} ), ///< Channel Map.
#if (BLE_VERSION_MAJOR > 1) || ((BLE_VERSION_MAJOR == 1) && (BLE_VERSION_MINOR >= 10))
    .o_addr_type        = {{ absjson.advertise[0].o_addr_type }}, ///< Own Bluetooth address type.
    .o_addr             = { 0 },
#else
    .o_addr_type        = BLE_GAP_ADDR_PUBLIC,
#endif
};

/* GATT server callback parameters */
static st_ble_abs_gatts_cb_param_t gs_abs_gatts_cb_param[] =
{
    {
        .cb         = gatts_cb,
        .priority   = 1,
    },
    {
        .cb         = NULL,
    }
};

/* GATT server initialization parameters */
static st_ble_abs_gatts_init_param_t gs_abs_gatts_init_param =
{
    .p_cb_param = gs_abs_gatts_cb_param,
    .cb_num     = BLE_GATTS_MAX_CB,
};

/* GATT client callback parameters */
static st_ble_abs_gattc_cb_param_t gs_abs_gattc_cb_param[] =
{
    {
        .cb         = gattc_cb,
        .priority   = 1,
    },
    {
        .cb         = NULL,
    }
};

/* GATT client initialization parameters */
static st_ble_abs_gattc_init_param_t gs_abs_gattc_init_param =
{
    .p_cb_param = gs_abs_gattc_cb_param,
    .cb_num     = BLE_GATTC_MAX_CB,
};

/* Pairing parameters */
static st_ble_abs_pairing_param_t gs_abs_pairing_param =
{
    .iocap          = BLE_GAP_IOCAP_NOINPUT_NOOUTPUT,
    .mitm           = BLE_GAP_SEC_MITM_BEST_EFFORT,
    .sec_conn_only  = BLE_GAP_SC_BEST_EFFORT,
    .loc_key_dist   = BLE_GAP_KEY_DIST_ENCKEY,
    .rem_key_dist   = 0,
    .max_key_size   = 16,
};

/* Host stack initialization parameters */
static st_ble_abs_init_param_t gs_abs_init_param =
{
    .gap_cb          = gap_cb,
    .p_gatts_cbs     = &gs_abs_gatts_init_param,
    .p_gattc_cbs     = &gs_abs_gattc_init_param,
    .vs_cb           = vs_cb,
    .p_pairing_param = &gs_abs_pairing_param,
};

/* GATT server Prepare Write Queue parameters */
static st_ble_gatt_queue_elm_t  gs_queue_elms[BLE_GATTS_QUEUE_ELEMENTS_SIZE];
static uint8_t gs_buffer[BLE_GATTS_QUEUE_BUFFER_LEN];
static st_ble_gatt_pre_queue_t gs_queue[BLE_GATTS_QUEUE_NUM] = {
    {
        .p_buf_start = gs_buffer,
        .buffer_len  = BLE_GATTS_QUEUE_BUFFER_LEN,
        .p_queue     = gs_queue_elms,
        .queue_size  = BLE_GATTS_QUEUE_ELEMENTS_SIZE,
    }
};

/* Connection handle */
uint16_t g_conn_hdl;
{%- for s in sjson %}
{%- if s.abbreviation in old_serv_s_list %}

/* {{ s.name }} initialize parameter */
static st_ble_{{s.abbreviation}}s_init_param_t gs_{{s.abbreviation}}s_init_param = 
{
    .cb = {{s.abbreviation}}s_cb,
};
{%- if s.abbreviation == "ht" %}
{%- else %}
/* {{ s.name }} connect parameter */
static st_ble_{{s.abbreviation}}s_connect_param_t    gs_{{s.abbreviation}}s_conn_param;
/* {{ s.name }} disconnect parameter */
static st_ble_{{s.abbreviation}}s_disconnect_param_t gs_{{s.abbreviation}}s_disconn_param;
{%- endif %}
{%- endif %}
{%- endfor %}
{%- for s in cjson %}
{%- if s.abbreviation in old_serv_c_list %}

/* {{ s.name }} initialize parameter */
static st_ble_{{s.abbreviation}}c_init_param_t gs_{{s.abbreviation}}c_init_param = 
{
    .cb = {{s.abbreviation}}c_cb,
};
/* {{ s.name }} connect parameter */
static st_ble_{{s.abbreviation}}c_connect_param_t    gs_{{s.abbreviation}}c_conn_param;
/* {{ s.name }} disconnect parameter */
static st_ble_{{s.abbreviation}}c_disconnect_param_t gs_{{s.abbreviation}}c_disconn_param;
{%- endif %}
{%- endfor %}

/******************************************************************************
 User global variables
*******************************************************************************/
${}
<#usercode("global variables")/>

/******************************************************************************
 Generated function definitions
*******************************************************************************/
/******************************************************************************
 * Function Name: gap_cb
 * Description  : Callback function for GAP API.
 * Arguments    : uint16_t type -
 *                  Event type of GAP API.
 *              : ble_status_t result -
 *                  Event result of GAP API.
 *              : st_ble_vs_evt_data_t *p_data - 
 *                  Event parameters of GAP API.
 * Return Value : none
 ******************************************************************************/
static void gap_cb(uint16_t type, ble_status_t result, st_ble_evt_data_t *p_data)
{
/* Hint: Input common process of callback function such as variable definitions */
${}
<#usercode("GAP callback function common process")/>

    switch(type)
    {
        case BLE_GAP_EVENT_STACK_ON:
        {
{%- if "BLE_GAP_ADDR_RAND" == absjson.advertise[0].o_addr_type %}
#if (BLE_VERSION_MAJOR > 1) || ((BLE_VERSION_MAJOR == 1) && (BLE_VERSION_MINOR >= 10))
            /* Get BD address for Advertising */
            R_BLE_VS_GetBdAddr(BLE_VS_ADDR_AREA_REG, BLE_GAP_ADDR_RAND);
#else
            /* Start Advertising when BLE protocol stack is ready */
            R_BLE_ABS_StartLegacyAdv(&gs_adv_param);
#endif
{%- else %}
            /* Start Advertising when BLE protocol stack is ready */
            R_BLE_ABS_StartLegacyAdv(&gs_adv_param);
{%- endif %}
        } break;

        case BLE_GAP_EVENT_CONN_IND:
        {
            if (BLE_SUCCESS == result)
            {
                /* Store connection handle */
                st_ble_gap_conn_evt_t *p_gap_conn_evt_param = (st_ble_gap_conn_evt_t *)p_data->p_param;
                g_conn_hdl = p_gap_conn_evt_param->conn_hdl;
{%- for s in sjson %}
{%- if s.abbreviation in old_serv_s_list %}
                {%- if s.abbreviation == "hid" %}
                R_BLE_{{s.abbreviation.upper()}}S_Connect(g_conn_hdl, 0, &gs_{{s.abbreviation}}s_conn_param);
                {%- elif s.abbreviation == "ht" %}

                {%- else %}
                R_BLE_{{s.abbreviation.upper()}}S_Connect(g_conn_hdl, &gs_{{s.abbreviation}}s_conn_param);
                {%- endif %}
{%- endif %}
{%- endfor %}
{%- for s in cjson %}
{%- if s.abbreviation in old_serv_c_list %}
                {%- if s.abbreviation == "hid" %}
                R_BLE_{{s.abbreviation.upper()}}C_Connect(g_conn_hdl, 0, &gs_{{s.abbreviation}}c_conn_param);
                {%- else %}
                R_BLE_{{s.abbreviation.upper()}}C_Connect(g_conn_hdl, &gs_{{s.abbreviation}}c_conn_param);
                {%- endif %}
{%- endif %}
{%- endfor %}
            }
            else
            {
                /* Restart advertising when connection failed */
                R_BLE_ABS_StartLegacyAdv(&gs_adv_param);
            }
        } break;

        case BLE_GAP_EVENT_DISCONN_IND:
        {
            /* Restart advertising when disconnected */
{%- for s in sjson %}
{%- if s.abbreviation in old_serv_s_list %}
            {%- if s.abbreviation == "hid" %}
            R_BLE_{{s.abbreviation.upper()}}S_Disconnect(g_conn_hdl, 0, &gs_{{s.abbreviation}}s_disconn_param);
            {%- elif s.abbreviation == "ht" %}
            {%- else %}
            R_BLE_{{s.abbreviation.upper()}}S_Disconnect(g_conn_hdl, &gs_{{s.abbreviation}}s_disconn_param);
            {%- endif %}
{%- endif %}
{%- endfor %}
{%- for s in cjson %}
{%- if s.abbreviation in old_serv_c_list %}
            {%- if s.abbreviation == "hid" %}
            R_BLE_{{s.abbreviation.upper()}}C_Disconnect(g_conn_hdl, 0, &gs_{{s.abbreviation}}c_disconn_param);
            {%- else %}
            R_BLE_{{s.abbreviation.upper()}}C_Disconnect(g_conn_hdl, &gs_{{s.abbreviation}}c_disconn_param);
            {%- endif %}
{%- endif %}
{%- endfor %}
            g_conn_hdl = BLE_GAP_INVALID_CONN_HDL;
            R_BLE_ABS_StartLegacyAdv(&gs_adv_param);
        } break;

        case BLE_GAP_EVENT_CONN_PARAM_UPD_REQ:
        {
            /* Send connection update response with value received on connection update request */
            st_ble_gap_conn_upd_req_evt_t *p_conn_upd_req_evt_param = (st_ble_gap_conn_upd_req_evt_t *)p_data->p_param;

            st_ble_gap_conn_param_t conn_updt_param = {
                .conn_intv_min = p_conn_upd_req_evt_param->conn_intv_min,
                .conn_intv_max = p_conn_upd_req_evt_param->conn_intv_max,
                .conn_latency  = p_conn_upd_req_evt_param->conn_latency,
                .sup_to        = p_conn_upd_req_evt_param->sup_to,
                .min_ce_length = 0xFFFF,
                .max_ce_length = 0xFFFF,
            };

            R_BLE_GAP_UpdConn(p_conn_upd_req_evt_param->conn_hdl,
                              BLE_GAP_CONN_UPD_MODE_RSP,
                              BLE_GAP_CONN_UPD_ACCEPT,
                              &conn_updt_param);
        } break;

/* Hint: Add cases of GAP event macros defined as BLE_GAP_XXX */
${}
<#usercode("GAP callback function event process")/>
    }

${}
<#usercode("GAP callback function closing process")/>
}

/******************************************************************************
 * Function Name: gatts_cb
 * Description  : Callback function for GATT Server API.
 * Arguments    : uint16_t type -
 *                  Event type of GATT Server API.
 *              : ble_status_t result -
 *                  Event result of GATT Server API.
 *              : st_ble_gatts_evt_data_t *p_data - 
 *                  Event parameters of GATT Server API.
 * Return Value : none
 ******************************************************************************/
static void gatts_cb(uint16_t type, ble_status_t result, st_ble_gatts_evt_data_t *p_data)
{
/* Hint: Input common process of callback function such as variable definitions */
${}
<#usercode("GATT Server callback function common process")/>

    R_BLE_SERVS_GattsCb(type, result, p_data);
    switch(type)
    {
/* Hint: Add cases of GATT Server event macros defined as BLE_GATTS_XXX */
${}
<#usercode("GATT Server callback function event process")/>
    }

${}
<#usercode("GATT Server callback function closing process")/>
}

/******************************************************************************
 * Function Name: gattc_cb
 * Description  : Callback function for GATT Client API.
 * Arguments    : uint16_t type -
 *                  Event type of GATT Client API.
 *              : ble_status_t result -
 *                  Event result of GATT Client API.
 *              : st_ble_gattc_evt_data_t *p_data - 
 *                  Event parameters of GATT Client API.
 * Return Value : none
 ******************************************************************************/
static void gattc_cb(uint16_t type, ble_status_t result, st_ble_gattc_evt_data_t *p_data)
{
/* Hint: Input common process of callback function such as variable definitions */
${}
<#usercode("GATT Client callback function common process")/>

    R_BLE_SERVC_GattcCb(type, result, p_data);
    switch(type)
    {
{%- if cjson %}
        case BLE_GATTC_EVENT_CONN_IND:
        {
            /* Start discovery operation after connection established */
            R_BLE_DISC_Start(p_data->conn_hdl, gs_disc_entries, ARRAY_SIZE(gs_disc_entries), disc_comp_cb);
        } break;
{%- endif %}

/* Hint: Add cases of GATT Client event macros defined as BLE_GATTC_XXX */
${}
<#usercode("GATT Client callback function event process")/>
    }

${}
<#usercode("GATT Client callback function closing process")/>
}

/******************************************************************************
 * Function Name: vs_cb
 * Description  : Callback function for Vendor Specific API.
 * Arguments    : uint16_t type -
 *                  Event type of Vendor Specific API.
 *              : ble_status_t result -
 *                  Event result of Vendor Specific API.
 *              : st_ble_vs_evt_data_t *p_data - 
 *                  Event parameters of Vendor Specific API.
 * Return Value : none
 ******************************************************************************/
static void vs_cb(uint16_t type, ble_status_t result, st_ble_vs_evt_data_t *p_data)
{
/* Hint: Input common process of callback function such as variable definitions */
${}
<#usercode("vender specific callback function common process")/>

    R_BLE_SERVS_VsCb(type, result, p_data);
    switch(type)
    {
{%- if "BLE_GAP_ADDR_RAND" == absjson.advertise[0].o_addr_type %}
#if (BLE_VERSION_MAJOR > 1) || ((BLE_VERSION_MAJOR == 1) && (BLE_VERSION_MINOR >= 10))
        case BLE_VS_EVENT_GET_ADDR_COMP:
        {
            /* Start advertising when BD address is ready */
            st_ble_vs_get_bd_addr_comp_evt_t * p_get_addr = (st_ble_vs_get_bd_addr_comp_evt_t *)p_data->p_param;
            memcpy(gs_adv_param.o_addr, p_get_addr->addr.addr, BLE_BD_ADDR_LEN);
            R_BLE_ABS_StartLegacyAdv(&gs_adv_param);
        } break;
#endif
{%- endif %}

/* Hint: Add cases of vender specific event macros defined as BLE_VS_XXX */
${}
<#usercode("vender specific callback function event process")/>
    }

${}
<#usercode("vender specific callback function closing process")/>
}
{%- for s in sjson %}
{% if s.abbreviation in old_serv_s_list %}
/******************************************************************************
 * Function Name: {{ s.abbreviation }}s_cb
 * Description  : Callback function for {{ s.name }} server feature.
 * Arguments    : uint16_t type -
 *                  Event type of {{ s.name }} server feature.
 *              : ble_status_t result -
 *                  Event result of {{ s.name }} server feature.
 *              : st_ble_{{s.abbreviation}}s_evt_data_t *p_data - 
 *                  Event parameters of {{ s.name }} server feature.
 * Return Value : none
 ******************************************************************************/
static void {{ s.abbreviation }}s_cb(uint16_t type, ble_status_t result, st_ble_{{s.abbreviation}}s_evt_data_t *p_data)
{
/* Hint: Input common process of callback function such as variable definitions */
${}
<#usercode("{{ s.name }} Server callback function common process")/>

    switch(type)
    {
/* Hint: Add cases of {{s.name}} server events defined in e_ble_{{s.abbreviation}}s_event_t */
${}
<#usercode("{{ s.name }} Server callback function event process")/>
    }

${}
<#usercode("{{ s.name }} Server callback function closing process")/>
}
{%- else %}
/******************************************************************************
 * Function Name: {{ s.abbreviation }}s_cb
 * Description  : Callback function for {{ s.name }} server feature.
 * Arguments    : uint16_t type -
 *                  Event type of {{ s.name }} server feature.
 *              : ble_status_t result -
 *                  Event result of {{ s.name }} server feature.
 *              : st_ble_servs_evt_data_t *p_data - 
 *                  Event parameters of {{ s.name }} server feature.
 * Return Value : none
 ******************************************************************************/
static void {{ s.abbreviation }}s_cb(uint16_t type, ble_status_t result, st_ble_servs_evt_data_t *p_data)
{
/* Hint: Input common process of callback function such as variable definitions */
${}
<#usercode("{{ s.name }} Server callback function common process")/>

    switch(type)
    {
/* Hint: Add cases of {{s.name}} server events defined in e_ble_{{s.abbreviation}}s_event_t */
${}
<#usercode("{{ s.name }} Server callback function event process")/>
    }

${}
<#usercode("{{ s.name }} Server callback function closing process")/>
}
{%- endif %}
{%- endfor %}
{%- for s in cjson %}
{% if s.abbreviation in old_serv_c_list %}
{%- if s.abbreviation == "hid" %}
/******************************************************************************
 * Function Name: {{ s.abbreviation }}c_cb
 * Description  : Callback function for {{ s.name }} client feature.
 * Arguments    : uint16_t type -
 *                  Event type of {{ s.name }} client feature.
 *              : ble_status_t result -
 *                  Event result of {{ s.name }} client feature.
 *              : uint8_t idx -
 *                  Index number hid service.
 *              : void *p_data - 
 *                  Event parameters of {{ s.name }} client feature.
 * Return Value : none
 ******************************************************************************/
static void {{ s.abbreviation }}c_cb(uint16_t type, ble_status_t result, uint8_t idx, void *p_data)
{
/* Hint: Input common process of callback function such as variable definitions */
${}
<#usercode("{{ s.name }} Client callback function common process")/>

    switch(type)
    {
/* Hint: Add cases of {{s.name}} client events defined in e_ble_{{s.abbreviation}}c_event_t */
${}
<#usercode("{{ s.name }} Client callback function event process")/>
    }

${}
<#usercode("{{ s.name }} Client callback function closing process")/>
}
{%- else %}
/******************************************************************************
 * Function Name: {{ s.abbreviation }}c_cb
 * Description  : Callback function for {{ s.name }} client feature.
 * Arguments    : uint16_t type -
 *                  Event type of {{ s.name }} client feature.
 *              : ble_status_t result -
 *                  Event result of {{ s.name }} client feature.
 *              : st_ble_{{s.abbreviation}}c_evt_data_t *p_data - 
 *                  Event parameters of {{ s.name }} client feature.
 * Return Value : none
 ******************************************************************************/
static void {{ s.abbreviation }}c_cb(uint16_t type, ble_status_t result, st_ble_{{s.abbreviation}}c_evt_data_t *p_data)
{
/* Hint: Input common process of callback function such as variable definitions */
${}
<#usercode("{{ s.name }} Client callback function common process")/>

    switch(type)
    {
/* Hint: Add cases of {{s.name}} client events defined in e_ble_{{s.abbreviation}}c_event_t */
${}
<#usercode("{{ s.name }} Client callback function event process")/>
    }

${}
<#usercode("{{ s.name }} Client callback function closing process")/>
}
{%- endif %}
{%- else %}
/******************************************************************************
 * Function Name: {{ s.abbreviation }}c_cb
 * Description  : Callback function for {{ s.name }} client feature.
 * Arguments    : uint16_t type -
 *                  Event type of {{ s.name }} client feature.
 *              : ble_status_t result -
 *                  Event result of {{ s.name }} client feature.
 *              : st_ble_servc_evt_data_t *p_data - 
 *                  Event parameters of {{ s.name }} client feature.
 * Return Value : none
 ******************************************************************************/
static void {{ s.abbreviation }}c_cb(uint16_t type, ble_status_t result, st_ble_servc_evt_data_t *p_data)
{
/* Hint: Input common process of callback function such as variable definitions */
${}
<#usercode("{{ s.name }} Client callback function common process")/>

    switch(type)
    {
/* Hint: Add cases of {{s.name}} client events defined in e_ble_{{s.abbreviation}}c_event_t */
${}
<#usercode("{{ s.name }} Client callback function event process")/>
    }

${}
<#usercode("{{ s.name }} Client callback function closing process")/>
}
{%- endif %}
{%- endfor %}

{%- if cjson %}
/******************************************************************************
 * Function Name: disc_comp_cb
 * Description  : Callback function for Service Discovery.
 * Arguments    : none
 * Return Value : none
 ******************************************************************************/
static void disc_comp_cb(uint16_t conn_hdl)
{
/* Hint: Input process such as GATT operation */
${}
<#usercode("Discovery Complete callback function")/>
    return;
}
{%- endif %}
/******************************************************************************
 * Function Name: ble_init
 * Description  : Initialize host stack and profiles.
 * Arguments    : none
 * Return Value : BLE_SUCCESS - SUCCESS
 *                BLE_ERR_INVALID_OPERATION -
 *                    Failed to initialize host stack or profiles.
 ******************************************************************************/
static ble_status_t ble_init(void)
{
    ble_status_t status;

    /* Initialize the Low Power Control function */
    R_BLE_LPC_Init();

    /* Initialize Timer Library */
    R_BLE_TIMER_Init();

    /* Initialize host stack */
    status = R_BLE_ABS_Init(&gs_abs_init_param);
    if (BLE_SUCCESS != status)
    {
        return BLE_ERR_INVALID_OPERATION;
    }

    /* Initialize GATT Database */
    status = R_BLE_GATTS_SetDbInst(&g_gatt_db_table);
    if (BLE_SUCCESS != status)
    {
        return BLE_ERR_INVALID_OPERATION;
    }

    /* Initialize GATT server */
    status = R_BLE_SERVS_Init();
    if (BLE_SUCCESS != status)
    {
        return BLE_ERR_INVALID_OPERATION;
    }

    /* Initialize GATT client */
    status = R_BLE_SERVC_Init();
    if (BLE_SUCCESS != status)
    {
        return BLE_ERR_INVALID_OPERATION;
    }

    /* Set Prepare Write Queue */
    R_BLE_GATTS_SetPrepareQueue(gs_queue, BLE_GATTS_QUEUE_NUM);
{%- if cjson %}
    /* Initialize GATT Discovery Library */
    status = R_BLE_DISC_Init();
    if (BLE_SUCCESS != status)
    {
        return BLE_ERR_INVALID_OPERATION;
    }
{%- endif %}
{%- for s in sjson %}
{% if s.abbreviation in old_serv_s_list %}
    /* Initialize {{ s.name }} server API */
    status = R_BLE_{{ s.abbreviation.upper() }}S_Init(&gs_{{ s.abbreviation }}s_init_param);
    if (BLE_SUCCESS != status)
    {
        return BLE_ERR_INVALID_OPERATION;
    }
{%- else %}
    /* Initialize {{ s.name }} server API */
    status = R_BLE_{{ s.abbreviation.upper() }}S_Init({{ s.abbreviation }}s_cb);
    if (BLE_SUCCESS != status)
    {
        return BLE_ERR_INVALID_OPERATION;
    }
{%- endif %}
{%- endfor %}
{%- for s in cjson %}
{% if s.abbreviation in old_serv_c_list %}
    /* Initialize {{ s.name }} client API */
    status = R_BLE_{{ s.abbreviation.upper() }}C_Init(&gs_{{ s.abbreviation }}c_init_param);
    if (BLE_SUCCESS != status)
    {
        return BLE_ERR_INVALID_OPERATION;
    }
{%- else %}
    /* Initialize {{ s.name }} client API */
    status = R_BLE_{{ s.abbreviation.upper() }}C_Init({{ s.abbreviation }}c_cb);
    if (BLE_SUCCESS != status)
    {
        return BLE_ERR_INVALID_OPERATION;
    }
{%- endif %}
{%- endfor %}

    return status;
}

/******************************************************************************
 * Function Name: app_main
 * Description  : Application main function with main loop
 * Arguments    : none
 * Return Value : none
 ******************************************************************************/
void app_main(void)
{
    /* Initialize BLE */
    R_BLE_Open();

    /* Initialize host stack and profiles */
    ble_init();

/* Hint: Input process that should be done before main loop such as calling initial function or variable definitions */
${}
<#usercode("process before main loop")/>

    /* main loop */
    while (1)
    {
/* Hint: Input process that should be done before BLE_Execute in main loop */
${}
<#usercode("process before BLE_Execute")/>

        /* Process BLE Event */
        R_BLE_Execute();

#if (BSP_CFG_RTOS_USED == 0)
        /* Enter the MCU Lower Power Mode */
        R_BLE_LPC_EnterLowPowerMode();
#elif (BSP_CFG_RTOS_USED == 1)
        if(0 != R_BLE_IsTaskFree()) 
        {
        	ulTaskNotifyTake(pdFALSE, portMAX_DELAY);
        }
#endif

/* Hint: Input process that should be done during main loop such as calling processing functions */
${}
<#usercode("process during main loop")/>
    }

/* Hint: Input process that should be done after main loop such as calling closing functions */
${}
<#usercode("process after main loop")/>

    /* Terminate BLE */
    R_BLE_Close();
}

/******************************************************************************
 User function definitions
*******************************************************************************/
${}
<#usercode("function definitions")/>
