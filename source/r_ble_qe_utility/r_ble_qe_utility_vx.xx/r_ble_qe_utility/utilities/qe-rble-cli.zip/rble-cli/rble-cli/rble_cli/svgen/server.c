/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_{{ s.name }}.c
 * Version : 1.0
 * Description : The source file for {{ s.full_name }} service.
 **********************************************************************************************************************/

#include "r_ble_{{ s.name.lower() }}.h"
#include "profile_cmn/r_ble_servs_if.h"
#include "gatt_db.h"

static st_ble_servs_info_t gs_servs_info;{{"\n"}}
{%- for c in s.characteristics %}
  {%- if c.descriptors | length > 0 %}
    {%- for d in c.descriptors %}
/*----------------------------------------------------------------------------------------------------------------------
    {{ c.full_name }} {{ d.full_name }} descriptor
----------------------------------------------------------------------------------------------------------------------*/{{"\n"}}
      {%- if not d.is_default_type() %}
static ble_status_t decode_{{ d.type_name() }}({{ d.type_name() }} *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
        {%- if qe %}
    ${}
    <#usercode("{{ c.full_name }} {{ d.full_name }} descriptor value decode function")/>
        {%- else %}
    /* TODO */
        {%- endif %}
    return BLE_SUCCESS;
}{{"\n"}}
static ble_status_t encode_{{ d.type_name() }}(const {{ d.type_name() }} *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
        {%- if qe %}
    ${}
    <#usercode("{{ c.full_name }} {{ d.full_name }} descriptor value encode function")/>
        {%- else %}
    /* TODO */
        {%- endif %}
    return BLE_SUCCESS;
}{{"\n"}}
      {%- endif %}
static const st_ble_servs_desc_info_t gs_{{ snake(d.parent.name) }}_{{ snake(d.name) }} = {
    .attr_hdl = {{ d.macro_name('DESC_HDL') }},
      {%- if (d.fields | length == 1) and (d.fields[0].length == 'variable') %}
    .app_size = {{ d.fields[0].macro_name('LEN') }},
      {%- else %}
    .app_size = sizeof({{ d.type_name() }}),
      {%- endif %}
    .desc_idx = {{ d.macro_name('IDX') }},
    .db_size  = {{ d.macro_name('LEN') }},
    .decode   = (ble_servs_attr_decode_t)decode_{{ d.type_name() }},
    .encode   = (ble_servs_attr_encode_t)encode_{{ d.type_name() }},
};{{"\n"}}
      {%- if 'Read' in d.properties %}
        {%- if 'Peer Specific' in d.aux_properties %}
ble_status_t {{ d.api_name('set') }}(uint16_t conn_hdl, const {{ d.type_name() }} *p_value)
        {%- else %}
ble_status_t {{ d.api_name('set') }}(const {{ d.type_name() }} *p_value)
        {%- endif %}
{
        {%- if 'Peer Specific' in d.aux_properties %}
    return R_BLE_SERVS_SetDesc(&gs_{{ snake(d.parent.name) }}_{{ snake(d.name) }}, conn_hdl, (const void *)p_value);
        {%- else %}
    return R_BLE_SERVS_SetDesc(&gs_{{ snake(d.parent.name) }}_{{ snake(d.name) }}, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
        {%- endif %}
}{{"\n"}}
        {%- if 'Peer Specific' in d.aux_properties %}
ble_status_t {{ d.api_name('get') }}(uint16_t conn_hdl, {{ d.type_name() }} *p_value)
        {%- else %}
ble_status_t {{ d.api_name('get') }}({{ d.type_name() }} *p_value)
        {%- endif %}
{
        {%- if 'Peer Specific' in d.aux_properties %}
    return R_BLE_SERVS_GetDesc(&gs_{{ snake(d.parent.name) }}_{{ snake(d.name) }}, conn_hdl, (void *)p_value);
        {%- else %}
    return R_BLE_SERVS_GetDesc(&gs_{{ snake(d.parent.name) }}_{{ snake(d.name) }}, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
        {%- endif %}
}{{"\n"}}
      {%- endif %}
    {%- endfor %}
  {%- endif %}
/*----------------------------------------------------------------------------------------------------------------------
    {{ c.full_name }} characteristic
----------------------------------------------------------------------------------------------------------------------*/{{"\n"}}
  {%- if not c.is_default_type() %}
static ble_status_t decode_{{ c.type_name() }}({{ c.type_name() }} *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
    {%- if qe %}
    ${}
    <#usercode("{{ c.full_name }} characteristic value decode function")/>
    {%- else %}
    /* TODO */
    {%- endif %}
    return BLE_SUCCESS;
}{{"\n"}}
static ble_status_t encode_{{ c.type_name() }}(const {{ c.type_name() }} *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
    {%- if qe %}
    ${}
    <#usercode("{{ c.full_name }} characteristic value encode function")/>
    {%- else %}
    /* TODO */
    {%- endif %}
    return BLE_SUCCESS;
}{{"\n"}}
    {%- endif %}
    {%- if c.descriptors | length > 0 %}
/* {{ c.full_name }} characteristic descriptor definition */
static const st_ble_servs_desc_info_t *gspp_{{ snake(c.name) }}_descs[] = {
      {%- for d in c.descriptors %}
    &gs_{{ snake(d.parent.name) }}_{{ snake(d.name) }},
      {%- endfor %}
};{{"\n"}}
    {%- endif %}
/* {{ c.full_name }} characteristic definition */
static const st_ble_servs_char_info_t gs_{{ snake(c.name) }}_char = {
    .start_hdl    = {{ c.macro_name('DECL_HDL') }},
    .end_hdl      = {{ c.end_hdl_name() }},
    .char_idx     = {{ c.macro_name('IDX') }},
      {%- if (c.fields | length == 1) and (c.fields[0].length == 'variable') %}
    .app_size     = {{ c.fields[0].macro_name('LEN') }},
      {%- else %}
    .app_size     = sizeof({{ c.type_name() }}),
      {%- endif %}
    .db_size      = {{ c.macro_name('LEN') }},
    .decode       = (ble_servs_attr_decode_t)decode_{{ c.type_name() }},
    .encode       = (ble_servs_attr_encode_t)encode_{{ c.type_name() }},
    {%- if c.descriptors | length > 0 %}
    .pp_descs     = gspp_{{ snake(c.name) }}_descs,
    .num_of_descs = ARRAY_SIZE(gspp_{{ snake(c.name) }}_descs),
    {%- endif %}
};{{"\n"}}
    {%- if 'Read' in c.properties %}
        {%- if 'Peer Specific' in c.aux_properties %}
ble_status_t {{ c.api_name('set') }}(uint16_t conn_hdl, const {{ c.type_name() }} *p_value)
        {%- else %}
ble_status_t {{ c.api_name('set') }}(const {{ c.type_name() }} *p_value)
        {%- endif %}
{
        {%- if 'Peer Specific' in c.aux_properties %}
    return R_BLE_SERVS_SetChar(&gs_{{ snake(c.name) }}_char, conn_hdl, (const void *)p_value);
        {%- else %}
    return R_BLE_SERVS_SetChar(&gs_{{ snake(c.name) }}_char, BLE_GAP_INVALID_CONN_HDL, (const void *)p_value);
        {%- endif %}
}{{"\n"}}
        {%- if 'Peer Specific' in c.aux_properties %}
ble_status_t {{ c.api_name('get') }}(uint16_t conn_hdl, {{ c.type_name() }} *p_value)
        {%- else %}
ble_status_t {{ c.api_name('get') }}({{ c.type_name() }} *p_value)
        {%- endif %}
{
        {%- if 'Peer Specific' in c.aux_properties %}
    return R_BLE_SERVS_GetChar(&gs_{{ snake(c.name) }}_char, conn_hdl, (void *)p_value);
        {%- else %}
    return R_BLE_SERVS_GetChar(&gs_{{ snake(c.name) }}_char, BLE_GAP_INVALID_CONN_HDL, (void *)p_value);
        {%- endif %}
}{{"\n"}}
    {%- endif %}
    {%- if 'Notify' in c.properties %}
ble_status_t {{ c.api_name('notify') }}(uint16_t conn_hdl, const {{ c.type_name() }} *p_value)
{
    return R_BLE_SERVS_SendHdlVal(&gs_{{ snake(c.name) }}_char, conn_hdl, (const void *)p_value, true);
}{{"\n"}}
    {%- endif %}
    {%- if 'Indicate' in c.properties %}
ble_status_t {{ c.api_name('indicate') }}(uint16_t conn_hdl, const {{ c.type_name() }} *p_value)
{
    return R_BLE_SERVS_SendHdlVal(&gs_{{ snake(c.name) }}_char, conn_hdl, (const void *)p_value, false);
}{{"\n"}}
    {%- endif %}
{%- endfor %}
/*----------------------------------------------------------------------------------------------------------------------
    {{ s.full_name }} server
----------------------------------------------------------------------------------------------------------------------*/

/* {{ s.full_name }} characteristics definition */
static const st_ble_servs_char_info_t *gspp_chars[] = {
{%- for c in s.characteristics %}
    &gs_{{ snake(c.name) }}_char,
{%- endfor %}
};

/* {{ s.full_name }} service definition */
static st_ble_servs_info_t gs_servs_info = {
    .pp_chars     = gspp_chars,
    .num_of_chars = ARRAY_SIZE(gspp_chars),
};

ble_status_t R_BLE_{{ s.name.upper() }}_Init(ble_servs_app_cb_t cb)
{
    if (NULL == cb)
    {
        return BLE_ERR_INVALID_PTR;
    }

    gs_servs_info.cb = cb;

    return R_BLE_SERVS_RegisterServer(&gs_servs_info);
}{{"\n"}}
