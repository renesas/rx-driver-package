import os, sys, re, json, argparse, copy
from jinja2 import Environment, FileSystemLoader


SERVICE_JSON_PATH = os.environ['RBLE_SDK_PATH'] + "/" + "app_lib/services/json/services2/"

def format_value(size, value):
    if value is None:
        return ['0x00' for i in range(size)]
    else:
        ret = ['0x00' for i in range(size)]

        if isinstance(value, (str, unicode)):
            value = list(map(lambda x: "'"+x+"'", value))

        if len(value) > size:
            for i in range(size):
                ret[i] = value[i]
        else:
            for i in range(len(value)):
                ret[i] = value[i]

        return ret

def format_properties1(properties):
    prop = 0x00
    if 'Broadcast' in properties:
        prop |= 0x01
    if 'Read' in properties:
        prop |= 0x02
    if 'WriteWithoutResponse' in properties:
        prop |= 0x04
    if 'Write' in properties:
        prop |= 0x08
    if 'Notify' in properties:
        prop |= 0x10
    if 'Indicate' in properties:
        prop |= 0x20
    if 'SignedWrites' in properties:
        prop |= 0x40
    if 'ReliableWrite' in properties:
        prop |= 0x80
    if 'WritableAuxiliaries' in properties:
        prop |= 0x80
    return prop

def format_properties2(properties):
    prop = []
    if 'Read' in properties:
        prop.append('BLE_GATT_DB_READ')
    if 'Write' in properties:
        prop.append('BLE_GATT_DB_WRITE')
    if 'WriteWithoutResponse' in properties:
        prop.append('BLE_GATT_DB_WRITE_WITHOUT_RSP')
    if 'Notify' in properties:
        pass
    if 'Indicate' in properties:
        pass
    return prop if prop else [0]

def format_aux_properties(aux_properteis):
    prop = []

    if 'Variable Length' not in aux_properteis:
        prop.append('BLE_GATT_DB_FIXED_LENGTH_PROPERTY')
    if 'Disable' in aux_properteis:
        prop.append('BLE_GATT_DB_ATTR_DISABLED')
    if 'Peer Specific' in aux_properteis:
        prop.append('BLE_GATT_DB_PEER_SPECIFIC_VAL_PROPERTY')
    if 'Const' in aux_properteis:
        prop.append('BLE_GATT_DB_CONST_ATTR_VAL_PROPERTY')
    if 'Authorization' in aux_properteis:
        prop.append('BLE_GATT_DB_AUTHORIZATION_PROPERTY')

    return prop if prop else ['BLE_GATT_DB_NO_AUXILIARY_PROPERTY']

def format_security(security):
    prop = []
    if 'Unauthentication' in security:
        prop.append('BLE_GATT_DB_SER_SECURITY_UNAUTH')
    if 'Authentication' in security:
        prop.append('BLE_GATT_DB_SER_SECURITY_AUTH')
    if 'Secure Connection' in security:
        prop.append('BLE_GATT_DB_SER_SECURITY_SECONN')
    if 'Encryption' in security:
        prop.append('BLE_GATT_DB_SER_SECURITY_ENC')
    if 'Authorization' in security:
        prop.append('BLE_GATT_DB_AUTHORIZATION_PROPERTY')
    return prop if prop else [0]

def format_name(json):
    namesub = r'[-\(\):\'\.,/]'

    if json['abbreviation']:
        return re.sub(namesub, '_', '_'.join(json['abbreviation'].upper().split(' ')))
    else:
        return re.sub(namesub, '_', '_'.join(json['name'].upper().split(' ')))

def gen_enum_hdls(pj):
    enum_hdls = []
    index = 1
    for sj in pj['services']:
        enum_hdls.append({
            'name': '_'.join(['BLE', format_name(sj)+'S', 'DECL', 'HDL']),
            'index': index
        })
        index += 1
        for cj in sj['characteristics']:
            enum_hdls.append({
                'name': '_'.join(['BLE', format_name(sj)+'S', format_name(cj), 'DECL', 'HDL']),
                'index': index
            })
            index += 1

            enum_hdls.append({
                'name': '_'.join(['BLE', format_name(sj)+'S', format_name(cj), 'VAL', 'HDL']),
                'index': index
            })
            index += 1
            for dj in cj['descriptors']:
                enum_hdls.append({
                    'name': '_'.join(['BLE', format_name(sj)+'S', format_name(cj), format_name(dj), 'DESC', 'HDL']),
                    'index': index,
                })
                index += 1

    return enum_hdls


def gen_attr_lens(pj):
    attr_lens = []
    for sj in pj['services']:
        for cj in sj['characteristics']:
            attr_lens.append({
                'name': '_'.join(['BLE', format_name(sj)+'S', format_name(cj), 'LEN']),
                'length': cj['db_size']
            })
            for dj in cj['descriptors']:
                attr_lens.append({
                    'name': '_'.join(['BLE', format_name(sj)+'S', format_name(cj), format_name(dj), 'LEN']),
                    'length': dj['db_size']
                })

    return attr_lens

def gen_uuid_table(pj):
    uuid_table = [
        {
            'name': 'Primary Service Declaration',
            'uuid': ['0x00', '0x28'],
            'offset': 0,
        },
        {
            'name': 'Secondary Service Declaration',
            'uuid': ['0x01', '0x28'],
            'offset': 2,
        },
        {
            'name': 'Included Service Declaration',
            'uuid': ['0x02', '0x28'],
            'offset': 4,
        },
        {
            'name': 'Characteristic Declaration',
            'uuid': ['0x03', '0x28'],
            'offset': 6,
        }
    ]
    uuid_offset = 8

    def add_new_uuid(v):
        for e in uuid_table:
            if e['uuid'] == v['uuid']:
                return False
        uuid_table.append(v)
        return True

    for sj in pj['services']:
        if add_new_uuid({
                'name': sj['name'],
                'uuid': sj['uuid'],
                'offset': uuid_offset}):
            uuid_offset += len(sj['uuid'])

        for cj in sj['characteristics']:
            if add_new_uuid({
                    'name': cj['name'],
                    'uuid': cj['uuid'],
                    'offset': uuid_offset}):
                uuid_offset += len(cj['uuid'])

            for dj in cj['descriptors']:
                if add_new_uuid({
                        'name': dj['name'],
                        'uuid': dj['uuid'],
                        'offset': uuid_offset}):
                    uuid_offset += len(dj['uuid'])

    return uuid_table


def gen_attr_table(pj):
    uuid_table = gen_uuid_table(pj)

    def get_uuid_offset(v):
        for uuid in uuid_table:
            if uuid['uuid'] == v:
                return uuid['offset']
        else:
            assert(False)

    attr_table = [
        {
            'name': 'Blank',
            'attr_hdl': 0xFFFF,
            'properties': [0],
            'aux_properties': ['BLE_GATT_DB_NO_AUXILIARY_PROPERTY'],
            'db_size': 1,
            'next_hdl': 0xFFFF,
            'uuid_offset': 0,
            'value': 'NULL'
        },
    ]
    attr_hdl = 1
    const_value_offset = 0
    const_peer_value_offset = 0
    value_offset = 0

    p = copy.deepcopy(pj)

    for sj in p['services']:
        # Primary Service Declaration
        sj['aux_properties'] = format_aux_properties(sj['aux_properties'])

        if len(sj['uuid']) > 2:
            sj['aux_properties'].append('BLE_GATT_DB_128_BIT_UUID_FORMAT')

        attr_table.append({
            'name': sj['name'] + ' : Primary Service Declaration',
            'attr_hdl': attr_hdl,
            'properties': format_properties2(['Read']),
            'aux_properties': sj['aux_properties'],
            'db_size': len(sj['uuid']),
            'next_hdl': 0,
            'uuid_offset': get_uuid_offset(['0x00', '0x28']),
            'value': '(uint8_t *)(gs_gatt_const_uuid_arr + ' + str(get_uuid_offset(sj['uuid'])) + ')',
        })
        attr_hdl += 1

        # Included Service Declaration
        for ij in sj['included']:
            attr_table.append({
                'name': ij['name'] + ' : Included Service Declaration',
                'attr_hdl': attr_hdl,
                'properties': format_properties2(['Read']),
                'aux_properties': format_aux_properties([]),
                'db_size': len(ij['uuid']) + 4,
                'next_hdl': 0,
                'uuid_offset': get_uuid_offset(['0x02', '0x28']),
                'value': '(uint8_t *)(gs_gatt_const_value_arr + ' + str(const_value_offset) + ')',
            })
            attr_hdl += 1
            const_value_offset += len(ij['uuid']) + 4

        for cj in sj['characteristics']:
            # Characteristic Declaration

            attr_table.append({
                'name': cj['name'] + ' : Characteristic Declaration',
                'attr_hdl': attr_hdl,
                'properties': format_properties2(['Read']),
                'aux_properties': format_aux_properties(cj['aux_properties']),
                'db_size': len(cj['uuid']) + 3,
                'next_hdl': 0,
                'uuid_offset': get_uuid_offset(['0x03', '0x28']),
                'value': '(uint8_t *)(gs_gatt_const_value_arr + ' + str(const_value_offset) + ')',
            })
            attr_hdl += 1
            const_value_offset += len(cj['uuid']) + 3

            # Characteristic Value
            if set(cj['properties']) & set(['Read', 'Write', 'WriteWithoutResponse']):
                if 'Peer Specific' in cj['aux_properties']:
                    value = '(uint8_t *)(gs_gatt_db_peer_specific_val_arr + ' + str(const_peer_value_offset) + ')'
                    const_peer_value_offset += cj['db_size']
                else:
                    value = '(uint8_t *)(gs_gatt_value_arr + ' + str(value_offset) + ')'
                    if 'Variable Length' in cj['aux_properties']:
                        value_offset += cj['db_size'] + 2
                    else:
                        value_offset += cj['db_size']
            else:
                value = '(NULL)'
                
            aux_props = format_aux_properties(cj['aux_properties'])
            if len(cj['uuid']) > 2:
                aux_props.append('BLE_GATT_DB_128_BIT_UUID_FORMAT')

            attr_table.append({
                'name': cj['name'],
                'attr_hdl': attr_hdl,
                'properties': format_properties2(cj['properties']),
                'aux_properties': aux_props,
                'db_size': cj['db_size'],
                'next_hdl': 0,
                'uuid_offset': get_uuid_offset(cj['uuid']),
                'value': value,
            })
            attr_hdl += 1

            for dj in cj['descriptors']:
                if set(dj['properties']) & set(['Read', 'Write']):
                    if  'Peer Specific' in dj['aux_properties']:
                        value = '(uint8_t *)(gs_gatt_db_peer_specific_val_arr + ' + str(const_peer_value_offset) + ')'
                        const_peer_value_offset += dj['db_size']
                    else:
                        value = '(uint8_t *)(gs_gatt_value_arr + ' + str(value_offset) + ')'
                        if 'Variable Length' in dj['aux_properties']:
                            value_offset += dj['db_size'] + 2
                        else:
                            value_offset += dj['db_size']
                else:
                    value = '(NULL)'

                dj['aux_properties'] = format_aux_properties(dj['aux_properties'])

                # Descriptor
                if len(dj['uuid']) > 2:
                    dj['aux_properties'].append('BLE_GATT_DB_128_BIT_UUID_FORMAT')

                attr_table.append({
                    'name': cj['name'] + ' : ' + dj['name'],
                    'attr_hdl': attr_hdl,
                    'properties': format_properties2(dj['properties']) if (len(dj['properties']) > 0) else [0],
                    'aux_properties': format_aux_properties(dj['aux_properties']),
                    'db_size': dj['db_size'],
                    'next_hdl': 0,
                    'uuid_offset': get_uuid_offset(dj['uuid']),
                    'value': value,
                })
                attr_hdl += 1

    for index, a1 in enumerate(attr_table):
        attr_table[index]['next_hdl'] = 0
        for a2 in attr_table[index+1:]:
            if a1['uuid_offset'] == a2['uuid_offset']:
                attr_table[index]['next_hdl'] = a2['attr_hdl']
                break

    return attr_table

def gen_value_table(pj):
    value_table = []

    for sj in pj['services']:
        for cj in sj['characteristics']:
            if set(cj['properties']) & set(['Read', 'Write', 'WriteWithoutResponse']):
                if 'Peer Specific' not in cj['aux_properties']:
                    if 'Variable Length' in cj['aux_properties']:
                        size = len(cj['value'])
                        value = ['0x' + format(size >> 0, '02x'),
                                 '0x' + format(size >> 8, '02x')]
                        value.extend(format_value(cj['db_size'], cj['value']))
                        value_table.append({
                            'name': cj['name'],
                            'value': value
                        })
                    else:
                        value_table.append({
                            'name': cj['name'],
                            'value': format_value(cj['db_size'], cj['value']),
                    })

            for dj in cj['descriptors']:
                if 'Peer Specific' not in dj['aux_properties']:
                    if 'Variable Length' in dj['aux_properties']:
                        size = len(dj['value'])
                        value = ['0x' + format(size >> 0, '02x'),
                                 '0x' + format(size >> 8, '02x')]
                        value.extend(format_value(dj['db_size'], dj['value']))
                        value_table.append({
                            'name': cj['name'] + ' : ' + dj['name'],
                            'value': value
                        })
                    else:
                        value_table.append({
                            'name': cj['name'] + ' : ' + dj['name'],
                            'value': format_value(dj['db_size'], dj['value']),
                        })                            

    return value_table

def gen_const_table(pj):
    const_table = []
    attr_hdl = 0x01
    servs = []

    for sj in pj['services']:
        servs.append({
            'uuid': sj['uuid'],
            'start_hdl': attr_hdl,
            'end_hdl': 0,
        })

        attr_hdl += 1

        for ij in sj['included']:
            attr_hdl += 1
            const_table.append({
                'type': 'Included',
                'name': ij['name'],
                'start_hdl': ['0x00', '0x00'],
                'end_hdl': ['0x00', '0x00'],
                'uuid': ij['uuid'],
                'index': ij['index'] if 'index' in ij else 0,
            })

        for cj in sj['characteristics']:
            attr_hdl += 1
            const_table.append({
                'type': 'Characteristic',
                'start_hdl': ['0x' + format((attr_hdl >> 0) & 0xFF, '02X'),
                              '0x' + format((attr_hdl >> 8) & 0xFF, '02X')],
                'name': cj['name'],
                'properties': format_properties1(cj['properties']),
                'uuid': cj['uuid'],
            })
            attr_hdl += 1

            for dj in cj['descriptors']:
                attr_hdl += 1

        servs[-1]['end_hdl'] = attr_hdl - 1

        for c in const_table:
            if c['type'] == 'Included':
                index = 0
                for s in servs:
                    if c['uuid'] == s['uuid']:
                        if index == c['index']:
                            c['start_hdl'] = ['0x' + format((s['start_hdl'] >> 0) & 0xFF, '02X'),
                                              '0x' + format((s['start_hdl'] >> 8) & 0xFF, '02X')]
                            c['end_hdl'] = ['0x' + format((s['end_hdl'] >> 0) & 0xFF, '02X'),
                                            '0x' + format((s['end_hdl'] >> 8) & 0xFF, '02X')]
                            break
                        else:
                            index += 1

    return const_table

def gen_peer_table_size(pj):
    peer_table_size = 0

    for sj in pj['services']:
        for cj in sj['characteristics']:
            if 'Peer Specific' in cj['aux_properties']:
                peer_table_size += cj['db_size']
            for dj in cj['descriptors']:
                if 'Peer Specific' in dj['aux_properties']:
                    peer_table_size += dj['db_size']

    return peer_table_size

def gen_const_peer_table(pj):
    const_peer_table = []

    for sj in pj['services']:
        for cj in sj['characteristics']:
            if 'Peer Specific' in cj['aux_properties']:
                const_peer_table.append({
                    'name': cj['name'],
                    'value': format_value(cj['db_size'], cj['value']),
                })
            for dj in cj['descriptors']:
                if 'Peer Specific' in dj['aux_properties']:
                    const_peer_table.append({
                        'name': cj['name'] + ' : ' + dj['name'],
                        'value': format_value(dj['db_size'], dj['value']),
                    })

    return const_peer_table

def gen_type_table(pj):
    type_table = []
    uuid_table = gen_uuid_table(pj)

    def get_uuid_offset(v):
        for uuid in uuid_table:
            if uuid['uuid'] == v:
                return uuid['offset']
        else:
            assert(False)

    def add_new_type(v):
        for index, e in enumerate(type_table):
            if e['uuid_offset'] == v['uuid_offset']:
                type_table[index]['last_type'] = v['attr_hdl']
                return False
        type_table.append(v)
        return True

    uuid_offset = 8
    attr_hdl = 1

    for sj in pj['services']:
        if add_new_type({
                'name': 'Primary Service Declaration',
                'attr_hdl': attr_hdl,
                'uuid_offset': get_uuid_offset(['0x00', '0x28']),
                'first_type': attr_hdl,
                'last_type': 0}):
            uuid_offset += 2

        if add_new_type({
                'name': sj['name'],
                'attr_hdl': attr_hdl,
                'uuid_offset': get_uuid_offset(sj['uuid']),
                'first_type': attr_hdl,
                'last_type': 0}):
            uuid_offset += len(sj['uuid'])
        attr_hdl += 1

        for ij in sj['included']:
            if add_new_type({
                    'name': 'Included Service Declaration',
                    'attr_hdl': attr_hdl,
                    'uuid_offset': get_uuid_offset(['0x02', '0x28']),
                    'first_type': attr_hdl,
                    'last_type': 0}):
                uuid_offset += 2
            attr_hdl += 1

        for cj in sj['characteristics']:
            if add_new_type({
                    'name': 'Characteristic Declaration',
                    'attr_hdl': attr_hdl,
                    'uuid_offset': get_uuid_offset(['0x03', '0x28']),
                    'first_type': attr_hdl,
                    'last_type': 0}):
                uuid_offset += 2
            attr_hdl += 1

            if add_new_type({
                    'name': cj['name'],
                    'attr_hdl': attr_hdl,
                    'uuid_offset': get_uuid_offset(cj['uuid']),
                    'first_type': attr_hdl,
                    'last_type': 0}):
                uuid_offset += len(cj['uuid'])
            attr_hdl += 1

            for dj in cj['descriptors']:
                if add_new_type({
                        'name': dj['name'],
                        'attr_hdl': attr_hdl,
                        'uuid_offset': get_uuid_offset(dj['uuid']),
                        'first_type': attr_hdl,
                        'last_type': 0}):
                    uuid_offset += len(dj['uuid'])
                attr_hdl += 1

    return type_table

def gen_char_table(pj):
    char_table = []
    serv_idx = -1
    char_start_hdl = 1

    for sj in pj['services']:
        char_start_hdl += 1
        for ij in sj['included']:
            char_start_hdl += 1
        serv_idx += 1
        for cj in sj['characteristics']:
            num_of_attrs = 2
            for dj in cj['descriptors']:
                num_of_attrs += 1

            char_table.append({
                'name': cj['name'],
                'num_of_attrs': num_of_attrs,
                'start_hdl': char_start_hdl,
                'serv_idx': serv_idx,
            })

            char_start_hdl += num_of_attrs

    return char_table

def gen_serv_table(pj):
    serv_table = []
    serv_start_hdl = 1
    serv_end_hdl = 0
    char_start_idx = 0
    char_end_idx = -1

    for sj in pj['services']:
        serv_end_hdl += 1
        for ij in sj['included']:
            serv_end_hdl += 1
        for cj in sj['characteristics']:
            serv_end_hdl += 2
            char_end_idx += 1
            for dj in cj['descriptors']:
                serv_end_hdl += 1

        serv_table.append({
            'name': sj['name'],
            'security': format_security(sj['aux_properties']),
            'start_hdl': serv_start_hdl,
            'end_hdl': serv_end_hdl,
            'char_start_idx': char_start_idx,
            'char_end_idx': char_end_idx,
        })
        serv_start_hdl = serv_end_hdl + 1
        char_start_idx = char_end_idx + 1

    return serv_table

def generate(pj, template):

    context = {
        'enum_hdls': gen_enum_hdls(pj),
        'attr_lens': gen_attr_lens(pj),
        'uuid_table': gen_uuid_table(pj),
        'attr_table': gen_attr_table(pj),
        'value_table': gen_value_table(pj),
        'const_table': gen_const_table(pj),
        'peer_table_size': gen_peer_table_size(pj),
        'const_peer_table': gen_const_peer_table(pj),
        'type_table': gen_type_table(pj),
        'char_table': gen_char_table(pj),
        'serv_table': gen_serv_table(pj),
    }

    TEMPLATE_ENVIRONMENT = Environment(
        autoescape=False,
        loader=FileSystemLoader(os.path.dirname(os.path.abspath(__file__))),
        trim_blocks=False)

    return TEMPLATE_ENVIRONMENT.get_template(template).render(context)

def main(args):
    parser = argparse.ArgumentParser(prog="rble-cli dbgen")

    parser.add_argument(
        'json',
        help='service json file'
    )

    parser.add_argument(
        '--out',
        default = '.',
        help='output directory of the generated source code'
    )

    parser.add_argument(
        '--qe',
        action='store_true'
    )

    args = parser.parse_args(args)

    pj = json.loads(open(args.json, "r").read())

    sjp = SERVICE_JSON_PATH;
    if args.qe:
        sjp = args.out + '/'

    for si, sj in enumerate(pj['services']):
        s = json.loads(open(sjp + sj['refer'], 'r').read())
        s['included'] = []
        if 'included' in sj:
            for ij in sj['included']:
                i = json.loads(open(sjp + ij['refer'], 'r').read())
                i['index'] = ij['index'] if 'index' in ij else 0
                s['included'].append(i)
            
        found = False
        if 'characteristics' in sj:
            for cj in sj['characteristics']:
                for ci, c in enumerate(s['characteristics']):
                    if cj['name'] == c['name']:
                        if 'value' in cj:
                            s['characteristics'][ci]['value'] = cj['value']
                        if 'db_size' in cj:
                            s['characteristics'][ci]['db_size'] = cj['db_size']
                        found = True

                        if 'descriptors' in cj:
                            for dj in cj['descriptors']:
                                for di, d in enumerate(c['descriptors']):
                                    if dj['name'] == d['name']:
                                        if 'value' in dj:
                                            s['characteristics'][ci]['descriptors'][di]['value'] = dj['value']
                                        if ('db_size' in dj) and (s['characteristics'][ci]['descriptors'][di]['db_size'] == 'Variable Length'):
                                            s['characteristics'][ci]['descriptors'][di]['db_size'] = dj['db_size']
                                        found = True
                                        break

                assert found, '"' + cj['name'] + '" is not in ' + sj['refer']

        pj['services'][si] = s

    # fill a blank space
    for sj in pj['services']:
        for cj in sj['characteristics']:
            if 'descriptors' not in cj:
                cj['descriptors'] = []
            if 'value' not in cj:
                cj['value'] = [ '0x00' ]
            for dj in cj['descriptors']:
                if 'value' not in dj:
                    dj['value'] = [ '0x00' ]

    open(args.out + '/' + 'gatt_db.c', 'w').write(generate(pj, 'gatt_db_template.c'))
    open(args.out + '/' + 'gatt_db.h', 'w').write(generate(pj, 'gatt_db_template.h'))

if __name__ == '__main__':
    main(sys.argv[1:])
