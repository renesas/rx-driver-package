{%- macro print_struct(attr) -%}
  {%- for f in attr.fields recursive %}
    {%- if f.fields | length > 0 %}
      {{ loop(f.fields) }}
/***************************************************************************//**
 * @brief {{ attr.full_name }} {{ f.name }} value structure.
*******************************************************************************/
typedef struct {
      {%- for ff in f.fields %}
    {{ ff.type_def() }}; /**< {{ ff.description }} */
      {%- endfor %}
} {{ f.type_name() }};{{"\n"}}
    {%- endif %}
  {%- endfor %}
/***************************************************************************//**
 * @brief {{ attr.full_name }} value structure.
*******************************************************************************/
typedef struct {
  {%- for f in attr.fields %}
    {{ f.type_def() }}; /**< {{ f.description }} */
  {%- endfor %}
} {{ attr.type_name() }};{{"\n"}}
{%- endmacro -%}
{%- macro print_enum(attr) -%}
  {%- for f in attr.fields recursive %}
    {%- if f.fields %}
      {{ loop(f.fields) }}
    {%- endif %}
    {%- if f.enumerations %}
/***************************************************************************//**
 * @brief {{ attr.full_name }} {{ f.name }} enumeration.
*******************************************************************************/
typedef enum {
      {%- for e in f.enumerations %}
    {{ e.enum_def() }} = {{ e.key }}, /**< {{ e.description }} */
      {%- endfor %}
} {{ f.enum_name() }};{{"\n"}}
    {%- endif %}
  {%- endfor %}
{%- endmacro -%}
{%- macro print_variable(attr) -%}
  {%- for f in attr.fields recursive %}
    {%- if f.fields %}
      {{ loop(f.fields) }}
    {%- endif %}
    {%- if f.length == 'variable' %}
/** {{ f.name }} Length */
#define {{ f.macro_name('LEN') }} (TODO){{"\n"}}
    {%- endif %}
    {%- if f.fields %}
      {{ print_variable(f) }}
    {%- endif %}
  {%- endfor %}
{%- endmacro -%}
/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_{{ s.name }}.h
 * Version : 1.0
 * Description : The header file for {{ s.full_name }} service.
 **********************************************************************************************************************/
/***********************************************************************************************************************
 * History : DD.MM.YYYY Version Description
 *         : 31.12.2999 1.00 First Release
 ***********************************************************************************************************************/

/*******************************************************************************************************************//**
 * @file
 * @defgroup {{ s.name }} {{ s.full_name }} Service
 * @{
 * @ingroup profile
 * @brief   {{ s.description }}
 **********************************************************************************************************************/
#include "r_ble_rx23w_if.h"

#include "profile_cmn/r_ble_servs_if.h"
#include "gatt_db.h"

#ifndef R_BLE_{{ s.name.upper() }}_H
#define R_BLE_{{ s.name.upper() }}_H{{"\n"}}
{%- for c in s.characteristics %}
/*----------------------------------------------------------------------------------------------------------------------
    {{ c.full_name }} Characteristic
----------------------------------------------------------------------------------------------------------------------*/
  {%- for d in c.descriptors %}
{{ print_variable(d) }}{{ print_enum(d) }}{%- if not d.is_default_type() %}{{ print_struct(d) }}{%- endif %}
  {%- endfor -%}
{{ print_variable(c) }}{{ print_enum(c) }}{%- if not c.is_default_type() %}{{ print_struct(c) }}{%- endif %}
  {%- if 'Read' in c.properties %}
/***************************************************************************//**
 * @brief     Set {{ c.full_name }} characteristic value to the local GATT database.
    {%- if 'Peer Specific' in c.aux_properties %}
 * @param[in] conn_hdl Connection handle.
    {%- endif %}
 * @param[in] p_value  Characteristic value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
    {%- if 'Peer Specific' in c.aux_properties %}
ble_status_t {{ c.api_name('set') }}(uint16_t conn_hdl, const {{ c.type_name() }} *p_value);{{"\n"}}
    {%- else %}
ble_status_t {{ c.api_name('set') }}(const {{ c.type_name() }} *p_value);{{"\n"}}
    {%- endif %}
/***************************************************************************//**
 * @brief     Get {{ c.full_name }} characteristic value from the local GATT database.
    {%- if 'Peer Specific' in c.aux_properties %}
 * @param[in] conn_hdl Connection handle.
    {%- endif %}
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
    {%- if 'Peer Specific' in c.aux_properties %}
ble_status_t {{ c.api_name('get') }}(uint16_t conn_hdl, {{ c.type_name() }} *p_value);{{"\n"}}
    {%- else %}
ble_status_t {{ c.api_name('get') }}({{ c.type_name() }} *p_value);{{"\n"}}
    {%- endif %}
  {%- endif %}
  {%- if 'Notify' in c.properties %}
/***************************************************************************//**
 * @brief     Send notification of  {{ c.full_name }} characteristic value to the remote device.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value  Characteristic value to send.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t {{ c.api_name('notify') }}(uint16_t conn_hdl, const {{ c.type_name() }} *p_value);{{"\n"}}
  {%- endif %}
  {%- if 'Indicate' in c.properties %}
/***************************************************************************//**
 * @brief     Send indication of  {{ c.full_name }} characteristic value to the remote device.
 * @param[in] conn_hdl Connection handle.
 * @param[in] p_value  Characteristic value to send.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t {{ c.api_name('indicate') }}(uint16_t conn_hdl, const {{ c.type_name() }} *p_value);{{"\n"}}
  {%- endif %}
  {%- for d in c.descriptors %}
    {%- if 'Read' in d.properties %}
/***************************************************************************//**
 * @brief     Set {{ c.full_name }} {{ d.name }} descriptor value to the local GATT database.
      {%- if 'Peer Specific' in d.aux_properties %}
 * @param[in] conn_hdl Connection handle.
      {%- endif %}
 * @param[in] p_value  Descriptor value to set.
 * @return    @ref ble_status_t
*******************************************************************************/
      {%- if 'Peer Specific' in d.aux_properties %}
ble_status_t {{ d.api_name('set') }}(uint16_t conn_hdl, const {{ d.type_name() }} *p_value);{{"\n"}}
      {%- else %}
ble_status_t {{ d.api_name('set') }}(const {{ d.type_name() }} *p_value);{{"\n"}}
      {%- endif %}
/***************************************************************************//**
 * @brief     Get {{ c.full_name }} {{ d.name }} descriptor value from the local GATT database.
      {%- if 'Peer Specific' in d.aux_properties %}
 * @param[in] conn_hdl Connection handle.
      {%- endif %}
 * @param[out] p_value  Output location for the acquired descriptor value.
 * @return    @ref ble_status_t
*******************************************************************************/
      {%- if 'Peer Specific' in d.aux_properties %}
ble_status_t {{ d.api_name('get') }}(uint16_t conn_hdl, {{ d.type_name() }} *p_value);{{"\n"}}
      {%- else %}
ble_status_t {{ d.api_name('get') }}({{ d.type_name() }} *p_value);{{"\n"}}
      {%- endif %}
    {%- endif %}
  {%- endfor %}
{%- endfor %}
/*----------------------------------------------------------------------------------------------------------------------
    {{ s.full_name }} Service
----------------------------------------------------------------------------------------------------------------------*/{{"\n"}}
{%- for err_code in s.error_codes %}
/***************************************************************************//**
 * @brief {{ err_code.description }}
*******************************************************************************/
#define {{ err_code.err_code_def() }} (BLE_ERR_GROUP_GATT | {{ err_code.code }}){{"\n"}}
{%- endfor %}
/***************************************************************************//**
 * @brief {{ s.full_name }} characteristic Index.
*******************************************************************************/
typedef enum {
{%- for c in s.characteristics %}
    {{ c.macro_name('IDX') }},
  {%- for d in c.descriptors %}
    {{ d.macro_name('IDX') }},
  {%- endfor %}
{%- endfor %}
} e_ble_{{ s.name.lower() }}_char_idx_t;

/***************************************************************************//**
 * @brief {{ s.full_name }} event type.
*******************************************************************************/
typedef enum {
{%- for c in s.characteristics %}
    /* {{ c.full_name }} */
  {%- if 'Write' in c.properties %}
    {{ c.evt_name('write_req') }} = BLE_SERVS_ATTR_EVENT({{ c.macro_name('IDX') }}, BLE_SERVS_WRITE_REQ),
    {{ c.evt_name('write_comp') }} = BLE_SERVS_ATTR_EVENT({{ c.macro_name('IDX') }}, BLE_SERVS_WRITE_COMP),
  {%- endif %}
  {%- if 'WriteWithoutResponse' in c.properties %}
    {{ c.evt_name('write_cmd') }} = BLE_SERVS_ATTR_EVENT({{ c.macro_name('IDX') }}, BLE_SERVS_WRITE_CMD),
  {%- endif %}
  {%- if 'Read' in c.properties %}
    {{ c.evt_name('read_req') }} = BLE_SERVS_ATTR_EVENT({{ c.macro_name('IDX') }}, BLE_SERVS_READ_REQ),
  {%- endif %}
  {%- if 'Indicate' in c.properties %}
    {{ c.evt_name('hdl_val_cnf') }} = BLE_SERVS_ATTR_EVENT({{ c.macro_name('IDX') }}, BLE_SERVS_HDL_VAL_CNF),
  {%- endif %}
  {%- for d in c.descriptors %}
    {%- if 'Write' in d.properties %}
    {{ d.evt_name('write_req') }} = BLE_SERVS_ATTR_EVENT({{ d.macro_name('IDX') }}, BLE_SERVS_WRITE_REQ),
    {{ d.evt_name('write_comp') }} = BLE_SERVS_ATTR_EVENT({{ d.macro_name('IDX') }}, BLE_SERVS_WRITE_COMP),
    {%- endif %}
    {%- if 'Read' in d.properties %}
    {{ d.evt_name('read_req') }} = BLE_SERVS_ATTR_EVENT({{ d.macro_name('IDX') }}, BLE_SERVS_READ_REQ),
    {%- endif %}
  {%- endfor %}
{%- endfor %}
} e_ble_{{ s.name.lower() }}_event_t;

/***************************************************************************//**
 * @brief     Initialize {{ s.full_name }} service.
 * @param[in] cb Service callback.
 * @return    @ref ble_status_t
*******************************************************************************/
ble_status_t R_BLE_{{ s.name.upper() }}_Init(ble_servs_app_cb_t cb);

#endif /* R_BLE_{{ s.name.upper() }}_H */

/** @} */{{"\n"}}
