#!/usr/bin/python

import os, json, copy
import xml.etree.ElementTree as ET
from collections import OrderedDict

PATH = 'c:/Program Files (x86)/Bluetooth SIG/Bluetooth Developer Studio/XmlFiles/'
PROFILE_PATH        = PATH + 'Profiles/'
SERVICE_PATH        = PATH + 'Services/'
CHARACTERISTIC_PATH = PATH + 'Characteristics/'
DESCRIPTORS_PATH    = PATH + 'Descriptors/'

ABBREVIATIONS = {
    'Alert Notification Service': 'an',
    'Automation IO': 'aio',
    'Battery Service': 'ba',
    'Blood Pressure': 'bl',
    'Body Composition': 'bc',
    'Bond Management Service': 'bm',
    'Continuous Glucose Monitoring': 'cgm',
    'Current Time Service': 'ct',
    'Cycling Power': 'cp',
    'Cycling Speed and Cadence': 'csc',
    'Device Information': 'di',
    'Environmental Sensing': 'es',
    'Generic Access': 'gap',
    'Generic Attribute': 'gatt',
    'Glucose': 'gl',
    'Health Thermometer': 'ht',
    'Heart Rate': 'hr',
    'HTTP Proxy': 'hp',
    'Human Interface Device': 'hid',
    'Immediate Alert': 'ia',
    'Indoor Positioning': 'ip',
    'Insulin Delivery': 'id',
    'Link Loss': 'll',
    'Location and Navigation': 'ln',
    'Next DST Change Service': 'ndc',
    'Object Transfer Service': 'ot',
    'Phone Alert Status Service': 'pas',
    'Pulse Oximeter Service': 'plx',
    'Reference Time Update Service': 'rtu',
    'Running Speed and Cadence': 'rsc',
    'Scan Parameters': 'scp',
    'Transport Discovery': 'td',
    'Tx Power': 'tp',
    'User Data': 'ud',
    'Weight Scale': 'ws',
}

def map_format_to_c_type(format):
    if format in ['boolean']:
        return ('bool', 1)
    elif format in ['uint8', 'nibble', '2bit', '4bit', '8bit']:
        return ('uint8_t', 1)
    elif format in ['uint16', 'uint12', '16bit']:
        return ('uint16_t', 1)
    elif format in ['uint32']:
        return ('uint32_t', 1)
    elif format in ['sint8']:
        return ('int8_t', 1)
    elif format in ['sint16']:
        return ('int16_t', 1)
    elif format in ['sint32', 'sint24']:
        return ('int32_t', 1)
    elif format in ['uint24', '24bit', '32bit']:
        return ('uint32_t', 1)
    elif format in ['uint40']:
        return ('uint8_t', 5)
    elif format in ['uint48']:
        return ('uint8_t', 6)
    elif format in ['variable', 'utf8s', 'reg-cert-data-list']:
        return ('uint8_t', 'variable')
    elif format in ['SFLOAT']:
        return ('st_ble_ieee11073_sfloat_t', 1)
    elif format in ['FLOAT']:
        return ('st_ble_ieee11073_float_t', 1)
    else:
        return ('TODO(' + format + ')', 1)



def map_descriptor_size(name):
    if name == 'Client Characteristic Configuration':
        return 2
    elif name == 'Characteristic Extended Properties':
        return 2
    elif name == 'Server Characteristic Configuration':
        return 2
    elif name == 'Characteristic Presentation Format':
        return 7
    else:
        return 'TODO'

def split_uuid(uuid):
    if len(uuid) == 4:
        return ['0x'+uuid[2]+uuid[3], '0x'+uuid[0]+uuid[1]]
    return uuid

class DescriptorParser(object):

    def __init__(self):
        self._descriptor = OrderedDict()

    def parse(self, file_name):
        descriptor_elem = ET.parse(DESCRIPTORS_PATH + file_name).getroot()

        self._descriptor['name']    = descriptor_elem.attrib['name']

        value_elem = descriptor_elem.find('Value')
        
        if self._descriptor['name'] == 'Client Characteristic Configuration':
            self._descriptor['abbreviation'] = 'cli cnfg'
            self._descriptor['uuid']    = split_uuid(descriptor_elem.attrib['uuid'])
            self._descriptor['db_size'] = 2
            self._descriptor['description'] = self._descriptor['name'] + ' Descriptor'
            self._descriptor['properties'] = ["Read", "Write"],
            self._descriptor['aux_properties'] = ["Peer Specific"]
            self._descriptor['fields'] = []
            self._descriptor['fields'].append(OrderedDict())
            self._descriptor['fields'][0]['name'] = "cli cnfg"
            self._descriptor['fields'][0]['description'] = "Client Characteristic Configuration"
            self._descriptor['fields'][0]['format'] = "uint16_t"

        else:
            if value_elem is not None:
                self._descriptor['format'] = 'struct'
                self._descriptor['fields'] = []
                for field_elem in value_elem:
                    field = OrderedDict()
                    field['name'] = field_elem.attrib['name']
                    field['description'] = field_elem.attrib['name']
                    format_elem = field_elem.find('Format')
                    if format_elem is not None:
                        type = map_format_to_c_type(format_elem.text)
                        field['format'] = type[0]
                    else:
                        field['format'] = 'TODO'
                    self._descriptor['fields'].append(field)
            else:
                self._descriptor['format'] = 'TODO'

        return self._descriptor


class CharacteristicParser(object):

    def __init__(self):
        self._characteristic = OrderedDict()

    def _parse_enumerations(self, enumerations_elem):
        enumerations = []
        enumeration_elems = enumerations_elem.findall('Enumeration')
        if enumeration_elems is not None:
            for enumeration_elem in enumeration_elems:
                enumeration = OrderedDict()
                for k, v in enumeration_elem.items():
                    enumeration[to_int_if_possible(k)] = to_int_if_possible(v)
                enumeration['description'] = enumeration['value']
                enumerations.append(enumeration)
        return enumerations

    def _parse_informative(self, informative_elem):
        abstract_elem = informative_elem.find('Abstract')
        if abstract_elem is not None:
            return abstract_elem.text
        else:
            return 'TODO'

    def _parse_fields(self, value_elem):
        if value_elem is None:
            return []

        fields = []

        for field_elem in value_elem:
            field = OrderedDict()
            field['name'] = field_elem.attrib['name']
            field['description'] = field_elem.attrib['name']

            format_elem = field_elem.find('Format')
            reference_elem = field_elem.find('Reference')

            if format_elem is not None:
                format, length = map_format_to_c_type(format_elem.text)
                field['format'] = format

                # enumerations
                enumerations_elem = field_elem.find('Enumerations')
                if enumerations_elem is not None:
                    field['format'] = format
                    field['enumerations'] = self._parse_enumerations(enumerations_elem)

                # bit fields
                bitfield_elem = field_elem.find('BitField')
                if bitfield_elem is not None:
                    field['format'] = 'struct'
                    bits_elem = bitfield_elem.findall('Bit')
                    field['fields'] = []
                    for bit_elem in bits_elem:
                        bit = OrderedDict()
                        for k, v in bit_elem.items():
                            bit[to_int_if_possible(k)] = to_int_if_possible(v)

                        if 'name' in bit:
                            bit['description'] = bit['name']
                            if 'size' in bit and bit['size'] == 1:
                                bit['name'] = 'Is ' + bit['name']
                                bit['format'] = 'bool'
                            else:
                                bit['format'] = 'uint8_t'

                        bit.pop('index')
                        bit.pop('size')

                        field['fields'].append(bit)

            elif reference_elem is not None:
                if reference_elem.text == 'org.bluetooth.characteristic.date_time':
                    field['format'] = 'st_ble_date_time_t'

            fields.append(field)

        return fields

    def parse(self, file_name):
        characteristic_elem = ET.parse(CHARACTERISTIC_PATH + file_name).getroot()

        # name
        self._characteristic['name'] = characteristic_elem.attrib['name']

        # abbreviation
        self._characteristic['abbreviation'] = 'TODO'

        # description
        informative_elem = characteristic_elem.find('InformativeText')
        if informative_elem is not None:
            self._characteristic['description'] = self._parse_informative(informative_elem)
        else:
            self._characteristic['description'] = 'TODO'

        # uuid
        self._characteristic['uuid'] = split_uuid(characteristic_elem.attrib['uuid'])

        # db_size
        self._characteristic['db_size'] = 'TODO'

        # fields
        value_elem = characteristic_elem.find('Value')
        fields = self._parse_fields(value_elem)

        if (len(fields) == 1) and ('fields' in fields[0]):
            self._characteristic['fields'] = fields[0]['fields']
        else:
            self._characteristic['fields'] = fields

        return self._characteristic


class ServiceParser(object):

    def __init__(self):
        self._service = OrderedDict()

    def _parse_properties(self, properties_elem):
        properties = []
        for property_elem in properties_elem:
            if (property_elem.text != 'Excluded') and (property_elem.tag != 'InformationText'):
                properties.append(property_elem.tag)
        return properties

    def _parse_informative(self, informative_elem):
        abstract_elem = informative_elem.find('Abstract')
        if abstract_elem is not None:
            return abstract_elem.text
        else:
            return 'TODO'

    def parse(self, file_name):
        service_elem = ET.parse(SERVICE_PATH + file_name).getroot()

        # name
        self._service['name'] = service_elem.attrib['name']

        # abbreviation
        if self._service['name'] in ABBREVIATIONS:
            self._service['abbreviation'] = ABBREVIATIONS[self._service['name']]
        else:
            self._service['abbreviation'] = 'TODO'

        # description
        informative = service_elem.find('InformativeText')
        self._service['description'] = self._parse_informative(informative)

        # uuid
        self._service['uuid'] = split_uuid(service_elem.attrib['uuid'])

        # aux_properties
        self._service['aux_properties'] = ["None"]

        # error codes
        self._service['error_codes'] = []
        error_codes_elem = service_elem.find('ErrorCodes')
        if error_codes_elem is not None:
            for error_code_elem in error_codes_elem.findall('ErrorCode'):
                error_code = {
                    'name': error_code_elem.attrib['name'],
                    'code': error_code_elem.attrib['code'],
                    'description': 'TODO'
                }
                if 'Description' in error_code_elem.attrib:
                    error_code['description'] = error_code_elem.attrib['Description']

                self._service['error_codes'].append(error_code)

        # characteristics
        self._service['characteristics'] = []
        for characteristic_elem in service_elem.find('Characteristics'):
            cp = CharacteristicParser()
            characteristic = cp.parse(characteristic_elem.attrib['type'] + '.xml')

            # properties
            properties = characteristic_elem.find('Properties')
            if properties is not None:
                characteristic['properties'] = self._parse_properties(properties)
            characteristic['aux_properties'] = []

            # descriptors
            descriptors_elem = characteristic_elem.find('Descriptors')
            if descriptors_elem is not None:
                characteristic['descriptors'] = []
                for descriptor_elem in descriptors_elem:
                    dp = DescriptorParser()
                    descriptor = dp.parse(descriptor_elem.attrib['type'] + '.xml')

                    # properties
                    properties_elem = descriptor_elem.find('Properties')
                    descriptor['properties'] = []
                    for property_elem in properties_elem:
                        if property_elem.text != 'Excluded':
                            descriptor['properties'].append(property_elem.tag)

                    if "Read" in descriptor['properties']:
                        descriptor['db_size'] = map_descriptor_size(descriptor['name'])
                            
                    characteristic['descriptors'].append(descriptor)

            self._service['characteristics'].append(characteristic)

        return self._service


class ProfileParser(object):

    def __init__(self):
        self._profile = OrderedDict()
        pass

    def parse(self, file_name):
        profile_elem = ET.parse(PROFILE_PATH + file_name).getroot()

        self._profile['name'] = profile_elem.attrib['name']
        self._profile['services'] = []

        # Role element
        roles_elem = profile_elem.findall('Role')
        for role_elem in roles_elem:
            # Services element
            services_elem = role_elem.findall('Service')
            for service_elem in services_elem:
                service = OrderedDict()
                service['refer'] = '.'.join([service_elem.attrib['type'].split('.')[3], 'service.json'])
                s = json.loads(open('services/' + service['refer'], 'r').read())

                service['characteristics'] = []
                for c in s['characteristics']:
                    characteristic = OrderedDict()
                    characteristic['name'] = c['name']
                    if 'Read' in c['properties']:
                        if c['db_size'] == 'TODO':
                            characteristic['value'] = ['0x00']
                        else:
                            characteristic['value'] = ['0x00' for i in range(c['db_size'])]

                    if 'descriptors' in c:
                        characteristic['descriptors'] = []
                        for d in c['descriptors']:
                            descriptor = OrderedDict()
                            descriptor['name'] = d['name']
                            if 'Read' in d['properties']:
                                if d['db_size'] == 'TODO':
                                    descriptor['value'] = ['0x00']
                                else:
                                    descriptor['value'] = ['0x00' for i in range(d['db_size'])]
                                characteristic['descriptors'].append(descriptor)

                    service['characteristics'].append(characteristic)

                self._profile['services'].append(service)


        return self._profile


def output(file_name, data):
    with open(file_name, 'w') as file:
        file.write(data)

def to_int_if_possible(string):
    try:
        return int(string)
    except ValueError:
        return string

def make_base_json(data):
    for c in data['characteristics']:
        c.pop('refer', None)
        c.pop('fields', None)
    return data

if __name__ == '__main__':
    if not os.path.exists('services'):
        os.mkdir('services')

    if not os.path.exists('profiles'):
        os.mkdir('profiles')

    service_xmls = os.listdir(SERVICE_PATH)
    sp = ServiceParser()

    for xml in service_xmls:
        service_json = sp.parse(xml)
        dump = json.dumps(service_json, indent=4)
        output('services/' + '.'.join([xml.split('.')[3], 'service', 'json']), dump + "\n")

    profile_xmls = os.listdir(PROFILE_PATH)
    pp = ProfileParser()
    for xml in profile_xmls:
        dump = json.dumps(pp.parse(xml), indent=4)
        output('profiles/' + '.'.join([xml.split('.')[3], 'profile', 'json']), dump + "\n")
