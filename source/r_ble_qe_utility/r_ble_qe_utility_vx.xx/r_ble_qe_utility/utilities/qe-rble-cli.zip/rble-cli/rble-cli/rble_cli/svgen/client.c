/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products. No
* other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED. TO THE MAXIMUM
* EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES
* SHALL BE LIABLE FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS
* SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability of
* this software. By using this software, you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2019 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/
/***********************************************************************************************************************
 * File Name: r_ble_{{ s.name }}.c
 * Version : 1.0
 * Description : The source file for {{ s.full_name }} client.
 **********************************************************************************************************************/
#include "r_ble_{{ s.name.lower() }}.h"
#include "profile_cmn/r_ble_servc_if.h"{{"\n"}}
static st_ble_servc_info_t gs_client_info;{{"\n"}}
{%- for c in s.characteristics %}
    {%- if c.descriptors | length > 0 %}
        {%- for d in c.descriptors %}
/*----------------------------------------------------------------------------------------------------------------------
    {{ c.full_name }} {{ d.full_name }} descriptor
----------------------------------------------------------------------------------------------------------------------*/{{"\n"}}
/* {{ c.full_name }} characteristic descriptors attribute handles */
static uint16_t gs_{{ snake(c.name) }}_{{ snake(d.name) }}_desc_hdls[BLE_SERVC_MAX_NUM_OF_SAVED];{{"\n"}}
            {%- if not d.is_default_type() %}
static ble_status_t decode_{{ d.type_name() }}({{ d.type_name() }} *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
                {%- if qe %}
    ${}
    <#usercode("{{ c.full_name }} {{ d.full_name }} descriptor value decode function")/>
                {%- else %}
    /* TODO */
                {%- endif %}
    return BLE_SUCCESS;
}{{"\n"}}
static ble_status_t encode_{{ d.type_name() }}(const {{ d.type_name() }} *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
                {%- if qe %}
    ${}
    <#usercode("{{ c.full_name }} {{ d.full_name }} descriptor value encode function")/>
                {%- else %}
    /* TODO */
                {%- endif %}
    return BLE_SUCCESS;
}{{"\n"}}
            {%- endif %}
static const st_ble_servc_desc_info_t gs_{{ snake(c.name) }}_{{ snake(d.name) }} ={
            {%- if d.uuid_len > 2  %}
    .uuid_128    = {{ d.macro_name('uuid') }},
    .uuid_type   = BLE_GATT_128_BIT_UUID_FORMAT,
            {%- else %}
    .uuid_16     = {{ d.macro_name('uuid') }},
    .uuid_type   = BLE_GATT_16_BIT_UUID_FORMAT,
            {%- endif %}
            {%- if (d.fields | length == 1) and (d.fields[0].length == 'variable') %}
    .app_size    = {{ d.fields[0].macro_name('LEN') }},
            {%- else %}
    .app_size    = sizeof({{ d.type_name() }}),
            {%- endif %}
    .db_size     = {{ d.macro_name('LEN') }},
    .desc_idx    = {{ d.macro_name('IDX') }},
    .p_attr_hdls = gs_{{ snake(c.name) }}_{{ snake(d.name) }}_desc_hdls,
    .decode      = (ble_servc_attr_decode_t)decode_{{ d.type_name() }},
    .encode      = (ble_servc_attr_encode_t)encode_{{ d.type_name() }},
};{{"\n"}}
            {%- if 'Write' in d.properties %}
ble_status_t {{ d.api_name('write') }}(uint16_t conn_hdl, const {{ d.type_name() }} *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteDesc(&gs_{{ snake(c.name) }}_{{ snake(d.name) }}, conn_hdl, p_value);
}{{"\n"}}
            {%- endif %}
            {%- if 'Read' in d.properties %}
ble_status_t {{ d.api_name('read') }}(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadDesc(&gs_{{ snake(c.name) }}_{{ snake(d.name) }}, conn_hdl);
}{{"\n"}}
            {%- endif %}
        {%- endfor %}
    {%- endif %}
/*----------------------------------------------------------------------------------------------------------------------
    {{ c.full_name }} Characteristic
----------------------------------------------------------------------------------------------------------------------*/{{"\n"}}

/* {{ c.full_name }} characteristic 128 bit UUID */
{%- if c.uuid is not number %}
const uint8_t {{ c.macro_name('uuid') }}[BLE_GATT_128_BIT_UUID_SIZE] = { {{ c.uuid | join(', ') }} };
{%- endif %}

/* {{ c.full_name }} characteristic attribute handles */
static st_ble_gatt_hdl_range_t gs_{{ snake(c.name) }}_char_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];{{"\n"}}
    {%- if not c.is_default_type() %}
static ble_status_t decode_{{ c.type_name() }}({{ c.type_name() }} *p_app_value, const st_ble_gatt_value_t *p_gatt_value)
{
        {%- if qe %}
    ${}
    <#usercode("{{ c.full_name }} characteristic value decode function")/>
        {%- else %}
    /* TODO */
        {%- endif %}
    return BLE_SUCCESS;
}{{"\n"}}
static ble_status_t encode_{{ c.type_name() }}(const {{ c.type_name() }} *p_app_value, st_ble_gatt_value_t *p_gatt_value)
{
        {%- if qe %}
    ${}
    <#usercode("{{ c.full_name }} characteristic value encode function")/>
        {%- else %}
    /* TODO */
        {%- endif %}
    return BLE_SUCCESS;
}{{"\n"}}
    {%- endif %}
    {%- if c.descriptors | length > 0 %}
/* {{ c.full_name }} characteristic descriptor definition */
static const st_ble_servc_desc_info_t *gspp_{{ snake(c.name) }}_descs[] = {
        {%- for d in c.descriptors %}
    &gs_{{ snake(c.name) }}_{{ snake(d.name) }},
        {%- endfor %}
};{{"\n"}}
    {%- endif %}
/* {{ c.full_name }} characteristic definition */
const st_ble_servc_char_info_t gs_{{ snake(c.name) }}_char = {
    {%- if c.uuid_len > 2 %}
    .uuid_128     = {{ c.macro_name('uuid') }},
    .uuid_type    = BLE_GATT_128_BIT_UUID_FORMAT,
    {%- else %}
    .uuid_16      = {{ c.macro_name('uuid') }},
    .uuid_type    = BLE_GATT_16_BIT_UUID_FORMAT,
    {%- endif %}
    {%- if (c.fields | length == 1) and (c.fields[0].length == 'variable') %}
    .app_size     = {{ c.fields[0].macro_name('LEN') }},
    {%- else %}
    .app_size     = sizeof({{ c.type_name() }}),
    {%- endif %}
    .db_size      = {{ c.macro_name('LEN') }},
    .char_idx     = {{ c.macro_name('IDX') }},
    .p_attr_hdls  = gs_{{ snake(c.name) }}_char_ranges,
    .decode       = (ble_servc_attr_decode_t)decode_{{ c.type_name() }},
    .encode       = (ble_servc_attr_encode_t)encode_{{ c.type_name() }},
    {%- if c.descriptors | length > 0 %}
    .num_of_descs = ARRAY_SIZE(gspp_{{ snake(c.name) }}_descs),
    .pp_descs     = gspp_{{ snake(c.name) }}_descs,
    {%- endif %}
    {%- if c.descs | length > 0 %}
    .pp_descs     = gspp_{{ snake(c.name) }}_descs,
    .num_of_descs = ARRAY_SIZE(gspp_{{ snake(c.name) }}_descs),
    {%- endif %}
};{{"\n"}}
    {%- if 'Write' in c.properties %}
ble_status_t {{ c.api_name('write') }}(uint16_t conn_hdl, const {{ c.type_name() }} *p_value) // @suppress("API function naming")
{
    return R_BLE_SERVC_WriteChar(&gs_{{ snake(c.name) }}_char, conn_hdl, p_value);
}{{"\n"}}
    {%- endif %}
    {%- if 'Read' in c.properties %}
ble_status_t {{ c.api_name('read') }}(uint16_t conn_hdl) // @suppress("API function naming")
{
    return R_BLE_SERVC_ReadChar(&gs_{{ snake(c.name) }}_char, conn_hdl);
}{{"\n"}}
    {%- endif %}
void {{ c.api_name('get') }}AttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_{{ s.name }}_{{ snake(c.name) }}_attr_hdl_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    p_hdl->range = gs_{{ snake(c.name) }}_char_ranges[conn_idx];
    {%- for d in c.descriptors %}
    p_hdl->{{ snake(d.name) }}_desc_hdl = gs_{{ snake(c.name) }}_{{ snake(d.name) }}_desc_hdls[conn_idx];
    {%- endfor %}
}{{"\n"}}
{%- endfor %}

/*----------------------------------------------------------------------------------------------------------------------
    {{ s.full_name }} client
----------------------------------------------------------------------------------------------------------------------*/{{"\n"}}
/* {{ s.full_name }} client attribute handles */
static st_ble_gatt_hdl_range_t gs_{{ s.name }}_ranges[BLE_SERVC_MAX_NUM_OF_SAVED];

const st_ble_servc_char_info_t *gspp_{{ s.name.lower() }}_chars[] = {
{%- for c in s.characteristics %}
    &gs_{{ snake(c.name) }}_char,
{%- endfor %}
};

static st_ble_servc_info_t gs_client_info = {
    .pp_chars     = gspp_{{ s.name.lower() }}_chars,
    .num_of_chars = ARRAY_SIZE(gspp_{{ s.name.lower() }}_chars),
    .p_attr_hdls  = gs_{{ s.name }}_ranges,
};

ble_status_t R_BLE_{{ s.name.upper() }}_Init(ble_servc_app_cb_t cb) // @suppress("API function naming")
{
    if (NULL == cb)
    {
        return BLE_ERR_INVALID_PTR;
    }

    gs_client_info.cb = cb;

    return R_BLE_SERVC_RegisterClient(&gs_client_info);
}

void R_BLE_{{ s.name.upper() }}_ServDiscCb(uint16_t conn_hdl, uint8_t serv_idx, uint16_t type, void *p_param) // @suppress("API function naming")
{
    R_BLE_SERVC_ServDiscCb(&gs_client_info, conn_hdl, serv_idx, type, p_param);
}

void R_BLE_{{ s.name.upper() }}_GetServAttrHdl(const st_ble_dev_addr_t *p_addr, st_ble_gatt_hdl_range_t *p_hdl)
{
    uint8_t conn_idx;

    conn_idx = R_BLE_SERVC_GetConnIdx(p_addr);

    *p_hdl = gs_{{ s.name }}_ranges[conn_idx];
}

