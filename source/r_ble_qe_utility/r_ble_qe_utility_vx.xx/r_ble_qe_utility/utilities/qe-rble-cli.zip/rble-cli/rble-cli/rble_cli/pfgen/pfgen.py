import os, sys, re, json, argparse
from jinja2 import Environment, FileSystemLoader

SERVICE_JSON_PATH = os.environ['RBLE_SDK_PATH'] + "/" + "app_lib/services/json/services2/"
old_service_s_list=["an","bc","cp","csc","ftm","ht","hid","ia","id","plx","rsc","scp","ud","ws"]
old_service_c_list=["an","bc","csc","ftm","ia","id","hid","plx","rsc","scp","ud","ws"]

def generate(sjson, cjson, template, qe):
    context = {
        'sjson': sjson,
        'cjson': cjson,
        'uuid_length': uuid_length,
        'old_serv_s_list':old_service_s_list,
        'old_serv_c_list':old_service_c_list
    }

    TEMPLATE_ENVIRONMENT = Environment(
        autoescape=False,
        loader=FileSystemLoader(os.path.dirname(os.path.abspath(__file__))),
        trim_blocks=False)

    return TEMPLATE_ENVIRONMENT.get_template(template).render(context)

def uuid_length(uuid):
    return (len(uuid) * 8)

def main(args):
    parser = argparse.ArgumentParser(prog="rble-cli pfgen")

    parser.add_argument(
        'target',
        choices=['peripheral', 'central'],
    )

    parser.add_argument(
        'server_json',
        help='server side json file'
    )

    parser.add_argument(
        'client_json',
        help='client side json file'
    )

    parser.add_argument(
        '--out',
        default = '.',
        help='output directory of the generated source code'
    )

    parser.add_argument(
        '--qe',
        action='store_true'
    )

    args = parser.parse_args(args)

    cjs = []
    sjs = []

    sjp = SERVICE_JSON_PATH
    if args.qe:
        sjp = args.out + '/'

    sjson = json.loads(open(args.server_json, "r").read())
    for s in sjson['services']:
        sjs.append(json.loads(open(sjp + s['refer'], 'r').read()))

    cjson = json.loads(open(args.client_json, "r").read())
    for s in cjson['services']:
        cjs.append(json.loads(open(sjp + s['refer'], 'r').read()))

    if args.target == 'central':
        open(args.out + '/' + 'app_main.c', 'w').write(generate(sjs, cjs, 'app_main_central_template.c', args.qe))
    else:
        open(args.out + '/' + 'app_main.c', 'w').write(generate(sjs, cjs, 'app_main_peripheral_template.c', args.qe))

if __name__ == '__main__':
    main(sys.argv[1:])
