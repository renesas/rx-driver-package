import os, sys, re, json, argparse
from jinja2 import Environment, FileSystemLoader

SERVICE_JSON_PATH = os.environ['RBLE_SDK_PATH'] + "/" + "app_lib/services/json/services2/"
old_service_s_list=["bc","cp","ftm","hid","ia","id","scp","ud","ws"]
old_service_c_list=["bc","ftm","hid","ia","id","plx","scp","ud","ws"]
ABS_JSON_DEFAULT ='default_abs.json'


def abs_value(size, value):
    if value is None:
        return ['0x00' for i in range(size)]
    else:
        ret = ['0x00' for i in range(size)]

        temp_value = []
        if isinstance(value, (str, unicode)):
            temp_value = list(map(lambda x: "'"+x+"'", value))
        else:
            for i in value:
                if isinstance(i, int):
                    temp_value.append('0x' + format(i & 0xff, '02X'))
                else:
                    temp_value.append(i)
        if len(value) > size:
            for i in range(size):
                ret[i] = temp_value[i]
        else:
            for i in range(len(value)):
                ret[i] = temp_value[i]
        return ', '.join(ret)

def abs_macro_dev_filter(value):
    if "BLE_GAP_SCAN_ALLOW_ADV_ALL" in value:
        return "BLE_ABS_SCAN_ALL_STATIC"
    elif "BLE_GAP_SCAN_ALLOW_ADV_EXCEPT_DIRECTED" in value:
        return "BLE_ABS_SCAN_EXC_DIR_STATIC"
    else:
        return None



def generate(sjson, cjson, absjson, template, qe):
    context = {
        'sjson': sjson,
        'cjson': cjson,
        'uuid_length': uuid_length,
        'old_serv_s_list':old_service_s_list,
        'old_serv_c_list':old_service_c_list,
        'absjson': absjson,
        'abs_value': abs_value,
        'abs_macro_dev_filter': abs_macro_dev_filter
    }

    TEMPLATE_ENVIRONMENT = Environment(
        autoescape=False,
        loader=FileSystemLoader(os.path.dirname(os.path.abspath(__file__))),
        trim_blocks=False)

    return TEMPLATE_ENVIRONMENT.get_template(template).render(context)

def uuid_length(uuid):
    return (len(uuid) * 8)

def main(args):
    parser = argparse.ArgumentParser(prog="rble-cli pfgen")

    parser.add_argument(
        'target',
        choices=['peripheral', 'central'],
    )

    parser.add_argument(
        'server_json',
        help='server side json file'
    )

    parser.add_argument(
        'client_json',
        help='client side json file'
    )

    parser.add_argument(
        '-abs',
        default = ABS_JSON_DEFAULT,
        help='abs application json file'
    )

    parser.add_argument(
        '--out',
        default = '.',
        help='output directory of the generated source code'
    )

    parser.add_argument(
        '--qe',
        action='store_true'
    )

    args = parser.parse_args(args)

    cjs = []
    sjs = []

    sjp = SERVICE_JSON_PATH
    if args.qe:
        sjp = args.out + '/'

    sjson = json.loads(open(args.server_json, "r").read())
    for s in sjson['services']:
        sjs.append(json.loads(open(sjp + s['refer'], 'r').read()))

    cjson = json.loads(open(args.client_json, "r").read())
    for s in cjson['services']:
        cjs.append(json.loads(open(sjp + s['refer'], 'r').read()))

    if args.abs == ABS_JSON_DEFAULT:
        args.abs = os.path.dirname(os.path.abspath(__file__)) + '/' + ABS_JSON_DEFAULT
    absjson = json.loads(open(args.abs, "r").read())

    if args.target == 'central':
        open(args.out + '/' + 'app_main.c', 'w').write(generate(sjs, cjs, absjson, 'app_main_central_template.c', args.qe))
    else:
        open(args.out + '/' + 'app_main.c', 'w').write(generate(sjs, cjs, absjson, 'app_main_peripheral_template.c', args.qe))

if __name__ == '__main__':
    main(sys.argv[1:])
