import os, sys, re, json, argparse
from jinja2 import Environment, FileSystemLoader

namesub = r'[-\(\):\'\.,/]'

DEFAULT_TYPES = [
    'uint8_t', 'uint16_t', 'uint24_t', 'uint32_t',
    'int8_t',  'int16_t',  'int24_t',  'int32_t',
    'st_ble_seq_data_t',
]

def snake(name):
    if isinstance(name, unicode):
        name = name.encode()
    if isinstance(name, str):
        return re.sub(namesub, '_', '_'.join(name.lower().split(' ')))
    else:
        ns = []
        for n in name:
            ns.append(snake(n))
        return '_'.join(ns)

def constant(name):
    if isinstance(name, unicode):
        name = name.encode()
    if isinstance(name, str):
        return re.sub(namesub, '_', '_'.join(name.upper().split(' ')))
    else:
        ns = []
        for n in name:
            ns.append(constant(n))
        return '_'.join(ns)


def pascal(name):
    if isinstance(name, unicode):
        name = name.encode()
    if isinstance(name, str):
        return re.sub(namesub, '', ''.join(map(str.capitalize, str(name).split(' '))))
    else:
        ns = []
        for n in name:
            ns.pascal(snake(n))
        return ''.join(ns)

class Attribute(object):
    def __init__(self, parent, json):
        self.parent = parent
        self._name = json['name']
        self._abbr = json['abbreviation']
        self.description = json['description']
        self.uuid = self.parse_uuid(json['uuid'])
        self.uuid_len = len(json['uuid'])

    def parse_uuid(self, uuid):
        if len(uuid) == 2:
            return (int(uuid[1], 16) << 8) | (int(uuid[0], 16) << 0)
        else:
            return uuid

    @property
    def full_name(self):
        return self._name

    @property
    def name(self):
        if self._abbr is None:
            return self._name
        else:
            return self._abbr

    def hnames(self):
        if self.parent is not None:
            names = self.parent.hnames()
            names.append(self.name)
            return names
        else:
            return [self.name]

    def is_default_type(self):
        return self.type_name() in DEFAULT_TYPES

    # R_BLE_SERV_CmdChar
    def api_name(self, cmd):
        names = ['R_BLE']
        hnames = self.parent.hnames()
        names.append(constant(hnames[0])) # service
        if len(hnames) > 1:
            names.append(pascal(cmd) + pascal(hnames[1]) + pascal(self.name))
        else:
            names.append(pascal(cmd) + pascal(self.name))
        return '_'.join(names)

    # BLE_SERV_EVENT_CHAR_CMD
    def evt_name(self, evt):
        names = ['BLE']
        hnames = self.parent.hnames()
        names.append(constant(hnames[0]))
        names.append('EVENT')
        if len(hnames) > 1:
            names.append(constant(hnames[1:]))
        names.append(constant(self.name))
        names.append(constant(evt))
        return '_'.join(names)

    def type_name(self):
        if len(self.fields) > 1:
            return '_'.join(['st', 'ble', snake(self.parent.name), snake(self.name), 't'])
        elif self.fields[0].length > "1":
            return '_'.join(['st', 'ble', snake(self.parent.name), snake(self.name), 't'])
        else:
            return self.fields[0].fmt

    def macro_name(self, postfix):
        names = ['BLE']
        names.extend([constant(self.parent.hnames())])
        names.append(constant(self.name))
        names.append(constant(postfix))
        return '_'.join(names)

    def codec_name(self, cmd):
        if self.is_default_type():
            return '_'.join([cmd, self.type_name()])
        else:
            names = [cmd]
            names.extend(self.type_name())
            return snake(names)

class Service(Attribute):
    def __init__(self, sj):
        super(Service, self).__init__(None, sj)
        self.characteristics = []
        for cj in sj['characteristics']:
            self.characteristics.append(Characteristic(self, cj))
        self.error_codes = []
        for errj in sj['error_codes']:
            self.error_codes.append(ErroCode(self, errj))

class Characteristic(Attribute):
    def __init__(self, parent, cj):
        super(Characteristic, self).__init__(parent, cj)
        self.properties = cj['properties']
        self.aux_properties = cj['aux_properties']
        self.db_size = cj['db_size']
        self.descriptors = []
        for dj in cj['descriptors']:
            self.descriptors.append(Descriptor(self, dj))
        self.fields = []
        for fj in cj['fields']:
            self.fields.append(Field(self, fj))

    def end_hdl_name(self):
        if len(self.descriptors) > 0:
            return self.descriptors[-1].macro_name('DESC_HDL')
        else:
            return self.macro_name('VAL_HDL')

class Descriptor(Attribute):
    def __init__(self, parent, dj):
        super(Descriptor, self).__init__(parent, dj)
        self.properties = dj['properties']
        self.aux_properties = dj['aux_properties']
        self.db_size = dj['db_size']
        self.fields = []
        for fj in dj['fields']:
            self.fields.append(Field(self, fj))

class ErroCode(object):
    def __init__(self, parent, errj):
        self.parent = parent
        self.name = errj['name']
        self.code = errj['code']
        self.description = errj['description']

    def err_code_def(self):
        names = ['BLE']
        names.append(constant(self.parent.hnames()))
        names.append(constant(self.name))
        names.append('ERROR')
        return '_'.join(names)

class Enumeration(object):
    def __init__(self, parent, ej):
        self.parent = parent
        self.key = ej['key']
        self.value = ej['value']
        self.description = ej['description']

    def enum_def(self):
        names = ['BLE']
        names.append(constant(self.parent.hnames()))
        names.append(constant(self.value))
        return '_'.join(names)

class Field(object):
    def __init__(self, parent, fj):
        self.parent = parent
        self._name = fj['name']
        self._abbr = fj['abbreviation'] if 'abbreviation' in fj else None
        self.description = fj['description']
        self.fmt = fj['format']
        self.length = fj['length'] if 'length' in fj else 1
        self.fields = []
        self.enumerations = []
        if 'enumerations' in fj:
            for ej in fj['enumerations']:
                self.enumerations.append(Enumeration(self, ej))

        if 'fields' in fj:
            for ffj in fj['fields']:
                self.fields.append(Field(parent, ffj))

    @property
    def name(self):
        if self._abbr is None:
            return self._name
        else:
            return self._abbr

    def macro_name(self, postfix):
        names = ['BLE']
        names.extend([constant(self.parent.hnames())])
        names.append(constant(self.name))
        names.append(constant(postfix))
        return '_'.join(names)

    def hnames(self):
        if self.parent is not None:
            names = self.parent.hnames()
            names.append(self.name)
            return names
        else:
            return [self.name]

    def enum_name(self):
        return '_'.join(['e', 'ble', snake(self.parent.name), snake(self.name), 't'])

    def type_def(self):
        tn = ''
        if self.fmt == 'struct':
            tn = self.type_name()
        else:
            tn = self.fmt

        if self.length == 'variable':
            return tn + ' ' + snake(self.name) + '[' + self.macro_name('LEN') + ']'
        elif self.length > 1:
            if self.length == '1':
                return  tn + ' ' + snake(self.name)
            else:
                return tn + ' ' + snake(self.name) + '[' + str(self.length) + ']'
        else:
            return  tn + ' ' + snake(self.name)        

    def type_name(self):
        if len(self.fields) > 1:
            return '_'.join(['st', 'ble', snake(self.parent.name), snake(self.name), 't'])
        elif self.fields.length > 1:
            return '_'.join(['st', 'ble', snake(self.parent.name), snake(self.name), 't'])
        else:
            return self.fmt

def generate(sj, template, postfix, qe):
    s = Service(sj)

    context = {
        's': s,
        'qe': qe,
        'snake': snake,
        'constant': constant,
        'pascal': pascal,
    }

    TEMPLATE_ENVIRONMENT = Environment(
        autoescape=False,
        loader=FileSystemLoader(os.path.dirname(os.path.abspath(__file__))),
        trim_blocks=False)

    return TEMPLATE_ENVIRONMENT.get_template(template).render(context)

def main(args):
    parser = argparse.ArgumentParser(prog="rble-cli svgen")

    parser.add_argument(
        'target',
        choices=['server', 'client'],
    )

    parser.add_argument(
        'json',
        help='service json file'
    )

    parser.add_argument(
        '--out',
        default = '.',
        help='output directory of the generated source code'
    )

    parser.add_argument(
        '--qe',
        action='store_true'
    )

    args = parser.parse_args(args)

    sj = json.loads(open(args.json, "r").read())

    # fill a blank space
    if 'abbreviation' not in sj:
        #assert(False, 'Service shall have \'abbreviation\'')
        pass

    for cj in sj['characteristics']:
        if 'abbreviation' not in cj:
            cj['abbreviation'] = None
        if 'description' not in cj:
            cj['abbreviation'] = ''

        if 'length' not in cj:
            cj['length'] = 1

        if 'descriptors' not in cj:
            cj['descriptors'] = []

        for dj in cj['descriptors']:
            if 'abbreviation' not in dj:
                dj['abbreviation'] = None
            if 'description' not in dj:
                dj['abbreviation'] = ''
            if 'length' not in dj:
                dj['length'] = 1

    if args.target == 'client':
        sj['abbreviation'] += 'c'
        open(args.out + '/' + 'r_ble_' + sj['abbreviation'] + '.h', 'w').write(generate(sj, 'client.h', 'c', args.qe))
        open(args.out + '/' + 'r_ble_' + sj['abbreviation'] + '.c', 'w').write(generate(sj, 'client.c', 'c', args.qe))

    if args.target == 'server':
        sj['abbreviation'] += 's'
        open(args.out + '/' + 'r_ble_' + sj['abbreviation'] + '.h', 'w').write(generate(sj, 'server.h', 's', args.qe))
        open(args.out + '/' + 'r_ble_' + sj['abbreviation'] + '.c', 'w').write(generate(sj, 'server.c', 's', args.qe))

if __name__ == '__main__':
    main(sys.argv[1:])
