import argparse
import pkg_resources

def dispatch(argv):
    rc = pkg_resources.iter_entry_points('rble_cli.registered_commands')
    registerd_commands = dict((c.name, c) for c in rc)

    parser = argparse.ArgumentParser('rble-cli')

    parser.add_argument(
        'command',
        choices=registerd_commands.keys(),
        help='target command',
    )

    parser.add_argument(
        'args',
        nargs=argparse.REMAINDER
    )

    args = parser.parse_args(argv)
    main = registerd_commands[args.command].load()

    main(args.args)
